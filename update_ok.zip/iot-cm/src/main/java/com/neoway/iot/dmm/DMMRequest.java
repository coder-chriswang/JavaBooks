package com.neoway.iot.dmm;

import com.neoway.iot.dmm.common.Utils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @desc: DMMRequest
 * @author: 20200312686
 * @date: 2020/7/21 11:00
 */
@ApiModel("资源请求实体")
public class DMMRequest {
    @ApiModelProperty("产品域")
    private String ns= Utils.R_PRODUCT;
    @ApiModelProperty("资源主题")
    private String category=Utils.R_CATEGORY;
    @ApiModelProperty("资源类型")
    private String ci;
    @ApiModelProperty("操作指令")
    private String action;
    @ApiModelProperty(value = "请求ID",hidden = true)
    private String reqId;
    @ApiModelProperty(value = "请求时间",hidden = true)
    private long ts;
    @ApiModelProperty("请求数据")
    private Object data;

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getCi() {
        return ci;
    }

    public String getAction() {
        return action;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
