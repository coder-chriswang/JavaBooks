package com.neoway.iot.dmm.handler.filter;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;

/**
 * @desc: DmmRspFilter
 * @author: 20200312686
 * @date: 2020/7/27 16:53
 */
public interface DmmRspFilter {
    /**
     * @desc 响应报文过滤器
     * @param request
     * @param response
     */
    void filter(DMMRequest request,DMMResponse response);
}
