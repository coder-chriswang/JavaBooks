package com.neoway.iot.dmm.handler.filter;

import com.neoway.iot.dmm.DMMRequest;

/**
 * @desc: DMMFilter
 * @author: 20200312686
 * @date: 2020/7/27 16:16
 */
public interface DmmReqFilter {
    /**
     * @desc 过滤器
     * @param request
     */
    void filter(DMMRequest request);
}
