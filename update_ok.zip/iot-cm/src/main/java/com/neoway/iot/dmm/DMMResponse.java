package com.neoway.iot.dmm;
/**
 * @desc: DMMResponse
 * @author: 20200312686
 * @date: 2020/7/21 11:01
 */
public class DMMResponse {
    public transient static int NOK=500;
    private int code;
    private String msg="";
    private int ts;
    private Object data;
    private transient boolean needFilter=true;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getTs() {
        return ts;
    }

    public void setTs(int ts) {
        this.ts = ts;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public boolean isOK(){
        return this.getCode() == 0;
    }

    public boolean isNeedFilter() {
        return needFilter;
    }

    public void setNeedFilter(boolean needFilter) {
        this.needFilter = needFilter;
    }
}
