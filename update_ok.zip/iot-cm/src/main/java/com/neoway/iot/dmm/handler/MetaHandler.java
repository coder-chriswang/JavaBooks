package com.neoway.iot.dmm.handler;

import com.neoway.iot.dmm.common.Utils;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * @desc: 元数据管理
 * @author: 20200312686
 * @date: 2020/7/21 10:59
 */
public class MetaHandler {
    private DMRunner runner;
    public MetaHandler(){
        this.runner=DMRunner.getInstance();
    }

    /**
     * @desc 查询指定CI元数据
     * @param ns 产品域
     * @param ci ci对象
     * @return
     */
    public DMMetaCI getMetaCI(String ns, String category,String ci){
        if(StringUtils.isEmpty(ns)
                || StringUtils.isEmpty(ci)
                || StringUtils.isEmpty(category)){
            return null;
        }
        return runner.getMetaCI(ns, category,ci);
    }

    /**
     * @desc 查询指定条件的元数据
     * @param condition
     * @return
     */
    public List<DMMetaCI> queryMetaCI(DMMetaCI condition) {
        List<DMMetaCI> values=runner.queryMetaCi(condition);
        return values;
    }
}
