#!/bin/bash

##mini产品发布库目录
MINI_RELEASE_PACKAGE="/opt/hera/release"
MINI_RELEASE_VERSION="1.0.0"
##minideploy产品名称
MINIDEPLOY_PRODUCT_NAME="mini-deploy"
OS_CENTOS_7="centos"

##MINIDEPLOY工具包源码目录
MINIDEPLOY_CODE_HOME="/opt/hera/build/hera/mini-deploy"
##MINIDEPLOY工具包工作父目录
MINIDEPLOY_TMP="/tmp"
##MINIDEPLOY工具包制作目录
MINIDEPLOY_TMP_HOME="$MINIDEPLOY_TMP/$MINIDEPLOY_PRODUCT_NAME"
MINIDEPLOY_TMP_RUNTIME="$MINIDEPLOY_TMP_HOME/runtime"
MINIDEPLOY_TMP_DEPEDENCY="$MINIDEPLOY_TMP_HOME/dependency"

##下载部署工具centos下rpm依赖包:https://centos.pkgs.org/
function centos_down_depedency(){
  echo "下载centos下depedency开始:当前路径：$MINIDEPLOY_TMP_DEPEDENCY..........."
  mkdir -p $MINIDEPLOY_TMP_DEPEDENCY
  cd $MINIDEPLOY_TMP_DEPEDENCY
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/libyaml-0.1.4-11.el7_0.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/PyYAML-3.10-11.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-backports-ssl_match_hostname-3.5.0.1-1.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-backports-1.0-8.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-enum34-1.0.4-1.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-idna-2.4-1.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/extras/x86_64/Packages/python-httplib2-0.9.2-1.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-ipaddress-1.0.16-2.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-markupsafe-0.11-10.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-jinja2-2.7.2-4.el7.noarch.rpm
  ##wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-jinja2-2.7.2-2.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-ply-3.4-11.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-pycparser-2.14-1.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-babel-0.9.6-8.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-paramiko-2.1.1-9.el7.noarch.rpm
  #wget http://mirror.centos.org/centos/7/updates/x86_64/Packages/python-paramiko-2.1.1-9.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python2-cryptography-1.7.2-2.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/extras/x86_64/Packages/python2-jmespath-0.9.0-3.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-cffi-1.6.0-5.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/extras/x86_64/Packages/sshpass-1.06-2.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python2-pyasn1-0.1.9-7.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/python-setuptools-0.9.8-7.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/extras/x86_64/Packages/python-passlib-1.6.5-2.el7.noarch.rpm
  wget --no-check-certificate https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/a/ansible-2.9.6-1.el7.noarch.rpm
  echo "下载centos下depedency结束..........."
}
##制作部署工具-centos发布包
function centos_createReleasePackage(){
  echo '******************制作部署工具发布包-centos版本********************'
  cp -rf $MINIDEPLOY_CODE_HOME/deploy_$OS_CENTOS_7.sh $MINIDEPLOY_TMP_HOME
  mv $MINIDEPLOY_TMP_HOME/deploy_$OS_CENTOS_7.sh $MINIDEPLOY_TMP_HOME/deploy.sh 
  mkdir -p $MINI_RELEASE_PACKAGE
  rm -rf $MINI_RELEASE_PACKAGE/$MINIDEPLOY_PRODUCT_NAME-$OS_CENTOS_7.tar.gz
  cd $MINIDEPLOY_TMP
  tar -zcvf $MINI_RELEASE_PACKAGE/$MINIDEPLOY_PRODUCT_NAME-$OS_CENTOS_7.tar.gz $MINIDEPLOY_PRODUCT_NAME
  echo '******************制作部署工具发布包-centos版本结束********************'
}

rm -rf $MINIDEPLOY_TMP_HOME
centos_down_depedency
centos_createReleasePackage
rm -rf $MINIDEPLOY_TMP_HOME
echo "**************************生成MINIDEPLOY安装包结束*******************************************"
exit 0
