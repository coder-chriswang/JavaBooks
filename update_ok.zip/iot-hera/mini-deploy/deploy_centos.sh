#!/bin/bash

##安装部署工具
MINIDEPLOY_HOME=$(cd "$(dirname "$0")";pwd)
MINIDEPLOY_DEPEDENCY=$(cd "$MINIDEPLOY_HOME"/dependency;pwd)

DEPEDENCYS=(
"libyaml-0.1.4-11.el7_0.x86_64.rpm"
"PyYAML-3.10-11.el7.x86_64.rpm"
"python-ipaddress-1.0.16-2.el7.noarch.rpm"
"python-backports-1.0-8.el7.x86_64.rpm" 
"python-backports-ssl_match_hostname-3.5.0.1-1.el7.noarch.rpm"
"python-enum34-1.0.4-1.el7.noarch.rpm" 
"python-idna-2.4-1.el7.noarch.rpm" 
"python-httplib2-0.9.2-1.el7.noarch.rpm"
"python-markupsafe-0.11-10.el7.x86_64.rpm" 
"python-babel-0.9.6-8.el7.noarch.rpm" 
"python-jinja2-2.7.2-4.el7.noarch.rpm"
"python-ply-3.4-11.el7.noarch.rpm" 
"python-pycparser-2.14-1.el7.noarch.rpm" 
"python2-pyasn1-0.1.9-7.el7.noarch.rpm" 
"python-cffi-1.6.0-5.el7.x86_64.rpm" 
"python-setuptools-0.9.8-7.el7.noarch.rpm"
"python-paramiko-2.1.1-9.el7.noarch.rpm" 
"python2-cryptography-1.7.2-2.el7.x86_64.rpm" 
"python2-jmespath-0.9.0-3.el7.noarch.rpm" 
"sshpass-1.06-2.el7.x86_64.rpm" 
"python-passlib-1.6.5-2.el7.noarch.rpm"
"ansible-2.9.6-1.el7.noarch.rpm" 
)

##安装部署工具及其依赖包
function install_ansible(){
  echo "安装depedency开始:$MINIDEPLOY_DEPEDENCY..........."
  cd $MINIDEPLOY_DEPEDENCY
  for package in ${DEPEDENCYS[@]};do
    echo "[depedency安装]------$package..........."
    rpm -ivh $package
  done
  echo "安装depedency结束..........."
}
install_ansible
echo "**************************安装MINIDEPLOY结束*******************************************"
exit 0
