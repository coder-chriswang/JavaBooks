#!/bin/bash


######################################################################
# name:第三方服务包制作脚本
# desc:包含第三方runtime、gpaas。
# author：xujianying
# slogan：第三方服务包制作脚本
######################################################################
##制作的第三方包归档路径
RD3_RELEASE_PACKAGE="/opt/hera/repo"
##制作第三方包临时路径
RD3_TMP_PACKAGE="/tmp/3rd-software"
##公司品牌
LOGO="neoway"
##产品品牌
PRODUCT="iotcloud"
SERVICE_RUN="/opt/$LOGO/$PRODUCT"

##扩展脚本目录
BUILD_MINI_BUILD_HOME="/opt/hera/build/mini-build"
OS_UBUNTU_16="ubuntu"
OS_CENTOS_7="centos"


######################################################################
# runtime包制作：erlang、nodejs、openjdk、jvm诊断工具
######################################################################


#--------------------------------------------
# name:arthas包制作脚本
# desc:jvm性能诊断工具
# author：xujianying
#--------------------------------------------
function create_runtime_arthas(){
  echo "开始制作arthas工具包"
  mkdir -p $RD3_TMP_PACKAGE/arthas
  rm -rf $RD3_RELEASE_PACKAGE/arthas.tar.gz
  cd $RD3_TMP_PACKAGE/arthas
  wget https://maven.aliyun.com/repository/public/com/taobao/arthas/arthas-packaging/3.1.8/arthas-packaging-3.1.8-bin.zip
  unzip arthas-packaging-3.1.8-bin.zip
  cd $RD3_TMP_PACKAGE
  tar -zcvf $RD3_RELEASE_PACKAGE/runtime-arthas.tar.gz arthas
  rm -rf $RD3_TMP_PACKAGE/arthas
  echo "arthas工具包制作结束"
}

#--------------------------------------------
# name:erlang包制作脚本
# desc:rabbitmq运行时
# author：xujianying
#--------------------------------------------
function create_runtime_erlang(){
  echo "开始制作erlang服务包"
  mkdir -p $RD3_TMP_PACKAGE/erlang
  rm -rf $RD3_RELEASE_PACKAGE/runtime-erlang.tar.gz
  cd $RD3_TMP_PACKAGE/erlang
  wget http://erlang.org/download/otp_src_22.3.tar.gz
  tar -xvf otp_src_22.3.tar.gz

  mkdir -p /opt/neoway/runtime/erlang
  cd otp_src_22.3
  yum install ncurses-devel
  yum install openssl openssl-devel
  ./configure -prefix=/opt/neoway/runtime/erlang 
  make
  make install
  cd /opt/neoway/runtime/
  tar -zcvf $RD3_RELEASE_PACKAGE/runtime-erlang.tar.gz erlang
  rm -rf $RD3_TMP_PACKAGE/erlang
  rm -rf /opt/neoway/runtime/
  echo "erlang服务包制作结束"

}
#--------------------------------------------
# name:nodejs包制作脚本
# desc:nodejs
# author：xujianying
#--------------------------------------------
function create_runtime_nodejs(){
  echo "开始制作nodejs服务包"
  mkdir -p $RD3_TMP_PACKAGE/nodejs
  rm -rf $RD3_RELEASE_PACKAGE/runtime-nodejs.tar.gz
  rm -rf /usr/local/bin/node
  rm -rf /usr/local/bin/npm
  cd $RD3_TMP_PACKAGE/nodejs
  wget https://nodejs.org/dist/v8.11.3/node-v8.11.3-linux-x64.tar.gz
  tar -xvf node-v8.11.3-linux-x64.tar.gz
  mv node-v8.11.3-linux-x64 node
  ln -s $RD3_TMP_PACKAGE/nodejs/node/bin/node /usr/local/bin/
  ln -s $RD3_TMP_PACKAGE/nodejs/node/bin/npm /usr/local/bin/
  cd $RD3_TMP_PACKAGE/nodejs
  tar -zcvf $RD3_RELEASE_PACKAGE/runtime-nodejs.tar.gz node
  echo "nodejs服务包制作结束"

}
#--------------------------------------------
# name:openjdk包制作脚本
# desc:openjdk
# author：xujianying
#--------------------------------------------
function create_runtime_openjdk(){
  echo "开始制作openjdk服务包"
  echo "openjdk服务包制作结束"
}

#--------------------------------------------
# name:php71包制作脚本
# desc:php74
# author：xujianying
#--------------------------------------------
function create_runtime_php74(){
  echo "开始制作php74服务包"
  ##安装php依赖：
  yum install libxml2 libxml2-devel openssl openssl-devel bzip2 bzip2-devel libcurl libcurl-devel libjpeg libjpeg-devel libpng libpng-devel freetype freetype-devel gmp gmp-devel libmcrypt libmcrypt-devel readline readline-devel libxslt libxslt-devel zlib zlib-devel glibc glibc-devel glib2 glib2-devel ncurses curl gdbm-devel db4-devel libXpm-devel libX11-devel gd-devel gmp-devel expat-devel xmlrpc-c xmlrpc-c-devel libicu-devel libmcrypt-devel libmemcached-devel sqlite-devel oniguruma-devel
  mkdir -p $RD3_TMP_PACKAGE/php
  cd $RD3_TMP_PACKAGE/php
  wget http://php.net/distributions/php-7.4.6.tar.gz
  tar -zxvf php-7.4.6.tar.gz
  cd php-7.4.6
  ./configure \
  --prefix=/opt/neoway/runtime/php \
  --with-config-file-path=/opt/neoway/runtime/php/etc \
  --enable-fpm \
  --with-fpm-user=www  \
  --with-fpm-group=www \
  --enable-inline-optimization \
  --disable-debug \
  --disable-rpath \
  --enable-shared  \
  --enable-soap \
  --with-libxml-dir \
  --with-xmlrpc \
  --with-openssl \
  --with-mcrypt \
  --with-mhash \
  --with-pcre-regex \
  --with-sqlite3 \
  --with-zlib \
  --enable-bcmath \
  --with-iconv \
  --with-bz2 \
  --enable-calendar \
  --with-curl \
  --with-cdb \
  --enable-dom \
  --enable-exif \
  --enable-fileinfo \
  --enable-filter \
  --with-pcre-dir \
  --enable-ftp \
  --with-gd \
  --with-openssl-dir \
  --with-jpeg-dir \
  --with-png-dir \
  --with-zlib-dir  \
  --with-freetype-dir \
  --enable-gd-native-ttf \
  --enable-gd-jis-conv \
  --with-gettext \
  --with-gmp \
  --with-mhash \
  --enable-json \
  --enable-mbstring \
  --enable-mbregex \
  --enable-mbregex-backtrack \
  --with-libmbfl \
  --with-onig \
  --enable-pdo \
  --with-mysqli=mysqlnd \
  --with-pdo-mysql=mysqlnd \
  --with-zlib-dir \
  --with-pdo-sqlite \
  --with-readline \
  --enable-session \
  --enable-shmop \
  --enable-simplexml \
  --enable-sockets  \
  --enable-sysvmsg \
  --enable-sysvsem \
  --enable-sysvshm \
  --enable-wddx \
  --with-libxml-dir \
  --with-xsl \
  --enable-zip \
  --enable-mysqlnd-compression-support \
  --with-pear \
  --enable-opcache
  make 
  make install
  cd /opt/neoway/runtime/
  tar -zcvf $RD3_RELEASE_PACKAGE/runtime-php.tar.gz php
  rm -rf $RD3_TMP_PACKAGE/php
  rm -rf /opt/neoway/runtime/
  echo "php74服务包制作结束"
}

######################################################################
# ops包制作：prometheus、grafana、各种exporter、ansible awx、consul
######################################################################


#--------------------------------------------
# name:grafana包制作脚本
# desc:监控dashboard
# author：xujianying
#--------------------------------------------
function create_gpaas_grafana(){
  echo "开始制作grafana服务包"
  mkdir -p $RD3_TMP_PACKAGE/grafana
  rm -rf $RD3_RELEASE_PACKAGE/grafana.tar.gz
  cd $RD3_TMP_PACKAGE/grafana
  wget https://dl.grafana.com/oss/release/grafana-6.2.5.linux-amd64.tar.gz
  tar -xvf grafana-6.2.5.linux-amd64.tar.gz
  mv grafana-6.2.5 grafana
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-grafana.tar.gz grafana
  rm -rf $RD3_TMP_PACKAGE/grafana
  echo "grafana服务包制作结束"
}
#--------------------------------------------
# name:prometheus包制作脚本
# desc:监控Server
# author：xujianying
#--------------------------------------------
function create_gpaas_prometheus(){
  echo "开始制作prometheus服务包"
  mkdir -p $RD3_TMP_PACKAGE/prometheus
  rm -rf $RD3_RELEASE_PACKAGE/prometheus.tar.gz
  cd $RD3_TMP_PACKAGE/prometheus
  wget https://github.com/prometheus/prometheus/releases/download/v2.11.1/prometheus-2.11.1.linux-amd64.tar.gz
  tar -xvf prometheus-2.11.1.linux-amd64.tar.gz
  mv prometheus-2.11.1.linux-amd64 prometheus 
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-prometheus.tar.gz prometheus
  rm -rf $RD3_TMP_PACKAGE/prometheus
  echo "prometheus服务包制作结束"
}

#--------------------------------------------
# name:redis-exporter包制作脚本
# desc:redis监控agent。
# author：xujianying
#--------------------------------------------
function create_gpaas_redis_exporter(){
  echo "开始制作redis-exporter服务包"
  mkdir -p $RD3_TMP_PACKAGE/redis-exporter
  rm -rf $RD3_RELEASE_PACKAGE/redis-exporter.tar.gz
  cd $RD3_TMP_PACKAGE/redis-exporter
  wget https://github.com/oliver006/redis_exporter/releases/download/v1.1.0/redis_exporter-v1.1.0.linux-amd64.tar.gz
  tar -xvf redis_exporter-v1.1.0.linux-amd64.tar.gz
  mv redis_exporter-v1.1.0.linux-amd64 redis-exporter 
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-redis-exporter.tar.gz redis-exporter
  rm -rf $RD3_TMP_PACKAGE/redis-exporter
  echo "redis-exporter服务包制作结束"
}
#--------------------------------------------
# name:mysql-exporter包制作脚本
# desc:mysql监控agent。
# author：xujianying
#--------------------------------------------
function create_gpaas_mysql_exporter(){
  echo "开始制作mysql-exporter服务包"
  mkdir -p $RD3_TMP_PACKAGE/mysql-exporter
  rm -rf $RD3_RELEASE_PACKAGE/mysql-exporter.tar.gz
  cd $RD3_TMP_PACKAGE/mysql-exporter
  wget https://github.com/prometheus/mysqld_exporter/releases/download/v0.12.1/mysqld_exporter-0.12.1.linux-amd64.tar.gz
  tar -xvf mysqld_exporter-0.12.1.linux-amd64.tar.gz
  mv mysqld_exporter-0.12.1.linux-amd64 mysql-exporter
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-mysql-exporter.tar.gz mysql-exporter
  rm -rf $RD3_TMP_PACKAGE/mysql-exporter
  echo "mysql-exporter服务包制作结束"
}

#--------------------------------------------
# name:node-exporter包制作脚本
# desc:os监控agent。
# author：xujianying
#--------------------------------------------
function create_gpaas_node_exporter(){
  echo "开始制作node-exporter服务包"
  mkdir -p $RD3_TMP_PACKAGE/node-exporter
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-node-exporter.tar.gz
  cd $RD3_TMP_PACKAGE/node-exporter
  wget https://github.com/prometheus/node_exporter/releases/download/v0.18.1/node_exporter-0.18.1.linux-amd64.tar.gz
  tar -xvf node_exporter-0.18.1.linux-amd64.tar.gz
  mv node_exporter-0.18.1.linux-amd64 node-exporter
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-node-exporter.tar.gz node-exporter
  rm -rf $RD3_TMP_PACKAGE/node-exporter
  echo "node-exporter服务包制作结束"
}

#--------------------------------------------
# name:elastic-exporter包制作脚本
# desc:elastic监控agent。
# author：xujianying
#--------------------------------------------
function create_gpaas_elastic_exporter(){
  echo "开始制作elastic-exporter服务包"
  mkdir -p $RD3_TMP_PACKAGE/elastic-exporter
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-elastic-exporter.tar.gz
  cd $RD3_TMP_PACKAGE/elastic-exporter
  wget https://github.com/justwatchcom/elasticsearch_exporter/releases/download/v1.1.0rc1/elasticsearch_exporter-1.1.0rc1.linux-amd64.tar.gz
  tar -xvf elasticsearch_exporter-1.1.0rc1.linux-amd64.tar.gz
  mv elasticsearch_exporter-1.1.0rc1.linux-amd64 elastic-exporter
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-elastic-exporter.tar.gz elastic-exporter
  rm -rf $RD3_TMP_PACKAGE/elastic-exporter
  echo "elastic-exporter服务包制作结束"
}

#--------------------------------------------
# name:consul包制作脚本
# desc:服务注册中心-consul
# author：xujianying
#--------------------------------------------
function create_gpaas_consul(){
  echo "开始制作consul服务包"
  mkdir -p $RD3_TMP_PACKAGE/consul
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-consul.tar.gz
  cd $RD3_TMP_PACKAGE/consul
  wget https://release.hashicorp.com/consul/1.7.3/consul_1.7.3_linux_amd64.zip
  unzip consul_1.7.3_linux_amd64.zip
  rm -rf consul_1.7.3_linux_amd64.zip
  cd $RD3_TMP_PACKAGE/
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-consul.tar.gz consul
  rm -rf $RD3_TMP_PACKAGE/consul
  echo "consul服务包制作结束"
}
#--------------------------------------------
# name:consul-template包制作脚本
# desc:服务注册中心-consul-template
# author：xujianying
#--------------------------------------------
function create_gpaas_consul_template(){
  echo "开始制作consul_template服务包"
  mkdir -p $RD3_TMP_PACKAGE/consul-template
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-consul-template.tar.gz
  cd $RD3_TMP_PACKAGE/consul-template
  wget https://releases.hashicorp.com/consul-template/0.25.0/consul-template_0.25.0_linux_amd64.tgz
  tar -xvf consul-template_0.25.0_linux_amd64.tgz
  rm -rf consul-template_0.25.0_linux_amd64.tgz
  cd $RD3_TMP_PACKAGE/
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-consul-template.tar.gz consul-template
  rm -rf $RD3_TMP_PACKAGE/consul-template
  echo "consul_template服务包制作结束"
}
#--------------------------------------------
# name:ansible-awx包制作脚本
# desc:部署变更服务-ansible-awx
# author：xujianying
#--------------------------------------------
function create_gpaas_ansible_awx(){
  echo "开始制作ansible-awx服务包"
  echo "ansible-awx服务包制作结束"
}
#--------------------------------------------
# name:mysql-admin包制作脚本
# desc:mysql-配置管理
# author：xujianying
#--------------------------------------------
function create_gpaas_mysql_admin(){
  echo "开始制作mysqladmin服务包"
  mkdir -p $RD3_TMP_PACKAGE/mysqladmin
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-mysqladmin.tar.gz
  cd $RD3_TMP_PACKAGE/mysqladmin
  wget https://files.phpmyadmin.net/phpMyAdmin/5.0.2/phpMyAdmin-5.0.2-all-languages.tar.gz
  tar -xvf phpMyAdmin-5.0.2-all-languages.tar.gz
  mv phpMyAdmin-5.0.2-all-languages mysqladmin
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-mysqladmin.tar.gz mysqladmin
  rm -rf $RD3_TMP_PACKAGE/mysqladmin
  echo "mysqladmin服务包制作结束"
}
#--------------------------------------------
# name:rabbitmq-admin包制作脚本
# desc:rabbitmq-配置管理
# author：xujianying
#--------------------------------------------
function create_gpaas_rabbitmq_admin(){
  echo "开始制作rabbitmq-admin服务包"
  echo "rabbitmq-admin服务包制作结束"
}
#--------------------------------------------
# name:hbase-admin包制作脚本
# desc:hbase-配置管理
# author：xujianying
#--------------------------------------------
function create_gpaas_hbase_admin(){
  echo "开始制作hbase-admin服务包"
  echo "hbase-admin服务包制作结束"
}

######################################################################
#
# 数据存储相关包制作：mysql、redis、elasticsearch、hbase、fastdfs、rabbitmq
#
######################################################################

#--------------------------------------------
# name:elastic包制作脚本
# desc:elastic数据库。
# author：xujianying
#--------------------------------------------
function create_gpaas_elasticsearch(){
  echo "开始制作elasticsearch服务包"
  mkdir -p $RD3_TMP_PACKAGE/elasticsearch
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-elasticsearch.tar.gz
  cd $RD3_TMP_PACKAGE/elasticsearch
  wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-6.2.4.tar.gz
  tar -xvf elasticsearch-6.2.4.tar.gz
  mv elasticsearch-6.2.4 elasticsearch
  $RD3_TMP_PACKAGE/elasticsearch/elasticsearch/bin/elasticsearch-plugin -v install https://github.com/medcl/elasticsearch-analysis-ik/releases/download/v6.2.4/elasticsearch-analysis-ik-6.2.4.zip
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-elasticsearch.tar.gz elasticsearch
  rm -rf $RD3_TMP_PACKAGE/elasticsearch
  echo "elasticsearch服务包制作结束"
}

#--------------------------------------------
# name:emq包制作脚本
# desc:emq。
# author：xujianying
#--------------------------------------------
function create_gpaas_emq(){
  echo "开始制作emq服务包"
  mkdir -p $RD3_TMP_PACKAGE/emq
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-emq.tar.gz
  cd $RD3_TMP_PACKAGE/emq
  wget https://github.com/emqx/emqx/releases/download/v4.1.0/emqx-centos7-v4.1.0.zip
  unzip emqx-centos7-v4.1.0.zip 
  mv emqx emq
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-emq.tar.gz emq
  rm -rf $RD3_TMP_PACKAGE/emq
  echo "emq服务包制作结束"
}

#--------------------------------------------
# name:mysql包制作脚本
# desc:mysql数据库。
# author：xujianying
#--------------------------------------------
function create_gpaas_mysql(){
  echo "开始制作mysql服务包"
  mkdir -p $RD3_TMP_PACKAGE/mysql
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-mysql.tar.gz
  cd $RD3_TMP_PACKAGE/mysql
  wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-5.7.27-linux-glibc2.12-x86_64.tar.gz
  tar -xvf mysql-5.7.27-linux-glibc2.12-x86_64.tar.gz
  mv mysql-5.7.27-linux-glibc2.12-x86_64 mysql
  ###centos下需要额外安装libaio库。
  mkdir -p $RD3_TMP_PACKAGE/mysql/mysql/dependency
  cd $RD3_TMP_PACKAGE/mysql/mysql/dependency
  wget http://mirror.centos.org/centos/6/os/x86_64/Packages/libaio-0.3.107-10.el6.x86_64.rpm
  cd $RD3_TMP_PACKAGE/mysql
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-mysql.tar.gz mysql
  rm -rf $RD3_TMP_PACKAGE/mysql
  echo "mysql服务包制作结束"
}

#--------------------------------------------
# name:mysql-mha-manager包制作脚本-centos
# desc:mysql-mha集群，manager包。参考：参考https://github.com/yoshinorim/mha4mysql-manager/wiki/Installation
# author：xujianying
#--------------------------------------------
function create_gpaas_mha_manager_centos(){
  echo "开始制作mha-manager服务包-centos"
  mkdir -p $RD3_TMP_PACKAGE/mha-manager/dependency
  cd $RD3_TMP_PACKAGE/mha-manager/dependency
  ###下载perl-Config-Tiny包及其依赖
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Config-Tiny-2.14-7.el7.noarch.rpm
  ###下载perl-Log-Dispatch包及其依赖
  wget https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/perl-Email-Date-Format-1.002-15.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Class-Load-0.20-3.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Data-OptList-0.107-9.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-IO-Socket-IP-0.21-5.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-IO-Socket-SSL-1.94-7.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-List-MoreUtils-0.33-9.el7.x86_64.rpm
  wget https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/perl-Log-Dispatch-2.41-1.el7.1.noarch.rpm
  wget https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/perl-MIME-Lite-3.030-1.el7.noarch.rpm
  wget https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/perl-MIME-Types-1.38-2.el7.noarch.rpm
  wget https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/perl-Mail-Sender-0.8.23-1.el7.noarch.rpm
  wget https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/perl-Mail-Sendmail-0.79-21.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-MailTools-2.12-2.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Module-Runtime-0.013-4.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Module-Implementation-0.06-6.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Mozilla-CA-20130114-5.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Net-SMTP-SSL-1.01-13.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Net-LibIDN-0.12-15.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Package-DeprecationManager-0.13-7.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Net-SSLeay-1.55-6.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Package-Stash-XS-0.26-3.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Package-Stash-0.34-2.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Params-Util-1.07-6.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Sub-Install-0.926-6.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Params-Validate-1.08-4.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Sys-Syslog-0.33-3.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Try-Tiny-0.12-2.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-TimeDate-2.30-2.el7.noarch.rpm
  ###perl-Parallel-ForkManager包及其依赖
  wget https://download-ib01.fedoraproject.org/pub/epel/7/x86_64/Packages/p/perl-Parallel-ForkManager-1.18-2.el7.noarch.rpm
  ##mha4mysql-manager-0.55-1.el5.noarch.rpm包下载需要翻墙：https://code.google.com/p/mysql-master-ha/downloads/list/xxx
  cp $BUILD_MINI_BUILD_HOME/ext/mha4mysql-manager-0.55-1.el5.noarch.rpm .
  ##拷贝部署脚本
  rm -rf $RD3_TMP_PACKAGE/mha-manager/*.sh
  rm -rf $RD3_TMP_PACKAGE/mha-manager/*.pm
  cp -rf $BUILD_MINI_BUILD_HOME/ext/deploy-mha-manager-$OS_CENTOS_7.sh $RD3_TMP_PACKAGE/mha-manager
  cp -rf $BUILD_MINI_BUILD_HOME/ext/NodeUtil.pm $RD3_TMP_PACKAGE/mha-manager
  mkdir -p $RD3_RELEASE_PACKAGE
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-mha-manager-$OS_CENTOS_7.tar.gz
  cd $RD3_TMP_PACKAGE/mha-manager
  mv deploy-mha-manager-$OS_CENTOS_7.sh deploy-mha-manager.sh
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-mha-manager-$OS_CENTOS_7.tar.gz .
  echo "mha-manager服务包制作结束"
}

#--------------------------------------------
# name:mysql-mha-manager包制作脚本-ubuntu
# desc:mysql-mha集群，manager包。
# author：xujianying
#--------------------------------------------
function create_gpaas_mha_manager_ubuntu(){
  echo "开始制作mha-manager服务包-centos"
  mkdir -p $RD3_TMP_PACKAGE/mha-manager/dependency
  cd $RD3_TMP_PACKAGE/mha-manager/dependency
  wget http://archive.ubuntu.com/ubuntu/pool/universe/m/mha4mysql-manager/mha4mysql-manager_0.55-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/liba/libauthen-sasl-perl/libauthen-sasl-perl_2.1600-1_all.deb
  ##拷贝部署脚本
  rm -rf $RD3_TMP_PACKAGE/mha-manager/*.sh
  rm -rf $RD3_TMP_PACKAGE/mha-manager/*.pm
  cp -rf $BUILD_MINI_BUILD_HOME/ext/deploy-mha-manager-$OS_UBUNTU_16.sh $RD3_TMP_PACKAGE/mha-manager
  cp -rf $BUILD_MINI_BUILD_HOME/ext/NodeUtil.pm $RD3_TMP_PACKAGE/mha-manager
  mkdir -p $RD3_RELEASE_PACKAGE
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-mha-manager-$OS_UBUNTU_16.tar.gz
  cd $RD3_TMP_PACKAGE/mha-manager
  mv deploy-mha-manager-$OS_UBUNTU_16.sh deploy-mha-manager.sh
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-mha-manager-$OS_UBUNTU_16.tar.gz .
  echo "mha-manager服务包制作结束-ubuntu"
}

#--------------------------------------------
# name:mysql-mha-node包制作脚本-centos
# desc:mysql-mha集群，node包。
# author：xujianying
#--------------------------------------------
function create_gpaas_mha_node_centos(){
  echo "开始制作mha-node服务包-centos"
  mkdir -p $RD3_TMP_PACKAGE/mha-node/dependency
  cd $RD3_TMP_PACKAGE/mha-node/dependency
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Compress-Raw-Bzip2-2.061-3.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Compress-Raw-Zlib-2.061-4.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-DBD-MySQL-4.023-6.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Data-Dumper-2.145-3.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-DBI-1.627-4.el7.x86_64.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-IO-Compress-2.061-2.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-Net-Daemon-0.48-5.el7.noarch.rpm
  wget http://mirror.centos.org/centos/7/os/x86_64/Packages/perl-PlRPC-0.2020-14.el7.noarch.rpm
  ##mha4mysql-node-0.54-1.el5.noarch.rpm包下载需要翻墙。wget https://code.google.com/p/mysql-master-ha/downloads/list/xxx
  cp $BUILD_MINI_BUILD_HOME/mini-build/ext/mha4mysql-node-0.54-1.el5.noarch.rpm .
  ##拷贝部署脚本
  rm -rf $RD3_TMP_PACKAGE/mha-node/*.sh
  rm -rf $RD3_TMP_PACKAGE/mha-node/*.pm
  cp -rf $BUILD_MINI_BUILD_HOME/ext/deploy-mha-node-$OS_CENTOS_7.sh $RD3_TMP_PACKAGE/mha-node
  cp -rf $BUILD_MINI_BUILD_HOME/ext/NodeUtil.pm $RD3_TMP_PACKAGE/mha-manager
  mkdir -p $RD3_RELEASE_PACKAGE
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-mha-node-$OS_CENTOS_7.tar.gz
  cd $RD3_TMP_PACKAGE/mha-node
  mv deploy-mha-node-$OS_CENTOS_7.sh deploy-mha-node.sh
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-mha-node-$OS_CENTOS_7.tar.gz .
  echo "mha-node服务包制作结束-centos"
}
#--------------------------------------------
# name:mysql-mha-node包制作脚本-ubuntu
# desc:mysql-mha集群，node包。
# author：xujianying
#--------------------------------------------
function create_gpaas_mha_node_ubuntu(){
  echo "开始制作mha-node服务包-ubuntu"
  mkdir -p $RD3_TMP_PACKAGE/mha-node/dependency
  cd $RD3_TMP_PACKAGE/mha-node/dependency
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libc/libconfig-tiny-perl/libconfig-tiny-perl_2.23-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libd/libdbi-perl/libdbi-perl_1.634-1build1_amd64.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/m/mysql-5.7/mysql-common_5.7.27-0ubuntu0.16.04.1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/m/mysql-5.7/libmysqlclient20_5.7.27-0ubuntu0.16.04.1_amd64.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libd/libdbd-mysql-perl/libdbd-mysql-perl_4.033-1ubuntu0.1_amd64.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libs/libsub-exporter-progressive-perl/libsub-exporter-progressive-perl_0.001011-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libd/libdevel-globaldestruction-perl/libdevel-globaldestruction-perl_0.13-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libp/libparams-classify-perl/libparams-classify-perl_0.013-5build1_amd64.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libm/libmodule-runtime-perl/libmodule-runtime-perl_0.014-2_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libd/libdist-checkconflicts-perl/libdist-checkconflicts-perl_0.11-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libe/libemail-date-format-perl/libemail-date-format-perl_1.005-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libn/libnet-ssleay-perl/libnet-ssleay-perl_1.72-1build1_amd64.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libi/libio-socket-ssl-perl/libio-socket-ssl-perl_2.024-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libt/libtry-tiny-perl/libtry-tiny-perl_0.24-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libm/libmodule-implementation-perl/libmodule-implementation-perl_0.09-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libp/libparams-validate-perl/libparams-validate-perl_1.22-1_amd64.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libl/liblog-dispatch-perl/liblog-dispatch-perl_2.54-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libs/libsys-hostname-long-perl/libsys-hostname-long-perl_1.5-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libm/libmail-sendmail-perl/libmail-sendmail-perl_0.79.16-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libt/libtimedate-perl/libtimedate-perl_2.3000-2_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libn/libnet-smtp-ssl-perl/libnet-smtp-ssl-perl_1.03-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libm/libmailtools-perl/libmailtools-perl_2.13-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libm/libmime-lite-perl/libmime-lite-perl_3.030-2_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libm/libmime-types-perl/libmime-types-perl_2.12-1ubuntu1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/main/libn/libnet-libidn-perl/libnet-libidn-perl_0.12.ds-2build2_amd64.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/libp/libparallel-forkmanager-perl/libparallel-forkmanager-perl_1.17-1_all.deb
  wget http://archive.ubuntu.com/ubuntu/pool/universe/m/mha4mysql-node/mha4mysql-node_0.54-1_all.deb

  rm -rf $RD3_TMP_PACKAGE/mha-node/*.sh
  rm -rf $RD3_TMP_PACKAGE/mha-node/*.pm
  cp -rf $BUILD_MINI_BUILD_HOME/ext/deploy-mha-node-$OS_UBUNTU_16.sh $RD3_TMP_PACKAGE/mha-node
  cp -rf $BUILD_MINI_BUILD_HOME/ext/NodeUtil.pm $RD3_TMP_PACKAGE/mha-manager
  mkdir -p $RD3_RELEASE_PACKAGE
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-mha-node-$OS_UBUNTU_16.tar.gz
  cd $RD3_TMP_PACKAGE/mha-node
  mv deploy-mha-node-$OS_UBUNTU_16.sh deploy-mha-node.sh
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-mha-node-$OS_UBUNTU_16.tar.gz .
  
  echo "mha-node服务包制作结束-ubuntu"
}
#--------------------------------------------
# name:postgresql包制作脚本
# desc:postgresql数据库。
# author：xujianying
#--------------------------------------------
function create_gpaas_postgresql(){
  echo "开始制作postgresql服务包"
  mkdir -p $RD3_TMP_PACKAGE/postgresql
  rm -rf $RD3_RELEASE_PACKAGE/postgresql.tar.gz
  cd $RD3_TMP_PACKAGE/postgresql
  wget https://get.enterprisedb.com/postgresql/postgresql-10.10-1-linux-x64-binaries.tar.gz
  tar -xvf postgresql-10.10-1-linux-x64-binaries.tar.gz
  mv pgsql postgresql
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-postgresql.tar.gz postgresql
  rm -rf $RD3_TMP_PACKAGE/postgresql
  echo "postgresql服务包制作结束"
}

#--------------------------------------------
# name:redis包制作脚本
# desc:分布式缓存redis
# author：xujianying
#--------------------------------------------
function create_gpaas_redis(){
  echo "开始制作redis服务包"
  mkdir -p $RD3_TMP_PACKAGE/redis
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-redis.tar.gz
  cd $RD3_TMP_PACKAGE/redis
  wget http://download.redis.io/releases/redis-5.0.5.tar.gz
  tar -xvf redis-5.0.5.tar.gz
  cd $RD3_TMP_PACKAGE/redis/redis-5.0.5
  mkdir -p /opt/neoway/iotcloud/service/redis
  make PREFIX=/opt/neoway/iotcloud/service/redis install
  cd /opt/neoway/iotcloud/service
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-redis.tar.gz redis
  rm -rf $RD3_TMP_PACKAGE/redis
  rm -rf /opt/neoway/iotcloud/
  echo "redis服务包制作结束"
}

#--------------------------------------------
# name:rabbitmq包制作脚本
# desc:消息队列
# author：xujianying
#--------------------------------------------
function create_gpaas_rabbitmq(){
  echo "开始制作rabbitmq服务包"
  mkdir -p $RD3_TMP_PACKAGE/rabbitmq
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-rabbitmq.tar.gz
  cd $RD3_TMP_PACKAGE/rabbitmq
  wget https://github.com/rabbitmq/rabbitmq-server/releases/download/v3.8.3/rabbitmq-server-generic-unix-3.8.3.tar.xz
  tar -xvf rabbitmq-server-generic-unix-3.8.3.tar.xz
  mv rabbitmq_server-3.8.3 rabbitmq
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-rabbitmq.tar.gz rabbitmq
  rm -rf $RD3_TMP_PACKAGE/rabbitmq
  echo "rabbitmq服务包制作结束"

}

#--------------------------------------------
# name:hbase包制作脚本
# desc:nosql-hbase数据库
# author：张文豪
#--------------------------------------------
function create_gpaas_hbase(){
  echo "开始制作hbase服务包"
  mkdir -p $RD3_TMP_PACKAGE/hbase
  rm -rf $RD3_RELEASE_PACKAGE/hbase.tar.gz
  cd $RD3_TMP_PACKAGE/hbase
  wget https://mirror.bit.edu.cn/apache/hbase/2.2.4/hbase-2.2.4-bin.tar.gz
  tar -xvf hbase-2.2.4-bin.tar.gz
  mv hbase-2.2.4 hbase
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-hbase.tar.gz hbase
  rm -rf $RD3_TMP_PACKAGE/hbase
  echo "hbase服务包制作结束"
}

#--------------------------------------------
# name:fastdfs包制作脚本
# desc:分布式文件系统
# author：xujianying
#--------------------------------------------
function create_gpaas_fastdfs(){
  echo "开始制作fastdfs服务包"
  mkdir -p $RD3_TMP_PACKAGE/fastdfs
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-fastdfs.tar.gz
  cd $RD3_TMP_PACKAGE/fastdfs
  
  ##下载libfastcommon
  wget https://codeload.github.com/happyfish100/libfastcommon/tar.gz/V1.0.43
  mv V1.0.43 libfastcommon-v1.0.43.tar.gz
  tar -xvf libfastcommon-v1.0.43.tar.gz
  ##下载并编译fastdfs
  wget https://codeload.github.com/happyfish100/fastdfs/tar.gz/V6.06
  mv V6.06 fastdfs_v6.06.tar.gz
  tar -xvf fastdfs_v6.06.tar.gz
  ##fastdfs与其libcommon都是通过设置DESTDIR环境变量来定义安装在哪个路径下
  mkdir -p $SERVICE_RUN/service/fastdfs
  export DESTDIR=$SERVICE_RUN/service/fastdfs
  cd $RD3_TMP_PACKAGE/fastdfs/libfastcommon-1.0.43/
  ##编译
  ./make.sh
  ##安装
  ./make.sh install
  cd $RD3_TMP_PACKAGE/fastdfs/fastdfs-6.06/
  ./make.sh
  ./make.sh install
  cd $SERVICE_RUN/service
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-fastdfs.tar.gz fastdfs
  rm -rf $RD3_TMP_PACKAGE/fastdfs
  rm -rf $SERVICE_RUN
  echo "fastdfs服务包制作结束"
}

######################################################################
#
# lb相关包制作：er、ir、keepalived
#
######################################################################
#--------------------------------------------
# name:ir包制作脚本
# desc:内部路由
# author：xujianying
#--------------------------------------------
function create_gpaas_ir(){
  echo "开始制作ir服务包"
  mkdir -p $RD3_TMP_PACKAGE/ir
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-ir.tar.gz
  cd $RD3_TMP_PACKAGE/ir
  wget https://codeload.github.com/openssl/openssl/zip/OpenSSL_1_1_1c
  wget http://zlib.net/zlib-1.2.11.tar.gz
  wget https://netix.dl.sourceforge.net/project/pcre/pcre/8.40/pcre-8.40.tar.gz
  wget https://openresty.org/download/openresty-1.15.8.1.tar.gz
  mv OpenSSL_1_1_1c OpenSSL_1_1_1c.zip
  tar -xvf openresty-1.15.8.1.tar.gz
  unzip -d $RD3_TMP_PACKAGE/ir/openresty-1.15.8.1/ OpenSSL_1_1_1c.zip 
  tar -xvf zlib-1.2.11.tar.gz -C $RD3_TMP_PACKAGE/ir/openresty-1.15.8.1/
  tar -xvf pcre-8.40.tar.gz -C $RD3_TMP_PACKAGE/ir/openresty-1.15.8.1/
  cd $RD3_TMP_PACKAGE/ir/openresty-1.15.8.1
  mkdir -p /opt/neoway/iotcloud/service/ir
  mkdir -p /var/log/iotcloud/ir
  yum install gcc-c++ 
  ./configure -j2 --prefix=/opt/neoway/iotcloud/service/ir \
   --with-pcre-jit \
   --with-http_ssl_module \
   --with-http_realip_module \
   --with-http_stub_status_module \
   --with-http_v2_module \
   --with-pcre=./pcre-8.40 \
   --with-zlib=./zlib-1.2.11 \
   --with-openssl=./openssl-OpenSSL_1_1_1c \
   --with-ipv6 \
   --error-log-path=/var/log/iotcloud/ir/error.log \
   --pid-path=/opt/neoway/iotcloud/run/ir.pid \
   --http-log-path=/var/log/iotcloud/ir/access.log
  make -j2
  make install
  cd /opt/neoway/iotcloud/service/
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-ir.tar.gz ir
  rm -rf $RD3_TMP_PACKAGE/ir
  rm -rf /opt/neoway/iotcloud/
  echo "ir服务包制作结束"
}
#--------------------------------------------
# name:er包制作脚本
# desc:外部负载均衡器
# author：xujianying
#--------------------------------------------
function create_gpaas_er(){
  echo "开始制作er服务包"
  mkdir -p $RD3_TMP_PACKAGE/er
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-er.tar.gz
  cd $RD3_TMP_PACKAGE/er
  wget https://codeload.github.com/openssl/openssl/zip/OpenSSL_1_1_1c
  wget http://zlib.net/zlib-1.2.11.tar.gz
  wget https://netix.dl.sourceforge.net/project/pcre/pcre/8.40/pcre-8.40.tar.gz
  wget https://openresty.org/download/openresty-1.15.8.1.tar.gz
  mv OpenSSL_1_1_1c OpenSSL_1_1_1c.zip
  tar -xvf openresty-1.15.8.1.tar.gz
  unzip -d $RD3_TMP_PACKAGE/er/openresty-1.15.8.1/ OpenSSL_1_1_1c.zip 
  tar -xvf zlib-1.2.11.tar.gz -C $RD3_TMP_PACKAGE/er/openresty-1.15.8.1/
  tar -xvf pcre-8.40.tar.gz -C $RD3_TMP_PACKAGE/er/openresty-1.15.8.1/
  cd $RD3_TMP_PACKAGE/er/openresty-1.15.8.1
  mkdir -p /opt/neoway/iotcloud/service/er
  mkdir -p /var/log/iotcloud/er
  yum install gcc-c++ 
  ./configure -j2 --prefix=/opt/neoway/iotcloud/service/er \
   --with-pcre-jit \
   --with-http_ssl_module \
   --with-http_realip_module \
   --with-http_stub_status_module \
   --with-http_v2_module \
   --with-pcre=./pcre-8.40 \
   --with-zlib=./zlib-1.2.11 \
   --with-openssl=./openssl-OpenSSL_1_1_1c \
   --with-ipv6 \
   --error-log-path=/var/log/iotcloud/er/error.log \
   --pid-path=/opt/neoway/iotcloud/run/er.pid \
   --http-log-path=/var/log/iotcloud/er/access.log
  make -j2
  make install
  cd /opt/neoway/iotcloud/service/
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-er.tar.gz er
  rm -rf $RD3_TMP_PACKAGE/er
  rm -rf /opt/neoway/iotcloud/
  echo "er服务包制作结束"
}
#--------------------------------------------
# name:ber包制作脚本
# desc:外部负载均衡器
# author：xujianying
#--------------------------------------------
function create_gpaas_ber(){
  echo "开始制作ber服务包"
  mkdir -p $RD3_TMP_PACKAGE/ber
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-ber.tar.gz
  cd $RD3_TMP_PACKAGE/ber
  wget https://codeload.github.com/openssl/openssl/zip/OpenSSL_1_1_1c
  wget http://zlib.net/zlib-1.2.11.tar.gz
  wget https://netix.dl.sourceforge.net/project/pcre/pcre/8.40/pcre-8.40.tar.gz
  wget https://openresty.org/download/openresty-1.15.8.1.tar.gz
  mv OpenSSL_1_1_1c OpenSSL_1_1_1c.zip
  tar -xvf openresty-1.15.8.1.tar.gz
  unzip -d $RD3_TMP_PACKAGE/ber/openresty-1.15.8.1/ OpenSSL_1_1_1c.zip 
  tar -xvf zlib-1.2.11.tar.gz -C $RD3_TMP_PACKAGE/ber/openresty-1.15.8.1/
  tar -xvf pcre-8.40.tar.gz -C $RD3_TMP_PACKAGE/ber/openresty-1.15.8.1/
  cd $RD3_TMP_PACKAGE/ber/openresty-1.15.8.1
  mkdir -p /opt/neoway/iotcloud/sbervice/ber
  mkdir -p /var/log/iotcloud/ber
  yum install gcc-c++ 
  ./configure -j2 --prefix=/opt/neoway/iotcloud/sbervice/ber \
   --with-pcre-jit \
   --with-stream \
   --with-http_ssl_module \
   --with-http_realip_module \
   --with-http_stub_status_module \
   --with-http_v2_module \
   --with-pcre=./pcre-8.40 \
   --with-zlib=./zlib-1.2.11 \
   --with-openssl=./openssl-OpenSSL_1_1_1c \
   --with-ipv6 \
   --berror-log-path=/var/log/iotcloud/ber/berror.log \
   --pid-path=/opt/neoway/iotcloud/run/ber.pid \
   --http-log-path=/var/log/iotcloud/ber/access.log
  make -j2
  make install
  cd /opt/neoway/iotcloud/sbervice/
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-ber.tar.gz ber
  rm -rf $RD3_TMP_PACKAGE/ber
  rm -rf /opt/neoway/iotcloud/
  echo "ber服务包制作结束"
}
#--------------------------------------------
# name:keepalived包制作脚本
# desc:HA包，被mysql集群、mq集群、fastdfs集群、er集群使用。
#      区分操作系统为centos还是ubuntu。本脚本默认centos
# author：xujianying
#--------------------------------------------
function create_gpaas_keepalived(){
  echo "开始制作keepalived服务包"
  mkdir -p $RD3_TMP_PACKAGE/keepalived
  rm -rf $RD3_RELEASE_PACKAGE/gpaas-keepalived-centos.tar.gz
  cd $RD3_TMP_PACKAGE/keepalived
  wget https://www.keepalived.org/software/keepalived-2.0.18.tar.gz
  #sudo apt-get install openssl -y
  #sudo apt-get install libssl-dev -y
  ###centos下制作包未如下：
  yum install openssl -y
  yum install openssl-devel -y
  tar -xvf keepalived-2.0.18.tar.gz
  cd $RD3_TMP_PACKAGE/keepalived/keepalived-2.0.18
  ./configure --prefix=$SERVICE_RUN/service/keepalived
  make
  make install
  cd $SERVICE_RUN/service
  tar -zcvf $RD3_RELEASE_PACKAGE/gpaas-keepalived.tar.gz keepalived
  rm -rf $RD3_TMP_PACKAGE/keepalived
  echo "keepalived服务包制作结束"
}

#--------------------------------------------
# name:goku包制作
# desc:API网关-goku
# author：xujianying
#--------------------------------------------
function create_gpaas_goku(){
  echo "开始制作goku服务包"
  echo "goku服务包制作结束"
}


########################################################################
#																	###
#                 总体制作脚本							            ###
#######################################################################
echo "**************************开始制作第三方服务包*******************************************"
mkdir -p $RD3_RELEASE_PACKAGE
rm -rf $RD3_TMP_PACKAGE
#runtime包开始制作
create_runtime_erlang
create_runtime_nodejs
create_runtime_arthas
create_runtime_openjdk
#ops包开始制作
create_gpaas_prometheus
create_gpaas_grafana
create_gpaas_node_exporter
create_gpaas_mysql_exporter
create_gpaas_redis_exporter
create_gpaas_consul
create_gpaas_ansible_awx
create_gpaas_mysql_admin
create_gpaas_rabbitmq_admin
create_gpaas_hbase_admin
create_gpaas_elastic_exporter
#数据存储包开始制作
create_gpaas_elasticsearch
create_gpaas_emq
create_gpaas_mysql
create_gpaas_redis
create_gpaas_hbase
create_gpaas_fastdfs
create_gpaas_mha_manager_centos
create_gpaas_mha_node_centos
create_gpaas_rabbitmq
#lb包开始制作
create_gpaas_er
create_gpaas_ber
create_gpaas_ir
create_gpaas_keepalived
create_gpaas_goku
rm -rf $RD3_TMP_PACKAGE
echo "**************************第三方服务包制作结束*******************************************"
exit 0
