#!/bin/bash

KONG_HOME=$(cd "$(dirname "$0")";pwd)
KONG_DEPEDENCY=$(cd "$KONG_HOME"/dependency;pwd)

KONG_PACKAGES=(
"perl-podlators-2.5.1-3.el7.noarch.rpm"
"perl-threads-1.87-4.el7.x86_64.rpm"
"perl-threads-shared-1.43-6.el7.x86_64.rpm"
"perl-parent-0.225-244.el7.noarch.rpm"
"perl-macros-5.16.3-294.el7_6.x86_64.rpm"
"perl-libs-5.16.3-294.el7_6.x86_64.rpm"
"perl-constant-1.27-2.el7.noarch.rpm"
"perl-Time-Local-1.2300-2.el7.noarch.rpm"
"perl-Time-HiRes-1.9725-3.el7.x86_64.rpm"
"perl-Text-ParseWords-3.29-4.el7.noarch.rpm"
"perl-Storable-2.45-3.el7.x86_64.rpm"
"perl-Socket-2.010-4.el7.x86_64.rpm"
"perl-Scalar-List-Utils-1.27-248.el7.x86_64.rpm"
"perl-Pod-Usage-1.63-3.el7.noarch.rpm"
"perl-Pod-Simple-3.28-4.el7.noarch.rpm"
"perl-Pod-Perldoc-3.20-4.el7.noarch.rpm"
"perl-Pod-Escapes-1.04-294.el7_6.noarch.rpm"
"perl-PathTools-3.40-5.el7.x86_64.rpm"
"perl-HTTP-Tiny-0.033-3.el7.noarch.rpm"
"perl-Getopt-Long-2.40-3.el7.noarch.rpm"
"perl-Filter-1.49-3.el7.x86_64.rpm"
"perl-File-Temp-0.23.01-3.el7.noarch.rpm"
"perl-File-Path-2.09-2.el7.noarch.rpm"
"perl-Exporter-5.68-3.el7.noarch.rpm"
"perl-Encode-2.51-7.el7.x86_64.rpm"
"perl-Carp-1.26-244.el7.noarch.rpm"
"perl-5.16.3-294.el7_6.x86_64.rpm"
"kong-1.3.0.el7.amd64.rpm"
)
KONG=(
"kong"
"perl-Carp"
"perl-Encode"
"perl-Exporter"
"perl-File-Path"
"perl-File-Temp"
"perl-Filter"
"perl-Getopt-Long"
"perl-HTTP-Tiny"
"perl-PathTools"
"perl-Pod-Escapes"
"perl-Pod-Perldoc"
"perl-Pod-Simple"
"perl-Pod-Usage"
"perl-Scalar-List-Utils"
"perl-Socket"
"perl-Storable"
"perl-Text-ParseWords"
"perl-Time-HiRes"
"perl-Time-Local"
"perl-constant"
"perl-libs"
"perl-macros"
"perl-parent"
"perl-threads-shared"
"perl-threads"
"perl-podlators"
"perl"
)

#卸载kong部署包和依赖包
function uninstall_kong() {
  cd $KONG_DEPEDENCY
  rpm -e kong
#  for package in ${KONG[@]};do
#    echo "[kong-dependence卸载]------$package..........."
#    rpm -e $package
#  done
}
##部署kong服务包
function deploy_kong(){
  cd $KONG_DEPEDENCY
  for package in ${KONG_PACKAGES[@]};do
    echo "[kong-dependence安装]------$package..........."
    rpm -ivh $package --nodeps
  done
}
echo "**************************安装kong服务开始*******************************************"
uninstall_kong
deploy_kong
echo "**************************安装kong服务结束*******************************************"
exit 0

