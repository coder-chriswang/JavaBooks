
#!/bin/bash

MHA4MYSQL_NODE_HOME=$(cd "$(dirname "$0")";pwd)
MHA4MYSQL_NODE_DEPEDENCY=$MHA4MYSQL_NODE_HOME/dependency

MHA_NODE_PACKAGES=(
"perl-Compress-Raw-Bzip2-2.061-3.el7.x86_64.rpm"
"perl-Compress-Raw-Zlib-2.061-4.el7.x86_64.rpm"
"perl-IO-Compress-2.061-2.el7.noarch.rpm"
"perl-Data-Dumper-2.145-3.el7.x86_64.rpm"
"perl-Net-Daemon-0.48-5.el7.noarch.rpm"
"perl-PlRPC-0.2020-14.el7.noarch.rpm"
"perl-DBI-1.627-4.el7.x86_64.rpm"
"perl-DBD-MySQL-4.023-6.el7.x86_64.rpm"
"mha4mysql-node-0.54-1.el5.noarch.rpm"
)

##部署mha-node服务包
function deploy_mha_node(){
  cd $MHA4MYSQL_NODE_DEPEDENCY
  for package in ${MHA_NODE_PACKAGES[@]};do
    echo "[mha-node-dependence安装]------$package..........."
    rpm -ivh $package
  done
}
echo "**************************安装mha-node服务开始*******************************************"
deploy_mha_node
echo "**************************安装mha-node服务结束*******************************************"
exit 0
