#!/bin/bash

##mha4mysql-manager版本号
RD3_MHA4MYSQL_MANAGER_VERSION="0.55"
MHA4MYSQL_MANAGER_HOME=$(cd "$(dirname "$0")";pwd)
MHA4MYSQL_MANAGER_DEPEDENCY=$(cd "$MHA4MYSQL_MANAGER_HOME"/dependency;pwd)
 
MHA_MANAGER_PACKAGES=(
"perl-Config-Tiny-2.14-7.el7.noarch.rpm"
"perl-Sub-Install-0.926-6.el7.noarch.rpm"
"perl-Net-SSLeay-1.55-6.el7.x86_64.rpm"
"perl-Try-Tiny-0.12-2.el7.noarch.rpm"
"perl-Params-Util-1.07-6.el7.x86_64.rpm" 
"perl-Module-Runtime-0.013-4.el7.noarch.rpm"
"perl-Module-Implementation-0.06-6.el7.noarch.rpm" 
"perl-Params-Validate-1.08-4.el7.x86_64.rpm" 
"perl-Data-OptList-0.107-9.el7.noarch.rpm"
"perl-Email-Date-Format-1.002-15.el7.noarch.rpm" 
"perl-Net-LibIDN-0.12-15.el7.x86_64.rpm" 
"perl-TimeDate-2.30-2.el7.noarch.rpm"
"perl-Package-Stash-XS-0.26-3.el7.x86_64.rpm" 
"perl-IO-Socket-IP-0.21-5.el7.noarch.rpm" 
"perl-MIME-Types-1.38-2.el7.noarch.rpm" 
"perl-MIME-Lite-3.030-1.el7.noarch.rpm" 
"perl-Mozilla-CA-20130114-5.el7.noarch.rpm"
"perl-IO-Socket-SSL-1.94-7.el7.noarch.rpm" 
"perl-Mail-Sender-0.8.23-1.el7.noarch.rpm" 
"perl-Net-SMTP-SSL-1.01-13.el7.noarch.rpm" 
"perl-MailTools-2.12-2.el7.noarch.rpm" 
"perl-List-MoreUtils-0.33-9.el7.x86_64.rpm"
"perl-Package-DeprecationManager-0.13-7.el7.noarch.rpm"
"perl-Package-Stash-0.34-2.el7.noarch.rpm" 
"perl-Class-Load-0.20-3.el7.noarch.rpm" 
"perl-Sys-Syslog-0.33-3.el7.x86_64.rpm" 
"perl-Mail-Sendmail-0.79-21.el7.noarch.rpm"
"perl-Log-Dispatch-2.41-1.el7.1.noarch.rpm"
"perl-Parallel-ForkManager-1.18-2.el7.noarch.rpm"
"mha4mysql-manager-0.55-1.el5.noarch.rpm"
)

##部署mha-manager服务包
function deploy_mha_manager(){
  cd $MHA4MYSQL_MANAGER_DEPEDENCY
  for package in ${MHA_MANAGER_PACKAGES[@]};do
    echo "[mha-manager-dependence安装]------$package..........."
    rpm -ivh $package
  done
  cp -rf $MHA4MYSQL_MANAGER_HOME/NodeUtil.pm /usr/lib/perl5/vendor_perl/MHA/
  ##rm -rf $MHA4MYSQL_MANAGER_HOME/*
}
echo "**************************安装mha-manager服务开始*******************************************"
deploy_mha_manager
echo "**************************安装mha-manager服务结束*******************************************"
exit 0
