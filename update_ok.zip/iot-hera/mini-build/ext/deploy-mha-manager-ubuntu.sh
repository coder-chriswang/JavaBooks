#!/bin/bash

##mha4mysql-manager版本号
RD3_MHA4MYSQL_MANAGER_VERSION="0.55"
MHA4MYSQL_MANAGER_HOME=$(cd "$(dirname "$0")";pwd)
MHA4MYSQL_MANAGER_DEPEDENCY=$(cd "$MHA4MYSQL_MANAGER_HOME"/dependency;pwd)

DEPEDENCYS=(
"mha4mysql-manager_0.55-1_all.deb"
"libauthen-sasl-perl_2.1600-1_all.deb"
)

##部署mha-manager服务包
function deploy_mha_manager(){
  cd $MHA4MYSQL_MANAGER_DEPEDENCY
  for package in ${DEPEDENCYS[@]};do
    echo "[ubuntu-mha-manager-dependence安装]------$package..........."
    dpkg -i $package
  done
  cp -rf $MHA4MYSQL_MANAGER_HOME/NodeUtil.pm /usr/share/perl5/MHA/
  rm -rf $MHA4MYSQL_MANAGER_HOME/*
}
echo "**************************安装mha-manager服务开始*******************************************"
deploy_mha_manager
echo "**************************安装mha-manager服务结束*******************************************"
exit 0
