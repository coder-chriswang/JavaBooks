#!/bin/bash

MHA4MYSQL_NODE_HOME=$(cd "$(dirname "$0")";pwd)
MHA4MYSQL_NODE_DEPEDENCY=$MHA4MYSQL_NODE_HOME/dependency

DEPEDENCYS=(
"libconfig-tiny-perl_2.23-1_all.deb"
"libdbi-perl_1.634-1build1_amd64.deb"
"mysql-common_5.7.27-0ubuntu0.16.04.1_all.deb"
"libmysqlclient20_5.7.27-0ubuntu0.16.04.1_amd64.deb"
"libdbd-mysql-perl_4.033-1ubuntu0.1_amd64.deb"
"libsub-exporter-progressive-perl_0.001011-1_all.deb"
"libdevel-globaldestruction-perl_0.13-1_all.deb"
"libparams-classify-perl_0.013-5build1_amd64.deb"
"libmodule-runtime-perl_0.014-2_all.deb"
"libdist-checkconflicts-perl_0.11-1_all.deb"
"libemail-date-format-perl_1.005-1_all.deb"
"libnet-ssleay-perl_1.72-1build1_amd64.deb"
"libio-socket-ssl-perl_2.024-1_all.deb"
"libtry-tiny-perl_0.24-1_all.deb"
"libmodule-implementation-perl_0.09-1_all.deb"
"libparams-validate-perl_1.22-1_amd64.deb"
"liblog-dispatch-perl_2.54-1_all.deb"
"libsys-hostname-long-perl_1.5-1_all.deb"
"libmail-sendmail-perl_0.79.16-1_all.deb"
"libtimedate-perl_2.3000-2_all.deb"
"libconfig-tiny-perl_2.23-1_all.deb"
"libnet-smtp-ssl-perl_1.03-1_all.deb"
"libmailtools-perl_2.13-1_all.deb"
"libmime-lite-perl_3.030-2_all.deb"
"libmime-types-perl_2.12-1ubuntu1_all.deb"
"libnet-libidn-perl_0.12.ds-2build2_amd64.deb"
"libparallel-forkmanager-perl_1.17-1_all.deb"
"mha4mysql-node_0.54-1_all.deb"
)

##部署mha-node服务包
function deploy_mha_node(){
  cd $MHA4MYSQL_NODE_DEPEDENCY
  for package in ${DEPEDENCYS[@]};do
    echo "[ubuntu-mha-node-dependence安装]------$package..........."
    dpkg -i $package
  done
}
echo "**************************安装mha-node服务开始*******************************************"
deploy_mha_node
echo "**************************安装mha-node服务结束*******************************************"
exit 0
