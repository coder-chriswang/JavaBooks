#!/bin/bash

KONG_HOME=$(cd "$(dirname "$0")";pwd)
KONG_DEPEDENCY=$(cd "$KONG_HOME"/dependency;pwd)

DEPEDENCYS=(
"libgpg-error0_1.21-2ubuntu1_amd64.deb"
"libgcrypt20_1.6.5-2_amd64.deb"
"libsystemd0_229-4ubuntu4_amd64.deb"
"libprocps4_3.3.10-4ubuntu2_amd64.deb"
"libdbus-1-3_1.10.6-1ubuntu3_amd64.deb"
"libdbus-1-3_1.6.18-0ubuntu4_amd64.deb"
"liblua5.2-0_5.2.4-1ubuntu1_amd64.deb"
"librpmio3_4.12.0.1+dfsg1-3build3_amd64.deb"
"librpm3_4.12.0.1+dfsg1-3build3_amd64.deb"
"rpm-common_4.12.0.1+dfsg1-3build3_amd64.deb"
"rpm2cpio_4.12.0.1+dfsg1-3build3_amd64.deb"
"libncurses5_6.0+20160213-1ubuntu1_amd64.deb"
"libpcre3_8.38-3.1_amd64.deb"
"libpcsclite1_1.8.14-1ubuntu1_amd64.deb"
"libtinfo5_6.0+20160213-1ubuntu1_amd64.deb"
"libncurses5_6.0+20160213-1ubuntu1_amd64.deb"
"procps_3.3.10-4ubuntu2_amd64.deb"
"kong-1.3.0.xenial.amd64.deb"
)

##部署mha-node服务包
function deploy_kong(){
  cd $KONG_DEPEDENCY
  for package in ${DEPEDENCYS[@]};do
    echo "[ubuntu-kong-dependence安装]------$KONG_DEPEDENCY/$package..........."
    dpkg -i $package
	continue
  done
}
echo "**************************安装kong服务开始*******************************************"
deploy_kong
echo "**************************安装kong服务结束*******************************************"
exit 0
