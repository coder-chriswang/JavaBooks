##脚本说明


脚本|作用|使用说明|
--|--|--
create-3rd.sh|第三方服务包构建脚本，主要是gPaaS侧组件|1：可以手动执行制作。2：可以嵌入到jenkins job中自动构建。
create-iotcloud.sh|有方物联网云平台安装盘构建脚本，包含接入云，管道云|1：可以手动执行制作。2：可以嵌入到jenkins job中自动构建。最终输出iotcloud-installer-{版本号}.tar.gz
create-iotpipe.sh|有方管道云安装盘构建脚本|1：可以手动执行制作。2：可以嵌入到jenkins job中自动构建。最终输出iotpipe-installer-{版本号}.tar.gz
create-iotplat.sh|有方接入云产品安装盘构建脚本|1：可以手动执行制作。2：可以嵌入到jenkisn job中自动构建。最终输出iotplat-installer-{版本号}.tar.gz