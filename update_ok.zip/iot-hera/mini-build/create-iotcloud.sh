#!/bin/bash

##########################################################################################################
#								                                                                        ##
# name：物联网云平台产品安装盘制作脚本				                                                    ##
# desc：物联网云平台产品安装盘制作脚本，包含运行接入云、管道云的所有组件.需要运行在CI服务器上		    ##
# date：2020.4.2				                                                                        ##
# author：xujianying		                                                                            ##
#								                                                                        ##
##########################################################################################################

##产品发布库目录
MINI_RELEASE_PACKAGE="/opt/hera/release"
##产品名称
MINI_PRODUCT_NAME="iotcloud-installer"
CURRENT_TIME=$(date "+%Y-%m-%d-%H-%M")
##产品版本号
##MINI_RELEASE_VERSION="1.4.0-$CURRENT_TIME"
MINI_RELEASE_VERSION="1.0.0"
##产品安装盘源码目录
MINI_INSTALLER_CODE_HOME="/opt/hera/build/mini-installer"
##产品安装盘制作目录
MINI_INSTALLER_DIR_TMP="/var/log/hera/build"
##三方件服务包归档目录
MINI_INSTALLER_3RDSOFTWARE="/opt/hera/repo"
## 接入云使用的所有组件（安装盘中的roles）。3rd表示第三方，self表示自研，空表示不涉及拷包
declare -A COMPONETS
COMPONETS=(
["runtime-erlang"]="3rd"
["runtime-jdk"]="3rd"
["runtime-arthas"]="3rd"
["runtime-os"]="none"
["runtime-php"]="3rd"
["stage-init"]="none"
["stage-clear"]="none"
["iot-app-init"]="none"
["gpaas-mysql"]="3rd"
["gpaas-mha-manager"]="3rd"
["gpaas-mha-node"]="3rd"
["gpaas-keepalived"]="3rd"
["gpaas-rabbitmq"]="3rd"
["gpaas-redis"]="3rd"
["gpaas-redis-slave"]="none"
["gpaas-redis-cluster"]="none"
["gpaas-postgresql"]="3rd"
["gpaas-hbase"]="3rd"
["gpaas-fastdfs"]="3rd"
["gpaas-ir"]="3rd"
["gpaas-er"]="3rd"
["gpaas-ber"]="3rd"
["gpaas-grafana"]="3rd"
["gpaas-prometheus"]="3rd"
["gpaas-node-exporter"]="3rd"
["gpaas-mysql-exporter"]="3rd"
["gpaas-redis-exporter"]="3rd"
["gpaas-lograte"]="none"
["gpaas-ops-config"]="none"
["gpaas-mysqladmin"]="3rd"
["gpaas-consul"]="3rd"
["gpaas-consul-template"]="3rd"
["iot-er-config"]="none"
["gpaas-spring-config"]="self"
["gpaas-spring-eureka"]="self"
["iot-app-backup"]="none"
["iot-cloud-home"]="self"
["iot-aigw"]="self"
["iot-aianalyze"]="self"
["iot-aiconsole"]="self"
["iot-aiamconsole"]="self"
["iot-iamserver"]="self"
["iot-iamconsole"]="self"
["iot-opmanage"]="self"
["iot-lora-ns"]="self"
["iot-lora-as"]="self"
["iot-lora-gw-bridge"]="self"
["iot-geogw"]="self"
["iot-geocompute"]="self"
["iot-geobusiness"]="self"
["iot-geoconsole"]="self"
["iot-geoconsolet101"]="self"
["iot-geogwt101"]="self"
["iot-geocomputet101"]="self"
["iot-geobusinesst101"]="iot-geobusiness"
["iot-lbsgw"]="self"
["iot-lbscompute"]="self"
["iot-lbsbusiness"]="self"
["iot-lbsconsole"]="self"
["iot-aigw4g"]="self"
["iot-aianalyze4g"]="self"
["iot-ai4gconsole"]="self"
)

function create_package(){
  echo "******************iotcloud packages start********************"
  #1：创建安装盘目录
  mkdir -p $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME
  #2：拷贝mini-installer源码
  ##2.1 拷贝除了roles目录下的所有
  cp -rf $MINI_INSTALLER_CODE_HOME/* $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME
  rm -rf $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/roles/*
  rm -rf $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/monitor/*
  cp -rf $MINI_INSTALLER_CODE_HOME//monitor/iotcloud/* $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/monitor/
  ##拷贝该产品的sql脚本
  cp -rf $MINI_INSTALLER_CODE_HOME/bsql/*/* $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/bsql/
  find $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/bsql/ -name 'iot*' -type d|xargs rm -rf
  #3：拷贝二进制包
  for comp in ${!COMPONETS[@]};do
	echo "正在处理:$comp"
	cp -rf $MINI_INSTALLER_CODE_HOME/roles/$comp $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/roles
	if [ ${COMPONETS[$comp]} == "3rd" ];then
	  cp -rf $MINI_INSTALLER_3RDSOFTWARE/$comp.tar.gz $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/roles/$comp/files/
	elif [ ${COMPONETS[$comp]}  == "self" ];then
	  #self的表示自己开发的微服务，流水线构建会将微服务包推送到/opt/hera/repo下。
	  cp -rf $MINI_INSTALLER_3RDSOFTWARE/$comp.tar.gz $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/roles/$comp/files/
	elif [ ${COMPONETS[$comp]}  == "none" ];then
	  echo "hello neoway"
	else
	  cp -rf $MINI_INSTALLER_3RDSOFTWARE/${COMPONETS[$comp]}.tar.gz $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/roles/$comp/files/
	fi
  done
  #4:删除多余文件
  rm -rf `ls $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/hosts/*|egrep -v '(hosts_iotcloud_gamma|hosts_iotcloud_test)'`
  rm -rf `ls $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/vars/*|egrep -v '(global-iotcloud.vars.yml|deploy-iotcloud.vars.yml)'`
  rm -rf `ls $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/*.yml|egrep -v '(ctl_iotcloud_allinone|ctl_iotcloud_migration)'`
  mv $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/vars/global-iotcloud.vars.yml $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/vars/global.vars.yml
  mv $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/vars/deploy-iotcloud.vars.yml $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME/vars/deploy.vars.yml
  #5：打成tar包。
  mkdir -p $MINI_RELEASE_PACKAGE
  rm -rf $MINI_RELEASE_PACKAGE/$MINI_PRODUCT_NAME-$MINI_RELEASE_VERSION.tar.gz
  cd $MINI_INSTALLER_DIR_TMP
  tar -zcvf $MINI_RELEASE_PACKAGE/$MINI_PRODUCT_NAME-$MINI_RELEASE_VERSION.tar.gz $MINI_PRODUCT_NAME --exclude *.md --exclude *.git
  #6：生成md5校验文件
  cd $MINI_RELEASE_PACKAGE
  md5sum $MINI_PRODUCT_NAME-$MINI_RELEASE_VERSION.tar.gz >$MINI_PRODUCT_NAME-$MINI_RELEASE_VERSION.tar.gz.md5
  rm -rf $MINI_INSTALLER_DIR_TMP/$MINI_PRODUCT_NAME
  echo "******************iotcloud package end.packages=$MINI_RELEASE_PACKAGE/$MINI_PRODUCT_NAME-$MINI_RELEASE_VERSION.tar.gz********************"
}

create_package
exit 0




