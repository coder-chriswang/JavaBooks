## mysql-exporter安装包制作说明
1. 官网下载：wget https://github.com/prometheus/mysqld_exporter/releases/download/v0.12.1/mysqld_exporter-0.12.1.linux-amd64.tar.gz
2. tar -xvf mysqld_exporter-0.12.1.linux-amd64.tar.gz
3. mv mysqld_exporter-0.12.1.linux-amd64 mysql-exporter 
4. tar -zcvf mysql-exporter.tar.gz mysql-exporter

