redis集群环境：


172.31.115.243
172.31.115.237
172.31.115.244

ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.243
ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.244

ansible-playbook -i hosts/hosts_redis ./yml/redis-cluster.yml --tags=uninstall



1：安装redis
2：安装ruby
yum -y install ruby
yum -y install rubygems


/opt/max/mymax/service/redis/bin/redis-cli -p 6379 -a mymax@321 --cluster create 172.31.115.243:6379 172.31.115.237:6379 172.31.115.244:6379 172.31.115.243:6479 172.31.115.237:6479 172.31.115.244:6479 --cluster-replicas 1

查看集群节点
/opt/max/mymax/service/redis/bin/redis-cli -c -p 6379 -a mymax@321 cluster nodes
查看集群信息：
/opt/max/mymax/service/redis/bin/redis-cli -c -p 6379 -a mymax@321 cluster info


maxuser@iZm5e9bofjg5xqnbvcrvrbZ:/opt/max/mymax/service/redis/bin$ ./redis-cli -p 6379 -a mymax@321 --cluster create 172.31.115.243:6379 172.31.115.237:6379 172.31.115.244:6379 --cluster-replicas 0
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
>>> Performing hash slots allocation on 3 nodes...
Master[0] -> Slots 0 - 5460
Master[1] -> Slots 5461 - 10922
Master[2] -> Slots 10923 - 16383
M: 51448a107d69fcb91cc1e1ee59ba70be7e139d86 172.31.115.243:6379
   slots:[0-5460] (5461 slots) master
M: 2402eb3ca2060f93c1603f64411133252d8a65b2 172.31.115.237:6379
   slots:[5461-10922] (5462 slots) master
M: a63e7791b41fe157b3a90e305db91f99cf8c49d3 172.31.115.244:6379
   slots:[10923-16383] (5461 slots) master
Can I set the above configuration? (type 'yes' to accept): yes
>>> Nodes configuration updated
>>> Assign a different config epoch to each node
>>> Sending CLUSTER MEET messages to join the cluster
Waiting for the cluster to join
.
>>> Performing Cluster Check (using node 172.31.115.243:6379)
M: 51448a107d69fcb91cc1e1ee59ba70be7e139d86 172.31.115.243:6379
   slots:[0-5460] (5461 slots) master
M: a63e7791b41fe157b3a90e305db91f99cf8c49d3 172.31.115.244:6379
   slots:[10923-16383] (5461 slots) master
M: 2402eb3ca2060f93c1603f64411133252d8a65b2 172.31.115.237:6379
   slots:[5461-10922] (5462 slots) master
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
maxuser@iZm5e9bofjg5xqnbvcrvrbZ:/opt/max/mymax/service/redis/bin$ 


