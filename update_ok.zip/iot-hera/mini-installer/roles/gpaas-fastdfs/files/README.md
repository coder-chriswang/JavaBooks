## redis安装包制作说明
1. 官网下载：wget http://download.redis.io/releases/redis-5.0.5.tar.gz
2. tar -xvf redis-5.0.5.tar.gz
3. mv redis-5.0.5 redis 
4. tar -zcvf redis.tar.gz redis

