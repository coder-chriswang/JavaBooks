## mysql安装包制作说明
1. 官网下载：wget https://www.keepalived.org/software/keepalived-2.0.18.tar.gz
2. tar -xvf keepalived-2.0.18.tar.gz
3. cd keepalived-2.0.18
4. sudo apt-get install openssl
5. sudo apt-get install libssl-dev
6. ./configure --prefix=/opt/max/mymax/service/keepalived
7. tar -zcvf keepalived.tar.gz /opt/max/mymax/service/keepalived


ln -s /usr/lib64/*.so /usr/lib



yum install libssl1.0.0



[root@localhost yum.repos.d]# yum install openssl 
Loaded plugins: langpacks, product-id, search-disabled-repos, subscription-manager
This system is not registered with an entitlement server. You can use subscription-manager to register.
base                                                                                                                                       | 3.6 kB  00:00:00     
extras                                                                                                                                     | 2.9 kB  00:00:00     
updates                                                                                                                                    | 2.9 kB  00:00:00     
(1/4): base/x86_64/group_gz                                                                                                                | 165 kB  00:00:00     
(2/4): extras/x86_64/primary_db                                                                                                            | 152 kB  00:00:00     
(3/4): updates/x86_64/primary_db                                                                                                           | 1.1 MB  00:00:00     
base/x86_64/primary_db         FAILED                                          
http://mirrors.aliyuncs.com/centos/7/os/x86_64/repodata/04efe80d41ea3d94d36294f7107709d1c8f70db11e152d6ef562da344748581a-primary.sqlite.bz2: [Errno 14] curl#7 - "Failed connect to mirrors.aliyuncs.com:80; Connection refused"
Trying other mirror.
(4/4): base/x86_64/primary_db                                                                                                              | 6.0 MB  00:00:00     
Resolving Dependencies
--> Running transaction check
---> Package openssl.x86_64 1:1.0.2k-8.el7 will be updated
---> Package openssl.x86_64 1:1.0.2k-19.el7 will be an update
--> Processing Dependency: openssl-libs(x86-64) = 1:1.0.2k-19.el7 for package: 1:openssl-1.0.2k-19.el7.x86_64
--> Running transaction check
---> Package openssl-libs.x86_64 1:1.0.2k-8.el7 will be updated
---> Package openssl-libs.x86_64 1:1.0.2k-19.el7 will be an update
--> Finished Dependency Resolution

Dependencies Resolved

==================================================================================================================================================================
 Package                                  Arch                               Version                                       Repository                        Size
==================================================================================================================================================================
Updating:
 openssl                                  x86_64                             1:1.0.2k-19.el7                               base                             493 k
Updating for dependencies:
 openssl-libs                             x86_64                             1:1.0.2k-19.el7                               base                             1.2 M

Transaction Summary
==================================================================================================================================================================
Upgrade  1 Package (+1 Dependent package)

Total download size: 1.7 M
Is this ok [y/d/N]: y
Downloading packages:
Delta RPMs disabled because /usr/bin/applydeltarpm not installed.
warning: /var/cache/yum/x86_64/7Server/base/packages/openssl-1.0.2k-19.el7.x86_64.rpm: Header V3 RSA/SHA256 Signature, key ID f4a80eb5: NOKEY
Public key for openssl-1.0.2k-19.el7.x86_64.rpm is not installed
(1/2): openssl-1.0.2k-19.el7.x86_64.rpm                                                                                                    | 493 kB  00:00:00     
(2/2): openssl-libs-1.0.2k-19.el7.x86_64.rpm                                                                                               | 1.2 MB  00:00:00     
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                                             6.0 MB/s | 1.7 MB  00:00:00     
Retrieving key from http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7
Importing GPG key 0xF4A80EB5:
 Userid     : "CentOS-7 Key (CentOS 7 Official Signing Key) <security@centos.org>"
 Fingerprint: 6341 ab27 53d7 8a78 a7c2 7bb1 24c6 a8a7 f4a8 0eb5
 From       : http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7
Is this ok [y/N]: y
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
Warning: RPMDB altered outside of yum.
  Updating   : 1:openssl-libs-1.0.2k-19.el7.x86_64                                                                                                            1/4 
  Updating   : 1:openssl-1.0.2k-19.el7.x86_64                                                                                                                 2/4 
  Cleanup    : 1:openssl-1.0.2k-8.el7.x86_64                                                                                                                  3/4 
  Cleanup    : 1:openssl-libs-1.0.2k-8.el7.x86_64                                                                                                             4/4 
  Verifying  : 1:openssl-libs-1.0.2k-19.el7.x86_64                                                                                                            1/4 
  Verifying  : 1:openssl-1.0.2k-19.el7.x86_64                                                                                                                 2/4 
  Verifying  : 1:openssl-libs-1.0.2k-8.el7.x86_64                                                                                                             3/4 
  Verifying  : 1:openssl-1.0.2k-8.el7.x86_64                                                                                                                  4/4 

Updated:
  openssl.x86_64 1:1.0.2k-19.el7                                                                                                                                  

Dependency Updated:
  openssl-libs.x86_64 1:1.0.2k-19.el7                                                                                                                             

Complete!



yum install openssl-devel

Downloading packages:
Delta RPMs disabled because /usr/bin/applydeltarpm not installed.
(1/20): e2fsprogs-libs-1.42.9-16.el7.x86_64.rpm                                                                                            | 167 kB  00:00:00     
(2/20): e2fsprogs-1.42.9-16.el7.x86_64.rpm                                                                                                 | 700 kB  00:00:00     
(3/20): libcom_err-1.42.9-16.el7.x86_64.rpm                                                                                                |  41 kB  00:00:00     
(4/20): keyutils-libs-devel-1.5.8-3.el7.x86_64.rpm                                                                                         |  37 kB  00:00:00     
(5/20): libcom_err-devel-1.42.9-16.el7.x86_64.rpm                                                                                          |  32 kB  00:00:00     
(6/20): krb5-libs-1.15.1-37.el7_7.2.x86_64.rpm                                                                                             | 805 kB  00:00:00     
(7/20): krb5-devel-1.15.1-37.el7_7.2.x86_64.rpm                                                                                            | 272 kB  00:00:00     
(8/20): libkadm5-1.15.1-37.el7_7.2.x86_64.rpm                                                                                              | 178 kB  00:00:00     
(9/20): libselinux-2.5-14.1.el7.x86_64.rpm                                                                                                 | 162 kB  00:00:00     
(10/20): libselinux-python-2.5-14.1.el7.x86_64.rpm                                                                                         | 235 kB  00:00:00     
(11/20): libselinux-devel-2.5-14.1.el7.x86_64.rpm                                                                                          | 187 kB  00:00:00     
(12/20): libselinux-utils-2.5-14.1.el7.x86_64.rpm                                                                                          | 151 kB  00:00:00     
(13/20): libsepol-2.5-10.el7.x86_64.rpm                                                                                                    | 297 kB  00:00:00     
(14/20): libsepol-devel-2.5-10.el7.x86_64.rpm                                                                                              |  77 kB  00:00:00     
(15/20): libss-1.42.9-16.el7.x86_64.rpm                                                                                                    |  46 kB  00:00:00     
(16/20): libverto-devel-0.2.5-4.el7.x86_64.rpm                                                                                             |  12 kB  00:00:00     
(17/20): pcre-devel-8.32-17.el7.x86_64.rpm                                                                                                 | 480 kB  00:00:00     
(18/20): zlib-1.2.7-18.el7.x86_64.rpm                                                                                                      |  90 kB  00:00:00     
(19/20): zlib-devel-1.2.7-18.el7.x86_64.rpm                                                                                                |  50 kB  00:00:00     
(20/20): openssl-devel-1.0.2k-19.el7.x86_64.rpm                                                                                            | 1.5 MB  00:00:00     
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                                             9.4 MB/s | 5.4 MB  00:00:00     
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction







在线安装：
[root@localhost lib64]# yum install keepalived -y 
Loaded plugins: langpacks, product-id, search-disabled-repos, subscription-manager
This system is not registered with an entitlement server. You can use subscription-manager to register.
Resolving Dependencies
--> Running transaction check
---> Package keepalived.x86_64 0:1.3.5-16.el7 will be installed
--> Processing Dependency: libnetsnmpmibs.so.31()(64bit) for package: keepalived-1.3.5-16.el7.x86_64
--> Processing Dependency: libnetsnmpagent.so.31()(64bit) for package: keepalived-1.3.5-16.el7.x86_64
--> Processing Dependency: libnetsnmp.so.31()(64bit) for package: keepalived-1.3.5-16.el7.x86_64
--> Running transaction check
---> Package net-snmp-agent-libs.x86_64 1:5.7.2-43.el7 will be installed
---> Package net-snmp-libs.x86_64 1:5.7.2-43.el7 will be installed
--> Finished Dependency Resolution

Dependencies Resolved

==================================================================================================================================================================
 Package                                        Arch                              Version                                   Repository                       Size
==================================================================================================================================================================
Installing:
 keepalived                                     x86_64                            1.3.5-16.el7                              base                            331 k
Installing for dependencies:
 net-snmp-agent-libs                            x86_64                            1:5.7.2-43.el7                            base                            706 k
 net-snmp-libs                                  x86_64                            1:5.7.2-43.el7                            base                            750 k

Transaction Summary
==================================================================================================================================================================
Install  1 Package (+2 Dependent packages)

Total download size: 1.7 M
Installed size: 6.0 M
Downloading packages:
(1/3): net-snmp-agent-libs-5.7.2-43.el7.x86_64.rpm                                                                                         | 706 kB  00:00:00     
(2/3): keepalived-1.3.5-16.el7.x86_64.rpm                                                                                                  | 331 kB  00:00:00     
(3/3): net-snmp-libs-5.7.2-43.el7.x86_64.rpm                                                                                               | 750 kB  00:00:00     
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                                             5.1 MB/s | 1.7 MB  00:00:00     
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
  Installing : 1:net-snmp-libs-5.7.2-43.el7.x86_64                                                                                                            1/3 
  Installing : 1:net-snmp-agent-libs-5.7.2-43.el7.x86_64                                                                                                      2/3 
  Installing : keepalived-1.3.5-16.el7.x86_64                                                                                                                 3/3 
  Verifying  : keepalived-1.3.5-16.el7.x86_64                                                                                                                 1/3 
  Verifying  : 1:net-snmp-agent-libs-5.7.2-43.el7.x86_64                                                                                                      2/3 
  Verifying  : 1:net-snmp-libs-5.7.2-43.el7.x86_64                                                                                                            3/3 

Installed:
  keepalived.x86_64 0:1.3.5-16.el7                                                                                                                                

Dependency Installed:
  net-snmp-agent-libs.x86_64 1:5.7.2-43.el7                                          net-snmp-libs.x86_64 1:5.7.2-43.el7                                         

Complete!






