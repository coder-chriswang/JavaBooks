## elastic-exporter安装包制作说明
1. 官网下载：wget https://github.com/justwatchcom/elasticsearch_exporter/releases/download/v1.1.0rc1/elasticsearch_exporter-1.1.0rc1.linux-amd64.tar.gz
2. tar -xvf elasticsearch_exporter-1.1.0rc1.linux-amd64.tar.gz
3. mv elasticsearch_exporter-1.1.0rc1.linux-amd64 elastic-exporter
4. tar -zcvf elastic-exporter.tar.gz elastic-exporter

