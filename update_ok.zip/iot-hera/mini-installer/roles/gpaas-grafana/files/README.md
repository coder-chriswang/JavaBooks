## grafana安装包制作说明
1. 官网下载：wget https://dl.grafana.com/oss/release/grafana-6.2.5.linux-amd64.tar.gz
2. tar -xvf grafana-6.2.5.linux-amd64.tar.gz
3. mv grafana-6.2.5.linux-amd64 grafana
4. tar -zcvf grafana.tar.gz grafana

