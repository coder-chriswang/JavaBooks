## Hbase安装包制作说明
1. 官网下载：wget https://mirrors.tuna.tsinghua.edu.cn/apache/hbase/2.2.4/hbase-2.2.4-bin.tar.gz
2. tar -xvf hbase-2.2.4-bin.tar.gz
3. mv hbase-2.2.4-bin.tar.gz hbase 
4. tar -zcvf hbase.tar.gz hbase


##mysql集群包制作（MHA+KeepAlive+MYSQL主从同步）
1：wget wget https://mirrors.tuna.tsinghua.edu.cn/apache/hbase/2.2.4/hbase-2.2.4-bin.tar.gz
2：wget https://downloads.apache.org/zookeeper/zookeeper-3.6.0/apache-zookeeper-3.6.0-bin.tar.gz


ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.228
ansible-playbook -i hosts/hosts_mysql_test ./yml/mysql.yml --tags=install

### 配置master-db数据库。

0. 备份master数据库：
/opt/max/mymax/service/mysql/bin/mysqldump -hlocalhost -uroot -p'mymax@321' --socket=/var/log/mymax/mysql/mysqld.sock --master-data=2 --single-transaction -R --triggers -A > /var/log/mymax/mysql/all.sql

1. 在Master MySQL上创建一个用户‘repl’，并允许其他Slave服务器可以通过远程访问Master，通过该用户读取二进制日志，实现数据同步。
mysql> GRANT REPLICATION SLAVE ON *.* TO 'maxrepl'@'172.31.115.%' IDENTIFIED BY 'mymax@321';

（//repl用户必须具有REPLICATION SLAVE权限，除此之外没有必要添加不必要的权限，密码为mymax@321。说明一下172.31.115.%，这个配置是指明maxrepl用户所在服务器，这里%是通配符，表示这个网段的Server都可以以maxrepl用户登陆主服务器。当然你也可以指定固定Ip。）

2. 启动二进制日志log-bin。修改mysql.cnf，在[mysqld]下面增加下面几行代码
server-id=1   //给数据库服务的唯一标识，一般为大家设置服务器Ip的末尾号
log-bin=master-bin
log-bin-index=master-bin.index

3. 查看binlog日志状态：
mysql> SHOW MASTER STATUS;

4. 重启MYSQL服务

### 配置slave-db-备主数据库。

1. 修改mysql.cnf。在[mysqld]下面增加如下配置。
[mysqld]
server-id=2
relay-log-index=slave-relay-bin.index
relay-log=slave-relay-bin
重启MYSQL服务

###数据库操作相关
1：控制台登陆：
/opt/max/mymax/service/mysql/bin/mysql --socket=/var/log/mymax/mysql/mysqld.sock -u root  -p'mymax@321'

2：查询数据库：show databases;

show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mymax              |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
5 rows in set (0.00 sec)

3：查询所有用户：
select user,host from mysql.user;

4：查看用户赋予的权限：
show grants for maxrepl;

5：查看当前登陆用户
select user();



