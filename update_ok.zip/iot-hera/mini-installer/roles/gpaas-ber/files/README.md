## openresty安装包制作说明
1. cd /opt/software/
2. mkdir openresty
3. wget https://codeload.github.com/openssl/openssl/zip/OpenSSL_1_1_1c
4. mv OpenSSL_1_1_1c OpenSSL_1_1_1c.tar.gz
5. wget http://zlib.net/zlib-1.2.11.tar.gz
6. wget https://openresty.org/download/openresty-1.15.8.1.tar.gz
7. tar -xvf openresty-1.15.8.1.tar.gz
8. tar -xvf OpenSSL_1_1_1c OpenSSL_1_1_1c.tar.gz ./openresty-1.15.8.1/
9. tar -xvf zlib-1.2.11.tar.gz.tar.gz ./openresty-1.15.8.1/
10. cd openresty-1.15.8.1
11. ./configure -j2 --prefix=/opt/max/mymax/service/openresty \
   --with-pcre-jit \
   --with-http_ssl_module \
   --with-http_realip_module \
   --with-http_stub_status_module \
   --with-http_v2_module \
   --with-pcre \
   --with-zlib=./zlib-1.2.11 \
   --with-openssl=./openssl-OpenSSL_1_1_1c \
   --with-ipv6 \
   --error-log-path=/var/log/mymax/openresty/error.log \
   --pid-path=/var/run/mymax/openresty.pid \
   --http-log-path=/var/log/mymax/openresty/access.log
12. make -j2
13. make install
14. tar -zcvf openresty.tar.gz /opt/max/mymax/service/openresty

