#!/bin/bash

###获取主机IP的最后一位数字
HOST_IP=`/sbin/ifconfig -a|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d "addr:"`
IP_NUMS=(${HOST_IP//./ })  
exit ${IP_NUMS[3]}

