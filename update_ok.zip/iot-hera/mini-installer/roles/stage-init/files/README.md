## 维护工具目录说明


工具名称|功能描述|使用场景
-|-|-
ip_endwith.sh|获取本机IP的最后一位数值|mysql的server_id生成使用
arthas|线上java问题定位工具|线上不停服场景下定位java应用的工具
tools-es-recover|es集群数据重建工具|es集群完全不可用场景下，重建es索引数据。
