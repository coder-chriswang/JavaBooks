mysql集群部署，参考：https://www.cnblogs.com/yuanermen/p/3726961.html

devops-dev           master-db 172.31.115.237
devops-ops           slave-1-db 172.31.115.228
水木游               slave-2-db 172.31.115.243       W@FeikOilBdJb06V

1：wget https://www.keepalived.org/software/keepalived-2.0.18.tar.gz
2：wget http://ftp.debian.org/debian/pool/main/m/mha4mysql-node/mha4mysql-node_0.54.orig.tar.gz
3：wget http://ftp.debian.org/debian/pool/main/m/mha4mysql-manager/mha4mysql-manager_0.55.orig.tar.gz
4：wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-5.7.27-linux-glibc2.12-x86_64.tar.gz


===========================配置主从同步========================================
1：mysql部署
1.1：master-db,slave-1-db,slave-2-db

ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.228
ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.237
ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.243
ansible-playbook -i hosts/hosts_mysql_test ./yml/mysql.yml --tags=install


1.2:每个节点创建主从复制用户

GRANT REPLICATION SLAVE ON *.* TO 'maxrepl'@'172.31.115.%' IDENTIFIED BY 'mymax@321';
flush privileges;

1.3：master-db上配置：
mysql.cnf中：
server-id=237
log-bin=mysql-bin
binlog_format=mixed
2.mysql>show master status;

1.4：slave-db上配置：
change master操作
mysql>change master to master_host='172.31.115.237',master_port=3306,master_user='maxrepl',master_password='mymax@321',master_log_file='master-bin.000002',master_log_pos=1730;
mysql>start slave;


说明：
master_log_file='mysql-bin.000001',master_log_pos=112;
这两名是通过maste中用： show master status;查出来的。
		
1.5：所有主机设置复制权限账号
5.所有主机上设置复制权限帐号
mysql>GRANT ALL PRIVILEGES ON*.*TO 'maxrepl '@'%' IDENTIFIED BY 'maxrepl';

1.6:查看主从同步：
slave-db上执行：show slave status\G


主从同步配置检查：
问题1： 从库：Slave_IO_Running:NO 
检查一：检查复制用户远程登录master-db是否成功？--ok
检查二：检查maxrepl权限----------ok

数据库操作：
/opt/max/mymax/service/mysql/bin/mysql --socket=/var/log/mymax/mysql/mysqld.sock -u root  -p'mymax@321'


注意：
数据库的安装及master与slave配置成功，可以进行主从同步了！
主从同步的常见错误，其实不外乎就是网络、权限、iptables、SELinux等问题，我们平时注意检查这些问题，处理起来应该不是很困难，
大家记得关闭iptables(或开通对应的端口)和SELinux，注意Slave_IO_Running和Slave_SQL_Running状态必须确保主Yes才行，
另外也要注意从机的Seconds_Behind_Master值及主从机的server-id不可以相同！



其它
1：检查从库与主库的最后同步状态：
mysql>show processlist;
mysql> show processlist;
+----+---------+----------------------+------+-------------+------+---------------------------------------------------------------+------------------+
| Id | User    | Host                 | db   | Command     | Time | State                                                         | Info             |
+----+---------+----------------------+------+-------------+------+---------------------------------------------------------------+------------------+
|  2 | maxrepl | 172.31.115.228:63809 | NULL | Binlog Dump |  174 | Master has sent all binlog to slave; waiting for more updates | NULL             |
|  3 | maxrepl | 172.31.115.243:57450 | NULL | Binlog Dump |  154 | Master has sent all binlog to slave; waiting for more updates | NULL             |
|  4 | root    | localhost            | NULL | Query       |    0 | starting                                                      | show processlist |
+----+---------+----------------------+------+-------------+------+---------------------------------------------------------------+------------------+
3 rows in set (0.00 sec)

验证：
1：master-db上写入数据，查看从库上是否存在此份数据。---验证通过
USE mysql;
CREATE DATABASE test DEFAULT CHARACTER SET UTF8 COLLATE UTF8_GENERAL_CI;
CREATE USER 'test'@'%' IDENTIFIED BY 'test';
GRANT ALL on test.* TO 'test';
FLUSH PRIVILEGES;

2：停止掉一台slave-db，并在master-db上写入数据，再启动slave-db，查看slave-db上是否存在刚才数据。--------验证通过
use test;
CREATE TABLE student (id int,name varchar(20));







ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.237
ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.228
ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.243






MHA部署：
配置集群节点每俩俩免密登陆
2：在manager（243）节点生成证书
ssh-keygen -t rsa -b 2048
scp /root/.ssh/id_rsa.pub root@172.31.115.228:/root/.ssh/
scp /root/.ssh/id_rsa.pub root@172.31.115.237:/root/.ssh/
3：在master-db和slave-db节点中：
cat /root/.ssh/id_rsa.pub >> authorized_keys

4：在master-db（237）节点生成证书
ssh-keygen -t rsa -b 2048
scp /root/.ssh/id_rsa.pub root@172.31.115.243:/root/.ssh/
scp /root/.ssh/id_rsa.pub root@172.31.115.228:/root/.ssh/
5：在manager和slave-db节点中：
cat /root/.ssh/id_rsa.pub >> authorized_keys

6：在slave-db（228）节点生成证书
ssh-keygen -t rsa -b 2048
scp /root/.ssh/id_rsa.pub root@172.31.115.243:/root/.ssh/
scp /root/.ssh/id_rsa.pub root@172.31.115.237:/root/.ssh/
7：在master-db和manager节点中：
cat /root/.ssh/id_rsa.pub >> authorized_keys


删除每个节点下的/root/.ssh/id_rsa.pub




1.3：测试manager免密登陆master-db和slave-db节点：
manager节点上执行：ssh 172.31.115.228


2：manager节点安装mha4mysql-manager
tar -zxf mha4mysql-manager-0.56.tar.gz
cd mha4mysql-manager-0.56
perl Makefile.PL
make
make install




make指令执行过程输出：会需要从公网下载东西

make install指令后，过程输出如下：
Installing /usr/local/share/perl/5.22.1/MHA/MasterFailover.pm
Installing /usr/local/share/perl/5.22.1/MHA/MasterMonitor.pm
Installing /usr/local/share/perl/5.22.1/MHA/ManagerAdminWrapper.pm
Installing /usr/local/share/perl/5.22.1/MHA/ManagerConst.pm
Installing /usr/local/share/perl/5.22.1/MHA/FileStatus.pm
Installing /usr/local/share/perl/5.22.1/MHA/Server.pm
Installing /usr/local/share/perl/5.22.1/MHA/HealthCheck.pm
Installing /usr/local/share/perl/5.22.1/MHA/DBHelper.pm
Installing /usr/local/share/perl/5.22.1/MHA/Config.pm
Installing /usr/local/share/perl/5.22.1/MHA/ManagerAdmin.pm
Installing /usr/local/share/perl/5.22.1/MHA/ServerManager.pm
Installing /usr/local/share/perl/5.22.1/MHA/ManagerUtil.pm
Installing /usr/local/share/perl/5.22.1/MHA/SSHCheck.pm
Installing /usr/local/share/perl/5.22.1/MHA/MasterRotate.pm
Installing /usr/local/man/man1/masterha_check_repl.1p
Installing /usr/local/man/man1/masterha_stop.1p
Installing /usr/local/man/man1/masterha_master_switch.1p
Installing /usr/local/man/man1/masterha_secondary_check.1p
Installing /usr/local/man/man1/masterha_manager.1p
Installing /usr/local/man/man1/masterha_master_monitor.1p
Installing /usr/local/man/man1/masterha_conf_host.1p
Installing /usr/local/man/man1/masterha_check_status.1p
Installing /usr/local/man/man1/masterha_check_ssh.1p
Installing /usr/local/bin/masterha_master_monitor
Installing /usr/local/bin/masterha_check_status
Installing /usr/local/bin/masterha_check_repl
Installing /usr/local/bin/masterha_manager
Installing /usr/local/bin/masterha_master_switch
Installing /usr/local/bin/masterha_check_ssh
Installing /usr/local/bin/masterha_conf_host
Installing /usr/local/bin/masterha_secondary_check
Installing /usr/local/bin/masterha_stop
Appending installation info to /usr/local/lib/x86_64-linux-gnu/perl/5.22.1/perllocal.pod





3：node几点安装：
tar -zxfmha4mysql-node-0.56.tar.gz
cd mha4mysql-node-0.56
perl Makefile.PL
make
make install



Usage:
    masterha_check_ssh --global_conf=/etc/masterha_default.cnf
    --conf=/etc/conf/masterha/app1.cnf




4:
[server default]
user=root
password=mymax@321
manager_workdir=/masterha/app1
manager_log=/masterha/app1/manager.log
remote_workdir=/masterha/app1
ssh_user=root
repl_user=maxrepl
repl_password=mymax@321
ping_interval=1
[server1]
hostname=172.31.115.237
master_binlog_dir=/opt/max/mymax/data/mysql
candidate_master=1
check_repl_delay = 0
[server2]
hostname=172.31.115.228
master_binlog_dir=/opt/max/mymax/data/mysql
candidate_master=1
check_repl_delay = 0
[server3]
hostname=172.31.115.243
master_binlog_dir=/opt/max/mymax/data/mysql
check_repl_delay = 0

5:验证ssh免密登陆是否成功
masterha_check_ssh --conf=/opt/masterha/app1.cnf          
此步骤如果出错，八成是ssh免密登陆配置有问题。同时排查防火墙是否关闭状态。


6：验证复制是否成功


masterha_check_repl --conf=/opt/masterha/app1.cnf

7：启动MHA manager并监控日志文件
[manager:201]
shell> nohup masterha_manager --conf=/etc/masterha/app1.cnf > /tmp/mha_manager.log 2>&1 
shell> tail -f /masterha/app1/manager.log  //这名最好在新窗口执行

8、测试master(231)宕机后，是否会自动切换

[master--231]
shell>service mysql stop


9、故障转移后，用命令恢复原来的master

(1)、在旧master上执行

复制代码
1.在旧master上执行
shell>service mysql start //数据库启动
shell>mysql -usunney -psunney
mysql> reset master;
mysql> change master to master_host='192.168.1.232', master_port=3306, master_user='sunney', master_password='sunney', master_log_file='mysql-bin.000031', master_log_pos=112;
mysql> start slave;      #暂时先把旧master变为slave
复制代码
（2）然后在manager节点上：

 

shell> masterha_master_switch --master_state=alive --conf=/etc/masterha/app1.cnf


=========================
mha4mysql-manager包及其依赖：ubuntu16.04
wget http://archive.ubuntu.com/ubuntu/pool/universe/m/mha4mysql-manager/mha4mysql-manager_0.55-1_all.deb
wget http://archive.ubuntu.com/ubuntu/pool/universe/libc/libconfig-tiny-perl/libconfig-tiny-perl_2.23-1_all.deb
wget http://archive.ubuntu.com/ubuntu/pool/universe/libd/libdbd-mysql-perl/libdbd-mysql-perl_4.033-1ubuntu0.1_amd64.deb
wget http://archive.ubuntu.com/ubuntu/pool/main/libd/libdbi-perl/libdbi-perl_1.634-1build1_amd64.deb
wget http://archive.ubuntu.com/ubuntu/pool/universe/libl/liblog-dispatch-perl/liblog-dispatch-perl_2.54-1_all.deb
wget http://archive.ubuntu.com/ubuntu/pool/universe/libp/libparallel-forkmanager-perl/libparallel-forkmanager-perl_1.17-1_all.deb
wget http://archive.ubuntu.com/ubuntu/pool/universe/m/mha4mysql-node/mha4mysql-node_0.54-1_all.deb
wget http://archive.ubuntu.com/ubuntu/pool/main/p/perl/perl_5.22.1-9ubuntu0.6_amd64.deb






