## prometheus安装包制作说明
1. 官网下载：wget https://github.com/prometheus/prometheus/releases/download/v2.11.1/prometheus-2.11.1.linux-amd64.tar.gz
2. tar -xvf prometheus-2.11.1.linux-amd64.tar.gz
3. mv prometheus-2.11.1.linux-amd64 prometheus 
4. tar -zcvf prometheus.tar.gz prometheus

