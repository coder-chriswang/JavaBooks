## node-exporter安装包制作说明
1. 官网下载：wget https://github.com/prometheus/node_exporter/releases/download/v0.18.1/node_exporter-0.18.1.linux-amd64.tar.gz
2. tar -xvf node_exporter-0.18.1.linux-amd64.tar.gz
3. mv node_exporter-0.18.1.linux-amd64 node-exporter 
4. tar -zcvf node-exporter.tar.gz node-exporter

