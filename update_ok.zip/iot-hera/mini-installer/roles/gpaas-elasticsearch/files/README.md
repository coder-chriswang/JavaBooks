## elasticsearch安装包制作说明
1. 官网下载：wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-6.2.4.tar.gz
2. tar -xvf elasticsearch-6.2.4.tar.gz
3. ./elasticsearch/bin/elasticsearch-plugin -v install https://github.com/medcl/elasticsearch-analysis-ik/releases/download/v6.2.4/elasticsearch-analysis-ik-6.2.4.zip
4. mv elasticsearch-6.2.4 elasticsearch
5. tar -zcvf elasticsearch.tar.gz elasticsearch


