## mysql安装包制作说明
1. 官网下载：wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-5.7.27-linux-glibc2.12-x86_64.tar.gz
2. tar -xvf mysql-5.7.27-linux-glibc2.12-x86_64.tar.gz
3. mv mysql-5.7.27-linux-glibc2.12-x86_64 mysql 
4. tar -zcvf mysql.tar.gz mysql


##mysql集群包制作（MHA+KeepAlive+MYSQL主从同步）
1：wget https://www.keepalived.org/software/keepalived-2.0.18.tar.gz
2：wget http://ftp.debian.org/debian/pool/main/m/mha4mysql-node/mha4mysql-node_0.54.orig.tar.gz
3：wget http://ftp.debian.org/debian/pool/main/m/mha4mysql-manager/mha4mysql-manager_0.55.orig.tar.gz
4：wget https://cdn.mysql.com//Downloads/MySQL-5.7/mysql-5.7.27-linux-glibc2.12-x86_64.tar.gz


ssh-copy-id -i /root/.ssh/id_rsa root@172.31.115.228
ansible-playbook -i hosts/hosts_mysql_test ./yml/mysql.yml --tags=install

### 配置master-db数据库。

0. 备份master数据库：
/opt/max/mymax/service/mysql/bin/mysqldump -hlocalhost -uroot -p'mymax@321' --socket=/var/log/mymax/mysql/mysqld.sock --master-data=2 --single-transaction -R --triggers -A > /var/log/mymax/mysql/all.sql

1. 在Master MySQL上创建一个用户‘repl’，并允许其他Slave服务器可以通过远程访问Master，通过该用户读取二进制日志，实现数据同步。
mysql> GRANT REPLICATION SLAVE ON *.* TO 'maxrepl'@'172.31.115.%' IDENTIFIED BY 'mymax@321';

（//repl用户必须具有REPLICATION SLAVE权限，除此之外没有必要添加不必要的权限，密码为mymax@321。说明一下172.31.115.%，这个配置是指明maxrepl用户所在服务器，这里%是通配符，表示这个网段的Server都可以以maxrepl用户登陆主服务器。当然你也可以指定固定Ip。）

2. 启动二进制日志log-bin。修改mysql.cnf，在[mysqld]下面增加下面几行代码
server-id=1   //给数据库服务的唯一标识，一般为大家设置服务器Ip的末尾号
log-bin=master-bin
log-bin-index=master-bin.index

3. 查看binlog日志状态：
mysql> SHOW MASTER STATUS;

4. 重启MYSQL服务

### 配置slave-db-备主数据库。

1. 修改mysql.cnf。在[mysqld]下面增加如下配置。
[mysqld]
server-id=2
relay-log-index=slave-relay-bin.index
relay-log=slave-relay-bin
重启MYSQL服务

###数据库操作相关
1：控制台登陆：
/opt/max/mymax/service/mysql/bin/mysql --socket=/var/log/mymax/mysql/mysqld.sock -u root  -p'mymax@321'

2：查询数据库：show databases;

show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mymax              |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
5 rows in set (0.00 sec)

3：查询所有用户：
select user,host from mysql.user;

4：查看用户赋予的权限：
show grants for maxrepl;

5：查看当前登陆用户
select user();


yum install cpan

warning: /var/cache/yum/x86_64/7/base/packages/libdb-5.3.21-25.el7.x86_64.rpm: Header V3 RSA/SHA256 Signature, key ID f4a80eb5: NOKEY
Public key for libdb-5.3.21-25.el7.x86_64.rpm is not installed
(1/17): libdb-5.3.21-25.el7.x86_64.rpm                                                                                                     | 720 kB  00:00:00     
(2/17): gdbm-devel-1.10-8.el7.x86_64.rpm                                                                                                   |  47 kB  00:00:00     
(3/17): libdb-utils-5.3.21-25.el7.x86_64.rpm                                                                                               | 132 kB  00:00:00     
(4/17): perl-CPAN-1.9800-294.el7_6.noarch.rpm                                                                                              | 293 kB  00:00:00     
(5/17): perl-Data-Dumper-2.145-3.el7.x86_64.rpm                                                                                            |  47 kB  00:00:00     
(6/17): libdb-devel-5.3.21-25.el7.x86_64.rpm                                                                                               |  39 kB  00:00:00     
(7/17): perl-Digest-1.17-245.el7.noarch.rpm                                                                                                |  23 kB  00:00:00     
(8/17): perl-Digest-SHA-5.85-4.el7.x86_64.rpm                                                                                              |  58 kB  00:00:00     
(9/17): perl-ExtUtils-MakeMaker-6.68-3.el7.noarch.rpm                                                                                      | 275 kB  00:00:00     
(10/17): perl-ExtUtils-Install-1.58-294.el7_6.noarch.rpm                                                                                   |  75 kB  00:00:00     
(11/17): perl-ExtUtils-Manifest-1.61-244.el7.noarch.rpm                                                                                    |  31 kB  00:00:00     
(12/17): perl-Test-Harness-3.28-3.el7.noarch.rpm                                                                                           | 302 kB  00:00:00     
(13/17): perl-ExtUtils-ParseXS-3.18-3.el7.noarch.rpm                                                                                       |  77 kB  00:00:00     
(14/17): perl-devel-5.16.3-294.el7_6.x86_64.rpm                                                                                            | 453 kB  00:00:00     
(15/17): pyparsing-1.5.6-9.el7.noarch.rpm                                                                                                  |  94 kB  00:00:00     
(16/17): perl-local-lib-1.008010-4.el7.noarch.rpm                                                                                          |  64 kB  00:00:00     
(17/17): systemtap-sdt-devel-4.0-9.el7.x86_64.rpm                                                                                          |  76 kB  00:00:00     
--------------------------------------------------------


---------centos7.4下---------------------------


[root@ecs-ubuntu-16 opt]# yum -y install perl-Config-Tiny perl-Log-Dispatch perl-Parallel-ForkManager perl-Time-HiRes perl-devel perl-Module-Install.noarch
Loaded plugins: fastestmirror
Repository base is listed more than once in the configuration
Repository updates is listed more than once in the configuration
Repository extras is listed more than once in the configuration
Repository centosplus is listed more than once in the configuration
Loading mirror speeds from cached hostfile
 * base: mirrors.aliyun.com
 * epel: mirrors.tuna.tsinghua.edu.cn
 * extras: mirrors.aliyun.com
 * updates: mirrors.aliyun.com
Package perl-Config-Tiny-2.14-7.el7.noarch already installed and latest version
Package perl-Log-Dispatch-2.41-1.el7.1.noarch already installed and latest version
Package perl-Parallel-ForkManager-1.18-2.el7.noarch already installed and latest version
Package 4:perl-Time-HiRes-1.9725-3.el7.x86_64 already installed and latest version
Resolving Dependencies
--> Running transaction check
---> Package perl-Module-Install.noarch 0:1.06-4.el7 will be installed
--> Processing Dependency: perl(PAR::Dist) >= 0.29 for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(YAML::Tiny) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(Module::ScanDeps) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(Module::CoreList) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(Module::Build) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(LWP::UserAgent) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(File::Remove) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(ExtUtils::ParseXS) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(ExtUtils::Manifest) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(ExtUtils::MakeMaker) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(CPANPLUS::Backend) for package: perl-Module-Install-1.06-4.el7.noarch
--> Processing Dependency: perl(CPAN) for package: perl-Module-Install-1.06-4.el7.noarch
---> Package perl-devel.x86_64 4:5.16.3-294.el7_6 will be installed
--> Processing Dependency: systemtap-sdt-devel for package: 4:perl-devel-5.16.3-294.el7_6.x86_64
--> Processing Dependency: perl(ExtUtils::Installed) for package: 4:perl-devel-5.16.3-294.el7_6.x86_64
--> Processing Dependency: libdb-devel for package: 4:perl-devel-5.16.3-294.el7_6.x86_64
--> Processing Dependency: gdbm-devel for package: 4:perl-devel-5.16.3-294.el7_6.x86_64
--> Running transaction check
---> Package gdbm-devel.x86_64 0:1.10-8.el7 will be installed
---> Package libdb-devel.x86_64 0:5.3.21-25.el7 will be installed
--> Processing Dependency: libdb(x86-64) = 5.3.21-25.el7 for package: libdb-devel-5.3.21-25.el7.x86_64
---> Package perl-CPAN.noarch 0:1.9800-294.el7_6 will be installed
--> Processing Dependency: perl(local::lib) for package: perl-CPAN-1.9800-294.el7_6.noarch
--> Processing Dependency: perl(Digest::SHA) for package: perl-CPAN-1.9800-294.el7_6.noarch
---> Package perl-CPANPLUS.noarch 0:0.91.38-4.el7 will be installed
--> Processing Dependency: perl(version) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Term::UI) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Parse::CPAN::Meta) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Params::Check) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Package::Constants) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Object::Accessor) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Module::Pluggable) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Module::Loaded) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Module::Load::Conditional) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Module::Load) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Log::Message) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Locale::Maketext::Simple) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(IPC::Cmd) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(File::Fetch) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(DBIx::Simple) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(DBD::SQLite) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
--> Processing Dependency: perl(Archive::Extract) for package: perl-CPANPLUS-0.91.38-4.el7.noarch
---> Package perl-ExtUtils-Install.noarch 0:1.58-294.el7_6 will be installed
---> Package perl-ExtUtils-MakeMaker.noarch 0:6.68-3.el7 will be installed
--> Processing Dependency: perl(Test::Harness) for package: perl-ExtUtils-MakeMaker-6.68-3.el7.noarch
---> Package perl-ExtUtils-Manifest.noarch 0:1.61-244.el7 will be installed
---> Package perl-ExtUtils-ParseXS.noarch 1:3.18-3.el7 will be installed
---> Package perl-File-Remove.noarch 0:1.52-6.el7 will be installed
---> Package perl-Module-Build.noarch 2:0.40.05-2.el7 will be installed
--> Processing Dependency: perl(Perl::OSType) >= 1 for package: 2:perl-Module-Build-0.40.05-2.el7.noarch
--> Processing Dependency: perl(Module::Metadata) >= 1.000002 for package: 2:perl-Module-Build-0.40.05-2.el7.noarch
--> Processing Dependency: perl(ExtUtils::CBuilder) >= 0.27 for package: 2:perl-Module-Build-0.40.05-2.el7.noarch
--> Processing Dependency: perl(CPAN::Meta::YAML) >= 0.003 for package: 2:perl-Module-Build-0.40.05-2.el7.noarch
--> Processing Dependency: perl(CPAN::Meta) >= 2.110420 for package: 2:perl-Module-Build-0.40.05-2.el7.noarch
---> Package perl-Module-CoreList.noarch 1:2.76.02-294.el7_6 will be installed
---> Package perl-Module-ScanDeps.noarch 0:1.10-3.el7 will be installed
---> Package perl-PAR-Dist.noarch 0:0.49-2.el7 will be installed
--> Processing Dependency: perl(Module::Signature) >= 0.25 for package: perl-PAR-Dist-0.49-2.el7.noarch
--> Processing Dependency: perl(Archive::Zip) for package: perl-PAR-Dist-0.49-2.el7.noarch
---> Package perl-YAML-Tiny.noarch 0:1.51-6.el7 will be installed
---> Package perl-libwww-perl.noarch 0:6.05-2.el7 will be installed
--> Processing Dependency: perl(WWW::RobotRules) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(URI) >= 1.10 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(Net::HTTP) >= 6.04 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(LWP::MediaTypes) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Status) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Response) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Request::Common) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Request) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Negotiate) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Date) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Daemon) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTTP::Cookies) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(File::Listing) >= 6 for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(URI::Heuristic) for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(URI::Escape) for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTML::HeadParser) for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(HTML::Entities) for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(Encode::Locale) for package: perl-libwww-perl-6.05-2.el7.noarch
--> Processing Dependency: perl(Digest::MD5) for package: perl-libwww-perl-6.05-2.el7.noarch
---> Package systemtap-sdt-devel.x86_64 0:4.0-9.el7 will be installed
--> Processing Dependency: pyparsing for package: systemtap-sdt-devel-4.0-9.el7.x86_64
--> Running transaction check
---> Package libdb.x86_64 0:5.3.21-24.el7 will be updated
--> Processing Dependency: libdb(x86-64) = 5.3.21-24.el7 for package: libdb-utils-5.3.21-24.el7.x86_64
---> Package libdb.x86_64 0:5.3.21-25.el7 will be an update
---> Package perl-Archive-Extract.noarch 1:0.68-3.el7 will be installed
---> Package perl-Archive-Zip.noarch 0:1.30-11.el7 will be installed
---> Package perl-CPAN-Meta.noarch 0:2.120921-5.el7 will be installed
--> Processing Dependency: perl(CPAN::Meta::Requirements) >= 2.121 for package: perl-CPAN-Meta-2.120921-5.el7.noarch
--> Processing Dependency: perl(CPAN::Meta::Requirements) for package: perl-CPAN-Meta-2.120921-5.el7.noarch
---> Package perl-CPAN-Meta-YAML.noarch 0:0.008-14.el7 will be installed
---> Package perl-DBD-SQLite.x86_64 0:1.39-3.el7 will be installed
---> Package perl-DBIx-Simple.noarch 0:1.35-7.el7 will be installed
---> Package perl-Digest-MD5.x86_64 0:2.52-3.el7 will be installed
--> Processing Dependency: perl(Digest::base) >= 1.00 for package: perl-Digest-MD5-2.52-3.el7.x86_64
---> Package perl-Digest-SHA.x86_64 1:5.85-4.el7 will be installed
---> Package perl-Encode-Locale.noarch 0:1.03-5.el7 will be installed
---> Package perl-ExtUtils-CBuilder.noarch 1:0.28.2.6-294.el7_6 will be installed
---> Package perl-File-Fetch.noarch 0:0.42-2.el7 will be installed
---> Package perl-File-Listing.noarch 0:6.04-7.el7 will be installed
---> Package perl-HTML-Parser.x86_64 0:3.71-4.el7 will be installed
--> Processing Dependency: perl(HTML::Tagset) >= 3 for package: perl-HTML-Parser-3.71-4.el7.x86_64
---> Package perl-HTTP-Cookies.noarch 0:6.01-5.el7 will be installed
---> Package perl-HTTP-Daemon.noarch 0:6.01-8.el7 will be installed
---> Package perl-HTTP-Date.noarch 0:6.02-8.el7 will be installed
---> Package perl-HTTP-Message.noarch 0:6.06-6.el7 will be installed
--> Processing Dependency: perl(IO::HTML) for package: perl-HTTP-Message-6.06-6.el7.noarch
---> Package perl-HTTP-Negotiate.noarch 0:6.01-5.el7 will be installed
---> Package perl-IPC-Cmd.noarch 1:0.80-4.el7 will be installed
---> Package perl-LWP-MediaTypes.noarch 0:6.02-2.el7 will be installed
--> Processing Dependency: mailcap for package: perl-LWP-MediaTypes-6.02-2.el7.noarch
---> Package perl-Locale-Maketext-Simple.noarch 1:0.21-294.el7_6 will be installed
--> Processing Dependency: perl(Locale::Maketext) for package: 1:perl-Locale-Maketext-Simple-0.21-294.el7_6.noarch
---> Package perl-Log-Message.noarch 1:0.08-3.el7 will be installed
---> Package perl-Module-Load.noarch 1:0.24-3.el7 will be installed
---> Package perl-Module-Load-Conditional.noarch 0:0.54-3.el7 will be installed
---> Package perl-Module-Loaded.noarch 1:0.08-294.el7_6 will be installed
---> Package perl-Module-Metadata.noarch 0:1.000018-2.el7 will be installed
---> Package perl-Module-Pluggable.noarch 1:4.8-3.el7 will be installed
---> Package perl-Module-Signature.noarch 0:0.73-2.el7 will be installed
--> Processing Dependency: perl(Text::Diff) for package: perl-Module-Signature-0.73-2.el7.noarch
--> Processing Dependency: perl(Digest::SHA1) for package: perl-Module-Signature-0.73-2.el7.noarch
---> Package perl-Net-HTTP.noarch 0:6.06-2.el7 will be installed
---> Package perl-Object-Accessor.noarch 1:0.42-294.el7_6 will be installed
---> Package perl-Package-Constants.noarch 1:0.02-294.el7_6 will be installed
---> Package perl-Params-Check.noarch 1:0.38-2.el7 will be installed
---> Package perl-Parse-CPAN-Meta.noarch 1:1.4404-5.el7 will be installed
--> Processing Dependency: perl(JSON::PP) >= 2.27200 for package: 1:perl-Parse-CPAN-Meta-1.4404-5.el7.noarch
---> Package perl-Perl-OSType.noarch 0:1.003-3.el7 will be installed
---> Package perl-Term-UI.noarch 0:0.36-2.el7 will be installed
--> Processing Dependency: perl(Log::Message::Simple) for package: perl-Term-UI-0.36-2.el7.noarch
---> Package perl-Test-Harness.noarch 0:3.28-3.el7 will be installed
---> Package perl-URI.noarch 0:1.60-9.el7 will be installed
--> Processing Dependency: perl(Business::ISBN) for package: perl-URI-1.60-9.el7.noarch
---> Package perl-WWW-RobotRules.noarch 0:6.02-5.el7 will be installed
---> Package perl-local-lib.noarch 0:1.008010-4.el7 will be installed
---> Package perl-version.x86_64 3:0.99.07-3.el7 will be installed
---> Package pyparsing.noarch 0:1.5.6-9.el7 will be installed
--> Running transaction check
---> Package libdb-utils.x86_64 0:5.3.21-24.el7 will be updated
---> Package libdb-utils.x86_64 0:5.3.21-25.el7 will be an update
---> Package mailcap.noarch 0:2.1.41-2.el7 will be installed
---> Package perl-Business-ISBN.noarch 0:2.06-2.el7 will be installed
--> Processing Dependency: perl(Business::ISBN::Data) >= 20120719.001 for package: perl-Business-ISBN-2.06-2.el7.noarch
---> Package perl-CPAN-Meta-Requirements.noarch 0:2.122-7.el7 will be installed
---> Package perl-Digest.noarch 0:1.17-245.el7 will be installed
---> Package perl-Digest-SHA1.x86_64 0:2.13-9.el7 will be installed
---> Package perl-HTML-Tagset.noarch 0:3.20-15.el7 will be installed
---> Package perl-IO-HTML.noarch 0:1.00-2.el7 will be installed
---> Package perl-JSON-PP.noarch 0:2.27202-2.el7 will be installed
---> Package perl-Locale-Maketext.noarch 0:1.23-3.el7 will be installed
---> Package perl-Log-Message-Simple.noarch 0:0.10-2.el7 will be installed
---> Package perl-Text-Diff.noarch 0:1.41-5.el7 will be installed
--> Processing Dependency: perl(Algorithm::Diff) for package: perl-Text-Diff-1.41-5.el7.noarch
--> Running transaction check
---> Package perl-Algorithm-Diff.noarch 0:1.1902-17.el7 will be installed
---> Package perl-Business-ISBN-Data.noarch 0:20120719.001-2.el7 will be installed
--> Finished Dependency Resolution

Dependencies Resolved

==================================================================================================================================================================
 Package                                             Arch                          Version                                      Repository                   Size
==================================================================================================================================================================
Installing:
 perl-Module-Install                                 noarch                        1.06-4.el7                                   base                        185 k
 perl-devel                                          x86_64                        4:5.16.3-294.el7_6                           base                        453 k
Installing for dependencies:
 gdbm-devel                                          x86_64                        1.10-8.el7                                   base                         47 k
 libdb-devel                                         x86_64                        5.3.21-25.el7                                base                         39 k
 mailcap                                             noarch                        2.1.41-2.el7                                 base                         31 k
 perl-Algorithm-Diff                                 noarch                        1.1902-17.el7                                base                         47 k
 perl-Archive-Extract                                noarch                        1:0.68-3.el7                                 base                         28 k
 perl-Archive-Zip                                    noarch                        1.30-11.el7                                  base                        107 k
 perl-Business-ISBN                                  noarch                        2.06-2.el7                                   base                         25 k
 perl-Business-ISBN-Data                             noarch                        20120719.001-2.el7                           base                         24 k
 perl-CPAN                                           noarch                        1.9800-294.el7_6                             base                        293 k
 perl-CPAN-Meta                                      noarch                        2.120921-5.el7                               base                        113 k
 perl-CPAN-Meta-Requirements                         noarch                        2.122-7.el7                                  base                         24 k
 perl-CPAN-Meta-YAML                                 noarch                        0.008-14.el7                                 base                         24 k
 perl-CPANPLUS                                       noarch                        0.91.38-4.el7                                base                        307 k
 perl-DBD-SQLite                                     x86_64                        1.39-3.el7                                   base                        1.3 M
 perl-DBIx-Simple                                    noarch                        1.35-7.el7                                   base                         43 k
 perl-Digest                                         noarch                        1.17-245.el7                                 base                         23 k
 perl-Digest-MD5                                     x86_64                        2.52-3.el7                                   base                         30 k
 perl-Digest-SHA                                     x86_64                        1:5.85-4.el7                                 base                         58 k
 perl-Digest-SHA1                                    x86_64                        2.13-9.el7                                   base                         50 k
 perl-Encode-Locale                                  noarch                        1.03-5.el7                                   base                         16 k
 perl-ExtUtils-CBuilder                              noarch                        1:0.28.2.6-294.el7_6                         base                         68 k
 perl-ExtUtils-Install                               noarch                        1.58-294.el7_6                               base                         75 k
 perl-ExtUtils-MakeMaker                             noarch                        6.68-3.el7                                   base                        275 k
 perl-ExtUtils-Manifest                              noarch                        1.61-244.el7                                 base                         31 k
 perl-ExtUtils-ParseXS                               noarch                        1:3.18-3.el7                                 base                         77 k
 perl-File-Fetch                                     noarch                        0.42-2.el7                                   base                         27 k
 perl-File-Listing                                   noarch                        6.04-7.el7                                   base                         13 k
 perl-File-Remove                                    noarch                        1.52-6.el7                                   base                         26 k
 perl-HTML-Parser                                    x86_64                        3.71-4.el7                                   base                        115 k
 perl-HTML-Tagset                                    noarch                        3.20-15.el7                                  base                         18 k
 perl-HTTP-Cookies                                   noarch                        6.01-5.el7                                   base                         26 k
 perl-HTTP-Daemon                                    noarch                        6.01-8.el7                                   base                         21 k
 perl-HTTP-Date                                      noarch                        6.02-8.el7                                   base                         14 k
 perl-HTTP-Message                                   noarch                        6.06-6.el7                                   base                         82 k
 perl-HTTP-Negotiate                                 noarch                        6.01-5.el7                                   base                         17 k
 perl-IO-HTML                                        noarch                        1.00-2.el7                                   base                         23 k
 perl-IPC-Cmd                                        noarch                        1:0.80-4.el7                                 base                         34 k
 perl-JSON-PP                                        noarch                        2.27202-2.el7                                base                         55 k
 perl-LWP-MediaTypes                                 noarch                        6.02-2.el7                                   base                         24 k
 perl-Locale-Maketext                                noarch                        1.23-3.el7                                   base                         93 k
 perl-Locale-Maketext-Simple                         noarch                        1:0.21-294.el7_6                             base                         50 k
 perl-Log-Message                                    noarch                        1:0.08-3.el7                                 base                         29 k
 perl-Log-Message-Simple                             noarch                        0.10-2.el7                                   base                         11 k
 perl-Module-Build                                   noarch                        2:0.40.05-2.el7                              base                        281 k
 perl-Module-CoreList                                noarch                        1:2.76.02-294.el7_6                          base                         86 k
 perl-Module-Load                                    noarch                        1:0.24-3.el7                                 base                         11 k
 perl-Module-Load-Conditional                        noarch                        0.54-3.el7                                   base                         18 k
 perl-Module-Loaded                                  noarch                        1:0.08-294.el7_6                             base                         46 k
 perl-Module-Metadata                                noarch                        1.000018-2.el7                               base                         26 k
 perl-Module-Pluggable                               noarch                        1:4.8-3.el7                                  base                         29 k
 perl-Module-ScanDeps                                noarch                        1.10-3.el7                                   base                         45 k
 perl-Module-Signature                               noarch                        0.73-2.el7                                   base                         68 k
 perl-Net-HTTP                                       noarch                        6.06-2.el7                                   base                         29 k
 perl-Object-Accessor                                noarch                        1:0.42-294.el7_6                             base                         56 k
 perl-PAR-Dist                                       noarch                        0.49-2.el7                                   base                         31 k
 perl-Package-Constants                              noarch                        1:0.02-294.el7_6                             base                         46 k
 perl-Params-Check                                   noarch                        1:0.38-2.el7                                 base                         18 k
 perl-Parse-CPAN-Meta                                noarch                        1:1.4404-5.el7                               base                         14 k
 perl-Perl-OSType                                    noarch                        1.003-3.el7                                  base                         20 k
 perl-Term-UI                                        noarch                        0.36-2.el7                                   base                         22 k
 perl-Test-Harness                                   noarch                        3.28-3.el7                                   base                        302 k
 perl-Text-Diff                                      noarch                        1.41-5.el7                                   base                         40 k
 perl-URI                                            noarch                        1.60-9.el7                                   base                        106 k
 perl-WWW-RobotRules                                 noarch                        6.02-5.el7                                   base                         18 k
 perl-YAML-Tiny                                      noarch                        1.51-6.el7                                   base                         37 k
 perl-libwww-perl                                    noarch                        6.05-2.el7                                   base                        205 k
 perl-local-lib                                      noarch                        1.008010-4.el7                               base                         64 k
 perl-version                                        x86_64                        3:0.99.07-3.el7                              base                         84 k
 pyparsing                                           noarch                        1.5.6-9.el7                                  base                         94 k
 systemtap-sdt-devel                                 x86_64                        4.0-9.el7                                    base                         76 k
Updating for dependencies:
 libdb                                               x86_64                        5.3.21-25.el7                                base                        720 k
 libdb-utils                                         x86_64                        5.3.21-25.el7                                base                        132 k

Transaction Summary
==================================================================================================================================================================
Install  2 Packages (+70 Dependent packages)
Upgrade             (  2 Dependent packages)

Total download size: 7.0 M
Downloading packages:
Delta RPMs disabled because /usr/bin/applydeltarpm not installed.
warning: /var/cache/yum/x86_64/7/base/packages/gdbm-devel-1.10-8.el7.x86_64.rpm: Header V3 RSA/SHA256 Signature, key ID f4a80eb5: NOKEY
Public key for gdbm-devel-1.10-8.el7.x86_64.rpm is not installed
(1/74): gdbm-devel-1.10-8.el7.x86_64.rpm                                                                                                   |  47 kB  00:00:00     
(2/74): libdb-devel-5.3.21-25.el7.x86_64.rpm                                                                                               |  39 kB  00:00:00     
(3/74): libdb-utils-5.3.21-25.el7.x86_64.rpm                                                                                               | 132 kB  00:00:00     
(4/74): mailcap-2.1.41-2.el7.noarch.rpm                                                                                                    |  31 kB  00:00:00     
(5/74): perl-Algorithm-Diff-1.1902-17.el7.noarch.rpm                                                                                       |  47 kB  00:00:00     
(6/74): perl-Archive-Extract-0.68-3.el7.noarch.rpm                                                                                         |  28 kB  00:00:00     
(7/74): perl-Archive-Zip-1.30-11.el7.noarch.rpm                                                                                            | 107 kB  00:00:00     
(8/74): perl-Business-ISBN-2.06-2.el7.noarch.rpm                                                                                           |  25 kB  00:00:00     
(9/74): perl-Business-ISBN-Data-20120719.001-2.el7.noarch.rpm                                                                              |  24 kB  00:00:00     
(10/74): perl-CPAN-1.9800-294.el7_6.noarch.rpm                                                                                             | 293 kB  00:00:00     
(11/74): perl-CPAN-Meta-2.120921-5.el7.noarch.rpm                                                                                          | 113 kB  00:00:00     
(12/74): libdb-5.3.21-25.el7.x86_64.rpm                                                                                                    | 720 kB  00:00:00     
(13/74): perl-CPAN-Meta-Requirements-2.122-7.el7.noarch.rpm                                                                                |  24 kB  00:00:00     
(14/74): perl-CPAN-Meta-YAML-0.008-14.el7.noarch.rpm                                                                                       |  24 kB  00:00:00     
(15/74): perl-DBD-SQLite-1.39-3.el7.x86_64.rpm                                                                                             | 1.3 MB  00:00:00     
(16/74): perl-DBIx-Simple-1.35-7.el7.noarch.rpm                                                                                            |  43 kB  00:00:00     
(17/74): perl-Digest-1.17-245.el7.noarch.rpm                                                                                               |  23 kB  00:00:00     
(18/74): perl-Digest-MD5-2.52-3.el7.x86_64.rpm                                                                                             |  30 kB  00:00:00     
(19/74): perl-Digest-SHA-5.85-4.el7.x86_64.rpm                                                                                             |  58 kB  00:00:00     
(20/74): perl-Digest-SHA1-2.13-9.el7.x86_64.rpm                                                                                            |  50 kB  00:00:00     
(21/74): perl-Encode-Locale-1.03-5.el7.noarch.rpm                                                                                          |  16 kB  00:00:00     
(22/74): perl-ExtUtils-CBuilder-0.28.2.6-294.el7_6.noarch.rpm                                                                              |  68 kB  00:00:00     
(23/74): perl-CPANPLUS-0.91.38-4.el7.noarch.rpm                                                                                            | 307 kB  00:00:00     
(24/74): perl-ExtUtils-Install-1.58-294.el7_6.noarch.rpm                                                                                   |  75 kB  00:00:00     
(25/74): perl-ExtUtils-Manifest-1.61-244.el7.noarch.rpm                                                                                    |  31 kB  00:00:00     
(26/74): perl-ExtUtils-ParseXS-3.18-3.el7.noarch.rpm                                                                                       |  77 kB  00:00:00     
(27/74): perl-File-Fetch-0.42-2.el7.noarch.rpm                                                                                             |  27 kB  00:00:00     
(28/74): perl-File-Listing-6.04-7.el7.noarch.rpm                                                                                           |  13 kB  00:00:00     
(29/74): perl-File-Remove-1.52-6.el7.noarch.rpm                                                                                            |  26 kB  00:00:00     
(30/74): perl-HTML-Parser-3.71-4.el7.x86_64.rpm                                                                                            | 115 kB  00:00:00     
(31/74): perl-HTML-Tagset-3.20-15.el7.noarch.rpm                                                                                           |  18 kB  00:00:00     
(32/74): perl-HTTP-Cookies-6.01-5.el7.noarch.rpm                                                                                           |  26 kB  00:00:00     
(33/74): perl-HTTP-Daemon-6.01-8.el7.noarch.rpm                                                                                            |  21 kB  00:00:00     
(34/74): perl-HTTP-Date-6.02-8.el7.noarch.rpm                                                                                              |  14 kB  00:00:00     
(35/74): perl-HTTP-Message-6.06-6.el7.noarch.rpm                                                                                           |  82 kB  00:00:00     
(36/74): perl-HTTP-Negotiate-6.01-5.el7.noarch.rpm                                                                                         |  17 kB  00:00:00     
(37/74): perl-IO-HTML-1.00-2.el7.noarch.rpm                                                                                                |  23 kB  00:00:00     
(38/74): perl-IPC-Cmd-0.80-4.el7.noarch.rpm                                                                                                |  34 kB  00:00:00     
(39/74): perl-ExtUtils-MakeMaker-6.68-3.el7.noarch.rpm                                                                                     | 275 kB  00:00:00     
(40/74): perl-JSON-PP-2.27202-2.el7.noarch.rpm                                                                                             |  55 kB  00:00:00     
(41/74): perl-LWP-MediaTypes-6.02-2.el7.noarch.rpm                                                                                         |  24 kB  00:00:00     
(42/74): perl-Locale-Maketext-1.23-3.el7.noarch.rpm                                                                                        |  93 kB  00:00:00     
(43/74): perl-Log-Message-0.08-3.el7.noarch.rpm                                                                                            |  29 kB  00:00:00     
(44/74): perl-Locale-Maketext-Simple-0.21-294.el7_6.noarch.rpm                                                                             |  50 kB  00:00:00     
(45/74): perl-Log-Message-Simple-0.10-2.el7.noarch.rpm                                                                                     |  11 kB  00:00:00     
(46/74): perl-Module-CoreList-2.76.02-294.el7_6.noarch.rpm                                                                                 |  86 kB  00:00:00     
(47/74): perl-Module-Build-0.40.05-2.el7.noarch.rpm                                                                                        | 281 kB  00:00:00     
(48/74): perl-Module-Load-0.24-3.el7.noarch.rpm                                                                                            |  11 kB  00:00:00     
(49/74): perl-Module-Load-Conditional-0.54-3.el7.noarch.rpm                                                                                |  18 kB  00:00:00     
(50/74): perl-Module-Loaded-0.08-294.el7_6.noarch.rpm                                                                                      |  46 kB  00:00:00     
(51/74): perl-Module-Metadata-1.000018-2.el7.noarch.rpm                                                                                    |  26 kB  00:00:00     
(52/74): perl-Module-Pluggable-4.8-3.el7.noarch.rpm                                                                                        |  29 kB  00:00:00     
(53/74): perl-Module-ScanDeps-1.10-3.el7.noarch.rpm                                                                                        |  45 kB  00:00:00     
(54/74): perl-Module-Install-1.06-4.el7.noarch.rpm                                                                                         | 185 kB  00:00:00     
(55/74): perl-Net-HTTP-6.06-2.el7.noarch.rpm                                                                                               |  29 kB  00:00:00     
(56/74): perl-Module-Signature-0.73-2.el7.noarch.rpm                                                                                       |  68 kB  00:00:00     
(57/74): perl-PAR-Dist-0.49-2.el7.noarch.rpm                                                                                               |  31 kB  00:00:00     
(58/74): perl-Object-Accessor-0.42-294.el7_6.noarch.rpm                                                                                    |  56 kB  00:00:00     
(59/74): perl-Package-Constants-0.02-294.el7_6.noarch.rpm                                                                                  |  46 kB  00:00:00     
(60/74): perl-Params-Check-0.38-2.el7.noarch.rpm                                                                                           |  18 kB  00:00:00     
(61/74): perl-Perl-OSType-1.003-3.el7.noarch.rpm                                                                                           |  20 kB  00:00:00     
(62/74): perl-Term-UI-0.36-2.el7.noarch.rpm                                                                                                |  22 kB  00:00:00     
(63/74): perl-Test-Harness-3.28-3.el7.noarch.rpm                                                                                           | 302 kB  00:00:00     
(64/74): perl-Text-Diff-1.41-5.el7.noarch.rpm                                                                                              |  40 kB  00:00:00     
(65/74): perl-URI-1.60-9.el7.noarch.rpm                                                                                                    | 106 kB  00:00:00     
(66/74): perl-WWW-RobotRules-6.02-5.el7.noarch.rpm                                                                                         |  18 kB  00:00:00     
(67/74): perl-YAML-Tiny-1.51-6.el7.noarch.rpm                                                                                              |  37 kB  00:00:00     
(68/74): perl-devel-5.16.3-294.el7_6.x86_64.rpm                                                                                            | 453 kB  00:00:00     
(69/74): perl-libwww-perl-6.05-2.el7.noarch.rpm                                                                                            | 205 kB  00:00:00     
(70/74): perl-local-lib-1.008010-4.el7.noarch.rpm                                                                                          |  64 kB  00:00:00     
(71/74): perl-version-0.99.07-3.el7.x86_64.rpm                                                                                             |  84 kB  00:00:00     
(72/74): pyparsing-1.5.6-9.el7.noarch.rpm                                                                                                  |  94 kB  00:00:00     
(73/74): systemtap-sdt-devel-4.0-9.el7.x86_64.rpm                                                                                          |  76 kB  00:00:00     
(74/74): perl-Parse-CPAN-Meta-1.4404-5.el7.noarch.rpm                                                                                      |  14 kB  00:00:00     
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Total                                                                                                                             2.2 MB/s | 7.0 MB  00:00:03     
Retrieving key from http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7
Importing GPG key 0xF4A80EB5:
 Userid     : "CentOS-7 Key (CentOS 7 Official Signing Key) <security@centos.org>"
 Fingerprint: 6341 ab27 53d7 8a78 a7c2 7bb1 24c6 a8a7 f4a8 0eb5
 From       : http://mirrors.aliyun.com/centos/RPM-GPG-KEY-CentOS-7
Running transaction check
Running transaction test
Transaction test succeeded
Running transaction
Warning: RPMDB altered outside of yum.
  Installing : 3:perl-version-0.99.07-3.el7.x86_64                                                                                                           1/76 
  Installing : perl-HTTP-Date-6.02-8.el7.noarch                                                                                                              2/76 
  Installing : perl-ExtUtils-Manifest-1.61-244.el7.noarch                                                                                                    3/76 
  Installing : 1:perl-Module-CoreList-2.76.02-294.el7_6.noarch                                                                                               4/76 
  Installing : 1:perl-Module-Load-0.24-3.el7.noarch                                                                                                          5/76 
  Installing : perl-Module-Metadata-1.000018-2.el7.noarch                                                                                                    6/76 
  Installing : perl-Digest-1.17-245.el7.noarch                                                                                                               7/76 
  Installing : 1:perl-Digest-SHA-5.85-4.el7.x86_64                                                                                                           8/76 
  Updating   : libdb-5.3.21-25.el7.x86_64                                                                                                                    9/76 
  Installing : perl-YAML-Tiny-1.51-6.el7.noarch                                                                                                             10/76 
  Installing : perl-Encode-Locale-1.03-5.el7.noarch                                                                                                         11/76 
  Installing : perl-Test-Harness-3.28-3.el7.noarch                                                                                                          12/76 
  Installing : perl-Perl-OSType-1.003-3.el7.noarch                                                                                                          13/76 
  Installing : perl-CPAN-Meta-YAML-0.008-14.el7.noarch                                                                                                      14/76 
  Installing : libdb-devel-5.3.21-25.el7.x86_64                                                                                                             15/76 
  Installing : perl-Digest-MD5-2.52-3.el7.x86_64                                                                                                            16/76 
  Installing : perl-File-Listing-6.04-7.el7.noarch                                                                                                          17/76 
  Installing : perl-CPAN-Meta-Requirements-2.122-7.el7.noarch                                                                                               18/76 
  Installing : perl-HTML-Tagset-3.20-15.el7.noarch                                                                                                          19/76 
  Installing : perl-File-Remove-1.52-6.el7.noarch                                                                                                           20/76 
  Installing : perl-IO-HTML-1.00-2.el7.noarch                                                                                                               21/76 
  Installing : mailcap-2.1.41-2.el7.noarch                                                                                                                  22/76 
  Installing : perl-LWP-MediaTypes-6.02-2.el7.noarch                                                                                                        23/76 
  Installing : perl-Net-HTTP-6.06-2.el7.noarch                                                                                                              24/76 
  Installing : pyparsing-1.5.6-9.el7.noarch                                                                                                                 25/76 
  Installing : systemtap-sdt-devel-4.0-9.el7.x86_64                                                                                                         26/76 
  Installing : perl-Archive-Zip-1.30-11.el7.noarch                                                                                                          27/76 
  Installing : perl-Digest-SHA1-2.13-9.el7.x86_64                                                                                                           28/76 
  Installing : perl-Business-ISBN-Data-20120719.001-2.el7.noarch                                                                                            29/76 
  Installing : perl-Business-ISBN-2.06-2.el7.noarch                                                                                                         30/76 
  Installing : perl-URI-1.60-9.el7.noarch                                                                                                                   31/76 
  Installing : perl-HTTP-Message-6.06-6.el7.noarch                                                                                                          32/76 
  Installing : perl-HTML-Parser-3.71-4.el7.x86_64                                                                                                           33/76 
  Installing : perl-HTTP-Cookies-6.01-5.el7.noarch                                                                                                          34/76 
  Installing : perl-HTTP-Negotiate-6.01-5.el7.noarch                                                                                                        35/76 
  Installing : perl-HTTP-Daemon-6.01-8.el7.noarch                                                                                                           36/76 
  Installing : perl-WWW-RobotRules-6.02-5.el7.noarch                                                                                                        37/76 
  Installing : perl-libwww-perl-6.05-2.el7.noarch                                                                                                           38/76 
  Installing : perl-JSON-PP-2.27202-2.el7.noarch                                                                                                            39/76 
  Installing : 1:perl-Parse-CPAN-Meta-1.4404-5.el7.noarch                                                                                                   40/76 
  Installing : perl-CPAN-Meta-2.120921-5.el7.noarch                                                                                                         41/76 
  Installing : 1:perl-Module-Loaded-0.08-294.el7_6.noarch                                                                                                   42/76 
  Installing : gdbm-devel-1.10-8.el7.x86_64                                                                                                                 43/76 
  Installing : 1:perl-ExtUtils-ParseXS-3.18-3.el7.noarch                                                                                                    44/76 
  Installing : perl-ExtUtils-MakeMaker-6.68-3.el7.noarch                                                                                                    45/76 
  Installing : perl-ExtUtils-Install-1.58-294.el7_6.noarch                                                                                                  46/76 
  Installing : 4:perl-devel-5.16.3-294.el7_6.x86_64                                                                                                         47/76 
  Installing : perl-Locale-Maketext-1.23-3.el7.noarch                                                                                                       48/76 
  Installing : 1:perl-Locale-Maketext-Simple-0.21-294.el7_6.noarch                                                                                          49/76 
  Installing : 1:perl-Params-Check-0.38-2.el7.noarch                                                                                                        50/76 
  Installing : perl-Module-Load-Conditional-0.54-3.el7.noarch                                                                                               51/76 
  Installing : 1:perl-IPC-Cmd-0.80-4.el7.noarch                                                                                                             52/76 
  Installing : 1:perl-Log-Message-0.08-3.el7.noarch                                                                                                         53/76 
  Installing : 1:perl-Object-Accessor-0.42-294.el7_6.noarch                                                                                                 54/76 
  Installing : perl-DBIx-Simple-1.35-7.el7.noarch                                                                                                           55/76 
  Installing : perl-Log-Message-Simple-0.10-2.el7.noarch                                                                                                    56/76 
  Installing : perl-Term-UI-0.36-2.el7.noarch                                                                                                               57/76 
  Installing : 1:perl-Archive-Extract-0.68-3.el7.noarch                                                                                                     58/76 
  Installing : 1:perl-ExtUtils-CBuilder-0.28.2.6-294.el7_6.noarch                                                                                           59/76 
  Installing : 2:perl-Module-Build-0.40.05-2.el7.noarch                                                                                                     60/76 
  Installing : perl-Module-ScanDeps-1.10-3.el7.noarch                                                                                                       61/76 
  Installing : perl-File-Fetch-0.42-2.el7.noarch                                                                                                            62/76 
  Installing : perl-DBD-SQLite-1.39-3.el7.x86_64                                                                                                            63/76 
  Installing : 1:perl-Module-Pluggable-4.8-3.el7.noarch                                                                                                     64/76 
  Installing : 1:perl-Package-Constants-0.02-294.el7_6.noarch                                                                                               65/76 
  Installing : perl-CPANPLUS-0.91.38-4.el7.noarch                                                                                                           66/76 
  Installing : perl-local-lib-1.008010-4.el7.noarch                                                                                                         67/76 
  Installing : perl-CPAN-1.9800-294.el7_6.noarch                                                                                                            68/76 
  Installing : perl-Algorithm-Diff-1.1902-17.el7.noarch                                                                                                     69/76 
  Installing : perl-Text-Diff-1.41-5.el7.noarch                                                                                                             70/76 
  Installing : perl-PAR-Dist-0.49-2.el7.noarch                                                                                                              71/76 
  Installing : perl-Module-Signature-0.73-2.el7.noarch                                                                                                      72/76 
  Installing : perl-Module-Install-1.06-4.el7.noarch                                                                                                        73/76 
  Updating   : libdb-utils-5.3.21-25.el7.x86_64                                                                                                             74/76 
  Cleanup    : libdb-utils-5.3.21-24.el7.x86_64                                                                                                             75/76 
  Cleanup    : libdb-5.3.21-24.el7.x86_64                                                                                                                   76/76 
  Verifying  : perl-Algorithm-Diff-1.1902-17.el7.noarch                                                                                                      1/76 
  Verifying  : perl-local-lib-1.008010-4.el7.noarch                                                                                                          2/76 
  Verifying  : 1:perl-Params-Check-0.38-2.el7.noarch                                                                                                         3/76 
  Verifying  : 1:perl-Package-Constants-0.02-294.el7_6.noarch                                                                                                4/76 
  Verifying  : 1:perl-Module-Pluggable-4.8-3.el7.noarch                                                                                                      5/76 
  Verifying  : libdb-devel-5.3.21-25.el7.x86_64                                                                                                              6/76 
  Verifying  : systemtap-sdt-devel-4.0-9.el7.x86_64                                                                                                          7/76 
  Verifying  : 1:perl-Object-Accessor-0.42-294.el7_6.noarch                                                                                                  8/76 
  Verifying  : 1:perl-Archive-Extract-0.68-3.el7.noarch                                                                                                      9/76 
  Verifying  : libdb-utils-5.3.21-25.el7.x86_64                                                                                                             10/76 
  Verifying  : perl-ExtUtils-Manifest-1.61-244.el7.noarch                                                                                                   11/76 
  Verifying  : perl-DBD-SQLite-1.39-3.el7.x86_64                                                                                                            12/76 
  Verifying  : perl-Module-ScanDeps-1.10-3.el7.noarch                                                                                                       13/76 
  Verifying  : perl-Locale-Maketext-1.23-3.el7.noarch                                                                                                       14/76 
  Verifying  : 2:perl-Module-Build-0.40.05-2.el7.noarch                                                                                                     15/76 
  Verifying  : gdbm-devel-1.10-8.el7.x86_64                                                                                                                 16/76 
  Verifying  : perl-CPAN-Meta-YAML-0.008-14.el7.noarch                                                                                                      17/76 
  Verifying  : perl-ExtUtils-MakeMaker-6.68-3.el7.noarch                                                                                                    18/76 
  Verifying  : perl-HTML-Parser-3.71-4.el7.x86_64                                                                                                           19/76 
  Verifying  : perl-LWP-MediaTypes-6.02-2.el7.noarch                                                                                                        20/76 
  Verifying  : perl-Perl-OSType-1.003-3.el7.noarch                                                                                                          21/76 
  Verifying  : perl-Module-Load-Conditional-0.54-3.el7.noarch                                                                                               22/76 
  Verifying  : perl-HTTP-Message-6.06-6.el7.noarch                                                                                                          23/76 
  Verifying  : perl-Test-Harness-3.28-3.el7.noarch                                                                                                          24/76 
  Verifying  : perl-Business-ISBN-2.06-2.el7.noarch                                                                                                         25/76 
  Verifying  : 1:perl-Parse-CPAN-Meta-1.4404-5.el7.noarch                                                                                                   26/76 
  Verifying  : perl-HTTP-Date-6.02-8.el7.noarch                                                                                                             27/76 
  Verifying  : perl-WWW-RobotRules-6.02-5.el7.noarch                                                                                                        28/76 
  Verifying  : perl-Text-Diff-1.41-5.el7.noarch                                                                                                             29/76 
  Verifying  : perl-Encode-Locale-1.03-5.el7.noarch                                                                                                         30/76 
  Verifying  : perl-YAML-Tiny-1.51-6.el7.noarch                                                                                                             31/76 
  Verifying  : 1:perl-Module-Loaded-0.08-294.el7_6.noarch                                                                                                   32/76 
  Verifying  : 1:perl-ExtUtils-CBuilder-0.28.2.6-294.el7_6.noarch                                                                                           33/76 
  Verifying  : perl-JSON-PP-2.27202-2.el7.noarch                                                                                                            34/76 
  Verifying  : 3:perl-version-0.99.07-3.el7.x86_64                                                                                                          35/76 
  Verifying  : 1:perl-ExtUtils-ParseXS-3.18-3.el7.noarch                                                                                                    36/76 
  Verifying  : libdb-5.3.21-25.el7.x86_64                                                                                                                   37/76 
  Verifying  : perl-ExtUtils-Install-1.58-294.el7_6.noarch                                                                                                  38/76 
  Verifying  : perl-Business-ISBN-Data-20120719.001-2.el7.noarch                                                                                            39/76 
  Verifying  : perl-Term-UI-0.36-2.el7.noarch                                                                                                               40/76 
  Verifying  : 1:perl-Log-Message-0.08-3.el7.noarch                                                                                                         41/76 
  Verifying  : perl-HTTP-Cookies-6.01-5.el7.noarch                                                                                                          42/76 
  Verifying  : perl-CPAN-1.9800-294.el7_6.noarch                                                                                                            43/76 
  Verifying  : perl-HTTP-Negotiate-6.01-5.el7.noarch                                                                                                        44/76 
  Verifying  : perl-libwww-perl-6.05-2.el7.noarch                                                                                                           45/76 
  Verifying  : perl-HTTP-Daemon-6.01-8.el7.noarch                                                                                                           46/76 
  Verifying  : perl-Digest-1.17-245.el7.noarch                                                                                                              47/76 
  Verifying  : perl-DBIx-Simple-1.35-7.el7.noarch                                                                                                           48/76 
  Verifying  : perl-Module-Signature-0.73-2.el7.noarch                                                                                                      49/76 
  Verifying  : perl-Digest-SHA1-2.13-9.el7.x86_64                                                                                                           50/76 
  Verifying  : perl-Archive-Zip-1.30-11.el7.noarch                                                                                                          51/76 
  Verifying  : 1:perl-IPC-Cmd-0.80-4.el7.noarch                                                                                                             52/76 
  Verifying  : pyparsing-1.5.6-9.el7.noarch                                                                                                                 53/76 
  Verifying  : 1:perl-Module-CoreList-2.76.02-294.el7_6.noarch                                                                                              54/76 
  Verifying  : perl-CPAN-Meta-2.120921-5.el7.noarch                                                                                                         55/76 
  Verifying  : perl-CPANPLUS-0.91.38-4.el7.noarch                                                                                                           56/76 
  Verifying  : perl-PAR-Dist-0.49-2.el7.noarch                                                                                                              57/76 
  Verifying  : perl-Net-HTTP-6.06-2.el7.noarch                                                                                                              58/76 
  Verifying  : 1:perl-Locale-Maketext-Simple-0.21-294.el7_6.noarch                                                                                          59/76 
  Verifying  : 1:perl-Module-Load-0.24-3.el7.noarch                                                                                                         60/76 
  Verifying  : perl-File-Fetch-0.42-2.el7.noarch                                                                                                            61/76 
  Verifying  : 1:perl-Digest-SHA-5.85-4.el7.x86_64                                                                                                          62/76 
  Verifying  : mailcap-2.1.41-2.el7.noarch                                                                                                                  63/76 
  Verifying  : perl-Log-Message-Simple-0.10-2.el7.noarch                                                                                                    64/76 
  Verifying  : perl-CPAN-Meta-Requirements-2.122-7.el7.noarch                                                                                               65/76 
  Verifying  : perl-IO-HTML-1.00-2.el7.noarch                                                                                                               66/76 
  Verifying  : perl-File-Remove-1.52-6.el7.noarch                                                                                                           67/76 
  Verifying  : perl-Module-Install-1.06-4.el7.noarch                                                                                                        68/76 
  Verifying  : 4:perl-devel-5.16.3-294.el7_6.x86_64                                                                                                         69/76 
  Verifying  : perl-HTML-Tagset-3.20-15.el7.noarch                                                                                                          70/76 
  Verifying  : perl-Module-Metadata-1.000018-2.el7.noarch                                                                                                   71/76 
  Verifying  : perl-Digest-MD5-2.52-3.el7.x86_64                                                                                                            72/76 
  Verifying  : perl-URI-1.60-9.el7.noarch                                                                                                                   73/76 
  Verifying  : perl-File-Listing-6.04-7.el7.noarch                                                                                                          74/76 
  Verifying  : libdb-5.3.21-24.el7.x86_64                                                                                                                   75/76 
  Verifying  : libdb-utils-5.3.21-24.el7.x86_64                                                                                                             76/76 

Installed:
  perl-Module-Install.noarch 0:1.06-4.el7                                           perl-devel.x86_64 4:5.16.3-294.el7_6                                          

Dependency Installed:
  gdbm-devel.x86_64 0:1.10-8.el7                    libdb-devel.x86_64 0:5.3.21-25.el7                      mailcap.noarch 0:2.1.41-2.el7                         
  perl-Algorithm-Diff.noarch 0:1.1902-17.el7        perl-Archive-Extract.noarch 1:0.68-3.el7                perl-Archive-Zip.noarch 0:1.30-11.el7                 
  perl-Business-ISBN.noarch 0:2.06-2.el7            perl-Business-ISBN-Data.noarch 0:20120719.001-2.el7     perl-CPAN.noarch 0:1.9800-294.el7_6                   
  perl-CPAN-Meta.noarch 0:2.120921-5.el7            perl-CPAN-Meta-Requirements.noarch 0:2.122-7.el7        perl-CPAN-Meta-YAML.noarch 0:0.008-14.el7             
  perl-CPANPLUS.noarch 0:0.91.38-4.el7              perl-DBD-SQLite.x86_64 0:1.39-3.el7                     perl-DBIx-Simple.noarch 0:1.35-7.el7                  
  perl-Digest.noarch 0:1.17-245.el7                 perl-Digest-MD5.x86_64 0:2.52-3.el7                     perl-Digest-SHA.x86_64 1:5.85-4.el7                   
  perl-Digest-SHA1.x86_64 0:2.13-9.el7              perl-Encode-Locale.noarch 0:1.03-5.el7                  perl-ExtUtils-CBuilder.noarch 1:0.28.2.6-294.el7_6    
  perl-ExtUtils-Install.noarch 0:1.58-294.el7_6     perl-ExtUtils-MakeMaker.noarch 0:6.68-3.el7             perl-ExtUtils-Manifest.noarch 0:1.61-244.el7          
  perl-ExtUtils-ParseXS.noarch 1:3.18-3.el7         perl-File-Fetch.noarch 0:0.42-2.el7                     perl-File-Listing.noarch 0:6.04-7.el7                 
  perl-File-Remove.noarch 0:1.52-6.el7              perl-HTML-Parser.x86_64 0:3.71-4.el7                    perl-HTML-Tagset.noarch 0:3.20-15.el7                 
  perl-HTTP-Cookies.noarch 0:6.01-5.el7             perl-HTTP-Daemon.noarch 0:6.01-8.el7                    perl-HTTP-Date.noarch 0:6.02-8.el7                    
  perl-HTTP-Message.noarch 0:6.06-6.el7             perl-HTTP-Negotiate.noarch 0:6.01-5.el7                 perl-IO-HTML.noarch 0:1.00-2.el7                      
  perl-IPC-Cmd.noarch 1:0.80-4.el7                  perl-JSON-PP.noarch 0:2.27202-2.el7                     perl-LWP-MediaTypes.noarch 0:6.02-2.el7               
  perl-Locale-Maketext.noarch 0:1.23-3.el7          perl-Locale-Maketext-Simple.noarch 1:0.21-294.el7_6     perl-Log-Message.noarch 1:0.08-3.el7                  
  perl-Log-Message-Simple.noarch 0:0.10-2.el7       perl-Module-Build.noarch 2:0.40.05-2.el7                perl-Module-CoreList.noarch 1:2.76.02-294.el7_6       
  perl-Module-Load.noarch 1:0.24-3.el7              perl-Module-Load-Conditional.noarch 0:0.54-3.el7        perl-Module-Loaded.noarch 1:0.08-294.el7_6            
  perl-Module-Metadata.noarch 0:1.000018-2.el7      perl-Module-Pluggable.noarch 1:4.8-3.el7                perl-Module-ScanDeps.noarch 0:1.10-3.el7              
  perl-Module-Signature.noarch 0:0.73-2.el7         perl-Net-HTTP.noarch 0:6.06-2.el7                       perl-Object-Accessor.noarch 1:0.42-294.el7_6          
  perl-PAR-Dist.noarch 0:0.49-2.el7                 perl-Package-Constants.noarch 1:0.02-294.el7_6          perl-Params-Check.noarch 1:0.38-2.el7                 
  perl-Parse-CPAN-Meta.noarch 1:1.4404-5.el7        perl-Perl-OSType.noarch 0:1.003-3.el7                   perl-Term-UI.noarch 0:0.36-2.el7                      
  perl-Test-Harness.noarch 0:3.28-3.el7             perl-Text-Diff.noarch 0:1.41-5.el7                      perl-URI.noarch 0:1.60-9.el7                          
  perl-WWW-RobotRules.noarch 0:6.02-5.el7           perl-YAML-Tiny.noarch 0:1.51-6.el7                      perl-libwww-perl.noarch 0:6.05-2.el7                  
  perl-local-lib.noarch 0:1.008010-4.el7            perl-version.x86_64 3:0.99.07-3.el7                     pyparsing.noarch 0:1.5.6-9.el7                        
  systemtap-sdt-devel.x86_64 0:4.0-9.el7           

Dependency Updated:
  libdb.x86_64 0:5.3.21-25.el7                                                 libdb-utils.x86_64 0:5.3.21-25.el7                                                

Complete!
[root@ecs-ub

