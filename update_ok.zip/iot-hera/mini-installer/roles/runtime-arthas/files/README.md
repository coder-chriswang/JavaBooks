## jdk安装包制作说明
1. 官网下载：xxx

---
  - name: 拷贝并解压JDK安装包
    unarchive: src={{ANSIBLE_ETC}}/roles/jdk/files/jdk.tar.gz dest={{RUNTIME_HOME}} owner={{MAXUSER}} group={{MAXGROUP}}
    tags: install
  - name: 设置JAVA环境变量
    lineinfile: dest=/etc/profile insertafter="{{item.position}}" line="{{item.value}}" state=present
    with_items:
    - {position: EOF, value: "export JAVA_HOME={{RUNTIME_HOME}}/jdk"}
    - {position: EOF, value: "export PATH=$JAVA_HOME/bin:$PATH"}
    tags: install
  - name: JAVA环境变量生效
    shell: 'source /etc/profile'
    tags: install
  - name: 增加JDK执行权限
    file: dest={{RUNTIME_HOME}}/jdk/bin mode=0755 recurse=yes
    tags: install
  - name: 删除JDK程序目录
    file: path={{RUNTIME_HOME}}/jdk state=absent
    tags: uninstall
  - name: 清除环境变量
    lineinfile: dest=/etc/profile regexp='JAVA_HOME=.*{{RUNTIME_HOME}}.*'  state=absent
    tags: uninstall
  - name: 清除环境变量
    lineinfile: dest=/etc/profile regexp='PATH=.*JAVA_HOME/bin.*'  state=absent
    tags: uninstall
  - name: JAVA环境变量生效
    shell: source /etc/profile
    tags: uninstall


