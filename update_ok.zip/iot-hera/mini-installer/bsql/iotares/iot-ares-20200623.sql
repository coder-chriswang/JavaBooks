CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ares` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `ares`;

-- ----------------------------
-- ares-产品域表
-- ----------------------------
DROP TABLE IF EXISTS `ARES_NS`;
CREATE TABLE `ARES_NS`  (
  `id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品表标识',
  `name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品名称',
  `desc` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品描述',
  `vendor` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品提供商',
  `vendor_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品提供商名称',
  `host` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品库IP',
  `port` int(5) DEFAULT NULL COMMENT '产品库端口',
  `user` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品库账号',
  `pwd` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品密码',
  `update_ts` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- ares-国际化词条表
-- ----------------------------
DROP TABLE IF EXISTS `ARES_I18N`;
CREATE TABLE `DM_NS`  (
  `ns` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品标识',
  `lan` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '语言类型',
  `k` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '词条K',
  `v` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '词条V',
  `update_ts` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`ns`,`lan`,`k`) USING BTREE,
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_mpkg_file
-- ----------------------------
DROP TABLE IF EXISTS `tbl_mpkg_file`;
CREATE TABLE `tbl_mpkg_file`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `ns` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'nameSpace',
  `file_type` tinyint(2) DEFAULT NULL COMMENT '文件类型（1：zip）',
  `store_type` tinyint(2) DEFAULT NULL COMMENT '存储类型（1：fdfs，2：direct）',
  `file_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '文件名称',
  `file_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '存放路径',
  `upload_user_id` varbinary(32) DEFAULT NULL COMMENT '上传用户id',
  `file_status` tinyint(2) DEFAULT NULL COMMENT '文件状态（1：加载使用中，2：已卸载）',
  `create_time` datetime(0) DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ns`(`ns`) USING BTREE COMMENT 'nameSpace',
  INDEX `fileName`(`file_name`) USING BTREE COMMENT '文件名称',
  INDEX `fileStatus`(`file_status`) USING BTREE COMMENT '文件状态'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;



