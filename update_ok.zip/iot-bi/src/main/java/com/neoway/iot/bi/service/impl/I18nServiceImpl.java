package com.neoway.iot.bi.service.impl;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.neoway.iot.bi.client.IotManagerApiClient;
import com.neoway.iot.bi.exception.ApiClientException;
import com.neoway.iot.bi.service.II18nService;
import com.neoway.iot.bi.util.MessageUtils;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class I18nServiceImpl implements II18nService {
    @Resource
    private IotManagerApiClient iotManagerApiClient;

    private LoadingCache<String, Map<String, String>> i18nBufferMap;

    @PostConstruct
    private void init() {
        CacheLoader<String, Map<String, String>> loader = new CacheLoader<String, Map<String, String>> () {
            @Override
            public Map<String, String> load(String key) throws Exception {
                Map<String, String> langSet = null;
                try {
                    langSet = iotManagerApiClient.requestI18nApi(key);
                } catch (ApiClientException e) {
                    return null;
                }
                if (langSet == null) {
                    return null;
                }
                return langSet;
            }
        };
        i18nBufferMap = CacheBuilder.newBuilder()
                .maximumSize(100)
                .expireAfterWrite(30, TimeUnit.MINUTES)
                .build(loader);

        MessageUtils.setI18nService(this);
    }

    @Override
    public String getMessage(String messageCode, Locale locale) {
        String languageTag = locale.toLanguageTag().replace("-", "_");
        try {
            String c = i18nBufferMap.get(languageTag).get(messageCode);
            if (c == null) {
                return messageCode;
            }
            return c;
        } catch (Exception e) {
            return messageCode;
        }
    }

    @Override
    public void clear() {
        i18nBufferMap.invalidateAll();
    }
}
