package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.db.DataSourceType;
import com.neoway.iot.bi.exception.BiMysqlServiceException;
import org.apache.commons.dbutils.QueryRunner;

import java.util.Map;

public interface IBiMysqlService {
    QueryRunner getQueryRunner(DataSourceType type) throws BiMysqlServiceException;
    Map<String, Object> executeQuery(DataSourceType type, String sql) throws BiMysqlServiceException;
}
