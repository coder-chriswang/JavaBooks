package com.neoway.iot.bi.api;

import com.google.gson.Gson;
import com.neoway.iot.bi.HttpResult;
import com.neoway.iot.bi.client.IotManagerApiClient;
import com.neoway.iot.bi.domain.BiChart;
import com.neoway.iot.bi.domain.chart.Chart;
import com.neoway.iot.bi.exception.ApiClientException;
import com.neoway.iot.bi.model.chart.QueryChartListParam;
import com.neoway.iot.bi.service.IChartService;
import com.neoway.iot.bi.util.BiPageModel;
import com.neoway.iot.bi.util.MessageUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @desc: BIController
 * @author: 20200312686
 * @date: 2020/8/4 13:22
 */
@RestController
@RequestMapping("/v1/chart")
@Api(tags = "bi",description = "数据统计Chart接口")
public class BiChartController {
    private static final Logger LOG = LoggerFactory.getLogger(BiChartController.class);

    @Resource
    private IChartService chartService;

    @Resource
    private IotManagerApiClient iotManagerApiClient;

    @ApiOperation("chart列表查询")
    @PostMapping("list")
    public HttpResult<BiPageModel<Chart>> queryCharts(@RequestBody QueryChartListParam param) {
        try{
            BiPageModel<Chart> r = chartService.queryPageList(param);
            return HttpResult.returnSuccess(r);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail("查询失败：" + e.getMessage());
        }
    }

    @ApiOperation("获取chart详情和数据")
    @GetMapping("data")
    public HttpResult<BiChart> queryChartData(@RequestParam("chartid") String chartid) {
        LOG.info(MessageUtils.getMessage("biChart"));
        try{
            BiChart c = chartService.getChartDetail(chartid);
            return HttpResult.returnSuccess(c);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail("查询失败：" + e.getMessage());
        }
    }
}
