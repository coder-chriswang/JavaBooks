package com.neoway.iot.bi.common.db;

public enum DataSourceType {
    IOT_BI("IOT_BI", "BI报表"),
    IOT_DMP("IOT_DMP", "设备接入网关"),
    IOT_DATA("IOT_DATA", "设备数据");

    private String status;
    private String desc;

    DataSourceType(String code, String msg) {
        this.status = code;
        this.desc=msg;
    }

    public String getStatus() {
        return status;
    }

    public String getDesc() {
        return desc;
    }
}
