package com.neoway.iot.bi.service;

import com.neoway.iot.bi.domain.BiChart;
import com.neoway.iot.bi.domain.chart.Chart;
import com.neoway.iot.bi.exception.ChartServiceException;
import com.neoway.iot.bi.model.chart.QueryChartListParam;
import com.neoway.iot.bi.util.BiPageModel;

public interface IChartService {
    BiPageModel<Chart> queryPageList(QueryChartListParam param) throws ChartServiceException;
    BiChart getChartDetail(String chartId) throws ChartServiceException;
}
