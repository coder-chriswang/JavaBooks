package com.neoway.iot.bi.dao.chart;

import com.neoway.iot.bi.domain.chart.Chart;
import com.neoway.iot.bi.model.chart.QueryChartListParam;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IChartDao {
    Chart queryByKey(@Param("chartid") String chartid);
    Integer insertSelective(@Param("chart") Chart chart);
    Integer updateSelective(@Param("chart") Chart chart);
    Integer deleteByKey(@Param("chartid") String chartid);

    List<Chart> queryList(@Param("param") QueryChartListParam param);
    Integer queryCount(@Param("param") QueryChartListParam param);
}