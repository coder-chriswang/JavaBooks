package com.neoway.iot.bi;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.List;

/**
 * @desc: Swagger2Config
 * @author: 20200312686
 * @date: 2020/7/8 12:57
 */
@Configuration
@EnableSwagger2
public class Swagger2Config {
    @Bean
    public Docket createRestApi() {
        ParameterBuilder langHeader = new ParameterBuilder();
        List<Parameter> pars = new ArrayList<>();
        langHeader.name("language").description("语言选择，默认或者 zh_CN 是中文，en_US 是英文")
                .modelRef(new ModelRef("string")).parameterType("header").defaultValue("zh_CN")
                // header中的lang参数非必填，传空也可以
                .required(false).build();
        pars.add(langHeader.build());

        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.neoway.iot.bi.api"))
                .paths(PathSelectors.any())
                .build()
                .globalOperationParameters(pars);
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Ares-统计管理-1.0 API文档")
                .version("1.0")
                .build();
    }
}
