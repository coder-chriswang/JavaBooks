package com.neoway.iot.gwm.meta;

import com.neoway.iot.gwm.common.GwmEnv;
import com.neoway.iot.sdk.dmk.DMRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileFilter;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: 产品域模型管理
 * @author: 20200312686
 * @date: 2020/8/28 15:35
 */
public class MetaManager {
    private static final Logger LOG = LoggerFactory.getLogger(MetaManager.class);
    private static MetaManager manager=null;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private DMRunner runner;
    private MetaManager() {
        this.runner = DMRunner.getInstance();
    }
    public static MetaManager getInstance() {
        if (manager == null) {
            synchronized (MetaManager.class) {
                if (manager == null) {
                    manager = new MetaManager();
                }
            }
        }
        return manager;
    }

    /**
     * 启动
     */
    public void start(){
        if(isStarted.get()){
            return;
        }
        initModelsDomain();
        initModelsAdapter();
    }

    /**
     * 产品模型包初始化
     * @return
     */
    public void initModelsDomain(){
        LOG.info("开始进行产品模型包初始化");
        try{
            String modelPath=GwmEnv.getInstance().getEnv("models.domain");
            File f=new File(modelPath);
            if(!f.exists()){
                return;
            }
            File[] nsFiles=f.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    return pathname.isDirectory();
                }
            });
            for(File nsFile:nsFiles){
                this.runner.addMetaNs(nsFile.getAbsolutePath());
            }
            for(File nsFile:nsFiles){
                this.runner.addTemplateMapping(nsFile.getAbsolutePath());
            }
        }finally {
            LOG.info("结束进行产品模型包初始化");
        }
    }
    /**
     * 数据源模型包初始化
     * @return
     */
    public void initModelsAdapter(){
        LOG.info("开始进行数据源适配模型包初始化");
        try{
            String modelPath=GwmEnv.getInstance().getEnv("models.adapter");
            File f=new File(modelPath);
            if(!f.exists()){
                return;
            }
            File[] dsFiles=f.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    return pathname.isDirectory();
                }
            });
            for(File dsFile:dsFiles){
                this.runner.addTemplateDs(dsFile.getAbsolutePath());
            }
        }finally {
            LOG.info("结束进行数据源适配模型包初始化");
        }


    }
}
