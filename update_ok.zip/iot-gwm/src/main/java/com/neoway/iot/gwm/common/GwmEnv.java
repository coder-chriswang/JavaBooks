package com.neoway.iot.gwm.common;

import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.data.DMCache;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: GWM环境变量管理注册
 * @author: 20200312686
 * @date: 2020/8/28 16:05
 */
public class GwmEnv {
    private static final String GWM_JDBC_HOST="gwm.jdbc.host";
    private static final String GWM_JDBC_PORT="gwm.jdbc.port";
    private static final String GWM_JDBC_DB="gwm.jdbc.db";
    private static final String GWM_JDBC_MAX_CONN="gwm.jdbc.max_conn";
    private static final String GWM_JDBC_MIN_CONN="gwm.jdbc.min_conn";
    private static final String GWM_JDBC_USER="gwm.jdbc.user";
    private static final String GWM_JDBC_PWD="gwm.jdbc.pwd";
    private static final String GWM_JDBC_CONN_TIMEOUT="gwm.jdbc.conn_timeout";
    private static final String GWM_JDBC_IDEL_TIMEOUT="gwm.jdbc.idel_timeout";
    private static final String GWM_DATA_CACHE="gwm.data.cache";
    private static GwmEnv manager=null;
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private Environment env;

    private GwmEnv(){
    }
    public void start(Environment env){
        this.env=env;
        if (isStarted.get()) {
            return;
        }
        DMRunner runner = DMRunner.getInstance();
        Map<String,Object> pro=new HashMap<>();
        pro.put(DMPool.JDBC_HOST,env.getProperty(GWM_JDBC_HOST));
        pro.put(DMPool.JDBC_PORT,env.getProperty(GWM_JDBC_PORT));
        pro.put(DMPool.JDBC_DB,env.getProperty(GWM_JDBC_DB));
        pro.put(DMPool.JDBC_MAX_CONN,env.getProperty(GWM_JDBC_MAX_CONN));
        pro.put(DMPool.JDBC_MIN_CONN,env.getProperty(GWM_JDBC_MIN_CONN));
        pro.put(DMPool.JDBC_USER,env.getProperty(GWM_JDBC_USER));
        pro.put(DMPool.JDBC_PWD,env.getProperty(GWM_JDBC_PWD));
        pro.put(DMPool.JDBC_CONN_TIMEOUT,env.getProperty(GWM_JDBC_CONN_TIMEOUT));
        pro.put(DMPool.JDBC_IDEL_TIMEOUT,env.getProperty(GWM_JDBC_IDEL_TIMEOUT));
        pro.put(DMCache.CACHE_KEY,env.getProperty(GWM_DATA_CACHE));
        runner.start(pro);
        isStarted.set(true);
    }
    public static GwmEnv getInstance() {
        if (manager == null) {
            synchronized (GwmEnv.class) {
                if (manager == null) {
                    manager = new GwmEnv();
                }
            }
        }
        return manager;
    }

    public String getEnv(String envKey){
        return this.env.getProperty(envKey);
    }
}
