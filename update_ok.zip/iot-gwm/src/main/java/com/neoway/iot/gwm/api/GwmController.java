package com.neoway.iot.gwm.api;

import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.handler.MetaHandler;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @desc: MetaController
 * @author: 20200312686
 * @date: 2020/7/21 10:56
 */
@RestController
@RequestMapping("/v1/meta")
@Api(tags = "元数据")
public class GwmController {
    private static final Logger LOG = LoggerFactory.getLogger(GwmController.class);
    private MetaHandler handler=new MetaHandler();

    @ApiOperation("查询系统中CI元数据")
    @GetMapping("/ci")
    public HttpResult<List<DMMetaCI>> queryCI() {
        try {
            return HttpResult.returnSuccess("查询成功！", handler.queryMetaCI());
        } catch (Exception e){
            LOG.error("查询失败！", e);
            return HttpResult.returnFail("查询失败！");
        }

    }

    @ApiOperation("查询CI元数据")
    @GetMapping("/{ns}/{category}/{ci}")
    public HttpResult<DMMetaCI> getMeta(@PathVariable("ns") String ns,
                                        @PathVariable("category") String category,
                                        @PathVariable("ci") String ci,
                                        @RequestParam("tag") String tag) {
        try {
            return HttpResult.returnSuccess("查询成功！", handler.getMetaCI(ns,category,ci,tag));
        } catch (Exception e) {
            LOG.error("查询失败！", e);
            return HttpResult.returnFail("查询失败！");
        }
    }
}
