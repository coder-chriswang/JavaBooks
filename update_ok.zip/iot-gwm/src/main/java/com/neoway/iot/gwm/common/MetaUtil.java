package com.neoway.iot.gwm.common;

/**
 * @desc: MetaUtil
 * @author: 20200312686
 * @date: 2020/8/18 12:33
 */
public class MetaUtil {
}
