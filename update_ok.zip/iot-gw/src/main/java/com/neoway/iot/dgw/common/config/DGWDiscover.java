package com.neoway.iot.dgw.common.config;

import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: 模型包自动发现
 * @author: 20200312686
 * @date: 2020/6/23 11:34
 */
public class DGWDiscover {
    private static final Logger LOG = LoggerFactory.getLogger(DGWDiscover.class);
    public static final String MQTT_URI="dgw.discover.mqtt.uri";
    public static final String MQTT_CLIENTID="dgw.discover.mqtt.client_id";
    public static final String MQTT_USER="dgw.discover.mqtt.user";
    public static final String MQTT_PWD="dgw.discover.mqtt.pwd";
    public static final String MQTT_RECONNECT="dgw.discover.mqtt.reconnect";
    public static final String MQTT_KEEPALIVED="dgw.discover.mqtt.keepalived";
    public static final String MQTT_CONNTIMEOUT="dgw.discover.mqtt.conn_timeout";
    public static final String MQTT_TOPIC_MODEL_SUBCRIBE="dgw.discover.mqtt.topic.subcribe";

    private static DGWDiscover discover = null;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private DGWConfig env=null;
    private String serviceURI;
    private String clientId;
    private String username;
    private String password;
    private boolean isReconnect=true;
    private int keepAlivedInternal=10;
    private int connTimeout=5;
    private String mqttTopic;
    private MqttConnectOptions options;
    private MqttClient client;
    private DGWDiscover() {
        this.env= DGWConfig.getInstance();
    }
    public static DGWDiscover getInstance() {
        if (discover == null) {
            synchronized (DGWDiscover.class) {
                if (discover == null) {
                    discover = new DGWDiscover();
                }
            }
        }
        return discover;
    }

    /**
     * @desc DGWDiscover 启动
     * @throws MqttException
     */
    public synchronized void start() throws MqttException{
        if(isStarted.get()){
            return;
        }
        LOG.info("DGWDiscover开始启动");
        this.setServiceURI(env.getValue(MQTT_URI).toString());
        this.setClientId(env.getValue(MQTT_CLIENTID).toString());
        this.setKeepAlivedInternal(env.getValue(MQTT_KEEPALIVED).toString());
        this.setConnTimeout(env.getValue(MQTT_CONNTIMEOUT).toString());
        this.setMqttTopic(env.getValue(MQTT_TOPIC_MODEL_SUBCRIBE).toString());
        this.setReconnect(env.getValue(MQTT_RECONNECT).toString());
        this.setUsername(env.getValue(MQTT_USER).toString());
        this.setPassword(env.getValue(MQTT_PWD).toString());
        client=new MqttClient(this.getServiceURI(),this.getClientId(),new MemoryPersistence());
        options=new MqttConnectOptions();
        options.setCleanSession(true);
        options.setUserName(this.getUsername());
        options.setPassword(this.getPassword().toCharArray());
        options.setConnectionTimeout(10);
        options.setKeepAliveInterval(this.getKeepAlivedInternal());
        options.setAutomaticReconnect(this.isReconnect());
        client.connect(options);
        client.subscribe(this.getMqttTopic());
        client.setCallback(new DGWMqttCallback(this.client,this.getMqttTopic()));
        isStarted.set(true);
        LOG.info("DGWDiscover启动成功");
    }

    /**
     * @desc: MQTTClient回调
     */
    private class DGWMqttCallback implements MqttCallbackExtended{
        private MqttClient mclient;
        private String topic;
        public DGWMqttCallback(MqttClient client,String topic){
            this.mclient=client;
            this.topic=topic;
        }
        @Override
        public void connectComplete(boolean b, String s) {
            LOG.info("连接完成");
            try{
                mclient.subscribe(this.topic);
                LOG.info("订阅成功");
            }catch (Exception e){
                LOG.error(e.getMessage(),e);
            }
        }
        @Override
        public void connectionLost(Throwable throwable) {
            LOG.warn("失去连接");
        }
        @Override
        public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
            String data=new String(mqttMessage.getPayload());
            LOG.info("模型包事件通知：{}",data);
            Map req=(Map) new Gson().fromJson(data,Map.class);
            String ns=String.valueOf(req.get("ns"));
            String fcode=String.valueOf(req.get("fcode"));
            String status=String.valueOf(req.get("action"));
            if(ModelStatus.REGISTER.getStatus().equals(status)){
                downModel(ns,fcode);
                //TODO 通知input 加载模型包
            }else if(ModelStatus.UNREGISTER.getStatus().equals(status)){
                removeModel(ns,fcode);
                //TODO 通知input移除模型包
            }else{
                LOG.error("模型包事件状态非法");
            }
        }
        @Override
        public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            LOG.debug("传送成功");
        }
    }

    private enum ModelStatus{
        REGISTER("register","注册"),
        UNREGISTER("unregister","去注册");
        private String status;
        private String desc;

        ModelStatus(String code, String msg) {
            this.status = code;
            this.desc=msg;
        }

        public String getStatus() {
            return status;
        }

        public String getDesc() {
            return desc;
        }
    }

    /**
     * @desc 下载并解压模型包到本地
     * @param ns
     * @param fcode
     */
    public void downModel(String ns,String fcode){
        //TODO 下载模型包
    }
    /**
     * @desc 删除模型包
     * @param ns
     * @param fcode
     */
    public void removeModel(String ns,String fcode){
        //删除指定模型包
    }

    public String getServiceURI() {
        return serviceURI;
    }

    public void setServiceURI(String serviceURI) {
        this.serviceURI = serviceURI;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId+UUID.randomUUID().toString();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isReconnect() {
        return isReconnect;
    }

    public void setReconnect(String reconnect) {
        if(StringUtils.isNotEmpty(reconnect)){
            isReconnect = Boolean.valueOf(reconnect);
        }

    }

    public int getKeepAlivedInternal() {
        return keepAlivedInternal;
    }

    public void setKeepAlivedInternal(String keepAlivedInternal) {
        if(StringUtils.isNotEmpty(keepAlivedInternal)){
            this.keepAlivedInternal = Integer.valueOf(keepAlivedInternal);
        }

    }

    public String getMqttTopic() {
        return mqttTopic;
    }

    public void setMqttTopic(String mqttTopic) {
        this.mqttTopic = mqttTopic;
    }

    public int getConnTimeout() {
        return connTimeout;
    }

    public void setConnTimeout(String connTimeout) {
        if(StringUtils.isNotEmpty(connTimeout)){
            this.connTimeout = Integer.valueOf(connTimeout);
        }

    }
}
