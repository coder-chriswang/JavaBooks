package com.neoway.iot.dgw.output.iotfm;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.DGWCmd;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWHeader;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.output.AbstractOutput;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotfm.handler.FmCmdHandler;
import com.neoway.iot.dgw.output.iotfm.storage.FMDMysqlSink;
import com.neoway.iot.dgw.output.iotfm.storage.FMDPoint;
import com.neoway.iot.dgw.output.iotfm.storage.FMDSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: FmOutput
 * @author: Chris(wangchao)
 * @date: 2020/7/9 14:41
 */
public class FmOutput extends AbstractOutput {

    private static final Logger LOG = LoggerFactory.getLogger(FmOutput.class);
    private static final String BACKEND = "dgw.output.fm.backend";
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private FMDSink sink;

    @Override
    public String name() {
        return "output-plugin-fm";
    }

    @Override
    public List<String> getTopics() {
        return Arrays.asList(DGWCmd.UPLINK_FM_DATA.name(),
                DGWCmd.UPLINK_FM_META.name(),
                DGWCmd.MSG_FM.name());
    }

    @Override
    public void start(DGWConfig config) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        String backend = String.valueOf(config.getValue(BACKEND));
        if (FMDSink.BACKEND_MYSQL.equals(backend)) {
            sink = new FMDMysqlSink();
        } else {
            sink = new FMDMysqlSink();
        }
        sink.start(config);
        super.start(config);
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public DGWResponse doProcess(OutputEvent event) throws DGWException {
        String topic = event.getHeader().getTopic();
        FmCmdHandler handler;
        if (DGWCmd.MSG_FM.name().equals(topic)) {
            DGWHeader head = event.getHeader();
            handler = FmCmdFactory.buildHandler(head.getCmdId(),this.sink);
        } else {
            handler = FmCmdFactory.buildHandler(topic, this.sink);
        }
        DGWResponse rsp = new DGWResponse();
        if(null == handler){
            LOG.warn("Topic非法：topic={}",topic);
            return rsp;
        }
        return handler.execute(event);
    }
}
