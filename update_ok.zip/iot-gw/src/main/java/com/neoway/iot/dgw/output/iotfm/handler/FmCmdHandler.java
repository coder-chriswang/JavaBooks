package com.neoway.iot.dgw.output.iotfm.handler;

import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;

/**
 * <pre>
 *  描述: FmCmdHandler
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 16:40
 */
public interface FmCmdHandler {
    /**
     * @desc
     * @return cmd指令名称
     */
    String name();

    /**
     * @desc 指令处理
     * @param event 数据
     * @return
     */
    DGWResponse execute(OutputEvent event);
}
