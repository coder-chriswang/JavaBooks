package com.neoway.iot.dgw;

import com.neoway.iot.dgw.channel.ChannelManager;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.config.DGWDiscover;
import com.neoway.iot.dgw.input.InputManager;
import com.neoway.iot.dgw.output.OutputManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class DGApplication implements CommandLineRunner {
	private static final Logger LOG = LoggerFactory.getLogger(DGApplication.class);
	@Autowired
	private Environment env;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LOG.info("开始启动");
		SpringApplication.run(DGApplication.class, args);
		LOG.info("启动成功");
	}
	@Override
	public void run(String... strings) throws Exception {
		LOG.info("注册配置");
		DGWConfig.getInstance().start(env.getProperty("dgw.config"));
		DGWDiscover.getInstance().start();
		LOG.info("配置注册成功");
		LOG.info("DGW开始初始化");
		DGLifecycleComponent outputComponent= OutputManager.getInstance();
		DGLifecycleComponent channelComponent= ChannelManager.getInstance();
		DGLifecycleComponent inputComponent= InputManager.getInstance();
		outputComponent.start();
		channelComponent.start();
		inputComponent.start();
		LOG.info("DGW初始化成功");
	}
}
