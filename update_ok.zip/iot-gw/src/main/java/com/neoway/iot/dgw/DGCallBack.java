package com.neoway.iot.dgw;

import com.neoway.iot.sdk.dmk.data.DMDataCallBack;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;

/**
 * @desc: DGCallBack
 * @author: 20200312686
 * @date: 2020/9/2 10:19
 */
public class DGCallBack implements DMDataCallBack {
    @Override
    public void callBack(DMDataOper oper, DMDataPoint point) {
        //DM数据变更通知。对于DGW来说只关注DS、DSInstance数据的变更
    }
}
