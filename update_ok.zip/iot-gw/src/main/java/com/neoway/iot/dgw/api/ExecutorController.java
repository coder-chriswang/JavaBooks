package com.neoway.iot.dgw.api;

import com.neoway.iot.dgw.common.DGWRequest;
import com.neoway.iot.dgw.common.DGWResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

/**
 * @desc: 指令执行接口
 * @author: 20200312686
 * @date: 2020/6/23 9:27
 */
@RestController
@RequestMapping("/v1/command")
@Api(tags = "指令执行")
public class ExecutorController {

    @ApiOperation("指令执行-同步")
    @PostMapping("/syn")
    public DGWResponse command(@RequestBody DGWRequest req) {
        //模板执行
        return null;
    }
    @ApiOperation("指令执行-异步")
    @PostMapping("/asyn")
    public DGWResponse asynCommand(@RequestBody DGWRequest req) {
        //模板执行
        return null;
    }
}
