package com.neoway.iot.dgw.input.connector;

import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.input.AbstractInput;
import com.neoway.iot.dgw.input.scheduler.ScheudlerAtoExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public abstract class Connector extends AbstractInput {
    private static final Logger LOG = LoggerFactory.getLogger(Connector.class);
    @Override
    public void start(DGWConfig config) throws DGWException {
        super.start(config);
    }

    @Override
    public void stop() {
        super.stop();
    }

    @Override
    public DGWResponse uplink(DGWRequest req) {
        return ScheudlerAtoExecutor.uplink(req);
    }

    /**
     * 执行
     * @param request
     * @return
     */
    public abstract ConnectorRsp downlink(ConnectorReq request);

}
