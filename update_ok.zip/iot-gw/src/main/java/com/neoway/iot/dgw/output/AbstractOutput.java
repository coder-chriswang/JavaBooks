package com.neoway.iot.dgw.output;

import com.neoway.iot.dgw.common.DGWContext;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;


/**
 * @desc: AbstractOutput
 * @author: 20200312686
 * @date: 2020/6/23 10:02
 */
public abstract class AbstractOutput implements Output {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractOutput.class);
    @Override
    public boolean isEnable() {
        return true;
    }

    @Override
    public void start(DGWConfig config) throws DGWException {
        LOG.info("插件：{} 启动成功", this.name());
    }

    @Override
    public void stop() {
        LOG.info("插件：{} 停止成功", this.name());
    }

    @Override
    public DGWResponse process(OutputEvent event) {
        LOG.info("output插件：{} 接收到数据记录:reqId={},记录数={}",
                this.name(),event.getHeader().getReqId(),event.getEvents().size());
        try {
            DGWResponse response = doProcess(event);
            return response;
        } catch (DGWException e) {
            DGWResponse response=new DGWResponse(e.getCode(),e.getMessage());
            return response;
        }finally {
            LOG.info("output插件：{} 处理数据结束,reqId={}",this.name(),event.getHeader().getReqId());
        }


    }

    public abstract DGWResponse doProcess(OutputEvent event) throws DGWException;

}
