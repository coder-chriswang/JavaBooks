package com.neoway.iot.dgw.output.iotdm.handler;

import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotdm.DmCmd;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: 资源激活
 * @author: 20200312686
 * @date: 2020/7/17 10:20
 */
public class DmCmdHandlerRegister implements DmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DmCmdHandlerRegister.class);
    @Override
    public String name() {
        return DmCmd.CMD_REGISTER.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> values=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(values)){
            return response;
        }
        Map<String,Object> value=values.get(0);
        String ns=event.getHeader().getDsCode();
        //根据资源ID查询热点缓存数据
        String ci=(String)value.get("ci");
        String tenent="";
        if(value.containsKey("tenent")){
            tenent=(String)value.get("tenent");
        }else{
            tenent= DMMetaCI.DEFAULT_TENENT;
        }
        try{
            DMRunner runner=DMRunner.getInstance();
            DMDataPoint point=DMDataPoint.builder(ns,tenent,ci);
            point=point.buildColumns(value);
            point=runner.getHotByPrimary(point);
            //资源不存在，则激活失败
            if(null == point){
                response.setCode("101");
                response.setMsg("资源不存在");
                return response;
            }
            DMDataColumn column=point.getDataColumn("auth_code");
            if(null == column){
                String errMsgTpl="模型中不存在auth_code属性。产品域={0},tenent={1},ci={1}";
                String errMsg=MessageFormat.format(errMsgTpl,ns,tenent,ci);
                LOG.error(errMsg);
                response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
                response.setMsg(errMsg);
                return response;
            }
            //资源存在，判断鉴权码是否存在，不存在则为首次激活，生成鉴权码并存储。否则返回鉴权码
            if(StringUtils.isEmpty(String.valueOf(column.value))){
                //更新激活时间，最后连接时间，在线状态
                column.value=String.valueOf(System.nanoTime());
                runner.write(point);
            }
            Map<String,Object> data=new HashMap<>();
            data.put("auth_code",column.value);
            response.setData(data);
        }catch (RuntimeException e){
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
        }
        return response;

    }
}
