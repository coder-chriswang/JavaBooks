package com.neoway.iot.dgw.output.iotlm;

/**
 * <pre>
 *  描述: LmCmd
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 14:42
 */
public enum LmCmd {
    UPLINK_LM_DATA("上报位置数据");
    private final String desc;

    private LmCmd(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
