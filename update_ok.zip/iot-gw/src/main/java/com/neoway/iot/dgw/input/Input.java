package com.neoway.iot.dgw.input;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWRequest;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;

import java.util.Map;

/**
 * @desc: Input
 * @author: 20200312686
 * @date: 2020/6/23 16:10
 */
public interface Input {
    /**
     * @desc 启动
     * @param config
     */
    void start(DGWConfig config) throws DGWException;

    /**
     * @desc 停止
     */
    void stop();

    /**
     * @desc 是否启用
     * @return
     */
    boolean isEnable();

    /**
     * @desc 获取配置
     * @return
     */
    Map<String,Object> configuration();

    /**
     * @desc 获取插件名称
     * @return 插件名称
     */
    String name();

    /**
     * @desc uplink处理：input->channel->output
     * @param req
     * @return
     */
    DGWResponse uplink(DGWRequest req);

}
