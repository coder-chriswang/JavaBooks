package com.neoway.iot.dgw.common.config;

import com.google.gson.*;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.data.DMCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: DGW运行配置参数
 * @author: 20200312686
 * @date: 2020/6/23 10:08
 */
public class DGWConfig  {
    private static final Logger LOG = LoggerFactory.getLogger(DGWConfig.class);

    private static DGWConfig env=null;
    private Map<String,Object> pro;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private DGWConfig(){
    }
    public static DGWConfig getInstance(){
        if(env == null){
            env=new DGWConfig();
        }
        return env;
    }
    public void start(String etc) throws Exception{
        Yaml dgwYml=new Yaml();
        File f=new File(etc);
        Map<String,Object> result=dgwYml.load(new FileInputStream(f));
        this.pro=result;
        this.startRunner();
        LOG.debug("DGW配置加载：{}", new Gson().toJson(this.pro));
    }
    private void startRunner() {
        if (isStarted.get()) {
            return;
        }
        DMRunner runner = DMRunner.getInstance();
        Map<String,Object> pro=new HashMap<>();
        pro.put(DMPool.JDBC_HOST,this.getValue(DMPool.JDBC_HOST));
        pro.put(DMPool.JDBC_PORT,this.getValue(DMPool.JDBC_PORT));
        pro.put(DMPool.JDBC_DB,this.getValue(DMPool.JDBC_DB));
        pro.put(DMPool.JDBC_MAX_CONN,this.getValue(DMPool.JDBC_MAX_CONN));
        pro.put(DMPool.JDBC_MIN_CONN,this.getValue(DMPool.JDBC_MIN_CONN));
        pro.put(DMPool.JDBC_USER,this.getValue(DMPool.JDBC_USER));
        pro.put(DMPool.JDBC_PWD,this.getValue(DMPool.JDBC_PWD));
        pro.put(DMPool.JDBC_CONN_TIMEOUT,this.getValue(DMPool.JDBC_CONN_TIMEOUT));
        pro.put(DMPool.JDBC_IDEL_TIMEOUT,this.getValue(DMPool.JDBC_IDEL_TIMEOUT));
        pro.put(DMCache.CACHE_KEY,this.getValue(DMCache.CACHE_KEY));
        pro.put(DMCache.CACHE_MAX,this.getValue(DMCache.CACHE_MAX));
        pro.put(DMCache.CACHE_INIT,this.getValue(DMCache.CACHE_INIT));
        runner.start(pro);
        isStarted.set(true);
    }

    public void stop(){
        this.pro.clear();
    }
    public Object getValue(String key){
        return pro.get(key);
    }

    public Map<String, Object> getPro() {
        return pro;
    }
}
