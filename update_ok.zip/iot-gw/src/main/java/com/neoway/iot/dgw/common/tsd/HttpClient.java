package com.neoway.iot.dgw.common.tsd;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: HttpClient
 * @author: 20200312686
 * @date: 2020/6/30 18:16
 */
public class HttpClient {
    private static final Logger LOG = LoggerFactory.getLogger(HttpClient.class);
    private String host;
    private int port;
    /**
     * 通过这个client来完成请求
     */
    private final CloseableHttpAsyncClient client;
    /**
     * 未完成任务数 for graceful close.
     */
    private final AtomicInteger unCompletedTaskNum;
    /**
     * 空闲连接清理服务
     */
    private ScheduledExecutorService connectionGcService;

    HttpClient(TSDConfig config, CloseableHttpAsyncClient client, ScheduledExecutorService connectionGcService) {
        this.host = config.getHost();
        this.port = config.getPort();
        this.client = client;
        this.connectionGcService = connectionGcService;
        this.unCompletedTaskNum = new AtomicInteger(0);
    }
    /***
     * post请求
     * @param path 请求路径
     * @param json json格式参数
     * @return
     */
    public Future<HttpResponse> post(String path, String json) {
        return this.post(path, json, null);
    }

    /***
     * post请求
     * @param path 请求路径
     * @param json 请求内容，json格式z
     * @param httpCallback 回调
     * @return
     */
    public Future<HttpResponse> post(String path, String json, FutureCallback<HttpResponse> httpCallback) {
        LOG.debug("发送post请求，路径:{}，请求内容:{}", path, json);
        HttpPost httpPost = new HttpPost(getUrl(path));
        if (StringUtils.isNoneBlank(json)) {
            httpPost.addHeader("Content-Type", "application/json");
            httpPost.setEntity(generateStringEntity(json));
        }

        FutureCallback<HttpResponse> responseCallback = null;
        if (httpCallback != null) {
            LOG.debug("等待完成的任务数:{}", unCompletedTaskNum.incrementAndGet());
            responseCallback = new TSDCloseCallBack(unCompletedTaskNum, httpCallback);
        }
        return client.execute(httpPost, responseCallback);
    }

    private String getUrl(String path) {
        return host + ":" + port + path;
    }

    private StringEntity generateStringEntity(String json) {
        StringEntity stringEntity = new StringEntity(json, Charset.forName("UTF-8"));
        return stringEntity;
    }

    public void start() {
        this.client.start();
    }

    public void gracefulClose() throws IOException {
        this.close(false);
    }

    public void forceClose() throws IOException {
        this.close(true);
    }

    private void close(boolean force) throws IOException {
        // 关闭等待
        if (!force) {
            // 优雅关闭
            while (client.isRunning()) {
                int i = this.unCompletedTaskNum.get();
                if (i == 0) {
                    break;
                } else {
                    try {
                        // 轮询检查优雅关闭
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        LOG.warn("The thread {} is Interrupted", Thread.currentThread()
                                .getName());
                    }
                }
            }
        }
        connectionGcService.shutdownNow();
        client.close();
    }
}
