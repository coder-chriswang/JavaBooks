package com.neoway.iot.dgw.channel.redis;

import com.google.gson.Gson;
import com.neoway.iot.dgw.channel.AbstractChannel;
import com.neoway.iot.dgw.channel.DGWChannelEvent;
import com.neoway.iot.dgw.common.DGWContext;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.redis.JedisUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @desc: redis-channel
 * @author: 20200312686
 * @date: 2020/7/7 9:27
 */
public class RedisChannel extends AbstractChannel {
    private static final Logger LOG = LoggerFactory.getLogger(RedisChannel.class);
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private static final String CONFIGURATION_DB="dgw.channel.redis.db";
    private static final String CONFIGURATION_HOST="dgw.channel.redis.host";
    private static final String CONFIGURATION_PORT="dgw.channel.redis.port";
    private static final String CONFIGURATION_PWD="dgw.channel.redis.password";
    private static final String CONFIGURATION_TIMEOUT="dgw.channel.redis.timeout";
    private static final String CONFIGURATION_MAX_ACTIVE="dgw.channel.redis.max_active";
    private static final String CONFIGURATION_MAX_WAIT="dgw.channel.redis.max_wait";
    private static final String CONFIGURATION_MAX_IDEL="dgw.channel.redis.max_idel";
    private static final String CONFIGURATION_MIN_IDEL="dgw.channel.redis.min_idel";
    private static final String REDIS_CHANNEL_QUEUE="redisChannelQueue";
    private JedisPool pool;
    private DGWConfig env;
    private Lock lock=new ReentrantLock();
    @Override
    public void start(DGWConfig config){
        if(isStarted.get()){
            return;
        }
        JedisUtil.Builder builder=JedisUtil.builder();
        builder=builder.buildURI((String)config.getValue(CONFIGURATION_HOST),
                String.valueOf(config.getValue(CONFIGURATION_PORT)),
                String.valueOf(config.getValue(CONFIGURATION_TIMEOUT)),
                String.valueOf(config.getValue(CONFIGURATION_PWD)),
                String.valueOf(config.getValue(CONFIGURATION_DB)));
        builder=builder.buildPool(String.valueOf(config.getValue(CONFIGURATION_MAX_ACTIVE)),
                String.valueOf(config.getValue(CONFIGURATION_MAX_WAIT)),
                String.valueOf(config.getValue(CONFIGURATION_MAX_IDEL)),
                String.valueOf(config.getValue(CONFIGURATION_MIN_IDEL)));
        JedisUtil utils=new JedisUtil();
        utils.start(builder);
        this.env=config;
        this.pool=utils.getJedisPool();
        this.isStarted.set(true);
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration=new HashMap<>();
        configuration.put(CONFIGURATION_HOST,env.getValue(CONFIGURATION_HOST));
        configuration.put(CONFIGURATION_PORT,env.getValue(CONFIGURATION_PORT));
        configuration.put(CONFIGURATION_TIMEOUT,env.getValue(CONFIGURATION_TIMEOUT));
        configuration.put(CONFIGURATION_PWD,env.getValue(CONFIGURATION_PWD));
        configuration.put(CONFIGURATION_DB,env.getValue(CONFIGURATION_DB));
        configuration.put(CONFIGURATION_MAX_ACTIVE,env.getValue(CONFIGURATION_MAX_ACTIVE));
        configuration.put(CONFIGURATION_MAX_WAIT,env.getValue(CONFIGURATION_MAX_WAIT));
        configuration.put(CONFIGURATION_MAX_IDEL,env.getValue(CONFIGURATION_MAX_IDEL));
        configuration.put(CONFIGURATION_MIN_IDEL,env.getValue(CONFIGURATION_MIN_IDEL));
        return configuration;
    }

    @Override
    public DGWResponse doProcess(List<DGWChannelEvent> events) {
        try(Jedis jedis = this.pool.getResource()){
            lock.lock();
            for(DGWChannelEvent event : events) {
                String eventInfo = new Gson().toJson(event);
                jedis.lpush(REDIS_CHANNEL_QUEUE, eventInfo);
            }
        } catch (Exception e) {
            LOG.error("RedisChannel doProcess error!", e);
        } finally {
            lock.unlock();
        }
        return new DGWResponse();
    }

    @Override
    public String name() {
        return "channel-redis";
    }

    @Override
    public List<DGWContext> take() throws DGWException {
        List<DGWContext> resultList = new ArrayList<>();
        try(Jedis jedis = this.pool.getResource()) {
            lock.lock();
            // 获取Redis队列中的所有元素
            List<String> redisChannelQueueList = jedis.lrange(REDIS_CHANNEL_QUEUE,0, jedis.llen(REDIS_CHANNEL_QUEUE));
            if (CollectionUtils.isEmpty(redisChannelQueueList)) {
                LOG.warn("Redis队列暂无数据！");
                return null;
            }
            redisChannelQueueList.forEach(r -> {
                DGWChannelEvent event = new Gson().fromJson(r, DGWChannelEvent.class);
                if (event != null) {
                    resultList.add(event.getContext());
                }
                // 清除Redis队列
                jedis.lrem(REDIS_CHANNEL_QUEUE, 0, r);
            });
        } catch (Exception e) {
            LOG.error("RedisChannel take error!", e);
            throw new DGWException("", e.getMessage());
        } finally {
            lock.unlock();
        }
        return resultList;
    }

    @Override
    public void commit(String eventId, String topic, boolean status) throws DGWException {
        // 更新redis中存储的结果status，并判断是否该记录的所有subscribe out插件都成功消费，是则删除此记录
        try(Jedis jedis = this.pool.getResource()) {
            lock.lock();
            List<String> redisChannelQueueList = jedis.lrange(REDIS_CHANNEL_QUEUE,0, jedis.llen(REDIS_CHANNEL_QUEUE));
            if (CollectionUtils.isEmpty(redisChannelQueueList)) {
                LOG.warn("Redis队列暂无数据！");
                return;
            }
            redisChannelQueueList.forEach(r -> {
                DGWChannelEvent event = new Gson().fromJson(r, DGWChannelEvent.class);
                if (event != null) {
                    if (eventId.equals(event.getEventId())) {
                        Map<String, Boolean> statusMap = event.getStatus();
                        if (statusMap == null || statusMap.size() == 0) {
                            return;
                        }
                        // 如果获取的主题下消费的对象存在并且状态是true,则说明消费成功，需在Redis队列中删除
                        if (statusMap.get(topic) != null && !statusMap.get(topic)) {
                            // 删除消费成功的数据
                            jedis.lrem(REDIS_CHANNEL_QUEUE, 0, r);
                        }
                    }
                }
            });

        } catch (Exception e) {
            LOG.error("RedisChannel commit error!", e);
            throw new DGWException("", e.getMessage());
        } finally {
            lock.unlock();
        }
    }
}
