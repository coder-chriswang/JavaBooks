package com.neoway.iot.dgw.api;

import com.neoway.iot.dgw.channel.Channel;
import com.neoway.iot.dgw.channel.ChannelManager;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.input.Input;
import com.neoway.iot.dgw.input.InputManager;
import com.neoway.iot.dgw.input.template.TemplateManager;
import com.neoway.iot.dgw.output.Output;
import com.neoway.iot.dgw.output.OutputManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: 管理API
 * @author: 20200312686
 * @date: 2020/6/23 9:02
 */
@RestController
@RequestMapping("/v1/manage")
@Api(tags = "管理")
public class ManageController {

    @ApiOperation("查询系统中加载的插件列表")
    @GetMapping("/plugins")
    public DGWResponse queryPlugin() {
        DGWResponse response = new DGWResponse();
        List<Input> inputs = InputManager.getInstance().getInputs();
        List<Map<String,Object>> plugins=new ArrayList<>();
        Map<String, Object> result = new HashMap<>();
        for (Input input : inputs) {
            Map<String, Object> inputResult = new HashMap<>();
            inputResult.put("name", input.name());
            inputResult.put("enable", input.isEnable());
            inputResult.put("configuration", input.configuration());
            plugins.add(inputResult);
        }
        result.put("input",plugins);
        plugins=new ArrayList<>();
        List<Channel> channels = ChannelManager.getInstance().getChannels();
        for (Channel channel : channels) {
            Map<String, Object> channelResult = new HashMap<>();
            channelResult.put("name", channel.name());
            channelResult.put("enable", true);
            channelResult.put("configuration", channel.configuration());
            plugins.add(channelResult);
        }
        result.put("channel",plugins);
        plugins=new ArrayList<>();
        List<Output> outputs = OutputManager.getInstance().getOutputs();
        for (Output output : outputs) {
            Map<String, Object> outputResult = new HashMap<>();
            outputResult.put("name", output.name());
            outputResult.put("enable", output.isEnable());
            outputResult.put("configuration", output.configuration());
            plugins.add(outputResult);
        }
        result.put("output",plugins);
        response.setData(result);
        return response;
    }

    @ApiOperation("获取当前统计数据")
    @GetMapping("/stats")
    public DGWResponse getStats() {
        return null;
    }


    @ApiOperation("通知远程加载模型包")
    @PostMapping("/notify/{ns}")
    public DGWResponse notify(@PathVariable("ns") String ns) {
        //收到通知后，调用模型包下载接口，下载模型包
        return null;
    }

    @ApiOperation("通知本地重加载模型包")
    @PostMapping("/notify/reload/{ns}")
    public DGWResponse notifyRelode(@PathVariable("ns") String ns) {
        //收到通知后，调用模型包下载接口，下载模型包
        return null;
    }
}
