package com.neoway.iot.dgw.input.scheduler;

import com.google.gson.Gson;
import com.neoway.iot.dgw.channel.Channel;
import com.neoway.iot.dgw.channel.ChannelManager;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.input.template.*;
import com.neoway.iot.sdk.dmk.template.MetaEvent;
import com.neoway.iot.sdk.dmk.template.MetaTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * @desc: 原子模板执行器-执行
 * @author: 20200312686
 * @date: 2020/6/29 14:11
 */
public class ScheudlerAtoExecutor {
    private static final Logger LOG = LoggerFactory.getLogger(ScheudlerAtoExecutor.class);


    /**
     * 上行指令执行
     * @param request
     * @return
     */
    public static DGWResponse uplink(DGWRequest request) {
        LOG.info("开始执行上行指令:reqId={},dsCode={},templateid={}",
                request.getReqId(),request.getDsCode(),request.getTemplateid());
        DGWResponse response = new DGWResponse();
        TemplateManager manager = TemplateManager.getInstance();
        MetaTemplate tpl = manager.getTemplate(request.getTemplateid());
        if(null == tpl){
            LOG.error("执行出错：错误原因：reqId={},dsCode={}未定位到执行模板"
                    ,request.getReqId(),request.getDsCode(),request.getTemplateid());
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg("");
            return response;
        }
        ChannelManager channelManager = ChannelManager.getInstance();
        Gson gson = new Gson();
        //模型翻译
        try {
            if(null == tpl.getHeader()){
                LOG.error("执行出错：错误原因：reqId={},dsCode={},模板={} header格式错误"
                        ,request.getReqId(),request.getDsCode(),request.getTemplateid());
                response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
                response.setMsg("");
                return response;
            }
            String headerJson = tpl.getHeader().transfter(request).trim();
            DGWHeader header = gson.fromJson(headerJson, DGWHeader.class);
            if(StringUtils.isEmpty(header.getTopic())){
                LOG.error("执行出错：错误原因：dsCode={},模板={} header格式错误"
                        ,request.getDsCode(),request.getTemplateid());
                response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
                response.setMsg("");
                return response;
            }
            header=header.build(request.getReqId(),request.getTs(),request.getDsCode());
            if(tpl.isDebugger()){
                LOG.info("翻译后的header报文={}",gson.toJson(header));
            }
            String reqJson = tpl.getRequest().transfter(request);
            if(tpl.isDebugger()){
                LOG.info("翻译后的request报文={}",reqJson);
            }

            Map<String, Object> reqMap = gson.fromJson(reqJson, Map.class);
            DGWContext context = new DGWContext(header, reqMap);
            //2:获取订阅的channel
            Channel channel = channelManager.getChannel(header.getTopic());
            response=channel.process(context.clone());
            return response;
        }catch (Exception e) {
            LOG.error(e.getMessage(), e);
            response = new DGWResponse(DGWCodeEnum.EXCEPTION_CODE.getCode(), e.getMessage());
            response.buildTs();
            return response;
        }finally {
            sendEvent(tpl,request,response);
            LOG.info("结束执行上行指令:reqId={},dsCode={},templateid={}",
                    request.getReqId(),request.getDsCode(),request.getTemplateid());
        }
    }

    /**
     * 生成em事件并发送
     * @param template
     * @param request
     * @param response
     * @return
     */
    public static void sendEvent(MetaTemplate template,DGWRequest request,DGWResponse response){
        MetaEvent event=template.getEvent();
        if(null == event){
            return;
        }
        ChannelManager channelManager = ChannelManager.getInstance();
        Gson gson = new Gson();
        try{
            String eventJson=event.transfter(request,response);
            if(template.isDebugger()){
                LOG.info("翻译后的event报文={}",eventJson);
            }
            Map<String, Object> reqMap = gson.fromJson(eventJson, Map.class);
            DGWHeader header=new DGWHeader(template.getDs_code(),DGWCmd.UPLINK_EM_DATA.name());
            DGWContext context = new DGWContext(header, reqMap);
            //2:获取订阅的channel
            Channel channel = channelManager.getChannel(header.getTopic());
            channel.process(context.clone());
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
        }
    }
}
