package com.neoway.iot.dgw.common.tsd;

import org.apache.http.HttpResponse;
import org.apache.http.concurrent.FutureCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: opentsdb写入回调
 * @author: 20200312686
 * @date: 2020/6/22 11:38
 */
public class TSDCloseCallBack implements FutureCallback<HttpResponse>{
    private static final Logger LOG = LoggerFactory.getLogger(TSDCloseCallBack.class);
    private final AtomicInteger unCompletedTaskNum;
    private final FutureCallback<HttpResponse> futureCallback;

    public TSDCloseCallBack(AtomicInteger unCompletedTaskNum, FutureCallback<HttpResponse> futureCallback) {
        super();
        this.unCompletedTaskNum = unCompletedTaskNum;
        this.futureCallback = futureCallback;
    }

    @Override
    public void completed(HttpResponse result) {
        futureCallback.completed(result);
        LOG.debug("等待完成的任务数:{}", unCompletedTaskNum.decrementAndGet());
    }

    @Override
    public void failed(Exception ex) {
        futureCallback.failed(ex);
        LOG.debug("等待完成的任务数:{}", unCompletedTaskNum.decrementAndGet());
    }

    @Override
    public void cancelled() {
        futureCallback.cancelled();
        LOG.debug("等待完成的任务数:{}", unCompletedTaskNum.decrementAndGet());
    }

}
