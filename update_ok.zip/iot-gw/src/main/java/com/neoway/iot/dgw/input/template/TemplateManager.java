package com.neoway.iot.dgw.input.template;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.input.AbstractInput;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.template.MetaDS;
import com.neoway.iot.sdk.dmk.template.MetaTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: AbstractInput
 * @author: 20200312686
 * @date: 2020/6/23 16:10
 */
public class TemplateManager extends AbstractInput {
    private static final Logger LOG = LoggerFactory.getLogger(TemplateManager.class);
    private static final String PRODUCT="ioc";
    private static TemplateManager manager=null;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    //静默执行的模板队列
    private List<MetaTemplate> initTemplateQueue=new ArrayList<MetaTemplate>();
    private DGWConfig env;
    private DMRunner runner;
    private TemplateManager() {
        this.runner=DMRunner.getInstance();
    }
    public static TemplateManager getInstance() {
        if (manager == null) {
            synchronized (TemplateManager.class) {
                if (manager == null) {
                    manager = new TemplateManager();
                }
            }
        }
        return manager;
    }

    @Override
    public String name() {
        return "module-input-template";
    }

    /**
     * @desc 系统启动阶段，加载本地的模型文件
     * @param env
     */
    @Override
    public void start(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        this.env=env;
        super.start(env);
    }
    @Override
    public DGWResponse uplink(DGWRequest req) {
        List<MetaTemplate> templates=this.listTemplate();
        if(CollectionUtils.isNotEmpty(templates)){
            this.initTemplateQueue.addAll(templates);
        }
        return new DGWResponse();
    }
    @Override
    public Map<String, Object> configuration() {
        return null;
    }
    public List<MetaTemplate> getInitTemplateQueue() {
        Gson gson=new Gson();
        String json=gson.toJson(this.initTemplateQueue);
        List<MetaTemplate> queues=gson.fromJson(json,new TypeToken<List<MetaTemplate>>() {}.getType());
        return queues;
    }
    public synchronized void commit(MetaTemplate template){
        this.initTemplateQueue.remove(template);
    }

    public MetaTemplate getTemplate(String templateId){
        DMDataPoint condition=DMDataPoint.builder(PRODUCT, MetaDS.DSCATEGORY,MetaTemplate.TEMPLATECI);
        DMDataColumn column=new DMDataColumn("templateid",templateId);
        condition.addColumn(column);
        DMDataPoint point=runner.get(condition);
        return MetaTemplate.buildTemplate(point);
    }

    public List<MetaTemplate> listTemplate(){
        DMDataPoint condition=DMDataPoint.builder(PRODUCT, MetaDS.DSCATEGORY,MetaTemplate.TEMPLATECI);
        DMDataColumn column=new DMDataColumn("policy",MetaTemplate.POLICY_INIT);
        condition.addColumn(column);
        List<DMDataPoint> points=runner.list(condition);
        if(CollectionUtils.isEmpty(points)){
            return null;
        }
        List<MetaTemplate> templates=new ArrayList<>();
        for(DMDataPoint point:points){
            MetaTemplate template=MetaTemplate.buildTemplate(point);
            templates.add(template);
        }
        return templates;
    }

}
