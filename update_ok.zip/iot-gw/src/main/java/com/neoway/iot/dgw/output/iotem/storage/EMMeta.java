package com.neoway.iot.dgw.output.iotem.storage;

import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * @desc: EmMeta
 * @author: 20200312686
 * @date: 2020/7/20 17:32
 */
public class EMMeta {
    private static final String CATEGORY_OM="OM";
    private static final String CATEGORY_DEVICE="Device";
    private static final String TYPE_SYSTEM="System";
    private static final String TYPE_OPERATE="Operate";
    private static final String SEVERITY_MAJOR="Major";
    private static final String SEVERITY_NORMAL="Normal";
    private String ns;
    //事件ID
    private int eventId;
    //事件名称
    private String eventName;
    //事件分类 【OM,Device】
    private String eventCategory;
    //事件类型 【System,Operate】
    private String eventType;
    //事件级别 【Major，Normal】
    private String eventSeverity;

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventCategory() {
        return eventCategory;
    }

    public void setEventCategory(String eventCategory) {
        this.eventCategory = eventCategory;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventSeverity() {
        return eventSeverity;
    }

    public void setEventSeverity(String eventSeverity) {
        this.eventSeverity = eventSeverity;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    /**
     * @desc 属性校验
     * @throws DGWException
     */
    public void validate() throws DGWException {
        if(this.eventId < 0
                || StringUtils.isEmpty(this.eventName)
                || StringUtils.isEmpty(this.ns)){
            String msg="模型配置错误，必填属性存在空值";
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
        if(!(this.eventCategory.equals(CATEGORY_DEVICE) || this.eventCategory.equals(CATEGORY_OM))){
            String msg="模型配置错误，category属性非法,category={}"+this.eventCategory;
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
        if(!(this.eventType.equals(TYPE_OPERATE) || this.eventType.equals(TYPE_SYSTEM))){
            String msg="模型配置错误，type属性非法,type={}"+this.eventType;
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
        if(!(this.eventSeverity.equals(SEVERITY_MAJOR) || this.eventSeverity.equals(SEVERITY_NORMAL))){
            String msg="模型配置错误，severity属性非法,severity={}"+this.eventSeverity;
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
    }

    public Object[] getParam(){
        Object[] param=new Object[]{
                this.getNs(),
                this.getEventId(),
                this.getEventName(),
                this.getEventCategory(),
                this.getEventType(),
                this.getEventSeverity()
        };
        return param;
    }

    public static EMMeta buildMeta(Map<String,Object> dbResult){
        EMMeta emMeta=new EMMeta();
        emMeta.setNs(dbResult.get("ns").toString());
        emMeta.setEventId(Integer.valueOf(String.valueOf(dbResult.get("event_id"))));
        emMeta.setEventName(dbResult.get("event_name").toString());
        emMeta.setEventCategory(dbResult.get("category").toString());
        emMeta.setEventType(dbResult.get("type").toString());
        emMeta.setEventSeverity(dbResult.get("severity").toString());
        return emMeta;
    }
}
