package com.neoway.iot.dgw.input;

import com.neoway.iot.dgw.DGAbstractLifecycleComponent;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.freemarker.FreemarkerDgwBase64;
import com.neoway.iot.dgw.common.freemarker.FreemarkerDgwHash;
import com.neoway.iot.dgw.input.connector.ConnectorManager;
import com.neoway.iot.dgw.input.template.TemplateManager;
import com.neoway.iot.sdk.dmk.common.util.DMEtl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: InputManager
 * @author: 20200312686
 * @date: 2020/6/23 14:22
 */
public class InputManager extends DGAbstractLifecycleComponent {
    private static InputManager manager=null;
    private List<Input> inputModules=new ArrayList<Input>();
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private InputManager() {

    }
    public static InputManager getInstance() {
        if (manager == null) {
            synchronized (InputManager.class) {
                if (manager == null) {
                    manager = new InputManager();
                }
            }
        }
        return manager;
    }
    @Override
    protected String name() {
        return "module-input";
    }
    @Override
    protected synchronized void doStart(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        DMEtl.init(env.getPro());
        DMEtl.addVariable("dgw_hash",new FreemarkerDgwHash());
        DMEtl.addVariable("dgw_base64",new FreemarkerDgwBase64());

        Input templateManager= TemplateManager.getInstance();
        inputModules.add(templateManager);
        templateManager.start(env);
        Input connectorManager= ConnectorManager.getInstance();
        inputModules.add(connectorManager);
        connectorManager.start(env);
        isStarted.set(true);
    }

    public List<Input> getInputs(){
        return inputModules;
    }
}
