package com.neoway.iot.dgw.output.iotpm;

import com.neoway.iot.dgw.output.iotdm.DmCmd;
import com.neoway.iot.dgw.output.iotdm.handler.*;
import com.neoway.iot.dgw.output.iotpm.handler.*;
import com.neoway.iot.dgw.output.iotpm.storage.PMDSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: DmCmdFactory
 * @author: 20200312686
 * @date: 2020/7/17 10:33
 */
public class PmCmdFactory {
    private static final Logger LOG = LoggerFactory.getLogger(PmCmdFactory.class);
    private static Map<PmCmd,PmCmdHandler> handlers=new HashMap<>();
    /**
     * @desc
     * @param cmdId
     * @return
     */
    public static PmCmdHandler buildHandler(String cmdId, PMDSink sink){
        PmCmd cmd=PmCmd.valueOf(cmdId.toUpperCase());;
        PmCmdHandler handler=handlers.get(cmd);
        if(null != handler){
            return handler;
        }else if(cmd == PmCmd.CMD_RULE_COMPUTE) {
            handler=new PmCmdHandlerRuleCompute(sink);
        }else if(cmd == PmCmd.UPLINK_PM_META) {
            handler=new PmCmdHandlerUplinkMeta(sink);
        }else if(cmd == PmCmd.UPLINK_PM_DATA) {
            handler=new PmCmdHandlerUplinkData(sink);
        }else if(cmd == PmCmd.SUBCRIBE_DM_DATA){
            handler=new PmCmdHandlerSubcribeDm(sink);
        }else{
            return null;
        }
        LOG.info("cmdId={},desc={}",cmd.name(),cmd.getDesc());
        handlers.put(cmd,handler);
        return handler;
    }
}
