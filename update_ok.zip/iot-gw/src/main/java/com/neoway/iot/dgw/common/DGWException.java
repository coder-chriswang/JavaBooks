package com.neoway.iot.dgw.common;

/**
 * @desc: DGWException
 * @author: 20200312686
 * @date: 2020/6/23 10:42
 */
public class DGWException extends Exception {
    private String code;
    public DGWException(Throwable cause) {
        super(cause);
    }
    public DGWException(String code, String msg) {
        super(msg);
        this.code=code;
    }

    public String getCode() {
        return code;
    }
}
