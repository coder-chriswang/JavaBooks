package com.neoway.iot.dgw.input.connector.hj212;

import com.neoway.iot.dgw.input.connector.Connector;
import com.neoway.iot.dgw.input.connector.ConnectorReq;
import com.neoway.iot.dgw.input.connector.ConnectorRsp;

import java.util.Map;

/**
 * @desc: HJ212Connector
 * @author: 20200312686
 * @date: 2020/8/18 12:15
 */
public class HJ212Connector extends Connector {
    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        return null;
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }
    @Override
    public String name() {
        return "input-connector-hj212";
    }
}
