package com.neoway.iot.dgw;

import com.neoway.iot.dgw.common.DGWException;

import java.io.Closeable;

/**
 * @desc: 组件生命周期管理接口
 * @author: 20200312686
 * @date: 2020/6/22 12:27
 */
public interface DGLifecycleComponent {
    void start() throws DGWException;
    void stop();
}
