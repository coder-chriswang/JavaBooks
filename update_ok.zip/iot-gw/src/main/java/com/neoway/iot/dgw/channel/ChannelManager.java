package com.neoway.iot.dgw.channel;

import com.neoway.iot.dgw.DGAbstractLifecycleComponent;
import com.neoway.iot.dgw.common.DGWCmd;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.output.OutputType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: ChannelManager
 * @author: 20200312686
 * @date: 2020/6/23 10:03
 */
public class ChannelManager extends DGAbstractLifecycleComponent {
    private static final Logger LOG = LoggerFactory.getLogger(ChannelManager.class);
    public static final String BACKEND = "dgw.channel.backend";
    private static ChannelManager manager=null;
    private List<Channel> channelsModules=new ArrayList<>();
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private ChannelManager() {

    }

    @Override
    protected void doStart(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        List<ChannelType> channelTypes=new ArrayList<>();
        channelTypes.add(ChannelType.DIRECT);
        String backend = String.valueOf(env.getValue(BACKEND));
        if (ChannelType.REDIS.name().toLowerCase().equals(backend)) {
            channelTypes.add(ChannelType.REDIS);
        }else{
            channelTypes.add(ChannelType.MEMORY);
        }
        for(ChannelType channelType:channelTypes){
            Channel channel=this.create(channelType.name(),channelType.getChannelClassName());
            channelsModules.add(channel);
            channel.start(env);
        }
        isStarted.set(true);
    }

    @Override
    protected String name() {
        return "module-channel";
    }

    public static ChannelManager getInstance() {
        if (manager == null) {
            synchronized (ChannelManager.class) {
                if (manager == null) {
                    manager = new ChannelManager();
                }
            }
        }
        return manager;
    }

    /**
     * @desc channel实例化
     * @param name
     * @param type
     * @return
     * @throws DGWException
     */
    private Channel create(String name, String type) throws DGWException {
        LOG.info("创建channel实例 类型={} clazz={}", name, type);
        Class<? extends Channel> channelClass = getClass(name);
        try {
            return channelClass.newInstance();
        } catch (Exception ex) {
            throw new DGWException("",ex.getMessage());
        }
    }

    /**
     * @desc 获取channel clazz
     * @param type
     * @return
     * @throws DGWException
     */
    private Class<? extends Channel> getClass(String type) throws DGWException {
        String channelClassName = type;
        ChannelType channelType = ChannelType.OTHER;
        try {
            channelType=ChannelType.valueOf(type.toUpperCase(Locale.ENGLISH));
        } catch (IllegalArgumentException ex) {
            LOG.error("Channel类型非内置，属于自定义", type);
        }
        if (!channelType.equals(channelType.OTHER)) {
            channelClassName = channelType.getChannelClassName();
        }
        try {
            return (Class<? extends Channel>) Class.forName(channelClassName);
        } catch (Exception ex) {
            throw new DGWException("",ex.getMessage());
        }
    }

    /**
     * @desc 获取订阅topic的channel
     * @param cmdId
     * @return
     */
    public Channel getChannel(String cmdId){
        if(DGWCmd.MSG_DM.name().equalsIgnoreCase(cmdId)
        || DGWCmd.MSG_EM.name().equalsIgnoreCase(cmdId)
        || DGWCmd.MSG_FM.name().equalsIgnoreCase(cmdId)
        || DGWCmd.MSG_LM.name().equalsIgnoreCase(cmdId)
        || DGWCmd.MSG_PM.name().equalsIgnoreCase(cmdId)){
            return channelsModules.get(0);
        }else{
            return channelsModules.get(1);
        }
    }

    public List<Channel> getChannels(){
        return this.channelsModules;
    }
}
