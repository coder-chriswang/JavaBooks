package com.neoway.iot.dgw.channel;

import com.neoway.iot.dgw.common.DGWContext;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.output.Output;
import com.neoway.iot.dgw.output.OutputManager;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: AbstractChannel
 * @author: 20200312686
 * @date: 2020/6/23 10:01
 */
public abstract class AbstractChannel implements Channel {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractChannel.class);
    private OutputManager outputManager;

    @Override
    public void start(DGWConfig config) {
        this.outputManager=OutputManager.getInstance();
        LOG.info("channel插件：{} 启动成功", this.name());
    }

    @Override
    public void stop() {
        LOG.info("channel插件：{} 停止成功", this.name());
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public DGWResponse process(DGWContext context) {
        String topic=context.getHeader().getTopic();
        List<Output> outputs=this.outputManager.getOutputs(topic);
        if(CollectionUtils.isEmpty(outputs)){
            LOG.warn("消息topic={},reqId={}没有接收的output插件",
                    context.getHeader().getTopic(),context.getHeader().getReqId());
            return new DGWResponse();
        }
        Map<String,Boolean> status=new HashMap<>();
        for(Output out:outputs){
            status.put(out.name(),false);
        }
        List<Map<String,Object>> values=context.decodeData();
        List<DGWChannelEvent> events=new ArrayList<>();
        for(Map<String,Object> value:values){
            DGWContext cc=new DGWContext(context.getHeader(),value);
            DGWChannelEvent event=new DGWChannelEvent(cc,status);
            events.add(event);
        }
        return this.doProcess(events);

    }

    /**
     * @desc
     * @param events
     * @throws DGWException
     */
    public abstract DGWResponse doProcess(List<DGWChannelEvent> events);
}
