package com.neoway.iot.dgw.output.iotpm.storage;

import com.neoway.iot.dgw.common.tsd.TSDPoint;
import com.neoway.iot.dgw.common.tsd.TSDPutCallBack;
import com.neoway.iot.dgw.common.tsd.TSDResult;

import java.util.List;

/**
 * @desc: PMDPutCallBackFile
 * @author: 20200312686
 * @date: 2020/7/1 14:04
 */
public class PMDPutCallBackFile implements TSDPutCallBack {
    @Override
    public void response(List<TSDPoint> points, TSDResult result) {

    }

    @Override
    public void responseError(List<TSDPoint> points, TSDResult result) {

    }

    @Override
    public void failed(List<TSDPoint> points, Exception e) {

    }
}
