package com.neoway.iot.dgw.common.monitor;

/**
 * @desc: DGW测量指标
 * @author: 20200312686
 * @date: 2020/6/23 10:09
 */
public class DGWMetric {
}
