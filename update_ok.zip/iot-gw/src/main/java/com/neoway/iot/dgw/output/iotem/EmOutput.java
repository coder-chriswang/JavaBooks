package com.neoway.iot.dgw.output.iotem;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.output.AbstractOutput;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotem.handler.EmCmdHandler;
import com.neoway.iot.dgw.output.iotem.storage.EMDElasticSink;
import com.neoway.iot.dgw.output.iotem.storage.EMDMySqlSink;
import com.neoway.iot.dgw.output.iotem.storage.EMDSink;
import com.neoway.iot.dgw.output.iotpm.PmCmd;
import com.neoway.iot.dgw.output.iotpm.PmCmdFactory;
import com.neoway.iot.dgw.output.iotpm.handler.PmCmdHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: EmOut
 * @author: 20200312686
 * @date: 2020/7/1 9:18
 */
public class EmOutput extends AbstractOutput {
    private static final Logger LOG = LoggerFactory.getLogger(EmOutput.class);
    public static final String BACKEND = "dgw.output.em.backend";
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private EMDSink sink;

    @Override
    public void start(DGWConfig config) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        String backend = String.valueOf(config.getValue(BACKEND));
        if (EMDSink.BACKEND_MYSQL.equals(backend)) {
            sink = new EMDMySqlSink();
        } else if (EMDSink.BACKEND_ELASTIC.equals(backend)) {
            sink = new EMDElasticSink();
        } else {
            sink = new EMDMySqlSink();
        }
        sink.start(config);
        super.start(config);
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public DGWResponse doProcess(OutputEvent event) throws DGWException {
        String topic=event.getHeader().getTopic();
        EmCmdHandler handler;
        if(DGWCmd.MSG_EM.name().equals(topic)){
            DGWHeader head=event.getHeader();
            handler=EmCmdFactory.buildHandler(head.getCmdId(),this.sink);
        }else{
            handler=EmCmdFactory.buildHandler(topic,this.sink);
        }
        DGWResponse rsp = new DGWResponse();
        if(null == handler){
            LOG.warn("Topic非法：topic={}",topic);
            return rsp;
        }
        return handler.execute(event);
    }

    @Override
    public String name() {
        return "output-plugin-em";
    }

    @Override
    public List<String> getTopics() {
        return Arrays.asList(DGWCmd.UPLINK_EM_DATA.name(),
                DGWCmd.UPLINK_EM_META.name(),
                DGWCmd.MSG_EM.name());
    }

}
