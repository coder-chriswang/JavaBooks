package com.neoway.iot.dgw.common;

import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * @desc: DGWHeader
 * @author: 20200312686
 * @date: 2020/7/2 14:03
 */
public class DGWHeader implements Serializable {
    private String dsCode;
    private String topic;
    private String cmdId;
    private long ts=0L;
    private String reqId;
    private Map<String,Object> ext=new HashMap<>();
    public DGWHeader(){

    }
    public DGWHeader(long dsCode,String topic){
        this.reqId= UUID.randomUUID().toString();
        this.ts=System.currentTimeMillis()/1000L;
        this.topic=topic;
        this.dsCode=String.valueOf(dsCode);
    }

    public DGWHeader build(String reqId,long ts,String dsCode){
        if(StringUtils.isEmpty(reqId)){
            this.reqId= UUID.randomUUID().toString();
        }else{
            this.reqId=reqId;
        }
        if(ts <= 0){
            this.ts=System.currentTimeMillis();
        }else{
            this.ts=ts;
        }
        this.dsCode=dsCode;
        return this;
    }
    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getCmdId() {
        return cmdId;
    }

    public void setCmdId(String cmdId) {
        this.cmdId = cmdId;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public Map<String, Object> getExt() {
        return ext;
    }

    public void setExt(Map<String, Object> ext) {
        this.ext = ext;
    }

    public String getDsCode() {
        return dsCode;
    }

    public void setDsCode(String dsCode) {
        this.dsCode = dsCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DGWHeader dgwHeader = (DGWHeader) o;
        return Objects.equals(reqId, dgwHeader.reqId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reqId);
    }


}
