package com.neoway.iot.dgw.output.iotem.storage;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.utils.IDWorker;

/**
 * @desc: EMDPoint
 * @author: 20200312686
 * @date: 2020/7/1 17:02
 */
public class EMDPoint {
    private static IDWorker idWorker=new IDWorker();
    private long eventNo;
    private int eventId;
    private String eventName;
    private String eventCategory;
    private String eventType;
    private String eventSeverity;
    private String eventInfo;
    private int eventSt;
    private int eventEt;
    private String eventResult;
    private String clientIp;
    private long instanceId;
    private String ns;

    public long getEventNo() {
        return eventNo;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }
    public String getEventCategory() {
        return eventCategory;
    }
    public String getEventType() {
        return eventType;
    }
    public String getEventSeverity() {
        return eventSeverity;
    }
    public String getEventInfo() {
        return eventInfo;
    }
    public int getEventSt() {
        return eventSt;
    }

    public int getEventEt() {
        return eventEt;
    }

    public String getEventResult() {
        return eventResult;
    }

    public String getClientIp() {
        return clientIp;
    }
    public long getInstanceId() {
        return instanceId;
    }
    public String getNs() {
        return ns;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public void setEventCategory(String eventCategory) {
        this.eventCategory = eventCategory;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public void setEventSeverity(String eventSeverity) {
        this.eventSeverity = eventSeverity;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public void buildEventNo(){
        this.eventNo=idWorker.nextId();
    }
    @Override
    public String toString() {
        Gson gson=new Gson();
        return gson.toJson(this);
    }
    public Object[] getParam(){
        Object[] param=new Object[]{
                this.eventNo,
                this.getEventId(),
                this.getEventName(),
                this.getEventCategory(),
                this.getEventType(),
                this.getEventSeverity(),
                this.getEventInfo(),
                this.getEventSt(),
                this.getEventEt(),
                this.getEventResult(),
                this.getClientIp(),
                this.getInstanceId()
        };
        return param;
    }
}
