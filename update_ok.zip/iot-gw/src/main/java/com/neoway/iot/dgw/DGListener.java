package com.neoway.iot.dgw;

import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.input.scheduler.ScheudlerAtoExecutor;
import com.neoway.iot.dgw.input.template.TemplateManager;
import com.neoway.iot.sdk.dmk.template.MetaTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @desc: springboot事件监听器。用于监听启动、销毁等事件来完成业务初始化
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
@Component
public class DGListener implements ApplicationListener {
    private static final Logger LOG = LoggerFactory.getLogger(DGListener.class);
    private static final String SCHEDULER_NAME="input-template-init";
    private static final int DEFAULT_INTERVAL=60;
    private List<DGLifecycleComponent> comps=new ArrayList<DGLifecycleComponent>();
    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        if(event instanceof ApplicationReadyEvent){
            LOG.info("DGW开始业务初始化",event.toString());
            this.initExecuteTemplate();
            this.initRunner(DEFAULT_INTERVAL);
            LOG.info("DGW业务初始化成功",event.toString());
        }
    }

    /**
     * @desc 静默自动化执行模板
     */
    private void initExecuteTemplate(){
        //2:静默执行模板自动执行
        TemplateManager manager=TemplateManager.getInstance();
        List<MetaTemplate> tpls=manager.getInitTemplateQueue();
        for(MetaTemplate template:tpls){
            DGWRequest request=new DGWRequest(template.getDs_code(),template.getTemplateid());
            DGWResponse rsp=ScheudlerAtoExecutor.uplink(request);
            if(rsp.getCode().equals(DGWCodeEnum.SUCCESS_CODE.getCode())){
                manager.commit(template);
            }else{
                LOG.error("模板静默自动化执行失败,一分钟后重试,错误码={},错误原因={},产品={}，模板ID={}",
                        rsp.getCode(),rsp.getMsg(),request.getDsCode(),request.getTemplateid());
            }
        }
    }

    /**
     * @desc 定时执行初始化
     * @param interval
     * @return 定时器服务
     */
    public ScheduledExecutorService initRunner(int interval){
        ScheduledExecutorService initRunner = Executors.newSingleThreadScheduledExecutor(
                (r) -> {
                    Thread t = new Thread(r, SCHEDULER_NAME);
                    t.setDaemon(true);
                    return t;
                }
        );
        initRunner.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try{
                    initExecuteTemplate();
                }catch (Exception e){
                    //TODO 发送
                }

            }
        }, 0, interval, TimeUnit.SECONDS);
        return initRunner;
    }
}
