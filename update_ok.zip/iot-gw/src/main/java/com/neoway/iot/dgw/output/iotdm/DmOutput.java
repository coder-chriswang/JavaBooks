package com.neoway.iot.dgw.output.iotdm;

import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.output.AbstractOutput;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotdm.handler.DmCmdHandler;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.data.DMCache;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: DM插件
 * @author: 20200312686
 * @date: 2020/7/1 9:18
 */
public class DmOutput extends AbstractOutput {
    private static final String DM_JDBC_HOST="dgw.output.dm.jdbc.host";
    private static final String DM_JDBC_PORT="dgw.output.dm.jdbc.port";
    private static final String DM_JDBC_DB="dgw.output.dm.jdbc.db";
    private static final String DM_JDBC_MAX_CONN="dgw.output.dm.jdbc.max_conn";
    private static final String DM_JDBC_MIN_CONN="dgw.output.dm.jdbc.min_conn";
    private static final String DM_JDBC_USER="dgw.output.dm.jdbc.user";
    private static final String DM_JDBC_PWD="dgw.output.dm.jdbc.pwd";
    private static final String DM_JDBC_CONN_TIMEOUT="dgw.output.dm.jdbc.conn_timeout";
    private static final String DM_JDBC_IDEL_TIMEOUT="dgw.output.dm.jdbc.idel_timeout";
    private static final String DM_DATA_CACHE="dgw.output.dm.data.cache";
    private static final String DM_DATA_CACHE_MAX="dgw.output.dm.data.cache.max";
    private static final String DM_DATA_CACHE_INIT="dgw.output.dm.data.cache.init";
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private DMRunner runner;

    @Override
    public String name() {
        return "output-plugin-dm";
    }

    @Override
    public List<String> getTopics() {
        return Arrays.asList(DGWCmd.UPLINK_DM_DATA.name(),
                DGWCmd.UPLINK_DM_META.name(),
                DGWCmd.MSG_DM.name());
    }

    @Override
    public void start(DGWConfig config) {
        if (isStarted.get()) {
            return;
        }
        this.runner = DMRunner.getInstance();
        Map<String,Object> pro=new HashMap<>();
        pro.put(DMPool.JDBC_HOST,config.getValue(DM_JDBC_HOST));
        pro.put(DMPool.JDBC_PORT,config.getValue(DM_JDBC_PORT));
        pro.put(DMPool.JDBC_DB,config.getValue(DM_JDBC_DB));
        pro.put(DMPool.JDBC_MAX_CONN,config.getValue(DM_JDBC_MAX_CONN));
        pro.put(DMPool.JDBC_MIN_CONN,config.getValue(DM_JDBC_MIN_CONN));
        pro.put(DMPool.JDBC_USER,config.getValue(DM_JDBC_USER));
        pro.put(DMPool.JDBC_PWD,config.getValue(DM_JDBC_PWD));
        pro.put(DMPool.JDBC_CONN_TIMEOUT,config.getValue(DM_JDBC_CONN_TIMEOUT));
        pro.put(DMPool.JDBC_IDEL_TIMEOUT,config.getValue(DM_JDBC_IDEL_TIMEOUT));
        pro.put(DMCache.CACHE_KEY,config.getValue(DM_DATA_CACHE));
        pro.put(DMCache.CACHE_MAX,config.getValue(DM_DATA_CACHE_MAX));
        pro.put(DMCache.CACHE_INIT,config.getValue(DM_DATA_CACHE_INIT));
        runner.start(pro);
        isStarted.set(true);
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }
    @Override
    public DGWResponse doProcess(OutputEvent event){
        String topic=event.getHeader().getTopic();
        DmCmdHandler handler;
        if(DGWCmd.UPLINK_DM_META.name().equals(topic)){
            handler=DmCmdFactory.buildHandler(DmCmd.UPLINK_DM_META.name());
        }else if(DGWCmd.UPLINK_DM_DATA.name().equals(topic)){
            handler=DmCmdFactory.buildHandler(DmCmd.UPLINK_DM_DATA.name());
        }else if(DGWCmd.MSG_DM.name().equals(topic)){
            DGWHeader head=event.getHeader();
            handler=DmCmdFactory.buildHandler(head.getCmdId());
        }else{
            String errMsg="接收到的topic非法:"+topic;
            DGWResponse rsp = new DGWResponse(DGWCodeEnum.EXCEPTION_CODE.getCode(),errMsg);
            return rsp;
        }
        return handler.execute(event);
    }


}
