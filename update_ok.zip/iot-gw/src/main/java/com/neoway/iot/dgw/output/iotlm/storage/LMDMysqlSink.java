package com.neoway.iot.dgw.output.iotlm.storage;

import com.google.common.hash.Hashing;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.jdbc.JdbcPool;
import org.apache.commons.codec.Charsets;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: LMDMysqlSink
 * @author: Chris(wangchao)
 * @date: 2020/7/1 16:46
 */
public class LMDMysqlSink extends LMDAbstractSink {
    private static final Logger LOG = LoggerFactory.getLogger(LMDMysqlSink.class);
    private static final String JDBC_URI = "dgw.output.lm.mysql.uri";
    private static final String JDBC_MAX_CONN = "dgw.output.lm.mysql.max_conn";
    private static final String JDBC_USER = "dgw.output.lm.mysql.user";
    private static final String JDBC_PWD = "dgw.output.lm.mysql.pwd";
    private static final String JDBC_CONN_TIMEOUT = "dgw.output.lm.mysql.conn_timeout";
    private static final String JDBC_IDEL_TIMEOUT = "dgw.output.lm.mysql.idel_timeout";
    private static final String JDBC_MIN_NUM = "dgw.output.lm.mysql.min_conn";
    private static final String PARTITION = "dgw.output.lm.mysql.partition";
    private static final String TABLE_NAME = "LM_VALUE";

    /**
     * 建表语句
     */
    private static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS %s ( "
                    + "instance_id BIGINT(20) NOT NULL, "
                    + "lat VARCHAR(32) NOT NULL, "
                    + "lon VARCHAR(32) NOT NULL, "
                    + "ut BIGINT NOT NULL, "
                    + "PRIMARY KEY (`instance_id`, `ut`) USING BTREE "
                    + " ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='位置数据表' ROW_FORMAT=DYNAMIC;";
    /**
     * 批量插入语句
     */
    private static final String BATCH_INSERT = "INSERT INTO {0} (" +
            "`instance_id`," +
            "`lat`," +
            "`lon`," +
            "`ut`) VALUES (?,?,?,?)";


    private AtomicBoolean isStarted = new AtomicBoolean(Boolean.FALSE);
    private int partition = 1;
    private JdbcPool client;

    @Override
    public void start(DGWConfig env) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        try {
            JdbcPool.Builder builder = new JdbcPool.Builder();
            this.client = builder.jdbcUri(env.getValue(JDBC_URI).toString()).jdbcUser(env.getValue(JDBC_USER).toString())
                    .jdbcPwd(env.getValue(JDBC_PWD).toString()).jdbcMaxConn(Integer.valueOf(env.getValue(JDBC_MAX_CONN).toString()))
                    .jdbcMinConn(Integer.valueOf(env.getValue(JDBC_MIN_NUM).toString()))
                    .jdbcConnTimeOut(Integer.valueOf(env.getValue(JDBC_CONN_TIMEOUT).toString()))
                    .jdbcIdelTimeOut(Integer.valueOf(env.getValue(JDBC_IDEL_TIMEOUT).toString()))
                    .jdbcReadOnly(false).jdbcAutoCommit(true).build();
            this.client.start();
            this.partition = (Integer) env.getValue(PARTITION);
            if (this.partition < 1) {
                this.partition = 1;
            }
            this.createTableIfNotExist(this.partition);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new DGWException("", e.getMessage());
        }
        isStarted.set(true);
        LOG.info("lm-out-mysql-sink启动成功!");
    }

    @Override
    void doWrite(List<LMDPoint> points) throws DGWException {
        if (CollectionUtils.isEmpty(points)) {
            return;
        }
        Map<String,List<Object[]>> groupMap=new HashMap<>();
        try {
            for (LMDPoint point : points) {
                String table = getTable(point);
                Object[] param = point.getParam();
                List<Object[]> params = groupMap.computeIfAbsent(table, k -> new ArrayList<>());
                params.add(param);
            }
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            for (Map.Entry<String,List<Object[]>> entry:groupMap.entrySet()) {
                Object[][] params = new Object[entry.getValue().size()][];
                String sql = MessageFormat.format(BATCH_INSERT,entry.getKey());
                params = entry.getValue().toArray(params);
                runner.batch(sql,params);
            }
        } catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }

    }

    /**
     * 创建数据表
     */
    private void createTableIfNotExist(int partition) throws SQLException {
        for (int index = 0; index<partition; index++) {
            String tableName = TABLE_NAME + "_" + index;
            String sql = String.format(CREATE_TABLE, tableName);
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            runner.update(sql);
        }
    }

    /**
     * @desc 定位数据表
     * @param point
     * @return 数据表名
     */
    private String getTable(LMDPoint point){
        String instanceId = String.valueOf(point.getInstanceId());
        int bucket = Hashing.consistentHash(Hashing.md5().hashString(instanceId, Charsets.UTF_8),this.partition);
        return TABLE_NAME + "_" + bucket;
    }
}
