package com.neoway.iot.dgw.output;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.DGWHeader;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: OutputEvent
 * @author: 20200312686
 * @date: 2020/7/7 16:40
 */
public class OutputEvent implements Cloneable {
    private DGWHeader header;
    private List<Map<String,Object>> events=new ArrayList<>();

    public OutputEvent(DGWHeader header) {
        this.header = header;
    }

    public DGWHeader getHeader() {
        return header;
    }

    public List<Map<String,Object>> getEvents() {
        return events;
    }

    public void addEvent(Map<String,Object> data){
        this.events.add(data);
    }
    @Override
    public OutputEvent clone() {
        Gson gson=new Gson();
        OutputEvent event = new Gson().fromJson(gson.toJson(this),OutputEvent.class);
        return event;
    }
}
