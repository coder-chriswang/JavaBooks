package com.neoway.iot.dgw.output.iotfm.storage;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.jdbc.JdbcPool;
import com.neoway.iot.dgw.common.redis.JedisUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 *  描述: FMDAbstractSink
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/09 14:54
 */
public abstract class FMDAbstractSink implements FMDSink {
    private static final Logger LOG = LoggerFactory.getLogger(FMDAbstractSink.class);
    private static final String JDBC_URI = "dgw.output.fm.jdbc.uri";
    private static final String JDBC_MAX_CONN = "dgw.output.fm.jdbc.max_conn";
    private static final String JDBC_USER = "dgw.output.fm.jdbc.user";
    private static final String JDBC_PWD = "dgw.output.fm.jdbc.pwd";
    private static final String JDBC_CONN_TIMEOUT = "dgw.output.fm.jdbc.conn_timeout";
    private static final String JDBC_IDEL_TIMEOUT = "dgw.output.fm.jdbc.idel_timeout";
    private static final String JDBC_MIN_NUM = "dgw.output.fm.jdbc.min_conn";
    private static final String CONFIGURATION_DB = "dgw.output.fm.redis.db";
    private static final String CONFIGURATION_HOST = "dgw.output.fm.redis.host";
    private static final String CONFIGURATION_PORT = "dgw.output.fm.redis.port";
    private static final String CONFIGURATION_PWD = "dgw.output.fm.redis.password";
    private static final String CONFIGURATION_TIMEOUT = "dgw.output.fm.redis.timeout";
    private static final String CONFIGURATION_MAX_ACTIVE = "dgw.output.fm.redis.max_active";
    private static final String CONFIGURATION_MAX_WAIT = "dgw.output.fm.redis.max_wait";
    private static final String CONFIGURATION_MAX_IDEL = "dgw.output.fm.redis.max_idel";
    private static final String CONFIGURATION_MIN_IDEL = "dgw.output.fm.redis.min_idel";
    protected JdbcPool client;
    protected DGWConfig env;
    protected JedisPool jedisPool;

    private static final String CREATE_STATIC_TABLE =
            "CREATE TABLE IF NOT EXISTS FM_META_ALARM ( "
                    + "code INT(10) NOT NULL, "
                    + "ns VARCHAR(64) NOT NULL, "
                    + "ci VARCHAR(64) NOT NULL, "
                    + "alarm_id VARCHAR(32) NOT NULL, "
                    + "alarm_name VARCHAR(64) NOT NULL, "
                    + "alarm_severity VARCHAR(32) NOT NULL, "
                    + "alarm_category VARCHAR(32) NOT NULL, "
                    + "alarm_cause_text TEXT NOT NULL, "
                    + "alarm_repair_text TEXT NOT NULL, "
                    + "alarm_effect_business TEXT NOT NULL, "
                    + "alarm_effect_device TEXT NOT NULL, "
                    + "ts bigint(20) DEFAULT NULL, "
                    + "PRIMARY KEY (alarm_id) USING BTREE, "
                    + "INDEX `alarm_name`(`alarm_name`) USING BTREE, "
                    + "INDEX `ns`(`ns`) USING BTREE "
                    + " ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='告警数据字典表' ROW_FORMAT=DYNAMIC;";

    public static final String GET_META= "SELECT * FROM FM_META_ALARM WHERE code = ?";

    public static final String QUERY_META= "SELECT * FROM FM_META_ALARM";

    public static final String BATCH_INSERT_META=
            "REPLACE INTO FM_META_ALARM(`code`,`ns`,`ci`,`alarm_id`,`alarm_name`,`alarm_severity`,`alarm_category`,`alarm_cause_text`,`alarm_repair_text`,`alarm_effect_business`,`alarm_effect_device`,`ts`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
    /**
     * 元数据缓存
     */
    private LoadingCache<String, FMMeta> metaCache;

    @Override
    public void start(DGWConfig env) throws DGWException {
        try {
            JdbcPool.Builder builder = new JdbcPool.Builder();
            this.client = builder.jdbcUri(env.getValue(JDBC_URI).toString()).jdbcUser(env.getValue(JDBC_USER).toString())
                    .jdbcPwd(env.getValue(JDBC_PWD).toString()).jdbcMaxConn(Integer.valueOf(env.getValue(JDBC_MAX_CONN).toString()))
                    .jdbcMinConn(Integer.valueOf(env.getValue(JDBC_MIN_NUM).toString()))
                    .jdbcConnTimeOut(Integer.valueOf(env.getValue(JDBC_CONN_TIMEOUT).toString()))
                    .jdbcIdelTimeOut(Integer.valueOf(env.getValue(JDBC_IDEL_TIMEOUT).toString()))
                    .jdbcReadOnly(false).jdbcAutoCommit(true).build();
            this.client.start();
            // Redis
            JedisUtil.Builder redisBuilder = JedisUtil.builder();
            redisBuilder = redisBuilder.buildURI((String)env.getValue(CONFIGURATION_HOST),
                    String.valueOf(env.getValue(CONFIGURATION_PORT)),
                    String.valueOf(env.getValue(CONFIGURATION_TIMEOUT)),
                    String.valueOf(env.getValue(CONFIGURATION_PWD)),
                    String.valueOf(env.getValue(CONFIGURATION_DB)));
            redisBuilder = redisBuilder.buildPool(String.valueOf(env.getValue(CONFIGURATION_MAX_ACTIVE)),
                    String.valueOf(env.getValue(CONFIGURATION_MAX_WAIT)),
                    String.valueOf(env.getValue(CONFIGURATION_MAX_IDEL)),
                    String.valueOf(env.getValue(CONFIGURATION_MIN_IDEL)));
            JedisUtil utils = new JedisUtil();
            utils.start(redisBuilder);
            this.jedisPool = utils.getJedisPool();
            this.env = env;
            this.createTableMeta();
            metaCache= CacheBuilder.newBuilder()
                    .maximumSize(100)
                    .recordStats()
                    .initialCapacity(100)
                    .build(new CacheLoader<String, FMMeta>() {
                        @Override
                        public FMMeta load(String code) throws Exception {
                            LOG.info("FMMeta缓存不存在，从数据库加载:K={}", code);
                            FMMeta meta = loadMeta(Integer.valueOf(code));
                            return meta;
                        }
                    });
            this.loadMetas();
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new DGWException("", e.getMessage());
        }
    }

    /**
     * @desc 创建元数据表
     * @throws SQLException
     */
    private void createTableMeta() throws SQLException {
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        runner.update(CREATE_STATIC_TABLE);
    }

    private FMMeta loadMeta(int code) throws SQLException{
        Object[] param=new Object[]{code};
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        Map<String,Object> result = runner.query(GET_META,new MapHandler(),param);
        FMMeta metaMetric = FMMeta.buildMeta(result);
        return metaMetric;
    }
    private void loadMetas() throws Exception{
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        List<Map<String,Object>> eventMaps=runner.query(QUERY_META,new MapListHandler());
        if(CollectionUtils.isEmpty(eventMaps)){
            return;
        }
        for(Map<String,Object> eventMap:eventMaps){
            FMMeta meta= FMMeta.buildMeta(eventMap);
            metaCache.put(meta.getAlarmId(),meta);
        }
    }

    private void loadRedisMetas(List<Map<String,Object>> eventMaps) throws DGWException {
        try (Jedis jedis = this.jedisPool.getResource()) {
            // 初始化删除META静态缓存数据
            Set<String> metaKeys = jedis.keys("FM:META:*");
            metaKeys.forEach(k -> jedis.del(k));
            for (Map<String,Object> eventMap : eventMaps) {
                FMMeta meta= FMMeta.buildMeta(eventMap);
                Map<String, String> metaMap = new HashMap<>();
                metaMap.put("code", String.valueOf(meta.getCode()));
                metaMap.put("alarmId", meta.getAlarmId());
                metaMap.put("alarmName", meta.getAlarmName());
                metaMap.put("alarmCategory", meta.getAlarmCategory());
                metaMap.put("alarmSeverity", meta.getAlarmSeverity());
                metaMap.put("alarmCauseText", meta.getAlarmCauseText());
                metaMap.put("alarmRepairText", meta.getAlarmRepairText());
                metaMap.put("alarmEffectBusiness", meta.getAlarmEffectBusiness());
                metaMap.put("alarmEffectDevice", meta.getAlarmEffectDevice());
                String key = "FM:META:" + meta.getCode();
                jedis.hmset(key, metaMap);
            }
        } catch (Exception e) {
            LOG.error("缓存静态告警数据失败！", e);
            throw new DGWException("", e.getMessage());
        }
    }

    /**
     * 模型注册
     * @param metas
     * @throws DGWException
     */
    @Override
    public void registerMeta(List<FMMeta> metas) throws DGWException{
        if(CollectionUtils.isEmpty(metas)){
            return;
        }
        Object[][] params = new Object[metas.size()][];
        int index=0;
        for(FMMeta meta:metas){
            params[index]=meta.getParam();
            index++;
        }
        try{
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            runner.batch(BATCH_INSERT_META,params);
            // loadRedisCache
            loadRedisMetas(runner.query(QUERY_META,new MapListHandler()));
        }catch (SQLException e){
            LOG.error(e.getSQLState(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }
    }

    /**
     * @desc 获取meta信息
     * @param code 告警code
     * @return
     * @throws DGWException
     */
    @Override
    public FMMeta getMeta(int code){
        try{
            return metaCache.get(String.valueOf(code));
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return null;
        }
    }

    @Override
    public void write(List<FMDPoint> points) throws DGWException {
        // 数据补齐
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        doWrite(points);
    }

    abstract void doWrite(List<FMDPoint> points) throws DGWException;
}
