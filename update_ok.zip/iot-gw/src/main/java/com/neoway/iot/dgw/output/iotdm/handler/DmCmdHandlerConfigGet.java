package com.neoway.iot.dgw.output.iotdm.handler;

import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotdm.DmCmd;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * @desc: 设备配置信息查询
 * @author: 20200312686
 * @date: 2020/7/17 10:22
 */
public class DmCmdHandlerConfigGet implements DmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DmCmdHandlerConfigGet.class);
    @Override
    public String name() {
        return DmCmd.CMD_CONFIG_GET.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        LOG.warn("设备配置信息查询暂未实现");
        List<Map<String,Object>> values=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(values)){
            return response;
        }
        Map<String,Object> value=values.get(0);
        String ns=event.getHeader().getDsCode();
        //根据资源ID查询热点缓存数据
        String ci=(String)value.get("ci");
        String tenent="";
        if(value.containsKey("tenent")){
            tenent=(String)value.get("tenent");
        }else{
            tenent= DMMetaCI.DEFAULT_TENENT;
        }
        //TODO
        return response;
    }
}
