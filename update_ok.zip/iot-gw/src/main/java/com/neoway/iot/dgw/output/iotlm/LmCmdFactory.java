package com.neoway.iot.dgw.output.iotlm;

import com.neoway.iot.dgw.output.iotlm.handler.LmCmdHandler;
import com.neoway.iot.dgw.output.iotlm.handler.LmCmdHandlerUplinkData;
import com.neoway.iot.dgw.output.iotlm.storage.LMDSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * <pre>
 *  描述: LmCmdFactory
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 14:48
 */
public class LmCmdFactory {
    private static final Logger LOG = LoggerFactory.getLogger(LmCmdFactory.class);
    private static Map<LmCmd, LmCmdHandler> handlers = new HashMap<>();

    public static LmCmdHandler buildHandler(String cmdId, LMDSink sink) {
        LmCmd cmd = LmCmd.valueOf(cmdId.toUpperCase());
        LmCmdHandler handler = handlers.get(cmd);
        if (null != handler) {
            return handler;
        } else if (cmd == LmCmd.UPLINK_LM_DATA) {
            handler = new LmCmdHandlerUplinkData(sink);
        } else {
            return null;
        }
        LOG.info("cmdId={},desc={}",cmd.name(),cmd.getDesc());
        handlers.put(cmd,handler);
        return handler;
    }
}
