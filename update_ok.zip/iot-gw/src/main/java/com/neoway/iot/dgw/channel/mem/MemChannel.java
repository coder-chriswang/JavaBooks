package com.neoway.iot.dgw.channel.mem;

import com.neoway.iot.dgw.channel.AbstractChannel;
import com.neoway.iot.dgw.channel.DGWChannelEvent;
import com.neoway.iot.dgw.common.DGWContext;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @desc: memchannel
 * 1:小规模场景下 可以使用此模式
 * @author: Chris(wangchao)
 * @date: 2020/7/2 10:01
 */
public class MemChannel extends AbstractChannel {
    private static final Logger LOG = LoggerFactory.getLogger(MemChannel.class);
    private static final int DEFAULT_CAPACITY = Integer.MAX_VALUE;
    private static final String CONFIGURATION_CAPACITY="dgw.channel.mem.capacity";
    private LinkedBlockingDeque<DGWChannelEvent> queue;
    private Lock lock=new ReentrantLock();
    private DGWConfig env;
    private int currentCapacity;
    private List<DGWChannelEvent> currentChannelEventList = new ArrayList<>();
    @Override
    public void start(DGWConfig config){
        String capacityStr = String.valueOf(config.getValue(CONFIGURATION_CAPACITY));
        int capacity;
        // 如果从配置中获取不到指定值，则采取队列默认size
        if (StringUtils.isBlank(capacityStr)) {
            capacity = DEFAULT_CAPACITY;
        } else {
            capacity = (Integer) config.getValue(CONFIGURATION_CAPACITY);
        }
        currentCapacity = capacity;
        queue = new LinkedBlockingDeque<>(capacity);
        this.env = config;
        super.start(config);
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration = new HashMap<>();
        configuration.put(CONFIGURATION_CAPACITY, env.getValue(CONFIGURATION_CAPACITY));
        return configuration;
    }

    @Override
    public DGWResponse doProcess(List<DGWChannelEvent> events) {
        try {
            lock.lock();
            // 存在队列满载时，增加不了元素的问题:Deque full
            // 因而处理队列，使得队列元素个数始终小于容量，不至于发生Deque full
            // 单次未能处理的数据放置currentChannelEventList中，待take处理
            if (events.size() <= (currentCapacity - queue.size())) {
                for (DGWChannelEvent event : events) {
                    this.queue.push(event);
                }
            } else {
                for (int i = 0; i < (currentCapacity - queue.size()); i++) {
                    this.queue.push(events.get(i));
                    currentChannelEventList.add(events.get(i));
                }
            }
        } finally {
            lock.unlock();
        }
        return new DGWResponse();
    }

    @Override
    public String name() {
        return "channel-mem";
    }

    @Override
    public List<DGWContext> take() throws DGWException {
        List<DGWContext> resultList = new ArrayList<>();
        try {
            lock.lock();
            if (queue.size() == 0) {
                LOG.warn("Mem队列暂无数据！");
                return null;
            }
            // 遍历队列获取数据
            queue.forEach(d -> {
                DGWContext dgwContext = d.getContext();
                if (dgwContext != null) {
                    resultList.add(dgwContext);
                }
            });
            queue.clear();
            // 每次take完队列中的数据后，若currentChannelEventList不为空，则处理其中的数据
            // 拷贝，清理，调用doProcess，放置队列中，待下次take
            if (!CollectionUtils.isEmpty(currentChannelEventList)) {
                LOG.info("处理currentChannelEventList中的数据！");
                List<DGWChannelEvent> tempList = new ArrayList<>(currentChannelEventList);
                currentChannelEventList.clear();
                this.doProcess(tempList);
            }
        } catch (Exception e) {
            LOG.error("从队列中取数据异常！", e);
            throw new DGWException("", e.getMessage());
        } finally {
            lock.unlock();
        }
        return resultList;
    }

    @Override
    public void commit(String eventId, String topic, boolean status) throws DGWException {
        LinkedBlockingDeque<DGWChannelEvent> temp = new LinkedBlockingDeque<>();
        // 更新内存queue存储的结果status，并判断是否该记录的所有subscribe-out插件都成功消费，是就从队列中清空
        try {
            lock.lock();
            if (queue.size() == 0) {
                LOG.warn("Mem队列暂无数据！");
                return;
            }
            queue.forEach(d -> {
                if (eventId.equals(d.getEventId())) {
                    Map<String, Boolean> statusMap = d.getStatus();
                    if (statusMap == null || statusMap.size() == 0) {
                        return;
                    }
                    // 如果获取的主题下消费的对象存在并且状态是false,则说明消费失败，需在队列中保留
                    if (statusMap.get(topic) != null && !statusMap.get(topic)) {
                        temp.push(d);
                    }
                }
            });
            // 并将消费失败的数据保留至队列
            queue.addAll(temp);
        } catch (Exception e) {
            LOG.error("commit数据异常！", e);
            throw new DGWException("", e.getMessage());
        } finally {
            lock.unlock();
        }
    }
}
