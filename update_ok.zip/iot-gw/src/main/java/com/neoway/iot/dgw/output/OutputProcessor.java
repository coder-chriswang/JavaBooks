package com.neoway.iot.dgw.output;

import com.google.common.eventbus.Subscribe;
import com.google.gson.Gson;
import com.neoway.iot.dgw.channel.Channel;
import com.neoway.iot.dgw.channel.ChannelManager;
import com.neoway.iot.dgw.channel.DGWChannelEvent;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.event.DGWEvent;
import com.neoway.iot.dgw.common.event.DGWEventBus;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: 固定间隔从channel获取数据并调用output处理
 * @author: 20200312686
 * @date: 2020/7/7 11:37
 */
public class OutputProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(OutputProcessor.class);
    private static final AtomicInteger NUM = new AtomicInteger();
    private static final String SCHEDULER_NAME = "output-runner";
    private static final String OUTPUT_INTERVAL = "dgw.output.pull_interval";
    private static final int DEFAULT_OUTPUT_INTERVAL = 30;
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private OutputManager manager;
    private static OutputProcessor processor = null;
    private ScheduledExecutorService pullService;

    private OutputProcessor() {
        this.manager=OutputManager.getInstance();
    }

    public static OutputProcessor getInstance() {
        if (processor == null) {
            synchronized (OutputProcessor.class) {
                if (processor == null) {
                    processor = new OutputProcessor();
                }
            }
        }
        return processor;
    }

    /**
     * @param env
     * @throws DGWException
     * @desc 启动
     */
    protected void doStart(DGWConfig env) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        LOG.info("初始化output-processor");
        String intervalStr = String.valueOf(env.getValue(OUTPUT_INTERVAL));
        int interval = DEFAULT_OUTPUT_INTERVAL;
        if (StringUtils.isNotEmpty(intervalStr)) {
            interval = Integer.valueOf(intervalStr);
        }
        this.pullService = initRunner(interval);
        //注册事件监听器
        DGWEventBus.register(this);
        isStarted.set(true);
    }
    @Subscribe
    public void recieveEvent(DGWEvent event){
        LOG.info("接收到的消息：{}",new Gson().toJson(event));
        List<Output> outputs=this.manager.getOutputs(event.header.getTopic());
        Output output=outputs.get(0);
        OutputEvent oevent = new OutputEvent(event.header);
        oevent.addEvent(event.message);
        output.process(oevent);
    }

    /**
     * @param events
     * @return
     * @desc 同步处理
     */
    public DGWResponse process(List<DGWChannelEvent> events) {
        if(CollectionUtils.isEmpty(events)){
            return new DGWResponse();
        }
        DGWChannelEvent event=events.get(0);
        DGWContext context=event.getContext();
        DGWHeader header=context.getHeader();
        List<Output> outputs=this.manager.getOutputs(header.getTopic());
        if(CollectionUtils.isEmpty(outputs)){
            LOG.warn("没有对应的output插件处理！,产品={},topic={}，cmdId={},reqId={}",
                    0,header.getTopic(),header.getCmdId(),header.getReqId());
            return new DGWResponse(DGWCodeEnum.ENDPOINT_CODE_2001.getCode(),"");
        }
        Output output=outputs.get(0);
        OutputEvent oevent = new OutputEvent(context.getHeader());
        for(DGWChannelEvent cEvent:events){
            oevent.addEvent(cEvent.getContext().getData());
        }
        return output.process(oevent);
    }

    /**
     * @param interval
     * @return 定时器服务
     * @desc 初始化pull数据定时器
     */
    private ScheduledExecutorService initRunner(int interval) {
        ScheduledExecutorService pullService = Executors.newSingleThreadScheduledExecutor(
                (r) -> {
                    Thread t = new Thread(r, SCHEDULER_NAME + NUM.incrementAndGet());
                    t.setDaemon(true);
                    return t;
                }
        );
        pullService.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try {
                    List<DGWContext> datas=pullData();
                    LOG.info("从Channel获取到的数据记录数={}",datas.size());
                    dispacher(datas);
                } catch (DGWException e) {
                    //TODO 发送
                }

            }
        }, interval, interval, TimeUnit.SECONDS);
        return pullService;
    }

    /**
     * @return
     * @throws DGWException
     * @desc 从channel拉取数据
     */
    private List<DGWContext> pullData() throws DGWException {
        List<DGWContext> results = new ArrayList<>();
        List<Channel> channels = ChannelManager.getInstance().getChannels();
        for (Channel channel : channels) {
            List<DGWContext> datas = channel.take();
            if (CollectionUtils.isEmpty(datas)) {
                continue;
            }
            results.addAll(datas);
        }
        return results;
    }

    /**
     * @desc 推送数据到output
     * @param datas
     * @throws DGWException
     */
    private void dispacher(List<DGWContext> datas) throws DGWException {
        Map<String, OutputEvent> group = new HashMap<>();
        for (DGWContext context : datas) {
            String topic = context.getHeader().getTopic();
            OutputEvent event = group.get(topic);
            if (null == event) {
                event = new OutputEvent(context.getHeader());
                group.put(topic, event);
            }
            event.addEvent(context.getData());
        }
        for (Map.Entry<String, OutputEvent> entry : group.entrySet()) {
            List<Output> outs = OutputManager.getInstance().getOutputs(entry.getKey());
            for (Output output : outs) {
                DGWResponse rsp = output.process(entry.getValue().clone());
                LOG.info("out插件:{}-数据处理结果为:code={},msg={}",output.name(),rsp.getCode(),rsp.getMsg());
            }

        }
    }


}
