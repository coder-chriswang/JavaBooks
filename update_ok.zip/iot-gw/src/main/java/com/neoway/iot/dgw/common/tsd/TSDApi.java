package com.neoway.iot.dgw.common.tsd;

/**
 * @desc: TSDApi
 * @author: 20200312686
 * @date: 2020/6/30 18:39
 */
public enum TSDApi {

    /***
     * path对应api地址
     */
    PUT("/api/put"),
    PUT_DETAIL("/api/put?details=true"),
    QUERY("/api/query"),
    LAST("/api/query/last"),
    SUGGEST("/api/suggest");

    private String path;
    TSDApi(String path) {
        this.path = path;
    }
    public String getPath() {
        return path;
    }
}
