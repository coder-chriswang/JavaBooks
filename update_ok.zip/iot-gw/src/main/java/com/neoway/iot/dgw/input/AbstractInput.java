package com.neoway.iot.dgw.input;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWRequest;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @desc: AbstractInput
 * @author: 20200312686
 * @date: 2020/6/23 16:10
 */
public abstract class AbstractInput implements Input{
    private static final Logger LOG = LoggerFactory.getLogger(AbstractInput.class);
    @Override
    public void start(DGWConfig config) throws DGWException {
        LOG.info("插件：{} 启动成功", this.name());
    }

    @Override
    public void stop() {
        LOG.info("插件：{} 停止成功", this.name());
    }

    @Override
    public boolean isEnable() {
        return true;
    }

    @Override
    public String name() {
        return "module-input";
    }
    @Override
    public DGWResponse uplink(DGWRequest req) {
        return null;
    }
}
