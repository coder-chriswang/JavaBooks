package com.neoway.iot.dgw.output.iotem.handler;

import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;

/**
 * @desc: EmCmdHandler
 * @author: 20200312686
 * @date: 2020/7/20 17:11
 */
public interface EmCmdHandler {
    /**
     * @desc
     * @return cmd指令名称
     */
    String name();

    /**
     * @desc 指令处理
     * @param event 数据
     * @return
     */
    DGWResponse execute(OutputEvent event);
}
