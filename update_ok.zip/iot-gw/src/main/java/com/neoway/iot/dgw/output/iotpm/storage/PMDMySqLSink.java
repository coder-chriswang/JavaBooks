package com.neoway.iot.dgw.output.iotpm.storage;

import com.google.common.hash.Hashing;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.tsd.TSDPoint;
import org.apache.commons.codec.Charsets;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: 性能数据-mysql存储实现
 * * +----------------------+
 * * | TSD_VALUE           |
 * * +----------------------+
 * * | INSTANCEID  : STRING  |
 * * | TS          : INTEGER |
 * * | METRIC      : STRING  |
 * * | VALUE      : FLOAT    |
 * * | TAGS      : JSON    |
 * * +----------------------+
 * @author: 20200312686
 * @date: 2020/7/1 9:57
 */
public class PMDMySqLSink extends PMDAbstractSink {
    private static final Logger LOG = LoggerFactory.getLogger(PMDMySqLSink.class);
    public static final String PARTITION = "dgw.output.pm.mysql.partition";
    private static final String TABLE_NAME = "PM_VALUE";
    //建表语句
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS %s ( "
            + "instanceid BIGINT NOT NULL, "
            + "metric int(10) NOT NULL, "
            + "ts INT(10) NOT NULL, "
            + "value FLOAT NOT NULL, "
            + "tags JSON, "
            + "PRIMARY KEY(instanceid,metric,ts) "
            + " ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='指标时序数据' ROW_FORMAT=DYNAMIC;";

    //批量插入语句
    public static final String BATCH_INSERT=
            "REPLACE INTO {0}(`instanceid`,`metric`,`ts`,`value`) VALUES(?,?,?,?)";
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private int partition=1;

    @Override
    public void start(DGWConfig env) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        super.start(env);
        try {
            this.partition=(Integer) env.getValue(PARTITION);
            if(this.partition < 1){
                this.partition = 1;
            }
            this.createTableIfNotExsit(this.partition);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new DGWException("", e.getMessage());
        }

        isStarted.set(true);
        LOG.info("pm-out-mysql-sink启动成功");
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration=new HashMap<>();
        configuration.put(JDBC_URI,env.getValue(JDBC_URI));
        configuration.put(JDBC_USER,env.getValue(JDBC_USER));
        configuration.put(JDBC_PWD,env.getValue(JDBC_PWD));
        configuration.put(JDBC_MAX_CONN,env.getValue(JDBC_MAX_CONN));
        configuration.put(JDBC_MIN_NUM,env.getValue(JDBC_MIN_NUM));
        configuration.put(JDBC_CONN_TIMEOUT,env.getValue(JDBC_CONN_TIMEOUT));
        configuration.put(JDBC_IDEL_TIMEOUT,env.getValue(JDBC_IDEL_TIMEOUT));
        return configuration;
    }

    /**
     * 创建数据表
     */
    private void createTableIfNotExsit(int partition) throws SQLException {
        for(int index = 0; index<partition;index++){
            String tableName=TABLE_NAME+"_"+index;
            String sql=String.format(CREATE_TABLE,tableName);
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            runner.update(sql);
        }

    }
    /**
     * @desc 生成写入sql
     * @param point 数据点
     * @return 参数
     */
    private Object[] getParam(TSDPoint point) throws Exception {
        Map<String,String> tag=point.getTags();
        if(StringUtils.isEmpty(point.getMetric())
                || point.getTimestamp() <= 0
                || MapUtils.isEmpty(tag)){
            return null;
        }
        if(StringUtils.isEmpty(tag.get(PMDAbstractSink.INSTANCEID))){
            return null;
        }
        PmMetaMetric metaMetric=this.getMeta(point.getMetric());
        Object[] param=new Object[]{
                tag.get(PMDAbstractSink.INSTANCEID),
                metaMetric.getCode(),
                point.getTimestamp(),
                point.getValue()
        };
        return param;
    }

    /**
     * @desc 定位数据表
     * @param point
     * @return
     */
    private String getTable(TSDPoint point){
        String instanceid=point.getTags().get(PMDAbstractSink.INSTANCEID);
        int bucket=Hashing.consistentHash(Hashing.md5().hashString(instanceid, Charsets.UTF_8),this.partition);
        String table=TABLE_NAME+"_"+bucket;
        return table;
    }

    @Override
    void doWrite(List<TSDPoint> points) throws DGWException {
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        Map<String,List<Object[]>> groupMap=new HashMap<>();
        try{
            for(TSDPoint point:points){
                String table=getTable(point);
                Object[] param=getParam(point);
                if(null == param){
                    continue;
                }
                List<Object[]> params=groupMap.get(table);
                if(null == params){
                    params=new ArrayList<>();
                    groupMap.put(table,params);
                }
                params.add(param);
            }
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            for(Map.Entry<String,List<Object[]>> entry:groupMap.entrySet()){
                Object[][] params=new Object[entry.getValue().size()][];
                String sql=MessageFormat.format(BATCH_INSERT,entry.getKey());
                params=entry.getValue().toArray(params);
                runner.batch(sql,params);

            }
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }

    }


}
