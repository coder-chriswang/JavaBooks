package com.neoway.iot.dgw.output.iotfm.storage;

/**
 * <pre>
 *  描述: FMDPoint
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/09 14:48
 */
public class FMDPoint {
    /**
     * 告警序列号
     */
    private long serialNo;
    private String alarmId;
    private String alarmSource;
    private long alarmSt;
    private long alarmEt;
    private int alarmStatus;
    private String alarmDesc;
    private String instanceId;
    private String tenantId;
    private String nativeId;
    private String instanceName;
    private String ci;
    private String ns;

    public long getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(long serialNo) {
        this.serialNo = serialNo;
    }

    public String getAlarmId() {
        return alarmId;
    }

    public void setAlarmId(String alarmId) {
        this.alarmId = alarmId;
    }

    public String getAlarmSource() {
        return alarmSource;
    }

    public void setAlarmSource(String alarmSource) {
        this.alarmSource = alarmSource;
    }

    public long getAlarmSt() {
        return alarmSt;
    }

    public void setAlarmSt(long alarmSt) {
        this.alarmSt = alarmSt;
    }

    public long getAlarmEt() {
        return alarmEt;
    }

    public void setAlarmEt(long alarmEt) {
        this.alarmEt = alarmEt;
    }

    public int getAlarmStatus() {
        return alarmStatus;
    }

    public void setAlarmStatus(int alarmStatus) {
        this.alarmStatus = alarmStatus;
    }

    public String getAlarmDesc() {
        return alarmDesc;
    }

    public void setAlarmDesc(String alarmDesc) {
        this.alarmDesc = alarmDesc;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public Object[] getParam() {
        Object[] param = new Object[]{
                this.getAlarmId(),
                this.getInstanceId(),
                this.getInstanceName(),
                this.getCi(),
                this.getAlarmSource(),
                this.getAlarmSt(),
                this.getAlarmEt(),
                this.getAlarmStatus(),
                this.getAlarmDesc(),
                this.getNativeId(),
                this.getTenantId()
        };
        return param;
    }
}
