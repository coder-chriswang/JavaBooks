package com.neoway.iot.dgw.common;

import com.google.gson.Gson;
import org.apache.commons.collections4.MapUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @desc: DGWContext
 * @author: 20200312686
 * @date: 2020/6/23 9:59
 */
public class DGWContext implements Cloneable {
    public static final String CONTEXT_BODY="body";
    private DGWHeader header;
    private Map<String,Object> data;
    public DGWContext(){
    }
    public DGWContext(DGWHeader header,Map<String,Object> data) {
        this.header=header;
        this.data=data;
    }

    public DGWHeader getHeader() {
        return header;
    }

    public void setHeader(DGWHeader header) {
        this.header = header;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    @Override
    public DGWContext clone() {
        Gson gson=new Gson();
        DGWContext context = new Gson().fromJson(gson.toJson(this),DGWContext.class);
        return context;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DGWContext context = (DGWContext) o;
        return Objects.equals(header, context.header);
    }

    @Override
    public int hashCode() {
        return Objects.hash(header);
    }

    /**
     * @desc 解码数据
     * @return
     */
    public List<Map<String,Object>> decodeData(){
        List<Map<String,Object>> values=new ArrayList<>();
        if(MapUtils.isEmpty(this.data)){
            return values;
        }
        Object value=this.data.get(CONTEXT_BODY);
        if(List.class.isInstance(value)){
            List<Map<String,Object>> vv=(List)value;
            for(Map<String,Object> singleD:vv){
                values.add(singleD);
            }
        }
        return values;
    }
}
