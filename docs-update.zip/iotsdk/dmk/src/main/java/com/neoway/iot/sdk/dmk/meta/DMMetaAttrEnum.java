package com.neoway.iot.sdk.dmk.meta;

public enum DMMetaAttrEnum {
    ATTR_TYPE_SHORT("short","tinyint(2)"),
    ATTR_TYPE_INT("int","int(10)"),
    ATTR_TYPE_LONG("long","bigint(11)"),
    ATTR_TYPE_FLOAT("float","decimal"),
    ATTR_TYPE_STRING("string","varchar(128)"),
    ATTR_TYPE_CHAR("char","varchar(32)"),
    ATTR_TYPE_TEXT("text","text"),
    ATTR_TYPE_JSON("json","json");
    private String dtype;
    private String btype;
    private DMMetaAttrEnum(String dtype,String btype){
        this.dtype=dtype;
        this.btype=btype;
    }

    public String getDtype() {
        return dtype;
    }

    public void setDtype(String dtype) {
        this.dtype = dtype;
    }

    public String getBtype() {
        return btype;
    }

    public void setBtype(String btype) {
        this.btype = btype;
    }

    public static boolean validate(String type){
        DMMetaAttrEnum[] typeEnums=DMMetaAttrEnum.values();
        for(DMMetaAttrEnum typeEnum:typeEnums){
            if(typeEnum.getDtype().equals(type)){
                return true;
            }
        }
        return false;
    }

    public static DMMetaAttrEnum getMetaAttrEnum(String type){
        DMMetaAttrEnum[] typeEnums=DMMetaAttrEnum.values();
        for(DMMetaAttrEnum typeEnum:typeEnums){
            if(typeEnum.getDtype().equals(type)){
                return typeEnum;
            }
        }
        return null;
    }
}
