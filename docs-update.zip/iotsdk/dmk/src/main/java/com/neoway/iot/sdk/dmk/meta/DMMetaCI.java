package com.neoway.iot.sdk.dmk.meta;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @desc: 元数据-对象类型
 * @author: 20200312686
 * @date: 2020/6/22 12:59
 */
public class DMMetaCI {
    private static final Logger LOG = LoggerFactory.getLogger(DMMetaCI.class);
    private static final String CI_ACTION_XPATH = "/ci/actions/action";
    private static final String CI_ATTRS_XPATH = "/ci/attrs/attr";
    public static final String TABLE_PREFFIX="CI_";
    public static final String TABLESPILITE="_";
    public static final String DEFAULT_TENENT="default";
    //资源表
    public static final String TYPE_P="R";
    //资源业务表
    public static final String TYPE_B="B";
    //产品域
    public String ns;
    //租户域
    public String tenent;
    //对象类型
    public String ci;
    //对象类型
    public String type;
    //对象名称
    public String name;
    //对象描述
    public String desc;
    //更新时间
    public int update_ts;
    //属性集合
    public List<DMMetaAttr> attrs=new ArrayList<>();
    //指令集合
    public List<DMMetaAction> actions=new ArrayList<>();

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public DMMetaCI(){

    }
    public DMMetaCI(String ns,String tenent,String ci){
        this.ci=ci;
        this.tenent=tenent;
        this.ns=ns;
    }
    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public List<DMMetaAttr> getAttrs() {
        return attrs;
    }

    public void setAttrs(List<DMMetaAttr> attrs) {
        this.attrs = attrs;
    }

    public void addAttr(DMMetaAttr attr){
        this.attrs.add(attr);
    }
    public List<DMMetaAction> getActions() {
        return actions;
    }

    public void setActions(List<DMMetaAction> actions) {
        this.actions = actions;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public void addAction(DMMetaAction action){
        this.actions.add(action);
    }

    public String getTenent() {
        return tenent;
    }

    public void setTenent(String tenent) {
        this.tenent = tenent;
    }

    public int getUpdate_ts() {
        return update_ts;
    }

    public void setUpdate_ts(int update_ts) {
        this.update_ts = update_ts;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DMMetaCI metaCI = (DMMetaCI) o;
        return Objects.equals(ns, metaCI.ns) &&
                Objects.equals(tenent, metaCI.tenent) &&
                Objects.equals(ci, metaCI.ci);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ns, tenent, ci);
    }

    /**
     * 构建表名
     * @return
     */
    public String getTable(){
        StringBuilder sb=new StringBuilder();
        if(this.type.equals(TYPE_P)){
            sb.append(TABLE_PREFFIX).append(TYPE_P).append(TABLESPILITE).append(ci.toUpperCase());
        }else{
            sb.append(TABLE_PREFFIX).append(TYPE_B).append(TABLESPILITE).append(ci.toUpperCase());
        }

        return sb.toString();
    }

    /**
     * @desc 获取insert参数
     * @return
     */
    public Object[] getParams(){
        Object[] params={this.getNs(),this.getTenent(),this.getCi(),this.getName(),this.getType(),
                this.getDesc(),System.currentTimeMillis()/1000};
        return params;
    }
    /**
     * @desc 获取insert参数-属性对象
     * @return
     */
    public Object[][] getAttrParams(){
        Object[][] params=new Object[this.getAttrs().size()][];
        int index=0;
        for(DMMetaAttr attr:this.getAttrs()){
            params[index]=attr.getParams();
            index++;
        }
        return params;
    }
    /**
     * @desc 获取insert参数-Action对象
     * @return
     */
    public Object[][] getActionsParams(){
        Object[][] params=new Object[this.getActions().size()][];
        int index=0;
        for(DMMetaAction action:this.getActions()){
            params[index]=action.getParams();
            index++;
        }
        return params;
    }
    /**
     * 根据属性ID获取属性对象
     * @param attrId 属性ID
     * @return
     */
    public DMMetaAttr getAssignAttr(String attrId){
        if(CollectionUtils.isEmpty(this.getAttrs())){
            return null;
        }
        for(DMMetaAttr metaAttr:this.getAttrs()){
            if(metaAttr.getId().equals(attrId)){
                return metaAttr;
            }
        }
        return null;
    }

    /**
     * 根据指令ID获取指令对象
     * @param actionId
     * @return
     */
    public DMMetaAction getAssignAction(String actionId){
        if(CollectionUtils.isEmpty(this.getActions())){
            return null;
        }
        for(DMMetaAction metaAction:this.getActions()){
            if(metaAction.getId().equals(actionId)){
                return metaAction;
            }
        }
        return null;
    }

    /**
     * @param metaPath
     * @return
     * @desc
     */
    public static DMMetaCI buildMetaCI(String metaPath, DMMMetaNs ns){
        File f = new File(metaPath);
        if (!f.exists()) {
            String erMsgTpl="dm模型文件不存在。ns={0},文件路径={1}";
            String errMsg= MessageFormat.format(erMsgTpl,ns.getId(),metaPath);
            throw new RuntimeException(errMsg);
        }
        SAXReader saxReader = new SAXReader();
        Document doc;
        try {
            doc = saxReader.read(f);
        } catch (DocumentException e) {
            LOG.error(e.getMessage(),e);
            String erMsgTpl="dm模型文件格式非法。ns={0},文件路径={1}";
            String errMsg= MessageFormat.format(erMsgTpl,ns.getId(),metaPath);
            throw new RuntimeException(errMsg);
        }
        Element root = doc.getRootElement();
        DMMetaCI metaCI = new DMMetaCI();
        metaCI.setNs(ns.getId());
        Element el = root.element("tenent");
        if(null != el){
            metaCI.setTenent(el.getTextTrim());
        }else{
            metaCI.setTenent(DEFAULT_TENENT);
        }

        el = root.element("id");
        metaCI.setCi(el.getTextTrim());
        el = root.element("name");
        if (null != el) {
            metaCI.setName(el.getTextTrim());
        }
        el = root.element("desc");
        if (null != el) {
            metaCI.setDesc(el.getTextTrim());
        }
        el = root.element("type");
        if (null != el) {
            metaCI.setType(el.getTextTrim());
        }
        List<Node> actions = doc.selectNodes(CI_ACTION_XPATH);
        if (null != actions) {
            for (Node actionNode : actions) {
                DMMetaAction action = DMMetaAction.buildMetaAction(actionNode, metaCI);
                metaCI.addAction(action);
            }
        }
        List<Node> attrs = doc.selectNodes(CI_ATTRS_XPATH);
        if (null != attrs) {
            for (Node attrNode : attrs) {
                DMMetaAttr attr = DMMetaAttr.buildMetaAttr(attrNode, metaCI);
                metaCI.addAttr(attr);
            }
        }
        try{
            metaCI.validate();
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw e;
        }

        return metaCI;
    }

    /**
     * @desc 参数校验
     */
    public void validate(){
        if(StringUtils.isEmpty(this.ci)){
            String erMsgTpl="ci属性为空。ns={0}！";
            String errMsg= MessageFormat.format(erMsgTpl,this.ns);
            throw new RuntimeException(errMsg);
        }
        if(StringUtils.isEmpty(this.name)){
            String erMsgTpl="ci属性-name为空。ns={0},ci={1}";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci);
            throw new RuntimeException(errMsg);
        }
        if(StringUtils.isEmpty(this.type) || !(type.equals(TYPE_B) || type.equals(TYPE_P))){
            String erMsgTpl="ci属性-type参数非法。ns={0},ci={1},type={2}";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci,type);
            throw new RuntimeException(errMsg);
        }
        if(CollectionUtils.isEmpty(this.getAttrs())){
            String erMsgTpl="ci属性-attrs为空。ns={0},ci={1}";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci);
            throw new RuntimeException(errMsg);
        }
        if(CollectionUtils.isEmpty(this.getActions())){
            String erMsgTpl="ci属性-actions为空。ns={0},ci={1}";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci);
            throw new RuntimeException(errMsg);
        }
        for(DMMetaAttr attr:this.getAttrs()){
            attr.validate();
        }
        for(DMMetaAction action:this.getActions()){
            action.validate();
        }
    }
}
