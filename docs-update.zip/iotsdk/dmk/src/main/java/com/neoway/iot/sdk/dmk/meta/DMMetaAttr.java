package com.neoway.iot.sdk.dmk.meta;

import com.google.gson.Gson;
import com.neoway.iot.sdk.dmk.DMUtil;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Element;
import org.dom4j.Node;

import java.text.MessageFormat;
import java.util.*;

/**
 * @desc: 元数据-属性管理
 * @author: 20200312686
 * @date: 2020/6/22 12:53
 */
public class DMMetaAttr {
    public String ns;
    //租户域
    public String tenent;
    //对象类型
    public String ci;
    //属性ID
    public String id;
    //属性名称
    public String name;
    //属性描述
    public String desc;
    //属性校验表达式
    public String validate;
    //属性类型
    public String type;
    @DMMetaColumnDBAnno(column = "is_primary",type = boolean.class)
    public boolean primary;
    @DMMetaColumnDBAnno(column = "is_index",type = boolean.class)
    public boolean index;
    //属性支持的操作指令
    @DMMetaColumnDBAnno(column = "support_actions",type = String.class)
    public List<String> supportAction=new ArrayList<>();
    //属性扩展描述
    @DMMetaColumnDBAnno(column = "ext",type = Map.class)
    public Map<String,Object> ext=new HashMap<>();

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public List<String> getSupportAction() {
        return supportAction;
    }

    public void setSupportAction(List<String> supportAction) {
        this.supportAction = supportAction;
    }
    public void setSupportAction(String  supportActions) {
        String[] actions=supportActions.split(",");
        for(String action:actions){
            this.addSupportAction(action);
        }
    }
    public void addSupportAction(String action){
        this.supportAction.add(action);
    }

    public String getSupportActionStr(){
        StringBuilder sb=new StringBuilder();
        int index=0;
        for(String action:this.getSupportAction()){
            index++;
            sb.append(action);
            if(index < this.getSupportAction().size()){
                sb.append(",");
            }
        }
        return sb.toString();
    }
    public Map<String, Object> getExt() {
        return ext;
    }

    public String getExtJson(){

        if(MapUtils.isEmpty(this.getExt())){
            return null;
        }else{
            Gson gson=new Gson();
            return gson.toJson(this.getExt());
        }
    }

    public void setExt(Map<String, Object> ext) {
        this.ext = ext;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValidate() {
        return validate;
    }

    public void setValidate(String validate) {
        this.validate = validate;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public boolean isIndex() {
        return index;
    }

    public void setIndex(boolean index) {
        this.index = index;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getTenent() {
        return tenent;
    }

    public void setTenent(String tenent) {
        this.tenent = tenent;
    }

    /**
     * @desc 获取insert参数
     * @return
     */
    public Object[] getParams(){
        Object[] params={this.getNs(),this.getTenent(),this.getCi(),this.getId(),this.getName(),
                this.getDesc(),this.getValidate(),this.getType(),this.isPrimary(),this.isIndex(),
                this.getSupportActionStr(),this.getExtJson(),System.currentTimeMillis()/1000};
        return params;
    }

    /**
     * @desc 数据库建表列语句
     * @return
     */
    public String buildAttrColumn(){
        StringBuilder sb=new StringBuilder();
        sb.append("`").append(this.id.toLowerCase()).append("` ");
        DMMetaAttrEnum attrEnum=DMMetaAttrEnum.getMetaAttrEnum(this.type);
        if(null == attrEnum){
            return "";
        }
        sb.append(attrEnum.getBtype()).append(" ");
        if(this.isPrimary() || this.isIndex()){
            sb.append("NOT NULL ");
        }
        sb.append("COMMENT ").append("'").append(this.getName()).append("'");
        return sb.toString();
    }
    /**
     * @desc
     * @param node
     * @param metaCI
     * @return
     */
    public static DMMetaAttr buildMetaAttr(Node node, DMMetaCI metaCI) {
        DMMetaAttr metaAttr = new DMMetaAttr();
        metaAttr.setCi(metaCI.getCi());
        metaAttr.setNs(metaCI.getNs());
        metaAttr.setTenent(metaCI.getTenent());
        Element root = (Element) node;
        Element el = root.element("desc");
        if (null != el) {
            metaAttr.setDesc(el.getTextTrim());
        }
        el = root.element("id");
        if (null != el) {
            metaAttr.setId(el.getTextTrim());
        }
        el = root.element("name");
        if (null != el) {
            metaAttr.setName(el.getTextTrim());
        }
        el = root.element("type");
        if (null != el) {
            metaAttr.setType(el.getTextTrim());
        }
        el = root.element("validate");
        if (null != el) {
            metaAttr.setValidate(el.getTextTrim());
        }
        el = root.element("is_primary");
        if (null != el) {
            metaAttr.primary = Boolean.valueOf(el.getTextTrim());
        }
        el = root.element("is_index");
        if (null != el) {
            metaAttr.index = Boolean.valueOf(el.getTextTrim());
        }
        el = root.element("support_action");
        if (null != el) {
            String actions = el.getTextTrim();
            if (!StringUtils.isEmpty(actions)) {
                String[] actionArr = actions.split(",");
                for (String action : actionArr) {
                    metaAttr.addSupportAction(action);
                }
            }
        }

        return metaAttr;
    }
    public void validate(){
        if(StringUtils.isEmpty(this.id)){
            String erMsgTpl="attr属性非法。ns={0},ci={1},id为空！";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci);
            throw new RuntimeException(errMsg);
        }
        if(!DMMetaAttrEnum.validate(this.type)){
            String erMsgTpl="attr属性-type非法。ns={0},ci={1},属性id={2}！";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci,this.id);
            throw new RuntimeException(errMsg);
        }
    }

    /**
     * @desc 数据校验
     * @param value
     * @return
     */
    public boolean validate(Object value){
        return true;
    }

}
