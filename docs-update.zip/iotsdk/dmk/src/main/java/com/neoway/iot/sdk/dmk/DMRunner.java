package com.neoway.iot.sdk.dmk;

import com.neoway.iot.sdk.dmk.data.*;
import com.neoway.iot.sdk.dmk.meta.DMMMetaNs;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaCache;
import com.neoway.iot.sdk.dmk.meta.DMMetaDdl;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: DMK操作入口类
 * @author: 20200312686
 * @date: 2020/6/22 19:45
 */
public class DMRunner {
    private static final Logger LOG = LoggerFactory.getLogger(DMRunner.class);
    private static DMRunner runner=null;
    private DMMetaCache cache;
    private DMCache dcache;
    private DMRunner(){
    }
    public static DMRunner getInstance(){
        if(runner == null){
            synchronized (DMRunner.class){
                if(runner == null){
                    runner=new DMRunner();
                }
            }
        }
        return runner;
    }

    /**
     * @desc dmk启动初始化
     * @param pro dmk初始化变量
     */
    public void start(Map<String,Object> pro){
        DMEnv.getInstance().start(pro);
        DMPool.getInstance().start();
        try{
            DMMetaDdl.createAresTable();
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="创建Ares元数据存储表失败,失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }
        this.cache=DMMetaCache.getInstance();
        this.cache.start();
        DMCacheBuilder.getInstance().start();
        this.dcache=DMCacheBuilder.getInstance().getCache();
    }

    /**
     * @desc dmk停止
     */
    public void stop(){
        DMCacheBuilder.getInstance().stop();
        this.cache.stop();
        DMPool.getInstance().stop();
        DMEnv.getInstance().stop();
    }
    /**
     * 添加模型
     * @param path 模型文件目录
     * @param ns 产品域
     */
    public void addMeta(String path,DMMMetaNs ns) throws RuntimeException{
        File f = new File(path);
        if (!f.exists()) {
            String erMsgTpl="dm模型目录文件不存在。ns={0},文件路径={1}";
            String errMsg= MessageFormat.format(erMsgTpl,ns.getId(),path);
            throw new RuntimeException(errMsg);
        }
        File[] fs = f.listFiles();
        if (null == fs) {
            LOG.warn("目录下未发现dm模型文件.ns={}，文件路径={}",ns.getId(),path);
            return;
        }
        for (File dmf : fs) {
            DMMetaCI metaCI = DMMetaCI.buildMetaCI(dmf.getAbsolutePath(), ns);
            this.addMeta(ns,metaCI);
        }
        return;
    }
    /**
     * @desc 添加模型
     * @param ns
     * @param metaCi
     * @throws Exception
     */
    public void addMeta(DMMMetaNs ns,DMMetaCI metaCi){
        LOG.info("添加模型对象:ns={},ci={}",ns.getId(),metaCi.getCi());
        try{
            //判断是否已经创建了该产品域库模型
            if(!this.cache.exsitNs(ns.getId())){
                //创建产品域资源库
                DMMetaDdl.initNSDB(ns);
                //更新缓存
                this.cache.writeNsCache(ns);
            }
            if(!this.cache.exsitMetaCI(metaCi)){
                //创建产品域资源库表
                DMMetaDdl.createMetaTable(metaCi);
                //添加资源模型源数据
                DMMetaDdl.addMetaCI(metaCi);
                //更新缓存模型
                this.cache.write(metaCi);
            }

        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="初始化模型失败。ns={0},ci={1},失败原因={2}";
            String errMsg= MessageFormat.format(erMsgTpl,ns.getId(),metaCi.getCi(),e.getMessage());
            throw new RuntimeException(errMsg);
        }finally {
            LOG.info("添加模型对象结束:ns={},ci={}",ns.getId(),metaCi.getCi());
        }

    }
    /**
     * @desc 资源写入
     * @param datas 资源列表
     */
    public void write(List<DMDataPoint> datas){
        if(CollectionUtils.isEmpty(datas)){
            return;
        }
        Map<DMMetaCI,List<DMDataPoint>> group=new HashMap<>();
        for(DMDataPoint point:datas){
            List<DMDataPoint> groupDatas=group.get(point.getMetaCI());
            if(CollectionUtils.isEmpty(groupDatas)){
                groupDatas=new ArrayList<>();
                group.put(point.getMetaCI(),groupDatas);
            }
            groupDatas.add(point);
        }
        try{
            for(List<DMDataPoint> values:group.values()){
                DMDml.addDatas(values);
            }
        }catch (SQLException e){
            e.printStackTrace();
            LOG.error(e.getMessage(),e);
            String erMsgTpl="资源写入失败。失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }
    }
    /**
     * @desc 资源写入
     * @param data 资源
     */
    public void write(DMDataPoint data){
        try{
            DMDml.addData(data);
        }catch (SQLException e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="资源写入失败。失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }
    }
    /**
     * @desc 资源查询
     * @param condition 查询条件
     * @return 资源列表
     */
    public List<DMDataPoint> read(DMDataPoint condition){
        return null;
    }

    /**
     * @desc 根据原始ID查询资源缓存数据
     * @param data
     * @return
     */
    public DMDataPoint getHotByNativeId(DMDataPoint data){
        return null;
    }
    /**
     * @desc 根据资源ID查询资源缓存数据
     * @param data
     * @return
     */
    public DMDataPoint getHot(DMDataPoint data){
        return null;
    }


    /**
     * @desc 添加国际化词条
     * @param ns 产品域
     * @param lan 语言
     * @param value 词条信息
     */
    public void addI18n(String ns,String lan,Map<String,Object> value){

    }
}
