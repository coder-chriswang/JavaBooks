package com.neoway.iot.sdk.dmk.data;

import com.neoway.iot.sdk.dmk.DMEnv;

/**
 * @desc: DMCache-工厂构造
 * @author: 20200312686
 * @date: 2020/6/22 13:51
 */
public class DMCacheBuilder {
    private static DMCacheBuilder builder=null;
    private DMCache cache;
    private DMEnv env;
    private DMCacheBuilder(){
        env=DMEnv.getInstance();
        this.cache=build();
    }
    public static DMCacheBuilder getInstance(){
        if (builder == null) {
            synchronized (DMCacheBuilder.class) {
                if (builder == null) {
                    builder = new DMCacheBuilder();
                }
            }
        }
        return builder;
    }
    private DMCache build(){
        DMCache cache;
        if(env.getValue(DMCache.CACHE_KEY).equals(DMCache.CACHE_REDIS)){
            cache=new DMCacheWithRedis();
        }else if(env.getValue(DMCache.CACHE_KEY).equals(DMCache.CACHE_MEM)){
            cache=new DMCacheWithGuava();
        }else{
            cache=new DMCacheWithGuava();
        }
        return cache;
    }
    public DMCache getCache() {
        return cache;
    }
    public void start(){
        this.cache.load();
    }
    public void stop(){
        this.cache.load();
    }
}
