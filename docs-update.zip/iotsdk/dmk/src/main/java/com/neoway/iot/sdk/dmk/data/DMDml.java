package com.neoway.iot.sdk.dmk.data;

import com.neoway.iot.sdk.dmk.DMPool;
import com.neoway.iot.sdk.dmk.DMSQL;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: DM DML操作
 * @author: 20200312686
 * @date: 2020/6/22 13:19
 */
public class DMDml {
    private static final Logger LOG = LoggerFactory.getLogger(DMDml.class);
    /**
     * @param point 数据
     * @desc 数据写入操作
     */
    public static void addData(DMDataPoint point) throws SQLException {
        //3：写入对象详情表
        String ns=point.getMetaCI().getNs();
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns));
        String sql= point.buildAddSQL();
        Object[] params= point.buildAddParams();
        runner.update(sql,params);
    }

    /**
     * @param points 数据集
     * @desc 批量写入数据
     */
    public static void addDatas(List<DMDataPoint> points) throws SQLException {
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        DMDataPoint point= points.get(0);
        String sql= point.buildAddSQL();
        Object[][] params=new Object[points.size()][];
        for(int index=0;index<points.size();index++){
            point= points.get(index);
            params[index]= point.buildAddParams();
        }
        String ns=point.getMetaCI().getNs();
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns));
        runner.batch(sql,params);
    }

    /**
     * @param point 查询条件
     * @return 对象详情
     * @desc 查询详情
     */
    public static DMDataPoint get(DMDataPoint point) {
        try {
            String ns=point.getMetaCI().getNs();
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns));
            Map<String, Object> value = runner.query(DMSQL.DML_CI_INSTANCE_GET.getSql(), new MapHandler());
            //data.setData(value);
            return point;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @param data 查询条件
     * @return 数据集
     * @desc 条件查询
     */
    public static List<DMDataPoint> query(DMDataPoint data) {
        List<DMDataPoint> results = new ArrayList<>();
       /* try {
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
            Object[] where = {createCondition(data)};
            List<Map<String, Object>> values = runner.query(
                    DMSQL.DML_CI_INSTANCES_GET.getSql(),
                    new MapListHandler(),
                    where);
            LOG.debug(DMSQL.DML_CI_INSTANCES_GET.getName() + "={},params={}",DMSQL.DML_CI_INSTANCES_GET.getSql(),where);
            for (Map<String, Object> value : values) {
                DMData dd = new DMData(value);
                results.add(dd);
            }
            return results;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }*/
       return results;
    }

    private static String createCondition(DMDataPoint data){
        StringBuilder sb=new StringBuilder();
       /* Map<String,Object> conditions=data.DMDataPoint();
        DMMetaCI metaCI= DMMetaCache.getInstance().getMetaCI(data.getNs(),data.getTenent(),data.getCi());
        int index=0;
        for(Map.Entry<String,Object> entry:conditions.entrySet()){
            DMMetaAttr metaAttr=metaCI.getAssignAttr(entry.getKey());
            if(metaAttr.getType().equals(DMMetaAttrEnum.ATTR_TYPE_INT.getDtype())
                || metaAttr.getType().equals(DMMetaAttrEnum.ATTR_TYPE_FLOAT.getDtype())){
                sb.append(entry.getKey()).append("=").append(entry.getValue());
            }else if(metaAttr.getType().equals(DMMetaAttrEnum.ATTR_TYPE_STRING.getDtype())){
                sb.append(entry.getKey()).append("=").append("'").append(entry.getValue()).append("'");
            }else{
                sb.append(entry.getKey()).append("=").append("'").append(entry.getValue()).append("'");
            }
            index++;
            if(index != conditions.size()){
                sb.append(" and ");
            }
        }*/
        return sb.toString();
    }
}
