package com.neoway.iot.sdk.dmk.data;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: DMCache-Guava实现类
 * @author: 20200312686
 * @date: 2020/6/22 13:49
 */
public class DMCacheWithGuava implements DMCache {
    private Map<String,Object> cache=new HashMap<>();
    @Override
    public void load() {
        //读取公共对象实例表数据，写入cache
    }

    @Override
    public void clear() {
        this.cache.clear();
    }

    @Override
    public void write(DMDataPoint data) {
    }

    @Override
    public DMDataPoint read(DMDataPoint data) {
        return null;
    }

    @Override
    public void remove(DMDataPoint data) {

    }
}
