package com.neoway.iot.sdk.dmk.data;

import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;

import java.text.MessageFormat;

/**
 * @desc: DMDataColumn
 * @author: 20200312686
 * @date: 2020/7/14 13:38
 */
public class DMDataColumn {
    public static final String SPECIAL_COLUMN_CI="ci";
    public static final String SPECIAL_COLUMN_TENENT="tenent";
    public String column;
    public Object value;
    public DMDataColumn(String column,Object value){
        this.column=column;
        this.value=value;
    }

    /**
     * @desc 属性校验
     */
    public boolean validateField(DMMetaCI metaCI){
        DMMetaAttr metaAttr=metaCI.getAssignAttr(this.column);
        if(metaAttr == null ){
            if(metaCI.getType().equals(DMMetaCI.TYPE_B)
                    &&(this.column.equalsIgnoreCase(SPECIAL_COLUMN_CI)
                    || this.column.equalsIgnoreCase(SPECIAL_COLUMN_TENENT))){
                return false;
            }
            String msg="添加数据失败，原因=属性不存在。产品域={0},租户={1},ci={2},属性={3}";
            String errMsg= MessageFormat.format(msg,
                    metaCI.getNs(),metaCI.getTenent(),metaCI.getCi(),this.column);
            throw new RuntimeException(errMsg);
        }
        if(!metaAttr.validate(this.value)){
            String msg="添加数据失败，原因=数据格式非法。产品域={0},租户={1},ci={2},属性={3},值={4}.期望的格式为：{5}";
            String errMsg= MessageFormat.format(msg,
                    metaCI.getNs(),metaCI.getTenent(),metaCI.getCi(),this.column,this.value,metaAttr.getValidate());
            throw new RuntimeException(errMsg);
        }
        return true;
    }
}
