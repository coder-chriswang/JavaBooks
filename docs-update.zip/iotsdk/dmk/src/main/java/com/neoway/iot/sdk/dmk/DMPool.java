package com.neoway.iot.sdk.dmk;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 数据库连接池配置
 * @author: 20200312686
 * @date: 2020/6/22 15:48
 */
public class DMPool {
    private static final Logger LOG = LoggerFactory.getLogger(DMPool.class);
    public static final String JDBC_HOST="jdbc_host";
    public static final String JDBC_PORT="jdbc_port";
    public static final String JDBC_DB="jdbc_db";
    public static final String JDBC_MAX_CONN="jdbc_max_conn";
    public static final String JDBC_USER="jdbc_user";
    public static final String JDBC_PWD="jdbc_pwd";
    public static final String JDBC_CONN_TIMEOUT="jdbc_conn_timeout";
    public static final String JDBC_IDEL_TIMEOUT="jdbc_idel_timeout";
    public static final String JDBC_MIN_CONN="jdbc_min_conn";

    private static DMPool pool=null;
    private DMEnv env;
    private HikariDataSource dataSource;
    private Map<String,HikariDataSource> nsDsMap=new HashMap<>();
    private ThreadLocal<Connection> container=new ThreadLocal<>();
    private DMPool(){
        env=DMEnv.getInstance();
    }
    public static DMPool getInstance(){
        if(pool == null){
            synchronized (DMPool.class){
                if(pool == null){
                    pool=new DMPool();
                }
            }
        }
        return pool;
    }

    public void start(){
        DMPoolConfig.Builder builder=DMPoolConfig.build();
        builder.jdbcUri(env.getValue(JDBC_HOST),env.getValue(JDBC_PORT),env.getValue(JDBC_DB))
                .jdbcAuth(env.getValue(JDBC_USER),env.getValue(JDBC_PWD))
                .jdbcPool(env.getValue(JDBC_MAX_CONN),env.getValue(JDBC_MIN_CONN))
                .jdbcTimeOut(env.getValue(JDBC_CONN_TIMEOUT),env.getValue(JDBC_IDEL_TIMEOUT));
        DMPoolConfig dmConfig=builder.config();
        HikariConfig config=this.initHikariConfig(dmConfig);
        this.dataSource=new HikariDataSource(config);
    }

    public void stop(){
        this.container=null;
        this.dataSource=null;
    }

    public HikariDataSource getDataSource() {
        return dataSource;
    }

    private HikariConfig initHikariConfig(DMPoolConfig dmConfig){
        HikariConfig config=new HikariConfig();
        config.setDriverClassName(dmConfig.getJdbcDriver());
        config.setJdbcUrl(dmConfig.getJdbcUri());
        config.setUsername(dmConfig.getJdbcUser());
        config.setPassword(dmConfig.getJdbcPwd());
        config.setMaximumPoolSize(dmConfig.getJdbcMaxConn());
        config.setConnectionTimeout(dmConfig.getJdbcConnTimeOut());
        config.setIdleTimeout(dmConfig.getJdbcIdelTimeOut());
        config.setMinimumIdle(dmConfig.getJdbcMinNum());
        config.setReadOnly(dmConfig.isJdbcReadOnly());
        config.setAutoCommit(dmConfig.isJdbcAutoCommit());
        config.setPoolName(dmConfig.getPoolName());
        return config;
    }

    public void initNsDS(String ns,DMPoolConfig dmPoolConfig){
        HikariConfig config=this.initHikariConfig(dmPoolConfig);
        HikariDataSource ds=new HikariDataSource(config);
        nsDsMap.put(ns,ds);
    }
    public HikariDataSource getNsDataSource(String ns){
        return nsDsMap.get(ns);
    }
    public ThreadLocal<Connection> getContainer() {
        return container;
    }
    public void startTransaction(){
        Connection conn=container.get();
        if(conn == null){
            conn=getConnection();
            container.set(conn);
        }
        try{
            conn.setAutoCommit(false);
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    public void commit(){
        Connection conn=container.get();
        if(conn != null){
            try{
                conn.commit();
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }
    }

    public void rollback(){
        Connection conn=container.get();
        if(conn != null){
            try{
                conn.rollback();
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }
    }
    public void close(){
        Connection conn=container.get();
        if(conn != null){
            try{
                conn.close();
            }catch (SQLException e){
                throw new RuntimeException(e);
            }finally {
                container.remove();
            }
        }
    }

    private Connection getConnection() {
        try{
            return this.dataSource.getConnection();
        }catch (SQLException e){
            throw new RuntimeException(e);
        }

    }

}
