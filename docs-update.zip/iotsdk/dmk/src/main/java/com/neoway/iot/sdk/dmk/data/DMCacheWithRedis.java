package com.neoway.iot.sdk.dmk.data;

/**
 * @desc: DMCache-Redis实现
 * @author: 20200312686
 * @date: 2020/6/22 13:48
 */
public class DMCacheWithRedis implements DMCache {
    @Override
    public void load() {
        //1:查询对象公共实例表数据，写入redis.
    }

    @Override
    public void clear() {

    }

    @Override
    public void write(DMDataPoint data) {

    }

    @Override
    public DMDataPoint read(DMDataPoint data) {
        return null;
    }

    @Override
    public void remove(DMDataPoint data) {

    }
}
