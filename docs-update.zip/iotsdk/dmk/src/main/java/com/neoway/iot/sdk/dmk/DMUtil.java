package com.neoway.iot.sdk.dmk;

import com.neoway.iot.sdk.dmk.meta.DMMetaColumnDBAnno;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * @desc: DMUtil
 * @author: 20200312686
 * @date: 2020/7/13 20:18
 */
public class DMUtil {
    private static final Logger LOG = LoggerFactory.getLogger(DMUtil.class);
    public static Set<Field> getFieldsIncludeSuperClass(Class clazz) {
        Set<Field> fields = new LinkedHashSet<Field>();
        Class current = clazz;
        while (current != null) {
            Field[] currentFields = current.getDeclaredFields();
            for (Field currentField : currentFields) {
                fields.add(currentField);
            }
            current = current.getSuperclass();
        }
        return fields;
    }
    /**
     * @desc 数据库字段映射到实体类
     * @param columnMap
     * @return
     */
    public static Object invokeObject(Map<String,Object> columnMap, Class clazz){
        Object instance;
        try {
            instance=clazz.newInstance();
        } catch (Exception ex) {
            LOG.error(ex.getMessage(),ex);
            String errTpl="设置对象属性值发生异常,无法实例化对象。对象={0}";
            String err= MessageFormat.format(errTpl,clazz.getName());
            throw new RuntimeException(err);
        }

        Set<Field> fields= DMUtil.getFieldsIncludeSuperClass(clazz);
        for (Field field : fields) {
            try{
                Method method=getSetterMethod(clazz,field);
                if(null == method){
                    continue;
                }
                String column=field.getName();
                Class fieldType=field.getType();
                DMMetaColumnDBAnno columnDBAnno = field.getAnnotation(DMMetaColumnDBAnno.class);
                if(null != columnDBAnno){
                    column=columnDBAnno.column();
                    fieldType=columnDBAnno.type();
                }
                if (method != null) {
                    Object value=columnMap.get(column);
                    method.invoke(instance, value);

                }
            }catch (Exception e){
                e.printStackTrace();
                LOG.error(e.getMessage(),e);
                String errTpl="设置对象属性值发生异常。对象={0}，属性={1}";
                String err= MessageFormat.format(errTpl,clazz.getName(),field.getName());
                throw new RuntimeException(err);
            }
        }
        return instance;
    }

    /**
     * @desc 根据对象属性获取属性方法
     * @param clazz 对象类型
     * @param field 对象属性
     * @return 方法
     */
    public static Method getSetterMethod(Class clazz, Field field) {
        DMMetaColumnDBAnno columnDBAnno = field.getAnnotation(DMMetaColumnDBAnno.class);
        Class fieldType=field.getType();
        if(null != columnDBAnno){
            fieldType=columnDBAnno.type();
        }
        String name = "set" + StringUtils.capitalize(field.getName());
        try {
            Method declaredMethod = clazz.getDeclaredMethod(name, fieldType);
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (NoSuchMethodException e) {
            /*LOG.error(e.getMessage(),e);
            String errTpl="设置对象属性值发生异常：原因为找不到对象set方法。对象={0}，属性={1}";
            String err= MessageFormat.format(errTpl,clazz.getName(),field.getName());
            throw new RuntimeException(err);*/
            return null;
        }
    }
}
