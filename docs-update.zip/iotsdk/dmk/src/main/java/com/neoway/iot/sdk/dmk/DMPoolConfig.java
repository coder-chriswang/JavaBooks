package com.neoway.iot.sdk.dmk;

import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;

/**
 * @desc: DMPoolConfig
 * @author: 20200312686
 * @date: 2020/7/6 16:09
 */
public class DMPoolConfig {
    private String jdbcDriver;
    private String jdbcUri;
    private int jdbcMaxConn;
    private String jdbcUser;
    private String jdbcPwd;
    private boolean jdbcReadOnly;
    private int jdbcConnTimeOut;
    private int jdbcIdelTimeOut;
    private int jdbcMinNum=5;
    private boolean jdbcAutoCommit;
    private String poolName;

    public static Builder build(){
        return new Builder();
    }
    public static class Builder {
        private String jdbcDriver="com.mysql.cj.jdbc.Driver";
        private String jdbcUri;
        //连接池允许的最大连接数
        private int jdbcMaxConn=30;
        private String jdbcUser;
        private String jdbcPwd;
        private boolean jdbcReadOnly=false;
        //等待连接池分配连接的最大时长：30秒
        private int jdbcConnTimeOut=30000;
        //一个idle状态的连接超时时长 10分钟
        private int jdbcIdelTimeOut=600000;
        private int jdbcMinConn=5;
        private boolean jdbcAutoCommit=true;
        private String poolName="dm-jdbc-pool";

        public Builder jdbcUri(String host,String port,String db){
            String jdbcUri= MessageFormat.format(DMSQL.JDBC_URL.getSql(),
                    host,port,db);
            this.jdbcUri=jdbcUri;
            return this;
        }
        public Builder jdbcUri(String uri){
            this.jdbcUri=uri;
            return this;
        }
        public Builder jdbcAuth(String user,String pwd){
            this.jdbcUser=user;
            this.jdbcPwd=pwd;
            return this;
        }
        public Builder jdbcPool(String jdbcMaxConn,String jdbcMinConn){
            if(StringUtils.isNotEmpty(jdbcMaxConn)){
                this.jdbcMaxConn = Integer.valueOf(jdbcMaxConn);
            }
            if(StringUtils.isNotEmpty(jdbcMinConn)){
                this.jdbcMinConn = Integer.valueOf(jdbcMinConn);
            }
            return this;
        }
        public Builder jdbcTimeOut(String jdbcConnTimeOut,String jdbcIdelTimeOut){
            if(StringUtils.isNotEmpty(jdbcConnTimeOut)){
                this.jdbcConnTimeOut = Integer.valueOf(jdbcConnTimeOut);
            }
            if(StringUtils.isNotEmpty(jdbcIdelTimeOut)){
                this.jdbcIdelTimeOut = Integer.valueOf(jdbcIdelTimeOut);
            }
            return this;
        }

        public Builder poolName(String poolName){
            this.poolName=poolName;
            return this;
        }
        public DMPoolConfig config(){
            DMPoolConfig config=new DMPoolConfig();
            config.jdbcAutoCommit=this.jdbcAutoCommit;
            config.jdbcConnTimeOut=this.jdbcConnTimeOut;
            config.jdbcAutoCommit=this.jdbcAutoCommit;
            config.jdbcDriver=this.jdbcDriver;
            config.jdbcIdelTimeOut=this.jdbcIdelTimeOut;
            config.jdbcMaxConn=this.jdbcMaxConn;
            config.jdbcMinNum=this.jdbcMinConn;
            config.jdbcUri=this.jdbcUri;
            config.jdbcUser=this.jdbcUser;
            config.jdbcPwd=this.jdbcPwd;
            config.jdbcReadOnly=this.jdbcReadOnly;
            config.poolName=this.poolName;
            return config;
        }
    }

    public String getJdbcDriver() {
        return jdbcDriver;
    }

    public String getJdbcUri() {
        return jdbcUri;
    }

    public int getJdbcMaxConn() {
        return jdbcMaxConn;
    }

    public String getJdbcUser() {
        return jdbcUser;
    }

    public String getJdbcPwd() {
        return jdbcPwd;
    }

    public boolean isJdbcReadOnly() {
        return jdbcReadOnly;
    }

    public int getJdbcConnTimeOut() {
        return jdbcConnTimeOut;
    }

    public int getJdbcIdelTimeOut() {
        return jdbcIdelTimeOut;
    }

    public int getJdbcMinNum() {
        return jdbcMinNum;
    }

    public boolean isJdbcAutoCommit() {
        return jdbcAutoCommit;
    }

    public String getPoolName() {
        return poolName;
    }
}
