package com.neoway.iot.sdk.dmk.data;

import com.neoway.iot.sdk.dmk.DMSQL;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaCache;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: DataField
 * @author: 20200312686
 * @date: 2020/7/14 12:47
 */
public class DMDataPoint {
    private static final Logger LOG = LoggerFactory.getLogger(DMDataPoint.class);
    private DMMetaCI metaCI;
    private List<DMDataColumn> columns = new ArrayList<>();

    public DMMetaCI getMetaCI() {
        return metaCI;
    }

    public static DMDataPoint builder(String ns, String tenent, String ci) {
        DMMetaCI metaCI = DMMetaCache.getInstance().getMetaCI(ns.toLowerCase(), tenent, ci);
        if (null == metaCI) {
            String msg = "添加数据失败，原因=元数据不存在。产品域={0},租户={1},ci={2}";
            String errMsg = MessageFormat.format(msg, ns, tenent, ci);
            throw new RuntimeException(errMsg);
        }
        DMDataPoint point = new DMDataPoint();
        point.metaCI = metaCI;
        return point;
    }

    public DMDataPoint buildColumns(Map<String, Object> value) {
        if (MapUtils.isEmpty(value)) {
            return this;
        }
        for (Map.Entry<String, Object> entry : value.entrySet()) {
            DMDataColumn dmColumn = new DMDataColumn(entry.getKey(), entry.getValue());
            try{
                if(dmColumn.validateField(this.metaCI)){
                    this.columns.add(dmColumn);
                }
            }catch (Exception e){
                LOG.error(e.getMessage());
            }
        }
        return this;
    }

    /**
     * @desc 构建SQL语句
     * @return
     */
    public String buildAddSQL() {
        if(CollectionUtils.isEmpty(this.columns)){
            throw new RuntimeException("columns不能为空");
        }
        String table=metaCI.getTable();
        StringBuilder columnBuilder=new StringBuilder();
        StringBuilder valueBuilder=new StringBuilder();
        int index=0;
        for(DMDataColumn column:columns){
            index++;
            columnBuilder.append("`").append(column.column).append("`");
            valueBuilder.append("?");
            if(index<columns.size()){
                columnBuilder.append(",");
                valueBuilder.append(",");
            }
        }
        String sql=MessageFormat.format(DMSQL.DML_CI_INSTANCE_INSERT.getSql(),
                table,columnBuilder.toString(),valueBuilder.toString());
        return sql;
    }

    /**
     * @desc 构建参数
     * @return
     */
    public Object[] buildAddParams() {
        if(CollectionUtils.isEmpty(this.columns)){
            throw new RuntimeException("columns不能为空");
        }
        Object[] params=new Object[this.columns.size()];
        int index=0;
        for(DMDataColumn column:columns){
            params[index]=column.value;
            index++;
        }
        return params;
    }

    /**
     * @desc 获取指定属性的column结构
     * @param attr
     * @return
     */
    public DMDataColumn getDataColumn(String attr){
        if(CollectionUtils.isEmpty(this.columns)){
            return null;
        }
        for(DMDataColumn column:this.columns){
            if(column.column.equals(attr)){
                return column;
            }
        }
        return null;
    }
}
