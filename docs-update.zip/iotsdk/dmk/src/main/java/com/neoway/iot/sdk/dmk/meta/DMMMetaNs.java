package com.neoway.iot.sdk.dmk.meta;

/**
 * @desc: 产品域
 * @author: 20200312686
 * @date: 2020/7/6 11:12
 */
public class DMMMetaNs {
    private String id;
    private String name;
    private String desc;
    private String vendor;
    private String vendorName;
    private String namespace;

    public String getId() {
        return id.toLowerCase();
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }
    public Object[] getParams(){
        Object[] params={this.getId(),this.getName(),this.getDesc(),
                this.getVendor(),this.getVendorName(),System.currentTimeMillis()/1000};
        return params;
    }
}
