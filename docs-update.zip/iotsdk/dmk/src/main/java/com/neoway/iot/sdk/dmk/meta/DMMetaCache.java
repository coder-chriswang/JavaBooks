package com.neoway.iot.sdk.dmk.meta;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.neoway.iot.sdk.dmk.DMEnv;
import com.neoway.iot.sdk.dmk.DMPool;
import com.neoway.iot.sdk.dmk.DMPoolConfig;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.List;

/**
 * @desc: 资源管理-元数据缓存
 * @author: 20200312686
 * @date: 2020/6/22 19:16
 */
public class DMMetaCache {
    private static final Logger LOG = LoggerFactory.getLogger(DMMetaCache.class);
    private static final String CACHE_SPLIT="@##@";
    private static DMMetaCache cache=null;
    //元数据缓存
    private LoadingCache<String,DMMetaCI> metaCache;
    //产品域缓存
    private LoadingCache<String,DMMMetaNs> nsCache;
    private DMMetaCache(){
        nsCache= CacheBuilder.newBuilder()
                .maximumSize(10)
                .recordStats()
                .initialCapacity(100)
                .build(new CacheLoader<String, DMMMetaNs>() {
                    @Override
                    public DMMMetaNs load(String s) throws Exception {
                        LOG.info("NS缓存不存在，从数据库加载:ns={}",s);
                        return DMMetaDdl.getNS(s);
                    }
                });
        metaCache=CacheBuilder.newBuilder()
                .maximumSize(10)
                .recordStats()
                .initialCapacity(100)
                .build(new CacheLoader<String, DMMetaCI>() {
                    @Override
                    public DMMetaCI load(String s) throws Exception {
                        LOG.info("MetaCI缓存不存在，从数据库加载:K={}",s);
                        String[] params=s.split(CACHE_SPLIT);
                        String ns=params[0];
                        String tenent=params[1];
                        String ci=s.substring(s.lastIndexOf(CACHE_SPLIT)+4);
                        return DMMetaDdl.getMetaCI(ns,tenent,ci);
                    }
                });
    }
    public static DMMetaCache getInstance(){
        if(cache == null){
            synchronized (DMMetaCache.class){
                if(cache == null){
                    cache=new DMMetaCache();
                }
            }
        }
        return cache;
    }

    /**
     * 初始化
     */
    public synchronized void start(){
        this.loadMetaNs();
        for(DMMMetaNs ns:nsCache.asMap().values()){
            initDS(ns);
            loadMetaCI(ns.getId());
        }
    }
    public synchronized void stop(){
        if(null != metaCache){
            metaCache.cleanUp();
        }
        if(null != nsCache){
            nsCache.cleanUp();
        }
    }


    /**
     * @desc 加载ns数据集
     */
    private void loadMetaNs(){
        try{
            List<DMMMetaNs> nsList=DMMetaDdl.queryNS();
            if(CollectionUtils.isEmpty(nsList)){
                return;
            }
            for(DMMMetaNs ns:nsList){
                nsCache.put(ns.getId(),ns);
            }
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="初始化缓存-加载ns数据集异常,异常原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }

    }

    /**
     * @desc 加载MetaCI元数据
     * @param ns
     */
    private void loadMetaCI(String ns){
        try{
            List<DMMetaCI> ciList=DMMetaDdl.queryMetaCI(ns);
            for(DMMetaCI metaCI:ciList){
                String k=buildMetaCIKey(metaCI.getNs(),metaCI.getTenent(),metaCI.getCi());
                metaCache.put(k,metaCI);
            }
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="初始化缓存-加载metaci数据集异常,异常原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }

    }
    /**
     * 初始化数据库连接池
     * @param ns
     */
    private void initDS(DMMMetaNs ns){
        DMPoolConfig.Builder builder=DMPoolConfig.build();
        DMEnv env= DMEnv.getInstance();
        builder.jdbcUri(env.getValue(DMPool.JDBC_HOST),env.getValue(DMPool.JDBC_PORT),ns.getId())
                .jdbcAuth(env.getValue(DMPool.JDBC_USER),env.getValue(DMPool.JDBC_PWD)).poolName("db-pool-"+ns.getId());
        DMPoolConfig config=builder.config();
        DMPool.getInstance().initNsDS(ns.getId(),config);

    }

    /**
     * @desc 构建metaci cache的key
     * @param ns 产品域
     * @param ci 对象类型
     * @return 缓存key
     */
    private String buildMetaCIKey(String ns,String tenent,String ci){
        StringBuilder sb=new StringBuilder();
        sb.append(ns.toLowerCase()).append(CACHE_SPLIT).append(tenent).append(CACHE_SPLIT).append(ci);
        return sb.toString();
    }

    /**
     * @desc 写metaci缓存
     * @param metaCI
     */
    public void write(DMMetaCI metaCI){
        metaCache.put(buildMetaCIKey(metaCI.getNs(),metaCI.getTenent(),metaCI.getCi()),metaCI);
    }

    /**
     * @desc 读取metaci缓存
     * @param ns
     * @param ci
     * @return
     */
    public DMMetaCI getMetaCI(String ns,String tenent,String ci){
        try{
            String k=buildMetaCIKey(ns,tenent,ci);
            return metaCache.get(k);
        }catch (Exception e){
            LOG.warn("产品域MetaCI缓存不存在,获取异常。指定ns={},ci={}",ns,ci);
            return null;
        }

    }

    /**
     * @desc 获取NS缓存
     * @param ns
     * @return
     */
    public synchronized DMMMetaNs getNs(String ns){
        try{
            return nsCache.get(ns);
        }catch (Exception e){
            LOG.warn("产品域缓存不存在,获取异常。指定ns={}",ns);
            return null;
        }

    }

    /**
     * @desc 判断缓存是否存在
     * @param ns
     * @return
     */
    public synchronized boolean exsitNs(String ns){
        ns=ns.toLowerCase();
        DMMMetaNs metaNS= nsCache.getIfPresent(ns);
        if(null == metaNS){
            return false;
        }
        return true;
    }
    public synchronized boolean exsitMetaCI(DMMetaCI metaCI){
        String k=buildMetaCIKey(metaCI.getNs(),metaCI.getTenent(),metaCI.getCi());
        DMMetaCI cacheMetaCI=metaCache.getIfPresent(k);
        if(null == cacheMetaCI){
            return false;
        }
        return true;
    }

    /**
     * @desc 写meta ns缓存
     * @param ns
     */
    public synchronized void writeNsCache(DMMMetaNs ns){
        this.initDS(ns);
        this.nsCache.put(ns.getId(),ns);
    }
}
