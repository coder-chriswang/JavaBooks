package com.neoway.iot.sdk.dmk.meta;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * @desc: 数据库字段与entity实体映射
 * @author: 20200312686
 * @date: 2020/7/13 20:10
 */
@Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.TYPE})
public @interface DMMetaColumnDBAnno {
    //数据库字段
    String column();
    //数据库字段类型
    Class type();
}
