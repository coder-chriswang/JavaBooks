package com.neoway.iot.sdk.dmk;

import com.neoway.iot.sdk.dmk.data.DMCache;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMMetaNs;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.*;

/**
 * @desc: DMRunner
 * @author: 20200312686
 * @date: 2020/7/10 14:37
 */
public class TestDMRunner {

    private static DMRunner runner;
    @BeforeClass
    public static void start(){
        Map<String,Object> pro=new HashMap<>();
        pro.put(DMPool.JDBC_HOST,"192.168.69.14");
        pro.put(DMPool.JDBC_PORT,"9000");
        pro.put(DMPool.JDBC_DB,"ares");
        pro.put(DMPool.JDBC_MAX_CONN,2);
        pro.put(DMPool.JDBC_MIN_CONN,1);
        pro.put(DMPool.JDBC_USER,"root");
        pro.put(DMPool.JDBC_PWD,"hera@321");
        pro.put(DMPool.JDBC_CONN_TIMEOUT,30000);
        pro.put(DMPool.JDBC_IDEL_TIMEOUT,30000);
        pro.put(DMCache.CACHE_KEY,"mem");
        runner=DMRunner.getInstance();
        runner.start(pro);
    }
    @Test
    public void addMetaTest(){
        DMMMetaNs ns=new DMMMetaNs();
        ns.setId("Channel");
        ns.setName("管道云产品");
        ns.setVendor("Neoway");
        ns.setVendorName("深圳市有方科技");
        ns.setDesc("物联网大数据智能分析平台");
        String path="D:\\gitme\\dgw-test\\models\\Channel\\dm";
        runner.addMeta(path,ns);
    }
    @Test
    public void writeTest(){
        DMDataPoint data=DMDataPoint.builder("Channel","default","Device");
        Map<String,Object> value=new HashMap<>();
        value.put("tenent","default");
        value.put("ci","Device");
        value.put("vendor","Neoway");
        value.put("type","电表");
        value.put("nativeid","3736632160665700");
        value.put("instanceid","3736632160665700");
        value.put("name","电表-3736632160665700");
        value.put("rt",System.currentTimeMillis()/1000);
        value.put("protocol","MQTT");
        value.put("protocol_version","v3.1");
        value.put("mode_version","N56");
        value.put("status","Unkown");
        data.buildColumns(value);
        runner.write(data);
    }

    @Test
    public void writeBatchTest(){
        List<DMDataPoint> points=new ArrayList<>();
        DMDataPoint data=DMDataPoint.builder("Channel","default","Device");
        Map<String,Object> value=new HashMap<>();
        value.put("tenent","default");
        value.put("ci","Device");
        value.put("vendor","Neoway");
        value.put("type","电表");
        value.put("nativeid","3736632160665700");
        value.put("instanceid","3736632160665700");
        value.put("name","电表-3736632160665700");
        value.put("rt",System.currentTimeMillis()/1000);
        value.put("protocol","MQTT");
        value.put("protocol_version","v3.1");
        value.put("mode_version","N56");
        value.put("status","Unkown");
        points.add(data.buildColumns(value));

        DMDataPoint data1=DMDataPoint.builder("Channel","default","Plmn");
        Map<String,Object> value1=new HashMap<>();
        value1.put("nativeid",46000);
        value1.put("instanceid","3736632160665700");
        value1.put("name","中国移动");
        value1.put("brand","China Mobile");
        value1.put("country","中国");
        value1.put("update_ts",System.currentTimeMillis()/1000);
        points.add(data1.buildColumns(value1));
        DMDataPoint data2=DMDataPoint.builder("Channel","default","Plmn");
        Map<String,Object> value2=new HashMap<>();
        value2.put("nativeid",46001);
        value2.put("instanceid","3736632160665701");
        value2.put("name","中国联通");
        value2.put("brand","China Unicom");
        value2.put("country","中国");
        value2.put("update_ts",System.currentTimeMillis()/1000);
        points.add(data2.buildColumns(value2));
        runner.write(points);
    }
}
