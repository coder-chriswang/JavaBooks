package com.neoway.oc.datacommand.fdfs;

import com.github.tobato.fastdfs.domain.StorePath;
import com.github.tobato.fastdfs.proto.storage.DownloadByteArray;
import com.github.tobato.fastdfs.service.FastFileStorageClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

/**
 * <pre>
 *  描述: 文件操作客户端实现类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/17 13:15
 */
//@Component
@Slf4j
public class FdfsClientImpl implements FdfsClient {

    @Autowired
    private FastFileStorageClient storageClient;

    /**
     * 借助springmvc文件存储，
     *
     * @param multipartFile
     * @return
     * @throws Exception
     */
    @Override
    public String saveFile(MultipartFile multipartFile) throws Exception {
        log.info("文件上传开始:{}", multipartFile.getOriginalFilename());
        StorePath storePath = storageClient.uploadFile(multipartFile.getInputStream(), multipartFile.getSize(),
                FilenameUtils.getExtension(multipartFile.getOriginalFilename()), null);
        log.info("文件上传结束:{}", multipartFile.getOriginalFilename());
        return storePath.getFullPath();
    }

    @Override
    public void deleteFile(String url) throws Exception {
        log.info("删除文件:{}", url);
        if (StringUtils.isEmpty(url)) {
            return;
        }
        StorePath storePath = StorePath.praseFromUrl(url);
        storageClient.deleteFile(storePath.getGroup(), storePath.getPath());
        log.info("删除文件结束:{}", url);
    }

    @Override
    public byte[] downFile(String url) throws Exception {
        StorePath storePath = StorePath.praseFromUrl(url);
        String group = storePath.getGroup();
        String path = storePath.getPath();
        DownloadByteArray downloadByteArray = new DownloadByteArray();
        byte[] bytes = storageClient.downloadFile(group, path, downloadByteArray);
        return bytes;
    }
}