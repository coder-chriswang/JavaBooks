package com.neoway.oc.datacommand.web;

import cn.hutool.http.HttpUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

/**
 * <pre>
 *  描述: HTTP请求封装类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/17 13:29
 */
@Slf4j
public class NeowayHttpUtils {

    private static final int MAX_TIME_OUT = 10 * 1000;

    public static String post(String urlString, Map<String, Object> paramMap) {
        return request((String u, Map<String, Object> p, String s) -> HttpUtil.post(u, p, MAX_TIME_OUT), urlString, paramMap, null);
    }

    public static String post(String urlString, String body) {
        return request((String u, Map<String, Object> p, String s) -> HttpUtil.post(u, s, MAX_TIME_OUT), urlString, null, body);
    }

    public static String get(String urlString) {
        return request((String u, Map<String, Object> p, String s) -> HttpUtil.get(u, MAX_TIME_OUT), urlString, null, null);
    }

    public static String get(String urlString, Map<String, Object> paramMap) {
        return request((String u, Map<String, Object> p, String s) -> HttpUtil.post(u, p, MAX_TIME_OUT), urlString, paramMap, null);
    }

    public static String request(NeowayHttpDeal neowayHttpDeal, String urlString, Map<String, Object> paramMap, String body) {
        log.info("NeowayHttpUtils request url={}", urlString);
        long startTime = System.currentTimeMillis();
        String result = neowayHttpDeal.deal(urlString, paramMap, body);
        log.info("NeowayHttpUtils request url={},执行耗时=={}毫秒", urlString, (System.currentTimeMillis() - startTime));
        return result;
    }

    @FunctionalInterface
    public interface NeowayHttpDeal {
        /**
         * 具体请求方法
         *
         * @param urlString
         * @param paramMap
         * @param body
         * @return
         */
        String deal(String urlString, Map<String, Object> paramMap, String body);
    }

}
