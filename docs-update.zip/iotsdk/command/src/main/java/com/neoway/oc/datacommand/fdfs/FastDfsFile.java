package com.neoway.oc.datacommand.fdfs;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 文件封装
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/17 13:11
 */
@Data
public class FastDfsFile implements Serializable {

    private static final long serialVersionUID = 1888532385762169306L;

    private String name;

    private byte[] content;

    private String ext;

    private String md5;

    private String author;

    public FastDfsFile(String name, byte[] content, String ext) {
        super();
        this.name = name;
        this.content = content;
        this.ext = ext;
    }

    public FastDfsFile() {
        super();
    }


}
