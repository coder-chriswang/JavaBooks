package com.neoway.oc.datacommand.service;

/**
 * <pre>
 *  描述: OC命令服务接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/18 15:59
 */
public interface OCCommandService {

    /**
     * OC鉴权获取访问token
     *
     * @return accessToken
     */
    String authentication();

    /**
     * OC应用端下发命令
     *
     * @param deviceId
     * @param serviceId
     * @param method
     * @param jsonRequest
     * @param callBackUrl
     * @return
     */
    boolean createCommand(String deviceId, String serviceId, String method, String jsonRequest, String callBackUrl);
}
