package com.neoway.oc.datacommand.fdfs;

import org.springframework.web.multipart.MultipartFile;

/**
 * <pre>
 *  描述: 文件操作客户端
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/17 13:14
 */
public interface FdfsClient {

    String saveFile(MultipartFile multipartFile) throws Exception;

    void deleteFile(String url) throws Exception;

    byte[] downFile(String fileUrl) throws Exception;
}
