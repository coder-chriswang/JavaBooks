package com.neoway.oc.datacommand.service.impl;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.neoway.oc.datacommand.service.OCCommandService;
import com.neoway.oc.datacommand.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * <pre>
 *  描述: OC命令服务接口实现类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/18 16:09
 */
@Component
@Slf4j
public class OCCommandServiceImpl implements OCCommandService {

    /**
     * 鉴权获取的token, 有效期60分钟
     */
    private String accessToken;

    /**
     * 定时获取token间隔
     */
    private static final int TOKEN_REFRESH_FIXED_RATE = 1000 * 60 * 59;

    /**
     * 创建命令返回体中Key
     */
    private static final String KEY_COMMAND_ID = "commandId";

    @Value("${neoway.oc.appId}")
    private String appId;

    @Value("${neoway.oc.secret}")
    private String secret;

    @Value("${neoway.oc.url}")
    private String url;

    @Value("${oc.certificate.path}")
    private String certUrl;

    @Override
    public String authentication() {
        if (StringUtil.strIsNullOrEmpty(accessToken) && !getAccessToken()) {
            return null;
        }
        return accessToken;
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean createCommand(String deviceId, String serviceId, String method, String jsonRequest, String callBackUrl) {
        if (StringUtil.strIsNullOrEmpty(accessToken) && !getAccessToken()) {
            getAccessToken();
        }
        try {
            HttpsUtil httpsUtil = new HttpsUtil(certUrl);
            httpsUtil.initSSLConfigForTwoWay();

            ObjectNode paras = JsonUtil.convertObject2ObjectNode(jsonRequest);
            Map<String, Object> paramCommand = new HashMap<>(3);
            paramCommand.put("serviceId", serviceId);
            paramCommand.put("method", method);
            paramCommand.put("paras", paras);

            Map<String, Object> paramCreateDeviceCommand = new HashMap<>(5);
            paramCreateDeviceCommand.put("deviceId", deviceId);
            paramCreateDeviceCommand.put("command", paramCommand);
            paramCreateDeviceCommand.put("callbackUrl", callBackUrl);
            paramCreateDeviceCommand.put("expireTime", 0);
            paramCreateDeviceCommand.put("maxRetransmit", 3);

            String request = JsonUtil.jsonObj2Sting(paramCreateDeviceCommand);

            Map<String, String> header = new HashMap<>(2);
            header.put(Constant.HEADER_APP_KEY, appId);
            header.put(Constant.HEADER_APP_AUTH, "Bearer" + " " + accessToken);

            HttpResponse responseCreateDeviceCommand = httpsUtil.doPostJson(url + "/iocm/app/cmd/v1.4.0/deviceCommands", header, request);
            String responseBody = httpsUtil.getHttpResponseBody(responseCreateDeviceCommand);
            if (responseBody == null) {
                log.error("返回体为null!");
                return false;
            }
            Map<String, String> dataMap = new HashMap<>();
            dataMap = JsonUtil.jsonString2SimpleObj(responseBody, dataMap.getClass());
            String commandId = dataMap.get(KEY_COMMAND_ID);
            log.info("commandId = {}", commandId);
            return !StringUtil.strIsNullOrEmpty(dataMap.get(KEY_COMMAND_ID));
        } catch (Exception e) {
            log.error("命令下发失败！", e);
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private boolean getAccessToken() {
        try {
            log.info("证书路径为{}", certUrl);
            // Two-Way Authentication
            HttpsUtil httpsUtil = new HttpsUtil(certUrl);
            httpsUtil.initSSLConfigForTwoWay();

            String urlLogin = url + "/iocm/app/sec/v1.1.0/login";

            Map<String, String> paramLogin = new HashMap<>(2);
            paramLogin.put("appId", appId);
            paramLogin.put("secret", secret);

            StreamClosedHttpResponse responseLogin = httpsUtil.doPostFormUrlEncodedGetStatusLine(urlLogin, paramLogin);

            log.info("app auth success,return accessToken:");
            log.info("line={}", responseLogin.getStatusLine());
            log.info("content={}", responseLogin.getContent());

            Map<String, String> data = new HashMap<>();
            data = JsonUtil.jsonString2SimpleObj(responseLogin.getContent(), data.getClass());
            accessToken = data.get("accessToken");
            return true;
        } catch (Exception e) {
            log.error("获取accessToken失败！", e);
        }
        return false;
    }

    /**
     * 定时获取token, 并续期
     */
    @Component
    private class TimedTask {
        @Scheduled(fixedRate = TOKEN_REFRESH_FIXED_RATE)
        public void fetchAccessToken() {
            log.info("定时获取accessToken!");
            getAccessToken();
        }
    }
}
