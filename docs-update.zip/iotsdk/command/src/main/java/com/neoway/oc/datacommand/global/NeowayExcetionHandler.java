package com.neoway.oc.datacommand.global;

import com.neoway.kernel.model.response.HttpResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * <pre>
 *  描述: 全局异常Handler
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/17 14:01
 */
@RestControllerAdvice
@Slf4j
@SuppressWarnings("all")
public class NeowayExcetionHandler {

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public HttpResult notFoundErrorHandler(Exception e) {
        log.error("Voc Exception,message:{}", e.getLocalizedMessage(), e);
        return HttpResult.returnFail();
    }
}
