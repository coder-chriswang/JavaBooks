package com.neoway.oc.datacommand.utils;

import com.neoway.oc.datacommand.core.DynamicBean;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * <pre>
 *  描述: class工具类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/17 13:34
 */
public class ClassUtil {

    /**
     * 生成动态代理对象
     *
     * @param object          原对象
     * @param extendReturnMap 扩展属性值，key：属性名，value：属性值
     * @param extendTypeMap   扩展属性类型，key：属性名，value：属性类型
     * @return 动态代理对象
     * @throws Exception
     */
    public static Object dynamicObject(Object object, Map<String, Object> extendReturnMap, Map<String, Class> extendTypeMap) throws Exception {
        if (extendReturnMap == null || extendReturnMap.size() == 0) {
            return object;
        }
        if (extendTypeMap == null || extendTypeMap.size() == 0) {
            return object;
        }
        Class clazz = object.getClass();
        BeanInfo beanInfo = Introspector.getBeanInfo(clazz);
        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
        for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
            String propertyName = propertyDescriptor.getName();
            if (!"class".equals(propertyName)) {
                //如果扩展属性中有和原对象重名的属性，以扩展属性为准
                if (extendReturnMap.containsKey(propertyName) && extendTypeMap.containsKey(propertyName)) {
                    continue;
                }
                //获取此属性的get方法
                Method method = propertyDescriptor.getReadMethod();
                Object result = method.invoke(object, null);
                extendTypeMap.put(propertyName, propertyDescriptor.getPropertyType());
                extendReturnMap.put(propertyName, result);
            }
        }
        DynamicBean bean = new DynamicBean(extendTypeMap, object.getClass());
        extendTypeMap.keySet().forEach(key -> {
            bean.setValue(key, extendReturnMap.get(key));
        });
        return bean.getObject();
    }
}
