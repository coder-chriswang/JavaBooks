package com.neoway.oc.datacommand.core;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.cglib.beans.BeanGenerator;
import org.springframework.cglib.beans.BeanMap;


/**
 * <pre>
 *  描述: 动态类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/17 11:46
 */
public class DynamicBean {

    private Object object = null;

    private BeanMap beanMap = null;

    public DynamicBean() {
    }

    public DynamicBean(Map propertyMap, Class superClass) {
        this.object = generateBean(propertyMap, superClass);
        this.beanMap = BeanMap.create(this.object);
    }

    /**
     * 给bean属性赋值
     *
     * @param property 属性名
     * @param value    值
     */
    public void setValue(Object property, Object value) {
        beanMap.put(property, value);
    }

    /**
     * 通过属性名得到属性值
     *
     * @param property 属性名
     * @return
     */
    public Object getValue(String property) {
        return beanMap.get(property);
    }

    /**
     * 得到该实体bean对象
     *
     * @return
     */
    public Object getObject() {
        return this.object;
    }

    /**
     * 生成动态代理对象
     *
     * @param propertyMap 属性map
     * @param superclass  父类
     * @return
     */
    @SuppressWarnings("rawtypes")
    private Object generateBean(Map propertyMap, Class superclass) {
        BeanGenerator generator = new BeanGenerator();
        Set keySet = propertyMap.keySet();
        for (Iterator i = keySet.iterator(); i.hasNext(); ) {
            String key = (String) i.next();
            generator.addProperty(key, (Class) propertyMap.get(key));
            generator.setSuperclass(superclass);
        }
        return generator.create();
    }
}
