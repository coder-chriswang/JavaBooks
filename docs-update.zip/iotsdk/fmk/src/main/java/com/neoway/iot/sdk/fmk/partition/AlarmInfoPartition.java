package com.neoway.iot.sdk.fmk.partition;

import com.neoway.iot.sdk.fmk.sharding.Partition;

/**
 * <pre>
 *  描述:告警信息分区
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 11:00
 */
public class AlarmInfoPartition extends Partition {
    private static final long serialVersionUID = 457015540428621158L;
}
