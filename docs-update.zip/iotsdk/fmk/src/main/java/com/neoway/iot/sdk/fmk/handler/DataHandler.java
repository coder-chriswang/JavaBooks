package com.neoway.iot.sdk.fmk.handler;

import com.neoway.iot.sdk.fmk.model.AlarmInfoVo;
import com.neoway.iot.sdk.fmk.model.BaseAlarmInfo;
import com.neoway.iot.sdk.fmk.model.params.DeleteParams;
import com.neoway.iot.sdk.fmk.model.params.SearchParams;

import java.util.List;

/**
 * <pre>
 *  描述: 数据处理类接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 19:42
 */
public interface DataHandler {
    /**
     * 查询告警数据
     * @param searchParams
     * @return
     */
    List<AlarmInfoVo> getAlarmInfoList(SearchParams searchParams);

    /**
     * 插入告警数据
     * @param alarmInfoVo
     * @return
     */
    int insert(AlarmInfoVo alarmInfoVo);

    /**
     * 批量插入告警数据
     * @param alarmInfoVos
     * @return
     */
    int batchInsert(List<AlarmInfoVo> alarmInfoVos);

    /**
     * 更新告警数据
     * @param alarmInfoVo
     * @return
     */
    int update(AlarmInfoVo alarmInfoVo);

    /**
     * 根据流水号删除告警信息
     * @param deleteParams
     * @return
     */
    int delete(DeleteParams deleteParams);

    /**
     * 获取静态告警数据
     * @param alarmIds 告警idList
     * @return
     */
    List<BaseAlarmInfo> getStaticAlarmInfo(List<String> alarmIds);
}
