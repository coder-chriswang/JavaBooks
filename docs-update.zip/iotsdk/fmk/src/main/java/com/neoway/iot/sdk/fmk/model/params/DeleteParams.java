package com.neoway.iot.sdk.fmk.model.params;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 删除参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/02 18:15
 */
@Data
public class DeleteParams implements Serializable {
    private static final long serialVersionUID = -7553455686750452382L;
    /**
     * instanceId
     */
    private String instanceId;

    /**
     * 告警序列号
     */
    private String serialNo;

    /**
     * 设备ID
     */
    private String deviceId;

    /**
     * 租户ID
     */
    private String tenantId;

    /**
     * 告警ID
     */
    private String alarmId;
}
