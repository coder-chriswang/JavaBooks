package com.neoway.iot.sdk.fmk.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 告警对象
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 11:32
 */
@Data
public class BaseAlarmInfo implements Serializable {
    private static final long serialVersionUID = 7782325929169796217L;
    /**
     * 告警id
     */
    private String alarmId;

    /**
     * 告警名称
     */
    private String alarmName;

    /**
     * 告警级别
     */
    private int alarmSeverity;

    /**
     * 告警类别
     */
    private int alarmCategory;

    /**
     * 告警可能原因
     */
    private String alarmCauseTxt;

    /**
     * 告警修复建议
     */
    private String alarmRepairTxt;

    /**
     * 告警业务影响
     */
    private String alarmEffectBusiness;

    /**
     * 告警设备影响
     */
    private String alarmEffectDevice;

}
