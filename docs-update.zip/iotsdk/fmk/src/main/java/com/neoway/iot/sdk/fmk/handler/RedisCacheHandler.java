package com.neoway.iot.sdk.fmk.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.neoway.iot.sdk.fmk.model.AlarmInfoVo;
import com.neoway.iot.sdk.fmk.model.BaseAlarmInfo;
import com.neoway.iot.sdk.fmk.model.constant.ConstantVariable;
import com.neoway.iot.sdk.fmk.model.params.DeleteParams;
import com.neoway.iot.sdk.fmk.model.params.SearchParams;
import com.neoway.iot.sdk.fmk.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <pre>
 *  描述: Redis操作handler
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 19:41
 */
@Slf4j
@Service("redisCacheHandler")
public class RedisCacheHandler implements DataHandler {

    @Autowired
    private RedisUtils redisUtils;

    @Override
    public List<AlarmInfoVo> getAlarmInfoList(SearchParams searchParams) {
        if (searchParams == null || StringUtils.isEmpty(searchParams.getDeviceId())) {
            log.warn("Redis key not identify!");
            return null;
        }
        List<AlarmInfoVo> alarmInfoVos = null;
        String key = ConstantVariable.ALARM_REDIS_PREFIX_KEY + "_" + searchParams.getDeviceId();
        try {
            alarmInfoVos = JSON.parseObject(JSON.toJSONString(redisUtils.find(key)), new TypeReference<List<AlarmInfoVo>>(){});
        } catch (Exception e) {
            log.error("RedisCacheHandler.getAlarmInfoVos error!", e);
        }
        return alarmInfoVos;
    }

    @Override
    public int insert(AlarmInfoVo alarmInfoVo) {
        if (alarmInfoVo == null || StringUtils.isEmpty(alarmInfoVo.getDeviceId())) {
            log.warn("Redis key not identify!");
            return 0;
        }
        List<Object> cacheValue = new ArrayList<>();
        try {
            String key = ConstantVariable.ALARM_REDIS_PREFIX_KEY + "_" + alarmInfoVo.getDeviceId();
            Map<String, String> alarmMap = new HashMap<>(1);
            Map<String, String> alarmDataMap = new HashMap<>(3);
            alarmDataMap.put("alarmId", alarmInfoVo.getAlarmId());
            alarmDataMap.put("alarmStatus", String.valueOf(alarmInfoVo.getAlarmStatus()));
            alarmDataMap.put("deviceId", alarmInfoVo.getDeviceId());
            cacheValue.add(alarmDataMap);
            alarmMap.put("alarmInfo", JSON.toJSONString(cacheValue));
            redisUtils.replace(key, alarmMap,-1);
            return 1;
        } catch (Exception e) {
            log.error("RedisCacheHandler.insert error!", e);
            return 0;
        }
    }

    @Override
    public int batchInsert(List<AlarmInfoVo> alarmInfoVos) {
        if (CollectionUtils.isEmpty(alarmInfoVos)) {
            return 0;
        }
        try {
            Map<String, List<AlarmInfoVo>> collection = alarmInfoVos.stream().collect(Collectors.groupingBy(AlarmInfoVo::getDeviceId));
            collection.forEach((k, v) -> {
                String key = ConstantVariable.ALARM_REDIS_PREFIX_KEY + "_" + k;
                List<Object> cacheValue = new ArrayList<>();
                Map<String, String> alarmMap = new HashMap<>(1);
                for (AlarmInfoVo alarmInfoVo : v) {
                    if (alarmInfoVo == null || StringUtils.isEmpty(alarmInfoVo.getDeviceId())) {
                        continue;
                    }
                    Map<String, String> alarmDataMap = new HashMap<>(3);
                    alarmDataMap.put("alarmStatus", String.valueOf(alarmInfoVo.getAlarmStatus()));
                    alarmDataMap.put("alarmId", alarmInfoVo.getAlarmId());
                    alarmDataMap.put("deviceId", alarmInfoVo.getDeviceId());
                    cacheValue.add(alarmDataMap);
                }
                alarmMap.put("alarmInfo", JSON.toJSONString(cacheValue));
                redisUtils.replace(key, alarmMap,-1);
            });
            return 1;
        } catch (Exception e) {
            log.error("RedisCacheHandler.batchInsert error!", e);
            return 0;
        }
    }

    @Override
    public int update(AlarmInfoVo alarmInfoVo) {
        return this.insert(alarmInfoVo);
    }

    @Override
    public int delete(DeleteParams deleteParams) {
        if (deleteParams == null || StringUtils.isEmpty(deleteParams.getDeviceId())) {
            log.warn("Redis key not identify!");
            return 0;
        }
        try {
            String key = ConstantVariable.ALARM_REDIS_PREFIX_KEY + "_" + deleteParams.getDeviceId();
            redisUtils.delete(key);
            return 1;
        } catch (Exception e) {
            log.error("RedisCacheHandler.delete error!", e);
            return 0;
        }
    }

    @Override
    public List<BaseAlarmInfo> getStaticAlarmInfo(List<String> alarmIds) {
        List<BaseAlarmInfo> resultList = new ArrayList<>();
        String key = ConstantVariable.STATIC_ALARM_INFO_REDIS_KEY;
        try {
            Map<String, String> staticAlarmInfoMap = redisUtils.find(key);
            if (CollectionUtils.isEmpty(staticAlarmInfoMap)) {
                return null;
            }
            List<BaseAlarmInfo> baseAlarmInfos = JSON.parseObject(staticAlarmInfoMap.get("baseAlarmInfo"), new TypeReference<List<BaseAlarmInfo>>(){});
            if (CollectionUtils.isEmpty(baseAlarmInfos)) {
                return null;
            }
            if (CollectionUtils.isEmpty(alarmIds)) {
                return baseAlarmInfos;
            }
            for (String alarmId : alarmIds) {
                for (BaseAlarmInfo baseAlarmInfo : baseAlarmInfos) {
                    if (alarmId.equals(baseAlarmInfo.getAlarmId())) {
                        resultList.add(baseAlarmInfo);
                    }
                }
            }
        } catch (Exception e) {
            log.error("RedisCacheHandler.getAlarmInfoVos error!", e);
        }
        return resultList;
    }
}
