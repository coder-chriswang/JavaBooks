package com.neoway.iot.sdk.fmk.model.constant;

/**
 * <pre>
 *  描述: SQL 语句定义
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/02 16:18
 */
public interface ConstantVariable {

    String ALARM_REDIS_PREFIX_KEY = "alarm_info_";

    String ALARM_TABLE_PREFIX = "tbl_alarm_info_data";

    int ALARM_DATABASE_COUNT = 1;

    String INSERT_ALARM_INFO_SQL = "INSERT INTO %s ( alarm_id, alarm_source, alarm_st, alarm_et, alarm_status, alarm_count, alarm_desc, device_id, tenant_id ) VALUES ( ?,?,?,?,?,?,?,?,? );";

    String UPDATE_ALARM_INFO_SQL = "UPDATE %s SET alarm_status = ?, alarm_et = ? WHERE serial_no = ?;";

    String DELETE_ALARM_INFO_SQL = "DELETE * FROM %s WHERE serial_no = ?";

    String SELECT_ALARM_INFO_SQL = "SELECT a.serial_no serialNo, a.alarm_id alarmId, a.alarm_source alarmSource, a.alarm_st alarmSt, a.alarm_et alarmEt, a.alarm_status alarmStatus, a.alarm_count alarmCount, a.alarm_desc alarmDesc,a.device_id deviceId,a.tenant_id tenantId, b.alarm_severity alarmSeverity, b.alarm_name alarmName, b.alarm_cause_text alarmCauseText, b.alarm_category alarmCategory, b.alarm_repair_text alarmRepairText, b.alarm_effect_business alarmEffectBusiness, b.alarm_effect_device alarmEffectDevice FROM %s a LEFT JOIN tbl_alarm_identify_dict b ON a.alarm_id = b.alarm_id WHERE 1=1 ";

    String SELECT_STATIC_ALARM_INFO_SQL = "SELECT alarm_id alarmId, alarm_name alarmName, alarm_severity alarmSeverity, alarm_category alarmCategory, alarm_cause_text alarmCauseTxt, alarm_repair_text alarmRepairTxt, alarm_effect_business alarmEffectBusiness, alarm_effect_device alarmEffectDevice FROM tbl_alarm_identify_dict;";

    String INIT_TBL_ALARM_IDENTIFY_DICT = "CREATE TABLE IF NOT EXISTS `tbl_alarm_identify_dict` (\n" +
            "  `alarm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '告警ID',\n" +
            "  `alarm_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '告警名称',\n" +
            "  `alarm_severity` tinyint(2) DEFAULT NULL COMMENT '告警级别',\n" +
            "  `alarm_category` tinyint(2) DEFAULT NULL COMMENT '告警类型',\n" +
            "  `alarm_cause_text` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警可能原因',\n" +
            "  `alarm_repair_text` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警修复意见',\n" +
            "  `alarm_effect_business` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警对业务影响',\n" +
            "  `alarm_effect_device` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警对设备影响',\n" +
            "  PRIMARY KEY (`alarm_id`) USING BTREE,\n" +
            "  INDEX `alarm_name`(`alarm_name`) USING BTREE COMMENT '告警名称'\n" +
            ") ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;";

    String INIT_TBL_ALARM_INFO_DATA = "CREATE TABLE IF NOT EXISTS `tbl_alarm_info_data_%d`  (\n" +
            "  `serial_no` int(11) NOT NULL AUTO_INCREMENT COMMENT '告警流水号',\n" +
            "  `alarm_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '告警ID',\n" +
            "  `alarm_source` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '告警来源',\n" +
            "  `alarm_st` bigint(20) DEFAULT NULL COMMENT '告警开始时间，毫秒级',\n" +
            "  `alarm_et` bigint(20) DEFAULT NULL COMMENT '告警结束时间，毫秒级',\n" +
            "  `alarm_status` tinyint(2) DEFAULT NULL COMMENT '告警状态（1未清除，2清除）',\n" +
            "  `alarm_count` bigint(11) DEFAULT 0 COMMENT '告警发生次数',\n" +
            "  `alarm_desc` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警描述',\n" +
            "  `device_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '设备ID',\n" +
            "  `tenant_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '租户ID',\n" +
            "  PRIMARY KEY (`serial_no`) USING BTREE,\n" +
            "  INDEX `alarm_id`(`alarm_id`) USING BTREE COMMENT '告警ID',\n" +
            "  INDEX `alarm_status`(`alarm_status`) USING BTREE COMMENT '告警状态',\n" +
            "  INDEX `device_id`(`device_id`) USING BTREE COMMENT '设备ID',\n" +
            "  INDEX `tenant_id`(`tenant_id`) USING BTREE COMMENT '租户ID'\n" +
            ") ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;";

    String STATIC_ALARM_INFO_REDIS_KEY = "alarm:static:all";

    enum AlarmStatusEnum {
        NOT_CONFIRM(1,"告警未确认"),
        CONFIRMED(2,"告警已确认"),
        ;

        AlarmStatusEnum(int code, String desc) {
            this.code = code;
            this.desc = desc;
        }

        private int code;
        private String desc;

        public int getCode() {
            return code;
        }

        public String getDesc() {
            return desc;
        }
    }
}
