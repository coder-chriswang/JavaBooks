package com.neoway.iot.sdk.fmk;

import com.neoway.iot.sdk.fmk.model.constant.ConstantVariable;
import com.neoway.iot.sdk.fmk.partition.AlarmInfoPartition;
import com.neoway.iot.sdk.fmk.sharding.Partition;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <pre>
 *  描述: 分区对象管理类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 10:51
 */
@Configuration
public class PartitionManager {

    @Value("${fmk.table.count}")
    private String tableCount;
    /**
     * 告警信息分区表对象
     * 其中，关注于分表个数和表名前缀，分表个数和表名前缀可由配置信息指定传递
     * @return
     */
    @Bean("alarmInfoPartition")
    public Partition getAlarmInfoPartition() {
        Partition partition = new AlarmInfoPartition();
        partition.setDatabaseCount(ConstantVariable.ALARM_DATABASE_COUNT);
        partition.setTableCount(Integer.valueOf(tableCount));
        partition.setTablePrefix(ConstantVariable.ALARM_TABLE_PREFIX);
        return partition;
    }
}
