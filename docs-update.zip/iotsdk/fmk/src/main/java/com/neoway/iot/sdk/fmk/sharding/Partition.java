package com.neoway.iot.sdk.fmk.sharding;

import com.neoway.iot.sdk.fmk.hash.Hashing;
import com.neoway.iot.sdk.fmk.hash.MurmurHash;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 分区对象
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 10:19
 */
@Data
public class Partition implements Serializable {
    private static final long serialVersionUID = 9047792013698852363L;
    /**
     * 分区表总数
     */
    private int tableCount;

    /**
     * 分区库总数
     */
    private int databaseCount;

    /**
     * 分区表表名前缀
     */
    private String tablePrefix;

    /**
     * 根据id获取分区库
     *
     * @param id
     * @return
     */
    public Database getDatabase(String id) {
        return null;
    }

    /**
     * 根据id获取分区表
     *
     * @param id
     * @return
     */
    public Table getTable(String id) {
        Hashing hashing = new MurmurHash();
        Long key = hashing.hash(id);
        int mod = Math.abs((int) (key % tableCount));
        String tableName = tablePrefix + "_" + mod;
        Table table = new Table();
        table.setTableName(tableName);
        return table;
    }

    /**
     * 采取MurmurHash算法，根据设备唯一ID生成表名后缀数字
     * @param args
     */
    public static void main(String[] args) {
        Hashing hashing = new MurmurHash();
        // key为设备Id---DeviceId
        Long key = hashing.hash("164e297756964618a3402324b387949f");
        // 假设生成32张告警信息表
        int mod = Math.abs((int) (key % 32));
        // 输出表名称后缀为25  {{tenantId}}_alarm_info_{{25}}
        System.out.println(mod);
    }

}
