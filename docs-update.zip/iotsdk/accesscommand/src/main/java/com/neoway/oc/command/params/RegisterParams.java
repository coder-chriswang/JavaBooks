package com.neoway.oc.command.params;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 注册设备实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/12/24 16:42
 */
@Data
public class RegisterParams implements Serializable {
    private static final long serialVersionUID = 5707997696141053154L;

    private String manufacturerId;

    private String manufacturerName;

    private String deviceType;

    private String deviceName;

    private String model;

    private String protocolType;

    private String verifyCode;

    private String nodeId;

    private Integer timeout;

    private String appId;

    private String url;

    private String accessToken;
}
