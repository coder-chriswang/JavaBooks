package com.neoway.oc.command.params;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 删除设备参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/12/25 12:31
 */
@Data
public class DeleteDeviceParams implements Serializable {
    private static final long serialVersionUID = 6794064852966730816L;

    private String deviceId;

    private String accessToken;

    private String appId;

    private String url;
}
