package com.neoway.oc.command.params;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 创建命令参数实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/12/04 18:37
 */
@Data
public class OcCommandParams implements Serializable {
    private static final long serialVersionUID = -5076612970755771046L;

    private String url;

    private String appId;

    private String deviceId;

    private String serviceId;

    private String method;

    private String jsonRequest;

    private String callBackUrl;

    private String accessToken;
}
