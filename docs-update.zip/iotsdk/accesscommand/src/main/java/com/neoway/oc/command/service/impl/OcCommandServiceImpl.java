package com.neoway.oc.command.service.impl;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.neoway.oc.command.params.DeleteDeviceParams;
import com.neoway.oc.command.params.OcCommandParams;
import com.neoway.oc.command.params.RegisterParams;
import com.neoway.oc.command.service.OcCommandService;
import com.neoway.oc.command.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * <pre>
 *  描述: OC命令服务接口实现类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/18 16:09
 */
@Component
@Slf4j
public class OcCommandServiceImpl implements OcCommandService {

    /**
     * 鉴权获取的token, 有效期60分钟
     */
    private String accessToken = "";

    /**
     * 创建命令返回体中Key
     */
    private static final String KEY_COMMAND_ID = "commandId";


    @Override
    @SuppressWarnings("unchecked")
    public String authentication(String url, String appId, String secret) {
        try {
            // Two-Way Authentication
            HttpsUtil httpsUtil = new HttpsUtil();
            httpsUtil.initSSLConfigForTwoWay();

            String urlLogin = url + "/iocm/app/sec/v1.1.0/login";

            Map<String, String> paramLogin = new HashMap<>(2);
            paramLogin.put("appId", appId);
            paramLogin.put("secret", secret);

            StreamClosedHttpResponse responseLogin = httpsUtil.doPostFormUrlEncodedGetStatusLine(urlLogin, paramLogin);

            log.info("app auth success,return accessToken:");
            log.info("line={}", responseLogin.getStatusLine());
            log.info("content={}", responseLogin.getContent());

            Map<String, String> data = new HashMap<>();
            data = JsonUtil.jsonString2SimpleObj(responseLogin.getContent(), data.getClass());
            accessToken = data.get("accessToken");
        } catch (Exception e) {
            log.error("获取accessToken失败！", e);
        }
        return accessToken;
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean createCommand(OcCommandParams ocCommandParams) {
        if (ocCommandParams == null) {
            return false;
        }
        try {
            HttpsUtil httpsUtil = new HttpsUtil();
            httpsUtil.initSSLConfigForTwoWay();

            ObjectNode paras = JsonUtil.convertObject2ObjectNode(ocCommandParams.getJsonRequest());
            Map<String, Object> paramCommand = new HashMap<>(3);
            paramCommand.put("serviceId", ocCommandParams.getServiceId());
            paramCommand.put("method", ocCommandParams.getMethod());
            paramCommand.put("paras", paras);

            Map<String, Object> paramCreateDeviceCommand = new HashMap<>(5);
            paramCreateDeviceCommand.put("deviceId", ocCommandParams.getDeviceId());
            paramCreateDeviceCommand.put("command", paramCommand);
            paramCreateDeviceCommand.put("callbackUrl", ocCommandParams.getCallBackUrl());
            paramCreateDeviceCommand.put("expireTime", 0);
            paramCreateDeviceCommand.put("maxRetransmit", 3);

            String request = JsonUtil.jsonObj2Sting(paramCreateDeviceCommand);

            Map<String, String> header = new HashMap<>(2);
            header.put(Constant.HEADER_APP_KEY, ocCommandParams.getAppId());
            header.put(Constant.HEADER_APP_AUTH, "Bearer" + " " + ocCommandParams.getAccessToken());

            HttpResponse responseCreateDeviceCommand = httpsUtil.doPostJson(ocCommandParams.getUrl() + "/iocm/app/cmd/v1.4.0/deviceCommands", header, request);
            String responseBody = httpsUtil.getHttpResponseBody(responseCreateDeviceCommand);
            if (responseBody == null) {
                log.error("返回体为null!");
                return false;
            }
            Map<String, String> dataMap = new HashMap<>();
            dataMap = JsonUtil.jsonString2SimpleObj(responseBody, dataMap.getClass());
            String commandId = dataMap.get(KEY_COMMAND_ID);
            log.info("commandId = {}", commandId);
            return !StringUtil.strIsNullOrEmpty(dataMap.get(KEY_COMMAND_ID));
        } catch (Exception e) {
            log.error("命令下发失败！", e);
        }
        return false;
    }

    @Override
    @SuppressWarnings("unchecked")
    public String findAllDeviceInfo(String url, String appId, String accessToken) {
        try {
            HttpsUtil httpsUtil = new HttpsUtil();
            httpsUtil.initSSLConfigForTwoWay();

            int pageNo = 0;
            int pageSize = 250;

            Map<String, String> paramQueryBatchDevices = new HashMap<>(2);
            paramQueryBatchDevices.put("pageNo", String.valueOf(pageNo));
            paramQueryBatchDevices.put("pageSize", String.valueOf(pageSize));

            Map<String, String> header = new HashMap<>(2);
            header.put(Constant.HEADER_APP_KEY, appId);
            header.put(Constant.HEADER_APP_AUTH, "Bearer" + " " + accessToken);

            StreamClosedHttpResponse responseQueryBatchDevices = httpsUtil.doGetWithParasGetStatusLine(url + "/iocm/app/dm/v1.4.0/devices", paramQueryBatchDevices, header);
            if (responseQueryBatchDevices != null) {
                return responseQueryBatchDevices.getContent();
            } else {
                return null;
            }
        } catch (Exception e) {
            log.error("查询OC设备信息失败！");
            return null;
        }
    }

    @Override
    public String registerDevice(RegisterParams registerParams) {
        try {
            HttpsUtil httpsUtil = new HttpsUtil();
            httpsUtil.initSSLConfigForTwoWay();

            Map<String, Object> paramDeviceInfo = new HashMap<>(5);
            paramDeviceInfo.put("manufacturerId", registerParams.getManufacturerId());
            paramDeviceInfo.put("manufacturerName", registerParams.getManufacturerName());
            paramDeviceInfo.put("deviceType", registerParams.getDeviceType());
            paramDeviceInfo.put("model", registerParams.getModel());
            paramDeviceInfo.put("protocolType", registerParams.getProtocolType());

            Map<String, Object> paramReg = new HashMap<>(4);
            paramReg.put("verifyCode", registerParams.getVerifyCode().toUpperCase());
            paramReg.put("nodeId", registerParams.getVerifyCode().toUpperCase());
            paramReg.put("deviceInfo", paramDeviceInfo);
            paramReg.put("timeout", registerParams.getTimeout());
            paramReg.put("deviceName", registerParams.getDeviceName());

            String jsonRequest = JsonUtil.jsonObj2Sting(paramReg);

            Map<String, String> header = new HashMap<>();
            header.put(Constant.HEADER_APP_KEY, registerParams.getAppId());
            header.put(Constant.HEADER_APP_AUTH, "Bearer" + " " + registerParams.getAccessToken());

            StreamClosedHttpResponse responseRegisterDirectConnectedDevice = httpsUtil.doPostJsonGetStatusLine(registerParams.getUrl() + "/iocm/app/reg/v1.1.0/deviceCredentials", header, jsonRequest);

            if (responseRegisterDirectConnectedDevice != null) {
                return responseRegisterDirectConnectedDevice.getContent();
            } else {
                return null;
            }

        } catch (Exception e) {
            log.error("注册设备失败！");
            return null;
        }
    }

    @Override
    public boolean deleteDeviceInfo(DeleteDeviceParams deleteDeviceParams) {
        try {
            HttpsUtil httpsUtil = new HttpsUtil();
            httpsUtil.initSSLConfigForTwoWay();

            String urlDeleteDirectConnectedDevice = deleteDeviceParams.getUrl() +  "/iocm/app/dm/v1.4.0/devices/" + deleteDeviceParams.getDeviceId();

            Map<String, String> header = new HashMap<>(2);
            header.put(Constant.HEADER_APP_KEY, deleteDeviceParams.getAppId());
            header.put(Constant.HEADER_APP_AUTH, "Bearer" + " " + accessToken);

            StreamClosedHttpResponse responseDeleteDirectConnectedDevice = httpsUtil.doDeleteWithParasGetStatusLine(urlDeleteDirectConnectedDevice, null, header);
            return responseDeleteDirectConnectedDevice != null;
        } catch (Exception e) {
            log.error("删除设备失败！", e);
            return false;
        }
    }
}
