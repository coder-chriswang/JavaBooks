package com.neoway.oc.command.service;

import com.neoway.oc.command.params.DeleteDeviceParams;
import com.neoway.oc.command.params.OcCommandParams;
import com.neoway.oc.command.params.RegisterParams;

/**
 * <pre>
 *  描述: OC命令服务接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/18 15:59
 */
public interface OcCommandService {

    /**
     * OC鉴权获取访问token
     * @param url
     * @param appId
     * @param secret
     * @return accessToken
     */
    String authentication(String url, String appId, String secret);

    /**
     * OC应用端下发命令
     * @param ocCommandParams
     * @return
     */
    boolean createCommand(OcCommandParams ocCommandParams);

    /**
     * OC获取设备信息
     * @param url
     * @param appId
     * @param accessToken
     * @return
     */
    String findAllDeviceInfo(String url, String appId, String accessToken);

    /**
     * 注册设备信息
     * @param registerParams
     * @return
     */
    String registerDevice(RegisterParams registerParams);

    /**
     * 删除设备信息
     * @param deleteDeviceParams
     * @return
     */
    boolean deleteDeviceInfo(DeleteDeviceParams deleteDeviceParams);
}
