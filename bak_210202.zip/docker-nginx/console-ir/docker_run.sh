#!/usr/bin/env bash

# 运行容器
# --name 容器名称
# -p 指定端口映射
# -v 指定卷映射，[本地目录路径]:[容器目录路径]
# -e 指定环境变量
docker run --name iot-console-ir -p 8800:80 -d iot-console-ir:2.0.0
