### 在打镜像时候，将前端工程文件夹下的文件替换为最新的版本

####### 查看镜像服务内网IP
docker inspect --format='{{.Name}} - {{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' $(docker ps -aq)
创建子网，制定容器服务IP
docker network create --subnet=172.172.0.0/24 docker-hw0
docker run脚本
docker run -i -d --net docker-hw0 --ip 172.172.0.10 --name iot-console-er -p 80:80 -d iot-console-er:2.0.0