#!/usr/bin/env bash

# -t 后面指定的是docker的镜像名称和版本，一般和jar包的一样即可
docker build -t iot-console-er:2.0.0 -f Dockerfile .
