/*
 * @Author: 张通
 * @Date: 2020-09-07 10:41:57
 * @LastEditors: 张通
 * @LastEditTime: 2020-09-17 15:50:00
 * @Description: file content
 */
import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import app from './modules/app'
import settings from './modules/settings'
import user from './modules/user'
import resources from './modules/resources'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app,
    settings,
    user,
    resources
  },
  getters
})

export default store
