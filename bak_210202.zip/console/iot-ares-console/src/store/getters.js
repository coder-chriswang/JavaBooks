/*
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 张通
 * @LastEditTime: 2020-09-17 15:50:21
 * @Description: file content
 */
const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  language: state => state.app.language,
  token: state => state.user.token,
  refreshToken: state => state.user.refreshToken,
  userInfo: state => state.user.userInfo,
  uid: state => state.user.uid,
  name: state => state.user.name
}
export default getters
