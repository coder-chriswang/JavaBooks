/*
 * @Author: 张通
 * @Date: 2020-09-17 15:46:16
 * @LastEditors: 张通
 * @LastEditTime: 2020-09-24 20:13:06
 * @Description: file content
 */
const resources = {
  state: {
    isShowFooterDetails: false, // 控制资源页面footer是否显示
    resourcesDetails: false, // 是否显示详情页
    showTitleSearch: false, // 是否显示titlesearch
    selectedNum: null, // 展示
    tableRow: {}, // table行
    requestType: {}, // ci  ns  category
    eventHeader: [], // 上行、下行事件header
    giveHeader: [], // 告警header
    monitorHeader: [], // 监控header
    positionTrack: [] // 位置轨迹
  },
  getters: {
    isShowFooterDetails: state => state.isShowFooterDetails,
    resourcesDetails: state => state.resourcesDetails,
    showTitleSearch: state => state.showTitleSearch,
    selectedNum: state => state.selectedNum,
    tableRow: state => state.tableRow,
    requestType: state => state.requestType,
    eventHeader: state => state.eventHeader,
    giveHeader: state => state.giveHeader,
    monitorHeader: state => state.monitorHeader,
    positionTrack: state => state.positionTrack
  },
  mutations: {
    CHANGE_STATE: (state, { key, value }) => {
      state[key] = value
    }
  },
  actions: {
    changeFooterDetails({ commit }, value) {
      commit('CHANGE_STATE', { key: 'isShowFooterDetails', value: value })
    },
    changeResourcesDetails({ commit }, value) {
      commit('CHANGE_STATE', { key: 'resourcesDetails', value: value })
    },
    changeShowTitleSearch({ commit }, value) {
      commit('CHANGE_STATE', { key: 'showTitleSearch', value: value })
    },
    changeSelectedNum({ commit }, value) {
      commit('CHANGE_STATE', { key: 'selectedNum', value: value })
    },
    setTableRow({ commit }, value) {
      commit('CHANGE_STATE', { key: 'tableRow', value: value })
    },
    setRequestType({ commit }, value) {
      commit('CHANGE_STATE', { key: 'requestType', value: value })
    }
  }
}
export default resources
