/*
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-09 09:54:53
 * @Description: file content
 */
import Vue from 'vue'
import Cookies from 'js-cookie'
import Element from 'element-ui'
import i18n from './lang' // internationalization
import App from './App'
import store from './store'
import router from './router'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets
import 'element-ui/lib/theme-chalk/index.css'
import '@/styles/index.scss' // global css
import '@/icons' // icon
import '@/permission' // permission control
import Bus from '@/utils/bus'
// 自定义icon 阿里巴巴icon
import '@/assets/iconfont/iconfont.css'

Vue.prototype.$bus = Bus

// 设置页面文字不可选中
document.onselectstart = function() { return false }

/**
 * If you don't want to use mock-server
 * you want to use MockJs for mock api
 * you can execute: mockXHR()
 *
 * Currently MockJs will be used in the production environment,
 * please remove it before going online ! ! !
 */
// if (process.env.NODE_ENV === 'production') {
//   const { mockXHR } = require('../mock')
//   mockXHR()
// }

Vue.use(Element, {
  size: Cookies.get('size') || 'medium', // set element-ui default size
  i18n: (key, value) => i18n.t(key, value)
})
Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  store,
  i18n,
  render: h => h(App)
})
