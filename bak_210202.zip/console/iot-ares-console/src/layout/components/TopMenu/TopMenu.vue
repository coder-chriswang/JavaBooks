<!--
 * @Author: 张通
 * @Date: 2020-10-16 11:16:37
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-11 14:05:29
 * @Description: file content
-->
<template>
  <div class="top-menu">
    <el-menu
      :default-active="activeIndex2"
      class="el-menu-demo"
      mode="horizontal"
      text-color="#fff"
      active-text-color="#fff"
      :router="true"
    >
      <el-menu-item v-for="(item,index) in router" :key="`router${index}`" :index="item.path">
        <i :class="`${item.icon} menu-item`" />
        <span slot="title">{{ item.name }}</span></el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeIndex2: '/dashboard',
      router: [
        {
          icon: 'iconfont icon-daping',
          name: this.$t('dashboard.anOverviewOf'),
          path: '/dashboard'
        },
        {
          icon: 'iconfont icon-daping',
          name: this.$t('route.application'),
          path: '/application'
        },
        {
          icon: 'iconfont icon-peizhi',
          name: this.$t('alarm.resources'),
          path: '/resources'
        },
        {
          icon: 'iconfont icon-alarm',
          name: this.$t('alarm.alarm'),
          path: '/alarm'
        },
        {
          icon: 'iconfont icon-tongji',
          name: this.$t('route.statistics'),
          path: '/statistics'
        },
        {
          icon: 'iconfont icon-yunwei',
          name: this.$t('route.system'),
          path: '/system'
        }
      ]
    }
  },
  watch: {
    '$route'(newRoute) {
      this.activeIndex2 = newRoute.path
    }
  },
  mounted() {
    const path = window.location.hash.split('/')[1]
    this.activeIndex2 = `/${path}`
  },
  methods: {

  }
}
</script>

<style lang="scss" scoped>
@import '../../../styles/variables.scss';
.top-menu {
  display: flex;
  line-height: 63px;
  justify-content: center;
  .el-menu {
    background: none;
    border: none;
  }
  .el-menu--horizontal>.el-menu-item:not(.is-disabled):focus, .el-menu--horizontal>.el-menu-item:not(.is-disabled):hover, .el-menu--horizontal>.el-submenu .el-submenu__title:hover {
    background: #409EFF;
  }
  .el-menu-item {
    background: none ;
    border: none !important;

  }
  .el-menu-item:hover {
    background: none;
  }

  .menu-item {
    color: #fff;
    padding-right: 8px;
    user-select:none;
  }
  .menu-item:hover{
    background-color: $linghtBlue2;
  }
  .is-active  {
    background-color: $linghtBlue1;
  }
  .menu-item:hover {
    background: none;
  }
}
</style>

