<template>
  <div class="navbar">

    <div class="left-menu">
      <img src="../../assets/login_logo.png">
    </div>
    <TopMenu />
    <div class="right-menu">
      <Help />
      <Alarm :severity-and-count-vos="SeverityAndCount" :color-severity="colorSeverity" />
      <LangSelect class="lang-selete" style="margin-right: 20px;" :hide-words="false" />
      <el-dropdown class="avatar-container" trigger="click">
        <div class="avatar-wrapper">
          {{ userInfo.username }}
          <i class="el-icon-caret-bottom" />
        </div>
        <el-dropdown-menu slot="dropdown" class="user-dropdown">
          <router-link to="/">
            <el-dropdown-item>{{ $t('navbar.dashboard') }}</el-dropdown-item>
          </router-link>
          <el-dropdown-item @click.native="logout">
            <span style="display:block;"> {{ $t('navbar.logOut') }} </span>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </div>
</template>

<script>
import LangSelect from '@/components/LangSelect/index.vue'
import Help from '@/components/Help/index.vue'
import Alarm from '@/components/Alarm/index.vue'
// import TopMenu from '../components/TopMenu/index.vue'
import TopMenu from '../components/TopMenu/TopMenu.vue'
import { mapGetters } from 'vuex'
import { getAlarmSeverityAndCount } from '@/api/user.js'

export default {
  components: {
    LangSelect,
    Help,
    TopMenu,
    Alarm
  },
  data() {
    return {
      SeverityAndCount: [],
      colorSeverity: 0,
      timer: 0
    }
  },
  computed: {
    ...mapGetters([
      'userInfo'
    ])
  },
  created() {
    this.getAlarmInfo()
    this.timer = setInterval(async() => {
      this.getAlarmInfo()
    }, 60000)
  },
  mounted() {
    // console.log(this.userInfo.username)
  },
  beforeDestroy() {
    clearInterval(this.timer)
  },
  methods: {
    async getAlarmInfo() {
      const res = await getAlarmSeverityAndCount()
      this.SeverityAndCount = res.data.alarmSeverityAndCountVos
      this.colorSeverity = res.data.colorSeverity
    },
    async logout() {
      await this.$store.dispatch('user/logout')
      this.$router.push(`/login?redirect=${this.$route.fullPath}`)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.navbar {
  height: $navbarHeight;
  overflow: hidden;
  // position: fixed;
  width: 100vw;
  box-shadow: 0 1px 4px rgba(0,21,41,.08);
  display: flex;
  justify-content: space-between;
  background: url('../../assets/bgTop.jpg')  center center no-repeat;
  background-size: 100%;

  .breadcrumb-container {
    float: left;
  }
  .left-menu {
    display: flex;
    align-items: center;
    line-height: 63px;
    margin-left: 20px;
    img {
      width: 138px;
    }
  }
  .right-menu {
    height: 100%;
    line-height: $navbarHeight;

    &:focus {
      outline: none;
    }

    .right-menu-item {
      display: inline-block;
      padding: 0 8px;
      height: 100%;
      font-size: 18px;
      color: #5a5e66;
      vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
        transition: background .3s;

        &:hover {
          background: rgba(0, 0, 0, .025)
        }
      }
    }

    .avatar-container {
      margin-right: 30px;
      .avatar-wrapper {
        position: relative;
        display: flex;
        line-height: 17px;
        cursor: pointer;
        font-size: 14px;
        color: #fff;
        user-select:none;
      }
    }
  }
}
</style>
