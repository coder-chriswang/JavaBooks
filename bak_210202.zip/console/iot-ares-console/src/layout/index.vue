<!--
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-11 16:28:18
 * @Description: file content
-->
<template>
  <div class="app-wrapper">
    <navbar />
    <div class="main-container">
      <app-main />
    </div>
  </div>
</template>

<script>

import {
  Navbar,
  AppMain } from './components'

export default {
  name: 'Layout',
  components: {
    Navbar,
    AppMain
  },
  computed: {
    device() {
      return this.$store.state.app.device
    },
    fixedHeader() {
      return this.$store.state.settings.fixedHeader
    }
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch('app/closeSideBar', { withoutAnimation: false })
    }
  }
}
</script>

<style lang="scss" scoped>
  @import "~@/styles/mixin.scss";
  @import "~@/styles/variables.scss";
  .app-wrapper {
    @include clearfix;
    position: relative;
    background-color: darkBlue2;
    // background: url("../assets/bg.jpg") center center no-repeat;
    background-attachment: fixed;
    background-size: 100% 100%;
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    &.mobile.openSidebar{
      position: fixed;
      top: 0;
    }

    .main-container {
      background: url("../assets/bgBottom.jpg") center center no-repeat;
      // min-height: 100%;
      transition: margin-left .28s;
      // margin-left: $sideBarWidth;
      // margin-top: $navbarHeight;
      // position: fixed;
      height: calc(100% - #{$navbarHeight});
      width: 100%;
      background-size: 100% 100%;
    }
  }
  .drawer-bg {
    background: #000;
    opacity: 0.3;
    width: 100%;
    top: 0;
    height: 100%;
    position: absolute;
    z-index: 999;
  }

  .fixed-header {
    position: fixed;
    top: 0;
    right: 0;
    z-index: 9;
    width: calc(100% - #{$sideBarWidth});
    transition: width 0.28s;
  }

  .hideSidebar .fixed-header {
    width: calc(100% - 54px)
  }

  .mobile .fixed-header {
    width: 100%;
  }
</style>
