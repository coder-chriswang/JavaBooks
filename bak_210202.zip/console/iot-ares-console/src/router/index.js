/*
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-11 14:05:57
 * @Description: file content
 */
import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: 'dashboard',
      component: () => import('@/views/dashboard/dashboard'),
      meta: { title: 'dashboard', icon: 'dashboard' }
    }]
  },
  {
    path: '/resources',
    component: Layout,
    redirect: '/resources',
    children: [{
      path: '/',
      name: 'resources',
      component: () => import('@/views/resources/resources'),
      meta: { title: 'resources', icon: 'resources' }
    },
    {
      path: 'detail',
      name: 'detail',
      component: () => import('@/views/resources/detail'),
      meta: { title: 'resources', icon: 'resources' }
    }]
  },
  {
    path: '/application',
    component: Layout,
    redirect: '/application',
    children: [{
      path: '/',
      name: 'application',
      component: () => import('@/views/application/pages/Application'),
      meta: { title: 'application', icon: 'application' }
    },
    {
      path: 'applicationMap',
      name: 'applicationMap',
      component: () => import('@/views/application/pages/ApplicationMap'),
      meta: { title: 'applicationMap', icon: 'applicationMap' }
    }]
  },
  {
    path: '/alarm',
    component: Layout,
    redirect: '/alarm',
    children: [{
      path: '/',
      name: 'alarm',
      component: () => import('@/views/alarm/alarm'),
      meta: { title: 'alarm', icon: 'alarm' }
    }]
  },
  {
    path: '/statistics',
    component: Layout,
    redirect: '/statistics',
    children: [{
      path: '/',
      name: 'statistics',
      component: () => import('@/views/statistics/statistics'),
      meta: { title: 'statistics', icon: 'statistics' }
    }]
  },
  {
    path: '/system',
    component: Layout,
    redirect: '/system',
    children: [{
      path: '/',
      name: 'system',
      component: () => import('@/views/system/system'),
      meta: { title: 'system', icon: 'system' }
    }]
  },

  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
