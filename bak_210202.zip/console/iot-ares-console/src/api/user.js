/*
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-14 14:32:32
 * @Description: file content
 */
import request from '@/utils/request'
const iam = '/iam'
export function login(data) {
  return request({
    url: iam + '/auth/unifyLogin',
    method: 'post',
    data
  })
}
export function getInfo(token) {
  return request({
    url: iam + '/user/getPrincipal',
    method: 'get'
  })
}
export function refreshToken(data) {
  return request({
    url: iam + '/auth/refresh',
    method: 'get',
    data: data
  })
}

export function getCodeImage(data) {
  return request({
    url: iam + '/common/codeImage',
    method: 'get',
    params: data
  })
}

export function logout() {
  return request({
    url: iam + '/auth/unifyLogout',
    method: 'get'
  })
}

export function getLocale() {
  return request({
    url: '/mng/v1/i18n?enable=f',
    method: 'get'
  })
}

export function getAlarmSeverityAndCount() {
  return request({
    url: '/mo/v1/fm/meta/alarmSeverityAndCount',
    method: 'get'
  })
}
