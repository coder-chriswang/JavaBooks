/*
 * @Author: 刘彦宏
 * @Date: 2020-09-14 14:29:41
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-25 14:31:09
 * @Description: file content
 */
import request from '@/utils/request'

/**
 * 查询view视图列表
 * @param {*} data 分页信息，不传则不分页
 */
export function getViewsTableData(data) {
  return request({
    url: '/mng/v1/dashboard/view',
    method: 'post',
    data
  })
}

/**
 * 查询视图下属的chartid数组
 * @param {*} data viewCode
 */
export function getChartID(data = '') {
  return request({
    url: '/mng/v1/dashboard/view/' + data,
    method: 'get'
  })
}

/**
 * 查询chart列表
 * @param {*} data 分页信息
 */
export function getChartTableData(data) {
  return request({
    url: '/bi/v1/chart/list',
    method: 'post',
    data
  })
}

/**
 * 根据viewCode查询chartId数组
 * @param {*} data viewCode
 */
export function getChartViewData(data = '') {
  return request({
    url: '/bi/v1/chart/data?chartid=' + data,
    method: 'get'
  })
}

export function addView(data) {
  return request({
    url: '/mng/v1/dashboard/view/add',
    method: 'post',
    data
  })
}

export function deleteView(data) {
  return request({
    url: '/mng/v1/dashboard/view/' + data,
    method: 'delete'
  })
}

export function updateView(data) {
  return request({
    url: '/mng/v1/dashboard/view/update',
    method: 'post',
    data
  })
}
