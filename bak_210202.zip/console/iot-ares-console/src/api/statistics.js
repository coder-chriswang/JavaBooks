/*
 * @Author: 张通
 * @Date: 2020-10-13 14:33:24
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-23 11:10:47
 * @Description: file content
 */
import request from '@/utils/request'
import axios from 'axios'
export const cancelQueue = []
export function getChartByViewId(viewId) {
  return request({
    url: `/bi/v1/chart/by/${viewId}`,
    method: 'get',
    cancelToken: new axios.CancelToken(c => {
      cancelQueue.push(c)
      cancelQueue.length - 1 && (cancelQueue[0](''), cancelQueue.shift())
    })
  })
}

export function getTypeMenu() {
  return request({
    url: `/bi/v1/viewConfig/queryView`,
    method: 'get'
  })
}

export function deleteReportStrategy(id) {
  return request({
    url: `/bi/v1/reportStrategy/${id}`,
    method: 'delete'
  })
}
export function updateView(data) {
  return request({
    url: '/bi/v1/viewConfig/update',
    method: 'post',
    data
  })
}

export function addPeriodReport(data) {
  return request({
    url: '/bi/v1/reportStrategy/add',
    method: 'post',
    data
  })
}
export function updatePeriodReport(data) {
  return request({
    url: '/bi/v1/reportStrategy/update',
    method: 'post',
    data
  })
}

export function getViewTableData(data) {
  return request({
    url: '/bi/v1/reportStrategy/list',
    method: 'post',
    data
  })
}

export function getViewDropDown(params) {
  return request({
    url: '/bi/v1/reportStrategy/getViewDropDown',
    method: 'get',
    params
  })
}

export function getNotifyGroup(params) {
  return request({
    url: `/mng/v1/notifyGroup/${params.type}`,
    method: 'get',
    params
  })
}

export function getViewChartList(data) {
  return request({
    url: '/bi/v1/chart/viewChartList',
    method: 'post',
    data
  })
}

export function getViewAllChartList(data) {
  return request({
    url: '/bi/v1/viewConfig/queryViewChartList',
    method: 'post',
    data
  })
}
// emailserver
export function saveEmailserver(data) {
  return request({
    url: '/mng/v1/emailserver',
    method: 'post',
    data
  })
}

export function getEmailserverConfig(params) {
  return request({
    url: '/mng/v1/emailserver/statistics',
    method: 'get',
    params
  })
}

export function getNoticeGroupTableData(data) {
  return request({
    url: '/mng/v1/notifyGroup/list',
    method: 'post',
    data
  })
}

export function addNotifyGroup(data) {
  return request({
    url: '/mng/v1/notifyGroup',
    method: 'post',
    data
  })
}
export function deleteNotifyGroup(data) {
  return request({
    url: `/mng/v1/notifyGroup/${data.code}`,
    method: 'delete',
    data
  })
}

export function modifyNotifyGroup(data) {
  return request({
    url: '/mng/v1/notifyGroup',
    method: 'put',
    data
  })
}

export function getGroupOrNotNotifyUser(params) {
  if (params) {
    return request({
      url: '/mng/v1/notifyGroup/getGroupOrNotNotifyUser/' + params.code,
      method: 'get'
    })
  } else {
    return request({
      url: '/mng/v1/notifyGroup/getGroupOrNotNotifyUser',
      method: 'get'
    })
  }
}

