/*
 * @Author: 张通
 * @Date: 2020-09-07 10:41:56
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-19 17:41:42
 * @Description: file content
 */

import request from '@/utils/request'

export default class Resource {
  static rm = `/cm`
  static mo = `/mo`
  // get 查看接口
  static getSeeMenu(data) {
    return request({
      url: `${Resource.rm}/v1/command/`,
      method: 'post',
      data
    })
  }
  // get 配置接口
  static getConfigMenu() {
    return request({
      url: `${Resource.rm}/v1/meta/ci?type=M`,
      method: 'get'
    })
  }
  static getConfigTableHeader(data) {
    return request({
      url: `${Resource.rm}/v1/meta/${data.category}/${data.ci}`,
      method: 'get'
    })
  }
  static getTableData(data) {
    return request({
      url: `${Resource.rm}/v1/command`,
      method: 'post',
      data
    })
  }
  // get tab 页签数据
  static getTab(data) {
    return request({
      url: `${Resource.rm}/v1/resource/om/${data.ns}/${data.ci}`,
      method: 'get'
    })
  }
  // get 基础信息仪表盘
  static getBicStatus(data) {
    return request({
      url: `${Resource.rm}/v1/resource/status/${data.instanceid}`,
      method: 'get'
    })
  }
  // get 告警
  static getGive(data) {
    return request({
      url: `${Resource.mo}/v1/fm/data`,
      method: 'post',
      data
    })
  }
  // 告警select
  static getConfigGiveSelect() {
    return request({
      url: `/mo/v1/fm/meta/alarms`,
      method: 'get'
    })
  }
  // get 监控图表模型
  static getMonitor_one(data) {
    return request({
      url: `${Resource.mo}/v1/pm/chart/${data.ci}`,
      method: 'post',
      data
    })
  }
  // get 监控图表数据
  static getMonitor_two(data) {
    return request({
      url: `${Resource.mo}/v1/pm/data`,
      method: 'post',
      data
    })
  }
  // 上下行事件
  static getEventHander(data) {
    return request({
      url: `${Resource.mo}/v1/em/data`,
      method: 'post',
      data
    })
  }
  // 左边菜单查看
  static getsee(data) {
    return request({
      url: `${Resource.rm}/v1/resource/tag`,
      method: 'get',
      data
    })
  }
  // 轨迹
  static getPositionTrack(data) {
    return request({
      url: `${Resource.mo}/v1/lm/track`,
      method: 'post',
      data
    })
  }
}

/**
 * 查询view视图列表
 * @param {*} data 分页信息，不传则不分页
 */
export function getViewsTableData(data) {
  return request({
    url: '/bi/v1/viewConfig/viewList',
    method: 'post',
    data
  })
}

/**
 * 查询chart列表
 * @param {*} data 分页信息
 */
export function getChartTableData(data) {
  return request({
    url: '/bi/v1/viewConfig/queryViewChartList',
    method: 'post',
    data
  })
}

export function addView(data) {
  return request({
    url: '/bi/v1/viewConfig/addView',
    method: 'post',
    data
  })
}

export function queryDetail(data) {
  return request({
    url: '/bi/v1/viewConfig/' + data,
    method: 'get'
  })
}

export function deleteView(data) {
  return request({
    url: '/bi/v1/viewConfig/' + data,
    method: 'delete'
  })
}

export function updateView(data) {
  return request({
    url: '/bi/v1/viewConfig/update',
    method: 'post',
    data
  })
}
