/*
 * @Author: 张通
 * @Date: 2020-10-13 14:33:24
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-23 11:10:47
 * @Description: file content
 */
import request from '@/utils/request'

// export function login(data) {
//   return request({
//     url: '/auth/unifyLogin',
//     method: 'post',
//     data
//   })
// }
export function getScreenChart(params) {
  return request({
    url: '/bi/v1/chart/data',
    method: 'get',
    params
  })
}
