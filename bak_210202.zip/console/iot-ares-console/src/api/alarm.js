/*
 * @Author: 张通
 * @Date: 2020-10-13 14:33:24
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-23 11:10:47
 * @Description: file content
 */
import request from '@/utils/request'
export default class Alarm {
  static mo = '/mo'
  static cm = '/cm'
  //  告警
  static getMoData(data) {
    return request({
      url: `${Alarm.mo}/v1/fm/data`,
      method: 'post',
      data
    })
  }
  // 告警三级联动通过产品域
  static getResourceTypesByNs(id) {
    return request({
      url: `${Alarm.mo}/v1/fm/meta/getResourceTypes/${id}`,
      method: 'get'
    })
  }
  // 资源类型下拉列表
  static getResourceType(data) {
    return request({
      url: `${Alarm.cm}/v1/resource/tag?targetId=${data}`,
      method: 'get'
    })
  }
  // 告警 指标名称下拉
  static getMetricByType(type) {
    return request({
      url: `${Alarm.mo}/v1/pm/metric/getMetricByType/${type}`,
      method: 'get'
    })
  }
  // 告警 阈值条件下拉
  static getMetricCondition(metric) {
    return request({
      url: `${Alarm.mo}/v1/fm/meta/getTargetThresholds/${metric}`,
      method: 'get'
    })
  }

  // 告警 产品域下拉
  static getProductDomain() {
    return request({
      url: `${Alarm.mo}/v1/pm/getProductDomain`,
      method: 'get'
    })
  }
  // 告警类型 search config
  static getMoSearchAlarm() {
    return request({
      url: `${Alarm.mo}/v1/fm/meta/alarms`,
      method: 'get'
    })
  }
  // 告警定义列表
  static getFmMetas(data) {
    return request({
      url: `${Alarm.mo}/v1/fm/metas`,
      method: 'post',
      data
    })
  }
  // 告警定义列表数据添加
  static addFmMeta(data) {
    return request({
      url: `${Alarm.mo}/v1/fm/meta/add`,
      method: 'post',
      data
    })
  }
  // 告警定义列表数据删除
  static deleteFmMeta(code) {
    return request({
      url: `${Alarm.mo}/v1/fm/meta/${code}`,
      method: 'delete'
    })
  }
  // 告警定义列表数据更新
  static updateFmMeta(data) {
    return request({
      url: `${Alarm.mo}/v1/fm/meta/update`,
      method: 'post',
      data
    })
  }
  // 告警定义详情
  static getFmMetaDetail(code) {
    return request({
      url: `${Alarm.mo}/v1/fm/meta/${code}`,
      method: 'get'
    })
  }

  // 阈值定义列表
  static getPmMetas(data) {
    return request({
      url: `${Alarm.mo}/v1/pm/metas`,
      method: 'post',
      data
    })
  }
  // 阈值定义列表数据添加
  static addPmMeta(data) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta`,
      method: 'post',
      data
    })
  }
  // 阈值定义列表数据删除
  static deletePmMeta(code) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta/${code}`,
      method: 'delete'
    })
  }
  // 阈值定义展开列数据删除
  static deletePmRule(code, oCondition) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta/rule/${code}/${oCondition}`,
      method: 'delete'
    })
  }

  // 阈值定义列表数据更新
  static updatePmMeta(code, data) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta/${code}`,
      method: 'post',
      data
    })
  }
  // 阈值配置数据新增
  static configPmMeta(code, data) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta/rule`,
      method: 'post',
      data: { ...data, code }
    })
  }
  // 阈值配置数据编辑
  static updateConfigPmMeta(code, data) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta/rule/update`,
      method: 'post',
      data: { ...data, code }
    })
  }

  // 阈值定义列表详情
  static getPmMetaDetail(code) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta/${code}`,
      method: 'get'
    })
  }
  // 阈值定义展开行表格
  static getMetaExpand(code) {
    return request({
      url: `${Alarm.mo}/v1/pm/meta/ruleList/${code}`,
      method: 'get'
    })
  }
  // 活动告警清除
  static setActiveClear(data) {
    return request({
      url: `${Alarm.mo}/v1/fm/data/command`,
      method: 'post',
      data
    })
  }
}
