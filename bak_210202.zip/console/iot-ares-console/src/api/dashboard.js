/*
 * @Author: 张通
 * @Date: 2020-11-10 14:16:59
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-11 10:26:49
 * @Description: file content
 */
import request from '@/utils/request'
export default class {
  bi = '/bi'
  static getMapAlarmData(data = {}) {
    let url = `/bi/v1/chart/data?chartid=${data.chartid}`
    if (data.doInstanceId) {
      url = `/bi/v1/chart/gisData?chartid=${data.chartid}&doInstanceId=${data.doInstanceId}`
    }
    return request({
      url: url,
      method: 'get'
    })
  }
  static getGISDeviceData(data = {}) {
    const url = `/bi/v1/chart/queryGISData`
    // if (data.doInstanceId) {
    //   url = `/bi/v1/chart/gisData?chartid=${data.chartid}&doInstanceId=${data.doInstanceId}`
    // }
    return request({
      url: url,
      method: 'post',
      data
    })
  }
}
