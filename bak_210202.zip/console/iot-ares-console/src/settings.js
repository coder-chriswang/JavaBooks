/*
 * @Author: 刘彦宏
 * @Date: 2020-10-09 09:08:00
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-22 18:44:52
 * @Description: file content
 */
module.exports = {

  title: '物联感知平台',

  /**
   * @type {boolean} true | false
   * @description Whether fix the header
   */
  fixedHeader: false,

  /**
   * @type {boolean} true | false
   * @description Whether show the logo in sidebar
   */
  sidebarLogo: false
}
