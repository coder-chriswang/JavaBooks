/* eslint-disable no-undef */
<template>
  <div class="resource-container">
    <TitleTopGroup :key="currentPage" :chart-filter-data="resourceChart" :default-model="defaultModel" @handlerEvent="handlerEvent" />
    <!-- v-if="totalRecordCount" v-loading="loading" -->
    <div

      class="charts-container"
      :element-loading-text="$t('public.loading')"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
    >
      <el-row :gutter="15">
        <el-col v-for="(item, index) in _chartOptions" :key="index" :span="8">
          <Chart
            v-if="item.type === 'chart'"
            :id="item.id"
            :options-data="item"
            :update-time="item.time"
            :side-bar-opend="sidebar.opened"
            class="chart-div"
          >
            <div v-if="item.id === 'DeviceCountStatistic'">{{ item.chartName }}</div>
          </Chart>
          <Table
            v-else
            :pagination="false"
            :table-data="item.options.tableData.rows"
            :table-header="item.options.tableHeader"
            class="chart-div"
            :highlight-current-row="false"
            :last-table-column="false"
            :table-title="item.chartName"
          />
        </el-col>
      </el-row>
    </div>
    <!-- <div
      v-else
      :class="containerClass"
      class="charts-container"
    >
      <div class="no-data-available">
        <span>暂无数据</span>
      </div>
    </div> -->
    <el-dialog
      :visible="previewShow"
      width="80%"
      top="5vh"
      @close="previewShow=false"
    >
      <div class="preview-image" />
    </el-dialog>
  </div>
</template>

<script>
import {
  mapGetters
} from 'vuex'
import TitleTopGroup from '../components/TitleTopGroup'
import chartFilterConfig from '../components/chartFilterConfig'
import { getChartOptions } from '@/utils/getChartOptions'
import Chart from '@/components/Chart/Chart'
import Table from '@/components/Table/Table'
export default {
  name: 'ResourceReport',
  components: {
    TitleTopGroup,
    Chart,
    Table
  },
  props: {
    // 搜索框渲染对象
    chartOptions: {
      type: Array,
      default: () => []
    },
    currentPage: {
      type: String,
      default: () => ''
    }
  },
  data() {
    return {
      previewShow: false,
      defaultModel: {
        exportType: 0
      }
    }
  },
  computed: {
    _chartOptions() {
      const _chartOptions = []
      this.chartOptions.forEach(chartOption => {
        if (!chartOption.chartDs) {
          return
        }
        const chartOptions = JSON.parse(chartOption.chartDs)
        if (chartOptions.chartType !== 'table') {
          if (chartOption.chartId === 'FmActiveStatus') return
          if (chartOption.chartId === 'AlarmDistributeStatistic') {
            chartOptions.chartTitleColor = '#a5d6f8'
          }
          if (chartOption.chartId === 'RmStatus') {
            var colorMap = { 'UNKOWN': '#61a0a8', 'UNKNOWN': '#61a0a8', 'OFFLINE': '#2f4554', 'ONLINE': '#008acd' }
            chartOptions.chartColor = chartOptions.data.legend.map(item => colorMap[item])
          }
          const { ...options } = getChartOptions(chartOptions)
          _chartOptions.push({
            type: 'chart',
            id: chartOption.chartId,
            options: options,
            time: Date.now(),
            chartName: chartOption.chartName
          })
        } else {
          const tableHeaderArr = []
          chartOptions.data.tableHeader.forEach(item => {
            tableHeaderArr.push(item.key)
          })
          _chartOptions.push({
            type: 'table',
            id: chartOption.chartId,
            chartName: chartOption.chartName,
            options: chartOptions.data
          })
        }
      })
      return _chartOptions
    },
    ...mapGetters([
      'sidebar',
      'name'
    ])
  },
  created() {
    this.resourceChart = chartFilterConfig.call(this, 'resourceReport')
  },
  methods: {
    handlerEvent(e) {
      console.log(e, e.item.defaultModel.exportType)
      if (e.id === 'preview') {
        domtoimage.toPng(document.querySelector('#app'))
          .then((dataUrl) => {
            this.previewShow = true
            this.$nextTick(() => {
              const parent = document.querySelector('.resource-container .preview-image')
              const child = document.querySelector('.resource-container .preview-image img')
              if (child) {
                parent.removeChild(child)
              }
              const img = new Image()
              img.src = dataUrl
              parent.appendChild(img)
            })
          })
      } else if (e.id === 'export') {
        domtoimage.toPng(document.querySelector('#app'))
          .then(function(dataUrl) {
            if (e.item.searchModel.exportType === 0) {
              const JsPDF = jsPDF
              const pdf = new JsPDF('l', 'pt', 'a4')
              pdf.addImage(dataUrl, 'PNG', 0, 0, 841.89, 595.28)
              pdf.save(`report${Date.now()}.pdf`)
            } else {
              window.saveAs(dataUrl, `report${Date.now()}.png`)
            }
          })
      }
    }
  }
}

</script>

<style lang="scss" scoped>
  .resource-container{
    height: calc(100vh - 63px);
    flex: 1;
    align-self: flex-start;
  }
  .preview-image{
      width:100%;
      ::v-deep img{
        width: 100%;
      }
    }
  .charts-container {
    padding: 15px 7.5px 0 7.5px;
    height: calc(100% - 36px);
    overflow: auto;
    .chart-div {
      background-image: url('../../../assets/chartbox.png');
      width: 100%;
      height: calc((100vh - 115px)/3);
      background-repeat: round;
      padding: 10px 10px 20px;
    }
  }
</style>
