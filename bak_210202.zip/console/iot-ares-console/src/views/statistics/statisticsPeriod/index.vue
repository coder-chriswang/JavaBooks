<template>
  <div class="period-container">
    <div class="period-container-inner">
      <TitleTopGroup :chart-filter-data="statisticsPeriod" @handlerEvent="handlerEvent" />
      <TitleSearch :search-data="searchData" class="TitleSearch" @search="handleSearch" />
      <Table
        v-loading="loading"
        :table-data="tableData"
        :element-loading-text="$t('public.loading')"
        :table-header="tableHeader"
        :highlight-current-row="false"
        :current-page="pageInfo.currentPage"
        :page-size="pageInfo.pageSize"
        :total="total"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        class="table-class"
        @pagination-change="paginationChange"
      >
        <template slot-scope="scope">
          <!-- 组件嵌套导致scope包了两层 -->
          <el-button type="text" class="table-text-btn" @click="handleDetail(scope.scope.row)">{{ $t('public.detail') }}</el-button>
          <el-button type="text" class="table-text-btn" @click="handleEdit(scope.scope.row)">{{ $t('public.edit') }}</el-button>
          <el-button type="text" class="table-text-btn" @click="handleDelete(scope.scope.row)">{{ $t('public.delete') }}</el-button>
        </template>
      </Table>
      <ActionDialog
        v-if="dialogVisible"
        ref="ActionDialog"
        :title="dialogTitle"
        :visible="dialogVisible"
        :form-items="formItems"
        :form-data="formData"
        :rules-data="rulesData"
        :dialog-type="dialogType"
        width="400px"
        :span="24"
        @handleClose="handleClose"
        @submit="handleSubmit"
      />
      <el-dialog
        :title="dialogChartTitle"
        :visible.sync="dialogChartVisible"
        :modal-append-to-body="false"
        width="50%"
      >
        <el-form label-width="25%" :model="formChartData" :rules="rulesChartData">
          <el-form-item v-if="dialogTypeChart !== 'detail'" prop="name" :label="$t('system.viewName')">
            <el-input v-model="formChartData.name" />
          </el-form-item>
          <el-form-item v-if="dialogTypeChart !== 'detail'" :label="$t('system.viewDesc')">
            <el-input v-model="formChartData.desc" />
          </el-form-item>
        </el-form>
        <div class="dialog-table">
          <Table
            ref="chartTable"
            :table-data="chartData"
            :table-header="chartTableHeader"
            :highlight-current-row="false"
            table-size="mini"
            :current-page="pageInfoDetail.currentPage"
            :page-size="pageInfoDetail.pageSize"
            :total="detailTotal"
            :show-selection="dialogTypeChart !== 'detail'"
            :last-table-column="false"
            :selection-row="selectionRow"
            @pagination-change="paginationChartChange"
            @selection-change="handleSelect"
          />
        </div>
        <span v-if="dialogTypeChart !== 'detail'" slot="footer" class="dialog-footer">
          <el-button class="zt-button" @click="dialogChartVisible = false">{{ $t('public.cancel') }}</el-button>
          <el-button type="primary" @click="confirmChart">{{ $t('public.confirm') }}</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import TitleTopGroup from '../components/TitleTopGroup'
import chartFilterConfig from '../components/chartFilterConfig'
import formConfig from '../components/formConfig'
import TitleSearch from '@/components/TitleSearch/TitleSearch'
import Table from '@/components/Table/Table'
import { getViewDropDown, getViewTableData, addPeriodReport, getNotifyGroup, getViewChartList, getViewAllChartList, updateView, updatePeriodReport, deleteReportStrategy } from '@/api/statistics'
import ActionDialog from '@/components/ActionDialog/actionDialog'
export default {
  name: 'StatisticsPeriod',
  components: {
    Table,
    TitleSearch,
    TitleTopGroup,
    ActionDialog
  },

  data() {
    return {
      dialogFormOption: [[], [{
        value: '0 0 0/1 * * ?',
        label: this.$t('statistics.perHour')
      }, {
        value: '0 0 0 * * ?',
        label: this.$t('statistics.everyDay')
      }, {
        value: '0 0 0 1 * ?',
        label: this.$t('statistics.aMonth')
      }], [{
        value: 'email',
        label: this.$t('statistics.email')
      }], []],
      chartOptions: [],
      // chart模态框变量
      chartTypeMap: {
        Line: this.$t('public.line'),
        Gauge: this.$t('public.gauge'),
        Bar: this.$t('public.bar'),
        Table: this.$t('public.table'),
        Pie: this.$t('public.pie'),
        ringScreen: this.$t('public.ringScreen'),
        LiquidFill: this.$t('public.LiquidFill')
      },
      dialogChartTitle: '',
      dialogChartId: '',
      dialogChartVisible: false,
      chartData: [],
      filterTableInput: '',
      chartTableHeader: [
        {
          name: this.$t('system.ChartTag'),
          id: 'chartid'
        },
        {
          name: this.$t('system.ChartName'),
          id: 'name'
        },
        {
          name: this.$t('system.ChartType'),
          id: 'type',
          width: '80'
        },
        {
          name: this.$t('system.ChartDesc'),
          id: 'desc'
        }
      ],
      // 增删改模态框变量
      dialogVisible: false,
      dialogTitle: '',
      formItems: [],
      formChartData: {
        chart: [],
        code: '',
        desc: '',
        name: ''
      },
      rulesChartData: {
        'name': [
          { required: true, message: this.$t('statistics.pleaseEnterGroupNameNotice'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'desc': [
          { max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ]
      },
      formData: {
        notifyGroupCode: '',
        viewId: '',
        policy: '',
        notifyType: ''
      },
      rulesData: {
        'notifyGroupCode': [
          { required: true, message: this.$t('statistics.pleaseInformGroupSelection') }
        ],
        'viewId': [
          { required: true, message: this.$t('statistics.pleaseSelectAView') }
        ],
        'policy': [
          { required: true, message: this.$t('statistics.pleaseSelectAPeriodStrategy') }
        ],
        'notifyType': [
          { required: true, message: this.$t('statistics.pleaseInformWayChoice') }
        ]
      },
      dialogType: 1,
      dialogTypeChart: '',
      pageInfo: {
        currentPage: 1,
        pageSize: 10
      },
      detailTotal: 0,
      pageInfoDetail: {
        currentPage: 1,
        pageSize: 10
      },
      total: 0,
      tableData: [],
      tableHeader: [
        {
          name: this.$t('system.viewName'),
          id: 'name'
        },
        {
          name: this.$t('system.viewDesc'),
          id: 'desc'
        },
        {
          name: this.$t('statistics.cycleStrategy'),
          id: 'policy_zh'
        },
        {
          name: this.$t('statistics.informWay'),
          id: 'notifyType_zh'
        },
        {
          name: this.$t('statistics.informGroup'),
          id: 'notifyGroup'
        }
      ],
      loading: false,
      searchData: [
        {
          searchType: 'select',
          id: 'statisticsPeriodView',
          searchCondition: true,
          key: 'select',
          name: this.$t('statistics.viewName'),
          option: []
        }
      ],
      selectionRow: [],
      dialogTitleMap: {
        'add': this.$t('public.add'),
        'edit': this.$t('public.edit'),
        'detail': this.$t('system.ChartList'),
        'addView': this.$t('public.add')
      }
    }
  },
  computed: {

  },
  created() {
    this.statisticsPeriod = chartFilterConfig.call(this, 'statisticsPeriod')
    this.getViewOption()
    this.getNotifyGroupOption()
    this.getTableData()
  },
  methods: {
    paginationChartChange(page) {
      this.pageInfoDetail.currentPage = page.currentPageNum
      this.pageInfoDetail.pageSize = page.pageSizeNum
      this.getchartData()
    },
    paginationChange(page) {
      this.pageInfo.currentPage = page.currentPageNum
      this.pageInfo.pageSize = page.pageSizeNum
      this.getTableData()
    },
    handleSelect(val) {
      this.formChartData.chart = []
      val.forEach((item) => {
        this.formChartData.chart.push({
          chartId: item.chartid,
          chartName: item.name,
          desc: item.desc,
          type: item.type
        })
      })
    },
    async getNotifyGroupOption() {
      const res = await getNotifyGroup({ type: 'statistics' })
      this.dialogFormOption[3] = res.data.map(({ code, name }) => ({
        value: code, label: name
      }))
    },
    async getTableData(data) {
      const notifyTypeMap = {}
      const policyMap = {}
      this.dialogFormOption[1].forEach(item => {
        policyMap[item.value] = item.label
      })
      this.dialogFormOption[2].forEach(item => {
        notifyTypeMap[item.value] = item.label
      })
      const resTableData = await getViewTableData({
        name: this.statisticsPeriodView,
        pageSize: this.pageInfo.pageSize,
        pageNum: this.pageInfo.currentPage
      })
      this.tableData = resTableData.data.records
      this.tableData.forEach(item => {
        item.notifyType_zh = notifyTypeMap[item.notifyType]
        item.policy_zh = policyMap[item.policy]
      })
      this.total = resTableData.data.totalRecordCount
    },
    async getViewOption() {
      const res = await getViewDropDown()
      this.searchData[0].option = res.data.map(({ viewId, name }) => ({
        value: name, label: name
      }))
      this.dialogFormOption[0] = res.data.map(({ viewId, name }) => ({
        value: viewId, label: name
      }))
    },
    async handleDetail(row) {
      this.pageInfoDetail = {
        currentPage: 1,
        pageSize: 10
      }
      this.dialogTypeChart = 'detail'
      this.dialogChartTitle = this.dialogTitleMap[this.dialogTypeChart]
      this.dialogChartVisible = true
      this.dialogChartRow = row
      this.getchartData(row)
    },
    confirmChart() {
      const params = {
        ...this.formChartData,
        chart: this.formChartData.chart.map(item => item.chartId)
      }

      if (!params.chart.length) {
        this.$message(this.$t('statistics.pleaseSelectA') + 'chart')
        return
      }
      updateView(params).then((result) => {
        if (result.code === 200) {
          result.message && this.$message.success(result.message)
          this.getTableData()
          this.dialogChartVisible = false
        }
      }).catch((err) => {
        console.log(err)
        // this.$message.error(err)
      })
    },
    async getchartData(row) {
      this.chartData = []
      let res
      if (this.dialogTypeChart === 'edit') {
        res = await getViewAllChartList({
          pageSize: this.pageInfoDetail.pageSize,
          pageNum: this.pageInfoDetail.currentPage
        })
      } else {
        res = await getViewChartList({
          'chart': this.dialogChartRow.chart,
          pageSize: this.pageInfoDetail.pageSize,
          pageNum: this.pageInfoDetail.currentPage
        })
      }

      this.chartData = res.data.records
      this.chartData.forEach(item => {
        item.type = this.chartTypeMap[item.type]
      })
      this.detailTotal = res.data.totalRecordCount
      this.dialogChartRow.chart.split(',').forEach(chartId => {
        this.chartData.forEach((item) => {
          if (chartId === item.chartid) {
            this.selectionRow.push(item)
          }
        })
      })
    },
    handleDelete(row) {
      this.$confirm(this.$t('public.deleteTips'), this.$t('public.tips'), {
        confirmButtonText: this.$t('public.confirm'),
        cancelButtonText: this.$t('public.cancel'),
        type: 'warning'
      }).then(() => {
        deleteReportStrategy(row.id).then((result) => {
          result.message && this.$message.success(result.message)
          this.pageInfo.currentPage = 1
          this.getTableData()
        }).catch((err) => {
          this.$message.error(err)
        })
      }).catch(() => {
        this.$message({
          showClose: true,
          type: 'info',
          message: this.$t('public.deleteCancel')
        })
      })
    },
    handleEdit(row) {
      this.dialogChart = 'edit'
      this.dialogTitle = this.dialogTitleMap[this.dialogChart]
      this.dialogVisible = true
      this.dialogChartId = row.id
      this.formItems = formConfig.call(this, 'statisticsPeriod').map(({ options, ...formItem }, index) => {
        return {
          options: this.dialogFormOption[index],
          ...formItem
        }
      })
      this.formData = {
        notifyGroupCode: row.notifyGroupCode,
        viewId: row.viewId,
        policy: row.policy,
        notifyType: row.notifyType
      }
      this.dialogType = 2
      // this.$nextTick(() => {
      //   this.$refs['ActionDialog'].reset()
      // })
    },

    // handleEdit(row) {
    //   this.dialogTypeChart = 'edit'
    //   this.dialogChartTitle = this.dialogTitleMap[this.dialogTypeChart]
    //   this.getchartData(row)
    //   this.dialogChartVisible = true
    //   this.formChartData = {
    //     chart: row.chart.split(','),
    //     viewId: row.viewId,
    //     desc: row.desc,
    //     name: row.name
    //   }
    // },
    handleSearch(item) {
      this.statisticsPeriodView = item.statisticsPeriodView
      this.pageInfo.currentPage = 1
      this.getTableData()
    },
    handleClose(val) {
      this.dialogVisible = val
      this.formItems = []
      this.formChartData = {}
      // this.rulesData = {}
    },
    async handleSubmit(params) {
      try {
        await this.$refs['ActionDialog'].$refs['ruleForm'].validate()
        if (this.dialogType === 1) {
          const result = await addPeriodReport(params)
          result.message && this.$message.success(result.message)
          this.dialogVisible = false
          this.getTableData()
        } else if (this.dialogType === 2) {
          params.id = this.dialogChartId
          const result = await updatePeriodReport(params)
          result.message && this.$message.success(result.message)
          this.dialogVisible = false
          this.getTableData()
        }
      } catch (error) {
        console.log(error)
        // this.$message.error(error)
        return false
      }
    },
    handlerEvent({ id }) {
      if (id === 'addView') {
        this.dialogTitle = this.dialogTitleMap['addView']
        this.formItems = formConfig.call(this, 'statisticsPeriod').map(({ options, ...formItem }, index) => {
          return {
            options: this.dialogFormOption[index],
            ...formItem
          }
        })
        this.dialogType = 1
        this.dialogVisible = true
        this.$nextTick(() => {
          this.$refs['ActionDialog'].reset()
        })
      }
    }
  }
}

</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
.period-container{
   margin-left:10px;
    .period-container-inner{
      height: 100%;
    }
    // padding-left:10px;
    flex: 1;
    align-self: flex-start;
  .table-class {
    background: $darkBlue4;
    padding: 10px;
    height: calc(100vh - 193px);
    width: 100%;
  }
  .Table .el-table--border::after,
  .Table .el-table--group::after,
  .Table .el-table::before {
    background: none;
  }
  .dialog-table{
    height: 250px;
    overflow-y: auto;
  }
}
  .TitleSearch{
    height: 60px;
    margin-bottom: 10px;
    background: $darkBlue4;
  }
</style>
