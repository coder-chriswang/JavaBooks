<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-18 11:45:33
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-26 16:30:58
 * @Description: file content
-->
<template>
  <div class="view-config-container">
    <div class="btn-group">
      <el-button type="primary" size="mini" @click="getTableData">{{ $t('public.refresh') }}</el-button>
      <el-button type="primary" size="mini" @click="handleAdd">{{ $t('public.add') }}</el-button>
    </div>
    <TitleSearch :search-data="searchData" class="TitleSearch" @search="handleSearch" />
    <Table
      v-loading="loading"
      :table-data="tableData"
      :element-loading-text="$t('public.loading')"
      :table-header="tableHeader"
      :highlight-current-row="false"
      :current-page="currentPage"
      :total="total"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      class="table-class"
      @pagination-change="paginationChange"
    >
      <template slot-scope="scope">
        <!-- 组件嵌套导致scope包了两层 -->
        <el-button type="text" class="table-text-btn" @click="handleDetail(scope.scope.row)">{{ $t('public.detail') }}</el-button>
        <el-button type="text" class="table-text-btn" :disabled="scope.scope.row.status===1" @click="handleEdit(scope.scope.row)">{{ $t('public.edit') }}</el-button>
        <el-button type="text" class="table-text-btn" :disabled="scope.scope.row.status===1" @click="handleDelete(scope.scope.row)">{{ $t('public.delete') }}</el-button>
      </template>
    </Table>
    <el-dialog
      :title="dialogTitle"
      :visible.sync="dialogVisible"
      :modal-append-to-body="false"
      width="50%"
    >
      <el-form ref="ruleForm" :model="formData" label-width="95px" :rules="rulesData">
        <el-form-item v-if="dialogType !== 'detail'" :label="$t('system.viewName')" prop="name">
          <el-input v-model="formData.name" />
        </el-form-item>
        <el-form-item v-if="dialogType !== 'detail'" :label="$t('system.viewDesc')" prop="desc">
          <el-input v-model="formData.desc" />
        </el-form-item>
      </el-form>
      <div class="dialog-table">
        <Table
          ref="chartTable"
          :table-data="chartData"
          :table-header="chartTableHeader"
          :highlight-current-row="false"
          table-size="mini"
          :pagination="false"
          :show-selection="dialogType !== 'detail'"
          :last-table-column="false"
          :selection-row="selectionRow"
          @selection-change="handleSelect"
        />
      </div>
      <span v-if="dialogType !== 'detail'" slot="footer" class="dialog-footer">
        <el-button class="zt-button" @click="dialogVisible = false">{{ $t('public.cancel') }}</el-button>
        <el-button type="primary" @click="formSubmit">{{ $t('public.confirm') }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import Table from '@/components/Table/Table'
import TitleSearch from '@/components/TitleSearch/TitleSearch'
import { checkSpecificKey } from '@/utils/validate'
import {
  getViewsTableData,
  getChartTableData,
  addView,
  deleteView,
  updateView,
  queryDetail
} from '@/api/resource'
export default {
  name: 'DashBoardConfig',
  components: {
    Table,
    TitleSearch
  },
  data() {
    const validateInput = (rule, value, callback) => {
      if (!checkSpecificKey(value)) {
        callback(new Error(this.$t('statistics.cantContainSpecialCharacters')))
      } else {
        callback()
      }
    }
    return {
      chartTypeMap: {
        Line: this.$t('public.line'),
        Gauge: this.$t('public.gauge'),
        Bar: this.$t('public.bar'),
        Table: this.$t('public.table'),
        Pie: this.$t('public.pie'),
        ringScreen: this.$t('public.ringScreen'),
        LiquidFill: this.$t('public.LiquidFill')
      },
      queryParam: {
        pageNum: 1,
        pageSize: 10
      },
      currentPage: 1,
      total: 0,
      tableData: [],
      tableHeader: [
        // {
        //   name: this.$t('system.viewId'),
        //   id: 'code'
        // },
        {
          name: this.$t('system.viewName'),
          id: 'name'
        },
        {
          name: this.$t('system.viewDesc'),
          id: 'desc'
        },
        {
          name: this.$t('system.reportName'),
          id: 'chartName'
        },
        { name: this.$t('alarm.lt'),
          id: 'dateTime'
        }
      ],
      chartData: [],
      chartTableHeader: [
        {
          name: this.$t('system.ChartTag'),
          id: 'chartid'
        },
        {
          name: this.$t('system.ChartName'),
          id: 'name'
        },
        {
          name: this.$t('system.ChartType'),
          id: 'typeLabel',
          width: '80'
        },
        {
          name: this.$t('system.ChartDesc'),
          id: 'desc'
        }
      ],
      chartTableTotal: 0,
      chartDataParams: {
        pageNum: 0,
        pageSize: 10
      },
      dialogVisible: false,
      dialogType: 'add',
      dialogTitle: '',
      selectionRow: [],
      selectNumber: 0,
      formData: {
        chart: [],
        desc: '',
        name: ''
      },
      rulesData: {
        'name': [
          { required: true, message: this.$t('public.pleaseInput') + this.$t('statistics.viewName'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' },
          { validator: validateInput, trigger: 'blur' }
        ],
        'desc': [
          { max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ]
      },
      searchData: [
        {
          type: 'text',
          id: 'statisticsPeriodView',
          searchCondition: true,
          name: this.$t('statistics.viewName')
        }
      ],
      loading: false
    }
  },
  created() {
    this.getTableData()
  },
  methods: {
    handleSearch(item) {
      this.queryParam.name = item.statisticsPeriodView
      this.queryParam.pageNum = 1
      this.getTableData()
    },
    paginationChange(page) {
      this.queryParam.pageNum = page.currentPageNum
      this.queryParam.pageSize = page.pageSizeNum
      this.getTableData()
    },
    getTableData() {
      this.loading = true
      if (!this.queryParam.name) {
        delete this.queryParam.name
      }
      getViewsTableData(this.queryParam).then((result) => {
        if (result.data.records && result.data.records.length > 0) {
          this.tableData = result.data.records
          this.currentPage = result.data.currentPage
          this.total = result.data.totalRecordCount
        } else {
          this.tableData = []
          this.currentPage = result.data.currentPage
          this.total = result.data.totalRecordCount
        }
        this.loading = false
      }).catch((err) => {
        console.log(err)
        this.loading = false
      })
    },
    getchartData(selectRow = '') {
      getChartTableData(this.chartDataParams).then((result) => {
        if (result.data.records && result.data.records.length > 0) {
          this.chartData = []
          result.data.records.forEach((item) => {
            this.chartData.push({
              chartid: item.chartid,
              name: item.name,
              typeLabel: this.chartTypeMap[item.type],
              type: item.type,
              desc: item.desc
            })
          })
          selectRow.split(',').forEach(item => {
            this.chartData.forEach((item2) => {
              if (item === item2.chartid) {
                this.selectionRow.push(item2)
              }
            })
          })
        }
      }).catch((err) => {
        console.log(err)
      })
    },
    setDialogTitle(dialogType) {
      switch (dialogType) {
        case 'add':
          this.dialogTitle = this.$t('public.add')
          break
        case 'edit':
          this.dialogTitle = this.$t('public.edit')
          break
        case 'detail':
          this.dialogTitle = this.$t('system.ChartList')
          break
      }
    },
    handleAdd() {
      this.resetForm()
      this.dialogType = 'add'
      this.setDialogTitle(this.dialogType)
      this.getchartData()
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.resetForm()
      this.dialogType = 'edit'
      this.setDialogTitle(this.dialogType)
      this.getchartData(row.chart)
      this.dialogVisible = true
      this.formData = {
        chart: row.chart,
        desc: row.desc,
        name: row.name,
        viewId: row.viewid
      }
    },
    async formSubmit() {
      try {
        await this.$refs['ruleForm'].validate()
      } catch (error) {
        return false
      }
      if (this.selectNumber === 0) {
        this.$message({
          message: '请至少选择表格中的一项',
          type: 'warning'
        })
        return
      }
      this.formData.chart = this.formData.chart.map(i => i.chartId)
      if (this.dialogType === 'add') {
        delete this.formData.viewId
        addView(this.formData).then((result) => {
          if (result.code === 200) {
            result.message && this.$message.success(result.message)
            this.getTableData()
            this.dialogVisible = false
            this.$emit('refreshMenu')
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      } else {
        updateView(this.formData).then((result) => {
          if (result.code === 200) {
            result.message && this.$message.success(result.message)
            this.getTableData()
            this.dialogVisible = false
            this.$emit('refreshMenu')
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      }
    },
    handleDetail(row) {
      this.dialogType = 'detail'
      this.setDialogTitle(this.dialogType)
      this.chartData = []
      queryDetail(row.chart).then(res => {
        res.data.forEach(item => {
          this.chartData.push({
            chartid: item.chartid,
            name: item.name,
            typeLabel: this.chartTypeMap[item.type],
            type: item.type,
            desc: item.desc
          })
        })
      })
      // row.chart.forEach(item => {
      //   this.chartData.push({
      //     chartid: item.chartId,
      //     name: item.chartName,
      //     typeLabel: this.chartTypeMap[item.type],
      //     type: item.type,
      //     desc: item.desc
      //   })
      // })
      this.dialogVisible = true
    },
    handleDelete(row) {
      this.$confirm(this.$t('public.deleteTips'), this.$t('public.tips'), {
        confirmButtonText: this.$t('public.confirm'),
        cancelButtonText: this.$t('public.cancel'),
        type: 'warning'
      }).then(() => {
        deleteView(row.viewid).then((result) => {
          result.message && this.$message.success(result.message)
          this.getTableData()
          this.$emit('refreshMenu')
        }).catch((err) => {
          this.$message.error(err)
        })
      }).catch(() => {
        this.$message({
          showClose: true,
          type: 'info',
          message: this.$t('public.deleteCancel')
        })
      })
    },
    handleSelect(val) {
      this.selectNumber = val.length
      this.formData.chart = []
      // console.log(val.length)
      val.forEach((item) => {
        this.formData.chart.push({
          chartId: item.chartid,
          chartName: item.name,
          desc: item.desc,
          type: item.type
        })
      })
    },
    resetForm() {
      this.$nextTick(() =>
        this.$refs['ruleForm'] && this.$refs['ruleForm'].clearValidate()
      )
      this.formData = {
        chart: [],
        desc: '',
        name: ''
      }
      this.selectionRow = []
      this.selectNumber = 0
    }
  }
}
</script>

<style lang="scss">
@import '@/styles/variables.scss';
.view-config-container{
  width: 100%;
  height: 100%;
  margin:0 0 0 10px;
  .btn-group{
    position: relative;
    top: 7px;
    left: 92.6%;
    width:200px;
    height: 45px;
  }
  .table-class {
    background: $darkBlue4;
    padding: 10px;
    height: calc(100vh - 198px);
  }
  // .Table .el-table--border::after,
  // .Table .el-table--group::after,
  // .Table .el-table::before {
  //   background: none;
  // }
  .dialog-table{
    height: 250px;
    overflow-y: auto;
  }
  .TitleSearch{
    height: 60px;
    margin-bottom: 10px;
    background: $darkBlue4;
  }
}
</style>
