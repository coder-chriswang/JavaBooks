<template>
  <div class="statistics-container">
    <SiderBar v-if="!setTimeShowSidBar" :menu-list="menuList" @menu-active="menuActive" />
    <Breadcrumb class="breadcrumb-location" :context="navName" />
    <resourceReport v-if="isTypePage" :current-page="menuSelectedId" :chart-options="chartOptions" />
    <!-- <mailServer v-if="menuSelectedId === '2-1'" /> -->
    <statisticsPeriod v-if="menuSelectedId === '2-2'" />
    <noticeGroup v-if="menuSelectedId === '2-3'" />
    <viewConfig v-if="menuSelectedId === '2-4'" @refreshMenu="getFirstPageRouter" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import Breadcrumb from '@/components/Breadcrumb/Breadcrumb'
import resourceReport from './resourceReport/index'
import statisticsPeriod from './statisticsPeriod/index'
import noticeGroup from './noticeGroup/index'
import viewConfig from './viewConfig/index'
import { getTypeMenu, getChartByViewId, cancelQueue } from '@/api/statistics'

export default {
  name: 'Statistics',
  components: {
    SiderBar,
    Breadcrumb,
    resourceReport,
    statisticsPeriod,
    noticeGroup,
    viewConfig
  },

  data() {
    return {
      chartOptions: [],
      navName: '',
      menuSelectedId: '',
      // 页面加载时首先不加载此组件  当 配置接口请求成功后 才加载此组件  并且调用table接口
      setTimeShowSidBar: true,
      menuList: [
        {
          label: this.$t('sidebar.type'),
          icon: 'icon-peizhi',
          isActive: false,
          id: '1',
          children: []
        },
        {
          label: this.$t('sidebar.config'),
          icon: 'icon-yunwei',
          isActive: false,
          id: '2',
          children: [
            // {
            //   label: this.$t('sidebar.mailServer'),
            //   // icon: 'icon-peizhi',
            //   isActive: true,
            //   id: '2-1'
            // },
            {
              label: this.$t('sidebar.statistics'),
              // icon: 'icon-peizhi',
              isActive: true,
              id: '2-2'
            },
            {
              label: this.$t('sidebar.noticeGroup'),
              // icon: 'icon-peizhi',
              isActive: true,
              id: '2-3'
            },
            {
              label: this.$t('sidebar.viewConfig'),
              // icon: 'icon-peizhi',
              isActive: true,
              id: '2-4'
            }
          ]
        }
      ]
    }
  },
  computed: {
    isTypePage() {
      return this.menuList[0].children.map(i => i.id).includes(this.menuSelectedId)
    },
    ...mapGetters([
      'sidebar',
      'name'
    ])
  },
  created() {
    this.getFirstPageRouter()
  },
  methods: {
    async getFirstPageRouter() {
      const res = await Promise.all([getTypeMenu()])
      if (res[0] && res[0].code === 200) {
        this.getTypeMenu(res[0].data)
      }
      // 渲染sidBar 查询数据
      this.setTimeShowSidBar = false
    },
    getTypeMenu(result) {
      if (result.length > 0) {
        const children = []
        for (const item of result) {
          // if (item && item.display) {
          children.push({
            label: item.name,
            // icon: 'icon-peizhi',
            isActive: true,
            id: item.viewid
          })
          // }
        }
        this.menuList[0].children = children
      }
    },
    // 面包屑递归查找
    getNameByIdInObjArr(arr, id) {
      arr.forEach(v => {
        if (id === v.id) {
          this.navName = v.label
        }
        if (v.children && v.children.length > 0) {
          this.getNameByIdInObjArr(v.children, id)
        }
      })
    },
    async menuActive({ item, menuId }) {
      // set面包屑
      this.getNameByIdInObjArr(this.menuList, menuId)
      this.menuSelectedId = menuId
      try {
        const res = await getChartByViewId(this.menuSelectedId)
        this.chartOptions = res.data
      } catch (error) {
        cancelQueue.length = 0
        console.log(error)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.statistics-container {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    position: relative;
    margin: 10px;
    .sidebar{
      align-self: self-start;
    }
    .breadcrumb-location {
      position: absolute;
      left: 25px;
      top: 0;
      height: 40px;
      padding-left: 0;
    }
}
</style>
