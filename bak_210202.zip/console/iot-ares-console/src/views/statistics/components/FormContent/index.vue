<template>
  <div class="TitleTopGroup">
    <el-row class="">
      <el-form ref="ruleForm" label-position="right" :model="searchModel" :rules="rulesData" label-width="200px" style="width: 600px;">
        <el-col v-for="(item,index) in formDataConfig" :key="`item${index}`">
          <el-form-item :prop="item.id" :label="item.label">
            <el-select v-if="item.searchType === 'select'" v-model="searchModel[item.id]" :placeholder="$t('statistics.pleaseSelectA')" :disabled="!edit">
              <el-option v-for="(op,i) in item.options" :key="`op${i}`" :label="op.label" :value="op.value" />
            </el-select>
            <!-- 单选类型 -->
            <el-radio-group v-if="item.searchType === 'radio'" v-model="searchModel[item.id]">
              <el-radio v-for="(op,i) in item.options" :key="`op${i}`" :label="op.label" :value="op.value" />
            </el-radio-group>
            <el-input v-else-if="item.searchType === 'input'" v-model="searchModel[item.id]" :disabled="!edit" />
            <!-- 日期选择类型 -->
            <el-date-picker v-else-if="item.searchType === 'date'" v-model="searchModel.TIME" type="date" :placeholder="$t('public.startDate')" />
            <el-button v-else-if="item.searchType === 'button'" type="primary" size="" @click="handlerItemEvent(item.id)">{{
              item.name }}</el-button>
            <!-- 扩展列展示 -->
          </el-form-item>
        </el-col>
        <el-col class="opt-btn">
          <el-button v-if="!edit" type="primary" size="" @click="edit=true">{{ $t('public.edit') }}</el-button>
          <el-button v-if="edit" type="primary" size="" @click="handlerSave">{{ $t('public.save') }}</el-button>
          <el-button size="" class="cancel" @click="handlerCancel">{{ $t('public.cancel') }}</el-button>
        </el-col>
      </el-form>
    </el-row>
  </div>
</template>
<script>
import {
  mapGetters
} from 'vuex'
export default {
  components: {

  },
  props: {
    // 搜索框渲染对象
    formDataConfig: {
      type: Array,
      default: () => []
    },
    formInitModel: {
      type: Object,
      default: () => {}
    },
    rulesData: {
      type: Object,
      default: () => {
        return {
        }
      }
    }
  },
  data() {
    return {
      edit: false,
      // 搜索框各字段父及对象
      searchModel: {
      }
    }
  },
  computed: {

    ...mapGetters([
      'sidebar'
    ])
  },
  watch: {
    'formInitModel': {
      handler(n, o) {
        this.searchModel = n
      }
    }
  },
  mounted() {

  },
  methods: {
    changeFormState(state) {
      this.edit = state
    },
    async handlerSave() {
      try {
        await this.$refs['ruleForm'].validate()
        this.$emit('save', this.searchModel)
      } catch (error) {
        console.log(error)
        // this.$message.error(error)
        return false
      }
    },
    handlerCancel() {
      this.edit && this.$refs['ruleForm'].resetFields()
    },
    handlerItemEvent(id) {
      this.$emit('handlerEvent', {
        item: this,
        id
      })
    }
  }
}

</script>
<style lang="scss" scoped>
  $borBg: #409EFF;
  $col: #fff;
  .opt-btn{
    margin-left: 200px;
     .cancel {
      background: none;
      color: $col;
      border: 1px solid $borBg;
    }
  }
  .el-form{
      ::v-deep .el-input__inner{
        width: 400px;
      }
      .el-form-item{
        margin-bottom: 40px;
      }
    }
</style>
