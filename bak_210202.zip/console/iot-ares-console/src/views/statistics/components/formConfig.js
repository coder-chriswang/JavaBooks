export default function(moduleName) {
  const modules = {
    statisticsPeriod: [{
      label: this.$t('statistics.viewName'),
      inputType: 'select',
      key: 'viewId',
      options: []
    }, {
      label: this.$t('statistics.cycleStrategy'),
      inputType: 'select',
      options: [],
      key: 'policy'
    },
    {
      label: this.$t('statistics.informWay'),
      inputType: 'select',
      options: [],
      key: 'notifyType'
    },
    {
      label: this.$t('statistics.informGroup'),
      inputType: 'select',
      options: [],
      key: 'notifyGroupCode',
      otherKeys: ['notifyGroup']
    }
    ],
    mailServer: [{
      searchType: 'select',
      id: 'protocol',
      label: this.$t('system.ConnectionProtocol'),
      options: [{
        value: 'smtp',
        label: 'smtp'
      }, {
        value: 'pop3',
        label: 'pop3'
      }, {
        value: 'imap4',
        label: 'imap4'
      }]
    }, {
      searchType: 'input',
      id: 'server',
      label: this.$t('system.mailServeAddress')
    }, {
      searchType: 'input',
      id: 'port',
      label: this.$t('system.port')
    }, {
      searchType: 'input',
      id: 'sendEmail',
      label: this.$t('system.sendUserEmail')
    }, {
      searchType: 'input',
      id: 'sendAccount',
      label: this.$t('system.sendUserAccount')
    },
    {
      searchType: 'input',
      id: 'sendPwd',
      label: this.$t('system.senduserPassword')
    }
    ]
  }
  return modules[moduleName]
}
