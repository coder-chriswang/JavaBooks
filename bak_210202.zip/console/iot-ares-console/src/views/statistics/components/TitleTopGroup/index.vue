<template>
  <div class="TitleTopGroup">
    <el-row class="">
      <el-form ref="form" :model="searchModel" label-width="10px" size="mini" class="form-layout">
        <el-col v-for="(item,index) in chartFilterData" :key="`item${index}`" :span="sidebar.opened ? 3.5:3">
          <el-form-item :prop="item.id">
            <!-- 单选类型 -->
            <el-radio-group v-if="item.searchType === 'radio'" v-model="searchModel[item.id]">
              <el-radio v-for="(op,i) in item.option" :key="`op${i}`" :label="op.value">{{ op.label }}</el-radio>
            </el-radio-group>
            <!-- 日期选择类型 -->
            <el-date-picker v-else-if="item.searchType === 'date'" v-model="searchModel[item.id]" type="date" :placeholder="$t('public.startDate')" @change="handlerItemEvent($event,item.id)" />
            <el-button v-else-if="item.searchType === 'button'" type="primary" size="mini" @click="handlerItemEvent($event,item.id)">{{
              item.name }}</el-button>
            <!-- 扩展列展示 -->
          </el-form-item>
        </el-col>
      </el-form>
    </el-row>
  </div>
</template>
<script>
import {
  mapGetters
} from 'vuex'
export default {
  components: {

  },
  props: {
    // 搜索框渲染对象
    chartFilterData: {
      type: Array,
      default: () => []
    },
    defaultModel: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      searchModel: {
      }
    }
  },
  computed: {
    ...mapGetters([
      'sidebar'
    ])
  },
  watch: {
    defaultModel: {
      handler(n, o) {
        this.searchModel = Object.assign({}, this.searchModel, n)
      },
      immediate: true
    }
  },
  created() {
  },
  mounted() {

  },
  methods: {
    handlerItemEvent(params, id) {
      this.$emit('handlerEvent', {
        item: this,
        id,
        params
      })
    }
  }
}

</script>
<style lang="scss" scoped>
  .TitleTopGroup {
    position: relative;
    // right: 0px;
    top: 5px;
    right:5px;
    height: 40px;
    // width: 50vw;

    .el-button+.el-button {
      height: 28px;
    }
  }

  .form-layout {
    display: flex;
    justify-content: flex-end;

    .el-col {
      display: inline-flex;
      align-items: center;
    }
  }

</style>
