export default function(moduleName) {
  const modules = {
    resourceReport: [
    //   {
    //   searchType: 'date',
    //   id: 'date'
    // },
      {
        searchType: 'radio',
        id: 'exportType',
        option: [{
          label: 'PDF',
          value: 0
        }, {
          label: this.$t('statistics.Picture'),
          value: 1
        }]
      }, {
        searchType: 'button',
        id: 'preview',
        // name: this.$t('public.search'),
        name: this.$t('statistics.preview')
      }, {
        searchType: 'button',
        id: 'export',
        // name: this.$t('public.search'),
        name: this.$t('statistics.export')
      }],
    statisticsPeriod: [{
      searchType: 'button',
      id: 'addView',
      // name: this.$t('public.search'),
      name: this.$t('statistics.add')
    }],
    noticeGroup: [{
      searchType: 'button',
      id: 'addNoticeGroup',
      // name: this.$t('public.search'),
      name: this.$t('statistics.add')
    }]
  }
  return modules[moduleName]
}
