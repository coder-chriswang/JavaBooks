<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-23 15:48:47
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-24 09:18:03
 * @Description: file content
-->
<template>
  <div class="form-class mailserver-container">
    <FormContent ref="formContent" :form-data-config="formDataConfig" :form-init-model="formInitModel" :rules-data="rulesData" @save="saveConfig" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import FormContent from '../components/FormContent'
import formConfig from '../components/formConfig'
import { saveEmailserver, getEmailserverConfig } from '@/api/statistics'
import { validatePort, isEmail, validatePass } from '@/utils/validate'
export default {
  name: 'MailService',
  components: {
    FormContent
  },
  data() {
    return {
      rulesData: {},
      formInitModel: {}
    }
  },
  computed: {
    ...mapGetters([
      'language'
    ])
  },
  async created() {
    this.formDataConfig = formConfig.call(this, 'mailServer')
    this.rulesData = {
      'protocol': [
        { required: true, message: this.$t('statistics.pleaseSelectAConnectionProtocol'), trigger: 'blur' }
      ],
      'server': [
        { required: true, message: this.$t('statistics.pleaseEnterEmailServer'), trigger: 'blur' },
        { max: 64, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 64 }), trigger: 'blur' }
      ],
      'port': [
        { required: true, message: this.$t('statistics.pleaseEnterPortNumber'), trigger: 'blur' },
        { validator: validatePort, langStatus: this.language, trigger: 'blur' }
      ],
      'sendEmail': [
        { required: true, message: this.$t('statistics.pleaseEnterSenderEmailAddress'), trigger: 'blur' },
        { max: 64, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 64 }), trigger: 'blur' },
        { validator: isEmail, langStatus: this.language, trigger: 'blur' }

      ],
      'sendAccount': [
        { required: true, message: this.$t('statistics.pleaseEnterSendersAccount'), trigger: 'blur' },
        { max: 64, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 64 }), trigger: 'blur' },
        { validator: isEmail, langStatus: this.language, trigger: 'blur' }
      ],
      'sendPwd': [
        { required: true, message: this.$t('statistics.enterPasswordForSender'), trigger: 'blur' },
        { max: 32, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 32 }), trigger: 'blur' },
        { validator: validatePass, langStatus: this.language, trigger: 'blur' }
      ]
    }
    const res = await getEmailserverConfig()
    if (res.data) {
      this.formInitModel = (({ port,
        protocol,
        sendAccount,
        sendEmail,
        sendPwd,
        server }) => ({ port,
        protocol,
        sendAccount,
        sendEmail,
        sendPwd,
        server }))(res.data)
    }
  },
  methods: {
    async saveConfig(params) {
      Object.assign(params, { type: 'statistics' })
      try {
        const result = await saveEmailserver(params)
        result.message && this.$message.success(result.message)
        this.$refs['formContent'].changeFormState(false)
      } catch (error) {
        this.$refs['formContent'].changeFormState(true)
        console.log(error)
        // this.$message.error(error)
        return false
      }
    }
  }
}

</script>

<style lang="scss" scoped>
 .mailserver-container{
    flex: 1;
    align-self: flex-start;
  }
  .form-class {
    display: flex;
    background: #111547;
    height: calc(100vh - 83px);
    padding-top: 50px;
    margin-left: 10px;
    .el-form{
      ::v-deep .el-input__inner{
        width: 400px;
      }
      .el-form-item{
        margin-bottom: 40px;
      }
    }

  }

</style>
