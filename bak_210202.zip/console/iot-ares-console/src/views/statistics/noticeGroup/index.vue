<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-18 14:55:57
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-25 18:45:50
 * @Description: file content
-->
<template>
  <div class="noticeGroup-container">
    <div class="noticeGroup-container-inner">
      <TitleTopGroup :chart-filter-data="noticeGroup" @handlerEvent="handlerEvent" />
      <Table
        :table-data="tableData"
        :table-header="tableHeader"
        :total="total"
        :highlight-current-row="false"
        :current-page="pageInfo.currentPage"
        :page-size="pageInfo.pageSize"
        class="table-class"
        @pagination-change="paginationChange"
      >
        <template slot-scope="scope">
          <!-- 组件嵌套导致scope包了两层 -->
          <el-button type="text" class="table-text-btn" @click="handleEdit(scope.scope.row)">{{ $t('public.edit') }}</el-button>
          <el-button type="text" class="table-text-btn" @click="handleDelete(scope.scope.row)">{{ $t('public.delete') }}</el-button>

        </template>
        <template slot="user" slot-scope="scope">
          <el-button type="text" class="table-text-btn" @click="viewUser(scope.scope.row)">{{ $t('statistics.toView') }}</el-button>
        </template>
      </Table>
      <el-dialog
        :title="dialogTitle"
        :visible.sync="dialogVisible"
        :modal-append-to-body="false"
        width="50%"
      >
        <el-form v-if="dialogType !== 'detail'" ref="ruleForm" label-width="105px" :model="formData" :rules="rulesData">
          <el-form-item :label="$t('system.noticeGroupName')" prop="name">
            <el-input v-model="formData.name" :disabled="dialogType === 'detail'" />
          </el-form-item>
          <el-form-item :label="$t('system.noticeGroupDesc')" prop="desc">
            <el-input v-model="formData.desc" :disabled="dialogType === 'detail'" />
          </el-form-item>
        </el-form>
        <div class="filter-table-input">
          <el-input
            v-model="filterTableInput"
            class="search-input"
            :placeholder="$t('statistics.pleaseEnterYourUserName')"
            prefix-icon="el-icon-search"
            size="small"
            @input="$refs['Table'] && $refs['Table'].toggleSelection(multipleSelection)"
          />
        </div>
        <div class="dialog-table">
          <Table
            ref="Table"
            :table-data="_dialogTableData"
            :table-header="dialogTableHeader"
            :highlight-current-row="false"
            table-size="mini"
            :pagination="false"
            :show-selection="dialogType !== 'detail'"
            :last-table-column="false"
            :selection-row="selectionRow"
            @selection-change="handleSelect"
          />
        </div>
        <span v-if="dialogType !== 'detail'" slot="footer" class="dialog-footer">
          <el-button class="zt-button" @click="dialogVisible = false">{{ $t('public.cancel') }}</el-button>
          <el-button type="primary" @click="confirm">{{ $t('public.confirm') }}</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import Table from '@/components/Table/Table'
import chartFilterConfig from '../components/chartFilterConfig'
import TitleTopGroup from '../components/TitleTopGroup'
import { getNoticeGroupTableData, getGroupOrNotNotifyUser, addNotifyGroup, modifyNotifyGroup, deleteNotifyGroup } from '@/api/statistics'
import { checkSpecificKey } from '@/utils/validate'

export default {
  name: 'Operation',
  components: {
    Table,
    TitleTopGroup
  },
  data() {
    const validateInput = (rule, value, callback) => {
      if (!checkSpecificKey(value)) {
        callback(new Error(this.$t('statistics.cantContainSpecialCharacters')))
      } else {
        callback()
      }
    }
    return {
      dialogTitle: '',
      dialogVisible: false,
      dialogType: '',
      formData: {
        notifyUsers: [],
        desc: '',
        name: ''
      },
      rulesData: {
        'name': [
          { required: true, message: this.$t('statistics.pleaseEnterGroupNameNotice'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' },
          { validator: validateInput, trigger: 'blur' }
        ],
        'desc': [
          { max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ]
      },
      filterTableInput: '',
      dialogTableData: [],
      dialogTableHeader: [{
        name: this.$t('statistics.userName'),
        id: 'name'
      },
      {
        name: this.$t('statistics.usersMobilePhoneNumber'),
        id: 'phone'
      },
      {
        name: this.$t('statistics.userMailbox'),
        id: 'email'
      }],
      detailTotal: 0,
      pageInfoDetail: {
        currentPage: 1,
        pageSize: 10
      },
      selectionRow: [],
      multipleSelection: [],
      // page table
      pageInfo: {
        currentPage: 1,
        pageSize: 10
      },
      total: 0,
      tableData: [],
      tableHeader: [
        {
          name: this.$t('system.noticeGroupName'),
          id: 'name'
        },
        {
          name: this.$t('system.noticeGroupDesc'),
          id: 'desc'
        },
        {
          name: this.$t('sidebar.user'),
          id: 'user',
          customize: true
        }
      ],
      dialogTitleMap: {
        'addNoticeGroup': this.$t('public.add'),
        'edit': this.$t('public.edit'),
        'detail': this.$t('statistics.userDetails')
      }
    }
  },
  computed: {
    _dialogTableData() {
      const data = this.dialogTableData.filter(p => p.name.indexOf(this.filterTableInput) !== -1)
      return data
    }
  },
  created() {
    this.noticeGroup = chartFilterConfig.call(this, 'noticeGroup')
    this.getTableData()
  },
  methods: {
    paginationChange(page) {
      this.pageInfo.currentPage = page.currentPageNum
      this.pageInfo.pageSize = page.pageSizeNum
      this.getTableData()
    },
    handleDelete(row) {
      this.$confirm(this.$t('public.deleteTips'), this.$t('public.tips'), {
        confirmButtonText: this.$t('public.confirm'),
        cancelButtonText: this.$t('public.cancel'),
        type: 'warning'
      }).then(() => {
        deleteNotifyGroup(row).then((result) => {
          result.message && this.$message.success(result.message)
          this.getTableData()
        }).catch((err) => {
          this.$message.error(err)
        })
      }).catch(() => {
        this.$message({
          showClose: true,
          type: 'info',
          message: this.$t('public.deleteCancel')
        })
      })
    },
    async getTableData(data) {
      const resTableData = await getNoticeGroupTableData({
        type: 'statistics',
        pageSize: this.pageInfo.pageSize,
        pageNum: this.pageInfo.currentPage
      })
      this.tableData = resTableData.data.records
      this.total = resTableData.data.totalRecordCount
    },
    viewUser(row) {
      this.formData = {
        desc: row.desc,
        name: row.name
      }
      this.dialogType = 'detail'
      this.dialogVisible = true
      this.dialogTitle = this.dialogTitleMap['detail']
      this.dialogTableData = row.list
    },
    async handleEdit(row) {
      this.resetForm()
      this.formData = {
        desc: row.desc,
        code: row.code,
        name: row.name
      }
      this.dialogType = 'edit'
      this.dialogVisible = true
      this.$nextTick(() =>
        this.$refs['ruleForm'].clearValidate()
      )
      this.dialogTitle = this.dialogTitleMap['edit']
      const res = await getGroupOrNotNotifyUser(row)
      this.dialogTableData = [].concat(res.data.groupList, res.data.noGroupList).filter(_ => _)

      row.list.forEach(item => {
        this.dialogTableData.forEach((item2) => {
          if (item.name === item2.name) {
            this.selectionRow.push(item2)
          }
        })
      })
    },
    async handlerEvent({ id }) {
      if (id === 'addNoticeGroup') {
        this.resetForm()
        this.dialogType = 'add'
        this.dialogVisible = true
        this.$nextTick(() =>
          this.$refs['ruleForm'].clearValidate()
        )
        this.dialogTitle = this.dialogTitleMap['addNoticeGroup']
        const res = await getGroupOrNotNotifyUser()
        this.dialogTableData = [].concat(res.data.groupList, res.data.noGroupList).filter(_ => _)
      }
    },
    async confirm() {
      if (!this.formData.notifyUsers.length) {
        this.$message(this.$t('statistics.pleaseSelectAUser'))
        return
      }
      this.formData.type = 'statistics'
      let result
      if (this.dialogType === 'add') {
        result = await addNotifyGroup(this.formData)
      } else if (this.dialogType === 'edit') {
        result = await modifyNotifyGroup(this.formData)
      }
      if (result.code === 200) {
        result.message && this.$message.success(result.message)
        this.getTableData()
        this.dialogVisible = false
      }
    },
    handleSelect(val) {
      this.multipleSelection = val
      this.formData.notifyUsers = []
      val.forEach(({ email, name, phone }) => {
        this.formData.notifyUsers.push({ email, name, phone
        })
      })
    },
    resetForm() {
      this.formData = {
        notifyUsers: [],
        code: '',
        desc: '',
        name: ''
      }
      this.filterTableInput = ''
      this.selectionRow = []
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .noticeGroup-container{
      flex: 1;
      margin-left:10px;
      .noticeGroup-container-inner{
        height: 100%;
      }
  }
    .filter-table-input{
    display:flex;
    justify-content: flex-end;
    .search-input{
      width:200px;
      margin-bottom: 15px;
    }
  }
  .table-class {
    background: $darkBlue4;
    padding: 10px;
    height: calc(100vh - 126px);
  }
  .Table .el-table--border::after,
  .Table .el-table--group::after,
  .Table .el-table::before {
    background: none;
  }
  .dialog-table{
    height: 250px;
    overflow-y: auto;
  }
</style>
