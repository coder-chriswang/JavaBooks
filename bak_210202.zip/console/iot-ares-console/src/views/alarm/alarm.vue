<!--
 * @Author: 张通
 * @Date: 2020-10-09 09:08:00
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-22 17:24:03
 * @Description: file content
-->
<template>
  <RightContainer class="alarm">
    <template v-slot:sildBar>
      <SiderBar :menu-list="menuList" @menu-active="menuActive" />
      <Breadcrumb class="mianbao" :context="titleContext" />
      <titleRightButton :static-prop="staticProp" @hander-button="handleRightBtn" />
    </template>
    <template>
      <TitleSearch ref="TitleSearch" :search-data="searchData" :default-model="defaultModel" class="TitleSearch" @search="titleSearch" />
      <Table
        v-if="showTable"
        class="table"
        :highlight-current-row="false"
        :loading="tableLoading"
        :table-data="tableData"
        :table-header="tableHeader"
        :total="total"
        :current-page="pageNum"
        :page-size="pageSize"
        :expand-data="expandData"
        :show-selection="tableSelection"
        :expand="tableExpand"
        :expand-table="showTableExpand"
        :expand-table-header="expandTableHeader"
        :last-column-width="`200`"
        table-size="medium"
        :last-table-column="!!actBtnOptions.length"
        :expand-act-btn-options="expandActBtnOptions"
        @pagination-change="paginationChange"
        @selection-change="handlerTableSelection"
        @handle-expand-command="handleExpandCommand"
      >
        <template slot="instanceName" slot-scope="scope">
          <span style="text-decoration:underline;cursor:pointer;" @click="handleCommand([scope.option.type, scope.scope.row])">{{ scope.scope.row.instanceName }}</span>
        </template>
        <template slot="alarmSeverityLabel" slot-scope="scope">
          <span class="iconfont icon-alarm help" :style="{color:alarmColorMap[scope.scope.row.alarmSeverity]}" />&nbsp;&nbsp;{{ scope.scope.row.alarmSeverityLabel }}
        </template>
        <template slot-scope="scope">
          <div>
            <el-button
              v-for="(item,index) in actBtnOptions"
              :key="index"
              type="text"
              class="table-text-btn"
              @click="handleCommand([item.type, scope.scope.row])"
            >{{ item.label }}</el-button>
            <el-dropdown
              v-if="actBtnOptionsMore.length > 0"
              class="table-text-btn margin-left"
              @command="handleCommand"
            >
              <span class="el-dropdown-link">
                {{ $t('public.more') }}
                <i class="el-icon-arrow-down el-icon--right" />
              </span>
              <el-dropdown-menu slot="dropdown" class="dropdown-menu">
                <el-dropdown-item
                  v-for="(item,index) in actBtnOptionsMore"
                  :key="`==${index}`"
                  :command="[item.type, scope.scope.row]"
                >
                  {{ item.label }}
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </template>

      </Table>
    </template>
    <!-- 增删改模态框 -->
    <ActionDialog
      v-if="dialogVisible"
      ref="ActionDialog"
      :title="dialogTitle"
      :visible="dialogVisible"
      :form-items="formItems"
      :form-data="formData"
      :rules-data="rulesData"
      :dialog-type="dialogType"
      @handleClose="handleClose"
      @handleEvent="handleEvent"
      @submit="handleSubmit"
    />
    <!-- 配置模态框 -->
    <thresholdConfigDialog
      v-if="configVisible"
      ref="thresholdConfigDialog"
      :config-visible="configVisible"
      :detail-form="detailForm"
      :title="dialogTitle"
      :dialog-type="dialogType"
      :config-form-data="configFormData"
      :config-rules-data="configRulesData"
      :config-item-list="configItemList"
      @handleClose="handleConfigClose"
      @submit="handleConfigSubmit"
    />
    <!-- 告警通知 -->
    <!-- <noticeDialog /> -->
  </RightContainer>

</template>

<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import RightContainer from './components/RightContainer'
import TitleSearch from '../../components/TitleSearch/TitleSearch'
import Table from '../../components/Table/Table'
import titleRightButton from '@/components/TitleRightButton/titleRightButton'
import Breadcrumb from '@/components/Breadcrumb/Breadcrumb'
import ActionDialog from '@/components/ActionDialog/actionDialog'
import thresholdConfigDialog from './components/thresholdConfigDialog'
// import noticeDialog from './components/noticeDialog'
import alarmMixin from './mixin/mixin'
import activeAlarmMixin from './mixin/activeAlarmMixin'
import historyAlarmMixin from './mixin/historyAlarmMixin'
import alarmDefineMixin from './mixin/alarmDefineMixin'
import thresholdDefineMixin from './mixin/thresholdDefineMixin'
export default {
  name: 'Alarm',
  components: {
    SiderBar,
    RightContainer,
    TitleSearch,
    Table,
    titleRightButton,
    Breadcrumb,
    ActionDialog,
    thresholdConfigDialog
    // noticeDialog
  },
  mixins: [alarmMixin, activeAlarmMixin, historyAlarmMixin, alarmDefineMixin, thresholdDefineMixin],
  data() {
    return {
      alarmColorMap: {
        4: '#ff0000',
        3: '#fe7506',
        2: '#fced02',
        1: '#fcf4cf'
      },
      menu: '',
      defaultModel: {},
      tableLoading: false,
      pageNum: 1,
      pageSize: 10,
      tableSelection: true,
      tableExpand: false,
      showTableExpand: false,
      showTable: false,
      total: null,
      // 增删改模态框变量
      dialogTitle: '',
      dialogVisible: false,
      formItems: [],
      formData: {},
      rulesData: {},
      configRulesData: {},
      dialogType: 1,
      // 阈值配置模态框变量
      configVisible: false,
      detailForm: [],
      configFormData: {},
      configItemList: [],
      configCode: '',
      expandTableHeader: [],
      tableHeader: [],
      tableData: [],
      searchData: [],
      // 展开行数据 配置key 就可以 实际渲染数据从表格行取
      expandData: [],
      expandActBtnOptions: [],
      // 表格操作列按钮, 前两个
      actBtnOptions: [],
      // 操作列下拉框
      actBtnOptionsMore: [],
      // 右上角按钮
      staticProp: [],
      // 面包屑 数据（左上角）
      titleContext: '',
      // search title
      searchCongigData: {},
      // table row 选中后指针
      tableSelectionData: [],
      menuList: [
        {
          label: this.$t('sidebar.activeAlarm'),
          icon: 'icon-peizhi',
          isActive: true,
          id: '1'
        },
        {
          label: this.$t('sidebar.historyAlarm'),
          icon: 'icon-yunwei',
          isActive: false,
          id: '2'
        },
        {
          label: this.$t('sidebar.config'),
          icon: 'icon-peizhi',
          isActive: true,
          id: '3',
          children: [
            {
              label: this.$t('sidebar.alarmDefinition'),
              icon: '',
              isActive: true,
              id: '3-1'
            },
            {
              label: this.$t('sidebar.thresholdDefinition'),
              icon: '',
              isActive: true,
              id: '3-2'
            // },
            // {
            //   label: this.$t('sidebar.alarmNotice'),
            //   icon: '',
            //   isActive: true,
            //   id: '3-3'
            }
          ]
        }
      ]
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'name'
    ]),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  mounted() {
  },
  created() {
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth}  + 10px);
  }
  .TitleSearch {
    margin-bottom: 10px;
  }
  .table {
    height: calc(100% - 70px);
    background: #1c214f;
  }
  .mianbao {
      position: absolute;
      left: 25px;
      top: 0;
      height: 40px;
      padding-left: 0;
  }
  .margin-left{
    span {margin-left: 10px;}
  }
}
</style>
