/*
 * @Author: 张通
 * @Date: 2020-10-13 16:26:36
 * @Description: file content
 */
import http from '@/api/alarm'
function alarmSeverityOtions() {
  return [
    {
      value: '1',
      label: this.$t('statistics.prompt')
    },
    {
      value: '2',
      label: this.$t('statistics.general')
    },
    {
      value: '3',
      label: this.$t('statistics.serious')
    },
    {
      value: '4',
      label: this.$t('statistics.emergency')
    }
  ]
}
function alarmCategoryOptions(params) {
  return [
    {
      value: 'Device',
      label: this.$t('alarm.equipmentAlarm')
    },
    {
      value: 'OM',
      label: this.$t('alarm.platformalarm')
    }
  ]
}

// 表格搜索的配置
function obj() {
  let result = null
  return function() {
    if (!result) {
      result = {
        // 活动--历史告警search_config
        alarm: [
          {
            searchType: 'select',
            id: 'type',
            name: this.$t('alarm.type'),
            searchCondition: true,
            option: []
          },
          {
            searchType: 'select',
            id: 'alarmCategory',
            name: this.$t('alarm.alarmCategory'),
            searchCondition: true,
            option: alarmCategoryOptions.call(this)
          },
          {
            searchType: 'select',
            id: 'alarmSeverity',
            name: this.$t('alarm.alarmSeverity'),
            searchCondition: true,
            option: alarmSeverityOtions.call(this)
          },
          {
            searchType: 'select',
            id: 'alarmid',
            name: this.$t('alarm.alarmName'),
            searchCondition: true,
            option: []
          },
          {
            searchType: 'select',
            id: 'timeType',
            name: this.$t('alarm.timeToType'),
            searchCondition: true,
            option: [
              {
                value: '1',
                label: this.$t('alarm.firstTime')
              },
              {
                value: '2',
                label: this.$t('alarm.lastTime')
              },
              {
                value: '3',
                label: this.$t('alarm.alarmClearTime')
              }
            ]
          },
          {
            type: 'text',
            id: 'instanceName',
            name: this.$t('alarm.resourceName'),
            searchCondition: true
          },
          {
            searchType: 'rangeDate',
            searchCondition: true,
            name: this.$t('alarm.time')
          }
        ],
        // 不要随便改变顺序，添加向最后边追加
        alarmDefine: [
          {
            searchType: 'select',
            id: 'type',
            name: this.$t('alarm.type'),
            searchCondition: true,
            option: []
          },
          {
            searchType: 'select',
            id: 'alarmSeverity',
            name: this.$t('alarm.alarmSeverity'),
            searchCondition: true,
            option: alarmSeverityOtions.call(this)
          },
          {
            searchType: 'select',
            id: 'alarmCategory',
            name: this.$t('alarm.alarmCategory'),
            searchCondition: true,
            option: alarmCategoryOptions.call(this)
          },
          {
            searchType: 'select',
            id: 'ns',
            name: this.$t('alarm.ns'),
            searchCondition: false,
            option: []
          }
        ],
        thresholdDefine: [
          {
            searchType: 'select',
            id: 'rtype',
            name: this.$t('alarm.type'),
            searchCondition: true,
            option: []
          },
          {
            searchType: 'select',
            id: 'ns',
            name: this.$t('alarm.ns'),
            searchCondition: false,
            option: []
          }
        ]
      }
    }
    return result
  }
}
const objFn = obj()

async function setTypeOptions({ type, id } = {}) {
  const objConfig = objFn.call(this)
  objConfig['alarmDefine'][0].option = []
  objConfig['thresholdDefine'][0].option = []
  objConfig['alarm'][0].option = []
  let res
  if (type === 'ns') {
    res = await http.getResourceTypesByNs(id)
    res.code === 200 && res.data && res.data.length > 0 && res.data.forEach(item => {
      objConfig['thresholdDefine'][0].option.push({
        label: item.typeName,
        value: item.type
      })
      objConfig['alarmDefine'][0].option.push({
        label: item.typeName,
        value: item.type
      })
      objConfig['alarm'][0].option.push({
        label: item.typeName,
        value: item.type
      })
    })
  } else {
    res = await http.getResourceType('Type')
    res.code === 200 && res.data && res.data.length > 0 && res.data.forEach(item => {
      objConfig['thresholdDefine'][0].option.push({
        label: item.label,
        value: item.ci
      })
      objConfig['alarmDefine'][0].option.push({
        label: item.label,
        value: item.ci
      })
      objConfig['alarm'][0].option.push({
        label: item.label,
        value: item.ci
      })
    })
  }
}
async function setAlarmConfig() {
  const objConfig = objFn.call(this)
  objConfig['alarm'][3].option = []
  const res = await http.getMoSearchAlarm()
  res && res.code === 200 && res.data && res.data.length > 0 && res.data.forEach(item => {
    objConfig['alarm'][3].option.push({
      label: item.alarmName,
      value: item.alarmId
    })
  })
}
// 进入页面调用查询搜索框的下拉列表
function searchConfig(val, type) {
  const objConfig = objFn.call(this)
  if (!val) return []
  switch (val) {
    case 1: // 告警config search
      setAlarmConfig.call(this)
      setTypeOptions.call(this)
      if (type === 'active') {
        objConfig['alarm'][4].option = [
          {
            value: '1',
            label: this.$t('alarm.firstTime')
          },
          {
            value: '2',
            label: this.$t('alarm.lastTime')
          }
        ]
      } else {
        objConfig['alarm'][4].option = [{
          value: '1',
          label: this.$t('alarm.firstTime')
        },
        {
          value: '2',
          label: this.$t('alarm.lastTime')
        },
        {
          value: '3',
          label: this.$t('alarm.alarmClearTime')
        }]
      }
      return objConfig['alarm']
    case 2: // 告警config search
      setTypeOptions.call(this)
      return objConfig['alarmDefine']
    case 3: // 告警config search
      setTypeOptions.call(this)
      return objConfig['thresholdDefine']
  }
}

function getTypeOptions(option) {
  const objConfig = objFn.call(this)
  setTypeOptions.call(this, option)
  return objConfig['alarmDefine'][0].option
}

function getProductDomainOptions() {
  const objConfig = objFn.call(this)
  setProductDomainOptions.call(this)
  return objConfig['alarmDefine'][3].option
}
async function setProductDomainOptions() {
  const objConfig = objFn.call(this)
  objConfig['alarmDefine'][3].option = []
  // objConfig['thresholdDefine'][0].option = []
  // objConfig['alarm'][0].option = []
  const res = await http.getProductDomain()
  res.code === 200 && res.data && res.data.length > 0 && res.data.forEach(item => {
    // objConfig['thresholdDefine'][0].option.push({
    //   label: item.label,
    //   value: item.ci
    // })
    objConfig['alarmDefine'][3].option.push({
      label: item.name,
      value: item.id
    })
    // objConfig['alarm'][0].option.push({
    //   label: item.label,
    //   value: item.ci
    // })
  })
}

export {
  searchConfig,
  alarmCategoryOptions,
  alarmSeverityOtions,
  getTypeOptions,
  getProductDomainOptions
}
