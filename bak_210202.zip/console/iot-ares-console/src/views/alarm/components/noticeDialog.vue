<!--
 * @Author: 张通
 * @Date: 2020-10-13 13:37:22
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-15 15:29:43
 * @Description: file content
-->
<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    width="40%"
    :modal-append-to-body="false"
    custom-class="noticeDialog"
  >

    <el-row>
      <el-col class="select-col" :span="24">
        <label class="select-label">{{ $t('statistics.informGroup') }}</label>
        <el-select v-model="value" size="mini" :placeholder="$t('statistics.pleaseSelectA')">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-col>
    </el-row>

    <footer class="footer">
      <Table
        :table-header="tableHeader"
        :table-data="tableData"
        :pagination="false"
        :last-table-column="false"
        :highlight-current-row="false"
        :cell-border-style="false"
        :show-selection="true"
      />
    </footer>

    <span slot="footer" class="dialog-footer">
      <el-button class="zt-button" @click="dialogVisible = false">{{ $t('alarm.cancel') }}</el-button>
      <el-button type="primary" @click="dialogVisible = false">{{ $t('alarm.determine') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
import Table from '@/components/Table/Table'
export default {
  components: {
    Table
  },
  props: {
    title: {
      type: String,
      default: () => this.$t('alarm.editor')
    }
  },
  data() {
    return {
      dialogVisible: false,
      options: [{
        value: '选项1',
        label: '黄金糕'
      }, {
        value: '选项2',
        label: '双皮奶'
      }],
      value: '',
      tableHeader: [
        {
          name: this.$t('alarm.resourceCategories'),
          id: 'name'
        },
        {
          name: this.$t('alarm.type'),
          id: 'type'
        }
      ],
      tableData: [
        {
          name: this.$t('alarm.sensingDevices'),
          type: this.$t('alarm.aFireHydrant')
        },
        {
          name: this.$t('alarm.sensingDevices'),
          type: this.$t('alarm.aFireHydrant')
        }
      ]
    }
  },
  methods: {

  }
}
</script>
<style lang="scss">
.noticeDialog {
  .select-col {
    display: flex;
  }
  .select-label {
    display: inline-block;
    width: 80px;
    text-align: right;
    margin-right: 10px;
    align-self: center;
    color: #fff;
  }
  .el-select {
    width: calc(100% - 80px);
  }
  // .el-input__inner {
  //   border: 1px solid #007ecc;
  // }
  .footer {
    margin-top: 10px;
    height: 300px;
    border: 1px solid #007ecc;
    .el-table__empty-block {
      background: none;
    }
    .tableRowClass:nth-child(even) {
      background: none;
    }
    .tableRowClass:nth-child(odd) {
      background: none;
    }
    .el-table th {
      background: #122b6e;
    }
  }
}

</style>
