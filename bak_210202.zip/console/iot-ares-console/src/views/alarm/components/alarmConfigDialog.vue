<!--
 * @Author: 张通
 * @Date: 2020-10-12 14:58:24
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-16 16:39:14
 * @Description: file content
-->
<template>
  <el-dialog
    :title="$t('alarm.configuration')"
    :visible.sync="dialog"
    custom-class="configDialogContainer"
    :modal-append-to-body="false"
    width="40%"
  >
    <div class="configDialog">
      <el-transfer
        v-model="value"
        style="text-align: left; display: inline-block;display: flex;"
        filterable
        :left-default-checked="[2, 3]"
        :right-default-checked="[1]"
        :render-content="renderFunc"
        :titles="['Source', 'Target']"
        :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }"
        :data="data"
      />
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button class="zt-button" @click="dialog = false">{{ $t('alarm.cancel') }}</el-button>
      <el-button type="primary" @click="dialog = false">{{ $t('alarm.determine') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  data() {
    const generateData = _ => {
      const data = []
      for (let i = 1; i <= 15; i++) {
        data.push({
          key: i,
          label: `${this.$t('alarm.alternativesToThe')} ${i}`,
          disabled: i % 4 === 0
        })
      }
      return data
    }
    return {
      dialog: false,
      data: generateData(),
      value: [1],
      value4: [1],
      renderFunc(h, option) {
        return <span>{ option.key } - { option.label }</span>
      }
    }
  },
  methods: {
    handleClose(done) {

    }
  }
}
</script>
<style lang="scss">
.configDialogContainer {
  .configDialog {
    text-align: center;
    width: 100%;
    .el-transfer {
      display: flex;
      flex-direction: row;
      justify-content: center;
      .el-transfer-panel__body {
        height: 300px;
        .el-transfer-panel__list.is-filterable {
            height: calc(100% - 60px);
          }
        .el-input__inner {
          border-radius: 0;
          // border: 1px solid #409EFF;
        }
      }
      .el-transfer-panel {
        width: 50%;
        background: none;
        border: 1px solid #409EFF;
        border-radius: 0;
        .el-transfer-panel__header {
          background: none;
          border: none;
          .el-checkbox__label {
            color: #fff;
          }
        }
      }
      .el-transfer__buttons {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      .el-button {
        margin-left: 0;
      }
    }
  }
}

</style>
