/*
 * @Author: 张通
 * @Date: 2020-10-10 11:42:00
 * @LastEditTime: 2020-10-23 14:21:44
 */

/*
  id用在el-table-column的prop中，
  key用在formItems的key,formItems的key，最后用在 v-model="formData[item.key]" 和 :prop="item.key" 注意有的地方用的是id
  customize: true 用在添加一个自定义表格列
  type用在弹窗是
*/

export default function(val, that) {
  const objConfig = {
    // 活动告警tableHeader
    activityTableHeader: [
      {
        name: that.$t('alarm.alarmSeverity'),
        id: 'alarmSeverityLabel',
        customize: true
      },
      {
        name: that.$t('alarm.alarmName'),
        id: 'alarmName'
      },
      {
        name: that.$t('alarm.resourceName'),
        id: 'instanceName',
        customize: true,
        type: 'detail'
      },
      {
        name: that.$t('alarm.resources') + 'ID',
        id: 'instanceId'
      },
      {
        name: that.$t('alarm.type'),
        id: 'typeLabel'
      },
      {
        name: that.$t('alarm.alarmCategory'),
        id: 'alarmCategoryLabel'
      },
      {
        name: that.$t('alarm.firstTime'),
        id: 'alarmStLabel'
      },
      {
        name: that.$t('alarm.lastTime'),
        id: 'alarmEtLabel'
      },
      // {
      //   name: '告警流水号',
      //   id: 'serialNo'
      // },
      // {
      //   name: '告警ID',
      //   id: 'alarmId'
      // },
      {
        name: that.$t('alarm.ns'),
        id: 'ns',
        hideInTable: true
      },
      // {
      //   name: '告警清除时间',
      //   id: 'alarmCtLabel'
      // },
      {
        name: that.$t('alarm.alarmStatus'),
        id: 'alarmStatusLabel',
        hideInTable: true
      },
      // {
      //   name: '告警发生次数',
      //   id: 'alarmCount'
      // },
      // {
      //   name: '告警清除类型',
      //   id: 'alarmCTypeLabel'
      // },
      {
        name: that.$t('alarm.tenant'),
        id: 'tenantId',
        hideInTable: true
      },
      {
        name: that.$t('alarm.resourceOriginalLogo'),
        id: 'nativeId',
        hideInTable: true
      }
    ],
    // 活动告警展开行
    activityExpend: [
      {
        label: that.$t('alarm.alarmSerialNumber'),
        key: 'serialNo'
      },
      {
        label: that.$t('alarm.alarm') + 'ID',
        key: 'alarmId'
      },
      {
        label: that.$t('alarm.alarmMayCause'),
        key: 'alarmCauseText'
      },
      {
        label: that.$t('alarm.alarmRepireText'),
        key: 'alarmRepireText'
      },

      {
        label: that.$t('alarm.alarmEffectBusiness'),
        key: 'alarmEffectBusiness'
      },
      {
        label: that.$t('alarm.alarmEffectDevice'),
        key: 'alarmEffectDevice'
      },
      {
        label: that.$t('alarm.alarmFrequency'),
        key: 'alarmCount'
      },
      {
        label: that.$t('alarm.alarmLastTime'),
        key: 'alarmEtLabel'
      }
    ],
    // 历史告警tableHeader
    historyTableHeader: [
      {
        name: that.$t('alarm.alarmSeverity'),
        id: 'alarmSeverityLabel',
        customize: true
      },
      {
        name: that.$t('alarm.alarmName'),
        id: 'alarmName'
      },
      {
        name: that.$t('alarm.resourceName'),
        id: 'instanceName',
        // customize: true,
        type: 'detail'
      },
      {
        name: that.$t('alarm.resources') + 'ID',
        id: 'instanceId'
      },
      {
        name: that.$t('alarm.type'),
        id: 'typeLabel'
      },
      {
        name: that.$t('alarm.alarmCategory'),
        id: 'alarmCategoryLabel'
      },
      {
        name: that.$t('alarm.alarmClearTime'),
        id: 'alarmCtLabel'
      },
      {
        name: that.$t('alarm.firstTime'),
        id: 'alarmStLabel'
      },
      // {
      //   name: '告警流水号',
      //   id: 'serialNo'
      // },
      // {
      //   name: '告警ID',
      //   id: 'alarmId'
      // },
      {
        name: that.$t('alarm.ns'),
        id: 'ns',
        hideInTable: true
      },

      {
        name: that.$t('alarm.lastTime'),
        id: 'alarmEtLabel'
      },
      {
        name: that.$t('alarm.alarmStatus'),
        id: 'alarmStatusLabel',
        hideInTable: true
      },
      // {
      //   name: '告警发生次数',
      //   id: 'alarmCount'
      // },
      {
        name: that.$t('alarm.alarmClearType'),
        id: 'alarmCTypeLabel',
        hideInTable: true
      },
      {
        name: that.$t('alarm.tenant'),
        id: 'tenantId',
        hideInTable: true
      },
      {
        name: that.$t('alarm.resourceOriginalLogo'),
        id: 'nativeId',
        hideInTable: true
      }
    ],
    // 阈值定义
    thresholdDefinition: [
      {
        name: that.$t('alarm.ns'),
        id: 'nsName',
        key: 'ns',
        inputType: 'select',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.type'),
        id: 'rtypeLable',
        key: 'rtype',
        inputType: 'select',
        needAdd: true,
        needConfigDetail: true,
        needEdit: true,
        needDetail: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.indicators') + 'ID',
        id: 'metric',
        key: 'metric',
        needAdd: true,
        needConfigDetail: true,
        needEdit: true,
        needDetail: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.indexName'),
        id: 'metricName',
        key: 'metricName',
        needAdd: true,
        needConfigDetail: true,
        needEdit: true,
        needDetail: true
      },
      {
        name: that.$t('alarm.indexGroup') + 'ID',
        id: 'group',
        key: 'group',
        needAdd: true,
        needConfigDetail: true,
        needEdit: true,
        needDetail: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.targetGroupName'),
        id: 'groupName',
        key: 'groupName',
        needAdd: true,
        needEdit: true,
        needDetail: true
      },
      {
        name: that.$t('alarm.indicatorDescription'),
        id: 'desc',
        key: 'desc',
        inputType: 'textarea',
        needAdd: true,
        needEdit: true,
        needDetail: true
      },
      {
        name: that.$t('alarm.indexOfUnit'),
        id: 'unit',
        key: 'unit',
        needAdd: true,
        needConfigDetail: true,
        needEdit: true,
        needDetail: true
      },
      {
        name: `${that.$t('alarm.testingCycle')}(${that.$t('alarm.seconds')})`,
        id: 'oPeriod',
        key: 'oPeriod',
        type: 'input',
        needConfig: true,
        hideInTable: true
      },
      {
        name: that.$t('alarm.detectionThreshold'),
        id: 'oThreshold',
        key: 'oThreshold',
        type: 'input',
        needConfig: true,
        hideInTable: true
      },
      {
        name: that.$t('alarm.toDetectTriggerCondition'),
        id: 'oCondition',
        key: 'oCondition',
        type: 'select',
        options: [
          { value: 0, label: that.$t('alarm.greaterThanOrEqualTo') },
          { value: 1, label: that.$t('alarm.lessThan') }
        ],
        needConfig: true,
        hideInTable: true
      },
      {
        name: that.$t('alarm.detectionOfTriggerActions'),
        id: 'oAction',
        key: 'oAction',
        type: 'select',
        options: [
          { value: 'IES_MO_FmValue_UplinkData', label: that.$t('alarm.callPolice') }
        ],
        needConfig: true,
        hideInTable: true
      },
      {
        name: `${that.$t('alarm.recoveryCycle')}(${that.$t('alarm.seconds')})`,
        id: 'cPeriod',
        key: 'cPeriod',
        type: 'input',
        needConfig: true,
        hideInTable: true
      },
      {
        name: that.$t('alarm.restoreThreshold'),
        id: 'cThreshold',
        key: 'cThreshold',
        type: 'input',
        needConfig: true,
        hideInTable: true
      },
      {
        name: that.$t('alarm.restoreTriggerAction'),
        id: 'cAction',
        key: 'cAction',
        type: 'select',
        options: [
          { value: 'IES_MO_FmValue_UplinkClear', label: that.$t('alarm.eliminatealarm') }
        ],
        needConfig: true,
        hideInTable: true
      }
    ],
    // 告警定义
    alarmDefinition: [
      // {
      //   name: '告警ID',
      //   id: 'alarmId',
      //   key: 'alarmId',
      //   needAdd: true,
      //   needDetail: true,
      //   needEdit: true,
      //   needDisabled: true
      // },
      {
        name: that.$t('alarm.alarmName'),
        id: 'alarmName',
        key: 'alarmName',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.alarmCategory'),
        id: 'alarmCategoryLabel',
        key: 'alarmCategory',
        inputType: 'select',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.alarmSeverity'),
        id: 'alarmSeverityLabel',
        key: 'alarmSeverity',
        inputType: 'select',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        customize: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.ns'),
        id: 'nsName',
        key: 'ns',
        inputType: 'select',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.type'),
        id: 'typeLabel',
        key: 'type',
        inputType: 'select',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.indexName'),
        id: 'metricName',
        key: 'metric',
        inputType: 'select',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.thresholdCondition'),
        id: 'occurCondition',
        key: 'occurCondition',
        inputType: 'select',
        needAdd: true,
        needDetail: true,
        needEdit: true,
        hideInTable: true,
        needDisabled: true
      },
      {
        name: that.$t('alarm.alarmCauseText'),
        id: 'alarmCauseText',
        key: 'alarmCauseText',
        hideInTable: true,
        inputType: 'textarea',
        needAdd: true,
        needDetail: true,
        needEdit: true
      },
      {
        name: that.$t('alarm.alarmEffectBusiness'),
        id: 'alarmEffectBusiness',
        key: 'alarmEffectBusiness',
        hideInTable: true,
        inputType: 'textarea',
        needAdd: true,
        needDetail: true,
        needEdit: true
      },
      {
        name: that.$t('alarm.alarmEffectDevice'),
        id: 'alarmEffectDevice',
        key: 'alarmEffectDevice',
        hideInTable: true,
        inputType: 'textarea',
        needAdd: true,
        needDetail: true,
        needEdit: true
      },
      {
        name: that.$t('alarm.alarmRepireText'),
        id: 'alarmRepireText',
        key: 'alarmRepireText',
        hideInTable: true,
        inputType: 'textarea',
        needAdd: true,
        needDetail: true,
        needEdit: true
      }
      // {
      //   name: '更新时间',
      //   id: 'ltLabel',
      //   key: 'lt',
      //   needAdd: false,
      //   needDetail: true,
      //   needEdit: true
      // }
    ],
    // 告警通知
    alarmNotification: [],
    thresholdDefinitionExpandTableHeader: [
      {
        name: `${that.$t('alarm.testingCycle')}(${that.$t('alarm.seconds')})`,
        id: 'oPeriod'
      },
      {
        name: that.$t('alarm.detectionThreshold'),
        id: 'oThreshold'
      },
      {
        name: that.$t('alarm.toDetectTriggerCondition'),
        id: 'oConditionLabel'
      },
      {
        name: that.$t('alarm.detectionOfTriggerActions'),
        id: 'oActionLabel'
      },
      {
        name: `${that.$t('alarm.recoveryCycle')}(${that.$t('alarm.seconds')})`,
        id: 'cPeriod'
      },
      {
        name: that.$t('alarm.restoreThreshold'),
        id: 'cThreshold'
      },
      {
        name: that.$t('alarm.restoreTriggerAction'),
        id: 'cActionLabel'
      }
    ]
  }
  switch (val) {
    case 1:
      return objConfig['activityTableHeader']
    case 2:
      return objConfig['activityExpend']
    case 3:
      return objConfig['thresholdDefinition']
    case 4:
      return objConfig['alarmDefinition']
    case 5:
      return objConfig['alarmNotification']
    case 6:
      return objConfig['historyTableHeader']
    case 7:
      return objConfig['thresholdDefinitionExpandTableHeader']
  }
}
