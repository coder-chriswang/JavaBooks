<template>
  <div class="resources-container">
    <slot name="sildBar" />
    <!-- 首页 -->
    <div class="resources-main-container" :class="{colsed: !sidebar.opened, open: sidebar.opened}">
      <slot />
    </div>
    <!-- 详情页 -->
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'Resources',
  components: {
  },
  data() {
    return {
      menuList: [],
      menuId: '1'
    }
  },
  computed: {
    ...mapGetters([
      'sidebar'
    ]),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {

  },
  mounted() {
  },
  methods: {
    // 点击侧边栏
    menuActive(val) {

    }

  }
}
</script>

<style lang="scss" scoped>
@import '../../../styles/variables.scss';
.resources {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth}  + 10px);
  }
}
.MainContainerHeight {
  height: calc(100% - 70px) !important;
  margin-bottom: 0px !important;
}
// 动画
@keyframes cllosed {
  from {width: calc(100% - 220px);}
  to {width: calc(100% - 74px);}
}
@keyframes open {
  from {width: calc(100% - 74px);}
  to {width: calc(100% - 220px);}
}
.resources-container {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  position: relative;
  .mianbao {
    position: absolute;
    left: 25px;
    top: 0;
    height: 40px;
    padding-left: 0;
  }
  // 动画
  .colsed {
    animation: cllosed 0.3s linear forwards;
    animation-direction: alternate;
   }
  .open {
    animation: open 0.3s linear forwards;
    animation-direction: alternate;
  }
  .resources-main-container {
    height: calc(100vh - 127px);
    color: aliceblue;
  }
}
</style>
