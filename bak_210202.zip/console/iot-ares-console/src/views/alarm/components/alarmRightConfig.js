/*
 * @Author: 张通
 * @Date: 2020-10-12 13:43:23
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-21 17:41:13
 * @Description: file content
 */

export default function(val, that) {
  const obj = {
    button_1: [
      {
        type: 'ClearAll',
        name: that.$t('alarm.removeAll')
      },
      {
        type: 'button_1',
        name: that.$t('alarm.turnToRepairOrder')
      }
    ],
    button_2: [
      {
        type: 'ClearAll',
        name: that.$t('alarm.removeAll')
      },
      {
        type: 'button_2',
        name: that.$t('alarm.turnToRepairOrder')
      }
    ],
    button_3_1: [
      {
        type: 'button_3_1',
        name: that.$t('alarm.import')
      },
      {
        type: 'button_3_1',
        name: that.$t('statistics.export')
      }
    ],
    button_3_2: [
      {
        type: 'button_3_2',
        name: that.$t('alarm.import')
      },
      {
        type: 'button_3_2',
        name: that.$t('statistics.export')
      }
    ],
    button_3_3: [
      {
        type: 'add',
        name: that.$t('statistics.add')
      }
    ]

  }
  switch (val) {
    case '1':
      return obj['button_1']
    case '2':
      return obj['button_2']
    case '3_1':
      return obj['button_3_1']
    case '3_2':
      return obj['button_3_2']
    case '3_3':
      return obj['button_3_3']
    default:
      return []
  }
}
