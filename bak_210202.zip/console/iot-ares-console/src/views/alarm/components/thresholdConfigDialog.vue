<!--
 * @Author: 张通
 * @Date: 2020-10-12 17:31:35
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-16 17:31:00
 * @Description: file content
-->
<template>
  <el-dialog
    :title="title"
    :visible.sync="myConfigVisible"
    width="50%"
    :modal-append-to-body="false"
    :before-close="handleClose"
    custom-class="thresholdDialog"
  >
    <header>
      <el-form label-width="25%">
        <el-col v-for="(item, index) in detailForm" :key="`detail${index}`" :span="8">
          <el-form-item :label="item.label">
            <strong>{{ item.value }}</strong>
          </el-form-item>
        </el-col>
      </el-form>
    </header>
    <footer>
      <el-row>

        <!-- v-model="configFormData" -->
        <el-form
          ref="ruleForm"
          label-width="25%"
          :model="configFormData"
          :rules="configRulesData"
        >
          <el-col
            v-for="(item, index) in configItemList"
            :key="`from${index}`"
            :span="12"
          >
            <el-form-item :label="item.label" :prop="item.key">
              <el-input
                v-if="item.type === 'input'"
                v-model="configFormData[item.key]"
                size="mini"
                class="form-input"
                :disabled="dialogType === 0"
                :placeholder="`${$t('public.pleaseInput')}${item.label}`"
              />
              <el-select
                v-else
                v-model="configFormData[item.key]"
                size="mini"
                class="form-input"
                :disabled="dialogType === 0"
                :placeholder="`${$t('public.pleaseSelect')}${item.label}`"
              >
                <el-option
                  v-for="(op, ind) in item.options"
                  :key="`op${ind}`"
                  :label="op.label"
                  :value="op.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </footer>
    <span v-if="dialogType !== 0" slot="footer" class="dialog-footer">
      <el-button class="zt-button" @click="handleClose">{{ $t('public.cancel') }}</el-button>
      <el-button type="primary" class="zy-button-bac" @click="formSubmit">{{ $t('public.confirm') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  name: 'ThresholdConfigDialog',
  props: {
    configVisible: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: ''
    },
    detailForm: {
      type: Array,
      default: () => {}
    },
    configRulesData: {
      type: Object,
      default: () => {}
    },
    configFormData: {
      type: Object,
      default: () => {}
    },
    // 0：详情，1：添加，2：修改
    dialogType: {
      type: Number,
      default: 0
    },
    configItemList: {
      type: Array,
      default: () => {}
    }
  },
  data() {
    return {
      myConfigVisible: this.configVisible
    }
  },
  methods: {
    formSubmit() {
      this.$emit('submit', this.configFormData)
      // this.handleClose()
    },
    handleClose() {
      this.myVisible = false
      this.$emit('handleClose', false)
    }
  }
}
</script>
<style lang="scss" scoped>
.thresholdDialog {
  header {
    min-height: 120px;
    margin-bottom: 10px;
    width: 100%;
    background: #13367a;
    .el-form-item {
        margin-bottom: 0px;
    }
  }
  footer {
    // height: 200px;
    width: 100%;
    // .el-input__inner {
    //   border: 1px solid #007ecc;
    // }
  }
  .el-form{display: flex;
    flex-wrap: wrap;}
  .el-col {
    text-align: center;
  }
  .el-input--suffix .el-input__inner {
    padding-right: 13px;
  }
}

.form-input{
  width: 100%;
}
::v-deep .el-form-item__content{
  text-align: left;
  margin-left:28% !important;
}
</style>
