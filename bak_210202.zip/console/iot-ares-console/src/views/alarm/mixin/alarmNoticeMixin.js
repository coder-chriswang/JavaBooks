/*
 * @Author: 刘彦宏
 * @Date: 2020-10-21 10:33:01
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-21 10:35:26
 * @Description: file content
 */

// import http from '@/api/alarm'
import tableConfig from '../components/alarmConfig.js'
import rightConfig from '../components/alarmRightConfig.js'
// import searchConfig from '../components/searchConfig.js'
export default {
  methods: {
    // 告警通知
    setAlarmNotification(val) {
      this.tableSelection = false
      this.tableExpand = false
      // 右上角button
      this.staticProp = rightConfig('3_3', this)
      this.titleContext = val.label
      this.tableHeader = tableConfig(5, this)
      this.getTableData()
      this.$nextTick(() => {
        this.showTable = true
      })
    }
  }
}
