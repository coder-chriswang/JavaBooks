/*
 * @Author: 刘彦宏
 * @Date: 2020-10-21 09:50:49
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-27 10:26:51
 * @Description: file content
 */

import http from '@/api/alarm'
import tableConfig from '../components/alarmConfig.js'
// import rightConfig from '../components/alarmRightConfig.js'
// import { searchConfig } from '../components/searchConfig.js'
export default {
  methods: {
    // 历史告警
    setHistoryAlarm(val) {
      this.tableSelection = false
      this.tableExpand = true
      // 右上角button
      // this.staticProp = rightConfig('2',this)
      this.staticProp = []
      this.titleContext = val.label
      this.actBtnOptions = [
        // {
        //   type: 'detail',
        //   label: this.$t('public.detail')
        // }
      ]
      this.searchData = this.searchConfig(1)
      this.tableHeader = tableConfig(6, this)
      this.expandData = tableConfig(2, this)
      this.getHistoryAlarmData()
      this.$nextTick(() => {
        this.showTable = true
      })
    },
    getHistoryAlarmData() {
      if (!this.searchCongigData.timeType && this.searchCongigData.from) {
        return this.$message(this.$t('alarm.pleaseSelectATimeType'))
      }
      if (this.searchCongigData.timeType && !this.searchCongigData.from) {
        return this.$message(this.$t('alarm.pleaseSelectATime'))
      }
      http.getMoData({
        type: this.searchCongigData.type ? this.searchCongigData.type : '', // 资源类型
        alarmCategory: this.searchCongigData.alarmCategory ? this.searchCongigData.alarmCategory : '', // 告警类别
        alarmSeverity: this.searchCongigData.alarmSeverity ? this.searchCongigData.alarmSeverity : '', // 告警等级
        alarmId: this.searchCongigData.alarmid ? this.searchCongigData.alarmid : '', // 告警类型
        timeType: this.searchCongigData.timeType ? this.searchCongigData.timeType : '', // 时间类型
        from: this.searchCongigData.from ? this.searchCongigData.from : '', // 开始时间
        to: this.searchCongigData.to ? this.searchCongigData.to : '', // 结束时间
        alarmStatus: '1',
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        instanceName: this.searchCongigData.instanceName ? this.searchCongigData.instanceName : ''
      }).then(res => {
        if (res && res.code === 200) {
          this.total = res.data.totalRecordCount
          this.tableData = res.data.records
        }
      }).finally(() => {
        this.tableLoading = false
      })
    },
    // 资源详情
    showHistoryAlarmDetail(row) {
      this.$router.push({ path: '/resources/detail', query: { ci: row.type, ns: row.ns, instanceid: row.instanceId }})
      console.log('detail: ', row)
    },
    editHistoryAlarm(row) {
      console.log('edit: ', row)
    }
  }
}
