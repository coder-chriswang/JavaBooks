/*
 * @Author: 刘彦宏
 * @Date: 2020-10-21 10:25:48
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-23 15:57:17
 * @Description: file content
 */

import http from '@/api/alarm'
import tableConfig from '../components/alarmConfig.js'
import rightConfig from '../components/alarmRightConfig.js'
// import { searchConfig, getTypeOptions, getProductDomainOptions } from '../components/searchConfig.js'
import { validateRangeOfValue } from '@/utils/validate'
import { mapGetters } from 'vuex'
export default {
  computed: {
    ...mapGetters(['language'])
  },
  methods: {
    // 阈值定义
    setThresholdDefinition(val) {
      this.tableSelection = false
      this.tableExpand = false
      this.showTableExpand = true
      // 右上角button
      this.staticProp = rightConfig(null, this)
      this.titleContext = val.label
      this.searchData = this.searchConfig(3)
      this.tableHeader = tableConfig(3, this)
      this.expandTableHeader = tableConfig(7, this)
      // expandActBtnOptions展开行的操作列
      this.expandActBtnOptions = [
        {
          type: 'edit',
          label: this.$t('public.edit')
        },
        {
          type: 'delete',
          label: this.$t('public.delete')
        }
      ]
      // 表格操作
      this.actBtnOptions = [
        {
          type: 'config',
          label: this.$t('public.add')
        },
        {
          type: 'edit',
          label: this.$t('public.edit')
        }
      ]
      this.actBtnOptionsMore = [
        {
          type: 'delete',
          label: this.$t('public.delete')
        }
      ]
      this.getTableData()
      this.$nextTick(() => {
        this.showTable = true
      })
    },
    getThresholdDefineData() {
      http.getPmMetas({
        ...this.searchCongigData,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then((result) => {
        if (result.code === 200 && result.data.records) {
          this.total = result.data.totalRecordCount

          result.data.records.forEach(item => {
            item.ruleList.forEach(item => {
              item.oConditionLabel = item.oCondition === 1 ? this.$t('alarm.lessThan') : this.$t('alarm.greaterThanOrEqualTo')
              item.oActionLabel = item.oAction === 'IES_MO_FmValue_UplinkData' ? this.$t('alarm.callPolice') : item.oAction
              item.cActionLabel = item.cAction === 'IES_MO_FmValue_UplinkClear' ? this.$t('alarm.eliminatealarm') : item.cAction
            })
          })

          this.tableData = result.data.records
          this.tableLoading = false
        }
      })
    },
    handleAddThresholdDefine() {
      this.dialogTitle = this.$t('public.add')
      this.formData = {
        rtype: null,
        metric: null,
        metricName: null,
        group: null,
        groupName: null,
        unit: null,
        desc: null,
        ns: 'ies',
        type: 'line'
      }
      this.rulesData = {
        'ns': [
          { required: true, message: this.$t('alarm.pleaseEnterProductDomain'), trigger: 'blur' }
        ],
        'rtypeLable': [
          { required: true, message: this.$t('alarm.pleaseSelectResourceType'), trigger: 'blur' }
        ],
        'metric': [
          { required: true, message: this.$t('alarm.pleaseEnterIndicators'), trigger: 'blur' },
          { max: 64, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 64 }), trigger: 'blur' }
        ],
        'metricName': [
          { required: true, message: this.$t('alarm.pleaseEnterAName'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'group': [
          { required: true, message: this.$t('alarm.pleaseEnterGroup'), trigger: 'blur' }
        ],
        'groupName': [
          { required: true, message: this.$t('alarm.pleaseProvideASetOfIndicators'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'desc': [
          { max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'unit': [
          { required: true, message: this.$t('alarm.pleaseEnterIndicatorUnit'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ]
      }
      this.formItems = []
      this.tableHeader.forEach(item => {
        let selectOptions = []
        if (item.inputType === 'select') {
          if (item.key === 'rtype') {
            selectOptions = this.getTypeOptions()
          } else if (item.key === 'ns') {
            selectOptions = this.getProductDomainOptions()
          }
        }
        item.needAdd && this.formItems.push({
          label: item.name,
          inputType: item.inputType ? item.inputType : '',
          key: item.id,
          options: selectOptions
        })
      })
      this.dialogType = 1
      this.dialogVisible = true
    },
    deleteThresholdDefine(row) {
      http.deletePmMeta(row.code).then((result) => {
        result.message && this.$message.success(result.message)
        this.getTableData()
      }).catch((err) => {
        this.$message.error(err)
      })
    },
    deleteThresholdConfig(row, code) {
      http.deletePmRule(code, row.oCondition).then((result) => {
        result.message && this.$message.success(result.message)
        this.getTableData()
      }).catch((err) => {
        this.$message.error(err)
      })
    },
    editThresholdDefine(row) {
      this.dialogTitle = this.$t('public.edit')
      this.configCode = row.code
      this.formData = {
        rtype: row.rtype,
        metric: row.metric,
        metricName: row.metricName,
        group: row.group,
        groupName: row.groupName,
        unit: row.unit,
        desc: row.desc,
        ns: row.ns,
        type: row.type
      }
      this.rulesData = {
        'rtype': [
          { required: true, message: this.$t('alarm.pleaseSelectResourceType'), trigger: 'blur' }
        ],
        'metric': [
          { required: true, message: this.$t('alarm.pleaseEnterIndicators'), trigger: 'blur' },
          { max: 64, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 64 }), trigger: 'blur' }
        ],
        'metricName': [
          { required: true, message: this.$t('alarm.pleaseEnterAName'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'group': [
          { required: true, message: this.$t('alarm.pleaseEnterGroup'), trigger: 'blur' }
        ],
        'ns': [
          { required: true, message: this.$t('alarm.pleaseEnterProductDomain'), trigger: 'blur' }
        ],
        'groupName': [
          { required: true, message: this.$t('alarm.pleaseEnterGroupName'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'desc': [
          { max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'unit': [
          { required: true, message: this.$t('alarm.pleaseEnterIndicatorUnit'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ]
      }
      this.formItems = []
      this.tableHeader.forEach(item => {
        let selectOptions = []
        if (item.inputType === 'select') {
          if (item.key === 'rtype') {
            selectOptions = this.getTypeOptions()
          } else if (item.key === 'ns') {
            selectOptions = this.getProductDomainOptions()
          }
        }
        item.needAdd && this.formItems.push({
          label: item.name,
          inputType: item.inputType ? item.inputType : '',
          key: item.key,
          needDisabled: item.needDisabled,
          options: selectOptions
        })
      })
      this.dialogType = 2
      this.dialogVisible = true
    },
    showThresholdDefineDetail(row) {
      this.dialogTitle = this.$t('public.detail')
      this.configCode = row.code
      this.dialogType = 0
      this.configItemList = []
      this.detailForm = []
      this.configFormData = {
        oPeriod: row.rule ? row.rule.oPeriod : '',
        oThreshold: row.rule ? row.rule.oThreshold : '',
        oAction: row.rule ? row.rule.oAction : '',
        cPeriod: row.rule ? row.rule.cPeriod : '',
        cThreshold: row.rule ? row.rule.cThreshold : '',
        cAction: row.rule ? row.rule.cAction : ''
      }
      this.tableHeader.forEach(item => {
        item.needConfig && this.configItemList.push({
          label: item.name,
          key: item.id,
          type: item.type,
          options: item.options ? item.options : null
        })
        item.needConfigDetail && this.detailForm.push({
          label: item.name,
          value: row[item.id]
        })
      })
      this.configVisible = true
    },
    editConfigThresholdDefine(innerRow, row) {
      this.dialogTitle = this.$t('alarm.thresholdToEdit')
      this.configCode = row.code
      this.dialogType = 2
      this.configItemList = []
      this.detailForm = []
      this.configFormData = {
        oPeriod: innerRow ? innerRow.oPeriod.toString() : '',
        oThreshold: innerRow ? innerRow.oThreshold.toString() : '',
        oAction: innerRow ? innerRow.oAction : '',
        cPeriod: innerRow ? innerRow.cPeriod.toString() : '',
        cThreshold: innerRow ? innerRow.cThreshold.toString() : '',
        cAction: innerRow ? innerRow.cAction : '',
        oCondition: innerRow ? innerRow.oCondition : ''
      }
      this.configRulesData = {
        'oPeriod': [
          { required: true, message: this.$t('alarm.pleaseEnterTestingCycle'), trigger: 'blur' },
          { pattern: /^([1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnIntegerGreaterThan', { number: 0 }), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [1, 2147483647], trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'oThreshold': [{ required: true, message: this.$t('alarm.pleaseEnterDetectionThreshold'), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [-2147483648, 2147483647], trigger: 'blur' },
          { pattern: /^(0|[1-9][0-9]*|-[1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnInteger'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }],
        'oCondition': [{ required: true, message: this.$t('alarm.pleaseSelectATriggerConditionDetection'), trigger: 'blur' }],
        'oAction': [{ required: true, message: this.$t('alarm.pleaseSelectADetectionTriggerActions'), trigger: 'blur' }],
        'cPeriod': [{ required: true, message: this.$t('alarm.pleaseEnterRecoveryPeriod'), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [1, 2147483647], trigger: 'blur' },
          { pattern: /^([1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnIntegerGreaterThan', { number: 0 }), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }],
        'cThreshold': [{ required: true, message: this.$t('alarm.pleaseEnterRecoveryThreshold'), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [-2147483648, 2147483647], trigger: 'blur' },
          { pattern: /^(0|[1-9][0-9]*|-[1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnInteger'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'cAction': [{ required: true, message: this.$t('alarm.pleaseSelectARecoveryTriggerActions'), trigger: 'blur' }]

      }
      this.tableHeader.forEach(item => {
        item.needConfig && this.configItemList.push({
          label: item.name,
          key: item.id,
          type: item.type,
          options: item.options ? item.options : null
        })
        item.needConfigDetail && this.detailForm.push({
          label: item.name,
          value: row[item.id]
        })
      })
      this.configVisible = true
    },
    configThresholdDefine(row) {
      this.dialogTitle = this.$t('alarm.configThreshold')
      this.configCode = row.code
      this.dialogType = 1
      this.configItemList = []
      this.detailForm = []
      this.configFormData = {
        oPeriod: row.rule ? row.rule.oPeriod : '',
        oThreshold: row.rule ? row.rule.oThreshold : '',
        oAction: row.rule ? row.rule.oAction : '',
        cPeriod: row.rule ? row.rule.cPeriod : '',
        cThreshold: row.rule ? row.rule.cThreshold : '',
        cAction: row.rule ? row.rule.cAction : ''
      }
      this.configRulesData = {
        'oPeriod': [
          { required: true, message: this.$t('alarm.pleaseEnterTestingCycle'), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [1, 2147483647], trigger: 'blur' },
          { pattern: /^([1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnIntegerGreaterThan', { number: 0 }), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'oThreshold': [{ required: true, message: this.$t('alarm.pleaseEnterDetectionThreshold'), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [-2147483648, 2147483647], trigger: 'blur' },
          { pattern: /^(0|[1-9][0-9]*|-[1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnInteger'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }],
        'oCondition': [{ required: true, message: this.$t('alarm.pleaseSelectATriggerConditionDetection'), trigger: 'blur' }],
        'oAction': [{ required: true, message: this.$t('alarm.pleaseSelectADetectionTriggerActions'), trigger: 'blur' }],
        'cPeriod': [{ required: true, message: this.$t('alarm.pleaseEnterRecoveryPeriod'), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [1, 2147483647], trigger: 'blur' },
          { pattern: /^([1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnIntegerGreaterThan', { number: 0 }), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }],
        'cThreshold': [{ required: true, message: this.$t('alarm.pleaseEnterRecoveryThreshold'), trigger: 'blur' },
          { validator: validateRangeOfValue, langStatus: this.language, range: [-2147483648, 2147483647], trigger: 'blur' },
          { pattern: /^(0|[1-9][0-9]*|-[1-9][0-9]*)$/, message: this.$t('alarm.canOnlyEnterAnInteger'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'cAction': [{ required: true, message: this.$t('alarm.pleaseSelectARecoveryTriggerActions'), trigger: 'blur' }]

      }
      this.tableHeader.forEach(item => {
        item.needConfig && this.configItemList.push({
          label: item.name,
          key: item.id,
          type: item.type,
          options: item.options ? item.options : null
        })
        item.needConfigDetail && this.detailForm.push({
          label: item.name,
          value: row[item.id]
        })
      })
      this.configVisible = true
    },
    async handleConfigSubmit(params) {
      try {
        await this.$refs['thresholdConfigDialog'].$refs['ruleForm'].validate()
      } catch (error) {
        return false
      }
      if (this.dialogType === 1) {
        http.configPmMeta(this.configCode, params).then((result) => {
          if (result && result.code === 200) {
            result.message && this.$message.success(result.message)
            this.configVisible = false
            this.getTableData()
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      } else {
        http.updateConfigPmMeta(this.configCode, params).then((result) => {
          if (result && result.code === 200) {
            result.message && this.$message.success(result.message)
            this.configVisible = false
            this.getTableData()
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      }
    },
    async thresholdDefineSubmit(params) {
      try {
        await this.formValidate('ruleForm')
      } catch (error) {
        return false
      }
      if (this.dialogType === 1) {
        http.addPmMeta(params).then((result) => {
          result.message && this.$message.success(result.message)
          this.dialogVisible = false
          this.getTableData()
        }).catch((err) => {
          this.$message.error(err)
        })
      } else {
        http.updatePmMeta(this.configCode, params).then((result) => {
          result.message && this.$message.success(result.message)
          this.dialogVisible = false
          this.getTableData()
        }).catch((err) => {
          this.$message.error(err)
        })
      }
    },
    handleConfigClose(val) {
      this.configVisible = val
    }
  }
}
