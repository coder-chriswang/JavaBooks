/*
 * @Author: 刘彦宏
 * @Date: 2020-09-30 11:17:01
 * @LastEditTime: 2020-10-23 10:49:25
 */
import { searchConfig, getTypeOptions, getProductDomainOptions } from '../components/searchConfig.js'
export default {
  methods: {
    searchConfig, getTypeOptions, getProductDomainOptions,
    menuActive(val) {
      if (Object.keys(this.searchCongigData).length > 0) {
        this.searchCongigData = {}
      }
      this.tableLoading = true
      this.menu = val
      this.pageNum = 1
      this.pageSize = 10
      this.showTable = false
      this.tableData = []
      this.actBtnOptions = []
      this.actBtnOptionsMore = []
      this.total = 0
      this.showTableExpand = false
      this.defaultModel = {}
      this.$nextTick(() => {
        this.$refs['TitleSearch'].reset()
        this.searchCongigData = {}
      })
      if (val.menuId === '1') return this.setActivityAlarm(val.item)
      if (val.menuId === '2') return this.setHistoryAlarm(val.item)
      if (val.menuId === '3-1') return this.setAlarmDefinition(val.item)
      if (val.menuId === '3-2') return this.setThresholdDefinition(val.item)
      if (val.menuId === '3-3') return this.setAlarmNotification(val.item)
    },
    // 查询列表
    getTableData() {
      switch (this.menu.menuId) {
        case '1':
          this.getActiveAlarmData()
          break
        case '2':
          this.getHistoryAlarmData()
          break
        case '3-1':
          this.getAlarmDefineData()
          break
        case '3-2':
          this.getThresholdDefineData()
          break
        case '3-3':
          break
      }
    },
    titleSearch(val = {}) {
      console.log(val)
      this.pageNum = 1
      // this.pageSize = 10
      this.searchCongigData = { ...val }
      if (val.rangeDate) {
        const from = Math.round(new Date(val.rangeDate[0]) / 1000)
        const to = Math.round(new Date(val.rangeDate[1]) / 1000)
        this.searchCongigData = { ...this.searchCongigData, ...{ from: from, to: to }}
        delete this.searchCongigData.rangeDate
      }
      this.getTableData()
    },
    paginationChange(val) {
      this.tableLoading = true
      this.pageNum = val.currentPageNum
      this.pageSize = val.pageSizeNum
      this.getTableData()
    },
    handleCommand(val) {
      switch (val[0]) {
        case 'clear':
          this.handleDelete(val[1], 'public.clearTips')
          break
        case 'delete':
          this.handleDelete(val[1])
          break
        case 'edit':
          this.handleEdit(val[1])
          break
        case 'detail':
          this.handleDetail(val[1])
          break
        case 'config':
          this.handleConfig(val[1])
          break
      }
    },
    handleExpandCommand(val) {
      const commandMap = {
        'delete': this.handleExpandDelete,
        'edit': this.handleExpandEdit
      }
      commandMap[val[0]](val[1], val[2])
    },
    handleExpandDelete(row, { code }) {
      this.$confirm(this.$t('public.deleteTips'), this.$t('public.tips'), {
        confirmButtonText: this.$t('public.confirm'),
        cancelButtonText: this.$t('public.cancel'),
        type: 'warning'
      }).then(() => {
        const deleteMap = {
          '3-2': this.deleteThresholdConfig
        }
        deleteMap[this.menu.menuId](row, code)
      }).catch(() => {
        this.$message({
          showClose: true,
          type: 'info',
          message: this.$t('public.deleteCancel')
        })
      })
    },
    handleDelete(row, tip = 'public.deleteTips') {
      this.$confirm(this.$t(tip), this.$t('public.tips'), {
        confirmButtonText: this.$t('public.confirm'),
        cancelButtonText: this.$t('public.cancel'),
        type: 'warning'
      }).then(() => {
        switch (this.menu.menuId) {
          case '1':
            return this.clearAlarm(row)
          case '3-1':
            this.deleteAlarmDefine(row)
            break
          case '3-2':
            this.deleteThresholdDefine(row)
            break
        }
      }).catch(() => {
        this.$message({
          showClose: true,
          type: 'info',
          message: this.$t('public.deleteCancel')
        })
      })
    },
    handleDetail(row) {
      switch (this.menu.menuId) {
        case '1':
          this.showActiveAlarmDetail(row)
          break
        case '2':
          this.showHistoryAlarmDetail(row)
          break
        case '3-1':
          this.showAlarmDefineDetail(row)
          break
        case '3-2':
          // this.showThresholdDefineDetail(row)
          this.configThresholdDefine(row)
          break
        case '3-3':
          // this.showThresholdDefineDetail(row)
          break
      }
    },
    handleEdit(row) {
      switch (this.menu.menuId) {
        case '1':
          this.editActiveAlarm(row)
          break
        case '2':
          this.editHistoryAlarm(row)
          break
        case '3-1':
          this.editAlarmDefine(row)
          break
        case '3-2':
          this.editThresholdDefine(row)
          break
        case '3-3':
          // this.editThresholdDefine(row)
          break
      }
    },
    handleExpandEdit(innerRow, row) {
      const editMap = {
        '3-2': this.editConfigThresholdDefine
      }

      editMap['3-2'](innerRow, row)
    },
    handleConfig(row) {
      switch (this.menu.menuId) {
        case '3-2':
          this.configThresholdDefine(row)
          break
      }
    },
    handleClose(val) {
      this.dialogVisible = val
      this.formItems = []
      this.formData = {}
      this.rulesData = {}
      this.configRulesData = {}
    },
    handleRightBtn(val) {
      switch (val.type) {
        case 'add':
          this.handleAdd()
          break
        case 'ClearAll':
          return this.clearAlarm(this.tableSelectionData)
      }
    },
    handleAdd() {
      switch (this.menu.menuId) {
        case '3-1':
          this.handleAddAlarmDefine()
          break
        case '3-2':
          this.handleAddThresholdDefine()
          break
      }
    },
    handleSubmit(val) {
      switch (this.menu.menuId) {
        case '3-1':
          this.alarmDefineSubmit(val)
          break
        case '3-2':
          this.thresholdDefineSubmit(val)
          break
      }
    },
    formValidate(formName) {
      return new Promise((resolve, reject) => {
        this.$refs['ActionDialog'].$refs[formName].validate((valid) => {
          if (valid) {
            resolve(valid)
          } else {
            reject(valid)
          }
        })
      })
    },
    // 表格选中
    handlerTableSelection(val) {
      this.tableSelectionData = val
    }
  }
}
