/*
 * @Author: 刘彦宏
 * @Date: 2020-10-21 09:50:49
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-21 18:00:07
 * @Description: file content
 */

import http from '@/api/alarm'
import tableConfig from '../components/alarmConfig.js'
import rightConfig from '../components/alarmRightConfig.js'
export default {
  methods: {
    // 活动告警 点击menu
    setActivityAlarm(val) {
      this.searchCongigData.alarmSeverity = this.$route.query.severity
      this.searchCongigData.instanceName = this.$route.query.instanceName
      this.defaultModel = {
        alarmSeverity: this.$route.query.severity && this.$route.query.severity.toString(),
        instanceName: this.$route.query.instanceName && this.$route.query.instanceName.toString()
      }
      this.tableSelection = true
      this.tableExpand = true
      // 右上角button
      this.staticProp = rightConfig('1', this)
      this.titleContext = val.label
      this.actBtnOptions = [
        // {
        //   type: 'detail',
        //   label: this.$t('public.detail')
        // },
        {
          type: 'clear',
          label: this.$t('public.clear') // 清除
        }
      ]
      this.actBtnOptionsMore = []
      this.searchData = this.searchConfig(1, 'active')
      this.tableHeader = tableConfig(1, this)
      this.expandData = tableConfig(2, this)
      this.getActiveAlarmData()
      this.$nextTick(() => {
        this.showTable = true
      })
    },
    // 默认加载
    getActiveAlarmData() {
      if (!this.searchCongigData.timeType && this.searchCongigData.from) {
        return this.$message(this.$t('alarm.pleaseSelectATimeType'))
      }
      if (this.searchCongigData.timeType && !this.searchCongigData.from) {
        return this.$message(this.$t('alarm.pleaseSelectATime'))
      }
      http.getMoData({
        type: this.searchCongigData.type ? this.searchCongigData.type : '', // 资源名称
        alarmCategory: this.searchCongigData.alarmCategory ? this.searchCongigData.alarmCategory : '', // 告警类别
        alarmSeverity: this.searchCongigData.alarmSeverity ? this.searchCongigData.alarmSeverity : '', // 告警等级
        alarmId: this.searchCongigData.alarmid ? this.searchCongigData.alarmid : '', // 告警类型
        timeType: this.searchCongigData.timeType ? this.searchCongigData.timeType : '', // 时间类型
        from: this.searchCongigData.from ? this.searchCongigData.from : '', // 开始时间
        to: this.searchCongigData.to ? this.searchCongigData.to : '', // 结束时间
        alarmStatus: '0',
        pageNum: this.pageNum,
        pageSize: this.pageSize,
        instanceName: this.searchCongigData.instanceName ? this.searchCongigData.instanceName : ''
      }).then(res => {
        if (res.code === 200) {
          this.total = res.data.totalRecordCount
          this.tableData = res.data.records
        }
      }).finally(() => {
        this.tableLoading = false
      })
    },
    // 告警清除
    clearAlarm(row) {
      let clearArr = []
      if (Array.isArray(row)) {
        if (row.length === 0) {
          return this.$message({
            showClose: true,
            message: this.$t('alarm.pleaseSelectToClearalarmEntries'),
            type: 'warning'
          })
        }
        row.forEach(item => {
          clearArr.push({
            instanceId: item.instanceId,
            serialNo: item.serialNo
          })
        })
      } else {
        clearArr = [
          {
            instanceId: row.instanceId,
            serialNo: row.serialNo
          }
        ]
      }
      http.setActiveClear({
        action: 'Clear',
        items: clearArr
      }).then(res => {
        if (res.code === 200) {
          this.$message.success(this.$t('alarm.alarmClearSuccess'))
          this.getActiveAlarmData() // 清除完成 掉接口
        } else {
          this.$message({
            showClose: true,
            message: this.$t('alarm.alarmClearFailure'),
            type: 'warning'
          })
        }
      })
    },
    // 资源详情
    showActiveAlarmDetail(row) {
      this.$router.push({ path: '/resources/detail', query: { ci: row.type, ns: row.ns, instanceid: row.instanceId }})
      console.log('detail: ', row)
    },
    editActiveAlarm(row) {
      console.log('edit: ', row)
    }
  }
}
