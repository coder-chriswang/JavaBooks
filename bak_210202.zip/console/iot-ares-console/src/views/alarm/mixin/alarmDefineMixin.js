/*
 * @Author: 刘彦宏
 * @Date: 2020-10-21 10:25:48
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-23 14:25:31
 * @Description: file content
 */

import http from '@/api/alarm'
import tableConfig from '../components/alarmConfig.js'
import rightConfig from '../components/alarmRightConfig.js'
import { alarmCategoryOptions, alarmSeverityOtions } from '../components/searchConfig.js'
export default {
  methods: {
    // 告警定义
    setAlarmDefinition(val) {
      this.tableSelection = false
      this.tableExpand = false
      // 右上角button
      this.staticProp = rightConfig('3_3', this)
      // 表格操作
      this.actBtnOptions = [
        { type: 'detail', label: this.$t('public.detail') },
        { type: 'edit', label: this.$t('public.edit') }
      ]
      this.actBtnOptionsMore = [{ type: 'delete', label: this.$t('public.delete') }]
      this.titleContext = val.label
      this.searchData = this.searchConfig(2)
      this.tableHeader = tableConfig(4, this)
      this.getTableData()
      this.$nextTick(() => {
        this.showTable = true
      })
    },
    getAlarmDefineData() {
      http.getFmMetas({
        ...this.searchCongigData,
        pageNum: this.pageNum,
        pageSize: this.pageSize
      }).then((result) => {
        if (result.code === 200 && result.data && result.data.records) {
          this.total = result.data.totalRecordCount
          this.tableData = result.data.records
          this.tableLoading = false
        } else {
          this.total = 0
          this.tableData = []
          this.tableLoading = false
        }
      })
    },
    async getDialogAlarmCondition(metric) {
      const res = await http.getMetricCondition(metric)
      this.tableHeader.forEach(item => {
        if (item.key === 'occurCondition' && item.needAdd) {
          const occurCondition = this.formItems.find(i => i.key === item.key)
          if (occurCondition) {
            const options = res.data.map(item => ({
              value: item,
              label: item === 1 ? this.$t('alarm.lessThan') : this.$t('alarm.greaterThanOrEqualTo')
            }))
            this.$set(occurCondition, 'options', options)
          }
          console.log(occurCondition)
        }
      })
    },
    async getDialogAlarmMetric(params) {
      const res = await http.getMetricByType(params)
      this.tableHeader.forEach(item => {
        if (item.key === 'metric' && item.needAdd) {
          const metric = this.formItems.find(i => i.key === item.key || i.key === 'metricName')
          if (metric) {
            const options = res.data.map(({ metric, metricName }) => ({
              value: metric,
              label: metricName })
            )
            this.$set(metric, 'options', options)
          }
        }
      })
    },
    async getDialogAlarmNs() {
      const res = await http.getProductDomain()
      this.tableHeader.forEach(item => {
        if (item.key === 'ns' && item.needAdd) {
          const ns = this.formItems.find(i => i.key === item.key)
          if (ns) {
            const options = res.data.map(({ id, name }) => ({
              value: id,
              label: name })
            )
            this.$set(ns, 'options', options)
          }
        }
      })
    },
    async handleEvent({ id, params }) {
      if (id === 'ns') {
        this.formData['metric'] = null
        this.formData['type'] = null
        this.formData['occurCondition'] = null
        const typeOption = this.getTypeOptions({ type: 'ns', id: params })
        this.tableHeader.forEach(item => {
          if (item.key === 'type' && item.needAdd) {
            const type = this.formItems.find(i => i.key === item.key)
            if (type) {
              type.options = typeOption
            }
          }
        })

        this.tableHeader.forEach(item => {
          if (item.key === 'metric' && item.needAdd) {
            const metric = this.formItems.find(i => i.key === item.key)
            if (metric) {
              metric.options = []
            }
          }
        })
      }
      if (id === 'type') {
        this.formData['metric'] = null
        this.formData['occurCondition'] = null
        this.getDialogAlarmMetric(params)
      }
      if (id === 'metric') {
        this.formData['occurCondition'] = null
        this.getDialogAlarmCondition(params)
      }
    },
    async alarmDefineSubmit(params) {
      try {
        await this.formValidate('ruleForm')
      } catch (error) {
        return false
      }
      if (this.dialogType === 1) {
        http.addFmMeta(params).then((result) => {
          if (result && result.code === 200) {
            result && result.message && this.$message.success(result.message)
            this.dialogVisible = false
            this.getTableData()
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      } else {
        http.updateFmMeta(params).then((result) => {
          if (result && result.code === 200) {
            result && result.message && this.$message.success(result.message)
            this.dialogVisible = false
            this.getTableData()
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      }
    },
    deleteAlarmDefine(row) {
      http.deleteFmMeta(row.code).then((result) => {
        result.message && this.$message.success(result.message)
        this.getTableData()
      }).catch((err) => {
        this.$message.error(err)
      })
    },
    handleAddAlarmDefine() {
      this.dialogTitle = this.$t('public.add')
      this.formData = {
        alarmCategory: null,
        alarmCauseText: null,
        alarmEffectBusiness: null,
        alarmEffectDevice: null,
        // alarmId: null,
        alarmName: null,
        alarmRepireText: null,
        alarmSeverity: null,
        ns: null,
        code: null,
        type: null,
        metric: null,
        occurCondition: null
      }
      this.rulesData = {
        // 'alarmId': [
        //   { required: true, message: '请输入告警ID', trigger: 'blur' }
        // ],
        'alarmName': [
          { required: true, message: this.$t('alarm.pleaseEnteralarmName'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'alarmCategory': [
          { required: true, message: this.$t('alarm.pleaseSelectalarmGroup') }
        ],
        'alarmSeverity': [
          { required: true, message: this.$t('alarm.pleaseSelectalarmLevel') }
        ],
        'ns': [
          { required: true, message: this.$t('alarm.pleaseSelectAProductDomain') },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }) }
        ],
        'type': [
          { required: true, message: this.$t('alarm.pleaseSelectResourceType') }
        ],
        'metric': [{ required: true, message: this.$t('alarm.pleaseSelectAMetricNames') }],
        'occurCondition': [
          { required: true, message: this.$t('alarm.pleaseSelectACondition') }
        ],
        'alarmCauseText': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'alarmEffectBusiness': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'alarmEffectDevice': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'alarmRepireText': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ]
      }
      this.formItems = []
      this.tableHeader.forEach(item => {
        let selectOptions = []
        if (item.inputType === 'select') {
          if (item.key === 'alarmCategory') {
            selectOptions = alarmCategoryOptions.call(this)
          } else if (item.key === 'alarmSeverity') {
            selectOptions = alarmSeverityOtions.call(this)
          } else if (item.key === 'type') {
            selectOptions = []
            // selectOptions = getTypeOptions({ type: 'ns', id: 'ies' })
          } else if (item.key === 'ns') {
            selectOptions = this.getProductDomainOptions()
          }
        }
        item.needAdd && this.formItems.push({
          label: item.name,
          inputType: item.inputType ? item.inputType : '',
          key: item.key,
          options: selectOptions
        })
      })
      this.dialogType = 1
      this.dialogVisible = true
    },
    editAlarmDefine(row) {
      this.dialogTitle = this.$t('public.edit')
      this.formData = {
        alarmCategory: row.alarmCategory,
        alarmCauseText: row.alarmCauseText,
        alarmEffectBusiness: row.alarmEffectBusiness,
        alarmEffectDevice: row.alarmEffectDevice,
        // alarmId: row.alarmId,
        alarmName: row.alarmName,
        alarmRepireText: row.alarmRepireText,
        alarmSeverity: row.alarmSeverity + '',
        ns: row.ns,
        code: row.code,
        type: row.type,
        metric: row.metric,
        occurCondition: row.occurCondition
      }
      // 通过资源选项调用指标接口做回填
      this.getDialogAlarmMetric(row.type)
      this.getDialogAlarmCondition(row.metric)
      this.rulesData = {
        // 'alarmId': [
        //   { required: true, message: '请输入告警ID', trigger: 'blur' }
        // ],
        'alarmName': [
          { required: true, message: this.$t('alarm.pleaseEnteralarmName'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'alarmCategory': [
          { required: true, message: this.$t('alarm.pleaseSelectalarmGroup'), trigger: 'blur' }
        ],
        'alarmSeverity': [
          { required: true, message: this.$t('alarm.pleaseSelectalarmLevel'), trigger: 'blur' }
        ],
        'ns': [
          { required: true, message: this.$t('alarm.pleaseSelectAProductDomain'), trigger: 'blur' },
          { max: 16, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 16 }), trigger: 'blur' }
        ],
        'type': [
          { required: true, message: this.$t('alarm.pleaseSelectResourceType'), trigger: 'blur' }
        ],
        'metric': [
          { required: true, message: this.$t('alarm.pleaseSelectAMetricNames'), trigger: 'blur' }
        ],
        'occurCondition': [
          { required: true, message: this.$t('alarm.pleaseSelectAMetricNames'), trigger: 'blur' }
        ],
        'alarmCauseText': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'alarmEffectBusiness': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'alarmEffectDevice': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ],
        'alarmRepireText': [{ max: 128, message: this.$t('statistics.lengthShouldNotExceedCharacters', { number: 128 }), trigger: 'blur' }
        ]
      }
      this.formItems = []
      this.tableHeader.forEach(item => {
        let selectOptions = []
        if (item.inputType === 'select') {
          if (item.key === 'alarmCategory') {
            selectOptions = alarmCategoryOptions.call(this)
          } else if (item.key === 'alarmSeverity') {
            selectOptions = alarmSeverityOtions.call(this)
          } else if (item.key === 'type') {
            selectOptions = this.getTypeOptions({ type: 'ns', id: row.ns })
          } else if (item.key === 'ns') {
            selectOptions = this.getProductDomainOptions()
          }
        }
        item.needEdit && this.formItems.push({
          label: item.name,
          inputType: item.inputType ? item.inputType : '',
          key: item.key,
          options: selectOptions,
          needDisabled: item.needDisabled
        })
      })
      this.dialogType = 2
      this.dialogVisible = true
    },
    showAlarmDefineDetail(row) {
      this.dialogTitle = this.$t('public.detail')
      this.formData = {
        alarmCategoryLabel: row.alarmCategoryLabel,
        alarmCauseText: row.alarmCauseText,
        alarmEffectBusiness: row.alarmEffectBusiness,
        alarmEffectDevice: row.alarmEffectDevice,
        // alarmId: row.alarmId,
        alarmName: row.alarmName,
        alarmRepireText: row.alarmRepireText,
        alarmSeverityLabel: row.alarmSeverityLabel,
        ltLabel: row.ltLabel,
        nsName: row.nsName,
        typeLabel: row.typeLabel,
        metricName: row.metricName,
        occurCondition: row.occurCondition
      }
      // this.getDialogAlarmNs()
      this.getDialogAlarmMetric(row.type)
      this.getDialogAlarmCondition(row.metric)
      this.rulesData = {}
      this.formItems = []
      this.tableHeader.forEach(item => {
        item.needDetail && this.formItems.push({
          label: item.name,
          inputType: item.inputType ? item.inputType : '',
          needDisabled: item.needDisabled,
          key: item.id
        })
      })
      this.dialogType = 0
      this.dialogVisible = true
    }
  }
}
