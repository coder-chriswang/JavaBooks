<template>
  <div class="resources-container">
    <SiderBar v-if="!setTimeShowSidBar" :menu-list="menuList" @menu-active="menuActive" />
    <Breadcrumb :show-back="resourcesDetails" class="mianbao" :context="menuSelectedName" @handleBack="back" />
    <titleRightButton :static-prop="staticButton" />
    <!-- 详情页 -->
    <div class="resources-main-container" :class="{colsed: !sidebar.opened, open: sidebar.opened}">
      <TitleSearch v-if="showTitleSearch" ref="detailSearch" :search-data="searchData" class="TitleSearch resources-card-bac-pad" @search="searchDetail" />
      <FooterDetail
        ref="detail"
        :show-header="false"
        :style="{height: detailFooterHeight}"
        class="FooterDetail resources-card-bac-pad"
      />
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import http from '@/api/resource'
import SiderBar from '@/components/Sidebar/Sidebar'
import TitleSearch from '../../components/TitleSearch/TitleSearch'
import FooterDetail from './details/FooterDetail'
import Breadcrumb from '@/components/Breadcrumb/Breadcrumb'
import getSearchConfig from './mixin/searchConfig'
import titleRightButton from '@/components/TitleRightButton/titleRightButton'
export default {
  name: 'Resources',
  components: {
    SiderBar,
    TitleSearch,
    FooterDetail,
    Breadcrumb,
    titleRightButton
  },
  mixins: [getSearchConfig],
  data() {
    return {
      pageInfo: {
        currentPage: 1,
        pageSize: 10
      },
      menuList: [],
      menuId: '1',
      // 是否显示footer组件
      MainContainer: {
        tableData: [],
        tableHeader: [],
        total: 0
      },
      lazyRender: false,
      // 头部搜索框
      searchData: [],
      // 页面加载时首先不加载此组件  当 配置接口请求成功后 才加载此组件  并且调用table接口
      setTimeShowSidBar: true,
      // 面包屑内容
      menuSelectedName: '',
      tableLoading: true,
      // 静态按钮
      staticButton: [],
      // 实例按钮
      instanceButton: [],
      menuListMap: {
        '1': this.$t('resources.basicInfo'),
        '2': this.$t('sidebar.downAction'),
        '3': this.$t('sidebar.upAction'),
        '4': this.$t('sidebar.topology'),
        '5': this.$t('alarm.alarm'),
        '6': this.$t('sidebar.monitor'),
        '7': this.$t('sidebar.positionTrack')
      }
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'isShowFooterDetails', // 控制资源页面footer是否显示
      'resourcesDetails', // 控制是否跳转至详情页
      'showTitleSearch', // 是否显示titlesearch
      'tableRow', // 选中某行
      'requestType'
    ]),
    detailFooterHeight() {
      if (this.showTitleSearch) {
        return `calc(100% - 70px)`
      } else {
        return '100%'
      }
    },
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {

  },
  mounted() {
    this.changeResourcesDetails(true)
    this.setTableRow({ instanceid: this.$route.query.instanceid })
    this.getRouter(this.$route.query.ci, this.$route.query.ns)
    this.setRequestType({
      instanceid: this.$route.query.instanceid,
      ci: this.$route.query.ci,
      ns: this.$route.query.ns
    })
  },
  beforeRouteEnter(to, from, next) {
    next()
  },
  beforeRouteLeave(to, from, next) {
    next(vm => {
      window.location.reload()
    })
    this.changeFooterDetails(false)
    this.changeResourcesDetails(false)
    this.changeShowTitleSearch(false)
    this.changeSelectedNum(false)
  },
  methods: {
    ...mapActions([
      'changeFooterDetails',
      'changeResourcesDetails',
      'changeSelectedNum',
      'changeShowTitleSearch',
      'setRequestType',
      'setTableRow'
    ]),
    // 左边路由信息
    getRouter(ci, ns) {
      this.getDatialPageRouter(ci, ns)
    },
    getDatialPageRouter(ci, ns) {
      http.getTab({
        ci: ci,
        ns: ns
      }).then(res => {
        if (res.code === 200) {
          this.menuList = res.data
          if (this.menuList !== null && this.menuList.length > 0) {
            this.menuList.forEach(item => {
              item.id = item.om
              item.label = this.menuListMap[item.om]
              // item.label = item.name
            })
            this.changeSelectedNum(this.menuList[0].id)
            this.setTimeShowSidBar = false
            this.getNameByIdInObjArr(this.menuList, this.menuList[0].id) // 设置 面包屑 显示内容
          } else {
            this.changeSelectedNum(null)
          }
        }
      })
    },
    // 面包屑递归查找
    getNameByIdInObjArr(arr, id) {
      arr.forEach(v => {
        if (id === v.id) {
          this.menuSelectedName = v.label
        }
        if (v.children && v.children.length > 0) {
          this.getNameByIdInObjArr(v.children, id)
        }
      })
    },

    // 点击侧边栏
    menuActive(val) {
      // set面包屑
      this.getNameByIdInObjArr(this.menuList, val.menuId)
      // 隐藏footer页签
      this.changeFooterDetails(false)

      // 详情
      this.changeSelectedNum(val.menuId)
      // 重置搜索条件
      if (this.$refs['detailSearch']) {
        this.$refs['detailSearch'].Handlerreset()
      }
      this.$refs['detail'].getDetail()
      // 后台会有字段说明此判断条件
      if (val.menuId === '2' || val.menuId === '3' || val.menuId === '5' || val.menuId === '6' || val.menuId === '7') {
        this.getDetailSearchData(val.menuId)
        this.changeShowTitleSearch(true)
      } else {
        this.changeShowTitleSearch(false)
      }
    },
    // 详情searchConfig
    async getDetailSearchData(v) {
      const that = this
      that.searchData = this.getSearchConfig(v)
      if (v === '5') {
        const con = await http.getConfigGiveSelect()
        if (con.code === 200) {
          con.data.length > 0 && con.data.forEach(item => {
            item.label = item.alarmName
            item.value = item.alarmId
          })
          that.searchData[0].option = con.data
        } else {
          that.searchData[0].option = []
        }
      }
    },
    // 详情搜索
    searchDetail(v) {
      if (v.rangeDate) {
        v.startTime = Math.round(new Date(v.rangeDate[0]).getTime() / 1000)
        v.endTime = Math.round(new Date(v.rangeDate[1]).getTime() / 1000)
      }
      this.$refs['detail'].getDetail(v)
    },
    // 分拣数据为静态button 或者是 实例button
    setStaticButton(ac) {
      this.staticButton = []
      this.instanceButton = []
      const action = ac.data.actions
      if (action.length > 0) {
        action.forEach(item => {
          if (item.domain === 'Static') {
            this.staticButton.push(item)
          } else if (item.domain === 'Instance') {
            this.instanceButton.push(item)
          }
        })
      }
    },
    // table 数据
    async getConfigTable(searchData = {}) {
      this.tableLoading = true
      const resHeader = await http.getConfigTableHeader({
        category: this.requestType.category,
        ci: this.requestType.ci
      })
      this.setStaticButton(resHeader)
      const resTableData = await http.getTableData({
        action: 'Query',
        ci: this.requestType.ci,
        ns: this.requestType.ns,
        pageSize: this.pageInfo.pageSize,
        pageNum: this.pageInfo.currentPage,
        data: {
          ...searchData
        }
      })
      this.MainContainer = {
        tableData: resTableData.data.list,
        total: resTableData.data.total,
        tableHeader: resHeader.data.attrs
      }
      // 条件选择渲染
      if (this.MainContainer.tableHeader.length > 0) {
        this.searchData = []
        this.MainContainer.tableHeader.forEach(item => {
          if (item.searchCondition) {
            this.searchData.push(item)
          }
        })
      }
      this.tableLoading = false
    },
    // 分页操作
    paginationChanged(page) {
      this.pageInfo.currentPage = page.currentPageNum
      this.pageInfo.pageSize = page.pageSizeNum
      this.getConfigTable()
    },
    // 搜索
    titleSearch(v) {
      this.pageInfo.currentPage = 1
      this.pageInfo.pageSize = 10
      this.getConfigTable(v)
    },
    back() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.resources {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth}  + 10px);
  }
}
.MainContainerHeight {
  height: calc(100% - 70px) !important;
  margin-bottom: 0px !important;
}
// 动画
@keyframes cllosed {
  from {width: calc(100% - 220px);}
  to {width: calc(100% - 74px);}
}
@keyframes open {
  from {width: calc(100% - 74px);}
  to {width: calc(100% - 220px);}
}
.resources-container {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  position: relative;
  .mianbao {
    position: absolute;
    left: 25px;
    top: 0;
    height: 40px;
    padding-left: 0;
  }
  // 动画
  .colsed {
    animation: cllosed 0.3s linear forwards;
    animation-direction: alternate;
   }
  .open {
    animation: open 0.3s linear forwards;
    animation-direction: alternate;
  }
  .resources-main-container {
    height: calc(100vh - 127px);
    color: aliceblue;

    .TitleSearch {
      margin-bottom: 10px;
    }
    .MainContainer {
      height: calc((100% - 80px) / 2);
      margin-bottom: 10px;
    }
    .FooterDetail {
      height: calc((100% - 80px) / 2);
    }
  }
}
</style>
