/*
 * @Author: 张通
 * @Date: 2020-09-23 16:00:48
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-21 17:06:00
 * @Description: file content
 */
export default {
  data() {
    return {
      mixins_EVENT: [
        {
          id: 'eventNo',
          name: this.$t('resources.eventNo')
        },
        {
          id: 'eventInfo',
          name: this.$t('resources.eventInfo')
        },
        {
          id: 'eventSt',
          name: this.$t('resources.eventSt')
        },
        {
          id: 'eventResult',
          name: this.$t('resources.eventResult')
        }
      ],
      mixins_GIVE: [
        {
          name: this.$t('alarm.alarmSeverity'),
          id: 'alarmSeverityLabel',
          customize: true
        },
        {
          name: this.$t('alarm.alarmName'),
          id: 'alarmName'
        },
        {
          name: this.$t('alarm.resourceName'),
          id: 'instanceName',
          // customize: true,
          type: 'detail'
        },
        {
          name: this.$t('alarm.resources') + 'ID',
          id: 'instanceId'
        },
        {
          name: this.$t('alarm.type'),
          id: 'typeLabel'
        },
        {
          name: this.$t('alarm.alarmCategory'),
          id: 'alarmCategoryLabel'
        },
        {
          name: this.$t('alarm.firstTime'),
          id: 'alarmStLabel'
        },
        {
          name: this.$t('alarm.lastTime'),
          id: 'alarmEtLabel'
        },
        {
          name: this.$t('alarm.alarmSerialNumber'),
          id: 'serialNo',
          hideInTable: true
        },
        {
          name: this.$t('alarm.alarm') + 'ID',
          id: 'alarmId',
          hideInTable: true
        },
        {
          name: this.$t('alarm.ns'),
          id: 'ns',
          hideInTable: true
        },

        {
          name: this.$t('alarm.alarmClearTime'),
          id: 'alarmCtLabel',
          hideInTable: true
        },
        {
          name: this.$t('alarm.alarmStatus'),
          id: 'alarmStatusLabel',
          hideInTable: true
        },
        {
          name: this.$t('alarm.alarmFrequency'),
          id: 'alarmCount',
          hideInTable: true
        },
        {
          name: this.$t('alarm.alarmClearType'),
          id: 'alarmCTypeLabel',
          hideInTable: true
        },
        {
          name: this.$t('alarm.tenant'),
          id: 'tenantId',
          hideInTable: true
        }
        // {
        //   id: 'alarmName',
        //   name: this.$t('resources.alarmName')
        // },
        // {
        //   id: 'alarmSeverityLabel',
        //   name: this.$t('resources.alarmSeverity')
        // },
        // {
        //   id: 'alarmCategoryLabel',
        //   name: this.$t('resources.alarmCategory')
        // },
        // {
        //   id: 'alarmCount',
        //   name: this.$t('resources.alarmCount')
        // },
        // {
        //   id: 'alarmSt',
        //   name: this.$t('resources.alarmSt')
        // },
        // {
        //   id: 'alarmCauseTxt',
        //   name: this.$t('resources.alarmCauseTxt')
        // },
        // {
        //   id: 'alarmEffectBusiness',
        //   name: this.$t('resources.alarmEffectBusiness')
        // },
        // {
        //   id: 'alarmRepairTxt',
        //   name: this.$t('resources.alarmRepairTxt')
        // }
      ]
    }
  },
  methods: {
    getTbaleHeaderConfig(config) {
      if (config) {
        switch (config) {
          case 'event':
            return this.mixins_EVENT
          case 'give':
            return this.mixins_GIVE
        }
      } else {
        return []
      }
    }
  }
}
