/*
 * @Author: 张通
 * @Date: 2020-09-23 16:00:48
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-22 14:35:21
 * @Description: file content
 */
export default {
  data() {
    return {
      mixins_MOINTOR: [
        {
          searchType: 'select',
          searchCondition: true,
          name: this.$t('resources.alarmName'),
          id: 'alarmId', // 告警ID
          option: [
            {
              value: '1',
              label: '赵信'
            },
            {
              value: '2',
              label: '盖伦'
            }
          ]
        },
        {
          searchType: 'select',
          id: 'timeType',
          name: this.$t('alarm.timeToType'),
          searchCondition: true,
          option: [
            {
              value: '1',
              label: this.$t('resources.alarmOccurredForFirstTime')
            },
            {
              value: '2',
              label: this.$t('alarm.alarmLastTime')
            },
            {
              value: '3',
              label: this.$t('alarm.alarmClearTime')
            }
          ]
        },
        {
          searchType: 'rangeDate',
          searchCondition: true
        }
      ],

      mixins_DATE: [
        {
          searchType: 'rangeDate',
          searchCondition: true
        }
      ],
      mixins_EVENT: [
        {
          searchType: 'select',
          searchCondition: true,
          name: this.$t('resources.handleResult'),
          id: 'eventResult',
          option: [
            {
              value: '0',
              label: this.$t('resources.YES')
            },
            {
              value: '1',
              label: this.$t('resources.NO')
            }
          ]
        },
        {
          searchType: 'rangeDate',
          searchCondition: true
        }
      ]
    }
  },
  methods: {
    getSearchConfig(config) {
      if (config) {
        switch (config) {
          case '5':
            return this.mixins_MOINTOR
          case '6':
            return this.mixins_DATE
          case '7':
            return this.mixins_DATE
          case '2':
            return this.mixins_EVENT
          case '3':
            return this.mixins_EVENT
        }
      } else {
        return []
      }
    }
  }
}
