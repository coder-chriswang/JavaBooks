<template>
  <div class="resources-container">
    <SiderBar v-if="!setTimeShowSidBar" :menu-list="menuList" @menu-active="menuActive" />
    <Breadcrumb :show-back="resourcesDetails" class="mianbao" :context="menuSelectedName" @handleBack="changeResourcesDetails(false)" />
    <titleRightButton :static-prop="staticButton" />
    <!-- 首页 -->
    <div v-if="!resourcesDetails" class="resources-main-container" :class="{colsed: !sidebar.opened, open: sidebar.opened}">
      <TitleSearch :key="menuId" :search-data="searchData" class="TitleSearch" @search="titleSearch" />
      <MainContainer
        v-loading="tableLoading"
        :table-loading="tableLoading"
        :element-loading-text="$t('public.loading')"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        :table-header="header"
        :table-data="MainContainer.tableData"
        :total="MainContainer.total"
        :current-page="pageInfo.currentPage"
        :page-size="pageInfo.pageSize"
        class="MainContainer resources-card-bac-pad"
        :class="{MainContainerHeight: !isShowFooterDetails}"
        :instance-but="instanceButton"
        @handlerOperation="handlerOperation"
        @pagination-changed="paginationChanged"
      />
      <FooterDetail v-show="isShowFooterDetails" ref="footerDetail" class="FooterDetail resources-card-bac-pad" />
    </div>
    <!-- 详情页 -->
  </div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from 'vuex'
import http from '@/api/resource'
import SiderBar from '@/components/Sidebar/Sidebar'
import MainContainer from './details/MainContainer'
import TitleSearch from '../../components/TitleSearch/TitleSearch'
import FooterDetail from './details/FooterDetail'
import Breadcrumb from '@/components/Breadcrumb/Breadcrumb'
import titleRightButton from '@/components/TitleRightButton/titleRightButton'
// import SiderBar from './details/components/SiderBar'
export default {
  name: 'Resources',
  components: {
    SiderBar,
    MainContainer,
    TitleSearch,
    FooterDetail,
    Breadcrumb,
    titleRightButton
  },
  beforeRouteLeave(to, from, next) {
    this.changeFooterDetails(false)
    this.changeResourcesDetails(false)
    this.changeShowTitleSearch(false)
    this.changeSelectedNum(false)
    next()
  },
  data() {
    return {
      searchDataConfig: null,
      pageInfo: {
        currentPage: 1,
        pageSize: 10
      },
      menuList: [],
      menuId: '1',
      // 是否显示footer组件
      MainContainer: {
        tableData: [],
        tableHeader: [],
        total: 0
      },
      lazyRender: false,
      // 头部搜索框
      searchData: [],
      // 表头
      header: [],
      // 页面加载时首先不加载此组件  当 配置接口请求成功后 才加载此组件  并且调用table接口
      setTimeShowSidBar: true,
      // 面包屑内容
      menuSelectedName: '',
      tableLoading: true,
      // 静态按钮
      staticButton: [],
      // 实例按钮
      instanceButton: {
        start: [],
        more: []
      }

    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'isShowFooterDetails', // 控制资源页面footer是否显示
      'resourcesDetails', // 控制是否跳转至详情页
      'showTitleSearch', // 是否显示titlesearch
      'tableRow', // 选中某行
      'requestType'
    ]),
    detailFooterHeight() {
      if (this.showTitleSearch) {
        return `calc(100% - 70px)`
      } else {
        return '100%'
      }
    },
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {

  },
  mounted() {
    this.getRouter()
  },
  methods: {
    ...mapActions([
      'changeFooterDetails',
      'changeResourcesDetails',
      'changeSelectedNum',
      'changeShowTitleSearch',
      'setRequestType'
    ]),
    // 左边路由信息
    getRouter() {
      this.getFirstPageRouter()
    },
    getFirstPageRouter() {
      this.menuList = [
        {
          label: this.$t('sidebar.config'),
          icon: 'icon-peizhi',
          isActive: true,
          display: false,
          id: '1',
          children: []
        },
        {
          label: this.$t('sidebar.see'),
          icon: 'icon-yunwei',
          isActive: false,
          id: '2',
          children: []
        }
      ]
      Promise.all([http.getConfigMenu(), http.getsee()]).then(res => {
        if (res[0] && res[0].code === 200) {
          this.getConfigMenu(res[0].data)
        }
        if (res[1] && res[1].code === 200) {
          this.getSeeMenu(res[1].data)
        }
        this.menuList = this.menuList.reverse()
        if (!this.setTimeShowSidBar) {
          // 返回时查询table
          this.getConfigTable()
          this.getNameByIdInObjArr(this.menuList, this.menuId)
        }
        // 渲染sidBar 查询数据
        this.setTimeShowSidBar = false
      })
    },
    // get 配置接口
    getConfigMenu(result) {
      const that = this
      that.menuList[0].children = []
      if (result.length > 0) {
        for (const item of result) {
          if (item && item.display) {
            that.menuList[0].children.push({
              label: item.name,
              isActive: false,
              id: `${item.category}/${item.ci}/${item.ns}`,
              category: item.category,
              ci: item.ci,
              ns: item.ns
            })
          }
        }
      }

      that.menuId = that.menuList[0].children[0].id
      const mm = that.menuList[0].children[0]
      // 初始化界面时需要的数据
      that.setRequestType({
        category: mm.category,
        ci: mm.ci,
        ns: mm.ns
      })
    },
    // get 查看接口
    getSeeMenu(result) {
      const arr = result
      this.menuList[1].children = []
      this.getMen(arr)
      this.menuList[1].children = arr
    },
    getMen(result) {
      result.length > 0 && result.forEach(item => {
        if (item.id === 'Instance') { // 全网
          item.leaf = true
        }
        if (item.children && item.children.length > 0) {
          return this.getMen(item.children)
        }
        item.data = {}
        item.method = 'get'
        item.url = `/cm/v1/resource/tag?targetId=${item.tagid}`
        item.id = `--${item.id}`
        item.children = []
        item.needActive = true
        item.label = item.name
        item.isActive = false
        item.display = item.display || true
      })
    },
    // 面包屑递归查找
    getNameByIdInObjArr(arr, id) {
      arr.forEach(v => {
        if (id === v.id) {
          this.menuSelectedName = v.label
        }
        if (v.children && v.children.length > 0) {
          this.getNameByIdInObjArr(v.children, id)
        }
      })
    },

    // 点击侧边栏
    menuActive(val) {
      // set面包屑
      this.getNameByIdInObjArr(this.menuList, val.menuId)
      // 隐藏footer页签
      this.changeFooterDetails(false)
      // 首页
      this.menuId = val.menuId
      if (val.menuId.includes('/')) {
        this.setRequestType({
          category: val.menuId.split('/')[0],
          ci: val.menuId.split('/')[1],
          ns: val.menuId.split('/')[2]
        })
      } else {
        this.setRequestType({
          category: val.item.children ? val.item.children[0].category : val.item.category,
          ci: val.item.children ? val.item.children[0].ci : val.item.ci,
          ns: val.item.children ? val.item.children[0].ns : val.item.ns,
          id: val.item.children ? val.item.children[0].id : val.item.id
        })
      }
      this.pageInfo.currentPage = 1
      this.pageInfo.pageSize = 10
      // table 查询
      this.getConfigTable()
    },
    // 分拣数据为静态button 或者是 实例button
    setStaticButton(ac) {
      const instanceBut = []
      const that = this
      this.staticButton = []
      this.instanceButton = {
        start: [],
        more: []
      }
      const action = ac.data.actions
      if (action.length > 0) {
        action.forEach(item => {
          if (item.domain === 'Static' && item.display) {
            this.staticButton.push(item)
          } else if (item.domain === 'Instance' && item.display) {
            instanceBut.push(item)
          }
        })
        if (instanceBut.length > 2) {
          that.instanceButton.start = instanceBut.splice(0, 2)
          that.instanceButton.more = instanceBut
        } else {
          that.instanceButton.start = instanceBut
        }
      }
    },
    // table 数据
    async getConfigTable(searchData = {}) {
      const that = this
      this.tableLoading = true
      const resHeader = await http.getConfigTableHeader({
        category: that.requestType.category,
        ci: that.requestType.ci
      })
      if (!resHeader || resHeader.data === null) {
        this.tableLoading = false
        return
      }
      this.setStaticButton(resHeader)
      const resTableData = await http.getTableData({
        action: 'Query',
        ci: that.requestType.ci,
        ns: that.requestType.ns,
        pageSize: that.pageInfo.pageSize,
        pageNum: that.pageInfo.currentPage,
        data: {
          ...searchData
        }
      })
      if (!resTableData || resTableData.data === null) {
        this.tableLoading = false
        return
      }
      this.MainContainer = {
        tableData: resTableData.data.list,
        total: resTableData.data.total,
        tableHeader: resHeader.data.attrs
      }
      // 条件选择渲染
      if (this.MainContainer.tableHeader.length > 0) {
        this.searchData = []
        this.header = []
        this.MainContainer.tableHeader.forEach(item => {
          if (item.searchCondition && item.display) {
            this.searchData.push(item)
          }
          if (item.display) {
            this.header.push(item)
          }
        })
      }
      this.tableLoading = false
    },
    // 表格操作 return 显示详情页或者footer页
    handlerOperation(v) {
      if (v === 'details') {
        this.$router.push({
          path: '/resources/detail',
          query: {
            ci: this.requestType.id === 'Instance' ? this.tableRow.type : this.requestType.ci,
            ns: this.requestType.ns,
            instanceid: this.tableRow.instanceid
          }
        })
      } else {
        this.$nextTick(() => {
          // if (this.isShowFooterDetails) {
          this.$refs['footerDetail'].getSelect()
          // }
        })
      }
    },
    // 分页操作
    paginationChanged(page) {
      this.pageInfo.currentPage = page.currentPageNum
      this.pageInfo.pageSize = page.pageSizeNum
      this.getConfigTable(this.searchDataConfig)
    },
    // 搜索
    titleSearch(v) {
      this.pageInfo.currentPage = 1
      this.pageInfo.pageSize = 10
      this.searchDataConfig = { ...v }
      this.getConfigTable(v)
    }
  }
}

</script>

<style lang="scss" scoped>
  @import '../../styles/variables.scss';

  .resources {
    &-container {
      margin: 10px;
    }

    &-text {
      font-size: 30px;
      line-height: 46px;
      margin-left: calc(#{$sideBarWidth} + 10px);
    }
  }

  .MainContainerHeight {
    height: calc(100% - 70px) !important;
    margin-bottom: 0px !important;
  }

  // 动画
  @keyframes cllosed {
    from {
      width: calc(100% - 220px);
    }

    to {
      width: calc(100% - 74px);
    }
  }

  @keyframes open {
    from {
      width: calc(100% - 74px);
    }

    to {
      width: calc(100% - 220px);
    }
  }

  .resources-container {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    position: relative;

    .mianbao {
      position: absolute;
      left: 25px;
      top: 0;
      height: 40px;
      padding-left: 0;
    }

    // 动画
    .colsed {
      animation: cllosed 0.3s linear forwards;
      animation-direction: alternate;
    }

    .open {
      animation: open 0.3s linear forwards;
      animation-direction: alternate;
    }

    .resources-main-container {
      height: calc(100vh - 127px);
      color: aliceblue;

      .TitleSearch {
        margin-bottom: 10px;
      }

      .MainContainer {
        height: calc((100% - 80px) / 2);
        margin-bottom: 10px;
      }

      .FooterDetail {
        height: calc((100% - 80px) / 2);
      }
    }
  }

</style>
