<!--
 * @Author: 张通
 * @Date: 2020-09-14 14:24:47
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-27 17:13:29
 * @Description: file content
-->

<template>
  <div class="MainContainer">
    <Table
      v-if="!tableLoading"
      :table-data="tableData"
      :table-header="tableHeader"
      :total="total"
      :current-page="currentPage"
      :page-size="pageSize"
      :last-column-width="`200`"
      @pagination-change="paginationChange"
      @handler-row="handlerRow"
    >
      <template slot-scope="scope">
        <el-button v-for="(item,index) in instanceBut.start" :key="`--${index}`" class="table-text-btn" type="text" @click="handleCommand({ row: scope.scope.row,item: item})">{{ item.name }}</el-button>
        <el-dropdown v-if="instanceBut.more.length > 0" @command="handleCommand">
          <span class="el-dropdown-link">
            {{ $t('public.more') }}<i class="el-icon-arrow-down el-icon--right" />
          </span>
          <el-dropdown-menu slot="dropdown" class="dropdown-menu">
            <el-dropdown-item v-for="(item,index) in instanceBut.more" :key="`==${index}`" :command="{ row: scope.scope.row,item: item}">{{ item.name }}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </template>
    </Table>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import Table from '../../../components/Table/Table'
export default {
  components: {
    Table
  },
  props: {
    tableData: {
      type: Array,
      default: () => []
    },
    tableHeader: {
      type: Array,
      default: () => []
    },
    total: {
      type: Number,
      default: () => 0
    },
    currentPage: {
      type: Number,
      default: () => 0
    },
    pageSize: {
      type: Number,
      default: () => 10
    },
    // 实例按钮
    instanceBut: {
      type: Object,
      default: () => {
        return {
          all: [],
          start: [],
          more: []
        }
      }
    },
    tableLoading: {
      type: Boolean,
      default: () => true
    }
  },
  data() {
    return {
      ins: []
    }
  },
  computed: {
    ...mapGetters([
      'tableRow'
    ])
    // more() {
    //   if (this.instanceBut.length > 2) {
    //     debugger
    //     // eslint-disable-next-line vue/no-side-effects-in-computed-properties
    //     return this.instanceBut.splice(2)
    //   } else {
    //     return []
    //   }
    // },
    // stat() {
    //   // eslint-disable-next-line vue/no-side-effects-in-computed-properties
    //   return this.instanceBut.splice(0, 2)
    // }
  },
  methods: {
    ...mapActions([
      'setTableRow',
      'changeFooterDetails'
    ]),
    paginationChange(page) {
      this.changeFooterDetails(false)
      this.$emit('pagination-changed', page)
    },
    handleFotter(v) {

    },
    handlerRow(row, column) {
      // 判断是否点击最后一列
      if (column.fixed !== 'right') {
        this.setTableRow(row)
        // this.changeFooterDetails(true)
        this.$emit('handlerOperation')
      }
    },
    // 点击表格操作列按钮事件
    handleCommand(val) {
      // this.$message(val.item.layOut)
      if (val.item.id === 'Get') { // 查看详情
        this.setTableRow(val.row)
        this.$emit('handlerOperation', 'details')
      }
    }
  }
}
</script>

<style lang="scss">
</style>
