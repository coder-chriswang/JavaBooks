<!--
 * @Author: 张通
 * @Date: 2020-09-15 19:07:28
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-14 15:31:38
 * @Description: file content
-->
<template>
  <div id="GDMap" />
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  props: {

  },
  data() {
    return {
      GDMap: {}
    }
  },
  computed: {
    ...mapGetters(['language'])
  },
  watch: {
    language(v) {
      this.GDMap.setLang(this.GDMapLang(v))
    }
  },
  mounted() {
    // this.initMap(this.language)
  },
  methods: {
    GDMapLang(lang) {
      if (lang === 'zh') return 'zh_cn'
      if (lang === 'en') return 'en'
      return 'zh_en'
    },

    // 覆盖物
    cover(pathContainer) {
      this.remove()
      // var path = [
      //   [108.624585, 33.797965],
      //   [108.300488, 34.972049],
      //   [109.679273, 34.144189],
      //   [109.997876, 34.994552]
      // ]
      var polyline = new AMap.Polyline({
        path: pathContainer,
        ...this.lineStyle()
      })
      // 添加标注物
      // this.GDMap.add(polyline)
      polyline.setMap(this.GDMap)
      // 缩放地图到合适的视野级别
      this.GDMap.setFitView([polyline])
    },
    // 坐标转换
    coordinate() {

    },
    initMap(lang, pathContainer) {
      this.GDMap = new AMap.Map('GDMap', {
        resizeEnable: true,
        center: [108.94748, 34.270964], // 地图中心
        zoom: 6 // 地图缩放级别
      })
      this.GDMap.setLang(this.GDMapLang(lang))
      this.cover(pathContainer)
    },
    // 覆盖物移除
    remove() {
      this.GDMap.clearMap()
    },
    // 覆盖物线样式
    lineStyle() {
      return {
        isOutline: true,
        outlineColor: '#ffeeff',
        borderWeight: 3,
        strokeColor: '#3366FF',
        strokeOpacity: 1,
        strokeWeight: 6,
        // 折线样式还支持 'dashed'
        strokeStyle: 'solid',
        // strokeStyle是dashed时有效
        strokeDasharray: [10, 5],
        lineJoin: 'round',
        lineCap: 'round',
        zIndex: 50
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  #GDMap {
    width: 100%;
    height: 100%;
  }
</style>
