<!--
 * @Author: 张通
 * @Date: 2020-09-15 19:07:28
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-20 10:09:00
 * @Description: file content
-->
<template>
  <el-row v-if="chartOptions.length > 0" class="Monitor">
    <el-col v-for="(item,index) in chartOptions" :key="`chart${index}`" :span="6" :style="{height: colHight }">
      <Chart :id="''+index" :options-data="item" :side-bar-opend="sidebar.opened" />
    </el-col>
  </el-row>
  <div v-else class="no-data-available" />
</template>
<script>
import { mapGetters } from 'vuex'
import Chart from '../../../components/Chart/Chart'
// import { getChartOptions } from '@/utils/getChartOptions'
export default {
  components: {
    Chart
  },
  props: {
    // colHight: {
    //   type: String,
    //   default: () => '100%'
    // }
    chartOptions: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      // chartOptions: []
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'resourcesDetails'
    ]),
    colHight() {
      if (this.resourcesDetails) {
        return '33.333333%'
      } else {
        return '100%'
      }
    }
  },
  mounted() {
    // import('./mock.json').then(res => {
    //   let a = 1
    //   while (a < 10) {
    //     a++
    //     this.chartOptions.push({
    //       type: 'chart',
    //       options: getChartOptions(res.lineChartData)
    //     })
    //   }
    // })
  }
}
</script>
<style lang="scss" scoped>
  .Monitor {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    .el-row {
      padding: 0;
    }
    .el-col {
      // padding-bottom: 10px;
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      div {
        height: 95%;
        width: 95% !important;
        background-image: url('../../../assets/chartbox.png');
        background-repeat: round;
        padding: 10px 10px 20px;
      }
    }
  }
</style>
