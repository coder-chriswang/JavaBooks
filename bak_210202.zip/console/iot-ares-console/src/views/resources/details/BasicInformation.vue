<!--
 * @Author: 张通
 * @Date: 2020-09-15 19:07:28
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-27 15:19:05
 * @Description: file content
-->
<template>
  <el-row class="BasicInformation">
    <el-col :span="colSpanOne" :style="{height: colHightOne }">
      <BasInfor :bash-info="basics" :title="$t('resources.basicInfo')" />
    </el-col>
    <!-- <el-col :span="colSpan" :style="{height: colHight }">
      <BasInfor :bash-info="configure" :title="$t('resources.configInfo')" />
    </el-col> -->
    <el-col :span="colSpanTwo" :style="{height: colHightTwo }">
      <BasInfor :col-hight="chartHight" :chart-options="chartOptions" :title="$t('resources.statusInfo')" :view-type="false" />
    </el-col>
  </el-row>
</template>
<script>
import { mapGetters } from 'vuex'
import BasInfor from './BasInfor'
import { getChartOptions } from '@/utils/getChartOptions'
export default {
  components: {
    BasInfor
  },
  props: {
    basArr: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    ...mapGetters([
      'resourcesDetails'
    ]),
    chartOptions() {
      const arr = []
      if (this.basArr[2] && this.basArr[2].code === 200 && this.basArr[2].data !== null && this.basArr[2].data.length > 0) {
        this.basArr[2].data.forEach(item => {
          const a = {
            chartType: 'gauge',
            chartTitle: item.metric_name,
            data: [{
              name: item.metric_name,
              value: item.metric_value,
              unit: item.metric_unit,
              min: 0,
              max: 220,
              splitNumber: 11
            }]
          }
          arr.push(
            {
              type: 'chart',
              options: getChartOptions(a)
            }
          )
        })
      }
      return arr
    },
    basics() {
      if (this.basArr[0] && this.basArr[0].code === 200 && this.basArr[0].data !== null && this.basArr[1] && this.basArr[1].code === 200 && this.basArr[1].data !== null) {
        return [...this.basArr[0].data, ...this.basArr[1].data]
      } else if (this.basArr[0] && this.basArr[0].code === 200 && this.basArr[0].data !== null) {
        return this.basArr[0].data
      } else if (this.basArr[1] && this.basArr[1].code === 200 && this.basArr[1].data !== null) {
        return this.basArr[1].data
      } else {
        return []
      }
    },
    colSpanOne() {
      if (this.resourcesDetails) {
        return 24
      } else {
        return 8
      }
    },
    colSpanTwo() {
      if (this.resourcesDetails) {
        return 24
      } else {
        return 16
      }
    },
    colHightOne() {
      if (this.resourcesDetails) {
        return '33.333333%'
      } else {
        return '100%'
      }
    },
    colHightTwo() {
      if (this.resourcesDetails) {
        return '66.666666%'
      } else {
        return '100%'
      }
    },
    chartHight() {
      if (this.resourcesDetails) {
        return '50%'
      } else {
        return '100%'
      }
    }
    // colSpan() {
    //   if (this.resourcesDetails) {
    //     return 24
    //   } else {
    //     return 8
    //   }
    // }

  }
}
</script>
<style lang="scss" scoped>
  .BasicInformation {
    height: 100%;
    width: 100%;
  }
</style>
