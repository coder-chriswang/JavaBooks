<!--
 * @Author: 张通
 * @Date: 2020-09-16 16:59:35
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-27 15:30:09
 * @Description: 基础信息子组件
-->
<template>
  <div class="BasInfor">
    <header>{{ title }}</header>
    <!-- 表格 -->
    <el-row v-if="viewType" class="footer">
      <!-- 暂无数据 -->
      <el-col v-if="bashInfo.length === 0" class="footer-chart no-data-available" :span="colChartSpan" :style="{height: '100%' }" />

      <el-form v-else label-position="right" label-width="40%">
        <el-col v-for="(item,index) in bashInfo" :key="`bash${index}`" :span="colFormSpan">
          <el-form-item :label="`${item.label}:`">
            <strong class="strong">{{ item.value }}</strong>
          </el-form-item>
        </el-col>
      </el-form>
    </el-row>
    <!-- chart -->
    <el-row v-else class="footer">
      <!-- 暂无数据 -->
      <el-col v-if="chartOptions.length === 0" class="footer-chart no-data-available" :span="colChartSpan" :style="{height: '100%' }" />

      <el-col v-for="(item,index) in chartOptions" v-else :key="`chart${index}`" class="footer-chart" :span="colChartSpan" :style="{height: colHight }">
        <Chart :id="''+index" :options-data="item" :side-bar-opend="sidebar.opened" />
      </el-col>
    </el-row>

  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Chart from '../../../components/Chart/Chart'

export default {
  components: {
    Chart
  },
  props: {
    title: {
      type: String,
      default: () => this.$t('sidebar.basicInfo')
    },
    colHight: {
      type: String,
      default: () => '100%'
    },
    viewType: {
      type: Boolean,
      default: () => true
    },
    chartOptions: {
      type: Array,
      default: () => []
    },
    bashInfo: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      // chartOptions: [],
      // bashInfo: []
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'resourcesDetails'
    ]),
    colFormSpan() {
      if (this.resourcesDetails) {
        return 4
      } else {
        return 12
      }
    },
    colChartSpan() {
      if (this.resourcesDetails) {
        return 3
      } else {
        return 4
      }
    }
  },
  mounted() {
  }
}
</script>
<style lang="scss" scoped>
  .BasInfor {
    width: 100%;
    height: 100%;
    padding: 10px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    header {
      height: 40px;
      width: 100%;
      background: #192e6f;
      display: flex;
      align-items: center;
      padding-left: 15px;
    }
    .footer {
      height: calc(100% - 55px);
      width: 100%;
      overflow-y: auto;
      .strong {
        display: inline-block;
        word-break: break-all;
      }
      .footer-chart {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        div {
          height: 95%;
          width: 95% !important;
          // background-image: url('../../../assets/chartbox.png');
          background-repeat: round;
          padding: 20px 10px 20px;
        }
      }
    }
  }
</style>
<style lang="scss">
  .BasInfor {
    .el-form-item__label {
      color: #fff;
    }
  }
</style>
