<!--
 * @Author: 张通
 * @Date: 2020-09-14 14:24:47
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-28 09:29:00
 * @Description: file content
-->

<template>
  <div class="FooterDetail">
    <header v-if="showHeader">
      <el-button
        v-for="(item, index) in headerTitle"
        :key="index"
        size="small"
        :class="{buttonCheckedStyle: selectedNum == item.id}"
        @click="handlerButton(item)"
      >{{ item.label }}</el-button>
    </header>
    <footer
      v-loading="footerLoading"
      :element-loading-text="$t('public.loading')"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :style="{height: footerHeight}"
    >

      <!-- 基础信息 -->
      <BasicInformation
        v-if="selectedNum == 1 && !footerLoading"
        :bas-arr="basicInfo"
      />
      <!-- 下行操作 -->
      <Table
        v-if="selectedNum == 2 && !footerLoading"
        :table-data="tableData"
        :table-header="tableHeader"
        :total="total"
        :last-table-column="false"
        :highlight-current-row="false"
        :cell-border-style="false"
        :page-size="pageConfig.pageSize"
        :current-page="pageConfig.pageNum"
        @pagination-change="paginationChange"
      />
      <!-- 上行操作 -->
      <Table
        v-if="selectedNum == 3 && !footerLoading"
        :table-data="tableData"
        :table-header="tableHeader"
        :total="total"
        :last-table-column="false"
        :highlight-current-row="false"
        :cell-border-style="false"
        :page-size="pageConfig.pageSize"
        :current-page="pageConfig.pageNum"
        @pagination-change="paginationChange"
      />
      <!-- 拓扑 -->
      <div v-if="selectedNum == 4">{{ $t('resources.topology') }}</div>
      <!-- 告警 -->
      <Table
        v-if="selectedNum == 5 && !footerLoading"
        :table-data="tableData"
        :table-header="tableHeader"
        :total="total"
        :last-table-column="false"
        :highlight-current-row="false"
        :cell-border-style="false"
        :page-size="pageConfig.pageSize"
        :current-page="pageConfig.pageNum"
        @pagination-change="paginationChange"
      >
        <template slot="alarmSeverityLabel" slot-scope="scope">
          <span class="iconfont icon-alarm help" :style="{color:alarmColorMap[scope.scope.row.alarmSeverity]}" />&nbsp;&nbsp;{{ scope.scope.row.alarmSeverityLabel }}
        </template>
      </Table>
      <!-- 监控 -->
      <Monitor v-if="selectedNum == 6 && PositionTrack" :chart-options="monitorData" />
      <!-- 位置轨迹 -->
      <PositionTrack v-if="selectedNum == 7 " ref="PositionTrack" :is-buit-in="true" />
      <!-- 暂无数据标识 -->
      <div v-if="!selectedNum" class="no-data-available" />
    </footer>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import Table from '../../../components/Table/Table'
import BasicInformation from './BasicInformation'
import Monitor from './Monitor'
import PositionTrack from './PositionTrack'
import http from '@/api/resource'
import getTbaleHeaderConfig from '../mixin/tableHeaderConfig'
import { getChartOptions } from '@/utils/getChartOptions'
export default {
  components: {
    Table,
    BasicInformation,
    Monitor,
    PositionTrack
  },
  mixins: [getTbaleHeaderConfig],
  props: {
    // tableData: {
    //   type: Array,
    //   default: () => []
    // },
    // tableHeader: {
    //   type: Array,
    //   default: () => []
    // },
    showHeader: {
      type: Boolean,
      default: () => true
    }
  },
  data() {
    return {
      alarmColorMap: {
        4: '#ff0000',
        3: '#fe7506',
        2: '#fced02',
        1: '#fcf4cf'
      },
      footerBtnMap: {
        '1': this.$t('resources.basicInfo'),
        '2': this.$t('sidebar.downAction'),
        '3': this.$t('sidebar.upAction'),
        '4': this.$t('sidebar.topology'),
        '5': this.$t('alarm.alarm'),
        '6': this.$t('sidebar.monitor'),
        '7': this.$t('sidebar.positionTrack')
      },
      headerTitle: [],
      tableData: [],
      tableHeader: [],
      // 基础信息
      basicInfo: [],
      // selectedNum: 1
      footerLoading: true,
      pageConfig: {
        pageNum: 1,
        pageSize: 10
      },
      total: 0,
      eventType: null,
      monitorData: [],
      PositionTrack: false
    }
  },
  computed: {
    ...mapGetters([
      'selectedNum',
      'tableRow',
      'requestType',
      'language'
    ]),
    footerHeight() {
      if (this.showHeader) {
        return 'calc(100% - 40px)'
      } else {
        return '100%'
      }
    }
  },
  mounted() {

  },
  methods: {
    ...mapActions([
      'changeSelectedNum',
      'changeFooterDetails'
    ]),
    handlerButton(item) {
      this.changeSelectedNum(item.id) // 设置选中那一项
      this.getDetail()
    },
    // 获取Tab页签
    getSelect(v) {
      const that = this
      that.tableRow
      const a = {
        ci: this.requestType.ci,
        ns: this.requestType.ns
      }
      if (this.requestType.id === 'Instance') {
        a.ci = this.tableRow.type
      }
      http.getTab(a).then(res => {
        if (res && res.code === 200) {
          if (res.data.length > 0) {
            this.changeFooterDetails(true)
          } else {
            this.changeFooterDetails(false)
            // this.$message({
            //   message: '接口无数据返回',
            //   type: 'warning'
            // })
          }
          this.headerTitle = res.data
          if (this.headerTitle !== null && this.headerTitle.length > 0) {
            this.headerTitle.forEach(item => {
              item.id = item.om
              // item.label = item.name
              item.label = this.footerBtnMap[item.om]
            })

            this.changeSelectedNum(this.headerTitle[0].id)
            this.getDetail()
          } else {
            this.changeSelectedNum(null)
          }
        }
      })
    },
    getDetail(v = {}) {
      // const inf = { ...v }
      this.pageConfig.pageNum = 1
      this.pageConfig.pageSize = 10
      let d1
      let d2
      let d3
      this.footerLoading = true
      switch (this.selectedNum) { // vuex 里取得值
        case '1': // 基础信息
        // 基础信息
          d1 = {
            action: 'Get',
            ci: 'Instance',
            data: {
              instanceid: this.tableRow.instanceid
            },
            ns: 'ies'
          }
          // 配置信息
          d2 = {
            action: 'Get',
            ci: this.requestType.id === 'Instance' ? this.tableRow.type : this.requestType.ci,
            data: {
              instanceid: this.tableRow.instanceid
            },
            ns: 'ies'
          }
          // 仪表盘
          d3 = {
            instanceid: this.tableRow.instanceid
          }
          Promise.all([http.getSeeMenu(d1), http.getSeeMenu(d2), http.getBicStatus(d3)]).then(res => {
            this.basicInfo = res
            this.footerLoading = false
          })
          break
        case '2': // 下行操作事件
          this.eventType = 'Down'
          this.event(v)
          break
        case '3': // 上行操作事件
          this.eventType = 'Up'
          this.event(v)
          break
        case '4': // 拓扑
          this.footerLoading = false
          break
        case '5': // 告警
          this.give(v)
          break
        case '6': // 监控
          this.monitor(v)
          break
        case '7': // 位置轨迹
          this.positionTrack(v)
          break
        default:
          break
      }
    },
    // 删除没有实际值的字段
    setParam(obj) {
      Object.keys(obj).forEach(item => {
        if (!obj[item] || obj[item] === '') {
          delete obj[item]
        }
      })
      return obj
    },
    // 上下行操作事件
    async event(eventV) {
      this.tableHeader = this.getTbaleHeaderConfig('event')
      const info = {
        instanceId: this.tableRow.instanceid,
        pageNum: this.pageConfig.pageNum,
        pageSize: this.pageConfig.pageSize,
        direction: this.eventType,
        eventResult: eventV ? eventV.eventResult ? eventV.eventResult : '' : '',
        timeFrom: eventV ? eventV.startTime ? eventV.startTime : '' : '',
        timeTo: eventV ? eventV.endTime ? eventV.endTime : '' : ''
      }
      const res = await http.getEventHander(this.setParam(info))
      if (res && res.code === 200) {
        this.tableData = res.data.records
        this.tableData.length > 0 && this.tableData.forEach(item => {
          item.eventResult = `${item.eventResult}`
        })
        this.total = res.data.totalRecordCount
      } else {
        this.tableData = []
        this.total = 0
      }
      this.footerLoading = false
    },
    // 告警
    async give(giveV = {}) {
      this.tableHeader = this.getTbaleHeaderConfig('give')
      if (!giveV.timeType && giveV.startTime) {
        this.footerLoading = false
        return this.$message(this.$t('alarm.pleaseSelectATimeType'))
      }
      if (giveV.timeType && !giveV.startTime) {
        this.footerLoading = false
        return this.$message(this.$t('alarm.pleaseSelectATime'))
      }

      const info = {
        instanceId: this.tableRow.instanceid,
        pageNum: this.pageConfig.pageNum,
        pageSize: this.pageConfig.pageSize,
        alarmId: giveV ? giveV.alarmId ? giveV.alarmId : '' : '',
        from: giveV ? giveV.startTime ? giveV.startTime : '' : '',
        to: giveV ? giveV.endTime ? giveV.endTime : '' : '',
        timeType: giveV ? giveV.timeType ? giveV.timeType : '' : ''
      }
      const res = await http.getGive({ ...this.setParam(info),
        alarmStatus: 0 })
      if (res.code === 200) {
        this.tableData = res.data.records
        this.total = res.data.totalRecordCount
      } else {
        this.tableData = []
        this.total = 0
      }
      this.footerLoading = false
    },
    paginationChange(page) {
      this.pageConfig.pageNum = page.currentPageNum
      this.pageConfig.pageSize = page.pageSizeNum
      if (this.selectedNum === '5') { // 告警
        this.give()
      } else if (this.selectedNum === '2' || this.selectedNum === '3') {
        this.event()
      }
    },
    // 监控
    async monitor(monitorV) {
      console.log(this.requestType)
      this.PositionTrack = false
      // const et = Math.round(new Date().getTime() / 1000)
      // const st = et - 24 * 60 * 60
      const res_one = await http.getMonitor_one({
        ci: this.requestType.id === 'Instance' ? this.tableRow.type : this.requestType.ci
      })
      this.monitorData = res_one.data
      const arr = []
      this.monitorData && this.monitorData.forEach(item => {
        const queries = []
        item.data.legend.keyArr.forEach(code => {
          queries.push({
            aggregator: '',
            code: code, // KeyArr
            interval: 0
          })
        })
        arr.push(http.getMonitor_two({
          et: monitorV.endTime ? monitorV.endTime : '',
          instanceid: this.tableRow.instanceid,
          queries: queries,
          st: monitorV.startTime ? monitorV.startTime : ''
        }))
      })
      const that = this
      Promise.all(arr).then(res => {
        res && res.length > 0 && res.forEach((item, index) => {
          that.monitorData[index].data.xData = item.data.xData
          that.monitorData[index].data.yData = item.data.yData
        })
        const arr = []
        that.monitorData.forEach(item => {
          arr.push({
            type: 'chart',
            options: getChartOptions(item)
          })
        })
        that.monitorData = arr
        this.$nextTick(() => {
          that.PositionTrack = true
          that.footerLoading = false
        })
      })
    },
    // 位置轨迹
    async positionTrack(positionTrackV) {
      const pathContainer = []
      // const et = Math.round(new Date().getTime() / 1000)
      // const st = et - 24 * 60 * 60
      const res = await http.getPositionTrack({
        downInterval: 0,
        end: positionTrackV.endTime ? positionTrackV.endTime : '',
        instanceId: this.tableRow.instanceid,
        start: positionTrackV.startTime ? positionTrackV.startTime : ''
      })
      if (res.code === 200) {
        res.data && res.data.length > 0 && res.data.forEach(item => {
          pathContainer.push([item.lon, item.lat])
        })
        this.$nextTick(() => {
          this.$refs['PositionTrack'].initMap(this.language, pathContainer)
        })
        this.footerLoading = false
      }
    }
  }
}
</script>

<style lang="scss" scoped>

  .buttonCheckedStyle {
    background: #00aeef !important;
    color: #ffffff !important;
  }
  .FooterDetail {
    header {
      height: 40px;
      width: 100%;
      display: flex;
      flex-direction: row;
      align-items: flex-start;
    }
    footer {
      width: 100%;
    }
    .el-button--small, .el-button--small.is-round {
      background: #0e3b78;
      color: #00aeef;
      border: none;
    }
  }
</style>
