<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-18 14:55:57
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-23 15:33:50
 * @Description: file content
-->
<template>
  <div>
    <Table
      :table-data="tableData"
      :table-header="tableHeader"
      :total="0"
      class="table-class"
    >
      <template slot-scope="scope">
        <el-button size="mini" @click="handleFotter(scope)">Fotter</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="handleDetails(scope.$index, scope.row)"
        >Details</el-button>
      </template>
    </Table>
  </div>
</template>

<script>
import Table from '@/components/Table/Table'
export default {
  name: 'Task',
  components: {
    Table
  },
  data() {
    return {
      tableData: [],
      tableHeader: [
        {
          name: this.$t('system.product'),
          id: 'code'
        },
        {
          name: this.$t('system.mode'),
          id: 'code'
        },
        {
          name: this.$t('system.obj'),
          id: 'code'
        },
        {
          name: this.$t('system.objName'),
          id: 'code'
        },
        {
          name: this.$t('system.objDesc'),
          id: 'code'
        },
        {
          name: this.$t('system.storageTime'),
          id: 'code'
        },
        {
          name: this.$t('system.dumpFileFormat'),
          id: 'code'
        }
      ]
    }
  },
  created() {
    this.getTableData()
  },
  methods: {
    getTableData() {

    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .table-class {
    background: $darkBlue4;
    padding: 10px;
    height: calc(100vh - 126px);
  }
</style>
