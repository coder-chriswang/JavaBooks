<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-18 14:55:57
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-23 15:33:35
 * @Description: file content
-->
<template>
  <div>
    <TitleSearch :search-data="searchData" class="TitleSearch" @search="handleSearch" />
    <Table
      :table-data="tableData"
      :table-header="tableHeader"
      :total="0"
      class="table-class"
    >
      <template slot-scope="scope">
        <el-button size="mini" @click="handleFotter(scope)">Fotter</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="handleDetails(scope.$index, scope.row)"
        >Details</el-button>
      </template>
    </Table>
  </div>
</template>

<script>
import TitleSearch from '@/components/TitleSearch/TitleSearch'
import Table from '@/components/Table/Table'
export default {
  name: 'Operation',
  components: {
    TitleSearch,
    Table
  },
  data() {
    return {
      searchData: [
        {
          searchType: 'select',
          searchCondition: true,
          key: 'select',
          name: this.$t('system.operationUser'),
          option: []
        },
        {
          searchType: 'select',
          searchCondition: true,
          key: 'select',
          name: this.$t('system.result'),
          option: []
        },
        {
          searchType: 'rangeDate',
          searchCondition: true
        }
      ],
      tableData: [],
      tableHeader: [
        {
          name: this.$t('system.requestId'),
          id: 'code'
        },
        {
          name: this.$t('system.operationName'),
          id: 'code'
        },
        {
          name: this.$t('system.result'),
          id: 'code'
        },
        {
          name: this.$t('public.time'),
          id: 'code'
        },
        {
          name: this.$t('system.operationUser'),
          id: 'code'
        },
        {
          name: this.$t('system.clientIP'),
          id: 'code'
        }
      ]
    }
  },
  created() {
    this.getTableData()
  },
  methods: {
    getTableData() {

    },
    handleSearch(val) {
      console.log(val)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .TitleSearch{
    height: 60px;
    margin-bottom: 10px;
    background: $darkBlue4;
  }
  .table-class {
    background: $darkBlue4;
    padding: 10px;
    height: calc(100vh - 196px);
  }
</style>
