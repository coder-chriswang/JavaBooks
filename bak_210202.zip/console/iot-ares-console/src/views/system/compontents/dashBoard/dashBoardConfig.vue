<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-18 11:45:33
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-26 16:30:58
 * @Description: file content
-->
<template>
  <div class="dashboard-config-container">
    <div class="btn-div">
      <el-button type="primary" size="mini" @click="getTableData">{{ $t('public.refresh') }}</el-button>
      <el-button type="primary" size="mini" @click="handleAdd">{{ $t('public.add') }}</el-button>
    </div>
    <Table
      v-loading="loading"
      :table-data="tableData"
      :element-loading-text="$t('public.loading')"
      :table-header="tableHeader"
      :highlight-current-row="false"
      :current-page="currentPage"
      :total="total"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      class="table-class"
    >
      <template slot-scope="scope">
        <!-- 组件嵌套导致scope包了两层 -->
        <el-button type="text" class="table-text-btn" @click="handleDetail(scope.scope.row)">{{ $t('public.detail') }}</el-button>
        <el-button type="text" class="table-text-btn" @click="handleEdit(scope.scope.row)">{{ $t('public.edit') }}</el-button>
        <el-button type="text" class="table-text-btn" @click="handleDelete(scope.scope.row)">{{ $t('public.delete') }}</el-button>
      </template>
    </Table>
    <el-dialog
      :title="dialogTitle"
      :visible.sync="dialogVisible"
      :modal-append-to-body="false"
      width="50%"
    >
      <el-form label-width="25%" :model="formData">
        <el-form-item v-if="dialogType !== 'detail'" :label="$t('system.viewName')">
          <el-input v-model="formData.name" />
        </el-form-item>
        <el-form-item v-if="dialogType !== 'detail'" :label="$t('system.viewDesc')">
          <el-input v-model="formData.desc" />
        </el-form-item>
      </el-form>
      <div class="dialog-table">
        <Table
          ref="chartTable"
          :table-data="chartData"
          :table-header="chartTableHeader"
          :highlight-current-row="false"
          table-size="mini"
          :pagination="false"
          :show-selection="dialogType !== 'detail'"
          :last-table-column="false"
          :selection-row="selectionRow"
          @selection-change="handleSelect"
        />
      </div>
      <span v-if="dialogType !== 'detail'" slot="footer" class="dialog-footer">
        <el-button class="zt-button" @click="dialogVisible = false">{{ $t('public.cancel') }}</el-button>
        <el-button type="primary" @click="formSubmit">{{ $t('public.confirm') }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import Table from '@/components/Table/Table'
import {
  getViewsTableData,
  getChartTableData,
  addView,
  deleteView,
  updateView
} from '@/api/system'
export default {
  name: 'DashBoardConfig',
  components: {
    Table
  },
  data() {
    return {
      chartTypeMap: {
        Line: this.$t('public.line'),
        Gauge: this.$t('public.gauge'),
        Bar: this.$t('public.bar'),
        Table: this.$t('public.table'),
        Pie: this.$t('public.pie'),
        ringScreen: this.$t('public.ringScreen'),
        LiquidFill: this.$t('public.LiquidFill')
      },
      queryParam: {
        pageNum: 1,
        pageSize: 10
      },
      currentPage: 1,
      total: 0,
      tableData: [],
      tableHeader: [
        {
          name: this.$t('system.viewId'),
          id: 'code'
        },
        {
          name: this.$t('system.viewName'),
          id: 'name'
        },
        {
          name: this.$t('system.viewDesc'),
          id: 'desc'
        }
      ],
      chartData: [],
      chartTableHeader: [
        {
          name: this.$t('system.ChartTag'),
          id: 'chartid'
        },
        {
          name: this.$t('system.ChartName'),
          id: 'name'
        },
        {
          name: this.$t('system.ChartType'),
          id: 'typeLabel',
          width: '80'
        },
        {
          name: this.$t('system.ChartDesc'),
          id: 'desc'
        }
      ],
      chartTableTotal: 0,
      chartDataParams: {
        pageNum: 0,
        pageSize: 10
      },
      dialogVisible: false,
      dialogType: 'add',
      dialogTitle: '',
      selectionRow: [],
      formData: {
        chart: [],
        code: '',
        desc: '',
        name: ''
      },
      loading: false
    }
  },
  created() {
    this.getTableData()
  },
  methods: {
    getTableData() {
      this.loading = true
      getViewsTableData(this.queryParam).then((result) => {
        if (result.data.records && result.data.records.length > 0) {
          this.tableData = result.data.records
          this.currentPage = result.data.currentPage
          this.total = result.data.totalRecordCount
        } else {
          this.tableData = []
          this.currentPage = result.data.currentPage
          this.total = result.data.totalRecordCount
        }
        this.loading = false
      }).catch((err) => {
        console.log(err)
        this.loading = false
      })
    },
    getchartData(selectRow = []) {
      getChartTableData(this.chartDataParams).then((result) => {
        if (result.data.records && result.data.records.length > 0) {
          this.chartData = []
          result.data.records.forEach((item) => {
            this.chartData.push({
              chartid: item.chartid,
              name: item.name,
              typeLabel: this.chartTypeMap[item.type],
              type: item.type,
              desc: item.desc
            })
          })
          selectRow.forEach(item => {
            this.chartData.forEach((item2) => {
              if (item.chartId === item2.chartid) {
                this.selectionRow.push(item2)
              }
            })
          })
        }
      }).catch((err) => {
        console.log(err)
      })
    },
    setDialogTitle(dialogType) {
      switch (dialogType) {
        case 'add':
          this.dialogTitle = this.$t('public.add')
          break
        case 'edit':
          this.dialogTitle = this.$t('public.edit')
          break
        case 'detail':
          this.dialogTitle = this.$t('system.ChartList')
          break
      }
    },
    handleAdd() {
      this.resetForm()
      this.dialogType = 'add'
      this.setDialogTitle(this.dialogType)
      this.getchartData()
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.resetForm()
      this.dialogType = 'edit'
      this.setDialogTitle(this.dialogType)
      this.getchartData(row.chart)
      this.dialogVisible = true
      this.formData = {
        chart: row.chart,
        code: row.code,
        desc: row.desc,
        name: row.name
      }
    },
    formSubmit() {
      if (this.dialogType === 'add') {
        delete this.formData.code
        addView(this.formData).then((result) => {
          if (result.code === 200) {
            result.message && this.$message.success(result.message)
            this.getTableData()
            this.dialogVisible = false
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      } else {
        updateView(this.formData).then((result) => {
          if (result.code === 200) {
            result.message && this.$message.success(result.message)
            this.getTableData()
            this.dialogVisible = false
          }
        }).catch((err) => {
          this.$message.error(err)
        })
      }
    },
    handleDetail(row) {
      this.dialogType = 'detail'
      this.setDialogTitle(this.dialogType)
      this.chartData = []
      row.chart.forEach(item => {
        this.chartData.push({
          chartid: item.chartId,
          name: item.chartName,
          typeLabel: this.chartTypeMap[item.type],
          type: item.type,
          desc: item.desc
        })
      })
      this.dialogVisible = true
    },
    handleDelete(row) {
      this.$confirm(this.$t('public.deleteTips'), this.$t('public.tips'), {
        confirmButtonText: this.$t('public.confirm'),
        cancelButtonText: this.$t('public.cancel'),
        type: 'warning'
      }).then(() => {
        deleteView(row.code).then((result) => {
          result.message && this.$message.success(result.message)
          this.getTableData()
        }).catch((err) => {
          this.$message.error(err)
        })
      }).catch(() => {
        this.$message({
          showClose: true,
          type: 'info',
          message: this.$t('public.deleteCancel')
        })
      })
    },
    handleSelect(val) {
      this.formData.chart = []
      // console.log(val.length)
      val.forEach((item) => {
        this.formData.chart.push({
          chartId: item.chartid,
          chartName: item.name,
          desc: item.desc,
          type: item.type
        })
      })
    },
    resetForm() {
      this.formData = {
        chart: [],
        code: '',
        desc: '',
        name: ''
      }
      this.selectionRow = []
    }
  }
}
</script>

<style lang="scss">
@import '@/styles/variables.scss';
.dashboard-config-container{
  width: 100%;
  height: 100%;
  .btn-div{
    position: absolute;
    top: 15px;
    left: 93%;
    width:200px;
  }
  .table-class {
    background: $darkBlue4;
    padding: 10px;
    height: calc(100vh - 126px);
  }
  .Table .el-table--border::after,
  .Table .el-table--group::after,
  .Table .el-table::before {
    background: none;
  }
  .dialog-table{
    height: 250px;
    overflow-y: auto;
  }
}
</style>
