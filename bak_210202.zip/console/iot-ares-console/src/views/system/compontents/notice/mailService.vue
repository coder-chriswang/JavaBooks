<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-23 15:48:47
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-24 09:18:03
 * @Description: file content
-->
<template>
  <div class="form-class">
    <el-form label-position="right" label-width="200px" :model="mailServeInfo">
      <el-form-item :label="$t('system.ConnectionProtocol')">
        <el-select v-model="mailServeInfo.ConnectionProtocol" :placeholder="$t('statistics.pleaseSelectA')">
          <el-option v-for="item in ConnectionProtocolOptions" :key="item.value" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('system.mailServeAddress')">
        <el-input v-model="mailServeInfo.mailServeAddress" />
      </el-form-item>
      <el-form-item :label="$t('system.port')">
        <el-input v-model="mailServeInfo.port" />
      </el-form-item>
      <el-form-item :label="$t('system.sendUserEmail')">
        <el-input v-model="mailServeInfo.sendUserEmail" />
      </el-form-item>
      <el-form-item :label="$t('system.sendUserAccount')">
        <el-input v-model="mailServeInfo.sendUserAccount" />
      </el-form-item>
      <el-form-item :label="$t('system.senduserPassword')">
        <el-input v-model="mailServeInfo.senduserPassword" />
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: 'MailService',
  data() {
    return {
      ConnectionProtocolOptions: [{
        value: 'smtp',
        label: 'smtp'
        // },
        // {
        //   value: 'pop3',
        //   label: 'pop3'
      }],
      mailServeInfo: {
        ConnectionProtocol: '',
        mailServeAddress: '',
        port: null,
        sendUserEmail: '',
        sendUserAccount: '',
        senduserPassword: ''
      }
    }
  }
}

</script>

<style lang="scss" scoped>
  .form-class {
    display: flex;
    background: #111547;
    height: calc(100vh - 126px);
    padding-top: 50px;
    .el-form{
      ::v-deep .el-input__inner{
        width: 400px;
      }
      .el-form-item{
        margin-bottom: 40px;
      }
    }

  }

</style>
