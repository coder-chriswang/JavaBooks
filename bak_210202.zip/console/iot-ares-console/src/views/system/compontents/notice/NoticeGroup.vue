<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-18 14:55:57
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-24 09:14:20
 * @Description: file content
-->
<template>
  <div>
    <Table
      :table-data="tableData"
      :table-header="tableHeader"
      :total="0"
      class="table-class"
    >
      <template slot-scope="scope">
        <el-button size="mini" @click="handleFotter(scope)">Fotter</el-button>
        <el-button
          size="mini"
          type="danger"
          @click="handleDetails(scope.$index, scope.row)"
        >Details</el-button>
      </template>
    </Table>
  </div>
</template>

<script>
import Table from '@/components/Table/Table'
export default {
  name: 'Operation',
  components: {
    Table
  },
  data() {
    return {
      tableData: [],
      tableHeader: [
        {
          name: this.$t('system.noticeGroupName'),
          id: 'code'
        },
        {
          name: this.$t('system.noticeGroupDesc'),
          id: 'code'
        },
        {
          name: this.$t('sidebar.user'),
          id: 'code'
        }
      ]
    }
  },
  created() {
    this.getTableData()
  },
  methods: {
    getTableData() {

    },
    handleSearch(val) {
      console.log(val)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .table-class {
    background: $darkBlue4;
    padding: 10px;
    height: calc(100vh - 126px);
  }
</style>
