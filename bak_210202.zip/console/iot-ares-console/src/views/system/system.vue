<!--
 * @Author: 刘彦宏
 * @Date: 2020-08-25 09:33:04
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-29 15:03:27
 * @Description: file content
-->
<template>
  <div class="system-container">
    <SiderBar :menu-list="menuList" :active-id="'1'" @menu-active="menuActive" />
    <Breadcrumb :context="menuSelectedName" />
    <div class="right-container" :class="containerClass">
      <DashBoardConfig v-if="menuSelected === '1'" />
      <Task v-if="menuSelected === '2-1'" />
      <Operation v-if="menuSelected === '3-1'" />
      <SafetyLog v-if="menuSelected === '3-2'" />
      <SysLog v-if="menuSelected === '3-3'" />
      <NoticeGroup v-if="menuSelected === '4-1'" />
      <MailServer v-if="menuSelected === '4-2'" />
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import Breadcrumb from '@/components/Breadcrumb/Breadcrumb'
import DashBoardConfig from './compontents/dashBoard/dashBoardConfig'
import Task from './compontents/dump/task'
import Operation from './compontents/log/operationLog'
import SafetyLog from './compontents/log/safetyLog'
import SysLog from './compontents/log/sysLog'
import NoticeGroup from './compontents/notice/NoticeGroup'
import MailServer from './compontents/notice/mailServer'
export default {
  name: 'System',
  components: {
    SiderBar,
    Breadcrumb,
    DashBoardConfig,
    Task,
    Operation,
    SysLog,
    SafetyLog,
    MailServer,
    NoticeGroup
  },

  data() {
    return {
      menuList: [
        {
          label: this.$t('route.overview'),
          icon: 'icon-peizhi',
          id: '1'
        },
        {
          label: this.$t('sidebar.dump'),
          icon: 'icon-peizhi',
          id: '2',
          children: [
            {
              label: this.$t('sidebar.task'),
              icon: '',
              id: '2-1'
            }
          ]
        },
        {
          label: this.$t('sidebar.auditLog'),
          icon: 'icon-yunwei',
          id: '3',
          children: [
            {
              label: this.$t('sidebar.operation'),
              icon: '',
              id: '3-1'
            },
            {
              label: this.$t('sidebar.security'),
              icon: '',
              id: '3-2'
            },
            {
              label: this.$t('route.system'),
              icon: '',
              id: '3-3'
            }
          ]
        },
        {
          label: this.$t('sidebar.notice'),
          icon: 'icon-yunwei',
          id: '4',
          children: [
            {
              label: this.$t('sidebar.notificationGroup'),
              icon: '',
              id: '4-1'
            },
            {
              label: this.$t('sidebar.mailServer'),
              icon: '',
              id: '4-2'
            }
          ]
        }
      ],
      menuSelected: '',
      menuSelectedName: ''
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'name'
    ]),
    containerClass() {
      return {
        rightContainerHideSidebar: !this.sidebar.opened,
        rightContainerShowSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    // console.log(this.menuList)
  },
  methods: {
    menuActive(val) {
      this.menuSelected = val.menuId
      this.getNameByIdInObjArr(this.menuList, this.menuSelected)
    },
    getNameByIdInObjArr(arr, id) {
      arr.forEach(v => {
        if (id === v.id) {
          this.menuSelectedName = v.label
        }
        if (v.children && v.children.length > 0) {
          this.getNameByIdInObjArr(v.children, id)
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.system-container {
  padding: 10px;
  height: calc(100vh - 83px);
}
.open {
  margin-left: $sideBarWidth;
}
.close {
  margin-left: $sideBarHideWidth;
}
</style>
