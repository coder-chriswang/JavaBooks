<!--
 * @Author: 张通
 * @Date: 2020-11-02 16:38:16
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-02 19:11:00
 * @Description: file content
-->
<template>
  <div class="TitleContainer">
    <div class="header">
      <span>{{ title }}</span>
    </div>
    <div class="footer">
      <slot />
    </div>
  </div>
</template>
<script>
export default {
  props: {
    title: {
      type: String,
      default: () => 'String'
    }
  }
}
</script>
<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .TitleContainer {
    height: 100%;
    width: 100%;
    .header {
      height: 30px;
      line-height: 30px;
      position: relative;
      span {
        margin-left: 10px;
      }
    }
    .header::before {
      content: "";
      height: 16px;
      width: 4px;
      position: absolute;
      background: $linghtBlue3;
      top: 7px;
    }
    .footer {
      height: calc(100% - 30px);
    }
  }
</style>
