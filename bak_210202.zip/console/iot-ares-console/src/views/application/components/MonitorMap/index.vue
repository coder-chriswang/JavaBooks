<!--
 * @Author: 张通
 * @Date: 2020-11-03 15:45:58
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-03 17:01:17
 * @Description: file content
-->
<template>
  <div id="MonitorMap" />
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      msg: 'hello map'
    }
  },
  computed: {
    ...mapGetters(['language'])
  },
  mounted() {
    this.initMap(this.language)
  },

  methods: {
    initMap(lang, pathContainer) {
      this.MonitorMap = new AMap.Map('MonitorMap', {
        resizeEnable: true,
        center: [108.94748, 34.270964], // 地图中心
        // 颜色111122
        mapStyle: 'amap://styles/darkblue',
        zoom: 6 // 地图缩放级别
      })
      this.MonitorMap.setLang(this.MonitorMapLang(lang))
      this.cover(pathContainer)
    },
    MonitorMapLang(lang) {
      if (lang === 'zh') return 'zh_cn'
      if (lang === 'en') return 'en'
      return 'zh_en'
    },
    // 覆盖物
    cover(pathContainer) {
      // this.remove()
      // var path = [
      //   [108.624585, 33.797965],
      //   [108.300488, 34.972049],
      //   [109.679273, 34.144189],
      //   [109.997876, 34.994552]
      // ]
      // var polyline = new AMap.Polyline({
      //   path: pathContainer,
      //   ...this.lineStyle()
      // })
      // polyline.setMap(this.GDMap)
      // 缩放地图到合适的视野级别
      // this.GDMap.setFitView([polyline])
    }
  }
}
</script>
<style lang="scss" scoped>
  #MonitorMap {
    width: 100%;
    height: 100%;
    border: 1px solid #2b3b5d;
    border-radius: 5px;
  }
</style>
