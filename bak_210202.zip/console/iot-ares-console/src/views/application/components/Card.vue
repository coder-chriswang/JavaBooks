<!--
 * @Author: 张通
 * @Date: 2020-11-02 19:21:05
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-10 11:38:58
 * @Description: file content
-->
<template>
  <div class="card-container">
    <TitleContainer :title="title">
      <p v-for="(item,index) in container" :key="`=_=${index}`" :title="item.name" @click="handlerP(item)">{{ item.name }}</p>
    </TitleContainer>
  </div>
</template>
<script>
import TitleContainer from './TitleContainer'
export default {
  name: 'Card',
  components: {
    TitleContainer
  },
  props: {
    container: {
      type: Array,
      default: () => []
    },
    title: {
      type: String,
      default: () => this.$t('application.reservoirLakesMonitoring')
    }
  },
  data() {
    return {

    }
  },
  methods: {
    handlerP(item) {
      console.log(this.title, JSON.stringify(item))
    }
  }
}
</script>
<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .card-container {
    padding: 10px 20px;
    margin-bottom: 30px;
    border: 2px solid $linghtBlue3;
    border-radius: 6px;
    p{
      padding-left: 12px;
      overflow: hidden;
      text-overflow:ellipsis;
      white-space: nowrap;
      transition: color 0.5s;
    }
    p:hover {
      cursor: pointer;
      color: $linghtBlue3;
    }
  }
</style>
