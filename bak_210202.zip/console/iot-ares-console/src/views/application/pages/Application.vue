<!--
 * @Author: 张通
 * @Date: 2020-11-02 11:13:57
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-12 09:26:32
 * @Description: file content
-->
<template>
  <div class="Application">
    <header>
      <TitleContainer :title="$t('application.businessProcessArchitecture')" class="title-container">
        <img src="@/assets/application/flow.png">
      </TitleContainer>
    </header>
    <footer>
      <div v-for="(item,index) in Object.keys(container)" :key="`--${index}`" class="footer-container">
        <Card v-for="(items,i) in container[item]" :key="`==${i}`" :title="items.cardName" :container="items.data" />
      </div>
    </footer>
  </div>
</template>
<script>
import TitleContainer from '../components/TitleContainer'
import Card from '../components/Card'
export default {
  name: 'Application',
  components: {
    TitleContainer,
    Card
  },
  data() {
    return {
      container: {
        container_one: [],
        container_two: [],
        container_three: [],
        container_four: []
      }
    }
  },
  mounted() {
    import('../components/mock.json').then(res => {
      this.container = {
        container_one: [],
        container_two: [],
        container_three: [],
        container_four: []
      }
      this.container = this.setData(res.footerData)
    })
  },
  methods: {
    setData(arr) {
      const obj = {
        container_one: [],
        container_two: [],
        container_three: [],
        container_four: []
      }
      arr && arr.length > 0 && arr.forEach((item, index) => {
        switch (index % 4) {
          case 0:
            obj.container_one.push(item)
            break
          case 1:
            obj.container_two.push(item)
            break
          case 2:
            obj.container_three.push(item)
            break
          case 3:
            obj.container_four.push(item)
            break
        }
      })
      return obj
    }
  }
}
</script>
<style lang="scss" scpoed>
@import '@/styles/variables.scss';
.Application {
  color: #fff;
  // background: $darkBlue4;
  height: calc(100vh - 63px);
  padding: 10px 20px;
  overflow-y: auto;
  overflow-x: hidden;
  header {
    height: 50%;
    font-size: 14px;
    width: 100%;
  }
  .title-container .footer {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    img {
      display: inline-block;
      width: 98%;
      height: 90%;
    }
  }
  footer{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    .footer-container {
      width: 24%;
      height: auto;
    }
  }
}

</style>
