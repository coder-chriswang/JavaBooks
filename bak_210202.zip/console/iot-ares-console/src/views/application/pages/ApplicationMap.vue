<!--
 * @Author: 张通
 * @Date: 2020-11-02 11:26:19
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-02 11:26:37
 * @Description: file content
-->
<template>
  <div>
    <Breadcrumb class="mianbao" :context="titleContext" />
    <div class="monitorMapContainer">
      <MonitorMap />
    </div>
    <div class="monitorScreenContainer">
      <div class="monitorScreenRight">
        <div class="monitorScreenRightTop" />
        <div class="monitorScreenRightCenter">
          <div class="monitorScreenRightCenterLeft" />
          <div class="monitorScreenRightCenterRight" />
        </div>
        <div class="monitorScreenRightBottom" />
      </div>
    </div>

  </div>
</template>
<script>
// 水库湖泊监测
import MonitorMap from '../components/MonitorMap/'
import Breadcrumb from '@/components/Breadcrumb/Breadcrumb'
export default {
  components: {
    MonitorMap,
    Breadcrumb
  },
  data() {
    return {
      titleContext: this.$t('application.reservoirLakesMonitoring')
    }
  }
}
</script>
<style lang="scss" scoped>
// @import '../../../styles/variables.scss';
  $screenContentHeight: calc(100vh - 63px - 43px - 3vh);;
  .monitorMapContainer{
    /* height: 100%; */
    height: $screenContentHeight;
    width: 66%;
    margin-left: 1%;
    background: transparent;
  }
  .rightContainerShowSidebar{
    animation: unset;
  }
  .breadcrumb{
    padding-left: 0.5vw;
  }
  .monitorScreenContainer{
    position: absolute;
    top:43px;
    right: 1.5%;
    height: $screenContentHeight;
    width: 30%;
    .monitorScreenRight{
      height: 100%;
    // border:1px solid #2b3b5d;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    .monitorScreenRightTop{
      height: 32%;
      width: 100%;
       background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
       background-size: 100% 100%;
    }
    .monitorScreenRightCenter{
       height: 32%;
      width: 100%;

        display: flex;
      .monitorScreenRightCenterLeft{
        flex:1;
        margin-right: 1vw;
        background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
        background-size: 100% 100%;
      }
      .monitorScreenRightCenterRight{
        flex:1;
        background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
        background-size: 100% 100%;
      }
    }
    .monitorScreenRightBottom{
       height: 32%;
      width: 100%;
       background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
        background-size: 100% 100%;
    }
  }
  }

</style>
