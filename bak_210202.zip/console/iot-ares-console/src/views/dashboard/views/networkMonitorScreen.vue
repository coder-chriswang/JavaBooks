<!--
 * @Author: 张通
 * @Date: 2020-11-02 11:26:19
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-10 10:32:09
 * @Description: file content
-->
<template>
  <div class="monitorOutter" :class="rightContainer">
    <Breadcrumb class="mianbao" :context="titleContext" />
    <div style="position:relative;">
      <div class="monitorMapContainer">
        <GMapPigView />
      </div>
      <div class="monitorScreenContainer">
        <div class="monitorScreenRight">
          <div class="monitorScreenRightTop">
            <div class="chartTitle">{{ deviceChartTitle }}</div>
            <div class="deviceTotal">{{ deviceChartSubTitle }}： <span>{{ deviceTotal }}</span></div>
            <div class="chartContainer">
              <Chart :id="chartOptions[0].id" :options-data="chartOptions[0]" :update-time="chartOptions[0].time" :side-bar-opend="sidebar.opened" class="chart-div" />
            </div>
          </div>
          <div class="monitorScreenRightCenter">
            <div class="monitorScreenRightCenterLeft">
              <Chart :id="chartOptions[1].id" ref="monitorAlarmChart" :options-data="chartOptions[1]" :update-time="chartOptions[1].time" :side-bar-opend="sidebar.opened" class="chart-div" />

            </div>
            <div class="monitorScreenRightCenterRight">
              <Chart :id="chartOptions[2].id" ref="monitorNumberChart" :options-data="chartOptions[2]" :update-time="chartOptions[2].time" :side-bar-opend="sidebar.opened" class="chart-div" />
            </div>
          </div>
          <div class="monitorScreenRightBottom">
            <Chart :id="chartOptions[3].id" :options-data="chartOptions[3]" :update-time="chartOptions[3].time" :side-bar-opend="sidebar.opened" class="chart-div" />
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Chart from '@/components/Chart/Chart'
import GMapPigView from '../GMapPigView/GMapPigView'
import Breadcrumb from '@/components/Breadcrumb/Breadcrumb'
import { getChartOptions } from '@/utils/getChartOptions'
import { getScreenChart } from '@/api/screen'

// const chartLegendMap = {
//   1: this.$t('statistics.prompt'),
//   2: this.$t('statistics.general'),
//   3: this.$t('statistics.serious'),
//   4: this.$t('statistics.emergency')
// }
// const chartLegendColorMap = {
//   4: '#ff0000',
//   3: '#fe7506',
//   2: '#fced02',
//   1: '#fcf4cf'
// }

export default {
  components: {
    GMapPigView,
    Breadcrumb,
    Chart
  },
  data() {
    return {
      chartOptions: Array(4),
      deviceTotal: 0,
      deviceChartTitle: this.$t('dashboard.totalEquipment'),
      deviceChartSubTitle: this.$t('dashboard.totalNumberOfEquipment'),
      titleContext: this.$t('dashboard.anOverviewOf')
    }
  },
  computed: {
    ...mapGetters([
      'sidebar'
    ]),
    rightContainer() {
      return {
        sidebarHideWidth: !this.sidebar.opened,
        sidebarShowWidth: this.sidebar.opened
      }
    }
  },
  created() {
    this.chartOptions.fill({ id: '', time: 0 })
    this.getChartsData()
  },
  methods: {
    highlightChart(chartRefs) {
      chartRefs.forEach(item => {
        setTimeout(() => {
          if (!this.$refs[item]) return
          this.$refs[item].chart.dispatchAction({
            type: 'highlight',
            seriesIndex: 0,
            dataIndex: 0
          })

          this.$refs[item].chart.on('mouseover', (params) => {
            // console.log(params)
            this.$refs[item].chart.dispatchAction({
              type: 'highlight',
              seriesIndex: params.dataIndex,
              dataIndex: params.seriesIndex
            })
            params.dataIndex !== 0 && this.$refs[item].chart.dispatchAction({
              type: 'downplay',
              seriesIndex: 0,
              dataIndex: 0
            })
          })

          this.$refs[item].chart.on('mouseout', (params) => {
            this.$refs[item].chart.dispatchAction({
              type: 'highlight',
              seriesIndex: 0,
              dataIndex: 0
            })
          })
        }, 1000)
      })
    },
    async getChartsData() {
      try {
        const response = await Promise.all(['DeviceCountStatistic', 'AlarmDistributeStatistic', 'DeviceDistributeStatistic', 'RunStatusStatistic'].map(chartid => getScreenChart({ chartid })))
        response.forEach((res, index) => {
          if (res.data) {
            const chartDs = JSON.parse(res.data.chartDs)
            switch (index) {
              case 0:
                this.deviceTotal = chartDs.total
                this.deviceChartTitle = chartDs.chartTitle
                this.deviceChartSubTitle = chartDs.chartSubTitle
                break
              case 1:
                chartDs.chartTitleColor = '#a5d6f8'
                break
              case 2:
                chartDs.chartColor = [
                  '#00baff',
                  '#fec006',
                  '#0072bc',
                  '#bd8cbf',
                  '#acd373'
                ]
                chartDs.chartTitleColor = '#a5d6f8'
                break
              case 3:
                chartDs.dataZoomNum = 6
                chartDs.chartTitleColor = '#a5d6f8'
                break
            }

            const options = getChartOptions(chartDs)
            this.chartOptions[index] = {
              type: 'chart',
              id: res.data.chartId || ('chart' + index),
              options: options,
              time: Date.now()
            }
          }
        })
        this.highlightChart(['monitorAlarmChart', 'monitorNumberChart'])
      } catch (error) {
        console.log(error)
      }
    }
  }

}
</script>
<style lang="scss" scoped>
// @import '../../../styles/variables.scss';
  .monitorOutter{
    float: right;
    height: calc(100vh - 83px);
  }
  $screenContentHeight: calc(100vh - 63px - 53px - 1vh);
  .sidebarHideWidth{
    width: calc(100% - 64px);
    .monitorMapContainer{
      width: calc(66%);
    }
  }
   .sidebarShowWidth{
    width: calc(100% - 210px);
    .monitorMapContainer{
      width: 66%;
    }
  }
  .monitorMapContainer{
    height: $screenContentHeight;
    margin-left: 1%;
    background: transparent;
  }
  .rightContainerShowSidebar,.rightContainerHideSidebar {
    animation: unset;
    ::v-deep .el-divider--vertical{
      left:23px
    }
    ::v-deep .el-divider--vertical + span{
      position: relative;
      left:23px
    }
  }
  .breadcrumb{
    padding-left: 0.5vw;
  }
  .monitorScreenContainer{
    position: absolute;
    top:0px;
    right: 0.5%;
    height: $screenContentHeight;
    width: 31%;
    .monitorScreenRight{
      height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    .monitorScreenRightTop{
      height: 32%;
      width: 100%;
       background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
       background-size: 100% 100%;
       position: relative;
       .chartTitle{
         color:#a5d6f8;
         font-weight:normal;
         font-size:16px;
         line-height:28px;
         padding: 15px 0 0 15px;
       }
       .deviceTotal{
         color:#a5d6f8;
         font-size:16px;
         line-height:28px;
         text-align: center;
         span{
           font-weight:normal;
           color:#c65519;
            font-size: 20px;
    vertical-align: bottom;
         }
       }
       .chartContainer{
         position: absolute;
         bottom: 6%;
    width: calc(100% - 5vw);
    left: 50%;
    transform: translateX(-50%);
    height: 60%;
          .chart-div {
          width: 100%;
          height: 100%;
          background-repeat: round;
          padding: 10px 10px 0px;
        }
       }
    }
    .monitorScreenRightCenter{
       height: 32%;
      width: 100%;

        display: flex;

    .chart-div {
          width: 100%;
          height: calc((100vh - 115px)/3);
          background-repeat: round;
          padding: 10px 10px 20px;
        }
      .monitorScreenRightCenterLeft{
        flex:1;
        margin-right: 1vw;
        background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
        background-size: 100% 100%;
      }
      .monitorScreenRightCenterRight{
        flex:1;
        background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
        background-size: 100% 100%;
      }
    }
    .monitorScreenRightBottom{
       .chart-div {
          width: 100%;
          height: 100%;
          background-repeat: round;
          padding: 10px 10px 20px;
        }
       height: 32%;
      width: 100%;
       background: url('../../../assets/screen/screenChartBox.png')  center center no-repeat;
        background-size: 100% 100%;
    }
  }
  }

</style>
