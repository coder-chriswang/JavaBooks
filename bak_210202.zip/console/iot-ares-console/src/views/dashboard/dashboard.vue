<!--
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @Description: file content
-->
<template>
  <div class="dashboard-container">
    <SiderBar :menu-list="menuList" :active-id="chartId" @menu-active="menuActive" />
    <template v-if="dashboardType === 'NetworkMonitorScreen'">
      <NetworkMonitorScreen />
    </template>
    <template v-else>
      <el-dropdown size="medium" split-button type="primary" class="drop-btn" @command="handleCommand">
        {{ refreshTimer + ' S' }}
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="10">10 S</el-dropdown-item>
          <el-dropdown-item command="30">30 S</el-dropdown-item>
          <el-dropdown-item command="60">60 S</el-dropdown-item>
          <el-dropdown-item command="300">300 S</el-dropdown-item>
          <el-dropdown-item command="600">600 S</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <div
        v-if="totalRecordCount"
        v-loading="loading"
        :class="rightContainerClass"
        class="charts-container"
        :element-loading-text="$t('public.loading')"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
      >
        <el-row :gutter="15">
          <el-col v-for="(item, index) in chartOptions" :key="index" :span="8">
            <Chart v-if="item.type === 'chart'" :id="item.id" :options-data="item" :update-time="item.time" :side-bar-opend="sidebar.opened" class="chart-div" />
            <Table
              v-else
              :pagination="false"
              :table-data="item.options.tableData.rows"
              :table-header="item.options.tableHeader"
              class="chart-div"
              :highlight-current-row="false"
              :last-table-column="false"
              :table-title="item.chartName"
            />
          </el-col>
        </el-row>
      </div>
      <div
        v-else
        :class="rightContainerClass"
        class="charts-container"
      >
        <div class="no-data-available">
          <span>{{ $t('dashboard.temporarilyNoData') }}</span>
        </div>
      </div>
    </template>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import Chart from '@/components/Chart/Chart'
import Table from '@/components/Table/Table'
import { getViewsTableData, getChartID, getChartViewData } from '@/api/system'
import { getChartOptions } from '@/utils/getChartOptions'
import NetworkMonitorScreen from './views/networkMonitorScreen'
export default {
  name: 'Dashboard',
  components: {
    SiderBar,
    Chart,
    Table,
    NetworkMonitorScreen
  },

  data() {
    return {
      dashboardType: 'NetworkMonitorScreen',
      menuList: [],
      chartOptions: [],
      viewIdArr: [],
      chartId: '',
      refreshTimer: 10,
      refreshInterval: null,
      totalRecordCount: 1,
      loading: true
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'name'
    ]),
    rightContainerClass() {
      return {
        rightContainerHideSidebar: !this.sidebar.opened,
        rightContainerShowSidebar: this.sidebar.opened
      }
    }
  },
  watch: {
    chartId: {
      handler(newVal, oldVal) {
        // 切换菜单时先清除定时器
        this.refreshTimeInterval && clearInterval(this.refreshTimeInterval)
        /* 点击菜单默认情况调用dashboard部分的接口，获取图表内容，其他根据情况调用*/
        switch (this.dashboardType) {
          case 'NetworkMonitorScreen':
            break
          default:
            this.getChartsData()
            this.refreshTimeInterval = setInterval(() => {
              this.getChartsData()
            }, this.refreshTimer * 1000)
            break
        }
      }
    }
  },
  created() {
    this.getMenu()
    // 切换菜单时先清除定时器
    this.refreshTimeInterval && clearInterval(this.refreshTimeInterval)
    // 点击菜单默认情况调用dashboard部分的接口，获取图表内容，其他根据情况调用
    switch (this.dashboardType) {
      case 'NetworkMonitorScreen':
        break
      default:
        this.getChartsData()
        this.refreshTimeInterval = setInterval(() => {
          this.getChartsData()
        }, this.refreshTimer * 1000)
        break
    }
  },
  beforeDestroy() {
    this.refreshTimeInterval && clearInterval(this.refreshTimeInterval)
  },
  methods: {
    menuActive(val) {
      this.dashboardType = val.menuId
      this.chartId = val.menuId
      this.loading = true
    },
    handleCommand(command) {
      this.refreshTimer = command
      this.refreshTimeInterval && clearInterval(this.refreshTimeInterval)
      this.refreshTimeInterval = setInterval(() => {
        this.getChartsData()
      }, this.refreshTimer * 1000)
      this.getChartsData()
    },
    getMenu() {
      this.menuList = [
        {
          label: this.$t('dashboard.entireNetworkMonitoring'),
          icon: 'icon-peizhi',
          isActive: true,
          id: 'NetworkMonitorScreen'
        }
      ]
      getViewsTableData({}).then((result) => {
        this.totalRecordCount = result.data.totalRecordCount
        result.data.records && result.data.records.forEach((item, index) => {
          this.menuList.push({
            label: item.name,
            icon: 'icon-peizhi',
            // isActive: index === 0,
            id: item.code + ''
          })
          /* 先注释
         this.chartId = index === 0 ? item.code + '' : this.chartId*/
        })
      }).catch(err => {
        console.log(err)
        this.totalRecordCount = 0
      }).finally(() => {
        this.loading = false
      })
    },

    getChartsData() {
      this.chartId && getChartID(this.chartId).then((res2) => {
        const promiseArr = []
        res2.data.length > 0 && res2.data.forEach((item, index) => {
          promiseArr.push(getChartViewData(item))
        })
        Promise.all(promiseArr).then(resArr => {
          this.chartOptions = []
          resArr.forEach(res3 => {
            if (res3.data) {
              try {
                const chartOptions = JSON.parse(res3.data.chartDs)
                if (chartOptions.chartType !== 'table') {
                  if (res3.data.chartId === 'RmStatus') {
                    var colorMap = { 'UNKOWN': '#61a0a8', 'UNKNOWN': '#61a0a8', 'OFFLINE': '#2f4554', 'ONLINE': '#008acd' }
                    chartOptions.chartColor = chartOptions.data.legend.map(item => colorMap[item])
                  }
                  const { dataLength, ...options } = getChartOptions(chartOptions)
                  this.chartOptions.push({
                    type: 'chart',
                    id: res3.data.chartId,
                    options: options,
                    dataLength,
                    time: Date.now()
                  })
                } else {
                  const tableHeaderArr = []
                  chartOptions.data.tableHeader.forEach(item => {
                    tableHeaderArr.push(item.key)
                  })
                  this.chartOptions.push({
                    type: 'table',
                    id: res3.data.chartId,
                    chartName: res3.data.chartName,
                    options: chartOptions.data
                  })
                }
                this.loading = false
              } catch (error) {
                this.loading = false
                return
              }
            }
          })
        }).catch(err => {
          console.log(err)
        }).finally(() => {
          this.loading = false
        })
      }).catch(err => {
        console.log(err)
        this.loading = false
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.dashboard {
  &-container {
    padding: 10px;
    height: calc(100vh - 80px);
      .drop-btn {
        position: absolute;
        right: 10px;
      }
      .charts-container {
        padding-top: 45px;
        // height: 100%;
        height: calc(100vh - 83px);
        overflow: hidden;
        .chart-div {
          background-image: url('../../assets/chartbox.png');
          width: 100%;
          height: calc((100vh - 115px)/3);
          background-repeat: round;
          padding: 10px 10px 20px;
        }
      }
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth}  + 10px);
  }

}
// 自定义暂无数据
.no-data-available {
  background-image: unset;
  span{
    color:whitesmoke;
    position: relative;
    font-size: 40px;
    font-weight: 200;
    background: linear-gradient(to bottom, #feffff, #7ed6f9);
    background-clip: text;
    color: transparent;
  }
}
</style>
