<!--
 * @Author: 张通
 * @Date: 2020-11-04 15:58:47
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-16 09:50:09
 * @Description: file content
-->
<template>
  <div class="GMapPigView" :class="isFullscreen?'fullscreen':''">
    <div class="toolbox">
      <el-autocomplete
        v-model="querySearchContent"
        :fetch-suggestions="querySearchAsync"
        placeholder="请输入设备名称"
        clearable
        prefix-icon="el-icon-search"
        @focus="addTitleTip"
        @select="handleSelectDevice"
      />
      <i class="el-icon-full-screen full-icon" @click="isFullscreen=!isFullscreen" /></div>
    <GMap ref="GMap" />
    <header>
      <div v-for="(item,index) in alarmStatus" :key="index" class="continer">
        <img :src="item.img">
        <span>{{ item.name }}</span>
        <strong>{{ item.count }}</strong>
      </div>
    </header>
    <footer ref="footer" class="device-container" @scroll="listenScroll">
      <div v-for="(item,index) in deviceType" :key="index" :class="{'device-choice':deviceChoice === index}" class="device-type" @click="handlerDevice(index,item)">
        <i v-html="item.icon" />
        <br>
        <span>{{ item.name }}</span>
      </div>
      <!-- <div v-show="deviceType.length>6 && showSlide" class="device-type" @click="slideToBottom">

        <svg-icon :icon-class="'bottom-slide'" />
      </div> -->
    </footer>
  </div>
</template>
<script>
const yellow = require('@/assets/yellow.png')
const origin = require('@/assets/origin.png')
const red = require('@/assets/red.png')
const green = require('@/assets/green.png')
const lightyellow = require('@/assets/lightyellow.png')

const shadow = require('@/assets/shadow.png')
import GMap from './components/GMap'
import http from '@/api/dashboard'
const titleTip = ({ target }) => {
  target.tagName === 'LI' && target.setAttribute('title', target.textContent)
}
export default {
  components: {
    GMap
  },
  data() {
    return {
      isFullscreen: false,
      querySearchContent: '',
      showSlide: true,
      alarmStatus: [
        {
          img: red,
          name: this.$t('dashboard.emergencyAlarm'),
          count: ''
        },
        {
          img: origin,
          name: this.$t('dashboard.seriousWarning'),
          count: ''
        },
        {
          img: yellow,
          name: this.$t('dashboard.generalAlarm'),
          count: ''
        },
        {
          img: lightyellow,
          name: this.$t('dashboard.promptAlarm'),
          count: ''
        },
        {
          img: green,
          name: this.$t('dashboard.normalEquipment'),
          count: ''
        }
      ],
      deviceType: [],
      deviceChoice: 0,
      preMarker: null
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.getFieldMenu()
    })
  },
  methods: {
    addTitleTip() {
      const el = document.querySelector('.el-autocomplete-suggestion')
      el.removeEventListener('mouseover', titleTip, false)
      el.addEventListener('mouseover', titleTip, false)
    },
    handleSelectDevice({ latitude, longitude, instanceid }) {
      this.preMarker && (this.preMarker.setAnimation('AMAP_ANIMATION_NONE'), this.preMarker.setShadow(null))
      const marker = this.$refs['GMap'].entity.point.find(item => item.entity.getExtData().instanceid === instanceid)
      if (marker) {
        this.preMarker = marker.entity
        setTimeout(() => {
          marker.entity.setAnimation('AMAP_ANIMATION_DROP')
          marker.entity.setShadow(new AMap.Icon({
            image: shadow,
            imageSize: new AMap.Size(24, 24)
          }))
        }, 600)
      }
      this.$refs['GMap'].GDMap.setZoomAndCenter(18, [
        longitude, latitude])
    },
    async querySearchAsync(queryString, cb) {
      if (!queryString.length) return cb([])
      const res = await http.getGISDeviceData({
        doInstanceId: this.deviceType[this.deviceChoice].doInstanceid === 'all' ? '' : this.deviceType[this.deviceChoice].doInstanceid,
        instanceName: queryString
      })
      cb(res.data.map(item => ({ ...item, value: item.name + '(' + item.instanceid + ')' })))
    },
    slideToBottom() {
      const footer = this.$refs['footer']
      footer.scrollTo(0, footer.scrollTop + 55)
    },
    listenScroll(e) {
      const footer = e.target
      this.showSlide = footer.scrollTop < (footer.scrollHeight - footer.offsetHeight)
    },
    async getFieldMenu() {
      try {
        // get 领域(地图左侧菜单)
        const res = await http.getMapAlarmData({
          chartid: 'CategoryStatistic'
        })
        if (res.code && res.code !== 200) return
        const op = JSON.parse(res.data.chartDs)
        this.deviceType = op
        // 设置默认选中第一项icon（svg）颜色
        this.setChoieceIconColor(this.deviceType[0], 0)
        // get 地图数据
        this.getPointData({ chartid: 'GISDataStatistic' })
        // 地图左上角数据
        this.getLeftTopData({ chartid: 'AlarmSeverityCount' })
      } catch (error) {
        throw new Error(error)
      }
    },
    // get 地图左上角数据
    async getLeftTopData(data = {}) {
      try {
        const res = await http.getMapAlarmData(data)
        if (res.code !== 200) return
        const op = JSON.parse(res.data.chartDs)
        this.alarmStatus.forEach(item => {
          item.count = 0
        })
        const that = this
        op.length > 0 && op.forEach(item => {
          that.alarmStatus[4 - item.alarmSeverity].count = item.alarmCount
          that.alarmStatus[4].count = item.normalDeviceCount || 0
        })
      } catch (error) {
        throw new Error(error)
      }
    },
    // get 地图数据
    async getPointData(data = {}) {
      try {
        // 地图数据 alarm
        const res = await http.getMapAlarmData(data)
        if (res.code !== 200) return
        const op = JSON.parse(res.data.chartDs)
        Array.isArray(op) && op.length > 0 && op.forEach(item => {
          item.position = [item.longitude, item.latitude]
        })
        this.$refs['GMap'].cover(op)
      } catch (error) {
        throw new Error(error)
      }
    },
    // 设置当前选中SVG颜色
    setChoieceIconColor(item, index) {
      this.deviceType.length > 0 && this.deviceType.forEach((item, index) => {
        item.icon = item.icon.replace(/fill='#b958d0'/g, `fill='#FFFFFF'`)
        this.$set(this.deviceType, index, item)
      })
      item.icon = item.icon.replace(/fill='#FFFFFF'/g, `fill='#b958d0'`)
      this.$set(this.deviceType, index, item)
    },
    // 领域筛选
    handlerDevice(index, item) {
      if (this.deviceChoice === index) return
      // 设置当前选中SVG颜色
      this.setChoieceIconColor(item, index)
      this.deviceChoice = index
      if (item.doInstanceid === 'all') {
        this.getPointData({
          chartid: 'GISDataStatistic'
        })
      } else {
        this.getPointData({
          chartid: 'GISDataSearchStatistic',
          doInstanceId: item.doInstanceid
        })
      }
      // this.getLeftTopData()
    }
  }
}
</script>
<style lang="scss" scoped>
@import '@/styles/variables.scss';
  .GMapPigView:lang(en){
    header .continer{
        span:lang(en){
          width: 86px;
        }
        strong:lang(en) {
          color: #031963;
        }
    }
  }
  .GMapPigView {
    position: relative;
    width: 100%;
    height: 100%;
    &.fullscreen{
        position: fixed;
        background: rgb(27, 38, 140);
        width: 100vw;
        height: 100vh;
        top: 0;
        left: 0;
        z-index: 99;
    }
    ::v-deep .full-icon{
          font-size: 26px;
          font-weight:bold;
          vertical-align: middle;
          cursor: pointer;
          margin-left:20px;
          color:#2eb0f9;
          &:hover{
          color: #007ecc;
          }
        }
    .device-choice{
      color: #b958d0 !important;
      display: block !important;
    }
    .toolbox{
      position: absolute;
      top:20px;
      right: 20px;
      z-index: 9;
      ::v-deep .el-input__inner{
        border-radius: 42px;
        background: rgba(0, 0, 0, 0.6) !important;
        border: none !important;
      }
    }
    header {
      position: absolute;
      bottom: 20px;
      right: 30px;
      background: rgba(0,0,0,0.4);
      padding: 15px;
      border-radius: 4px;
      .continer {
        margin-bottom: 5px;
        display: flex;
        align-items: center;
        img {
          display: inline-block;
          width: 20px;
          height: 20px;
          margin-right: 20px;
          align-self: flex-start;
        }
        span {
          display: inline-block;
          margin-right: 20px;
          color: #fff;
          font-size: 12px;
        }
        strong {
          display: inline-block;
          font-size: 22px;
          color: #fff;
        }
      }
    }
    footer {
      position: absolute;
      top: 20px;
      z-index: 10;
      transform:translateX(20px);
      &:hover{
        .device-type{
          display: block !important;
        }
        max-height: 330px !important;
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;
        overflow: unset !important;
      }
      &.device-container{
        max-height: 55px;
        overflow: auto;
        // >:first-child{
        //   position: sticky;
        //   z-index: 2;
        //   top: 0;
        // }
        // >:last-child{
        //   position: sticky;
        //   bottom: 0;
        //   height: 28px;
        //   padding: 0;
        // }
        &::-webkit-scrollbar{
          display: none;
        }
        .svg-icon{
          position: sticky;
          bottom: 0;
          left: 50%;
          transform: translate(-50%,4px);
          z-index: 1;
          color: #eee;
          font-size: 26px;
          // animation:lightAnimate 1s linear infinite;
        }
        @keyframes lightAnimate {
          0%,100% {
            margin-top: 0px;
          }
          20% {
            margin-top: 0.5px;
          }
          40% {
            margin-top: 1px;
          }

          60% {
            margin-top: 1.5px;
          }
        }
      }
      .device-type {
        display: none;
        position: relative;
        height: 55px;
        z-index: 1;
        padding: 10px;
        background: #0f1f30;
        color: #96baf1;
        text-align: center;
        transition: color 0.5s;
        .iconfont {
          font-size: 16px;
        }
        span {
          display: inline-block;
          font-size: 12px;
        }
      }
      .device-type:hover {
        cursor: pointer;
        color: #b958d0;
      }
    }
    .show-slide{
      .device-type{
        display: none;
      }
    }
  }
</style>
