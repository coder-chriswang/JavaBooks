<!--
 * @Author: 张通
 * @Date: 2020-09-15 19:07:28
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-12 15:00:50
 * @Description: file content
-->
<template>
  <div id="GMap" />
</template>
<script>
import { mapGetters } from 'vuex'
const yellow = require('@/assets/yellow.png')
const origin = require('@/assets/origin.png')
const red = require('@/assets/red.png')
const green = require('@/assets/green.png')
const lightyellow = require('@/assets/lightyellow.png')
export default {
  props: {

  },
  data() {
    return {
      GDMap: {},
      entity: {
        // 点实体
        point: []
      },
      cluster: null,
      alarmSeverityMap: {
        4: '#ff0000',
        3: '#fe7506',
        2: '#fced02',
        1: '#fcf4cf',
        0: '#07c118'
      }
    }
  },
  computed: {
    ...mapGetters(['language'])
  },
  watch: {
    language(v) {
      this.GDMap.setLang(this.GDMapLang(v))
    }
  },
  mounted() {
    this.initMap(this.language)
  },
  methods: {
    GDMapLang(lang) {
      if (lang === 'zh') return 'zh_cn'
      if (lang === 'en') return 'en'
      return 'zh_en'
    },
    initMap(lang) {
      this.GDMap = new AMap.Map('GMap', {
        resizeEnable: true,
        keyboardEnable: false,
        center: [108.94748, 34.270964], // 地图中心
        zoom: 5 // 地图缩放级别
      })
      // eslint-disable-next-line no-undef
      // AMapUI.loadUI(['control/BasicControl'], BasicControl => {
      // 添加一个缩放控件
      //   this.GDMap.addControl(new BasicControl.Zoom({
      //     position: 'lb',
      //     theme: 'user-zoom'
      //   }))
      // })
      this.GDMap.setMapStyle('amap://styles/7130ea6600af2fabb068b0abdc74a57e')
      this.GDMap.setLang(this.GDMapLang(lang))
      // this.cover(pathContainer)
    },
    // 添加覆盖物
    cover(continer = [], type = 'point') {
      switch (type) {
        case 'point':
          // 添加点
          return this.addPoint(continer)
      }
    },
    createInfoWindow(title, content) {
      const info = document.createElement('div')
      info.className = 'custom-info input-card content-window-card'

      // 可以通过下面的方式修改自定义窗体的宽高
      // info.style.width = "400px";
      // 定义顶部标题
      const top = document.createElement('div')
      const titleD = document.createElement('div')
      top.className = 'info-top'
      titleD.innerHTML = title

      top.appendChild(titleD)
      info.appendChild(top)

      // 定义中部内容
      const middle = document.createElement('div')
      middle.className = 'info-middle'
      middle.style.backgroundColor = '#1a3c97'
      middle.innerHTML = content
      info.appendChild(middle)

      // 定义底部内容
      const bottom = document.createElement('div')
      bottom.className = 'info-bottom'
      bottom.style.position = 'relative'
      bottom.style.top = '0px'
      bottom.style.margin = '0 auto'
      var sharp = document.createElement('span')
      sharp.className = 'info-window-arrow'
      bottom.appendChild(sharp)
      info.appendChild(bottom)
      return info
    },
    // 设置显示地图图片类型
    setPointImg(imgType = 0) {
      switch (imgType) {
        case 4:
          return red
        case 3:
          return origin
        case 2:
          return yellow
        case 1:
          return lightyellow
        case 0:
          return green
      }
    },
    // 批量或者单独绘制点
    addPoint(pointContiner = []) {
      this.remove()
      if (!Array.isArray(pointContiner)) return
      try {
        pointContiner && pointContiner.forEach(item => {
          this.entity.point.push({
            entity: new AMap.Marker({
              position: new AMap.LngLat(item.position[0], item.position[1]),
              offset: new AMap.Pixel(-10, -10),
              extData: {
                alarmSeverity: item.alarmSeverity,
                name: item.name,
                ci: item.ci,
                imei: item.nativeId,
                instanceid: item.instanceid
              },
              icon: new AMap.Icon({
                image: this.setPointImg(item.alarmSeverity),
                imageSize: new AMap.Size(24, 24)
              })// 添加 Icon 图标 URL
            }),
            info: item
          })
        })
        const InfoWindow = new AMap.InfoWindow({
          isCustom: true, // 使用自定义窗体
          retainWhenClose: true
          // offset: new AMap.Pixel(16, -45)
        })
        const _renderClusterMarker = (context) => {
          const div = document.createElement('div')
          const alarmSeveritys = new Set()
          context.markers.forEach(item => {
            const { alarmSeverity } = item.getExtData()
            alarmSeveritys.add(alarmSeverity)
          })
          div.style.backgroundImage = `url('${this.setPointImg(Math.max(...alarmSeveritys))}')`
          div.style.backgroundSize = `100% 100%`
          const size = 36
          div.style.width = div.style.height = size + 'px'
          div.innerHTML = context.count
          div.style.lineHeight = size + 'px'
          div.style.color = '#031963'
          div.style.fontSize = '14px'
          div.style.fontWeight = 'bold'
          div.style.textAlign = 'center'
          context.marker.setOffset(new AMap.Pixel(-size / 2, -size / 2))
          context.marker.setContent(div)
        }

        const markers = []
        this.entity.point.forEach(i => {
          const item = i.entity
          markers.push(item)
          const { alarmSeverity, name, ci, instanceid, imei } = item.getExtData()
          AMap.event.addListener(item, 'mouseover', () => { // 绑定鼠标移入事件
            AMap.event.removeListener('mouseout') // 先清除后绑定，放置多次绑定事件
            const triangle = `<span  class="alarm-triangle" style="border-bottom-color:${this.alarmSeverityMap[alarmSeverity]};"></span>`
            const info = this.createInfoWindow(name + (alarmSeverity > 0 ? triangle : ''), [`${this.$t('sidebar.device')}ID:` + instanceid, `${this.$t('sidebar.device')}IMEI:` + imei, `<span class="info-middle-detail">${this.$t('dashboard.deviceDetail')}</span>`].join('<br/>'))
            InfoWindow.setContent(info)
            InfoWindow.open(this.GDMap, item.getPosition())
            info.addEventListener('click', (e) => {
              if (e.target.className === 'alarm-triangle') {
                this.$router.push({ path: '/alarm?' + Date.now(), query: { instanceName: name }})
              }
              if (e.target.className === 'info-middle-detail') {
                this.$router.push({ path: '/resources/detail', query: { ci, ns: 'ies', instanceid }})
              }
            }, false)
            AMap.event.addListener(item, 'mouseout', () => {
              InfoWindow.close()
            })
          })
        })

        this.cluster && this.cluster.clearMarkers()
        this.cluster = new AMap.MarkerClusterer(this.GDMap, markers, {
          gridSize: 80,
          maxZoom: 17.8,
          renderClusterMarker: _renderClusterMarker
        })
      } catch (err) {
        throw new Error(err)
      }
    },

    // 覆盖物移除
    remove() {
      this.GDMap.clearMap()
      for (const item in this.entity) {
        this.entity[item] = []
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  #GMap {
    width: 100%;
    height: 100%;

  }
  ::v-deep {

    .content-window-card {
        position: relative;
        box-shadow: none;
        bottom: 0;
        left: 0;
        width: auto;
        padding: 0;
        p {
          height: 2rem;
        }
        .custom-info {
          border: solid 1px silver;
        }

        div.info-top {
            position: relative;
            background: none repeat scroll 0 0 #1a3c97;
            border-bottom: 1px solid #3a89c2;
            border-radius: 5px 5px 0 0;
        }

        div.info-top div {
            display: inline-block;
            color: #fff;
            font-size: 14px;
            font-weight: bold;
            line-height: 31px;
            padding: 0 10px;
        }
         div.info-bottom {
            height: 0px;
            width: 100%;
            clear: both;
            text-align: center;
            height: 5px;
        }
        div.info-middle {
            font-size: 14px;
            padding: 10px 6px;
            line-height: 28px;
            text-align: left;
            color:#fff;
            span{
              text-decoration: underline;
              cursor: pointer;
              text-align: center;
              display: block;
            }
        }
        .alarm-triangle{
            margin-left: 5px;
            width: 0;
            height: 0;
            border-right: 10px solid transparent;
            border-left: 10px solid transparent;
            border-bottom: 14px solid transparent;
            display: inline-block;
            cursor: pointer;
        }
        .info-window-arrow {
          width: 0;
          height: 0;
          border-right: 10px solid transparent;
          border-left: 0px solid transparent;
          border-top: 14px solid #1a3c99;
          color: hsl(224deg 71% 35%);
          display: inline-block;
          transform: translateX(50%);
        }
    }

  }
  ::v-deep .amap-ui-control-theme-user-zoom{
    // top:10px;
    border-color: transparent;
    .amap-ui-control-zoom {
      border-color: transparent;
      a{
        background: transparent;
        border-color: transparent;
        color: #0f1f30;
      }
    }
  }
</style>
