<!--
 * @Author: 刘彦宏
 * @Date: 2020-10-20 16:55:20
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-22 17:20:44
 * @Description: file content
-->
<template>
  <el-dialog
    :title="title"
    :visible.sync="myVisible"
    :modal-append-to-body="false"
    :before-close="handleClose"
    :width="width"
  >

    <el-form ref="ruleForm" label-width="25%" :model="formData" :rules="rulesData">
      <el-row>
        <!-- formItems的key对应配置中的id,当select没有值时，给select赋值label相当于给v-model赋值label中文 -->
        <div v-for="(item, index) in formItems" :key="index">
          <el-col :span="span">
            <el-form-item :label="item.label" :prop="item.key">
              <!-- inputType只支持textarea -->
              <el-input
                v-if="item.inputType !== 'select'"
                v-model="formData[item.key]"
                :type="item.inputType ? item.inputType : ''"
                class="form-input"
                size="mini"
                :placeholder="`${$t('public.pleaseInput')}${item.label}`"
                :disabled="isDisableInput(item)"
              />
              <el-select
                v-else-if="item.inputType === 'select'"
                v-model="formData[item.key]"
                class="form-input"
                size="mini"
                :placeholder="`${$t('public.pleaseSelect')}${item.label}`"
                :disabled="isDisableInput(item)"
                @change="handleChange($event,item)"
              >
                <el-option
                  v-for="(op,i) in item.options"
                  :key="`op${i}`"
                  :label="op.label"
                  :value="op.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
        </div>
      </el-row>
    </el-form>
    <span v-if="dialogType !== 0" slot="footer" class="dialog-footer">
      <el-button class="zt-button" @click="handleClose">{{ $t('public.cancel') }}</el-button>
      <el-button type="primary" @click="formSubmit">{{ $t('public.confirm') }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  name: 'ActionDialog',
  props: {
    width: {
      type: String,
      default: () => {
        return '50%'
      }
    },
    span: {
      type: Number,
      default: () => {
        return 12
      }
    },
    formItems: {
      type: Array,
      default: () => {
        // return [{ label: '默认label', key: 'test' }]
      }
    },
    formData: {
      type: Object,
      default: () => {
        // return { test: '123' }
      }
    },
    rulesData: {
      type: Object,
      default: () => {
        return {
          // 'rtype': [
          //   { required: true, message: '请输入活动名称', trigger: 'blur' }
          // ],
          // 'metric': [
          //   { required: true, message: '请输入指标', trigger: 'blur' }
          // ]
        }
      }
    },
    title: {
      type: String,
      default: ''
    },
    // 0：详情，1：添加，2：修改
    dialogType: {
      type: Number,
      default: 0
    },
    visible: {
      type: Boolean,
      default: false
    },
    colNum: {
      type: Number,
      default: 2
    }
  },
  data() {
    return {
      myVisible: this.visible
    }
  },
  computed: {
    isDisableInput() {
      return function(item) {
        return this.dialogType === 0 || item.needDisabled
      }
    }
  },
  methods: {
    formSubmit() {
      this.$emit('submit', this.formData)
    },
    handleClose() {
      this.myVisible = false
      this.$emit('handleClose', false)
    },
    handleChange(e, { options, otherKeys, key }) {
      const obj = options.find(i => i.value === e)
      if (obj && otherKeys) {
        otherKeys.forEach(item => {
          this.formData[item] = obj.label
        })
      }
      this.$emit('handleEvent', {
        item: this,
        id: otherKeys || key,
        params: e
      })
    },
    reset() {
      Object.keys(this.formData).forEach(item => {
        this.formData[item] = ''
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.form-input{
  width: 90%;
}
</style>
