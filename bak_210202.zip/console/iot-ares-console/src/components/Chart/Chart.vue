<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-07 10:39:17
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-25 18:39:03
 * @Description: file content
-->
<template>
  <div class="chart-parent">
    <!-- <div class="chart-title-slot">分布</div> -->
    <div class="chart-title-slot">
      <slot />
    </div>
    <div :id="id" class="chart" style="width: 100%" />
  </div>

</template>

<script>
import echarts from 'echarts'
import 'echarts-liquidfill'
export default {
  name: 'Chart',
  props: {
    optionsData: {
      type: Object,
      default: null
    },
    id: {
      type: String,
      default: 'chart'
    },
    sideBarOpend: {
      type: Boolean,
      default: false
    },
    updateTime: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      chart: null,
      theme: require('./theme.json'),
      tableHeaderArr: []
    }
  },
  watch: {
    sideBarOpend: {
      handler: function(newVal, oldVal) {
        setTimeout(() => {
          this.chart && this.chart.resize()
        }, 300)
      }
    },
    updateTime: {
      handler() {
        this.optionsData.type === 'chart' && setTimeout(() => {
          this.drawEcharts()
        }, 400)
        this.chart && this.chart.resize()
      }
    }
  },
  mounted() {
    this.optionsData.type === 'chart' && setTimeout(() => {
      this.drawEcharts()
    }, 400)
    this.$bus.$on('resize', () => {
      this.chart && this.chart.resize()
    })
  },
  updated() {
    this.optionsData.type === 'chart' && setTimeout(() => {
      this.drawEcharts()
    }, 400)
    this.chart && this.chart.resize()
  },
  methods: {
    drawEcharts() {
      echarts.registerTheme('walden', this.theme)
      const chartElement = document.getElementById(this.id)
      if (chartElement) {
        this.chart = echarts.init(document.getElementById(this.id), 'walden')
        this.chart.setOption(this.optionsData.options, true)
      }
    },
    getTableHeaderKey() {
      this.optionsData.options.tableHeader.forEach(item => {
        this.tableHeaderArr.push(item.key)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
  .chart-parent {
    height: calc((100vh - 115px)/3);
    position: relative;
    .chart-title-slot {
      color: #fff;
      position: absolute;
      top: 15px;
      font-weight: 600;
      left: 15px;
    }
  }
  .chart {
    // background-image: url('../../assets/chartbox.png');
    width: 100%;
    height: 100%;
    // background-repeat: round;
    // padding: 10px 10px 20px;
  }
  .largeWidth {
    width: calc((100vw - #{$sideBarWidth} - 55px)/3);
    div {
      margin: 0 auto;
    }
  }
  .smallWidth {
    width: calc((100vw - #{$sideBarHideWidth} - 55px)/3);
    div {
      margin: 0 auto;
      color: #89bd0245
    }
  }
</style>
