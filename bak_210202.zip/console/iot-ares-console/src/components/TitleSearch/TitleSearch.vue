<!--
 * @Author: 张通
 * @Date: 2020-09-14 14:24:47
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-22 15:04:53
 * @Description: file content
-->

<template>
  <el-row class="titleSearch">
    <el-form ref="form" :model="searchModel" label-width="10px" size="mini" :class="{formSearch:isFromDisplay}">
      <template v-for="(item,index) in searchData">
        <el-col v-if="item.searchCondition" :key="`item${index}`" :span="item.searchType === 'rangeDate' ? sidebar.opened ? 6 : 5.5 : 3">
          <el-form-item :prop="item.id">
            <!-- Number类型 -->
            <el-input v-if="(item.type === 'short' || item.type === 'int' || item.type === 'long')" v-model.number="searchModel[item.id]" clearable :placeholder="`${$t('public.pleaseInput')}${item.name}`" />
            <!-- 文本框类型 -->
            <el-input v-if="(item.type === 'text' || item.type === 'json' || item.type === 'string')" v-model="searchModel[item.id]" clearable :placeholder="`${$t('public.pleaseInput')}${item.name}`" />
            <!-- 下拉框类型 -->
            <el-select v-else-if="item.searchType === 'select'" v-model="searchModel[item.id]" clearable :placeholder="`${$t('public.pleaseSelect')}${item.name}`">
              <el-option v-for="(op,i) in item.option" :key="`op${i}`" :label="op.label" :value="op.value" />
            </el-select>
            <!-- 范围日期选择类型 -->
            <el-date-picker
              v-else-if="item.searchType === 'rangeDate'"
              v-model="searchModel.TIME"
              type="datetimerange"
              :range-separator="$t('public.to')"
              :start-placeholder="$t('public.startDate')"
              :end-placeholder="$t('public.endDate')"
            />
          <!-- 扩展列展示 -->
          </el-form-item>
        </el-col>
      </template>
      <el-col class="button" :span="4">
        <el-button type="primary" size="mini" @click="handlerSearch">{{ $t('public.search') }}</el-button>
        <el-button size="mini" class="reset" @click="Handlerreset">{{ $t('public.reset') }}</el-button>
      </el-col>
    </el-form>
  </el-row>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  props: {
    // 搜索框渲染对象
    searchData: {
      type: Array,
      default: () => []
    },
    defaultModel: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      value: '',
      // 搜索框各字段父及对象
      searchModel: {
        TIME: [] // 日期字段 不能与后端传来动态字段相同，原因是日期组件渲染问题，需要做一次转换嫁接
      }
    }
  },
  computed: {
    // from 是否为flex布局 根据 searchData 的长度确定
    isFromDisplay() {
      if (this.searchData.length <= 7) {
        return true
      } else {
        return false
      }
    },
    ...mapGetters([
      'sidebar'
    ])
  },
  watch: {
    defaultModel: {
      handler(n, o) {
        this.$nextTick(() => {
          this.searchModel = Object.assign({}, this.searchModel, n)
        })
      }
    }
  },
  methods: {
    // 搜索
    handlerSearch() {
      const obj = { ...this.searchModel, rangeDate: this.searchModel.TIME }
      if (Object.keys(obj).length > 0) {
        Object.keys(obj).forEach(item => {
          if (!obj[item] || obj[item] === '' || obj[item].length <= 0) {
            delete obj[item]
          }
        })
      }
      delete obj.TIME
      this.$emit('search', obj)
    },
    // 重置
    Handlerreset() {
      let status = false
      for (const item in this.searchModel) {
        if (this.searchModel[item]) {
          status = true
        }
      }
      if (!status) return
      this.reset()
      this.$nextTick(() => {
        this.handlerSearch()
      })
    },
    reset() {
      Object.keys(this.searchModel).forEach(item => {
        this.searchModel[item] = ''
      })
    }
  }
}
</script>

<style lang="scss">
  $col: #fff;
  $borBg: #409EFF;
  .titleSearch {
    .el-input__inner {
      background: none;
      // border: 1px solid $borBg;
      color: $col;
    }
    .el-select {
      width: 100%;
    }
    // .el-range-input {
    //   background: none;
    //   color: $col;
    // }
    .el-range-separator {
      color: $col;
    }
    .el-select .el-input .el-select__caret {
      color: $borBg;
    }
  }
</style>

<style lang="scss" scoped>
$col: #fff;
$borBg: #409EFF;
// 动态样式
  .formSearch {
      display: flex;
      align-items: center;
      flex-direction: row;
      height: 100%;
  }
.titleSearch {
    padding: 0;
    height: 60px;
  .el-form {
    .el-form-item--mini.el-form-item, .el-form-item--small.el-form-item {
      margin-bottom: 0;
    }
  }
  .button {
    display: flex;
    justify-content: flex-start;
    margin-left: 10px;
    .el-button--mini, .el-button--mini.is-round {
      padding: 7px 30px;
    }
    .reset {
      background: none;
      color: $col;
      border: 1px solid $borBg;
    }
  }
}
</style>
