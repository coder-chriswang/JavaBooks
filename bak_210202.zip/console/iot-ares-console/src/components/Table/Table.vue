<!--
 * @Author: 张通
 * @Date: 2020-09-14 14:24:47
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-21 15:03:20
 * @Description: file content
-->
<!--
Table组件使用注意事项(必须在外面写一个固定大小的盒子包裹Table组件)
1、pagination 值为true 时，分页才能够有作用，分页对应的方法才能够使用
2、组件tableData、tableHeader 为必穿参数
3、组件table title label字段为label
4、组件table value 字段为 prop
-->
<template>
  <div class="Table">
    <header :class="{headers: !pagination}">
      <div v-if="tableTitle" class="chart-table-title">{{ tableTitle }}</div>
      <el-table
        ref="singleTable"
        v-loading="loading"
        :element-loading-text="$t('public.loading')"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.6)"
        row-class-name="tableRowClass"
        :highlight-current-row="highlightCurrentRow"
        :data="tableData"
        height="100%"
        style="width: 100%"
        :size="tableSize"
        :cell-style="cellStyle"
        @row-click="rowClick"
        @selection-change="handleSelectionChange"
        @expand-change="expandChange"
      >
        <el-table-column
          v-if="showSelection"
          type="selection"
          width="55"
        />

        <el-table-column v-if="expand" fixed="left" type="expand">
          <template slot-scope="props">
            <el-row>
              <el-form label-position="left" inline class="demo-table-expand">
                <el-col v-for="(item,index) in expandData" :key="`expand${index}`" :span="8">
                  <el-form-item :label="item.label+ '：'">
                    <span>{{ props.row[item.key]||$t('public.No') }}</span>
                  </el-form-item>
                </el-col>
              </el-form>
            </el-row>

          </template>
        </el-table-column>
        <el-table-column v-if="expandTable" fixed="left" type="expand">
          <template slot-scope="props">
            <!-- {{ JSON.stringify(props.row['ruleList']) }}
            {{ JSON.stringify(expandTableHeader) }} -->
            <Table
              :table-header="expandTableHeader"
              :table-data="props.row['ruleList']"
              :pagination="false"
              :highlight-current-row="false"
              :cell-border-style="false"
              :show-selection="false"
              :last-table-column="true"
            ><template slot-scope="scope">
              <div>
                <el-button
                  v-for="(item,index) in expandActBtnOptions"
                  :key="index"
                  type="text"
                  class="table-text-btn"
                  @click="handleCommand([item.type, scope.scope.row,props.row])"
                >{{ item.label }}</el-button>
              </div>
            </template></Table>
          </template>
        </el-table-column>
        <template
          v-for="(item,index) in tableHeader"
        >
          <!-- hideInTable用于隐藏列，设置为true则不在表格中显示
          customize自定义table column，外部使用slot对应的tableHeader的id
          <template slot="user" slot-scope="scope">
            <span>用户</span>
          </template>
          -->
          <el-table-column
            v-if="(!item.hideInTable)&&(!item.customize)"
            :key="index"
            align="center"
            :min-width="item.width ? item.width : `182`"
            :prop="item.id"
            :label="item.name"
          />

          <!-- 自定义内容列 -->
          <el-table-column
            v-if="!!item.customize"
            :key="index"
            align="center"
            :min-width="item.width ? item.width : `182`"
            :prop="item.id"
            :label="item.name"
          >
            <template slot-scope="scope">
              <slot :scope="scope" :name="item.id" :option="item" />
            </template>
          </el-table-column>
        </template>
        <el-table-column v-if="lastTableColumn" fixed="right" align="center" :label="$t('sidebar.operation')" :width="lastColumnWidth">
          <template slot-scope="scope">
            <slot :scope="scope" />
          </template>
        </el-table-column>
      </el-table>
    </header>
    <footer v-if="pagination">
      <el-pagination
        class="pagination"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </footer>
  </div>
</template>

<script>
export default {
  name: 'Table',
  components: {},
  props: {
    // pageSizes
    pageSizes: {
      type: Array,
      default: () => [10, 20, 40, 80]
    },
    // pageSize
    pageSize: {
      type: Number,
      default: () => 10
    },
    // 分页总数
    total: {
      type: Number,
      default: () => 0
    },
    // 当前页
    currentPage: {
      type: Number,
      default: () => 1
    },
    // 表格size
    tableSize: {
      type: String,
      default: () => 'small'
    },
    // 是否展示分页
    pagination: {
      type: Boolean,
      default: () => true
    },
    // tableData
    tableData: {
      type: Array,
      default: () => []
    },
    tableTitle: {
      type: String,
      default: () => null
    },
    // tableHader
    tableHeader: {
      type: Array,
      default: () => []
    },
    // 展开列tableHader
    expandTableHeader: {
      type: Array,
      default: () => []
    },
    expandActBtnOptions: {
      type: Array,
      default: () => []
    },
    // 高亮当前选中行
    highlightCurrentRow: {
      type: Boolean,
      default: () => true
    },
    cellBorderStyle: {
      type: Boolean,
      default: () => true
    },
    // 是否展示table最后列  当lastTableColumn为 true 时， slot才能起作用
    lastTableColumn: {
      type: Boolean,
      default: () => true
    },
    loading: {
      type: Boolean,
      default: () => false
    },
    lastColumnWidth: {
      type: String,
      default: () => '200'
    },
    // value  为true 时，可选择， 触发事件 selection-change
    showSelection: {
      type: Boolean,
      default: () => false
    },
    // 是否显示展开行
    expand: {
      type: Boolean,
      default: () => false
    },
    expandTable: {
      type: Boolean,
      default: () => false
    },
    // 默认选中行参数   row 每一项需要与 table行一样
    selectionRow: {
      type: Array,
      default: () => []
    },
    // 展开行所需数据
    expandData: {
      type: Array,
      default: () => [
        // {
        //   label: '姓名',
        //   key: 'name'
        // },
        // {
        //   label: '日期',
        //   key: 'name'
        // }
      ]
    }
  },
  data() {
    return {
      page: {
        currentPageNum: this.currentPage,
        pageSizeNum: this.pageSize
      }
    }
  },
  watch: {
    pageSize: {
      handler(val) {
        this.page.pageSizeNum = val
      }
    },
    selectionRow: {
      handler(val) {
        if (val.length > 0) {
          this.toggleSelection(val)
        } else {
          this.toggleSelection()
        }
      },
      deep: true
    }
  },
  methods: {
    // 展开行的操作列事件
    handleCommand(e) {
      this.$emit('handle-expand-command', e)
    },
    // 单元格样式
    cellStyle() {
      if (!this.cellBorderStyle) return
      return {
        borderRight: '2px solid #0f1441',
        borderBottom: '2px solid #0f1441'
      }
    },
    // 每页展示的数量改变
    handleSizeChange(v) {
      this.page.currentPageNum = 1
      this.page.pageSizeNum = v
      this.$emit('pagination-change', this.page)
    },
    // 当前页数改变
    handleCurrentChange(v) {
      this.page.currentPageNum = v
      this.$emit('pagination-change', this.page)
    },
    rowClick(newRow, column) {
      if (this.highlightCurrentRow) {
        this.$emit('handler-row', newRow, column)
      }
    },
    // 多选
    handleSelectionChange(val) {
      if (this.showSelection) {
        this.$emit('selection-change', val)
      }
    },
    // expandTable 点击展开行事件
    expandChange(row, expandedRows) {
      this.$emit('expand-change', { row, expandedRows })
    },
    // 默认选中行
    toggleSelection(rows) {
      this.$nextTick(() => {
        if (rows) {
          rows.forEach(row => {
            this.$refs['singleTable'].toggleRowSelection(row)
          })
        } else {
          this.$refs['singleTable'].clearSelection()
        }
      })
    }
  }
}
</script>

<style lang="scss">
.headers {
  height: 88% !important;
}
.Table {
  height: 100%;
  header {
    height: calc(100% - 40px);
  }
  footer {
    display: flex;
    align-items: flex-end;
    justify-content: flex-end;
    height: 40px;
  }

  // pagination style start
  .pagination {
    color: #ffffff;

  }
  // pagination style end
  .chart-table-title{
    color:#fff;font-size:18px;line-height:28px;
  }
}
</style>
