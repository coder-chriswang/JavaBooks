<template>
  <el-dropdown trigger="click" style="line-height: 15px;">
    <span class="alarm_outter" :title="$t('navbar.alarm')">
      <span class="iconfont icon-alarm help" :style="{color:colorSeverity&&alarmSeverityMap[colorSeverity][1]}">
        <!-- {{ $t('navbar.alarm') }} -->
      </span>
      <span class="alarm_num">{{ alarmTotal>99?'99+':alarmTotal }}</span>
    </span>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item v-if="colorSeverity===-1">{{ $t('public.currentWithoutWarning') }}</el-dropdown-item>
      <template v-else>
        <el-dropdown-item v-for="item in alarmInfo" :key="item.name" :style="{color:item.color}" @click.native="jumpToAlarm(item)">
          <span class="iconfont icon-alarm help" />&nbsp;&nbsp;{{ item.name }} {{ item.count }}
        </el-dropdown-item>
      </template>
    </el-dropdown-menu>
  </el-dropdown>

</template>
<script>
export default {
  props: {
    severityAndCountVos: {
      type: Array,
      default: () => ([])
    },
    colorSeverity: {
      type: Number,
      default: () => (1)
    }
  },
  data() {
    return {
      alarmSeverityMap: {
        4: [this.$t('statistics.emergency'), '#ff0000'],
        3: [this.$t('statistics.serious'), '#fe7506'],
        2: [this.$t('statistics.general'), '#fced02'],
        1: [this.$t('statistics.prompt'), '#fcf4cf'],
        '-1': [this.$t('public.normal'), '#07c118']
      }
    }
  },
  computed: {
    alarmTotal() {
      if (!this.severityAndCountVos) return 0
      return this.severityAndCountVos.reduce((pre, cur) => pre + cur.count, 0)
    },
    alarmInfo() {
      const alarmInfo = []
      this.severityAndCountVos.forEach(item => {
        alarmInfo.push({
          ...item,
          name: this.alarmSeverityMap[item.severity][0],
          color: this.alarmSeverityMap[item.severity][1]
        })
      })
      return alarmInfo
    }
  },
  methods: {
    jumpToAlarm(row) {
      console.log('row', row)

      this.$router.push({ path: '/alarm?' + Date.now(), query: { severity: row.severity }})
    }
  }
}
</script>

<style lang="scss" scoped>
.alarm_outter{
  &:hover{
    background-color: #404040;
  }
  padding:5px;
  margin-right: 20px;
  border-radius: 5px;
  cursor:pointer;
  .help {
    font-size: 14px;
    color: #fff;
    user-select:none;
    line-height: 15px;
    display: inline-block;
    margin-right: 5px;
  }
.alarm_num{
    display: inline-flex;
    justify-content: center;
    align-items: center;
    height: 14px;
    line-height: 14px;
    padding: 4px;
    min-width: 16px;
    color: #fff;
    background-color: crimson;
    font-weight: bold;
    font-size: 12px;
    border-radius: 40%;
    position: relative;
    bottom: 1px;
}
}

</style>
