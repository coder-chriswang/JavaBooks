<!--
 * @Author: 张通
 * @Date: 2020-09-15 19:07:28
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-17 11:18:27
 * @Description: file content
-->
<template>
  <div class="titleRightButton">
    <el-button v-for="(item,index) in staticProp" :key="`but${index}`" type="primary" size="mini" @click="handlerButton(item)">{{ item.name }}</el-button>
  </div>
</template>
<script>

export default {
  components: {

  },
  props: {
    staticProp: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
    }
  },

  mounted() {

  },
  methods: {
    handlerButton(val) {
      this.$emit('hander-button', val)
    }
  }
}
</script>
<style lang="scss" scoped>
.titleRightButton {
    position: absolute;
    right: 0px;
    top: 0;
    height: 40px;
    display: flex;
    flex-direction: row;
    align-items: center;
    .el-button+.el-button {
      height: 28px;
    }
}
</style>
