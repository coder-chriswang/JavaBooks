<!--
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-21 10:10:39
 * @Description: file content
-->
<template>
  <div class="breadcrumb" :class="containerClass">
    <el-button v-if="showBack" type="text" icon="el-icon-arrow-left" @click="goBack">{{ $t('navbar.back') }}</el-button>
    <el-divider direction="vertical" class="vertical" />
    <span>{{ context }}</span>
    <slot />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'Breadcrumb',
  props: {
    showBack: {
      type: Boolean,
      default: false
    },
    context: {
      type: String,
      default: '面包屑'
    }
  },
  data() {
    return {
      levelList: null
    }
  },
  computed: {
    ...mapGetters([
      'sidebar'
    ]),
    containerClass() {
      return {
        rightContainerHideSidebar: !this.sidebar.opened,
        rightContainerShowSidebar: this.sidebar.opened
      }
    }
  },
  created() {
  },
  methods: {
    goBack() {
      this.$emit('handleBack')
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.breadcrumb {
  color: #ffffff;
  line-height: 43px;
  padding-left: 40px;
  font-size: 14px;
  .vertical {
    border: $linghtBlue1 1px solid
  }
}
</style>
