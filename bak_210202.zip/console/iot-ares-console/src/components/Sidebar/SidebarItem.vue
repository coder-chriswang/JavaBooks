<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-25 15:46:48
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-14 14:16:21
 * @Description:
-->
<template>
  <div class="menu-item-div">
    <template v-if="item.display===undefined?true:item.display">
      <template v-if="!item.children">
        <el-tooltip class="item" effect="dark" :content="item.label" placement="right" :disabled="sidebar.opened">
          <li :style="indent" class="menu-item" :title="sidebar.opened&&item.label" :class="{'is-active': active}" @click="menuActive(item)">

            <i v-if="item.icon" class="menu-icon iconfont" :class="item.icon" />
            <div class="menu-title-container"><span>{{ item.label }}</span></div>
          </li>
        </el-tooltip>
      </template>
      <ul v-else class="submenu-item">
        <el-tooltip class="item" effect="dark" :content="item.label" placement="right" :disabled="sidebar.opened">
          <li :style="indent" class="submenu-item-title" :title="sidebar.opened&&item.label" :class="{'is-active': active}" @click="menuActive(item)">
            <i v-if="item.icon" class="menu-icon iconfont" :class="item.icon" />
            <div class="menu-title-container">
              <span>{{ item.label }}</span>
            </div>
            <i v-if="item.children" :class="arrow" class="arrow" />
          </li>
        </el-tooltip>
        <template v-if="opend">
          <SidebarItem
            v-for="child in item.children"
            :key="child.id"
            :is-nest="true"
            :parent-id="child.id"
            :parent-ids="[...parentIds,child.id]"
            :item="child"
            :depth="depth + 1"
            :class="nestMenu"
          />
        </template>
      </ul>
    </template>
  </div>
</template>

<script>
import request from '@/utils/request'
import Emitter from '@/utils/emitter'
import { mapGetters } from 'vuex'
export default {
  name: 'SidebarItem',
  mixins: [Emitter],
  props: {
    item: {
      type: Object,
      default: () => {}
    },
    isNest: {
      type: Boolean,
      default: false
    },
    optional: {
      type: Boolean,
      default: true
    },
    // eslint-disable-next-line vue/require-default-prop
    parentId: [String, Number, Object],
    parentIds: {
      type: Array,
      default: () => { return [] }
    },
    depth: {
      type: Number,
      default: 0
    },
    isShowNest: {
      type: Boolean,
      default: false
    }
  },
  inject: ['rootMenu'],
  data() {
    return {
      opend: true
    }
  },
  computed: {
    ...mapGetters(['sidebar']),
    indent() {
      return `padding-left:${this.depth * 20 + 20}px`
    },
    arrow() {
      return this.opend ? 'el-icon-arrow-up' : 'el-icon-arrow-down'
    },
    active() {
      return this.item.id === this.rootMenu.activeMenuId
    },
    nestMenu() {
      return this.opend ? 'nest-menu' : 'hide-menu'
    }
  },
  mounted() {
    if (this.item.id !== this.rootMenu.activeMenuId) {
      this.opend = false
    } else {
      this.$nextTick(() => {
        let head = this
        while (head.depth !== 0) {
          head = head.$parent
          head.opend = true
        }
      })
    }
  },
  methods: {
    async menuActive(item) {
      if (item.url) {
        const requestParam = {
          url: item.url,
          method: item.method,
          data: item.data ? item.data : {}
        }
        const res = await request(requestParam)
        // eslint-disable-next-line require-atomic-updates
        item.children = []
        res.data.length > 0 && res.data.forEach(re => {
          item.children.push({
            ...re,
            label: re.name,
            isActive: true,
            id: `${this.parentId}-${re.id}`,
            parentIds: this.parentIds
          })
        })
        this.opend = !this.opend
      } else {
        this.opend = !this.opend
        // leaf 为true时  触发抛事假
        if (!item.children || item.children.length === 0 || item.needActive || item.leaf) {
          this.dispatch('Sidebar', 'item-click', item)
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.menu-item-div{
  background: $darkBlue3;
  user-select: none;
  color: $light_gray;
  font-size: 14px;
  .submenu-item-title{
    span {
      width: 122px;
    }
  }
  li {
    list-style-type:none;
    cursor: pointer;
    span {
      // width: 112px;
      width: calc(100% - 0px);
      min-width: 0;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
    .menu-title-container {
      display: inline-flex;
      // flex: 1;
      max-width: 155px;
      width: calc(100% - 0px);
    }
  }
  ul {
    margin: 0;
    padding: 0;
  }
}
.menu-item, .submenu-item-title{
  line-height: 50px;
  background: $darkBlue1;
  display: inline-flex;
    justify-content: space-between;
    width:100%;
}
.menu-item:hover, .submenu-item-title:hover{
  background: $linghtBlue3;
}
.nest-menu{
  .menu-item:hover, .submenu-item-title:hover{
    background: $darkBlue5;
  }
}
.nest-menu{
  .menu-item, .submenu-item-title{
    background: $darkBlue3;
  }
}

.is-active{
  background: $linghtBlue2;
}
.nest-menu{
  .is-active{
    color: $linghtBlue2;
  }
}
.arrow {
  float: right;
  padding-right: 20px;
  line-height: 50px;
}
.hide-menu{
  display: none;
}
</style>
