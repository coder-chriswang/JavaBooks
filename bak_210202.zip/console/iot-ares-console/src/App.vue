<!--
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-12 17:25:46
 * @Description: file content
-->
<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import { getLocale } from '@/api/user'
import { getLanguage } from '@/lang/index'
import elementEnLocale from 'element-ui/lib/locale/lang/en' // element-ui lang
import elementZhLocale from 'element-ui/lib/locale/lang/zh-CN'// element-ui lang
import enLocale from '@/lang/en'
import zhLocale from '@/lang/zh'
export default {
  name: 'App',
  mounted() {
    window.onresize = () => {
      this.$bus.$emit('resize')
    }
  },
  created() {
    const lang = getLanguage()
    const localFromServe = JSON.parse(localStorage.getItem(lang))
    const elementLocal = lang === 'en' ? elementEnLocale : elementZhLocale
    const frontLocal = lang === 'en' ? enLocale : zhLocale
    let messages = {
      ...elementLocal,
      ...frontLocal,
      ...localFromServe
    }
    // storage里有语言数据则直接覆盖否则查询后端接口
    if (localFromServe) {
      this.$i18n.setLocaleMessage(lang, messages)
    } else {
      getLocale().then(res => {
        messages = {
          ...elementLocal,
          ...frontLocal,
          ...res.data
        }
        this.$i18n.setLocaleMessage(lang, messages)
        localStorage.setItem(getLanguage(), JSON.stringify(res.data))
      }).catch(e => {
        console.log('GET LOCALE JSON FAILED!')
      })
    }
  }
}
</script>
