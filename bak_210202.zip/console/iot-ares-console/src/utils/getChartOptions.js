
/*
* chartData 后端接口数据
* chartType 图类型：'line','bar'
* 生成柱状图或折线图的option配置
*/
function lineOrBarChart(chartData, chartType, defaultDataZoom = 5) {
  const dataZoomconfig = function(v) {
    return {
      show: chartData.data.xData.length > v,
      end: v / chartData.data.xData.length * 100
    }
  }

  const option = {
    dataLength: chartData.data.xData.length,
    color: chartType === 'bar' ? (chartData.chartColor || '') : ['#4ecd66',
      '#e0442a',
      '#9d9ea0'],
    title: { // 标题
      // top: 20,
      text: chartData.chartTitle,
      textStyle: {
        fontWeight: 'normal',
        color: chartData.chartTitleColor || '#fff',
        fontSize: 16
      },
      left: '1%'
    },
    dataZoom: [
      {
        show: dataZoomconfig(defaultDataZoom).show,
        handleSize: 20,
        realtime: true,
        start: 0,
        end: dataZoomconfig(defaultDataZoom).end,
        height: 12,
        bottom: 5,
        left: 40,
        right: 40,
        showDetail: false,
        xAxisIndex: [0, 0]
      },
      {
        type: 'inside',
        realtime: true,
        start: 0,
        end: 100,
        xAxisIndex: [0, 0]
      }
    ],
    tooltip: { // 鼠标悬浮显示
      trigger: 'axis',
      fontSize: 24,
      formatter: function(params) {
        let line = ''
        params.forEach((item, index) => {
          if (index === 0) line += item.name + ': ' + '<br>'
          line += item.marker + '  ' + item.seriesName + (item.value !== undefined ? (' (' + item.value + (~chartData.data.yUnit.indexOf('%') ? '%' : '') + ')') : '') + '<br>'
        })
        return line
      },
      transitionDuration: 0
    },
    legend: { // 图例
      top: 20,
      // icon: 'rect',
      itemWidth: 14,
      itemHeight: 5,
      itemGap: 13,
      data: chartData.data.legend.nameArr,
      right: '4%',
      textStyle: {
        fontSize: 12
      }
    },
    grid: { // 画布布局
      left: '8%',
      right: '8%',
      bottom: '25',
      containLabel: true
    },
    xAxis: [{ // X轴
      type: 'category', // 轴类型： 'value','category','time','log'
      boundaryGap: chartType === 'bar',
      data: chartData.data.xData,
      axisLabel: {
        rotate: chartData.data.xData.length > 4 ? 10 : 0,
        interval: chartData.data.xData.length > 5 ? 'auto' : 0
      }
    }],
    yAxis: [{ //    Y轴
      type: 'value',
      name: chartData.data.yUnit, // 轴数据单位
      nameTextStyle: { color: '#FFFFFF' },
      axisTick: {
        show: false
      },
      axisLabel: {
        margin: 10,
        textStyle: {
          fontSize: 14
        }
      }
    }],
    series: []
  }
  // 限制最多6条数据
  const seriesNum = chartData.data.legend.keyArr.length < 6 ? chartData.data.legend.keyArr.length : 6
  for (let i = 0; i < seriesNum; i++) {
    const serie = {
      name: chartData.data.legend.nameArr[i],
      type: chartType, // 'line': 折线图，'bar': 柱状图
      stack: chartType === 'bar' ? chartData.data.legend.nameArr[0] : null,
      barMaxWidth: chartType === 'bar' ? 50 : null,
      smooth: true,
      symbol: 'circle',
      symbolSize: 5,
      showSymbol: true,
      lineStyle: {
        normal: {
          width: 1
        }
      },
      // data: [0, 100, 50]
      data: chartData.data.yData[chartData.data.legend.keyArr[i]]
    }
    option.series.push(serie)
  }
  return option
}

/**
 *  仪表盘chart配置方法
 *
 */
function gaugeChart(chartData) {
  return {
    dataLength: chartData.data.length,
    title: { // 标题
      // top: 20,
      text: chartData.chartTitle,
      textStyle: {
        fontWeight: 'normal',
        fontSize: 16
      },
      left: '1%'
    },
    tooltip: {
      fontSize: 24,
      formatter: '{a} <br/>{b} : {c}' + (chartData.data ? chartData.data[0].unit : '个'),
      transitionDuration: 0 // tooltip 浮层移动时间 为0 时跟随鼠标移动
    },
    series: [
      {
        name: chartData.chartTitle,
        type: 'gauge',
        center: ['50%', '60%'], // 默认全局居中
        radius: '100%',
        startAngle: 200,
        endAngle: -20,
        axisLine: { // 坐标轴线          // 坐标轴线
          lineStyle: { // 属性lineStyle控制线条样式
            color: [[1, '#008ACD']],
            width: 2
            // shadowColor: '#fff', // 默认透明
            // shadowBlur: 10
          }
        },
        axisTick: {
          length: 5
        },

        splitLine: { // 分隔线
          length: 10, // 属性length控制线长
          lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
            color: 'auto'
          }
        },
        pointer: {
          width: 2,
          shadowColor: '#fff', // 默认透明
          shadowBlur: 5
        },
        title: {
          show: false
        },
        detail: {
          formatter: '{value} ' + (chartData.data ? chartData.data[0].unit : '个'),
          color: '#eee',
          fontSize: 20
        },
        max: chartData.data ? chartData.data[0].max : 100,
        splitNumber: chartData.data ? chartData.data[0].splitNumber : 5,
        data: chartData.data
      }
    ]
  }
}

/**
 * 饼图chart配置方法
 */
function pieChart(chartData, chartType) {
  return {
    color: chartData.chartColor || '',
    dataLength: chartData.data.series.pieData.length,
    title: {
      text: chartData.chartTitle,
      // subtext: '纯属虚构',
      left: 'left',
      textStyle: {
        fontWeight: 'normal',
        color: chartData.chartTitleColor || '#fff'
      }
    },
    tooltip: {
      trigger: 'item',
      formatter: '{b} : {c} ({d}%)'
    },
    legend: {
      type: 'scroll',
      orient: 'vertical',
      right: 10,
      top: 20,
      data: chartData.data.legend
    },
    series: [
      {
        type: 'pie',
        radius: ['36%', '50%'],
        center: ['50%', '50%'],
        data: chartData.data.series.pieData,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0
          }
        }
      }
    ]
  }
}
function ringScreenChart(chartData, chartColor = [
  '#00baff',
  '#fec006',
  '#0072bc',
  '#bd8cbf',
  '#acd373'
]) {
  const dataArr = chartData.data.series.pieData
  dataArr.forEach(item => {
    item.value = (item === null || !item.rate) ? null : parseFloat(item.rate.replace('%', ''))
  })
  let nameLength = 0
  const dataMap = dataArr.reduce((pre, item) => {
    nameLength = Math.max(nameLength, item.name.length)
    pre[item.name] = item.rate
    return pre
  }, {})
  // const total = dataArr.reduce((pre, item) => pre + item.rate, 0)
  return {
    color: chartColor,
    dataLength: dataArr.length,
    title: {
      text: chartData.chartTitle,
      textStyle: {
        fontWeight: 'normal',
        color: chartData.chartTitleColor || '#fff',
        fontSize: 16
      },
      left: 'left'
    },
    tooltip: {
      trigger: 'item',
      formatter: '{b} ({d}%)'
    },
    legend: {
      orient: 'vartical',
      x: 'left',
      left: '44%',
      selectedMode: false,
      textStyle: {
        color: '#ffffff',
        fontSize: 12,
        height: 12,
        rich: {
          font: {
            width: 12
          }
        },
        backgroundColor: {
          image: require('../assets/screen/screenChartPieLegend.png')
        }
      },
      itemWidth: 12,
      itemHeight: 12,
      itemGap: 10,
      icon: 'circle',
      top: 'middle',
      formatter: function(name) {
        const space = '  ' + new Array(nameLength - name.length).fill('{font| }').join('')
        return `${name}${space}${dataMap[name]}`
      },
      data: chartData.data.legend
    },
    series: [
      {
        type: 'pie',
        radius: ['30%', '38%'],
        center: ['22%', '50%'],
        data: dataArr,
        hoverOffset: 5,
        label: {
          normal: {
            show: false,
            position: 'center',
            color: '#ffffff',
            rich: {
              percentValue: {
                padding: [5, 0, 0, 0],
                fontSize: 28,
                color: '#fff'
              },
              percent: {
                fontSize: 16,
                color: '#fff'
              }
            }
            // formatter: (value) => {
            //   return (
            //     '{percentValue|' + parseInt(value.percent) + '}{percent|%}')
            // }
          },
          emphasis: {
            show: false,
            textStyle: {
              fontSize: () => 14
            }
          }
        }
      }
    ]
  }
}
function liquidFillChart(chartData) {
  const chartColor = [['#4ecd66', '#3a9654'], ['#602d2d', '#81332d'], ['#4f5963', '#73797f']]
  const pieData = chartData.series.percent.map(item => item === null ? null : parseFloat(item.replace('%', '')) / 100)
  const percent = chartData.series.percent
  const names = chartData.names
  const seriesArr = pieData.map((data, index) => {
    return {
      type: 'liquidFill',
      color: [chartColor[index][0]],
      radius: '60%',
      center: [20 + 30 * index + '%', '40%'],
      data: [data],
      backgroundStyle: {
        color: 'transparent'
      },
      label: {
        normal: {
          color: 'white',
          fontSize: 13,
          formatter: (data * 100).toFixed(2) + '%'
        }
      },
      outline: {
        //  borderDistance: 5,
        itemStyle: {
          borderWidth: 2,
          borderColor: chartColor[index][0]
        }
      },
      amplitude: '4%',
      waveAnimation: true
    }
  })
  const titleArr = names.map((name, index) => {
    return {
      text: name + '：{percent|' + percent[index] + '}',
      left: (index + 1) * 33 - 16 + '%',
      top: '80%',
      textAlign: 'center',
      textStyle: {
        fontWeight: 'normal',
        fontSize: '16',
        color: '#7fa4bb',
        textAlign: 'center',
        rich: {
          percent: {
            fontSize: '16',
            color: chartColor[index][1]
          }
        }
      }
    }
  })
  return {
    title: titleArr,
    // backgroundColor: '#0f1f30',
    series: seriesArr
  }
}
function roseChart(chartData) {
  return {
    backgroundColor: '#0B1837',
    color: ['#EAEA26', '#906BF9', '#FE5656', '#01E17E', '#3DD1F9', '#FFAD05'],
    title: {
      text: '网络/安全设备',
      left: '60',
      top: 0,
      textAlign: 'center',
      textStyle: {
        color: '#fff',
        fontSize: 14,
        fontWeight: 0
      }
    },
    grid: {
      left: -100,
      top: 50,
      bottom: 10,
      right: 10,
      containLabel: true
    },
    tooltip: {
      trigger: 'item',
      formatter: '{b} : {c} ({d}%)'
    },
    legend: {
      type: 'scroll',
      orient: 'vartical',
      top: 'center',
      right: '15',
      itemWidth: 16,
      itemHeight: 8,
      itemGap: 16,
      textStyle: {
        color: '#A3E2F4',
        fontSize: 12,
        fontWeight: 0
      },
      // data: chartData.data.legend
      data: ['IDS', 'VPN', '交换机', '防火墙', 'WAF', '堡垒机']
    },
    calculable: true,
    series: [{
      stack: 'a',
      type: 'pie',
      radius: ['15%', '80%'],
      roseType: 'area',
      zlevel: 10,
      label: {
        normal: {
          show: true,
          formatter: '{c}',
          textStyle: {
            fontSize: 12
          },
          position: 'outside'
        },
        emphasis: {
          show: true
        }
      },

      // data: chartData.data.series.pieData,
      data: [{
        value: 10,
        name: 'IDS'
      },
      {
        value: 5,
        name: 'VPN'
      },
      {
        value: 15,
        name: '交换机'
      },
      {
        value: 25,
        name: '防火墙'
      },
      {
        value: 20,
        name: 'WAF'
      },
      {
        value: 35,
        name: '堡垒机'
      }
      ]
    }]
  }
}
function getChartOptions(chartData) {
  switch (chartData.chartType) {
    case 'line':
      return lineOrBarChart(chartData, chartData.chartType, chartData.dataZoomNum)
    case 'bar':
      return lineOrBarChart(chartData, chartData.chartType, chartData.dataZoomNum)
    case 'pie':
      return pieChart(chartData, chartData.chartType)
    case 'ringScreen':
      return ringScreenChart(chartData, chartData.chartColor)
    case 'liquidFill':
      return liquidFillChart(chartData)
    case 'gauge':
      return gaugeChart(chartData)
    case 'rose':
      return roseChart(chartData)
  }
}
export {
  getChartOptions
}
