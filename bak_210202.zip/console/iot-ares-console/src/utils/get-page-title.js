/*
 * @Author: 张通
 * @Date: 2020-09-07 10:41:57
 * @LastEditors: 张通
 * @LastEditTime: 2020-11-11 10:37:46
 * @Description: file content
 */
import defaultSettings from '@/settings'

const title = defaultSettings.title || 'Vue Admin Template'

export default function getPageTitle(pageTitle) {
  if (pageTitle) {
    return `${title}`
  }
  return `${title}`
}
