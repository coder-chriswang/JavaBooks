/**
 * Created by PanJiaChen on 16/11/18.
 */

/**
 * @param {string} path
 * @returns {Boolean}
 */
export function isExternal(path) {
  return /^(https?:|mailto:|tel:)/.test(path)
}

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function validUsername(str) {
  const valid_map = ['admin', 'editor']
  return valid_map.indexOf(str.trim()) >= 0
}

export function validatePort(rule, value, callback) {
  value = value.toString()
  if (value === '' || value === null) {
    rule.langStatus === 'zh' ? callback(new Error('端口不能为空！')) : callback(new Error('Port is mandatory '))
    return
  }
  const reg = /^([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/
  const falg = reg.test(value.trim())
  if (!falg) {
    rule.langStatus === 'zh' ? callback(new Error('请输入正确的端口号')) : callback(new Error('Please input a correct port No. '))
  } else {
    callback()
  }
}
export function isEmail(rule, value, callback) {
  if (value === '' || value === null) {
    rule.langStatus === 'zh' ? callback(new Error('邮箱不能为空！')) : callback(new Error('E-mail can not be empty!'))
    return
  }
  const startFalg = /^[_\.-]/.test(value.trim()) // 判断字符串开头不能为 _ . -
  const endFalg = /[_\.-]$/.test(value.split('@')[0].trim()) // 判断字符串@前不能为 _ . -
  const reg = /^[A-Za-z0-9\u4e00-\u9fa5\._-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
  const falg = reg.test(value.trim())
  if (!falg || startFalg || endFalg) {
    rule.langStatus === 'zh' ? callback(new Error('请输入正确的合法邮箱')) : callback(new Error('Please enter the correct legal email address!'))
  } else {
    callback()
  }
}
export function checkSpecificKey(str) {
  var specialKey = "[`~!#$^&*()=|{}':;',\\[\\].<>/?~！#￥……&*（）——|{}【】‘；：”“'。，、？]‘'"
  for (var i = 0; i < str.length; i++) {
    if (specialKey.indexOf(str.substr(i, 1)) !== -1) {
      return false
    }
  }
  return true
}
export function checkAccountNumber(rule, value, callback) {
  const accountNumber = (str) => {
    // [\u4E00-\uFA29]|[\uE7C7-\uE7F3]汉字编码范围
    var re1 = new RegExp("^([\u4E00-\uFA29]|[\uE7C7-\uE7F3]|[a-zA-Z0-9]|[`~!#$^&*()=|{}':;',\\[\\].<>/?~！#￥……&*（）——|{}【】‘；：”“'。，、？]‘')*$")
    if (!re1.test(str)) {
      return false
    }
    return true
  }
  if (!accountNumber(value)) {
    callback(new Error('请输入正确的账号格式：中英文、数字、特殊字符'))
  } else {
    callback()
  }
}

/**
     * @des  密码
     * @param <Object> rule 校验规则参数
     * @param <String> value form表单但校验的值
     * @return <Function>  callback 回调函数
     */
export function validatePass(rule, value, callback) {
  const accountNumber = (str) => {
    var re1 = new RegExp("^([a-zA-Z0-9]|[`~!#$^&*()=|{}':;',\\[\\].<>/?~！#￥……&*（）——|{}【】‘；：”“'。，、？]‘')*$")
    if (!re1.test(str)) {
      return false
    }
    return true
  }
  if (!accountNumber(value)) {
    rule.langStatus === 'zh' ? callback(new Error('请输入正确的密码格式：英文、数字、特殊字符')) : callback(new Error('Please enter the correct password format: English, numbers, special characters'))
  } else {
    callback()
  }
}

export function validateRangeOfValue({ langStatus, range } = { range: [] }, value, callback) {
  const checkRange = (str) => {
    if (str < range[0] || str > range[1]) {
      return false
    }
    return true
  }
  if (!checkRange(value)) {
    langStatus === 'zh' ? callback(new Error(`请输入${range[0]}到${range[1]}之间的整数`)) : callback(new Error(`Please enter an integer between ${range[0]} and ${range[1]}`))
  } else {
    callback()
  }
}
