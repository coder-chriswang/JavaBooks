/*
 * @Author: 刘彦宏
 * @Date: 2019-12-02 11:15:54
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-08-20 14:59:51
 * @Description: file content
 */
import Cookies from 'js-cookie'

const languageKey = 'language'

const TokenKey = 'user_center_token'

const refreshTokenKey = 'user_center_refreshtoken'

// language
export function getLanguage() {
  return Cookies.get(languageKey)
}

export function setLanguage(language) {
  return Cookies.set(languageKey, language)
}

// ums
export function getToken() {
  return Cookies.get(TokenKey)
}

export function setToken(token) {
  return Cookies.set(TokenKey, token)
}

export function removeToken() {
  return Cookies.remove(TokenKey)
}

export function getRefreshToken() {
  return Cookies.get(refreshTokenKey)
}

export function setRefreshToken(refreshToken) {
  return Cookies.set(refreshTokenKey, refreshToken)
}

export function removeRefreshToken() {
  return Cookies.remove(refreshTokenKey)
}
