/*
 * @Author: 刘彦宏
 * @Date: 2019-12-02 11:15:54
 * @LastEditTime: 2020-10-21 11:52:12
 */
import axios from 'axios'
// import { refreshToken } from '@/api/user'
// MessageBox,
import { Message } from 'element-ui'
import { getLanguage } from '@/lang/index'
import store from '@/store'
import { getToken, getRefreshToken } from '@/utils/auth'

// create an axios instance
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  withCredentials: true, // send cookies when cross-domain requests
  timeout: 5000 // request timeout
})
// service.defaults.withCredentials = true
// request interceptor
service.interceptors.request.use(
  config => {
    config.headers['lang'] = getLanguage() === 'zh' ? 'zh_CN' : 'en_US'
    // 判断是否验证码请求接口，是则传sid
    if (config.data && config.data.isLogin) {
      config.headers['sid'] = sessionStorage.getItem('uuid')
      delete config.data.isLogin
    } else if ((config.data && config.data.isRefresh) || config.url.indexOf('unifyLogout') > -1) { // 判断是否刷新token接口，是则传refreshToken否则传token
      if (config.data && config.data.isRefresh) {
        delete config.data.isRefresh
      }
      config.headers['refreshToken'] = getRefreshToken()
    } else {
      config.headers['authorization'] = 'Bearer' + ' ' + getToken()
    }
    return config
  },
  error => {
    console.log(error) // for debug
    return Promise.reject(error)
  }
)
// 是否正在刷新的标记
let isRefreshing = false
// 重试队列，每一项将是一个待执行的函数形式
let requests = []
// response interceptor
service.interceptors.response.use(
  async(response) => {
    const res = response.data
    // if the custom code is not 20000, it is judged as an error.
    if (parseInt(res.code) === 200) {
      return res
    } else {
      const config = response.config
      switch (parseInt(res.code)) {
        case 1006:
          if (!isRefreshing) {
            try {
              isRefreshing = true
              await store.dispatch('user/resetToken')
              config.baseURL = '' // url已经带上了/api，避免出现/api/api的情况
              requests.forEach(cb => cb())
              requests = []
              return service(config)
            } catch (error) {
              store.dispatch('user/logout')
            } finally {
              // eslint-disable-next-line require-atomic-updates
              isRefreshing = false
            }
          } else {
            // 返回promise是因为请求都已经执行了then，当forEach的的时候会逐个执行then里边的方法
            return new Promise((resolve) => {
              requests.push(() => {
                config.baseURL = ''
                resolve(service(config))
              })
            })
          }
          break
        case 1010:
          Message({
            message: res.message,
            showClose: true,
            type: 'error',
            duration: 5 * 1000
          })
          store.dispatch('user/logout')
          // store.dispatch('user/clearData')
          break

        default:
          Message({
            message: res.message,
            showClose: true,
            type: 'error',
            duration: 5 * 1000
          })
          break
      }
    }
  },
  error => {
    if (error.message) {
      Message({
        message: error.message,
        showClose: true,
        type: 'error',
        duration: 5 * 1000
      })
    } else {
      console.log('err' + error) // for debug
    }
    return Promise.reject(error)
  }
)

export default service
