/*
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-08-17 09:17:23
 * @Description: file content
 */
const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  language: state => state.app.language,
  token: state => state.user.token,
  refreshToken: state => state.user.refreshToken,
  userInfo: state => state.user.userInfo,
  uid: state => state.user.uid,
  name: state => state.user.name
}
export default getters
