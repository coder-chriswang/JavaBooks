import { login, logout, getInfo, refreshToken } from '@/api/user'
import { Encrypt } from '@/utils/secret'
// import { removeUmsToken, removeUmsRefreshToken } from '@/utils/cookies'
import { getToken, setToken, removeToken, getRefreshToken, setRefreshToken, removeRefreshToken } from '@/utils/auth'
import { resetRouter } from '@/router'

const state = {
  token: getToken(),
  refreshToken: getRefreshToken(),
  name: '',
  uid: '',
  userInfo: {}
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_REFRESHTOKEN: (state, refreshToken) => {
    state.refreshToken = refreshToken
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_UID: (state, uid) => {
    state.uid = uid
  },
  SET_USERINFO: (state, userInfo) => {
    state.userInfo = userInfo
  }
}

const actions = {
  // user login
  login({ commit }, userInfo) {
    // const { username, password, verificationCode } = userInfo
    const { username, password, verificationCode } = userInfo
    return new Promise((resolve, reject) => {
      login({ username: username.trim(), password: Encrypt(password), code: verificationCode, isLogin: true }).then(response => {
        const { data } = response
        commit('SET_TOKEN', data.token)
        commit('SET_REFRESHTOKEN', data.refreshToken)
        setToken(data.token)
        setRefreshToken(data.refreshToken)
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // get user info
  getInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      getInfo().then(response => {
        const data = response.data
        if (!data) {
          reject('Verification failed, please Login again.')
        }
        commit('SET_USERINFO', data)
        commit('SET_NAME', data.username)
        commit('SET_UID', data.uid)
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({ commit, state }) {
    return new Promise((resolve, reject) => {
      logout().then(() => {
        commit('SET_TOKEN', '')
        commit('SET_REFRESHTOKEN', '')
        removeToken()
        removeRefreshToken()
        resetRouter()
        resolve()
        location.reload()
      }).catch(error => {
        reject(error)
      })
    })
  },
  clearData({ commit }) {
    localStorage.clear()
    commit('SET_TOKEN', '')
    commit('SET_REFRESHTOKEN', '')
    removeToken()
    removeRefreshToken()
    resetRouter()
  },

  // remove token
  resetToken({ commit }) {
    return new Promise((resolve, reject) => {
      refreshToken({ isRefresh: true }).then(response => {
        if (response) {
          const { data } = response
          commit('SET_TOKEN', data.token)
          commit('SET_REFRESHTOKEN', data.refreshToken)
          setToken(data.token)
          setRefreshToken(data.refreshToken)
          location.reload()
          resolve()
        }
      }).catch(error => {
        reject(error)
      })
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

