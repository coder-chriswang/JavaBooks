<template>
  <div>
    <SiderBar :menu-list="menuList" @menu-active="menuActive" />
    <div class="Breadcrumb">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item>{{ $t('route.system') }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t('sidebar.source') }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="button">
      <el-button>{{
        $t("sidebar.export")
      }}</el-button>
    </div>
    <el-main id="main_body" :class="containerClass">
      <div class="alarm-container">
        <search :search-data="searchData" />
        <el-dialog
          :title="$t('sidebar.export')"
          :visible.sync="dialogFormVisible"
          :modal-append-to-body="false"
        >
          <el-form :model="form">
            <el-form-item :label="$t('access.productName')" :label-width="formLabelWidth">
              <el-input v-model="form.mingc" autocomplete="off" />
            </el-form-item>
            <el-form-item :label="$t('access.productCategory')" :label-width="formLabelWidth">
              <el-select v-model="value1" multiple :placeholder="$t('public.pleaseSelect')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <el-select v-model="value1" multiple :placeholder="$t('public.pleaseSelect')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <el-select v-model="value1" multiple :placeholder="$t('public.pleaseSelect')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.accessMode')" :label-width="formLabelWidth">
              <el-select v-model="value1" multiple :placeholder="$t('public.pleaseSelect')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.protocol')" :label-width="formLabelWidth">
              <el-select v-model="value1" multiple :placeholder="$t('public.pleaseSelect')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.deviceVersion')" :label-width="formLabelWidth">
              <el-select v-model="value1" multiple :placeholder="$t('public.pleaseSelect')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.payloadType')" :label-width="formLabelWidth">
              <el-select v-model="value1" multiple :placeholder="$t('public.pleaseSelect')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.desc')" :label-width="formLabelWidth">
              <el-input
                v-model="form.miaoshu"
                autocomplete="off"
                type="textarea"
              />
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
            <el-button type="primary" @click="dialogFormVisible = false">{{ $t("sidebar.determine") }}</el-button>
          </div>
        </el-dialog>

        <Table
          :table-data="tableData"
          :table-header="tableHeader"
          :current-page="currentPage"
          :pagination="pagination"
          :total="total"
          :page-sizes="pageSizes"
          :page-size="pageSize"
          :last-table-column="lastTableColumn"
          :class="detaile == false?'table':'table table1'"
          @handler-row="rowClick"
          @pagination-change="childByValue"
        >
          <template slot-scope="scope">
            <el-button
              size="small"
              @click="handleEdit(scope.scope.$index, tableData)"
            >{{ $t("public.edit") }}</el-button>
            <el-button
              size="small"
              @click="handleDelete(scope.scope.$index, tableData)"
            >{{ $t("sidebar.delete") }}
            </el-button>
          </template>
        </Table>
        <div class="tab">
          <template v-if=" detaile == true">
            <el-tabs v-model="activeName" type="border-card">
              <el-tab-pane :key="'first'" :label="$t('public.detail')" name="first">
                <el-row class="margin">
                  <el-col v-model="form" :span="6">
                    <div class="grid-content bg-purple" label="weee">
                      <ul>
                        <li
                          v-for="child in detils"
                          :key="child.id"
                        >{{ child.name }}:{{ child.value }}</li>
                      </ul>
                    </div>
                  </el-col>
                  <el-col :span="6"><div class="grid-content bg-purple">
                    <ul>
                      <li
                        v-for="child in detils1"
                        :key="child.id"
                      >{{ child.name }}:{{ child.value }}</li>
                    </ul>
                  </div>
                  </el-col>
                  <el-col :span="6">
                    <div class="grid-content bg-purple">
                      <ul>
                        <li
                          v-for="child in detils3"
                          :key="child.id"
                        >{{ child.name }}:{{ child.value }}</li>
                      </ul>
                    </div>
                  </el-col>
                  <el-col :span="6">
                    <div class="grid-content bg-purple">
                      <ul>
                        <li
                          v-for="child in detils2"
                          :key="child.id"
                        >{{ child.name }}:{{ child.value }}</li>
                      </ul>
                    </div>
                  </el-col>
                </el-row>
              </el-tab-pane>
              <!-- <el-tab-pane :key="'second'" label="统计" name="second">
                <div style="background: green; display: inline" />
                  <div class="charts">
                    <x-chart :id="id" :option="option" />
                  </div>
              </el-tab-pane> -->
            </el-tabs>
          </template>
        </div>
      </div>
    </el-main>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import Table from '@/components/Table/Table'
import search from '@/components/TitleSearch/TitleSearch'
import { parseTime } from '@/utils/index'
import { getTree, getTable, getCommand } from '@/api/data.js'
export default {
  name: 'Statistics',
  components: {
    SiderBar,
    Table,
    search
  },
  filters: {
    parseTime(time) {
      var data = new Date(time)
      return parseTime(data, 'yyyy-MM-dd')
    }
  },
  data() {
    return {
      menuList: [],
      currentPage: 1,
      id: 'test',
      detils: [],
      detils1: [],
      detils2: [],
      detils3: [],
      detaile: false,
      chartOptions: [],
      chartId: '',
      tabPosition: 'details',
      dialogFormVisible: false,
      value1: [],
      options: [],
      form: {
        biaoshi: '',
        mingc: '',
        miaoshu: '',
        gongyings: ''
      },
      category: '',
      ci: '',
      formLabelWidth: '120px',
      pagination: true,
      categoryage: 1,
      total: 0,
      detilsWidth: '6',
      pageSizes: [10, 20, 30, 40, 50],
      // 搜索框
      searchData: [],
      tableHeader: [],
      tableData: [],
      pageSize: 10,
      lastTableColumn: true,
      activeName: 'first'
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'name'
    ]),
    containerClass() {
      return {
        main_body: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    this.getListTree()
  },
  methods: {
    rowClick(row, event, column) {
      console.log(event)
      this.detils = []
      this.detils1 = []
      this.detils2 = []
      this.detils3 = []
      if (event.fixed === 'right') {
        this.detaile = false
      } else {
        this.detaile = true
      }
      const tableHeader = this.tableHeader
      for (const i in tableHeader) {
        if (i < 10) {
          const src = {}
          src.name = tableHeader[i].name
          src.id = tableHeader[i].id
          src.value = row[tableHeader[i].id]
          this.detils.push(src)
        }
        if (i >= 10 && i < 20) {
          const src = {}
          src.name = tableHeader[i].name
          src.id = tableHeader[i].id
          src.value = row[tableHeader[i].id]
          this.detils1.push(src)
        }
        if (i >= 20 && i < 30) {
          const src = {}
          src.name = tableHeader[i].name
          src.id = tableHeader[i].id
          src.value = row[tableHeader[i].id]
          this.detils3.push(src)
        }
        if (i >= 30 && i < 40) {
          const src = {}
          src.name = tableHeader[i].name
          src.id = tableHeader[i].id
          src.value = row[tableHeader[i].id]
          this.detils2.push(src)
        }
      }
    },
    childByValue: function(childValue) {
      this.currentPage = childValue.currentPageNum
      this.pageSize = childValue.pageSizeNum
      this.GetListTable()
    },
    menuActive(val) {
      this.detaile = false
      this.ci = val.item.ci
      this.category = val.item.category
      this.currentPage = 1
      this.GetListTable()
    },
    // 获取左边导航数据
    getListTree() {
      getTree().then((res) => {
        const Tree = res.data
        for (let i = 0; i < Tree.length; i++) {
          const menuList2 = {}
          menuList2.label = Tree[i].name
          menuList2.ns = Tree[i].ns
          menuList2.id = i + 1
          menuList2.children = []
          for (let j = 0; j < Tree[i].categoryList.length; j++) {
            const categoryList = {}
            categoryList.label = Tree[i].categoryList[j].name
            categoryList.ns = menuList2.ns
            categoryList.category = Tree[i].categoryList[j].category
            this.category = Tree[0].categoryList[0].category
            categoryList.id = (i + 1) + '-' + (j + 1)
            categoryList.children = []
            for (let k = 0; k < Tree[i].categoryList[j].typeList.length; k++) {
              const typeList = {}
              typeList.label = Tree[i].categoryList[j].typeList[k].name
              typeList.ns = categoryList.ns
              typeList.type = Tree[i].categoryList[j].typeList[k].type
              typeList.category = categoryList.category
              typeList.id = (i + 1) + '-' + (j + 1) + '-' + (k + 1)
              typeList.children = []
              for (let q = 0; q < Tree[i].categoryList[j].typeList[k].ciList.length; q++) {
                const ciList = {}
                ciList.label = Tree[i].categoryList[j].typeList[k].ciList[q].name
                ciList.ns = typeList.ns
                ciList.type = typeList.type
                ciList.ci = Tree[i].categoryList[j].typeList[k].ciList[q].ci
                ciList.category = typeList.category
                this.ci = Tree[0].categoryList[0].typeList[0].ciList[0].ci
                ciList.id = (i + 1) + '-' + (j + 1) + '-' + (k + 1) + '-' + (q + 1)
                typeList.children.push(ciList)
              }
              categoryList.children.push(typeList)
            }
            menuList2.children.push(categoryList)
          }

          this.menuList.push(menuList2)
          this.GetListTable()
        }
      })
    },
    // //获取表格数据
    GetListTable() {
      const params = {
        ci: this.ci,
        category: this.category
      }
      getTable(params).then(res => {
        this.searchData = []
        this.tableHeader = res.data.attrs
        const index = []
        for (const i in res.data.attrs) {
          if (res.data.attrs[i].searchCondition === true) {
            const text = {}
            text.type = 'text'
            text.searchCondition = res.data.attrs[i].id
            text.name = res.data.attrs[i].name
            this.searchData.push(text)
            index.push(i)
          }
        }
        const data = {
          action: 'Query',
          category: res.data.category,
          ci: res.data.ci,
          data: {},
          ns: res.data.ns,
          pageNum: this.currentPage,
          pageSize: this.pageSize
        }
        //
        getCommand(data).then(res => {
          this.total = res.data.total
          this.tableData = res.data.list
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth} + 10px);
  }
}
.Breadcrumb {
    position: absolute;
    margin-left: 264px;
    top:57px;
}
#main_body {
    position: absolute;
    left: 210px;
    width: calc(100% - #{$sideBarWidth});
    height:100%;
    top: 42px;
}
.margin{
  margin-top: 35px;
}
.main_body {
  width: calc(100% - #{$sideBarHideWidth}) !important;

}
// .el-main div.el-tab-pane {
//   margin-top:10px;
// }
.table {
  position: absolute;
  width:96%;
  height: 80%;
  background: #11164a
}
.table1 {
  height:45%;
}
.titleSearch{
  position: relative
}
.tab {
  position: absolute;
  width: 85%;
  top: 57%;
}
.el-table--scrollable-x .el-table__body-wrapper{
  overflow-x: auto
}
.button {
  position: fixed;
  right: 3%;
  top: 86px;
}
.button button {
  background-color: #20a3f5;
  color: #fff;
  border: none;
  line-height: 30px;
  padding: 0 15px;
  font-size: 12px;
  border-radius: 4px;
  margin: 0 5px;
}

.el-button {
  background: none;
  border: none;
  color: #fff;
}
.dialog_heat {
  background: #20a3f5;
}
.el-tabs--border-card {
  background: none;
  border: none;
}
.el-button--small,
.el-button--small.is-round {
  padding: 9px 0;
}
</style>

<style>
.el-tabs--border-card > .el-tabs__header {
  background: none;
}
.el-breadcrumb__inner,.el-breadcrumb__inner a, .el-breadcrumb__inner.is-link{
  color:#fff
}
.el-breadcrumb__item:last-child .el-breadcrumb__inner, .el-breadcrumb__item:last-child .el-breadcrumb__inner a, .el-breadcrumb__item:last-child .el-breadcrumb__inner a:hover, .el-breadcrumb__item:last-child .el-breadcrumb__inner:hover{
  color:#fff;
}
.Breadcrumb{
  margin-top: -28px;
  border-left:4px solid #20A3F5;
  padding-left:10px;
}
.el-input__inner{
  color:#fff;
}
.el-tabs--border-card > .el-tabs__header {
  background: none !important;
  border-bottom: 1px solid #1e3675;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
  background: #20a3f5;
  color: #fff;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
  border: none;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item {
  background: #1c214f;
  color: #20a3f5;
  margin-right: 20px;
  border-radius: 4px;
}
.el-tabs--border-card
  > .el-tabs__header
  .el-tabs__item:not(.is-disabled):hover {
  color: #fff;
}
.el-dialog__header {
  background: #20a3f5;
  color: #fff;
}
.el-dialog__body,
.el-dialog__footer {
  background: #10296c;
}
.el-input__inner,
.el-textarea__inner {
  background-color: #10296c;
  border: 1px solid #20a3f5;
  resize: none;
}
.el-table,
.el-table__expanded-cell {
  background-color: #10296c;
  margin: 10px 0;
}
.el-table thead,
.el-table th,
.el-table tr {
  background-color: #1c214f;
}
.el-table tr:nth-child(even) {
  background: #1c214f;
}
.el-table tr:nth-child(odd) {
  background: rgba(255, 255, 255, 0);
}
.el-table td,
.el-table th.is-leaf {
  border: none;
  color: #fff;
  text-align: center;
}
.el-table__body tr.current-row > td {
  background: #037fcd;
}

.el-table--enable-row-hover .el-table__body tr:hover > td {
  background: #20a3f5;
}
.el-form-item__label {
  color: #fff;
}
.el-dialog__headerbtn .el-dialog__close,
.el-dialog__title {
  color: #fff;
}
.el-select {
  margin-right: 5px;
}
.el-table__fixed-body-wrapper{
  top: 37px!important
}
.el-row{
  color:#fff;
  line-height: 25px;
}
.el-col-6{
  margin-top:-22px!important
}
/* .el-table__body-wrapper.is-scrolling-left{
  height: 95%!important
} */
</style>

