<template>
  <div class="resources-main-container" :class="containerClass">
    <SiderBar :menu-list="menuList" @menu-active="menuActive" />
    <div class="Breadcrumb">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item
          v-for="item in breadcrumb"
          :key="item.value"
        >
          {{ item.name }}
        </el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <el-main id="main_body" :class="containerClass">
      <Product v-if="idType=='product'" :ids="ids" :product="product" @toPath="toPath" />
      <Category v-if="idType == 'equipment'" :code="ids" :category="category" />
      <Theme v-if="idType == 'service'" :ids="ids" :theme="theme" />
      <Resources v-if="idType == 'resources'" :resources="resources" />
    </el-main>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import Product from './access/product'
import Category from './access/equipment'
import Theme from './access/service'
import Resources from './access/resources'
import { getTree, getCitree } from '@/api/access.js'
export default {
  name: 'Alarm',
  components: {
    SiderBar,
    Product,
    Resources,
    Category,
    Theme
  },
  data() {
    return {
      breadcrumb: [
        {
          name: this.$t('route.access')
        },
        {
          name: this.$t('sidebar.perceptual')
        },
        {
          name: ''
        }
      ],
      menuList: [
        {
          label: this.$t('sidebar.perceptual'),
          icon: 'icon-peizhi',
          isActive: true,
          id: '1',
          children: []
        },
        {
          label: this.$t('sidebar.manage'),
          icon: 'icon-yunwei',
          isActive: true,
          id: '2',
          children: []
        }
      ],
      idType: '1-1-1',
      ids: '1111',
      product: '',
      resources: '',
      category: '',
      theme: ''
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'name'
    ]),
    containerClass() {
      return {
        main_body: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    // 设备管理树-侧栏数据获取
    getTree().then(res => {
      const tree = res.data
      const mentListBody = []
      for (let index = 0; index < tree.length; index++) {
        const map = {}
        map['label'] = tree[index].h_name
        map['isActive'] = true
        map['id'] = '1-' + (index + 1)
        map['typeList'] = [{ 'name': tree[index].h_name, 'code': tree[index].h_code }]
        const mapSonOld = tree[index].domainList
        const childrenList = []
        for (let indexSon = 0; indexSon < mapSonOld.length; indexSon++) {
          const mapSon = {}
          mapSon['label'] = mapSonOld[indexSon].name
          mapSon['isActive'] = true
          mapSon['id'] = '1-' + (index + 1) + '-' + (indexSon + 1)
          mapSon['typeList'] = [{ 'name': tree[index].h_name, 'code': tree[index].h_code }, { 'name': mapSonOld[indexSon].name, 'code': mapSonOld[indexSon].code }]
          childrenList.push(mapSon)
          if (mapSonOld[indexSon].dsList) {
            const childrenD = mapSonOld[indexSon].dsList
            const childrenDList = []
            if (childrenD) {
              for (let indexSonD = 0; indexSonD < childrenD.length; indexSonD++) {
                const mapSonD = {}
                mapSonD['label'] = childrenD[indexSonD].name
                mapSonD['isActive'] = true
                mapSonD['id'] = '1-' + (index + 1) + '-' + (indexSon + 1) + '-' + (indexSonD + 1)
                mapSonD['idType'] = 'product'
                mapSonD['alldata'] = childrenD[indexSonD]
                mapSonD['typeList'] = [{ 'name': tree[index].h_name, 'code': tree[index].h_code }, { 'name': mapSonOld[indexSon].name, 'code': mapSonOld[indexSon].code }, { 'name': childrenD[indexSonD].name, 'code': childrenD[indexSonD].ci }]
                childrenDList.push(mapSonD)
              }
            }
            mapSon['children'] = childrenDList
          }
        }
        map['children'] = childrenList
        mentListBody.push(map)
      }
      this.menuList[0].children = mentListBody
    })
    // 系统管理树-侧栏数据获取
    getCitree().then(res => {
      const manageTreeList = res.data
      const manageTreeChildren = []
      for (let MTLindex = 0; MTLindex < manageTreeList.ciList.length; MTLindex++) {
        const mtCmBm = {}
        mtCmBm['label'] = manageTreeList.ciList[MTLindex].name
        mtCmBm['isActive'] = true
        mtCmBm['id'] = '2-' + (MTLindex + 1)
        mtCmBm['idType'] = 'resources'
        mtCmBm['alldata'] = manageTreeList.ciList[MTLindex]
        manageTreeChildren.push(mtCmBm)
      }
      this.menuList[1].children = manageTreeChildren
    })
  },
  methods: {
    menuActive(key) {
      this.product = key
      this.resources = key
      this.theme = key
      this.breadcrumb[2].name = ''
      this.idType = key.item.idType ? key.item.idType : 'product'
      this.ids += 1
    },
    toPath(data, val) {
      this.ids = data.code
      if (val === 'equipment') {
        this.idType = 'equipment'
        this.category = data
        this.breadcrumb[2].name = this.$t('sidebar.equipmentgl')
      } else {
        this.idType = 'service'
        this.theme = data
        this.breadcrumb[2].name = this.$t('sidebar.service')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth}  + 10px);
  }
}
.Breadcrumb {
    position: absolute;
    margin-left: 264px;
    top:57px;
}
#main_body {
    position: absolute;
    left: 210px;
    width: calc(100% - #{$sideBarWidth});
    height:100%;
    top: 42px;
}
.main_body {
  width: calc(100% - #{$sideBarHideWidth}) !important;

}

</style>
<style>
.alarm-container {
  height: 95%;
  width: 100%
}
.button_add{
  position: fixed;
  right: 3%;
  top: 86px;
  z-index: 23;
}
.table .el-button {
  background: none;
  border: none;
  color: #fff;
}
.tab {
  position: absolute;
  width: 85%;
  top: 58%;
}
.dialog_heat {
  background: #20a3f5;
}
.el-tabs--border-card {
  background: none;
  border: none;
}
.el-button--small,
.el-button--small.is-round {
  padding: 9px 0;
}
.button_add button.el-button,.button_add3 button.el-button {
  background-color: #20a3f5;
  color: #fff;
  border: none;
  line-height: 30px;
  padding: 0 15px;
  font-size: 12px;
  border-radius: 4px;
  margin: 0 5px;
 }

 .table {
  margin-top: 15px;
  width: 100%;
  height: 90%;
  max-height: 90%;
  padding: 0 10px 15px;
  background: #111547;
  }
.table1 {
  height: 50%!important;
}
.el-input__inner{
  color:#fff;
}
.el-breadcrumb__inner,.el-breadcrumb__inner a, .el-breadcrumb__inner.is-link{
  color:#fff
}
.el-breadcrumb__item:last-child .el-breadcrumb__inner, .el-breadcrumb__item:last-child .el-breadcrumb__inner a, .el-breadcrumb__item:last-child .el-breadcrumb__inner a:hover, .el-breadcrumb__item:last-child .el-breadcrumb__inner:hover{
  color:#fff;
}
.Breadcrumb{
  margin-top: -28px;
  border-left:4px solid #20A3F5;
  padding-left:10px;
}
.el-input__inner,.el-textarea__inner{
  color:#fff;
}
.el-message-box__btns button{
  padding: 9px
}
</style>
