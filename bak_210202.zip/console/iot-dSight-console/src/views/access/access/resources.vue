<template>
  <div class="alarm-container">
    <div class="tab" style="top:20px;height:100%;width:100%">
      <el-tabs v-model="activeName" type="border-card" style="height:100%;width:98%">
        <el-tab-pane :key="'first'" :label="$t('sidebar.service')" name="first" style="height:100%">
          <template>
            <el-select v-model="value" :placeholder="$t('access.datasourcein')" class="select">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </template>
          <Theme />
        </el-tab-pane>
        <el-tab-pane :key="'second'" :label="$t('route.data')" name="second" style="height:100%;width:98%">
          <Table
            :table-data="tableData"
            :table-header="tableHeader2"
            :current-page="currentPage"
            :pagination="pagination"
            :total="total"
            :page-size="pageSize"
            :page-sizes="pageSizes"
            class="table1"
            :last-table-column="lastTableColumne"
            @pagination-change="childByValue"
          >
            <template slot-scope="scope">
              <el-button size="small" @click="handleEdit(scope.scope.$index,tableData)"><i class="el-icon-edit-outline" /></el-button>
              <el-button
                size="small"
                @click="handleDelete(scope.scope.$index, tableData)"
              >
                <i class="el-icon-delete" />
              </el-button>
            </template>
          </Table>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Table from '@/components/Table/Table'
import Theme from '@/views/access/access/service'
import { getDstypedata, getMetaData, getDataCommand } from '@/api/access.js'
export default {
  name: 'Alarm',
  components: {
    Table,
    Theme
  },
  props: {
    resources: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      Selection: true,
      dialogFormVisible: false,
      dialogTableVisible: false,
      value1: '',
      value: '',
      options: [],
      // 搜索框
      searchData: [
        {
          searchType: 'select',
          searchCondition: '15522',
          name: this.$t('access.Onlinestatus')
        },
        {
          searchType: 'select',
          searchCondition: '15522',
          name: this.$t('access.devicestatus')
        },
        {
          searchType: 'select',
          searchCondition: '15522',
          name: this.$t('access.IMEI')
        },
        {
          searchType: 'select',
          searchCondition: '15522',
          name: this.$t('access.devicesID')
        },
        {
          searchType: 'select',
          searchCondition: '15522',
          name: this.$t('access.productCategory')
        }
      ],
      form: {
        biaoshi: '',
        mingc: '',
        miaoshu: '',
        gongyings: ''
      },
      formLabelWidth: '120px',
      // table
      pagination: true,
      currentPage: 1,
      total: 50,
      pageSize: 10,
      pageSizes: [10, 20, 30, 40, 50],
      tableHeader: [
        {
          name: this.$t('access.devicename'),
          id: 'id'
        },
        {
          name: this.$t('access.devicesID'),
          id: 'adl'
        },
        {
          name: this.$t('access.productCategory'),
          id: 'type'
        },
        {
          name: this.$t('access.tenant'),
          id: 'vendor'
        },
        {
          name: this.$t('access.IMEI'),
          id: 'adl'
        },
        {
          name: this.$t('access.updateTs'),
          id: 'type'
        },
        {
          name: this.$t('access.lasttime'),
          id: 'vendor'
        },
        {
          name: this.$t('access.devicestatus'),
          id: 'type'
        },
        {
          name: this.$t('access.Onlinestatus'),
          id: 'vendor'
        }
      ],
      tableHeader2: [],
      tableData: [],
      firstTableColumn: true,
      lastTableColumne: true,
      activeName: 'first',
      ci: '',
      category: ''
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  watch: {
    'resources': {
      handler: function(n, o) {
        const params = {
          ci: n.item.alldata.ci,
          category: n.item.alldata.category
        }
        this.ci = n.item.alldata.ci
        this.category = n.item.alldata.category
        this.GetListTable(params)
      }
    }
  },
  created() {
    const params = {
      ci: this.resources.item.alldata.ci,
      category: this.resources.item.alldata.category
    }
    this.ci = this.resources.item.alldata.ci
    this.category = this.resources.item.alldata.category
    this.GetListTable(params)
    getDstypedata().then((res) => {
      if (res.code === 200) {
        for (const i in res.data) {
          const option = {}
          option.label = res.data[i].name
          option.value = res.data[i].name
          this.options.push(option)
        }
      }
    })
  },
  methods: {
    childByValue: function(childValue) {
      this.currentPage = childValue.currentPageNum
      this.pageSize = childValue.pageSizeNum
      const params = {
        ci: this.ci,
        category: this.category
      }
      this.GetListTable(params)
    },
    // 表格数据编辑
    // handleEdit(index, rows) {
    //   this.dialogFormVisible = true;
    //   (this.form.biaoshi = rows[index].id),
    //     (this.form.mingc = rows[index].adl),
    //     (this.form.miaoshu = rows[index].desc),
    //     (this.form.gongyings = rows[index].vendor);
    // },
    // handleEdit2(index, rows) {
    //   this.dialogTableVisible = true;
    //   (this.form.biaoshi = rows[index].id),
    //     (this.form.mingc = rows[index].adl),
    //     (this.form.miaoshu = rows[index].desc),
    //     (this.form.gongyings = rows[index].vendor);
    // },
    // // 表格数据删除
    // handleDelete(index, rows) {
    //   rows.splice(index, 1);
    // },
    // handleDelete2(index, rows) {
    //   rows.splice(index, 1);
    // },
    // //获取表格数据
    GetListTable(params) {
      getMetaData(params).then((res) => {
        this.tableHeader2 = res.data.data.attrs
        const data = {
          action: 'Query',
          category: res.data.data.category,
          ci: res.data.data.ci,
          data: {},
          ns: res.data.data.ns,
          pageNum: this.currentPage,
          pageSize: this.pageSize
        }
        getDataCommand(data).then(res => {
          this.total = res.data.data.total
          this.tableData = res.data.data.list
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../../styles/variables.scss";
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth} + 10px);
  }
}
.select{
  width:500px;
  margin: 0 10px;
}
// .table {
//   margin-left: 1%;
//   position: absolute;
//   width: 98%;
//   height: 340px;
// }
.addbutton {
  // position: absolute;
  // // right:3%;
  // top:13px;
  float: right;
}
.el-tabs--border-card {
  background: none;
  border: none;
}
.button {
  overflow: hidden;
  margin-top: -22px;
  margin-bottom: 10px;
}
.button button {
  background-color: #20a3f5;
  color: #fff;
  border: none;
  line-height: 30px;
  padding: 0 15px;
  font-size: 12px;
  border-radius: 4px;
  margin: 0 5px;
}
.el-button {
  background: none;
  border: none;
  color: #fff;
  font-size: 28px;
}
.el-button--small,
.el-button--small.is-round {
  padding: 9px 0;
}
.top {
  position: relative;
  width: 100%;
  background-color: rgba(16, 41, 108, 0.3);
  height: 440px;
  margin-bottom: 10px;
}
</style>
<style>
.el-tabs--border-card > .el-tabs__header {
  background: none;
}
.el-tabs--border-card > .el-tabs__header {
  background: none !important;
  border-bottom: 1px solid #1e3675;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
  background: #20a3f5;
  color: #fff;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
  border: none;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item {
  background: #1c214f;
  color: #20a3f5;
  margin-right: 20px;
  border-radius: 4px;
}
.el-tabs--border-card
  > .el-tabs__header
  .el-tabs__item:not(.is-disabled):hover {
  color: #fff;
}
.el-dialog__header {
  background: #20a3f5;
  color: #fff;
}
.el-dialog__body,
.el-dialog__footer {
  background: #10296c;
}
.el-input__inner,
.el-textarea__inner {
  background-color: #10296c;
  border: 1px solid #20a3f5;
  resize: none;
}
.el-table,
.el-table__expanded-cell {
  background-color: #10296c;
  margin: 10px 0;
}
.el-table thead,
.el-table th,
.el-table tr {
  background-color: #1c214f;
}
.el-table tr:nth-child(even) {
  background: #1c214f;
}
.el-table tr:nth-child(odd) {
  background: rgba(255, 255, 255, 0);
}
.el-table td,
.el-table th.is-leaf {
  border: none;
  color: #fff;
  text-align: center;
}

.el-table__body tr.current-row > td {
  background: #037fcd;
}

.el-table--enable-row-hover .el-table__body tr:hover > td {
  background: #20a3f5;
}
.el-form-item__label {
  color: #fff;
}
.el-dialog__headerbtn .el-dialog__close,
.el-dialog__title {
  color: #fff;
}
.el-input__inner,
.el-textarea__inner {
  color: #fff;
}
.el-select {
  margin-right: 5px;
}
</style>
