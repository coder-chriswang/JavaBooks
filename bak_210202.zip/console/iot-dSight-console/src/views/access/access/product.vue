<template>
  <div class="alarm-container">
    <search ref="search" :search-data="searchData" @search="search" />
    <div class="button_add">
      <el-button v-if="show" type="primary" @click="handleEditdia()">
        {{ $t("public.add") }}
      </el-button>
      <el-dialog
        :title="title"
        :visible.sync="dialogFormVisible"
        :modal-append-to-body="false"
      >
        <el-form :model="form" style="margin-top:15px;">
          <el-form-item :label="$t('access.productCategory')" :label-width="formLabelWidth">
            <el-input v-model="form.industry" autocomplete="off" class="hide" />
            <el-select v-model="form.industryName" disabled :placeholder="$t('metadata.pleaseSelect')">
              <el-option
                v-for="(item) in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-input v-model="form.domain" autocomplete="off" class="hide" />
            <el-select v-model="form.domainName" disabled :placeholder="$t('metadata.pleaseSelect')">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-input v-model="form.deviceType" autocomplete="off" class="hide" />
            <el-select v-model="form.deviceTypeName" disabled :placeholder="$t('metadata.pleaseSelect')">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('access.productName')" :label-width="formLabelWidth">
            <el-input v-model="form.name" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('access.accessMode')" :label-width="formLabelWidth">
            <el-select v-model="form.accessType" :placeholder="$t('metadata.pleaseSelect')">
              <el-option
                v-for="item in options.accesstype"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('access.protocol')" :label-width="formLabelWidth">
            <el-select v-model="form.protocol" :placeholder="$t('metadata.pleaseSelect')">
              <el-option
                v-for="item in options.protocol"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('access.deviceVendor')" :label-width="formLabelWidth">
            <el-input v-model="form.deviceVendor" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('access.deviceVendorName')" :label-width="formLabelWidth">
            <el-input v-model="form.deviceVendorName" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('access.deviceVersion')" :label-width="formLabelWidth">
            <el-input v-model="form.deviceVersion" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('access.payloadType')" :label-width="formLabelWidth">
            <el-select v-model="form.payloadType" :placeholder="$t('metadata.pleaseSelect')">
              <el-option
                v-for="item in options.msgtype"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('access.desc')" :label-width="formLabelWidth">
            <el-input
              v-model="form.desc"
              autocomplete="off"
              type="textarea"
            />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="info" @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
          <el-button type="primary" @click="tableDataGet()">{{ $t("sidebar.determine") }}</el-button>
        </div>
      </el-dialog>
    </div>
    <Table
      v-if="!tableLoading"
      :table-data="tableData"
      :table-header="tableHeader"
      :current-page="currentPage"
      :pagination="pagination"
      :total="total"
      :page-sizes="pageSizes"
      :page-size="pageSize"
      :last-table-column="lastTableColumn"
      :class="detaile === false?'table':'table table1'"
      @handler-row="rowClick"
      @pagination-change="childByValue"
    >
      <template slot-scope="scope">
        <el-button
          size="small"
          @click="handleEdit(scope.scope.$index, tableData)"
        >{{ $t("public.edit") }}
        </el-button>
        <el-button
          size="small"
          @click="handleDelete(scope.scope.$index, tableData)"
        >{{ $t("sidebar.delete") }}
        </el-button>
        <el-button
          size="small"
          @click="toPath('equipment',scope.scope.$index,tableData)"
        >{{ $t("sidebar.equipmentgl") }}
        </el-button>
        <el-button
          size="small"
          @click="toPath('service',scope.scope.$index,tableData)"
        >{{ $t("sidebar.service") }}
        </el-button>
      </template>
    </Table>
    <div class="tab">
      <template v-if="detaile">
        <el-tabs v-model="activeName" type="border-card">
          <el-tab-pane :key="'first'" :label="$t('public.detail')" name="first">
            <el-row>
              <el-col v-model="form" :span="6">
                <div class="grid-content bg-purple">
                  <ul>
                    <li
                      v-for="child in detils"
                      :key="child.id"
                    >{{ child.name }}:{{ child.value }}</li>
                  </ul>
                </div>
              </el-col>
              <el-col :span="6"><div class="grid-content bg-purple">
                <ul>
                  <li
                    v-for="child in detils1"
                    :key="child.id"
                  >{{ child.name }}:{{ child.value }}</li>
                </ul>
              </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <ul>
                    <li
                      v-for="child in detils3"
                      :key="child.id"
                    >{{ child.name }}:{{ child.value }}</li>
                  </ul>
                </div>
              </el-col>
              <el-col :span="6"><div class="grid-content bg-purple" /></el-col>
            </el-row>
          </el-tab-pane>
          <!-- <el-tab-pane :key="'second'" label="统计" name="second">
            <div style="display: inline;">
              <img src="../../../assets/login_logo.png" class="logo">
              <div id="chartLineBox" style="width: 300px; height:24.5vh" />
              < <el-row :gutter="15">
              <el-col v-for="(item, index) in chartOptions" :key="index" :span="8">
                <Chart v-if="item.type === 'chart'" :id="''+index" :options-data="item" :side-bar-opend="sidebar.opened" class="chart-div" />
              </el-col>
               </el-row>
            </div>
          </el-tab-pane> -->
        </el-tabs>
      </template>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Table from '@/components/Table/Table'
import search from '@/components/TitleSearch/TitleSearch'
import { parseTime } from '@/utils/index'
import { getProduct, addProduct, editProduct, delectProduct, getProductcode, getDsdomains, getDevicetypes, getProtocol, getAccesstype, getMsgtype } from '@/api/access.js'
export default {
  name: 'Alarm',
  components: {
    Table,
    search
  },
  filters: {
    parseTime(time) {
      var data = new Date(time)
      return parseTime(data, 'yyyy-MM-dd')
    }
  },
  props: {
    ids: {
      type: String,
      default: () => '2-1'
    },
    product: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      isActiveTable: false,
      detaile: false,
      tabPosition: 'details',
      dialogFormVisible: false,
      value1: [],
      options: {
        protocol: [],
        msgtype: [],
        accesstype: []
      },
      form: {
        code: '',
        domain: '',
        deviceType: '',
        domainName: '',
        deviceTypeName: '',
        accessType: '',
        protocol: '',
        update_ts: '',
        deviceVendor: '',
        deviceVendorName: '',
        industry: '',
        industryName: '',
        tenant: '',
        ext: '',
        name: '',
        payloadType: '',
        deviceNum: '',
        deviceVersion: '',
        desc: ''
      },
      formLabelWidth: '120px',
      pagination: true,
      currentPage: 1,
      total: 0,
      pageSizes: [10, 20, 30, 40, 50],
      // 搜索框
      searchData: [
        {
          searchType: 'select',
          searchCondition: true,
          name: this.$t('access.productArea'),
          id: 1,
          option: []
        },
        {
          searchType: 'select',
          searchCondition: true,
          name: this.$t('access.category'),
          id: 3,
          option: []
        },
        {
          searchType: 'select',
          searchCondition: true,
          name: this.$t('access.protocol'),
          id: 4,
          option: []
        }
      ],
      tableHeader: [
        {
          name: this.$t('access.code'),
          id: 'code'
        },
        {
          name: this.$t('access.productName'),
          id: 'name'
        },
        {
          name: this.$t('access.domainName'),
          id: 'domainName'
        },
        {
          name: this.$t('access.productCategory'),
          id: 'deviceTypeName'
        },
        {
          name: this.$t('access.accessMode'),
          id: 'accessType'
        },
        {
          name: this.$t('access.protocol'),
          id: 'protocol'
        },
        {
          name: this.$t('access.updateTs'),
          id: 'update_ts'
        },
        {
          name: this.$t('access.tenant'),
          id: 'tenant'
        },
        {
          name: this.$t('access.deviceNum'),
          id: 'deviceNum'
        },
        {
          name: this.$t('access.deviceVersion'),
          id: 'deviceVersion'
        },
        {
          name: this.$t('access.desc'),
          id: 'desc'
        },
        {
          name: this.$t('access.deviceVendor'),
          id: 'deviceVendor'
        },
        {
          name: this.$t('access.deviceVendorName'),
          id: 'deviceVendorName'
        }
      ],
      tableData: [],
      detils: [], // 列表详情第一列
      detils1: [], // 列表详情第二列
      detils3: [], // 列表详情第三列
      show: false,
      tableHeaderDetals: [],
      title: this.$t('public.add'),
      pageSize: 10,
      lastTableColumn: true,
      activeName: 'first',
      indext: -2, // 判断是否是添加或编辑
      typeList: [],
      tableLoading: false
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name', 'userInfo']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  watch: {
    'product': {
      handler(newValue, oldVlaue) {
        this.detaile = false
        this.currentPage = 1
        // 点击数结构  清除搜索框数据
        if (this.$refs.search) {
          if (this.$refs.search.searchModel[1] || this.$refs.search.searchModel[3] || this.$refs.search.searchModel[4]) {
            this.$refs.search.searchModel[1] = ''
            this.$refs.search.searchModel[3] = ''
            this.$refs.search.searchModel[4] = ''
            this.form.protocol = ''
          }
        }
        // 最后一级叶子节点 添加按钮显示 搜索条件只剩一条
        if (newValue.item.alldata) {
          this.show = true
          if (this.searchData.length >= 3) {
            this.searchData.splice(0, 2)
          }
          this.form.industry = newValue.item.typeList[0].code
          this.form.domain = newValue.item.typeList[1].code
          this.form.deviceType = newValue.item.typeList[2].code
          this.form.industryName = newValue.item.typeList[0].name
          this.form.domainName = newValue.item.typeList[1].name
          this.form.deviceTypeName = newValue.item.typeList[2].name
          this.GetListTable()
        } else {
          this.show = false
          const serch = {
            searchType: 'select',
            searchCondition: true,
            name: this.$t('access.productArea'),
            id: 1,
            option: []
          }
          const serchc = {
            searchType: 'select',
            searchCondition: true,
            name: this.$t('access.category'),
            id: 3,
            option: []
          }
          if (this.searchData.length < 3) {
            this.searchData.unshift(serchc)
            this.searchData.unshift(serch)
            this.getSelect()
          }
        }
      },
      deep: true
    }
  },
  created() {
    this.currentPage = 1
    if (this.product.item.alldata) {
      if (this.searchData.length >= 3) {
        this.searchData.splice(0, 2)
      }
      this.show = true
      this.form.deviceType = this.product.item.alldata.ci
      this.form.industry = this.product.item.typeList[0].code
      this.form.domain = this.product.item.typeList[1].code
      this.form.industryName = this.product.item.typeList[0].name
      this.form.domainName = this.product.item.typeList[1].name
      this.form.deviceTypeName = this.product.item.typeList[2].name
      this.GetListTable()
    } else {
      this.GetListTable()
    }
    this.getSelect()
  },
  mounted() {
    if (this.detaile) {
      this.currentPage = 1
      this.pageSize = 10
      this.GetListTable()
    }
  },
  methods: {
    // 点击列表行  展示详情
    rowClick(row, event, column) {
      // 操纵列除外
      if (event.fixed === 'right') {
        this.detaile = false
      } else {
        this.detaile = true
      }
      this.detils = []
      this.detils1 = []
      this.detils3 = []
      this.tableHeaderDetals = []
      this.tableHeaderDetals = this.tableHeader
      for (const i in this.tableHeaderDetals) {
        if (i < 6) {
          const src = {}
          src.name = this.tableHeaderDetals[i].name
          src.id = this.tableHeaderDetals[i].id
          src.value = row[this.tableHeaderDetals[i].id]
          this.detils.push(src)
        }
        if (i >= 6 && i < 12) {
          const src = {}
          src.name = this.tableHeaderDetals[i].name
          src.id = this.tableHeaderDetals[i].id
          src.value = row[this.tableHeaderDetals[i].id]
          this.detils1.push(src)
        }
        if (i >= 12 && i < this.tableHeader.length) {
          const src = {}
          src.name = this.tableHeaderDetals[i].name
          src.id = this.tableHeaderDetals[i].id
          src.value = row[this.tableHeaderDetals[i].id]
          this.detils3.push(src)
        }
      }
    },
    // 获取下拉框数据
    getSelect() {
      // 产品领域
      getDsdomains().then((res) => {
        if (res.code === 200) {
          const dsdomains = res.data
          for (let index = 0; index < dsdomains.length; index++) {
            const mapOne = {}
            mapOne.value = dsdomains[index].code
            mapOne.label = dsdomains[index].name
            if (this.searchData.length >= 3) {
              this.searchData[0].option.push(mapOne)
            }
          }
        }
      })
      // 接入方式
      getAccesstype().then((res) => {
        if (res.code === 200) {
          this.options.accesstype = res.data || []
        }
      })
      // 消息格式
      getMsgtype().then(res => {
        if (res.code === 200) {
          this.options.msgtype = res.data || []
        }
      })
      // 产品类别
      getDevicetypes().then((res) => {
        if (res.code === 200) {
          if (this.searchData.length >= 3) {
            this.searchData[1].option = res.data || []
          }
        }
      })
      // 通信协议
      getProtocol().then((res) => {
        if (res.code === 200) {
          this.options.protocol = res.data || []
          if (this.searchData.length >= 3) {
            this.searchData[2].option = res.data || []
          } else {
            this.searchData[0].option = res.data || []
          }
        }
      })
    },
    childByValue(childValue) {
      this.currentPage = childValue.currentPageNum
      this.pageSize = childValue.pageSizeNum
      this.GetListTable()
    },
    // 获取表格数据
    GetListTable() {
      const params = {
        currentPage: this.currentPage,
        pageSize: this.pageSize,
        deviceType: this.form.deviceType,
        protocol: this.form.protocol,
        domain: this.form.domain
      }
      this.tableLoading = true
      getProduct(params).then(res => {
        if (res.code === 200) {
          for (const i in res.data.currentPageContent) {
            res.data.currentPageContent[i].update_ts = parseTime(res.data.currentPageContent[i].update_ts)
            switch (res.data.currentPageContent[i].accessType) {
              case 'DIRECT':
                res.data.currentPageContent[i].accessType = this.$t('access.direct')
                break
              case 'OneNet':
                res.data.currentPageContent[i].accessType = this.$t('access.OneNet')
                break
              case 'CTWing':
                res.data.currentPageContent[i].accessType = this.$t('access.CTWing')
                break
              default:
                break
            }
            switch (res.data.currentPageContent[i].protocol) {
              case 'MQTT':
                res.data.currentPageContent[i].protocol = this.$t('access.Mqttprotocol')
                break
              case 'SL651':
                res.data.currentPageContent[i].protocol = this.$t('access.Mwr651agreement')
                break
              case 'TCP':
                res.data.currentPageContent[i].protocol = this.$t('access.TCPtransparenttransmission')
                break
              case 'HJ212':
                res.data.currentPageContent[i].protocol = this.$t('access.Mep212agreement')
                break
              default:
                break
            }
          }
          this.total = res.data.recordsTotal
          this.tableData = res.data.currentPageContent
        }
      }).finally(() => {
        this.tableLoading = false
      })
    },
    // 表格数据编辑
    handleEdit(index, rows, obj) {
      this.title = this.$t('public.edit')
      getProductcode(rows[index].code).then(res => {
        if (res.code === 200) {
          this.form = res.data
          this.dialogFormVisible = true
          this.indext = index
        }
      })
    },
    // 表格数据删除
    handleDelete(index, rows) {
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      }).then(() => {
        const params = rows[index].code
        delectProduct(params).then((res) => {
          if (res.code === 200) {
            this.$message({
              message: res.data,
              type: 'success'
            })
            if (this.$refs.search) {
              if (this.searchData.length >= 3) {
                if (!this.$refs.search.searchModel[1]) {
                  this.form.domain = ''
                }
                if (!this.$refs.search.searchModel[3]) {
                  this.form.deviceType = ''
                }
              }
              if (!this.$refs.search.searchModel[4]) {
                this.form.protocol = ''
              }
            }
            this.currentPage = 1
            this.GetListTable()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: this.$t('sidebar.canceldelete')
        })
      })
    },
    // 添加数据||或修改数据
    tableDataGet() {
      if (this.indext === -2) {
        this.form.update_ts = new Date().getTime(this.form.update_ts)
        const params = {
          'accessType': this.form.accessType,
          'desc': this.form.desc,
          'deviceType': this.form.deviceType,
          'deviceVendor': this.form.deviceVendor,
          'deviceVendorName': this.form.deviceVendorName,
          'deviceVersion': this.form.deviceVersion,
          'domain': this.form.domain,
          'name': this.form.name,
          'payloadType': this.form.payloadType,
          'protocol': this.form.protocol,
          'tenant': this.userInfo.username
        }
        addProduct(JSON.stringify(params)).then(res => {
          if (res.code === 200) {
            this.dialogFormVisible = false
            this.currentPage = 1
            this.form.protocol = ''
            if (this.$refs.search) {
              if (this.$refs.search.searchModel[4]) {
                this.$refs.search.searchModel[4] = ''
              }
            }
            this.GetListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      } else {
        const params = {
          'accessType': this.form.accessType,
          'desc': this.form.desc,
          'code': this.form.code,
          'deviceType': this.form.deviceType,
          'deviceVendor': this.form.deviceVendor,
          'deviceVendorName': this.form.deviceVendorName,
          'deviceVersion': this.form.deviceVersion,
          'domain': this.form.domain,
          'name': this.form.name,
          'payloadType': this.form.payloadType,
          'protocol': this.form.protocol,
          'update_ts': this.form.update_ts,
          'tenant': this.userInfo.username
        }
        editProduct(JSON.stringify(params)).then(res => {
          if (res.code === 200) {
            this.dialogFormVisible = false
            this.currentPage = 1
            if (this.$refs.search) {
              if (this.searchData.length >= 3) {
                if (!this.$refs.search.searchModel[1]) {
                  this.form.domain = ''
                }
                if (!this.$refs.search.searchModel[3]) {
                  this.form.deviceType = ''
                }
              }
              if (!this.$refs.search.searchModel[4]) {
                this.form.protocol = ''
              }
            }
            this.GetListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      }
    },
    // 添加按钮
    handleEditdia() {
      this.title = this.$t('sidebar.addto')
      this.dialogFormVisible = true
      this.form.accessType = ''
      this.form.protocol = ''
      this.form.update_ts = ''
      this.form.deviceVendor = ''
      this.form.deviceVendorName = ''
      this.form.ext = ''
      this.form.payloadType = ''
      this.form.deviceNum = ''
      this.form.deviceVersion = ''
      this.form.desc = ''
      this.form.name = ''
      this.indext = -2
    },
    // 搜索
    search(obj) {
      this.currentPage = 1
      this.form.domain = obj[1]
      this.form.deviceType = obj[3]
      this.form.protocol = obj[4]
      if (this.searchData.length <= 1) {
        this.form.domain = this.product.item.typeList[1].code
        this.form.deviceType = this.product.item.typeList[2].code
      }
      this.GetListTable()
    },
    // 进入设备
    toPath(val, index, rows) {
      this.$emit('toPath', rows[index], val)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../../styles/variables.scss";
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth} + 10px);
  }
}
.table1 {
  height:50%;
}
.tab {
  position: absolute;
  width: 85%;
  top: 58%;
}
.hide{display: none}
el-row {
    margin-bottom: 20px;
    &:last-child {
      margin-bottom: 0;
    }
  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: none;
    border:none
  }
  .bg-purple-light {
    background: none;
  }
  .logo{
    width:600px;
    margin: 90px 200px 0;
  }

  .grid-content{
    height:280px;
    border-right:none;
    color:#fff;
    line-height:40px;
    padding:18px 30px 0;
  }
 .el-col.el-col-6:nth-child(4) .grid-content{
   border-right:none
 }
  .row-bg {
    padding: 10px 0;
    background-color: none;
  }

.el-button {
  border: none;
  color: #fff;
  font-size: 14px;
}
.dialog_heat {
  background: #20a3f5;
}
.el-tabs--border-card {
  background: none;
  border: none;
}
.el-button--small,
.el-button--small.is-round {
  padding: 9px 0;
}
</style>
