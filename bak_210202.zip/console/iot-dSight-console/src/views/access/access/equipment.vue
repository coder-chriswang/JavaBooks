<template>
  <div style="height:100%">
    <div class="button_add">
      <el-button class="addbutton" @click="deletes">{{ $t('sidebar.MassDeletion') }}</el-button>
      <el-button class="addbutton" @click="importDin()">{{ $t('sidebar.import') }}</el-button>
      <el-dialog :title="$t('sidebar.import')" :visible.sync="dialogImporVisible" :modal-append-to-body="false">
        <el-button size="small" @click="downloadDemo">{{ $t('public.downloadfile') }}</el-button><br>
        <el-upload
          ref="upload"
          class="upload"
          size="small"
          :on-change="handleChange"
          :on-success="handleSuccess"
          :headers="heads"
          :action="urls"
        >
          <el-button class="upload12" size="small">{{ $t('public.Uploadfiles') }}</el-button>
        </el-upload>
        <div class="tips">
          <p>{{ $t('public.step') }}</p>
          {{ $t('public.stepone') }}<br>
          {{ $t('public.steptwo') }}<br>
          {{ $t('public.stepthree') }}<br>
          {{ $t('public.stepfour') }}<br>
          <p>{{ $t('public.careful') }}</p>
          {{ $t('public.carefulone') }}<br>
          {{ $t('public.carefultwo') }}
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogImporVisible = false">{{ $t("sidebar.cancel") }}</el-button>
          <el-button type="primary" @click="upload_determine">{{ $t("sidebar.determine") }}</el-button>
        </div>
      </el-dialog>
      <el-button class="addbutton" @click="exportDinstance()">{{ $t('sidebar.export') }}</el-button>
      <el-button class="addbutton" @click="handleEditdia()">{{ $t('sidebar.addto') }}</el-button>
      <el-dialog :title="title" :visible.sync="dialogFormVisible" :modal-append-to-body="false">
        <el-form :model="dinstance" style="margin-top:15px">
          <el-form-item :label="$t('access.productArea')" :label-width="formLabelWidth">
            <el-select v-model="dinstance.industryName" :placeholder="$t('public.pleaseSelect')" disabled>
              <!-- <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              /> -->
            </el-select>
            <el-select v-model="dinstance.domainName" :placeholder="$t('public.pleaseSelect')" disabled>
              <!-- <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              /> -->
            </el-select>
            <el-select v-model="dinstance.deviceTypeName" :placeholder="$t('public.pleaseSelect')" disabled>
              <!-- <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              /> -->
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('access.devicename')" :label-width="formLabelWidth">
            <el-input v-model="dinstance.name" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('access.IMEI')" :label-width="formLabelWidth">
            <el-input v-model="dinstance.nativeId" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('access.gw_nativeid')" :label-width="formLabelWidth">
            <el-input v-model="dinstance.gw_nativeid" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('access.deviceaddress')" :label-width="formLabelWidth">
            <el-input v-model="location.longitude" autocomplete="off" style="width:40%;float:left;margin-right:5px" :placeholder="$t('access.longitude')" />
            <el-input v-model="location.latitude" autocomplete="off" style="width:40%;float:left;margin-right:5px" :placeholder="$t('access.latitude')" />
            <el-button type="primary" @click="Amap()">{{ $t('access.mapselect') }}</el-button>
          </el-form-item>
          <el-form-item :label="$t('access.mapaddress')" :label-width="formLabelWidth">
            <el-input v-model="location.address" autocomplete="off" :placeholder="$t('access.mapmeageess')" />
          </el-form-item>
          <div v-show="bool" ref="container" class="container" />
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false,bool = false">{{ $t("sidebar.cancel") }}</el-button>
          <el-button type="primary" @click="tableDataP()">{{ $t("sidebar.determine") }}</el-button>
        </div>
      </el-dialog>
    </div>
    <search ref="search" :search-data="searchData" @search="search" />
    <Table
      :class="detaile === false?'table':'table table1'"
      :select="select"
      :table-data="tableData"
      :table-header="tableHeader"
      :current-page="currentPage"
      :pagination="pagination"
      :total="total"
      :page-sizes="pageSizes"
      :last-table-column="firstTableColumn"
      @changeDelete="selectDelete"
      @handler-row="rowClick"
      @pagination-change="childByValue"
    >
      <template slot-scope="scope">
        <el-button size="small" @click="handleEdit(scope.scope.$index,tableData)">{{ $t("public.edit") }}</el-button>
        <el-button
          size="small"
          @click="handleDelete(scope.scope.$index, tableData)"
        >{{ $t("sidebar.delete") }}
        </el-button>
      </template>
    </Table>
    <div class="tab">
      <template v-if="detaile === true">
        <el-tabs v-model="activeName" type="border-card">
          <el-tab-pane :key="'first'" :label="$t('public.detail')" name="first">
            <el-row>
              <el-col :span="6">
                <div class="grid-content bg-purple" label="weee">
                  <ul>
                    <li
                      v-for="child in detils"
                      :key="child.id"
                    >{{ child.name }}:{{ child.value }}</li>
                  </ul>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <ul>
                    <li
                      v-for="child in detils1"
                      :key="child.id"
                    >{{ child.name }}:{{ child.value }}</li>
                  </ul>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <ul>
                    <li
                      v-for="child in detils3"
                      :key="child.id"
                    >{{ child.name }}:{{ child.value }}</li>
                  </ul>
                </div>
              </el-col>
              <el-col :span="6"><div class="grid-content bg-purple" /></el-col>
            </el-row>
          </el-tab-pane>
          <!-- <el-tab-pane :key="'second'" label="上行消息" name="second">
            <div style="background: green; display: inline">
              <Table
                :table-data="tableData"
                :table-header="tableHeader2"
                :current-page="currentPage"
                :pagination="pagination"
                :total="total"
                :page-sizes="pageSizes"
                :last-table-column="lastTableColumne"
                class="table2"
                @pagination-change="childByValue"
              />
            </div>
          </el-tab-pane>
          <el-tab-pane :key="'three'" label="下行消息" name="three">
            <div style="background: green; display: inline">
              <Table
                :table-data="tableData"
                :table-header="tableHeader2"
                :current-page="currentPage"
                :pagination="pagination"
                :total="total"
                :page-size="pageSize"
                :page-sizes="pageSizes"
                :last-table-column="lastTableColumne"
                class="table2"
              />
            </div>
          </el-tab-pane> -->
        </el-tabs>
      </template>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import AMap from 'AMap'
import Table from '@/components/Table/Table'
import search from '@/components/TitleSearch/TitleSearch'
import { parseTime } from '@/utils/index'
import { getStatus, getDInstance, getDinstance, addDinstance, editDinstance, deleteDinstances, delectDinstances, getDinstanceId, downloadDinstance, exportDinstance, importDinstance } from '@/api/access.js'
export default {
  name: 'Alarm',
  components: {
    Table,
    search
  },
  filters: {
    parseTime(time) {
      var data = new Date(time)
      return parseTime(data, 'yyyy-MM-dd')
    }
  },
  props: {
    category: {
      type: Object,
      default: () => {}
    },
    code: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      select: true,
      title: this.$t('public.add'),
      bool: false,
      dialogFormVisible: false,
      dialogTableVisible: false,
      dialogImporVisible: false,
      detaile: false,
      heads: {},
      // 搜索框
      searchData: [
        {
          searchType: 'select',
          searchCondition: true,
          name: this.$t('access.Onlinestatus'),
          id: 1,
          option: []
        },
        {
          searchType: 'select',
          searchCondition: true,
          name: this.$t('access.devicestatus'),
          id: 2,
          option: []
        },
        {
          type: 'text',
          searchCondition: true,
          id: 3,
          name: this.$t('access.IMEI')
        },
        {
          type: 'text',
          searchCondition: true,
          id: 4,
          name: this.$t('access.devicesID')
        }
      ],
      location: {
        longitude: '',
        latitude: '',
        address: ''
      },
      dinstance: {
        name: '',
        nativeId: '',
        gw_nativeid: '',
        onLine: '',
        status: '',
        tenant: '',
        device_type: '',
        deviceds_id: '',
        instanceid: '',
        industryName: '',
        domainName: '',
        deviceTypeName: '',
        rt: '',
        lt: ''
      },
      formLabelWidth: '120px',
      pagination: true,
      currentPage: 1,
      total: 50,
      pageSize: 10,
      pageSizes: [10, 20, 30, 40, 50],
      tableHeader: [
        {
          name: this.$t('access.devicename'),
          id: 'name'
        },
        {
          name: this.$t('access.devicesID'),
          id: 'instanceid'
        },
        {
          name: this.$t('access.productCategory'),
          id: 'device_type'
        },
        {
          name: this.$t('access.tenant'),
          id: 'tenant'
        },
        {
          name: this.$t('access.IMEI'),
          id: 'nativeId'
        },
        {
          name: this.$t('access.updateTs'),
          id: 'rt'
        },
        {
          name: this.$t('access.lasttime'),
          id: 'lt'
        },
        {
          name: this.$t('access.devicestatus'),
          id: 'statusName'
        },
        {
          name: this.$t('access.Onlinestatus'),
          id: 'onLineName'
        },
        {
          name: this.$t('access.gw_nativeid'),
          id: 'gw_nativeid'
        },
        {
          name: this.$t('access.longitude'),
          id: 'longitude'
        },
        {
          name: this.$t('access.latitude'),
          id: 'latitude'
        },
        {
          name: this.$t('access.address'),
          id: 'address'
        }
      ],
      tableHeader2: [
        {
          name: this.$t('access.serialnumber'),
          id: 'id'
        },
        {
          name: this.$t('access.serialdetaile'),
          id: 'adl'
        },
        {
          name: this.$t('access.serialtime'),
          id: 'type'
        },
        {
          name: this.$t('access.handlingresults'),
          id: 'vendor'
        }
      ],
      tableData: [],
      firstTableColumn: true,
      lastTableColumne: false,
      activeName: 'first',
      onLine: '',
      status: '',
      nativeId: '',
      detils: [],
      detils1: [],
      detils3: [],
      indext: -1,
      file: {},
      instanceid: '',
      params: [],
      deleteArr: [],
      upload: '',
      urls: '/rest/gwm/v1/dinstance/import/data/'
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'name'
    ]),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  mounted() {
    this.dinstance.deviceTypeName = this.category.deviceTypeName
    this.dinstance.industryName = this.category.industryName
    this.dinstance.domainName = this.category.domainName
    this.GetListTable()
    this.urls = `/rest/gwm/v1/dinstance/import/data/${this.code}`
  },
  created() {
    getDInstance().then(res => {
      if (res.code === 200) {
        this.searchData[0].option = res.data || []
      }
    })
    getStatus().then(res => {
      if (res.code === 200) {
        this.searchData[1].option = res.data || []
      }
    })
  },
  methods: {
    handleSuccess(res) {
      this.upload = res
    },
    importDin() {
      this.dialogImporVisible = true
    },
    //
    upload_determine() {
      if (this.upload.code === 200) {
        this.$message({
          type: 'success',
          message: this.upload.data
        })
      }
      if (this.$refs.search) {
        if (this.$refs.search.searchModel[1] || this.$refs.search.searchModel[2] || this.$refs.search.searchModel[4] || this.$refs.search.searchModel[3] || this.$refs.search.searchModel[4]) {
          this.$refs.search.searchModel[1] = ''
          this.$refs.search.searchModel[3] = ''
          this.$refs.search.searchModel[2] = ''
          this.$refs.search.searchModel[4] = ''
        }
      }
      this.dialogImporVisible = false
      this.currentPage = 1
      this.nativeId = ''
      this.onLine = ''
      this.status = ''
      this.instanceid = ''
      this.GetListTable()
      this.$refs.upload.clearFiles()
    },
    rowClick(row, event, column) {
      this.detils = []
      this.detils1 = []
      this.detils3 = []
      if (event.fixed === 'right') {
        this.detaile = false
      } else {
        this.detaile = true
      }
      for (const i in this.tableHeader) {
        if (i < 6) {
          const src = {}
          src.name = this.tableHeader[i].name
          src.id = this.tableHeader[i].id
          src.value = row[this.tableHeader[i].id]
          this.detils.push(src)
        }
        if (i >= 6 && i < 12) {
          const src = {}
          src.name = this.tableHeader[i].name
          src.id = this.tableHeader[i].id
          src.value = row[this.tableHeader[i].id]
          this.detils1.push(src)
        }
        if (i >= 12 && i < 13) {
          const src = {}
          src.name = this.tableHeader[i].name
          src.id = this.tableHeader[i].id
          src.value = row[this.tableHeader[i].id]
          this.detils3.push(src)
        }
      }
    },
    // 批量删除
    selectDelete(val) {
      this.deleteArr = []
      if (val.length > 0) {
        for (let i = 0; i < val.length; i++) {
          this.deleteArr.push(val[i].instanceid)
        }
      }
    },
    deletes() {
      if (this.deleteArr.length <= 0) {
        this.$message({
          message: this.$t('tips.selectdect'),
          type: 'warning'
        })
        return
      } else {
        this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
          confirmButtonText: this.$t('sidebar.determine'),
          cancelButtonText: this.$t('sidebar.cancel'),
          type: 'warning'
        })
          .then(() => {
            delectDinstances(this.deleteArr).then(res => {
              if (res.code === 200) {
                this.$message({
                  message: res.data,
                  type: 'success'
                })
                this.params = this.$route.params.title
                this.currentPage = 1
                this.GetListTable()
              }
            })
          })
          .catch(() => {
            this.$message({
              type: 'info',
              message: this.$t('sidebar.canceldelete')
            })
          })
      }
    },

    // 上传文件，获取文件流
    handleChange(file) {
      this.file = file.raw
    },
    // 自定义上传
    uploadFile() {
    // 创建表单对象
      const wenjia = new FormData()
      wenjia.append('file', this.file)
      const excel = wenjia.get('file')
      importDinstance({ 'code': this.params.code, 'file': excel }).then(res => {
        //
      })
    },
    downloadDemo() {
      this.$confirm(this.$t('tips.tipsdownload'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      }).then(res => {
        downloadDinstance().then(res => {
          const content = res.res
          const blob = new Blob([content])
          const fileNames = res.headers['content-disposition'] // 获取到Content-Disposition;filename
          const regFileNames = fileNames.match(/=(.*)$/)[1] // 文件名称  截取=后面的文件名称
          if ('download' in document.createElement('a')) { // 非IE下载
            const elink = document.createElement('a')
            elink.download = regFileNames
            elink.style.display = 'none'
            elink.href = URL.createObjectURL(blob)
            document.body.appendChild(elink)
            elink.click()
            URL.revokeObjectURL(elink.href) // 释放URL 对象
            document.body.removeChild(elink)
          } else { // IE10+下载
            navigator.msSaveBlob(blob, fileNames)
          }
        })
      }).catch(() => {
        this.$message({
          message: this.$t('sidebar.canceldownload'),
          type: 'info'
        })
      })
    },
    childByValue(childValue) {
      this.detaile = false
      this.currentPage = childValue.currentPageNum
      this.pageSize = childValue.pageSizeNum
      this.GetListTable()
    },
    search: function(obj) {
      this.detaile = false
      this.onLine = obj[1]
      this.status = obj[2]
      this.nativeId = obj[3]
      this.instanceid = obj[4]
      this.currentPage = 1
      this.GetListTable()
    },
    // 添加数据||或修改数据
    tableDataP() {
      // switch (this.dinstance.status) {
      //   case this.$t('access.activated'):
      //     this.dinstance.status = 'DSINSTANCE_ACTIVE'
      //     break
      //   case this.$t('access.noactivated'):
      //     this.dinstance.status = 'DSINSTANCE_INACTIVE'
      //     break
      //   default:
      //     break
      // }
      // switch (this.dinstance.onLine) {
      //   case this.$t('access.Online'):
      //     this.dinstance.onLine = 'ONLINE'
      //     break
      //   case this.$t('access.offline'):
      //     this.dinstance.onLine = 'OFFLINE'
      //     break
      //   case this.$t('access.unknown'):
      //     this.dinstance.onLine = 'UNKNOWN'
      //     break
      //   default:
      //     break
      // }
      if (this.indext === -1) {
        const params = {
          'device_type': this.dinstance.device_type,
          'deviceds_id': this.code,
          'gw_nativeid': this.dinstance.gw_nativeid,
          'instanceid': this.dinstance.instanceid,
          'location': JSON.stringify(this.location),
          'name': this.dinstance.name,
          'nativeId': this.dinstance.nativeId,
          'onLine': this.dinstance.onLine,
          'status': this.dinstance.status,
          'tenant': this.dinstance.tenant
        }
        addDinstance(JSON.stringify(params)).then((res) => {
          if (res.code === 200) {
            this.bool = !this.bool
            if (this.$refs.search) {
              if (this.$refs.search.searchModel[1] || this.$refs.search.searchModel[2] || this.$refs.search.searchModel[4] || this.$refs.search.searchModel[3] || this.$refs.search.searchModel[4]) {
                this.$refs.search.searchModel[1] = ''
                this.$refs.search.searchModel[3] = ''
                this.$refs.search.searchModel[2] = ''
                this.$refs.search.searchModel[4] = ''
              }
            }
            this.nativeId = ''
            this.onLine = ''
            this.status = ''
            this.instanceid = ''
            this.dialogFormVisible = false
            this.currentPage = 1
            this.GetListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
        // }
      } else {
        const params = {
          'device_type': this.dinstance.device_type,
          'deviceds_id': this.code,
          'gw_nativeid': this.dinstance.gw_nativeid,
          'instanceid': this.dinstance.instanceid,
          'location': JSON.stringify(this.location),
          'name': this.dinstance.name,
          'rt': this.dinstance.rt,
          'lt': this.dinstance.lt,
          'nativeId': this.dinstance.nativeId,
          'onLine': this.dinstance.onLine,
          'status': this.dinstance.status,
          'tenant': this.dinstance.tenant
        }
        editDinstance(JSON.stringify(params)).then(res => {
          if (res.code === 200) {
            this.bool = !this.bool
            this.dialogFormVisible = false
            this.currentPage = 1
            this.GetListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      }
    },
    // 表格数据编辑
    handleEdit(index, rows) {
      this.title = this.$t('public.edit')
      this.dialogFormVisible = true
      getDinstanceId(rows[index].instanceid).then(res => {
        this.dinstance = res.data
        this.dinstance.instanceid = rows[index].instanceid
        this.dinstance.gw_nativeid = rows[index].gw_nativeid
        this.dinstance.industryName = this.category.industryName
        this.dinstance.domainName = this.category.domainName
        this.dinstance.deviceTypeName = this.category.deviceTypeName
        this.location.address = res.data.address
        this.location.latitude = res.data.latitude
        this.location.longitude = res.data.longitude
        if (!res.data.address) {
          this.location.address = ''
        }
        if (!res.data.latitude) {
          this.location.latitude = ''
        }
        if (!res.data.longitude) {
          this.location.longitude = ''
        }
      })
      this.indext = index
    },
    exportDinstance() {
      const params = {
        pageSize: this.currentPage,
        pageNum: this.pageSize,
        data: {
          'deviceds_id': this.code,
          'onLine': this.onLine,
          'instanceid': this.instanceid,
          'status': this.status,
          'nativeId': this.nativeId
        }
      }
      this.$confirm(this.$t('tips.tipsexport'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      })
        .then(() => {
          exportDinstance(params).then(res => {
            const content = res.res
            const blob = new Blob([content])
            const fileNames = res.headers['content-disposition'] // 获取到Content-Disposition;filename
            const fileName = fileNames.match(/=(.*)$/)[1] // 文件名称  截取=后面的文件名称
            // const fileName = '设备管理列表.xlsx'
            if ('download' in document.createElement('a')) { // 非IE下载
              const elink = document.createElement('a')
              elink.download = fileName
              elink.style.display = 'none'
              elink.href = URL.createObjectURL(blob)
              document.body.appendChild(elink)
              elink.click()
              URL.revokeObjectURL(elink.href) // 释放URL 对象
              document.body.removeChild(elink)
            } else { // IE10+下载
              navigator.msSaveBlob(blob, fileName)
            }
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: this.$t('tips.cancelexport')
          })
        })
    },
    // 添加按钮
    handleEditdia() {
      this.title = this.$t('public.add')
      this.dialogFormVisible = true
      this.dinstance.name = ''
      this.dinstance.nativeId = ''
      this.dinstance.gw_nativeid = ''
      this.location = {
        longitude: '',
        latitude: '',
        address: ''
      }
      this.indext = -1
    },
    // 表格数据删除
    handleDelete(index, rows) {
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      })
        .then(() => {
          const params = rows[index].instanceid
          deleteDinstances(params).then(res => {
            if (res.code === 200) {
              this.$message({
                message: res.data,
                type: 'success'
              })
              this.currentPage = 1
              this.GetListTable()
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: this.$t('sidebar.canceldelete')
          })
        })
    },
    GetListTable() {
      const params = {
        pageNum: this.currentPage,
        pageSize: this.pageSize,
        deviceds_id: this.code,
        onLine: this.onLine,
        status: this.status,
        nativeId: this.nativeId,
        instanceid: this.instanceid
      }
      getDinstance(params).then(res => {
        if (res.code === 200) {
          this.tableData = res.data.currentPageContent
          for (const i in res.data.currentPageContent) {
            if (res.data.currentPageContent[i].rt) {
              res.data.currentPageContent[i].rt = parseTime(res.data.currentPageContent[i].rt)
            }
            if (res.data.currentPageContent[i].lt) {
              res.data.currentPageContent[i].lt = parseTime(res.data.currentPageContent[i].lt)
            }
            res.data.currentPageContent[i].device_type = this.category.deviceTypeName
            // switch (res.data.currentPageContent[i].status) {
            //   case 'DSINSTANCE_ACTIVE':
            //     res.data.currentPageContent[i].status = this.$t('access.activated')
            //     break
            //   case 'DSINSTANCE_INACTIVE':
            //     res.data.currentPageContent[i].status = this.$t('access.noactivated')
            //     break
            //   default:
            //     break
            // }
            // switch (res.data.currentPageContent[i].onLine) {
            //   case 'ONLINE':
            //     res.data.currentPageContent[i].onLine = this.$t('access.Online')
            //     break
            //   case 'OFFLINE':
            //     res.data.currentPageContent[i].onLine = this.$t('access.offline')
            //     break
            //   case 'UNKNOWN':
            //     res.data.currentPageContent[i].onLine = this.$t('access.unknown')
            //     break
            //   default:
            //     break
            // }
          }
          this.total = res.data.recordsTotal
        }
      })
    },
    Amap() {
      this.initMap()
      this.bool = !this.bool
    },
    initMap() {
      var map = new AMap.Map(this.$refs.container, {
        resizeEnable: true, // 是否监控地图容器尺寸变化
        zoom: 11, // 初始化地图层级
        mapStyle: [116.397428, 39.90923], // 设置地图的显示样式
        visible: true
      })

      var geocoder = new AMap.Geocoder({
        city: '010', // 城市设为北京，默认：“全国”
        radius: 1000 // 范围，默认：500
      })
      const that = this
      map.on('click', showInfoClick)
      function showInfoClick(e) {
        map.clearMap()// 清理地图
        const lng = e.lnglat.getLng() // 获取经度
        const lat = e.lnglat.getLat() // 获取纬度
        // marker点
        const marker = new AMap.Marker({
          position: [lng, lat],
          offset: new AMap.Pixel(-13, -30)
        })
        that.location.longitude = lng + ''
        that.location.latitude = lat + '' // 将经纬度绑定至input输入框
        const adds = that.location.longitude + ',' + that.location.latitude
        map.add(marker)
        geocoder.getAddress(adds, function(status, result) {
          if (status === 'complete' && result.regeocode) {
            var address = result.regeocode.formattedAddress
            that.location.address = address
          }
        })

        // 加载点
        map.setFitView() // 缩放至地图
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.container{
  width: 500px;
  height: 300px;
  margin: 0 auto;
}
.table2{
  height:30%;
}
.addbutton{
  float: right
}
.tips{
  margin: 30px 10px 10px;
  border: 1px solid #20A3F5;
  border-radius: 4px;
  padding:30px;
  line-height:20px;
  color: rgb(212, 205, 205)
}
.upload{
  margin-top: 10px
}
.tips p{
  border-left: 4px solid #20A3F5;
  padding-left: 5px
}
.el-tabs--border-card{
  background: none;
  border:none
}
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: none;
    border:none
  }
  .bg-purple-light {
    background: none;
  }
  .grid-content{
    height: 280px;
    color: #fff;
    line-height: 40px;
    padding: 18px 30px 0;
  }
 .el-col.el-col-6:nth-child(4) .grid-content{
   border-right:none
 }
  .row-bg {
    padding: 10px 0;
    background-color: none;
  }
.el-button{
  background: none;
  border:none;
  color:#fff
}
.el-button--small, .el-button--small.is-round{
  padding:9px 0;
}
.top{
  position: relative;
  width:100%;
  background-color: rgba(16,41,108,0.3);
  height:440px;
  margin-bottom: 10px;
}
</style>
<style>
.el-tabs__nav{
  margin-left: 15px
}
.el-tabs--border-card>.el-tabs__header{
  background: none
}
.el-tabs--border-card>.el-tabs__header{
  background: none!important;
  border-bottom:1px solid #1e3675
}
.el-tabs--border-card>.el-tabs__header .el-tabs__item.is-active{
  background: #20A3F5;
  color:#fff
}
.el-tabs--border-card>.el-tabs__header .el-tabs__item.is-active{
  border:none
}
.el-tabs--border-card>.el-tabs__header .el-tabs__item{
   background: #1c214f;
   color:#20A3F5;
   margin-right:20px;
   border-radius: 4px;
}
.el-tabs--border-card>.el-tabs__header .el-tabs__item:not(.is-disabled):hover{
  color:#fff;
}
  .el-dialog__header{
    background: #20A3F5;
    color:#fff;
  }
  .el-dialog__body,.el-dialog__footer{
    background:#10296C;
  }
  .el-input__inner,.el-textarea__inner{
  background-color: #10296C;
  border:1px solid #20A3F5;
  resize: none
}
.el-table, .el-table__expanded-cell{
  background-color: #10296C;
  margin: 10px 0;
}
.el-table thead,.el-table th, .el-table tr{
  background-color: #1c214f;
}
  .el-table tr:nth-child(even) {
    background: #1c214f;
  }
  .el-table tr:nth-child(odd) {
    background: rgba(255,255,255, 0);
  }
  .el-table td, .el-table th.is-leaf{
    border:none;
    color:#fff;
    text-align: center
  }

  .el-table__body tr.current-row > td {
    background: #037fcd;
  }

  .el-table--enable-row-hover .el-table__body tr:hover>td {
    background: #20a3f5;
  }
  .el-form-item__label{
    color:#fff;
  }
  .el-dialog__headerbtn .el-dialog__close,.el-dialog__title{
    color:#fff;
  }
  .el-input__inner, .el-textarea__inner{
    color:#fff
  }
   .el-select{
    margin-right: 5px;
  }
</style>
