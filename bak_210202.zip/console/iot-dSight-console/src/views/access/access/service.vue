<template>
  <div class="alarm-container">
    <div class="top">
      <div class="button_add3">
        <el-button class="addbutton" @click="handleEditdia('attribute')">{{
          $t("access.Addmapping")
        }}</el-button>
        <el-button class="tishi">{{ $t("sidebar.attribute") }}</el-button>
        <el-dialog
          :title="titleattrs"
          :visible.sync="dialogFormVisible"
          :modal-append-to-body="false"
        >
          <el-form :model="attribute" style="margin-top:10px">
            <el-form-item :label="$t('access.productName')" :label-width="formLabelWidth">
              <el-select v-model="attribute.industryName" :placeholder="$t('public.pleaseSelect')" disabled>
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <el-select v-model="attribute.domainName" :placeholder="$t('public.pleaseSelect')" disabled>
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <el-select v-model="attribute.deviceTypeName" :placeholder="$t('public.pleaseSelect')" disabled>
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.attributeidentification')" :label-width="formLabelWidth">
              <el-input v-model="attribute.attr_id" autocomplete="off" :disabled="disabled" />
            </el-form-item>
            <el-form-item :label="$t('access.namebz')" :label-width="formLabelWidth">
              <el-select v-model="attribute.meta_attr_id" :placeholder="$t('public.pleaseSelect')" @change="selectTrigger(attribute.meta_attr_id,'attribute')">
                <el-option
                  v-for="item in attribute.options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.attributeidentificationbz')" :label-width="formLabelWidth">
              <el-input v-model="attribute.meta_attr_Name" autocomplete="off" disabled />
            </el-form-item>
            <el-form-item :label="$t('access.attributetype')" :label-width="formLabelWidth">
              <el-input v-model="attribute.meta_attr_Type" autocomplete="off" disabled />
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
            <el-button type="primary" @click="tableDataP('attribute')">{{ $t("sidebar.determine") }}</el-button>
          </div>
        </el-dialog>
      </div>
      <Table
        :table-data="tableData"
        :table-header="tableHeader"
        :pagination="pagination"
        :last-table-column="lastTableColumn"
        class="table"
      >
        <template slot-scope="scope">
          <el-button
            size="small"
            @click="handleEdit(scope.scope.$index, tableData, 'attribute')"
          >
            {{ $t("public.edit") }}
          </el-button>
          <el-button
            size="small"
            @click="handleDelete(scope.scope.$index, tableData, 'attribute')"
          >
            {{ $t("sidebar.delete") }}
          </el-button>
        </template>
      </Table>
    </div>
    <div class="top">
      <div class="button_add3">
        <el-button class="addbutton" @click="handleEditdia('service')">{{
          $t("access.addserveys")
        }}</el-button>
        <el-button class="tishi">{{ $t("sidebar.service") }}</el-button>
        <el-dialog
          :title="titleactions"
          :visible.sync="dialogTableVisible1"
          :modal-append-to-body="false"
        >
          <el-form :model="attribute" style="margin-top:10px">
            <el-form-item :label="$t('access.productName')" :label-width="formLabelWidth">
              <el-select v-model="attribute.industryName" :placeholder="$t('public.pleaseSelect')" disabled>
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <el-select v-model="attribute.domainName" :placeholder="$t('public.pleaseSelect')" disabled>
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <el-select v-model="attribute.deviceTypeName" :placeholder="$t('public.pleaseSelect')" disabled>
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.serverid')" :label-width="formLabelWidth">
              <el-input v-model="attribute.action_id" autocomplete="off" :disabled="disabled" />
            </el-form-item>
            <el-form-item :label="$t('access.nameservebz')" :label-width="formLabelWidth">
              <el-select v-model="attribute.meta_action_id" :placeholder="$t('public.pleaseSelect')" @change="selectTrigger(attribute.meta_action_id,'service')">
                <el-option
                  v-for="item in attribute.name_type"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item :label="$t('access.serveridbz')" :label-width="formLabelWidth">
              <el-input v-model="attribute.meta_action_name" autocomplete="off" disabled />
            </el-form-item>
            <el-form-item :label="$t('access.typeserveba')" :label-width="formLabelWidth">
              <el-input v-model="attribute.meta_action_type" autocomplete="off" disabled />
            </el-form-item>
            <el-form-item :label="$t('access.templatemethod')" :label-width="formLabelWidth">
              <el-select v-model="attribute.template_method" :placeholder="$t('public.pleaseSelect')" @change="selectTrigger(attribute.template_method,'service')">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
            <el-form-item
              v-if="show"
              :label="$t('access.templatefile')"
              :label-width="formLabelWidth"
            >
              <el-upload
                class="upload-demo"
                action=""
                :on-change="handleChange"
                :http-request="uploadFile"
              >
                <el-button size="small" type="primary">{{ $t('access.clickupload') }}</el-button>
              </el-upload>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogTableVisible1 = false">{{ $t("sidebar.cancel") }}</el-button>
            <el-button type="primary" @click="tableDataP('service')">{{ $t("sidebar.determine") }}</el-button>
          </div>
        </el-dialog>
      </div>
      <Table
        :table-data="tableData2"
        :table-header="tableHeader2"
        :pagination="pagination"
        :total="total2"
        :last-table-column="lastTableColumn"
        class="table"
        @serve="tab_dialog"
      >
        <template slot-scope="scope">
          <el-button
            size="small"
            @click="handleEdit(scope.scope.$index, tableData2, 'service')"
          >
            {{ $t("public.edit") }}
          </el-button>
          <el-button
            size="small"
            @click="handleDelete(scope.scope.$index, tableData2, 'service')"
          >
            {{ $t("sidebar.delete") }}
          </el-button>
        </template>
      </Table>

    </div>
    <el-dialog :title="$t('access.metaattrlist')" :visible.sync="dialogTableVisible2" :append-to-body="true">
      <el-table :data="parameterList[0]">
        <el-table-column property="id" :label="$t('access.attributeidentificationbz')" />
        <el-table-column property="name" :label="$t('access.namebz')" />
        <el-table-column property="type" :label="$t('access.attributetype')" />
      </el-table>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Table from '@/components/Table/Table'
import { getProductciinfo, getActionmap, addActionmap, editActionmap, deleteActionmap, getImport, getAttrmap, addAttrmap, editAttrmap, deleteAttrmap, getDstype, getMethod } from '@/api/access.js'
export default {
  name: 'Alarm',
  components: {
    Table
  },
  props: {
    theme: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      dialogFormVisible: false,
      dialogTableVisible1: false,
      dialogTableVisible2: false,
      gridData: [],
      options: [],
      tanch: false,
      titleattrs: this.$t('access.Addmapping'),
      titleactions: this.$t('access.addserveys'),
      show: false,
      attribute: {
        industryName: '',
        domainName: '',
        deviceTypeName: '',
        template_id: '',
        attr_id: '',
        name_type: [],
        meta_attr_Name: '',
        meta_attr_id: '',
        ds_type: '',
        template_method: '',
        meta_action_name: '',
        meta_action_id: '',
        action_id: '',
        options: [],
        meta_action_type: ''
      },
      formLabelWidth: '120px',
      // table
      pagination: false,
      total: 0,
      parameterList: '',
      indext: -1,
      tableHeader: [
        {
          name: this.$t('access.attributeidentification'),
          id: 'attr_id'
        },
        {
          name: this.$t('access.attributeidentificationbz'),
          id: 'meta_attr_id'
        },
        {
          name: this.$t('access.namebz'),
          id: 'meta_attr_Name'
        },
        {
          name: this.$t('access.metaattrType'),
          id: 'meta_attr_Type'
        }
      ],
      tableHeader2: [
        {
          name: this.$t('access.serverid'),
          id: 'action_id'
        },
        {
          name: this.$t('access.namebz'),
          id: 'meta_action_name'
        },
        {
          name: this.$t('access.typeserveba'),
          id: 'meta_action_type'
        },
        {
          name: this.$t('access.metaactiondirection'),
          id: 'meta_action_direction'
        },
        {
          name: this.$t('access.metaattrlist'),
          id: 'meta_attr_list',
          typeSlot: 123
        },
        {
          name: this.$t('access.templateid'),
          id: 'template_id'
        }
      ],
      tableData: [],
      tableData2: [],
      params: [],
      disabled: 'false',
      ds_type: '',
      total2: 0,
      lastTableColumn: true,
      file: '',
      upLoadData: {
        cpyId: '123456',
        occurTime: '2017-08'
      },
      actionId: '',
      ds_code: '',
      deviceType: '',
      urls: '/gwm/v1/actionmap/import/template/'
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    this.params = this.theme
    this.attribute.industryName = this.theme.industryName
    this.attribute.domainName = this.theme.domainName
    this.attribute.deviceTypeName = this.theme.deviceTypeName
    this.ds_code = this.theme.code
    this.deviceType = this.theme.deviceType
    // let deviceType = 'RainMeterRemoteStation'
    this.GetListTable()
    getDstype().then((res) => {
      if (res.code === 200) {
        for (const i in res.data) {
          if (res.data[i].value === 'DEVICE') {
            this.ds_type = res.data[i].value
          }
        }
      }
    })
    getMethod().then(res => {
      if (res.code === 200) {
        for (const i in res.data) {
          const option = {}
          option.label = res.data[i].label
          option.value = res.data[i].value
          // this.attribute.template_id = res.data[0].label
          this.options.push(option)
        }
      }
    })
    getProductciinfo(this.deviceType).then(res => {
      if (res.code === 200) {
        this.params = res.data
        for (const i in res.data.attrs) {
          const option = {}
          // this.attribute.meta_attr_id = res.data.attrs[0].id
          // this.attribute.meta_attr_Name = res.data.attrs[0].name
          // this.attribute.meta_attr_type = res.data.attrs[0].type
          option.label = res.data.attrs[i].name
          option.value = res.data.attrs[i].id
          option.type = res.data.attrs[i].type
          this.attribute.options.push(option)
        }
        for (const i in res.data.actions) {
          const type = {}
          // this.attribute.meta_action_id = res.data.actions[0].id
          // this.attribute.meta_action_name = res.data.actions[0].name
          // this.attribute.meta_action_type = res.data.actions[0].type
          type.label = res.data.actions[i].name
          type.value = res.data.actions[i].id
          type.type = res.data.actions[i].type
          this.attribute.name_type.push(type)
        }
      }
    })
  },
  methods: {
    // 添加数据
    tableDataP(obj) {
      if (this.indext === -1 && obj === 'attribute') {
        const params = {
          'attr_id': this.attribute.attr_id, // 消息标识
          'ds_code': this.ds_code, // 数据源标识
          'ds_type': this.ds_type, // 数据源类型
          'meta_attr_Name': this.attribute.meta_attr_Name, // 名称
          'meta_attr_Type': this.attribute.ds_type, // 属性
          'meta_attr_id': this.attribute.meta_attr_id // 标准属性标识
        }
        addAttrmap(params).then(res => {
          if (res.code === 200) {
            this.GetListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
            this.dialogFormVisible = false
          }
        })
      } else if (this.indext !== -1 && obj === 'attribute') {
        const params = {
          'attr_id': this.attribute.attr_id, // 消息标识
          'ds_code': this.ds_code, // 数据源标识
          'ds_type': this.ds_type, // 数据源类型
          'meta_attr_Name': this.attribute.meta_attr_Name, // 名称
          'meta_attr_Type': this.attribute.ds_type, // 属性
          'meta_attr_id': this.attribute.meta_attr_id // 标准属性标识
        }
        editAttrmap(params).then((res) => {
          if (res.code === 200) {
            this.GetListTable()
            this.dialogFormVisible = false
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      } else if (this.indext === -1 && obj === 'service') {
        const params = {
          'action_id': this.attribute.action_id, // 消息标识
          'ds_code': this.ds_code, // 数据源标识
          'ds_type': this.ds_type, // 数据源类型
          'meta_action_id': this.attribute.meta_action_id, // 标准属性标识
          'template_method': this.attribute.template_method, // 映射魔板方式
          'template_id': this.attribute.template_id // 映射魔板方式
        }
        addActionmap(params).then((res) => {
          if (res.code === 200) {
            this.GetListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
            this.dialogTableVisible1 = false
          }
        })
      } else if (this.indext !== -1 && obj === 'service') {
        const params = {
          'action_id': this.attribute.action_id, // 消息标识
          'ds_code': this.ds_code, // 数据源标识
          'ds_type': this.ds_type, // 数据源类型
          'meta_action_id': this.attribute.meta_action_id, // 标准属性标识
          'template_method': this.attribute.template_method, // 映射魔板方式
          'template_id': this.attribute.template_id // 映射魔板方式
        }
        editActionmap(params).then((res) => {
          if (res.code === 200) {
            this.GetListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
            this.dialogTableVisible1 = false
          }
        })
      }
    },
    // 添加
    handleEditdia(obj) {
      if (obj === 'attribute') {
        this.titleattrs = this.$t('access.Addmapping')
        this.dialogTableVisible1 = false
        this.dialogFormVisible = true
        this.disabled = false
        this.attribute.attr_id = ''
        this.attribute.meta_attr_Name = ''
        this.attribute.meta_attr_Type = ''
        this.attribute.meta_attr_id = ''
      } else if (obj === 'service') {
        this.titleactions = this.$t('access.addserveys')
        this.dialogTableVisible1 = true
        this.dialogFormVisible = false
        this.disabled = false
        this.attribute.action_id = ''
        this.attribute.meta_action_id = ''
        this.attribute.meta_action_name = ''
        this.attribute.meta_action_type = ''
        this.attribute.template_method = ''
        this.attribute.template_id = ''
        this.show = false
      }
      this.indext = -1
    },
    // 表格数据编辑
    handleEdit(index, rows, obj) {
      this.indext = index
      this.disabled = true
      if (obj === 'attribute') {
        this.titleattrs = this.$t('access.editmapping')
        this.dialogTableVisible = false
        this.dialogFormVisible = true
        this.attribute.attr_id = rows[index].attr_id
        this.attribute.ds_type = rows[index].ds_type
        this.ds_code = rows[index].ds_code
        this.attribute.meta_attr_Name = rows[index].meta_attr_Name
        this.attribute.meta_attr_Type = rows[index].meta_attr_Type
        this.attribute.meta_attr_id = rows[index].meta_attr_id
      } else if (obj === 'service') {
        this.titleactions = this.$t('access.editserveys')
        this.dialogTableVisible1 = true
        this.dialogFormVisible = false
        this.dialogTableVisible = false
        this.ds_code = rows[index].ds_code
        this.attribute.action_id = rows[index].action_id
        this.actionId = rows[index].action_id
        this.ds_type = rows[index].ds_type
        this.attribute.meta_action_id = rows[index].meta_action_id
        this.attribute.meta_action_name = rows[index].meta_action_id
        this.attribute.meta_action_type = rows[index].meta_action_type
        this.attribute.template_id = rows[index].template_id
        this.attribute.template_method = rows[index].template_method
        if (rows[index].template_method === 'NOAUTO') {
          this.show = true
        } else {
          this.show = false
        }
      }
    },
    // 表格数据删除
    handleDelete(index, rows, obj) {
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      }).then(() => {
        if (obj === 'attribute') {
          const params = {
            attr_id: rows[index].attr_id,
            ds_code: rows[index].ds_code,
            ds_type: rows[index].ds_type
          }
          deleteAttrmap(params).then((res) => {
            if (res.code === 200) {
              rows.splice(index, 1)
              this.$message({
                message: res.data,
                type: 'success'
              })
            } else {
              this.$message({
                message: res.message,
                type: 'error'
              })
            }
          })
        }
        if (obj === 'service') {
          const params = {
            actionid: rows[index].action_id,
            ds_code: rows[index].ds_code,
            ds_type: rows[index].ds_type
          }
          deleteActionmap(params).then((res) => {
            if (res.code === 200) {
              rows.splice(index, 1)
              this.$message({
                message: res.data,
                type: 'success'
              })
            } else {
              this.$message({
                message: res.message,
                type: 'error'
              })
            }
          })
        }
      })
        .catch(() => {
          this.$message({
            type: 'info',
            message: this.$t('sidebar.canceldelete')
          })
        })
    },
    // 获取服务属性
    GetListTable() {
      getAttrmap(this.ds_code).then((res) => {
        if (res.code === 200) {
          this.tableData = res.data
        }
      })
      getActionmap(this.ds_code).then((res) => {
        if (res.code === 200) {
          for (const i in res.data) {
            switch (res.data[i].meta_action_type) {
              case 'Device':
                res.data[i].meta_action_type = this.$t('access.devicetype')
                break
              case 'System':
                res.data[i].meta_action_type = this.$t('access.systemtype')
                break
              default:
                break
            }
            switch (res.data[i].meta_action_direction) {
              case 'Uplink':
                res.data[i].meta_action_direction = this.$t('access.uplink')
                break
              case 'Downlink':
                res.data[i].meta_action_direction = this.$t('access.downlink')
                break
              default:
                break
            }
          }
          this.tableData2 = res.data
        }
      })
    },
    selectTrigger(val, obj) {
      if (obj === 'service') {
        for (const i in this.attribute.name_type) {
          if (val === this.attribute.name_type[i].value) {
            this.attribute.meta_action_name = this.attribute.name_type[i].value
            switch (this.attribute.name_type[i].type) {
              case 'Device':
                this.attribute.name_type[i].type = this.$t('access.devicetype')
                break
              case 'System':
                this.attribute.name_type[i].type = this.$t('access.systemtype')
                break
              default:
                break
            }
            this.attribute.meta_action_type = this.attribute.name_type[i].type
          }
        }
        if (val === 'NOAUTO') {
          this.show = true
        } else {
          this.show = false
        }
      } else if (obj === 'attribute') {
        for (const i in this.attribute.options) {
          if (val === this.attribute.options[i].value) {
            this.attribute.meta_attr_Name = this.attribute.options[i].value
            this.attribute.meta_attr_Type = this.attribute.options[i].type
          }
        }
      }
    },
    // 上传文件，获取文件流
    handleChange(file) {
      this.file = file.raw
    },
    // 自定义上传
    uploadFile(Files) {
      // 创建表单对象
      this.actionId = this.attribute.action_id
      const wenjia = new FormData()
      wenjia.append('file', Files.file)
      getImport({ param: wenjia, dsType: this.ds_type, actionId: this.actionId, dsCode: this.ds_code }).then((res) => {
        if (res.code === 200) {
          this.$message({
            message: this.$t('tips.uplosdseccess'),
            type: 'success'
          })
          this.attribute.template_id = res.data.templateid
        } else {
          this.$message({
            message: res.message,
            type: 'success'
          })
        }
      })
    },
    tab_dialog(data, index) {
      this.parameterList = []
      this.reverse = data
      if (this.reverse === true) {
        this.dialogTableVisible2 = this.reverse
      }
      const data_lint = this.tableData2[0].meta_attr_list
      var shuju = []
      for (const i in data_lint) {
        shuju.push(data_lint[i])
      }
      this.parameterList.push(shuju)
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../../styles/variables.scss";
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth} + 10px);
  }
}
.table {
  margin-left: 1%;
  margin-top: 15px;
  position: absolute;
  width: 98%;
  left: 0;
  height: 100%;
}
.button_add3.button_add  {
   width: 97%;
   top: 5px
}
.addbutton {
  position: absolute;
  right: 3%;
  top: 10px;
}
.button {
  position: relative;
}
.button button {
  background-color: #20a3f5;
  color: #fff;
  border: none;
  line-height: 30px;
  padding: 0 15px;
  font-size: 12px;
  left:0;
  border-radius: 4px;
  margin: 0 5px;
}
.button_add button.tishi {
  position: absolute;
  top: 10px;
  left: 15px;
  background-color: #10296c;
  color: #20a3f5;
}
.el-button {
  background: none;
  border: none;
  color: #fff;
}
.el-button--small,
.el-button--small.is-round {
  padding: 9px 0;
}
.top {
  position: relative;
  width: 100%;
  background-color: rgba(16, 41, 108, 0.3);
  height: 45%;
  margin-bottom: 10px;
}
</style>
<style>
.el-dialog__header {
  background: #20a3f5;
  color: #fff;
}
.el-dialog__body,
.el-dialog__footer {
  background: #10296c;
}
.el-input__inner,
.el-textarea__inner {
  background-color: #10296c;
  border: 1px solid #20a3f5;
  resize: none;
}
.el-table,
.el-table__expanded-cell {
  background-color: #10296c;
  margin: 10px 0;
}
.el-table thead,
.el-table th,
.el-table tr {
  background-color: #1c214f;
}
.el-table tr:nth-child(even) {
  background: #1c214f;
}
.el-table tr:nth-child(odd) {
  background: rgba(255, 255, 255, 0);
}
.el-table td,
.el-table th.is-leaf {
  border: none;
  color: #fff;
  text-align: center;
}

.el-table__body tr.current-row > td {
  background: #037fcd;
}

.el-table--enable-row-hover .el-table__body tr:hover > td {
  background: #20a3f5;
}
.el-form-item__label {
  color: #fff;
}
.el-dialog__headerbtn .el-dialog__close,
.el-dialog__title {
  color: #fff;
}
.el-input__inner,
.el-textarea__inner {
  color: #fff;
}
.el-select {
  margin-right: 5px;
}
.el-input.is-disabled .el-input__inner{
    background-color: #10296c;
    border: 1px solid #20a3f5;
}
</style>
