<template>
  <div class="login-container">
    <div class="title-div">
      <img src="../../assets/login_logo.png">
    </div>
    <div class="login-form">
      <el-col :span="14" class="login-left">
        <el-form ref="loginForm" :model="loginForm" :rules="loginRules" auto-complete="on" label-position="top">
          <div class="title-container">
            <h3 class="title">{{ $t('login.logIn') }}</h3>
          </div>
          <el-form-item prop="username">
            <label class="form-label">{{ $t('login.username') }}</label>
            <el-input
              ref="username"
              v-model="loginForm.username"
              :placeholder="$t('login.username')"
              name="username"
              type="text"
              tabindex="1"
              auto-complete="on"
            />
          </el-form-item>
          <el-form-item prop="password">
            <label class="form-label">{{ $t('login.password') }}</label>
            <el-input
              :key="passwordType"
              ref="password"
              v-model="loginForm.password"
              :type="passwordType"
              :placeholder="$t('login.password')"
              name="password"
              tabindex="2"
              auto-complete="on"
              @keyup.enter.native="handleLogin"
            />
            <span class="show-pwd" @click="showPwd">
              <svg-icon :icon-class="passwordType === 'password' ? 'eye' : 'eye-open'" />
            </span>
          </el-form-item>

          <el-form-item prop="verificationCode">
            <label class="form-label">{{ $t('login.virifyCode') }}</label>
            <el-input
              ref="verificationCode"
              v-model="loginForm.verificationCode"
              :placeholder="$t('login.virifyCode')"
              name="verificationCode"
              tabindex="2"
              @keyup.enter.native="handleLogin"
            >
              <template
                slot="append"
              >
                <img
                  :src="codeImage"
                  style="cursor: pointer;"
                  @click="changeCode"
                >
              </template>
            </el-input>
          </el-form-item>
          <!-- <el-button type="text">{{ $t('login.forFetPW') }}</el-button> -->
          <el-button :loading="loading" type="primary" style="margin-left: 0;display: block" @click.native.prevent="handleLogin">{{ $t('login.logIn') }}</el-button>
        </el-form>
      </el-col>
      <el-col :span="10" class="login-right">
        <el-row>
          <LangSelect class="lang-selete" :hide-words="true" />
        </el-row>
        <el-row style="height: 100%;">
          <el-carousel style="height: 100%;" arrow="never">
            <el-carousel-item>
              <h3 class="login-right-h3">{{ $t('login.title') }}</h3>
              <p class="login-right-p">{{ $t('login.rightDes1') }}</p>
            </el-carousel-item>
            <el-carousel-item>
              <h3 class="login-right-h3">{{ $t('login.title') }}</h3>
              <p class="login-right-p">{{ $t('login.rightDes1') }}</p>
            </el-carousel-item>
            <el-carousel-item>
              <h3 class="login-right-h3">{{ $t('login.title') }}</h3>
              <p class="login-right-p">{{ $t('login.rightDes1') }}</p>
            </el-carousel-item>
            <el-carousel-item>
              <h3 class="login-right-h3">{{ $t('login.title') }}</h3>
              <p class="login-right-p">{{ $t('login.rightDes1') }}</p>
            </el-carousel-item>
            <el-carousel-item>
              <h3 class="login-right-h3">{{ $t('login.title') }}</h3>
              <p class="login-right-p">{{ $t('login.rightDes1') }}</p>
            </el-carousel-item>
          </el-carousel>
        </el-row>
      </el-col>
    </div>
    <div class="footer">
      <span>{{ $t('login.CopyRight') }}</span>
      <a href="http://www.neoway.com/">{{ $t('login.emailAndTel') }}</a>
    </div>
  </div>
</template>

<script>
import LangSelect from '@/components/LangSelect/index.vue'

export default {
  name: 'Login',
  components: {
    LangSelect
  },
  data() {
    return {
      loginForm: {
        username: '',
        password: '',
        verificationCode: ''
      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', message: this.$t('login.usernameTips') }],
        password: [{ required: true, trigger: 'blur', message: this.$t('login.passwordTips') }],
        verificationCode: [{ required: true, trigger: 'blur', message: this.$t('login.verificationCodeTips') }]
      },
      codeImage: null,
      loading: false,
      passwordType: 'password',
      uuid: '',
      redirect: undefined
    }
  },
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect
      },
      immediate: true
    }
  },
  created() {
    this.changeCode()
  },
  methods: {
    changeCode() {
      this.uuid = this.generateUUID()
      sessionStorage.setItem('uuid', this.uuid)
      this.codeImage = process.env.VUE_APP_BASE_API + '/common/codeImage?sid=' + this.uuid
    },
    generateUUID() {
      var d = new Date().getTime()
      if (window.performance && typeof window.performance.now === 'function') {
        d += performance.now() // use high-precision timer if available
      }
      var uuid = 'xxxxxxxxxxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random() * 16) % 16 | 0
        d = Math.floor(d / 16)
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16)
      })
      return uuid.replace(/[-]/g, '')
    },
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          this.$store
            .dispatch('user/login', this.loginForm)
            .then(() => {
              this.$store.dispatch('user/getInfo')
              // this.$router.push({ path: this.redirect || '/statistics' })
              this.$router.push({ path: '/data' })
              this.loading = false
            })
            .catch(() => {
              this.loading = false
            })
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss">
.login-container {
  .el-input {
    .el-input-group__append {
      background-color: transparent;
      height: 36px;
      padding: 0;
      border: 0;
      left: auto !important;
      width: 120px !important;
      border-radius: 0;
      text-align: right;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
}
.el-carousel__button {
  width: 5px !important;
  height: 5px !important;
  border-radius: 50% !important;
}
.el-carousel__indicator.is-active button {
  opacity: 2;
}
</style>
<style lang="scss" scoped>
@import '../../styles/variables.scss';

.login-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;

  min-height: 100%;
  width: 100%;
  background-color: $bg;
  background: url("../../assets/loginBg.jpg") center center no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
  overflow: hidden;
  .title-div,.footer {
    padding: 40px 0;
  }
  .footer{
    font-size: 14px;
    span{
      color: $dark_gray;
    }
    a {
      color: #1E7BBA;
    }
  }
  .login-form {
      position: relative;
      // align-self: center;
      width: 50%;
      height: 486px;
      max-width: 720px;
      min-width: 540px;
      border-radius: 3px;
    .login-left,.login-right {
      // width: 520px;
      height: 100%;
      max-width: 100%;
      margin: 0 auto;
      overflow: hidden;
      background: #fff;
      padding: 30px;
    }
    .login-left {
      border-top-left-radius: 3px;
      border-bottom-left-radius: 3px;
    }
    .login-right{
      background: rgba($color: #000000, $alpha: 0.3);
      border-top-right-radius: 3px;
      border-bottom-right-radius: 3px;
      .lang-selete {
        float: right;
        color: #fff;
      }
      .login-right-h3 {
        float: left;
        display: contents;
        color: #fff;
      }
       .login-right-p {
        color: #fff;
        font-size: 14px;
        line-height: 26px;
        text-indent:2em;
      }
    }
  }

  .svg-container {
    padding: 6px 5px 6px 15px;
    color: $dark_gray;
    vertical-align: middle;
    width: 30px;
    display: inline-block;
  }

  .title-container {
    position: relative;
    .title {
      font-size: 26px;
      margin: 20px auto;
      font-weight: bold;
    }
  }

  .show-pwd {
    position: absolute;
    right: 10px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }
  .form-label {
    color: #606266
  }
}
</style>
