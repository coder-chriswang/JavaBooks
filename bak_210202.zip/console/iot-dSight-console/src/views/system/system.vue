<template>
  <div>
    <SiderBar :menu-list="menuList" @menu-active="menuActive" />
    <div class="Breadcrumb">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item>{{
          $t("route.data")
        }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t("route.wholenetwork") }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="button">
      <el-button>{{
        $t("sidebar.export")
      }}</el-button>
    </div>
    <el-main id="main_body" :class="containerClass">
      <div class="alarm-container">
        <search :search-data="searchData" @search="search" />
        <div class="button">
          <el-button @click="handleEditdia()">{{ $t("sidebar.addto") }}</el-button>
          <el-dialog
            :title="$t('public.add')"
            :model="system"
            :visible.sync="dialogFormVisible"
            :modal-append-to-body="false"
          >
            <el-form :model="system">
              <el-form-item :label="$t('system.name')" :label-width="formLabelWidth">
                <el-input v-model="system.name" autocomplete="off" />
              </el-form-item>
              <el-form-item :label="$t('system.nativeId')" :label-width="formLabelWidth">
                <el-input v-model="system.nativeId" autocomplete="off" />
              </el-form-item>
              <el-form-item :label="$t('system.xiayi')" :label-width="formLabelWidth" class="input_width">
                <el-select v-model="system.xiayi" :placeholder="$t('metadata.pleaseSelect')">
                  <el-option
                    v-for="item in optionw"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                :label="$t('system.authentication')"
                :label-width="formLabelWidth"
                class="input_width"
              >
                <el-select v-model="system.fangshi" :placeholder="$t('metadata.pleaseSelect')">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                :label="$t('system.username')"
                :label-width="formLabelWidth"
                class="input_width"
              >
                <el-input v-model="system.username" autocomplete="off" />
              </el-form-item>
              <el-form-item
                :label="$t('system.password')"
                :label-width="formLabelWidth"
                class="input_width"
              >
                <el-input v-model="system.password" autocomplete="off" />
              </el-form-item>
              <el-form-item
                v-show="system.xiayi === 'HTTPS'"
                :label="$t('system.certificate')"
                :label-width="formLabelWidth"
                class="clear"
              >
                <el-upload
                  class="upload-demo"
                  action=""
                  :on-change="handleChange"
                  :http-request="uploadFile"
                >
                  <el-button size="small" type="primary">{{ $t("system.clickupload") }}</el-button>
                </el-upload>
              </el-form-item>
              <el-button class="child_button" type="primary" @click="handleAdd()">
                {{ $t("public.add") }}
              </el-button>
              <el-table ref="mytable" :data="table_data" style="width: 100%">
                <el-table-column
                  v-for="(item, index, key) in gridData"
                  :key="key"
                  align="center"
                  :item="item"
                  :index="index"
                  :label="item.label"
                >
                  <template slot-scope="scope">
                    <el-input
                      v-if="scope.row.edit"
                      v-model="scope.row[item.prop]"
                      size="small"
                      :placeholder="$t('metadata.pleaseEnter') + item.label"
                    />
                    <span v-if="!scope.row.edit">{{ scope.row[item.prop] }}</span>
                  </template>
                </el-table-column>
                <el-table-column :label="$t('sidebar.operation')" align="center">
                  <template slot-scope="scope">
                    <!-- 全局控制的编辑 -->
                    <div
                      v-if="is_edit && !scope.row.add"
                      style="display: inline-block"
                    >
                      <!-- 编辑 -->
                      <el-button
                        v-if="!scope.row.edit"
                        size="mini"
                        class="save_button"
                        type="primary"
                        @click="handleEdit(scope.$index, scope.row)"
                      ><i class="el-icon-edit-outline" />
                      </el-button>
                      <!-- 保存 -->
                      <el-button
                        v-if="scope.row.edit"
                        size="mini"
                        type="success"
                        :plain="true"
                        class="save_button"
                        @click="handleSave(scope.$index, scope.row)"
                      ><i class="el-icon-finished" />
                      </el-button>
                    </div>
                    <!-- 添加控制 -->
                    <div
                      v-if="scope.row.add != undefined && scope.row.add"
                      style="display: inline-block"
                    >
                      <!-- 保存 -->
                      <el-button
                        v-if="scope.row.edit"
                        size="mini"
                        type="success"
                        :plain="true"
                        class="save_button"
                        @click="handleSave(scope.$index, scope.row)"
                      ><i class="el-icon-finished" />
                      </el-button>
                    </div>
                    <!-- 全局控制删除 -->
                    <el-button
                      v-if="is_delete && scope.row.add === undefined"
                      size="mini"
                      :plain="true"
                      type="danger"
                      class="save_button"
                      @click="handleDelete(scope.$index, scope.row)"
                    ><i class="el-icon-delete" />
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
              <el-button
                type="primary"
                @click="systemAdd()"
              >{{ $t("sidebar.determine") }}
              </el-button>
            </div>
          </el-dialog>
        </div>
        <Table
          :table-data="tableData"
          :table-header="tableHeader"
          :current-page="currentPage"
          :pagination="pagination"
          :total="total"
          :page-sizes="pageSizes"
          :page-size="pageSize"
          :last-table-column="lastTableColumn"
          class="table"
          @pagination-change="childByValue"
        >
          <template slot-scope="scope">
            <el-button
              size="small"
              @click="handleEditw(scope.scope.$index, tableData)"
            ><i class="el-icon-edit-outline" />
            </el-button>
            <el-button
              size="small"
              @click="handleDeletew(scope.scope.$index, tableData)"
            ><i class="el-icon-delete" />
            </el-button>
            <el-button
              size="small"
              @click="handleEdit(scope.scope.$index, tableData)"
            ><i class="el-icon-s-operation" />
            </el-button>
          </template>
        </Table>
      </div>
    </el-main>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import Table from '@/components/Table/Table'
import search from '@/components/TitleSearch/TitleSearch'
// import chart from '@/components/Chart/Chart'
import { parseTime } from '@/utils/index'
// import { getChartID, getChartViewData } from '@/api/user'
// import { getChartOptions } from '@/utils/getChartOptions'
import { getSinstance, addSinstance, editSinstance, deleteSinstance, getTree, getSnstance, getProtocol, getAuthway, getCertificate, getConnectivity } from '@/api/system.js'
export default {
  name: 'Statistics',
  components: {
    SiderBar,
    Table,
    search
  },
  filters: {
    parseTime(time) {
      var data = new Date(time)
      return parseTime(data, 'yyyy-MM-dd')
    }
  },
  data() {
    return {
      menuList: [
        {
          label: this.$t('sidebar.source'),
          icon: 'icon-peizhi',
          isActive: true,
          id: '1',
          children: []
        }
      ],
      filters: {
        parseTime(time) {
          var data = new Date(time)
          return parseTime(data, 'yyyy-MM-dd')
        }
      },
      is_edit: true, // 是否可编辑
      is_delete: true, // 是否可删除
      gridData: [
        {
          prop: 'bmd',
          label: this.$t('system.whitelist'),
          width: '150'
        },
        {
          prop: 'decs',
          label: this.$t('metadata.desc'),
          width: '150'
        }
      ],
      chartOptions: [],
      title: this.$t('public.add'),
      chartId: '',
      tabPosition: 'details',
      dialogFormVisible: false,
      value1: [],
      options: [],
      optionw: [],
      system: {
        nativeId: '',
        type: '',
        name: '',
        connectivity: '',
        xieyi: '',
        rt: '',
        username: '',
        password: '',
        fangshi: ''
      },
      formLabelWidth: '80px',
      pagination: true,
      currentPage: 1,
      total: 50,
      pageSizes: [10, 20, 30, 40, 50],
      // 搜索框
      searchData: [
        {
          searchType: 'select',
          searchCondition: '122',
          name: this.$t('system.connectivitystate'),
          option: [],
          value: ''
        }
      ],
      tableHeader: [
        {
          name: this.$t('system.systemtype'),
          id: 'type'
        },
        {
          name: this.$t('system.name'),
          id: 'name'
        },
        {
          name: this.$t('system.nativeId'),
          id: 'nativeId'
        },
        {
          name: this.$t('system.updateTs'),
          id: 'rt'
        },
        {
          name: this.$t('system.connectivitystate'),
          id: 'connectivity',
          typeSlot: 'slot'
        }
      ],
      tableData: [],
      pageSize: 4,
      lastTableColumn: true,
      activeName: 'first',
      table_data: [],
      id: '',
      systemType: '',
      connectivity: '',
      instanceId: '',
      optiondata: [
        {
          label: 'name',
          icon: 'icon-peizhi',
          isActive: 3,
          id: 0
        }
      ],
      indext: -1,
      file: {}
    }
  },
  computed: {
    ...mapGetters([
      'sidebar',
      'name'
    ]),
    containerClass() {
      return {
        main_body: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    this.GetListImg()
    this.GetListselectx()
    this.GetListselect()
    this.GetListselecty()
  },
  methods: {
    search: function(obj) {
      const page = {
        currentPageNum: this.currentPage,
        pageSizeNum: this.pageSize,
        id: this.id,
        systemType: obj.undefined,
        connectivity: this.connectivity
      }
      this.GetListTable(page)
    },
    // 白名单
    handleEdit(index, row) {
      // this.dialogFormVisible = true;
      row.edit = true
    },
    // 保存
    handleSave(index, row) {
      row.edit = false

      delete this.table_data[index].add
    },
    handleAdd() {
      var addDataJson = {}
      for (var key in this.new_date_json) {
        if (key === 'edit') {
          delete addDataJson[key]
        } else if (key === 'add') {
          delete addDataJson[key]
        } else {
          addDataJson[key] = ''
        }
      }
      addDataJson.edit = true
      addDataJson.add = true
      this.table_data.push(addDataJson)
    },

    // 初始化编辑属性
    initEditAttribute() {
      var dataArray = this.table_dat
      if (dataArray.length > 0) {
        // 添加编辑事件
        for (var index in dataArray) {
          dataArray[index]['edit'] = false
          // this.table_data.push(dataArray[index]);
        }

        if (Object.keys(this.new_date_json).length === 0) {
          // 新增时，初始化数据结构
          this.initAddDataJson(dataArray[0])
        }
      }
    },
    initAddDataJson(dataArray) {
      // 新增时，初始化数据结构
      var dataJson = dataArray
      var newDateJson = {}
      for (var key in dataJson) {
        if (key === 'edit') {
          newDateJson[key] = 'true'
        } else {
          newDateJson[key] = ''
        }
      }
      newDateJson['add'] = true
      this.new_date_json = newDateJson
    },
    // 数据添加
    handleEditdia() {
      this.indext = -1
      this.system.xieyi = ''
      this.system.username = ''
      this.system.password = ''
      this.system.fangshi = ''
      this.system.name = ''
      this.system.type = this.systemType
      this.system.id = ''
      this.system.nativeId = ''// 域名
      this.dialogFormVisible = true
    },
    // handleEdit编辑查询详情
    handleEditw(index, row) {
      this.indext = index
      const instanceId = row[index].instanceId
      getSnstance(instanceId).then(res => {
        if (res.code === 200) {
          const ext = JSON.parse(res.data.ext)
          this.system.name = res.data.name
          this.system.nativeId = res.data.name // 域名
          this.id = res.data.systemId
          this.table_data = ext.whiteList
          this.instanceId = res.data.instanceId
          this.system.xieyi = ext.xieyi
          this.system.rt = res.data.rt
          this.system.username = ext.username
          this.system.password = ext.password
          this.system.fangshi = ext.fangshi
          this.system.type = res.data.type
          this.dialogFormVisible = true
        }
      })
    },
    // 添加或编辑接口调用
    systemAdd() {
      if (this.indext === -1) {
        const params = {
          'name': this.system.name,
          'nativeId': this.system.nativeId, // 域名
          'systemId': this.id,
          'instanceId': this.instanceId,
          'ext': {
            'xieyi': this.system.xieyi,
            'time': this.system.time,
            'username': this.system.username,
            'password': this.system.password,
            'fangshi': this.system.fangshi,
            'whiteList': this.table_data
          }
        }
        addSinstance(params).then(res => {
          if (res.code === 200) {
            const timestamp3 = new Date().getTime()
            this.system.rt = parseTime(timestamp3)
            this.system.type = this.systemType
            const page = {
              currentPageNum: this.currentPage,
              pageSizeNum: this.pageSize,
              id: this.id,
              systemType: this.systemType,
              connectivity: this.connectivity
            }
            this.GetListTable(page)
            this.dialogFormVisible = false
          }
        })
      } else {
        const params = {
          'name': this.system.name,
          'nativeId': this.system.nativeId, // 域名
          'systemId': this.id,
          'instanceId': this.instanceId,
          'ext': {
            'xieyi': this.system.xieyi,
            'time': this.system.time,
            'username': this.system.username,
            'password': this.system.password,
            'fangshi': this.system.fangshi,
            'whiteList': this.table_data
          }
        }
        editSinstance(params).then(res => {
          if (res.code === 200) {
            const page = {
              currentPageNum: this.currentPage,
              pageSizeNum: this.pageSize,
              id: this.id,
              systemType: this.systemType,
              connectivity: this.connectivity
            }
            this.GetListTable(page)
            this.dialogFormVisible = false
          }
        })
      }
    },
    menuActive(val) {
      if (this.id) {
        this.systemType = val.item.systemType
        this.id = val.item.code
        // this.connectivity = this.connectivity
        const page = {
          currentPageNum: this.currentPage,
          pageSizeNum: this.pageSize,
          id: this.id,
          systemType: this.systemType,
          connectivity: this.connectivity
        }
        this.GetListTable(page)
      }
    },
    childByValue: function(childValue) {
      const page = {
        currentPageNum: childValue.currentPageNum,
        pageSizeNum: childValue.pageSizeNum,
        id: this.id,
        systemType: this.systemType,
        connectivity: this.connectivity
      }
      this.GetListTable(page)
    },
    // 外层删除
    handleDeletew(index, row) {
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      }).then(() => {
        const id = row[index].instanceId
        deleteSinstance(id).then(res => {
          if (res.code === 200) {
            row.splice(index, 1)
            this.$message({
              message: res.data,
              type: 'success'
            })
            this.total = this.tableData.length
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: this.$t('sidebar.canceldelete')
        })
      })
    },
    // 获取左边导航数据
    GetListImg() {
      getTree().then((res) => {
        const Tree = res.data
        if (res.data) {
          for (let i = 0; i < Tree.length; i++) {
            const menuList2 = {}
            menuList2.systemType = Tree[i].systemType
            menuList2.label = Tree[i].systemType
            menuList2.protocol = Tree[i].protocol
            menuList2.ext = Tree[i].ext
            menuList2.connectivity = Tree[i].connectivity
            menuList2.code = Tree[i].code
            menuList2.tenant = Tree[i].tenant
            menuList2.id = i + 1
            this.id = Tree[i].version
            this.id = Tree[0].code
            this.instanceId = Tree[0].systemType
            this.systemType = Tree[0].systemType
            this.menuList[0].children.push(menuList2)
            const page = {
              currentPageNum: this.currentPage,
              pageSizeNum: this.pageSize,
              id: this.id,
              systemType: this.systemType,
              connectivity: this.connectivity
            }
            this.GetListTable(page)
          }
        }
      })
    },
    // 获取连通性测试  (需求待确认)
    // liantongx(id){
    // this.$axios({
    // method: 'post',
    // url:`/gwm/v1/systemds/connectivity/${id}`,
    // headers: {
    //   'Content-Type': 'application/json'
    // }
    // })
    // .then(res => {
    //  this.connectivity =  res.data.data
    // })
    // },
    // //获取表格数据
    GetListTable(params) {
      getSinstance(params).then(res => {
        for (const i in res.data.currentPageContent) {
          res.data.currentPageContent[i].rt = parseTime(res.data.currentPageContent[i].rt)
        }
        this.tableData = res.data.currentPageContent
        this.total = res.data.recordsTotal
        // }
      })
    },
    // 获取认证方式
    GetListselect() {
      getAuthway().then(res => {
        for (const i in res.data) {
          const option = {}
          option.label = res.data[i].label
          option.value = res.data[i].value
          this.options.push(option)
        }
      })
    },
    // 获取协议
    GetListselecty() {
      getProtocol().then(res => {
        for (const i in res.data) {
          const option = {}
          option.label = res.data[i].label
          option.value = res.data[i].value
          this.optionw.push(option)
        }
      })
    },
    // 获取连通性状态
    GetListselectx() {
      getConnectivity().then(res => {
        for (const i in res.data) {
          const options = {}
          options.label = res.data[i].label
          options.value = res.data[i].value
          this.searchData[0].option.push(options)
        }
      })
    },
    // 连通性样式
    changeCellStyle(row, column, rowIndex, columnIndex) {
      if (row.column.id === 'connectivity') {
        return {
          borderRight: '2px solid #0f1441',
          borderBottom: '2px solid #0f1441'
        }
      } else {
        return ''
      }
    },
    // 上传文件，获取文件流
    handleChange(file) {
      this.file = file.raw
    },
    // 自定义上传
    uploadFile() {
      // 创建表单对象
      const wenjia = new FormData()
      wenjia.append('file', this.file)
      getCertificate(this.system.nativeId).then(res => {
        this.$message({
          type: 'success',
          message: res.data
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth} + 10px);
  }
}
.Breadcrumb {
    position: absolute;
    margin-left: 264px;
    top:57px;
}
#main_body {
    position: absolute;
    left: 210px;
    width: calc(100% - #{$sideBarWidth});
    height:100%;
    top: 42px;
}
.margin{
  margin-top: 35px;
}
.main_body {
  width: calc(100% - #{$sideBarHideWidth}) !important;

}
.table {
  margin-top: 15px;
  width: 100%;
  height: 90%;
  max-height: 90%;
  padding: 0 10px 15px;
  background: #111547;
}
.table1 {
  height:45%;
}
.titleSearch{
  position: relative
}
.el-table--scrollable-x .el-table__body-wrapper{
  overflow-x: auto
}
.button {
  position: fixed;
  right: 3%;
  top: 86px;
}
.button button {
  background-color: #20a3f5;
  color: #fff;
  border: none;
  line-height: 30px;
  padding: 0 15px;
  font-size: 12px;
  border-radius: 4px;
  margin: 0 5px;
}

.el-button {
  background: none;
  border: none;
  color: #fff;
}
.dialog_heat {
  background: #20a3f5;
}
.el-tabs--border-card {
  background: none;
  border: none;
}
.el-button--small,
.el-button--small.is-round {
  padding: 9px 0;
}
</style>

<style>
.el-tabs--border-card > .el-tabs__header {
  background: none;
}
.el-breadcrumb__inner,.el-breadcrumb__inner a, .el-breadcrumb__inner.is-link{
  color:#fff
}
.el-breadcrumb__item:last-child .el-breadcrumb__inner, .el-breadcrumb__item:last-child .el-breadcrumb__inner a, .el-breadcrumb__item:last-child .el-breadcrumb__inner a:hover, .el-breadcrumb__item:last-child .el-breadcrumb__inner:hover{
  color:#fff;
}
.Breadcrumb{
  margin-top: -28px;
  border-left:4px solid #20A3F5;
  padding-left:10px;
}
.el-input__inner{
  color:#fff;
}
.el-tabs--border-card > .el-tabs__header {
  background: none !important;
  border-bottom: 1px solid #1e3675;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
  background: #20a3f5;
  color: #fff;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
  border: none;
}
.el-tabs--border-card > .el-tabs__header .el-tabs__item {
  background: #1c214f;
  color: #20a3f5;
  margin-right: 20px;
  border-radius: 4px;
}
.el-tabs--border-card
  > .el-tabs__header
  .el-tabs__item:not(.is-disabled):hover {
  color: #fff;
}
.el-dialog__header {
  background: #20a3f5;
  color: #fff;
}
.el-dialog__body,
.el-dialog__footer {
  background: #10296c;
}
.el-input__inner,
.el-textarea__inner {
  background-color: #10296c;
  border: 1px solid #20a3f5;
  resize: none;
}
.el-table,
.el-table__expanded-cell {
  background-color: #10296c;
  margin: 10px 0;
}
.el-table thead,
.el-table th,
.el-table tr {
  background-color: #1c214f;
}
.el-table tr:nth-child(even) {
  background: #1c214f;
}
.el-table tr:nth-child(odd) {
  background: rgba(255, 255, 255, 0);
}
.el-table td,
.el-table th.is-leaf {
  border: none;
  color: #fff;
  text-align: center;
}
.el-table__body tr.current-row > td {
  background: #037fcd;
}

.el-table--enable-row-hover .el-table__body tr:hover > td {
  background: #20a3f5;
}
.el-form-item__label {
  color: #fff;
}
.el-dialog__headerbtn .el-dialog__close,
.el-dialog__title {
  color: #fff;
}
.el-select {
  margin-right: 5px;
}
.el-table__fixed-body-wrapper{
  top: 37px!important
}
.el-row{
  color:#fff;
  line-height: 25px;
}
.el-col-6{
  margin-top:-22px!important
}
/* .el-table__body-wrapper.is-scrolling-left{
  height: 95%!important
} */
</style>

