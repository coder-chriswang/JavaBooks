<template>
  <div class="alarm-container">
    <!-- <div class="Breadcrumb">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">{{
          $t("route.metadata")
        }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t("sidebar.label") }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t("sidebar.relationship") }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div> -->
    <div class="button_add">
      <el-button class="button" @click="handleEditdia()">
        {{ $t("public.add") }}</el-button>
      <!-- </div>   -->
      <el-dialog
        :title="$t('public.add')"
        :visible.sync="dialogFormVisible"
        :modal-append-to-body="false"
      >
        <el-form :model="relation" style="margin-top:15px;">
          <div id="panel">
            <flow-panel ref="FlowPanel" :get-data-a="getDataA" :menu-list="menuList" :menu-listv="menuListv" />
          </div>
          <div class="kuang_re">
            <el-form-item :label="$t('metadata.name')" :label-width="formLabelWidth" class="el-form-item">
              <el-input v-model="relation.name" autocomplete="off" />
            </el-form-item>
            <el-form-item :label="$t('metadata.desc')" :label-width="formLabelWidth" class="el-form-item">
              <el-input v-model="relation.desc" type="textarea" />
            </el-form-item>
          </div>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
          <el-button
            type="primary"
            @click="clickParent()"
          >{{ $t("sidebar.determine") }}</el-button>
        </div>
      </el-dialog>
    </div>
    <Table
      :table-data="tableData"
      :table-header="tableHeader"
      :current-page="currentPage"
      :pagination="pagination"
      :total="total"
      :page-sizes="pageSizes"
      :last-table-column="lastTableColumn"
      class="table"
      @pagination-change="childByValue"
    >
      <template slot-scope="scope">
        <el-button
          size="small"
          @click="handleEdit(scope.scope.$index, tableData)"
        >{{ $t("public.edit") }}</el-button>
        <el-button
          size="small"
          @click="handleDelete(scope.scope.$index, tableData)"
        >{{ $t("sidebar.delete") }}
        </el-button>
      </template>
    </Table>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Table from '@/components/Table/Table'
import FlowPanel from '@/components/ef/panel'
import { getRelations, getCatalogtree, getDateils, deleteRelations } from '@/api/metadata.js'
export default {
  // name: 'Alarm', // 元数据关系
  // name: 'panel',
  components: {
    Table,
    FlowPanel
  },
  data() {
    return {
      getDataA: {
        'name': '',
        'decs': '',
        'graphid': '',
        'nodeList': [],
        'lineList': []
      },
      menuList: [{
        id: '1',
        type: 'group',
        name: this.$t('metadata.group'),
        ico: 'el-icon-video-pause',
        open: true,
        children: []
      }
      ],
      menuListv: [
        {
          id: '2',
          type: 'group',
          name: this.$t('metadata.relationship'),
          ico: 'el-icon-video-pause',
          open: true,
          children: [
            {
              id: '21',
              type: 'timer',
              name: this.$t('metadata.contain'),
              ico: '',
              // 自定义覆盖样式
              style: {}
            }, {
              id: '22',
              type: 'end4',
              name: this.$t('metadata.belocated'),
              ico: '',
              // 自定义覆盖样式
              style: {}
            },
            {
              id: '23',
              type: 'ove3r',
              name: this.$t('metadata.belongto'),
              ico: '',
              // 自定义覆盖样式
              style: {}
            },
            {
              id: '24',
              type: 'ove1r',
              name: this.$t('metadata.connect'),
              ico: '',
              // 自定义覆盖样式
              style: {}
            },
            {
              id: '25',
              type: 'over2',
              name: this.$t('metadata.Masterslave'),
              ico: '',
              // 自定义覆盖样式
              style: {}
            }
          ]
        }
      ],
      defaultProps: {
        children: 'children',
        label: 'label'
      },

      // 表格数据
      table_data: [],
      dialogFormVisible: false,
      relation: {
        name: '',
        desc: ''
      },
      formLabelWidth: '120px',
      // table
      pagination: true,
      currentPage: 1,
      total: 0,
      pageSize: 10,
      indext: -1,
      pageSizes: [10, 20, 30, 40, 50],
      tableHeader: [
        {
          name: this.$t('metadata.parduct'),
          id: 'name'
        },
        {
          name: this.$t('metadata.desc'),
          id: 'desc'
        }
      ],
      tableData: [],
      lastTableColumn: true
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    const page = {
      currentPageNum: this.currentPage,
      pageSizeNum: this.pageSize
    }
    this.getListTable(page)
    this.GetListImg()
  },
  methods: {
    // 获取模型导航数据
    GetListImg() {
      getCatalogtree().then((res) => {
        const Tree = res.data
        for (let i = 0; i < Tree.length; i++) {
          const menuList2 = {}
          menuList2.name = Tree[i].name
          menuList2.label = Tree[i].name
          menuList2.type = Tree[i].ns
          menuList2.ico = 'el-icon-video-play'
          menuList2.id = i + 1
          menuList2.ns = Tree[i].ns
          menuList2.children = []
          for (let j = 0; j < Tree[i].categoryList.length; j++) {
            const categoryList = {}
            categoryList.name = Tree[i].categoryList[j].name
            categoryList.label = Tree[i].categoryList[j].name
            categoryList.type = Tree[i].categoryList[j].ns
            categoryList.id = (i + 1) + '-' + (j + 1)
            categoryList.ico = 'el-icon-time'
            categoryList.ns = menuList2.ns
            categoryList.category = Tree[i].categoryList[j].category
            categoryList.style = {}
            categoryList.children = []
            for (let k = 0; k < Tree[i].categoryList[j].typeList.length; k++) {
              const typeList = {}
              typeList.name = Tree[i].categoryList[j].typeList[k].name
              typeList.label = Tree[i].categoryList[j].typeList[k].name
              typeList.type = Tree[i].categoryList[j].typeList[k].ns
              typeList.id = (i + 1) + '-' + (j + 1) + '-' + (k + 1)
              typeList.ico = ' el-icon-caret-right'
              typeList.ns = categoryList.ns
              typeList.category = categoryList.category
              typeList.style = {}
              typeList.children = []
              for (let q = 0; q < Tree[i].categoryList[j].typeList[k].ciList.length; q++) {
                const ciList = {}
                ciList.name = Tree[i].categoryList[j].typeList[k].ciList[q].name
                ciList.label = Tree[i].categoryList[j].typeList[k].ciList[q].name
                ciList.type = 'type' + (i + 1) + '-' + (j + 1) + '-' + (k + 1) + '-' + (q + 1)
                ciList.ico = 'el-icon-shopping-cart-full'
                ciList.ns = typeList.ns
                ciList.ci = Tree[i].categoryList[j].typeList[k].ciList[q].ci
                ciList.category = typeList.category
                ciList.id = (i + 1) + '-' + (j + 1) + '-' + (k + 1) + '-' + (q + 1)
                typeList.children.push(ciList)
              }
              categoryList.children.push(typeList)
            }
            menuList2.children.push(categoryList)
          }

          this.menuList[0].children.push(menuList2)
        }
      })
    },
    childByValue: function(childValue) {
      const totl = {
        currentPageNum: childValue.currentPageNum,
        pageSizeNum: childValue.pageSizeNum
      }
      this.GetListTable(totl)
    },
    handleEditdia() {
      this.dialogFormVisible = true
      this.relation.name = ''
      this.relation.desc = ''
      this.indext = -1
      this.disabled = false
    },
    // 添加数据||或修改数据
    clickParent() {
      if (this.indext === -1) {
        this.$refs.FlowPanel.downloadData(this.relation.name, this.relation.desc, this.relation.graphid)
        const page = {
          currentPageNum: this.currentPage,
          pageSizeNum: this.pageSize
        }
        this.GetListTable(page)
      } else {
        this.$refs.FlowPanel.downloadDatabj(this.relation.name, this.relation.desc, this.getDataA.graphid, this.getDataA.code)
      }

      this.dialogFormVisible = false
    },

    menuActive(val) {
    },
    // 编辑
    handleEdit(index, row) {
      const id = row[index].graphid
      this.getDataA = {
        'name': '',
        'decs': '',
        'code': '',
        'graphid': '',
        'nodeList': [],
        'lineList': []
      }
      getDateils(id).then(res => {
        if (res.code === 200) {
          this.relation.name = res.data.name
          this.relation.desc = res.data.desc
          this.getDataA.code = res.code
          this.getDataA.nodeList = res.data.nodeList
          this.getDataA.desc = res.data.desc
          this.getDataA.name = res.data.name
          this.getDataA.lineList = res.data.lineList
          this.getDataA.graphid = res.data.graphid
          this.indext = index
          this.dialogFormVisible = true
        }
      })
    },
    // 删除
    handleDelete(index, row) {
      const id = row[index].graphid
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      })
        .then(() => {
          deleteRelations(id).then(res => {
            if (res.code === 200) {
              row.splice(index, 1)
              this.$message({
                message: res.data,
                type: 'success'
              })
              this.total = this.tableData.length
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: this.$t('sidebar.canceldelete')
          })
        })
    },
    // 获取表格
    getListTable(params) {
      getRelations(params).then(res => {
        this.total = res.data.recordsTotal
        this.tableData = res.data.currentPageContent
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../../styles/variables.scss";
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth} + 10px);
  }
}
.el-button {
  background: none;
  border: none;
  color: #fff;
  font-size: 28px;
}

.kuang_re {
  position: absolute;
  top:60px;
  right:37px;
  width: 80%;
}

.child_button {
  float: right;
  margin: 10px !important;
}

</style>

