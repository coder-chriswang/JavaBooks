<template>
  <div class="resources-main-container" :class="containerClass">
    <SiderBar :menu-list="menuList" @menu-active="menuActive" />
    <div class="Breadcrumb">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <span v-if="show === 'details'" class="back" @click="back()">{{ $t('navbar.back') }}</span>
        <i v-if="show === 'details'" class="el-breadcrumb__separator el-icon-arrow-right" style="float:left;color:#409eff" />
        <el-breadcrumb-item
          v-for="item in breadcrumb"
          :key="item.value"
        >
          {{ item.name }}
        </el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <el-main id="main_body" :class="containerClass">
      <Product v-if="ids === '1-1'" />
      <Theme v-if="ids === '1-2'" />
      <Category v-if="ids === '1-3'" />
      <Model v-if="ids === '2-1'" :modeldata="modeldata" @menu-active="menuActive" />
      <Details v-if="ids === '2-2'" :details="details" @menu-active="menuActive" />
      <Relationship v-if="ids === '3-1'" />
    </el-main>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import SiderBar from '@/components/Sidebar/Sidebar'
import Product from './label/product'
import Theme from './label/theme'
import Category from './label/category'
import Model from './model/model'
import Details from './model/details'
import Relationship from './relationship/relationship'
import { getTree } from '@/api/metadata.js'
export default {
  name: 'Alarm',
  components: {
    SiderBar,
    Product,
    Theme,
    Category,
    Model,
    Details,
    Relationship
  },
  data() {
    return {
      ids: '2-1', // 界面切换的条件
      modeldata: {},
      details: {},
      show: '',
      breadcrumbM: [
        {
          name: this.$t('sidebar.model')
        },
        {
          name: this.$t('sidebar.perception')
        },
        {
          name: this.$t('sidebar.unifiedDataManagement')
        }
      ],
      breadcrumbDetails: [
        {
          name: this.$t('sidebar.details')
        }
      ],
      menuList: [
        {
          label: this.$t('sidebar.label'),
          icon: 'icon-peizhi',
          isActive: true,
          id: '1',
          url: '',
          children: [
            {
              label: this.$t('sidebar.product'),
              isActive: true,
              id: '1-1',
              url: '',
              types: '1-1'
            },
            {
              label: this.$t('sidebar.theme'),
              isActive: false,
              id: '1-2',
              url: '',
              types: '1-2'
            },
            {
              label: this.$t('sidebar.category'),
              isActive: false,
              id: '1-3',
              url: '',
              types: '1-3'
            }
          ]
        },
        {
          label: this.$t('sidebar.model'),
          icon: 'icon-yunwei',
          isActive: false,
          id: '2',
          url: '',
          types: '2-1',
          children: [
          ]
        },
        {
          label: this.$t('sidebar.relationship'),
          icon: 'icon-guanxi',
          isActive: false,
          id: '3',
          url: '',
          types: '3-1'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        main_body: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  mounted() {
    this.changeClass()
    this.ids = '2-1'
  },
  created() {
    this.breadcrumb = this.breadcrumbM
    this.GetListImg()
  },
  methods: {
    changeClass(routeName = this.$route.name) {
      this.isActive = {
        model: false,
        product: false,
        theme: true,
        relationship: false
      }
      this.isActive[routeName] = true
    },
    // 详情返回按钮
    back() {
      this.breadcrumb = this.breadcrumbM
      this.ids = '2-1'
      this.show = ''
    },
    menuActive(val) {
      // 模型列表删除 添加 编辑操作 同步更改树结构数据
      if (val.type === 'delect') {
        const menuList = this.menuList[0].children[0].children[0].children
        if (val.type === 'delect') {
          for (const i in menuList) {
            if (val.item.type === menuList[i].type) {
              for (const j in menuList[i].children) {
                if (val.item.ci === menuList[i].children[j].ci) {
                  val.types = '2-1'
                  menuList[i].children.splice(j, 1)
                }
              }
            }
          }
        }
      }
      if (val.item.types) {
        if (this.menuList[1].children[0]) {
          const menuList = this.menuList[1].children[0].children[0].children
          for (const i in menuList) {
            if (val.item.type === menuList[i].type) {
              const text = {}
              const idOne = menuList[i].children[0].id.substring(0, 8)
              const idAfter = Number(menuList[i].children.length) + 2
              text.category = val.item.category
              text.ci = val.item.ci
              text.details = 'details'
              text.id = idOne + idAfter
              text.label = val.item.name
              text.ns = val.item.ns
              text.type = val.item.type
              text.types = '2-2'
              if (val.type === 'add') {
                menuList[i].children.push(text)
              } else if (val.type === 'edit') {
                for (const j in menuList[i].children) {
                  if (val.item.ci === menuList[i].children[j].ci) {
                    menuList[i].children[j].label = val.item.name
                  }
                }
              }
            }
            menuList[i].children[0]
          }
        }
      }
      if (val.item.details === 'details') {
        this.show = 'details'
        this.breadcrumb = this.breadcrumbDetails
      } else {
        this.show = ''
        this.breadcrumb = this.breadcrumbM
      }
      this.ids = val.item.types
      this.modeldata = {
        ns: val.item.ns,
        category: val.item.category,
        type: val.item.type,
        details: val.item.details,
        ci: val.item.ci,
        ciTypeName: val.item.ciTypeName
      }
      this.details = {
        ns: val.item.ns,
        category: val.item.category,
        type: val.item.type,
        details: val.item.details,
        ci: val.item.ci
      }
    },
    // 对象元数据树形目录
    GetListImg() {
      getTree().then((res) => {
        const Tree = res.data
        for (let i = 0; i < Tree.length; i++) {
          const menuList2 = {}
          menuList2.label = Tree[i].name
          menuList2.ns = Tree[i].ns
          menuList2.id = '2-' + i + 2
          menuList2.url = ''
          menuList2.types = '2-1'
          menuList2.children = []
          for (let j = 0; j < Tree[i].categoryList.length; j++) {
            const categoryList = {}
            categoryList.label = Tree[i].categoryList[j].name
            categoryList.ns = Tree[i].ns
            categoryList.category = Tree[i].categoryList[j].category
            categoryList.id = '2-' + (i + 2) + '-' + (j + 1)
            categoryList.types = '2-1'
            categoryList.url = ''
            categoryList.children = []
            for (let k = 0; k < Tree[i].categoryList[j].typeList.length; k++) {
              const typeList = {}
              typeList.label = Tree[i].categoryList[j].typeList[k].name
              typeList.ciTypeName = Tree[i].categoryList[j].typeList[k].name
              typeList.ns = Tree[i].ns
              typeList.id = '2-' + (i + 2) + '-' + (j + 1) + '-' + (k + 1)
              typeList.type = Tree[i].categoryList[j].typeList[k].type
              typeList.category = Tree[i].categoryList[j].category
              typeList.types = '2-1'
              typeList.children = []
              typeList.url = ''
              for (let q = 0; q < Tree[i].categoryList[j].typeList[k].ciList.length; q++) {
                const ciList = {}
                ciList.label = Tree[i].categoryList[j].typeList[k].ciList[q].name
                ciList.ci = Tree[i].categoryList[j].typeList[k].ciList[q].ci
                ciList.url = ''
                ciList.type = Tree[i].categoryList[j].typeList[k].type
                ciList.category = Tree[i].categoryList[j].category
                ciList.ciTypeName = Tree[i].categoryList[j].typeList[k].name
                ciList.ns = Tree[i].ns
                ciList.id = '2-' + (i + 2) + '-' + (j + 1) + '-' + (k + 1) + '-' + (q + 1)
                ciList.types = '2-2'
                ciList.details = 'details'
                typeList.children.push(ciList)
              }
              categoryList.children.push(typeList)
            }
            menuList2.children.push(categoryList)
          }

          this.menuList[1].children.push(menuList2)
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
@import "../../styles/variables.scss";
.alarm {
  &-container {
    margin: 10px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
    margin-left: calc(#{$sideBarWidth} + 10px);
  }
}
.Breadcrumb {
    position: absolute;
    margin-left: 264px;
    top:57px;
}
#main_body {
    position: absolute;
    left: 210px;
    width: calc(100% - #{$sideBarWidth});
    height:100%;
    top: 42px;
}
.main_body {
  width: calc(100% - #{$sideBarHideWidth}) !important;

}
.back{
  float: left;
  color: #409eff;
  cursor: pointer;
}
</style>
<style>
.tableRowClass .el-button{
  background: rgba(0,0,0,0);
  border: none;
  color: #fff
}
.alarm-container {
  height: 95%;
  width: 100%
}
.button_add{
  position: fixed;
  right: 3%;
  top: 85px;
  z-index: 23;
}
 .button_add .button{
  background-color: #20a3f5;
  color: #fff;
  border: none;
  line-height: 30px;
  padding: 0 15px;
  font-size: 12px;
  border-radius: 4px;
  margin: 0 5px;
 }
 .titleSearch{
   margin-top:25px;
 }
.el-breadcrumb__inner,.el-breadcrumb__inner a, .el-breadcrumb__inner.is-link{
  color:#fff
}
.el-breadcrumb__item:last-child .el-breadcrumb__inner, .el-breadcrumb__item:last-child .el-breadcrumb__inner a, .el-breadcrumb__item:last-child .el-breadcrumb__inner a:hover, .el-breadcrumb__item:last-child .el-breadcrumb__inner:hover{
  color:#fff;
}
.Breadcrumb{
  margin-top: -28px;
  border-left:4px solid #20A3F5;
  padding-left:10px;
}
.el-input__inner{
  color:#fff;
}
.table {
  /* position: absolute; */
  width: 100%;
  height: 82%;
  max-height: 90%;
  background: #111547;
  }
.el-dialog__header {
  background: #20a3f5;
  color: #fff;
}
.save_button{
  border: none;
  background: none;
  color:#fff
}
.el-input.is-disabled .el-input__inner{
  background-color: rgba(0,0,0,0);
  border-color: #20a3f5;
}
.kuang {
  border: 1px solid #20a3f5;
  border-radius: 4px;
  position: relative;
  margin-top: 30px;
}
.kuang:first-child {
  margin-top: 0;
}
.jichu {
   position: absolute;
  top: -24px;
  background: #10296c;
  color: #fff;
  margin-left: 20px;
  padding: 0 15px;
 }
.el-form-item1 {
  width:24%;
  float: left;
  margin-top: 20px;
}
 .el-form-item2 {
  clear:both;
  width:96%;
}
 .child_button {
   float: right;
   margin: 10px !important;
 }
.el-dialog__body,
.el-dialog__footer {
  background: #10296c;
}
.el-input__inner,
.el-textarea__inner {
  background-color: #10296c;
  border: 1px solid #20a3f5;
  resize: none;
  color:#fff
}
.el-table,
.el-table__expanded-cell {
  background-color: #10296c;
  margin: 14px 0;
}
.el-table thead,
.el-table th,
.el-table tr {
  background-color: #1c214f;
}
.el-table tr:nth-child(even) {
  background: #1c214f;
}
.el-table tr:nth-child(odd) {
  background: rgba(255, 255, 255, 0);
}
.el-table td,
.el-table th.is-leaf {
  border: none;
  color: #fff;
  text-align: center;
}

.el-table__body tr.current-row > td {
  background: #037fcd;
}

.el-table--enable-row-hover .el-table__body tr:hover > td {
  background: #20a3f5;
}
.el-form-item__label {
  color: #fff;
}
.el-dialog__headerbtn .el-dialog__close,
.el-dialog__title {
  color: #fff;
}
.el-table--border::after, .el-table--group::after, .el-table::before{
      content: '';
    position: absolute;
    background-color: none;
    z-index: 1;
}
.el-table__body-wrapper{
  overflow: auto;
  overflow-x: hidden;
  height:73%
}
/*  */
</style>
