<template>
  <div class="alarm-container">
    <!-- <div class="Breadcrumb">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">{{
          $t("route.metadata")
        }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t("sidebar.label") }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t("sidebar.theme") }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div> -->
    <search :search-data="searchData" @search="search" />
    <div class="button_add">
      <el-button class="button" @click="handleEditdia()">
        {{ $t("public.add") }}</el-button>
      <el-dialog
        :title="$t('public.add')"
        :visible.sync="dialogFormVisible"
        :modal-append-to-body="false"
      >
        <el-form :model="theme" style="margin-top:15px;">
          <el-form-item :label="$t('metadata.identification')" :label-width="formLabelWidth">
            <el-input v-model="theme.sign" autocomplete="off" :disabled="disabled" />
          </el-form-item>
          <el-form-item :label="$t('metadata.name')" :label-width="formLabelWidth">
            <el-input v-model="theme.name" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('metadata.desc')" label-width="formLabelWidth">
            <el-input v-model="theme.desc" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('metadata.categoryns')" :label-width="formLabelWidth">
            <el-input v-model="theme.ns" autocomplete="off" :disabled="disabled" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
          <el-button
            type="primary"
            @click="tableDataP()"
          >{{ $t("sidebar.determine") }}</el-button>
        </div>
      </el-dialog>
      <!-- <button>{{ $t("sidebar.OneClick") }}</button>
      <button>{{ $t("sidebar.export") }}</button> -->
    </div>
    <Table
      :table-data="tableData"
      :table-header="tableHeader"
      :current-page="currentPage"
      :pagination="pagination"
      :total="total"
      :page-size="pageSize"
      :page-sizes="pageSizes"
      class="table"
      @pagination-change="childByValue"
    >
      <template slot-scope="scope">
        <el-button
          size="small"
          @click="handleEdit(scope.scope.$index, tableData)"
        >{{ $t("public.edit") }}</el-button>
        <el-button
          size="small"
          @click="handleDelete(scope.scope.$index, tableData)"
        >{{ $t("sidebar.delete") }}
        </el-button>
      </template>
    </Table>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Table from '@/components/Table/Table'
import search from '@/components/TitleSearch/TitleSearch'
import { getCategorys, addCategorys, editCategorys, deleteCategorys, getNss } from '@/api/metadata.js'
export default {
  name: 'Alarm',
  components: {
    Table,
    search
  },

  data() {
    return {
      dialogFormVisible: false,
      disabled: false,
      theme: {
        category: '',
        name: '',
        desc: '',
        ns: '',
        sign: ''
      },
      formLabelWidth: '120px',
      // 搜索框
      searchData: [
        {
          searchType: 'select',
          searchCondition: '23',
          option: [],
          name: this.$t('metadata.productName')
        }
      ],
      type: '',
      // table
      pagination: true,
      currentPage: 1,
      total: 0,
      indext: -1,
      pageSize: 10,
      pageSizes: [10, 20, 30, 40, 50],
      tableHeader: [
        {
          name: this.$t('metadata.identification'),
          id: 'sign'
        },
        {
          name: this.$t('metadata.name'),
          id: 'name'
        },
        {
          name: this.$t('metadata.desc'),
          id: 'desc'
        },
        {
          name: this.$t('metadata.categoryns'),
          id: 'ns'
        }
      ],
      tableData: [],
      lastTableColumn: true
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    const page = {
      currentPageNum: this.currentPage,
      pageSizeNum: this.pageSize,
      type: this.type
    }
    this.GetListTable(page)
    getNss().then(res => {
      for (let i = 0; i < res.data.nsList.length; i++) {
        const options = {}
        options.label = res.data.nsList[i].label
        options.value = res.data.nsList[i].value
        this.searchData[0].option.push(options)
      }
    })
  },
  methods: {
    search: function(obj) {
      const totl = {
        currentPageNum: this.currentPage,
        pageSizeNum: this.pageSize,
        type: obj.undefined
      }
      this.GetListTable(totl)
    },
    childByValue: function(childValue) {
      const totl = {
        currentPageNum: childValue.currentPageNum,
        pageSizeNum: childValue.pageSizeNum,
        type: this.type
      }
      this.GetListTable(totl)
    },
    // 添加数据||或修改数据
    tableDataP() {
      this.theme.category = this.theme.sign
      if (this.indext === -1) {
        addCategorys(this.theme).then(res => {
          if (res.code === 200) {
            const page = {
              currentPageNum: this.currentPage,
              pageSizeNum: this.pageSize,
              type: this.type
            }
            this.GetListTable(page)
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      } else {
        editCategorys(this.theme).then(res => {
          if (res.code === 200) {
            this.tableData[this.indext].category = this.theme.category
            this.tableData[this.indext].name = this.theme.name
            this.tableData[this.indext].desc = this.theme.desc
            this.tableData[this.indext].ns = this.theme.ns
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      }
      this.dialogFormVisible = false
    },
    handleEditdia() {
      this.dialogFormVisible = true
      this.theme.category = ''
      this.theme.sign = ''
      this.theme.name = ''
      this.theme.desc = ''
      this.theme.ns = ''
      this.indext = -1
      this.disabled = false
    },
    // 表格数据编辑
    handleEdit(index, rows, obj) {
      this.dialogFormVisible = true
      this.theme.category = rows[index].category
      this.theme.sign = rows[index].sign
      this.theme.name = rows[index].name
      this.theme.desc = rows[index].desc
      this.theme.ns = rows[index].ns
      this.indext = index
      this.disabled = true
    },
    // 表格数据删除
    handleDelete(index, rows) {
      this.theme.category = rows[index].category
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      })
        .then(() => {
          const params = {
            category: rows[index].category,
            ns: rows[index].ns
          }
          deleteCategorys(params).then(res => {
            if (res.code === 200) {
              rows.splice(index, 1)
              this.$message({
                message: res.data,
                type: 'success'
              })
              this.total = this.tableData.length
            }
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: this.$t('sidebar.canceldelete')
          })
        })
    },
    // //获取表格数据
    GetListTable(params) {
      getCategorys(params).then(res => {
        this.total = res.data.recordsTotal
        this.tableData = res.data.currentPageContent
      })
    }
  }
}
</script>
