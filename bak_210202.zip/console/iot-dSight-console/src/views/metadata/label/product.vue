<template>
  <div class="alarm-container">
    <!-- <div class="Breadcrumb">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/' }">{{ $t("route.metadata") }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t("sidebar.label") }}</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $t("sidebar.product") }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div> -->
    <div class="button_add">
      <el-button class="button" @click="handleEditdia()">
        {{ $t("sidebar.addto") }}
      </el-button>
      <el-dialog
        :title="$t('public.add')"
        :visible.sync="dialogFormVisible"
        :modal-append-to-body="false"
      >
        <el-form :model="form" style="margin-top:15px;">
          <el-form-item :label="$t('metadata.code')" :label-width="formLabelWidth">
            <el-input v-model="form.id" autocomplete="off" :disabled="disabled" />
          </el-form-item>
          <el-form-item :label="$t('metadata.productName')" :label-width="formLabelWidth">
            <el-input v-model="form.name" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('metadata.productdesc')" :label-width="formLabelWidth">
            <el-input v-model="form.desc" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('metadata.deviceVendor')" :label-width="formLabelWidth">
            <el-input v-model="form.vendor" autocomplete="off" />
          </el-form-item>
          <el-form-item :label="$t('metadata.deviceVendorname')" :label-width="formLabelWidth">
            <el-input v-model="form.vendor_name" autocomplete="off" />
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
          <el-button
            type="primary"
            @click="tableDataP()"
          >{{ $t("sidebar.determine") }}</el-button>
        </div>
      </el-dialog>
    </div>
    <Table
      :table-data="tableData"
      :table-header="tableHeader"
      :current-page="currentPage"
      :pagination="pagination"
      :total="total"
      :page="page"
      :page-sizes="pageSizes"
      :last-table-column="lastTableColumn"
      class="table"
      @pagination-change="childByValue"
    >
      <template slot-scope="scope">
        <el-button
          size="small"
          @click="handleEdit(scope.scope.$index, tableData)"
        >{{ $t("public.edit") }}</el-button>
        <el-button
          size="small"
          @click="handleDelete(scope.scope.$index, tableData)"
        >{{ $t("sidebar.delete") }}
        </el-button>
      </template>
    </Table>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Table from '@/components/Table/Table'
import { getNssList, deleteNs, addNs, editNs } from '@/api/metadata.js'
export default {
  name: 'Alarm',
  components: {
    Table
  },

  data() {
    return {
      dialogFormVisible: false,
      form: {
        id: '',
        name: '',
        desc: '',
        vendor: '',
        vendor_name: ''
      },
      formLabelWidth: '120px',
      pagination: true,
      currentPage: 1,
      total: 0,
      pageSize: 10,
      indext: 0,
      disabled: false,
      pageSizes: [5, 15, 20, 25, 30],
      tableHeader: [
        {
          name: this.$t('metadata.code'),
          id: 'id'
        },
        {
          name: this.$t('metadata.productName'),
          id: 'name'
        },
        {
          name: this.$t('metadata.productdesc'),
          id: 'desc'
        },
        {
          name: this.$t('metadata.deviceVendor'),
          id: 'vendor'
        },
        {
          name: this.$t('metadata.deviceVendorname'),
          id: 'vendor_name'
        }
      ],
      tableData: [],
      lastTableColumn: true,
      page: []
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  created() {
    const page = {
      currentPageNum: this.currentPage,
      pageSizeNum: this.pageSize
    }
    this.GetListTable(page)
  },
  methods: {
    childByValue: function(childValue) {
      const totl = {
        currentPageNum: childValue.currentPageNum,
        pageSizeNum: childValue.pageSizeNum
      }
      this.GetListTable(totl)
    },
    menuActive(val) {},
    // 表格数据编辑
    handleEdit(index, rows, obj) {
      this.dialogFormVisible = true
      this.form.id = rows[index].id
      this.form.name = rows[index].name
      this.form.desc = rows[index].desc
      this.form.vendor = rows[index].vendor
      this.form.vendor_name = rows[index].vendor_name
      this.indext = index
      this.disabled = true
    },
    // 添加数据||或修改数据
    tableDataP() {
      if (this.indext === -1) {
        // alert(typeof(JSON.parse(this.form)))
        addNs(this.form).then(res => {
          if (res.code === 200) {
            const page = {
              currentPageNum: this.currentPage,
              pageSizeNum: this.pageSize
            }
            this.GetListTable(page)
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      } else {
        editNs(this.form).then(res => {
          if (res.code === 200) {
            this.tableData[this.indext].id = this.form.id
            this.tableData[this.indext].name = this.form.name
            this.tableData[this.indext].desc = this.form.desc
            this.tableData[this.indext].vendor = this.form.vendor
            this.tableData[this.indext].vendor_name = this.form.vendor_name
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      }
      this.dialogFormVisible = false
    },
    handleEditdia() {
      this.dialogFormVisible = true
      this.form.id = ''
      this.form.name = ''
      this.form.desc = ''
      this.form.vendor = ''
      this.form.vendor_name = ''
      this.indext = -1
      this.disabled = false
    },
    // 表格数据删除
    handleDelete(index, rows) {
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      })
        .then(() => {
          const id = rows[index].id
          deleteNs(id).then(res => {
            if (res.code === 200) {
              rows.splice(index, 1)
              this.$message({
                message: res.data,
                type: 'success'
              })
              this.total = this.tableData.length
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: this.$t('sidebar.canceldelete')
          })
        })
    },
    // //获取表格数据
    GetListTable(params) {
      getNssList(params).then(res => {
        this.total = res.data.recordsTotal
        this.tableData = res.data.currentPageContent
      })
    }
  }
}
</script>
