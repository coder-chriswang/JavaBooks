<template>
  <div class="alarm-container">
    <search v-if="selectShow" ref="search" :search-data="searchData" @search="search" />
    <div class="button_add">
      <el-button v-if="addShow" class="button" @click="handleEditdia()">{{ $t("public.add") }}</el-button>
      <el-dialog
        v-model="title"
        :title="title"
        :visible.sync="dialogFormVisible"
        :modal-append-to-body="false"
      >
        <el-form :model="model" style="margin-top:15px;">
          <div class="kuang">
            <p class="jichu">{{ $t("metadata.basics") }}</p>
            <el-form-item
              :label="$t('metadata.identification')"
              :label-width="formLabelWidth"
              class="el-form-item1"
            >
              <el-input v-model="model.ci" autocomplete="off" :disabled="disabled" />
            </el-form-item>
            <el-form-item
              :label="$t('metadata.name')"
              :label-width="formLabelWidth"
              class="el-form-item1"
            >
              <el-input v-model="model.name" autocomplete="off" />
            </el-form-item>
            <el-form-item
              :label="$t('metadata.type')"
              :label-width="formLabelWidth"
              class="el-form-item1"
            >
              <el-input v-model="model.ciTypeName" autocomplete="off" disabled="disabled" />
            </el-form-item>
            <el-form-item
              :label="$t('metadata.desc')"
              :label-width="formLabelWidth"
              class="el-form-item2"
            >
              <el-input v-model="model.desc" type="textarea" />
            </el-form-item>
          </div>
        </el-form>
        <div class="kuang heigth">
          <p class="jichu"> {{ $t("sidebar.service") }}</p>
          <el-button
            class="child_button"
            type="primary"
            @click="handleAdd('competence')"
          >
            {{ $t("public.add") }}</el-button>
          <el-table ref="mytable" :data="table_data" style="width: 100%;height:188px">
            <el-table-column
              v-for="(item, index, key) in gridData"
              :key="key"
              align="center"
              :item="item"
              :index="index"
              :label="item.label"
            >
              <template slot-scope="scope">
                <div v-if="scope.row.edit">
                  <el-input
                    v-if="item.prop !='type' && item.prop !='direction' && item.prop !='domain' && item.prop !='group' && item.prop !='id' && item.prop !='name' "
                    v-model="scope.row[item.prop]"
                    size="small"
                    :placeholder="$t('metadata.pleaseEnter') + item.label"
                  />
                  <el-input v-if="item.prop==='id'" v-model="scope.row[item.prop]" autocomplete="off" :disabled="disabledAdd" :placeholder="$t('metadata.pleaseEnter') + item.label" />
                  <el-input v-if="item.prop==='name'" v-model="scope.row[item.prop]" autocomplete="off" :disabled="disabledAdd" :placeholder="$t('metadata.pleaseEnter') + item.label" />
                  <el-select v-if="item.prop==='type'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')">
                    <el-option
                      v-for="itema in optionsrattr"
                      :key="itema.value"
                      :label="itema.label"
                      :value="itema.value"
                    />
                  </el-select>
                  <el-select v-if="item.prop==='direction'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')">
                    <el-option
                      v-for="itemb in optionsrtype"
                      :key="itemb.value"
                      :label="itemb.label"
                      :value="itemb.value"
                    />
                  </el-select>
                  <el-select v-if="item.prop==='domain'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')">
                    <el-option
                      v-for="itemc in optionDomainType"
                      :key="itemc.value"
                      :label="itemc.label"
                      :value="itemc.value"
                    />
                  </el-select>
                  <el-select v-if="item.prop==='group'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')">
                    <el-option
                      v-for="itemc in group"
                      :key="itemc.value"
                      :label="itemc.label"
                      :value="itemc.value"
                    />
                  </el-select>
                </div>
                <div v-if="!scope.row.edit">
                  <el-select v-if="item.prop==='group'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')" disabled>
                    <el-option
                      v-for="itemc in group"
                      :key="itemc.value"
                      :label="itemc.label"
                      :value="itemc.value"
                    />
                  </el-select>
                  <el-select v-if="item.prop==='direction'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')" disabled>
                    <el-option
                      v-for="itemb in optionsrtype"
                      :key="itemb.value"
                      :label="itemb.label"
                      :value="itemb.value"
                    />
                  </el-select>
                  <span v-if="item.prop !=='group' && item.prop !='direction' ">{{ scope.row[item.prop] }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column :label="$t('sidebar.operation')" align="center">
              <template slot-scope="scope">
                <!-- 全局控制的编辑 -->
                <div
                  v-if="is_edit && scope.row.add === undefined"
                  style="display: inline-block"
                >
                  <!-- 编辑 -->
                  <el-button
                    v-if="!scope.row.edit"
                    size="mini"
                    class="save_button"
                    @click="handleEdit(scope.$index, scope.row,'competence')"
                  >{{ $t("public.edit") }}</el-button>
                  <!-- 保存 -->
                  <el-button
                    v-if="scope.row.edit"
                    size="mini"
                    :plain="true"
                    class="save_button"
                    @click="handleSave(scope.$index, scope.row,'competence')"
                  >{{ $t("public.save") }}</el-button>
                </div>
                <!-- 添加控制 -->
                <div
                  v-if="scope.row.add != undefined && scope.row.add"
                  style="display: inline-block"
                >
                  <!-- 保存 -->
                  <el-button
                    v-if="scope.row.edit"
                    size="mini"
                    :plain="true"
                    class="save_button"
                    @click="handleSave(scope.$index, scope.row,'competence')"
                  >{{ $t("public.save") }}</el-button>
                </div>
                <!-- 全局控制删除 -->
                <el-button
                  v-if="is_delete && scope.row.add === undefined"
                  size="mini"
                  :plain="true"
                  class="save_button"
                  @click="handleDelete(scope.$index, scope.row,'competence')"
                >{{ $t("sidebar.delete") }}</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="kuang heigth">
          <p class="jichu">{{ $t("metadata.attribute") }}</p>
          <el-button
            class="child_button"
            type="primary"
            @click="handleAdd('attribute')"
          >{{ $t("public.add") }}</el-button>
          <el-table ref="mytable" :data="table_datac" style="width: 100%;height:229px">
            <el-table-column
              v-for="(item, index, key) in gridData1"
              :key="key"
              align="center"
              :item="item"
              :index="index"
              :label="item.label"
            >
              <template slot-scope="scope">
                <div v-if="scope.row.edit">
                  <el-input
                    v-if="item.prop != 'type' && item.prop != 'index' && item.prop != 'primary' && item.prop !='supportAction'&& item.prop != 'id' && item.prop !='name'"
                    v-model="scope.row[item.prop]"
                    size="small"
                    :placeholder="$t('metadata.pleaseEnter') + item.label"
                  />
                  <el-input v-if="item.prop==='id'" v-model="scope.row[item.prop]" autocomplete="off" :disabled="disabledAdd" :placeholder="$t('metadata.pleaseEnter') + item.label" />
                  <el-input v-if="item.prop==='name'" v-model="scope.row[item.prop]" autocomplete="off" :disabled="disabledAdd" :placeholder="$t('metadata.pleaseEnter') + item.label" />
                  <el-select v-if="item.prop==='type'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')">
                    <el-option
                      v-for="itemd in optionsr"
                      :key="itemd.value"
                      :label="itemd.label"
                      :value="itemd.value"
                    />
                  </el-select>
                  <el-select v-if="item.prop === 'supportAction'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')" multiple>
                    <el-option
                      v-for="itemf in attrActionList"
                      :key="itemf.value"
                      :label="itemf.label"
                      :value="itemf.value"
                    />
                  </el-select>
                </div>
                <div v-if="!scope.row.edit">
                  <el-select v-if="item.prop==='type'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')" disabled>
                    <el-option
                      v-for="itemd in optionsr"
                      :key="itemd.value"
                      :label="itemd.label"
                      :value="itemd.value"
                    />
                  </el-select>
                  <el-select v-if="item.prop === 'supportAction'" v-model="scope.row[item.prop]" :placeholder="$t('metadata.pleaseSelect')" multiple disabled="disabled">
                    <el-option
                      v-for="itemf in attrActionList"
                      :key="itemf.value"
                      :label="itemf.label"
                      :value="itemf.value"
                    />
                  </el-select>
                  <span v-if="item.prop !== 'supportAction' && item.prop !== 'type' ">{{ scope.row[item.prop] }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column :label="$t('sidebar.operation')" align="center">
              <template slot-scope="scope">
                <!-- 全局控制的编辑 -->
                <div
                  v-if="is_edit && scope.row.add === undefined"
                  style="display: inline-block"
                >
                  <!-- 编辑 -->
                  <el-button
                    v-if="!scope.row.edit"
                    size="mini"
                    class="save_button"
                    @click="handleEdit(scope.$index, scope.row,'attribute')"
                  >{{ $t("public.edit") }}</el-button>
                  <!-- 保存 -->
                  <el-button
                    v-if="scope.row.edit"
                    size="mini"
                    :plain="true"
                    class="save_button"
                    @click="handleSave(scope.$index, scope.row,'attribute')"
                  >{{ $t("public.save") }}</el-button>
                </div>
                <!-- 添加控制 -->
                <div
                  v-if="scope.row.add != undefined && scope.row.add"
                  style="display: inline-block"
                >
                  <!-- 保存 -->
                  <el-button
                    v-if="scope.row.edit"
                    size="mini"
                    :plain="true"
                    class="save_button"
                    @click="handleSave(scope.$index, scope.row,'attribute')"
                  >{{ $t("public.save") }}</el-button>
                </div>
                <!-- 全局控制删除 -->
                <el-button
                  v-if="is_delete && scope.row.add === undefined"
                  size="mini"
                  :plain="true"
                  class="save_button"
                  @click="handleDelete(scope.$index, scope.row,'attribute')"
                >{{ $t("sidebar.delete") }}</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">{{ $t("sidebar.cancel") }}</el-button>
          <el-button type="primary" @click="tableDataP()">{{ $t("sidebar.determine") }}</el-button>
        </div>
      </el-dialog>
    </div>
    <Table
      :table-data="tableData"
      :table-header="tableHeader"
      :current-page="currentPage"
      :pagination="pagination"
      :total="total"
      :page-sizes="pageSizes"
      class="table"
      @pagination-change="childByValue"
    >
      <template slot-scope="scope">
        <el-button
          size="small"
          @click="handleEditw(scope.scope.$index, tableData)"
        >{{ $t("public.edit") }}</el-button>
        <el-button
          size="small"
          @click="handleDeletew(scope.scope.$index, tableData)"
        >{{ $t("sidebar.delete") }}
        </el-button>
      </template>
    </Table>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import Table from '@/components/Table/Table'
import search from '@/components/TitleSearch/TitleSearch'
import { getTable, getAttrType, getActionType, getCiType, deleteCiType, getCiDectals, addCi, editCi, getDirectionType, getActionDomainType, getActionGroup } from '@/api/metadata.js'
export default {
  name: 'Alarm',
  components: {
    Table,
    search
  },
  props: {
    modeldata: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      is_edit: true, // 是否可编辑
      is_delete: true, // 是否可删除
      title: this.$t('public.add'),
      group: [],
      gridData: [
        {
          prop: 'id',
          label: this.$t('metadata.identification'),
          width: '150'
        },
        {
          prop: 'name',
          label: this.$t('metadata.name'),
          width: '150'
        },
        {
          prop: 'desc',
          label: this.$t('metadata.desc'),
          width: '150'
        },
        {
          prop: 'group',
          label: this.$t('metadata.servicegroup'),
          width: '150'
        },
        {
          prop: 'direction',
          label: this.$t('metadata.instruction'),
          width: '150'
        }
      ],
      gridData1: [
        {
          prop: 'id',
          label: this.$t('metadata.identification'),
          width: '150'
        },
        {
          prop: 'name',
          label: this.$t('metadata.name'),
          width: '150'
        },
        {
          prop: 'desc',
          label: this.$t('metadata.desc'),
          width: '150'
        },
        {
          prop: 'type',
          label: this.$t('metadata.attributetype'),
          width: '150'
        },
        {
          prop: 'supportAction',
          label: this.$t('metadata.supportAction'),
          width: '150'
        }
      ],
      // 表格数据
      table_data: [],
      table_datac: [],
      new_date_json: [],
      optionsrattr: [],
      optiontype: [],
      dialogFormVisible: false,
      model: {
        partition: '',
        name: '',
        type: '',
        desc: '',
        ci: '',
        category: '',
        types: '',
        ciTypeName: ''
      },
      selectShow: true,
      addShow: false,
      formLabelWidth: '120px',
      // 搜索框
      searchData: [
        {
          searchType: 'select',
          searchCondition: true,
          id: 'search',
          name: this.$t('metadata.type'),
          option: []
        }
      ],
      optionsr: [],
      optionsrtype: [],
      optionDomainType: [],
      attrActionList: [],
      pagination: true,
      currentPage: 1,
      total: 0,
      indext: -1,
      pageSize: 10,
      type: '',
      pageSizes: [10, 20, 30, 40, 50],
      tableHeader: [
        {
          name: this.$t('metadata.type'),
          id: 'ciTypeName'
        },
        {
          name: this.$t('metadata.name'),
          id: 'name'
        },
        {
          name: this.$t('metadata.desc'),
          id: 'desc'
        }
      ],
      tableData: [],
      dataArray: [],
      dataArrays: [],
      lastTableColumn: true,
      disabled: false,
      disabledAdd: true
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  watch: {
    'modeldata': {
      handler(newValue, oldValue) {
        if (newValue.details === 'details') {
          this.title = this.$t('metadata.details')
          this.model.category = newValue.category
          this.model.nullLiteral
          this.model.ci = newValue.ci
          const params = {
            category: newValue.category,
            ci: newValue.ci,
            ns: newValue.ns
          }
          getCiDectals(params).then(res => {
            for (let i = 0; i < res.data.actions.length; i++) {
              res.data.actions[i].edit = 'false'
            }
            this.dialogFormVisible = true
            this.table_data = res.data.actions
            this.table_datac = res.data.attrs
            this.model = res.data
            this.indext = 5
            this.initEditAttribute()
          })
        } else if (!newValue.ci) {
          this.currentPage = 1
          this.model.ciTypeName = newValue.ciTypeName
          this.model.category = newValue.category
          this.model.ns = newValue.ns
          this.dialogFormVisible = false
          this.model.type = newValue.type
          if (newValue.type) {
            this.selectShow = false
            this.addShow = true
          } else {
            this.addShow = false
            this.selectShow = true
            if (this.$refs.search && this.$refs.search.searchModel.search) {
              this.$refs.search.searchModel.search = ''
            }
          }
          this.getListTable()
        }
      },
      deep: true
    }
  },
  created() {
    this.model.category = this.modeldata.category
    this.model.ns = this.modeldata.ns
    this.model.types = '2-1'
    this.model.type = this.modeldata.type
    this.model.ciTypeName = this.modeldata.ciTypeName
    if (this.modeldata.type) {
      this.selectShow = false
      this.addShow = true
    } else {
      this.addShow = false
      this.selectShow = true
    }
    this.getListTable()
  },
  mounted: function() {
    this.getListTable()
    // 查询对象属性类型下拉列表
    getAttrType().then(res => {
      this.optionsr = res.data.attrType || []
    })
    // 查询对象能力类型下拉列表
    getActionType().then(res => {
      this.optionsrattr = res.data.actionType || []
    })
    // 查询对象类型下拉列表
    getCiType().then(res => {
      this.searchData[0].option = res.data.ciType || []
      this.optiontype = res.data.ciType || []
    })
    // 查询对象能力服务类别下拉列表
    getDirectionType().then(res => {
      this.optionsrtype = res.data.directionType || []
    })
    // 查询对象能力域下拉列表
    getActionDomainType().then(res => {
      this.optionDomainType = res.data.actionType || []
    })
    // 服务能力类别组下拉列表
    getActionGroup().then(res => {
      this.group = res.data.attrActionList || []
    })
  },
  methods: {
    search: function(obj) {
      this.currentPage = 1
      this.model.type = obj.search
      this.getListTable()
    },
    childByValue: function(childValue) {
      this.currentPage = childValue.currentPageNum
      this.pageSize = childValue.pageSizeNum
      this.getListTable()
    },
    // 添加数据||或修改数据
    tableDataP() {
      this.model.types = '2-1'
      this.currentPage = 1
      this.pageSize = 10
      for (let i = 0; i < this.table_datac.length; i++) {
        if (this.table_datac[i].edit === true) {
          this.$message({
            message: this.$t('metadata.waringAttribute'),
            type: 'warning'
          })
          return
        }
        for (const w in this.table_data) {
          for (const j in this.table_datac[i].supportAction) {
            if (this.table_data[w].name === this.table_datac[i].supportAction[j]) {
              this.table_datac[i].supportAction[j] = this.table_data[w].id
            }
          }
        }
        this.table_datac[i].supportAction = JSON.stringify(this.table_datac[i].supportAction)
      }
      for (const i in this.table_data) {
        if (this.table_data[i].edit === true) {
          this.$message({
            message: this.$t('metadata.waringServe'),
            type: 'warning'
          })
          return
        }
      }
      if (this.indext === -1) {
        for (const i in this.table_datac) {
          this.table_datac[i].supportAction = this.table_datac[i].supportAction.substring(1, this.table_datac[i].supportAction.length - 1)
        }
        const data = {
          'ns': this.model.ns,
          'category': this.model.category,
          'ci': this.model.ci,
          'name': this.model.name,
          'type': this.modeldata.type,
          'desc': this.model.desc,
          'partition': this.model.partition,
          'attrs': this.table_datac,
          'actions': this.table_data
        }
        if (this.model.ci === '') {
          this.$message({
            message: this.$t('error.objectidentification'),
            type: 'warning'
          })
          return
        }
        if (this.model.name === '') {
          this.$message({
            message: this.$t('error.objectname'),
            type: 'warning'
          })
          return
        }
        addCi(data).then(res => {
          if (res.code === 200) {
            this.tableData.ciTypeName = this.model.type
            this.currentPage = 1
            if (this.$refs.search && !this.$refs.search.searchModel.search) {
              this.model.type = ''
            }
            this.getListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
            this.dialogFormVisible = false
            this.$emit('menu-active', { item: this.model, type: 'add' })
          }
        })
      } else {
        for (const i in this.table_datac) {
          this.table_datac[i].supportAction = this.table_datac[i].supportAction.substring(1, this.table_datac[i].supportAction.length - 1)
          this.table_datac[i].ext = this.model.attrs.ext
          this.table_datac[i].category = this.model.category
          this.table_datac[i].ci = this.model.ci
          this.table_datac[i].ns = this.model.ns
        }
        for (const i in this.table_data) {
          this.table_data[i].layout = null
        }
        const data = JSON.stringify({
          'ns': this.model.ns,
          'category': this.model.category,
          'ci': this.model.ci,
          'name': this.model.name,
          'type': this.model.type,
          'desc': this.model.desc,
          'partition': this.model.partition,
          'attrs': this.table_datac,
          'actions': this.table_data
        })
        if (this.selectShow && !this.model.type) {
          this.model.type = ''
        }
        editCi(data).then(res => {
          this.model.types = '2-1'
          if (res.code === 200) {
            this.dialogFormVisible = false
            this.currentPage = 1
            if (this.$refs.search && !this.$refs.search.searchModel.search) {
              this.model.type = ''
            }
            this.$emit('menu-active', { item: this.model, type: 'edit' })
            this.getListTable()
            this.$message({
              message: res.data,
              type: 'success'
            })
          }
        })
      }
    },
    handleEditdia() {
      this.title = this.$t('sidebar.addto')
      this.disabled = false
      this.dialogFormVisible = true
      this.model.name = ''
      this.model.desc = ''
      this.model.partition = ''
      this.model.ci = ''
      this.indext = -1
      this.table_data = []
      this.table_datac = []
    },
    // 外层编辑
    handleEditw(index, row) {
      this.model.addShow = true
      this.disabled = true
      this.title = this.$t('public.edit')
      const params = {
        category: row[index].category,
        ci: row[index].ci,
        ns: row[index].ns
      }
      // 列表详情
      getCiDectals(params).then(res => {
        this.attrActionList = []
        for (let i = 0; i < res.data.actions.length; i++) {
          res.data.actions[i].edit = false
          const params = {}
          params.label = res.data.actions[i].name
          params.value = res.data.actions[i].id
          this.attrActionList.push(params)
        }
        for (let i = 0; i < res.data.attrs.length; i++) {
          res.data.attrs[i].edit = true
          res.data.attrs[i].supportAction = res.data.attrs[i].supportAction.split(',')
        }
        this.dialogFormVisible = true
        this.table_data = res.data.actions
        this.table_datac = res.data.attrs
        this.model = res.data
        this.model.types = '2-1'
        this.indext = index
        this.initEditAttribute()
      })
    },
    // 服务 属性编辑
    handleEdit(index, row, obj) {
      for (const i in this.table_datac) {
        if (this.table_datac[i].edit === true) {
          this.$message({
            type: 'warning',
            message: this.$t('metadata.waringAttribute')
          })
          return
        }
      }
      for (const i in this.table_data) {
        if (this.table_data[i].edit === true) {
          this.$message({
            type: 'warning',
            message: this.$t('metadata.waringServe')
          })
          return
        }
      }
      this.disabledAdd = true
      this.attrActionList = []
      for (const i in this.table_data) {
        const params = {}
        params.label = this.table_data[i].name
        params.value = this.table_data[i].id
        this.attrActionList.push(params)
      }
      row.edit = true
    },
    // 删除
    handleDeletew(index, row) {
      const params = {
        category: row[index].category,
        ci: row[index].ci,
        ns: row[index].ns
      }
      this.model = row[index]
      this.model.types = '2-1'
      this.$confirm(this.$t('tips.whetherdelete'), this.$t('tips.tips'), {
        confirmButtonText: this.$t('sidebar.determine'),
        cancelButtonText: this.$t('sidebar.cancel'),
        type: 'warning'
      }).then(() => {
        deleteCiType(params).then(res => {
          if (res.code === 200) {
            this.currentPage = 1
            this.$emit('menu-active', { item: this.model, type: 'delect' })
            this.$message({
              message: res.message,
              type: 'success'
            })
            if (this.selectShow && !this.model.type) {
              this.model.type = ''
            }
            if (this.$refs.search && !this.$refs.search.searchModel.search) {
              this.model.type = ''
            }
            this.getListTable()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: this.$t('sidebar.canceldelete')
        })
      })
    },
    // 服务  属性删除
    handleDelete(index, row, obj) {
      if (obj === 'attribute') {
        this.table_datac.splice(index, 1)
      } else if (obj === 'competence') {
        if (row.flag === true) {
          this.$message({
            type: 'warning',
            message: this.$t('error.errorDd')
          })
        } else {
          this.table_data.splice(index, 1)
        }
      }
    },
    // 能力 属性保存
    handleSave(index, row, obj) {
      if (obj === 'attribute') {
        if (!row.id) {
          this.$message({
            message: this.$t('error.Enterattributeidentification'),
            type: 'warning'
          })
          return
        }
        if (!row.name) {
          this.$message({
            message: this.$t('error.Enterattributename'),
            type: 'warning'
          })
          return
        }
        if (!row.type) {
          this.$message({
            message: this.$t('error.Enterattributetype'),
            type: 'warning'
          })
          return
        }
        if (row.supportAction.length <= 0) {
          this.$message({
            message: this.$t('error.EnterattributesupportAction'),
            type: 'warning'
          })
          return
        }
        delete this.table_datac[index].add
      } else if (obj === 'competence') {
        if (!row.id) {
          this.$message({
            message: this.$t('error.Enterservename'),
            type: 'warning'
          })
          return
        }
        if (!row.name) {
          this.$message({
            message: this.$t('error.Enterservetype'),
            type: 'warning'
          })
          return
        }
        if (!row.group) {
          this.$message({
            message: this.$t('error.Enterservegroup'),
            type: 'warning'
          })
          return
        }
        if (!row.direction) {
          this.$message({
            message: this.$t('error.Enterservedirection'),
            type: 'warning'
          })
          return
        }
        delete this.table_data[index].add
      }
      row.edit = false
    },
    // 服务  属性添加
    handleAdd(obj) {
      var addDataJson = {}
      for (var key in this.new_date_json) {
        if (key === 'edit') {
          delete addDataJson[key]
        } else if (key === 'add') {
          delete addDataJson[key]
        } else {
          addDataJson[key] = ''
        }
      }
      addDataJson.edit = true
      addDataJson.add = true
      for (const i in this.table_data) {
        if (this.table_data[i].edit === true) {
          this.$message({
            type: 'warning',
            message: this.$t('metadata.waringServe')
          })
          return
        }
      }
      for (const i in this.table_datac) {
        if (this.table_datac[i].edit === true) {
          this.$message({
            type: 'warning',
            message: this.$t('metadata.waringAttribute')
          })
          return
        }
      }
      this.disabledAdd = false
      if (obj === 'attribute') {
        this.attrActionList = []
        for (const i in this.table_data) {
          if (this.table_data[i].edit === false) {
            const params = {}
            params.label = this.table_data[i].name
            params.value = this.table_data[i].id
            this.attrActionList.push(params)
          }
        }
        this.table_datac.unshift(addDataJson)
      } else if (obj === 'competence') {
        this.table_data.unshift(addDataJson)
      }
    },
    // 初始化编辑属性
    initEditAttribute() {
      // for (const i in this.table_datac) {
      //   this.table_datac[i].supportAction = this.table_datac[i].supportAction.split(',')
      // }
      var dataArray = this.table_data
      var dataArrayt = this.table_datac
      if (dataArray.length > 0) {
        // 添加编辑事件
        for (var index in dataArray) {
          dataArray[index]['edit'] = false
        }
        if (Object.keys(this.new_date_json).length === 0) {
          //  新增时，初始化数据结构
          this.initAddDataJson(dataArray[0])
        }
      }
      if (dataArrayt.length > 0) {
        // 添加编辑事件
        for (var indext in dataArrayt) {
          dataArrayt[indext]['edit'] = false
        }
        if (Object.keys(this.new_date_json).length === 0) {
          this.initAddDataJson(dataArrayt[0])
        }
      }
    },
    initAddDataJson(dataArray) {
      // 新增时，初始化数据结构
      var dataJson = dataArray
      var newDateJson = {}
      for (var key in dataJson) {
        if (key === 'edit') {
          newDateJson[key] = 'true'
        } else {
          newDateJson[key] = ''
        }
      }
      newDateJson['add'] = true
      this.new_date_json = newDateJson
    },
    // 获取表格数据
    getListTable() {
      const params = {
        category: this.model.category,
        ns: this.model.ns,
        type: this.model.type
      }
      const val = {
        pageNum: this.currentPage,
        pageSize: this.pageSize
      }
      getTable(val, params).then(res => {
        if (res.code === 200) {
          this.tableData = res.data.currentPageContent
          this.total = res.data.recordsTotal
        }
      })
    }
  }
}
</script>
