  <!-- 详情暂定为不可编辑
  bool  限制服务 属性添加 及编辑成功之后提价按钮
  关于编辑  添加的方法同model页面   此页面方法依旧存在-->
<template>
  <div class="alarm-container">
    <el-form :model="model" style="margin-top:15px;">
      <div class="kuang">
        <p class="jichu">{{ $t("metadata.basics") }}</p>
        <el-form-item
          :label="$t('metadata.identification')"
          :label-width="formLabelWidth"
          class="el-form-item1"
        >
          <el-input v-model="model.ci" autocomplete="off" disabled="disabled" />
        </el-form-item>
        <el-form-item
          :label="$t('metadata.name')"
          :label-width="formLabelWidth"
          class="el-form-item1"
        >
          <el-input v-model="model.name" autocomplete="off" disabled="disabled" />
        </el-form-item>
        <el-form-item
          :label="$t('metadata.type')"
          :label-width="formLabelWidth"
          class="el-form-item1"
        >
          <el-input v-model="model.ciTypeName" autocomplete="off" disabled="disabled" />
        </el-form-item>
        <el-form-item
          :label="$t('metadata.desc')"
          :label-width="formLabelWidth"
          class="el-form-item2"
        >
          <el-input v-model="model.desc" disabled="disabled" />
        </el-form-item>
      </div>
    </el-form>
    <div class="kuang heigth">
      <p class="jichu"> {{ $t("sidebar.service") }}</p>
      <el-button
        v-show="bool"
        class="child_button"
        type="primary"
        @click="handleAdd('competence')"
      >
        {{ $t("sidebar.addto") }}</el-button>
      <el-table ref="mytable" :data="table_data" style="width: 100%;height:240px">
        <el-table-column
          v-for="(item, index, key) in gridData"
          :key="key"
          align="center"
          :item="item"
          :index="index"
          :label="item.label"
        >
          <template slot-scope="scope">
            <span>{{ scope.row[item.prop] }}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="kuang heigth">
      <p class="jichu">{{ $t("metadata.attribute") }}</p>
      <el-button
        v-show="bool"
        class="child_button"
        type="primary"
        @click="handleAdd('attribute')"
      >{{ $t("sidebar.addto") }}</el-button>
      <el-table ref="mytable" :data="table_datac" style="width: 100%;height:278px">
        <el-table-column
          v-for="(item, index, key) in gridData1"
          :key="key"
          align="center"
          :item="item"
          :index="index"
          :label="item.label"
        >
          <template slot-scope="scope">
            <span v-if="scope.row.edit">{{ scope.row[item.prop] }}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div v-show="bool" slot="footer" class="dialog-footer" style="float:right;margin-top:10px">
      <el-button @click="back()">{{ $t("sidebar.cancel") }}</el-button>
      <el-button type="primary" @click="tableDataP()">{{ $t("sidebar.determine") }}</el-button>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { getCiDectals, getActionType, getAttrType, getCiType, getDirectionType, getActionDomainType } from '@/api/metadata.js'
export default {
  name: 'Alarm',
  props: {
    details: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      is_edit: true, // 是否可编辑
      is_delete: true, // 是否可删除
      bool: false,
      title: this.$t('sidebar.addto'),
      gridData: [
        {
          prop: 'id',
          label: this.$t('metadata.identification'),
          width: '150'
        },
        {
          prop: 'name',
          label: this.$t('metadata.name'),
          width: '150'
        },
        {
          prop: 'desc',
          label: this.$t('metadata.desc'),
          width: '150'
        },
        {
          prop: 'groupLabel',
          label: this.$t('metadata.servicegroup'),
          width: '150'
        },
        {
          prop: 'directionLabel',
          label: this.$t('metadata.instruction'),
          width: '150'
        }
      ],
      gridData1: [
        {
          prop: 'id',
          label: this.$t('metadata.identification'),
          width: '150'
        },
        {
          prop: 'name',
          label: this.$t('metadata.name'),
          width: '150'
        },
        {
          prop: 'desc',
          label: this.$t('metadata.desc'),
          width: '150'
        },
        {
          prop: 'type',
          label: this.$t('metadata.attributetype'),
          width: '150'
        },
        {
          prop: 'supportActionLabel',
          label: this.$t('metadata.supportAction'),
          width: '150'
        }
      ],
      // 表格数据
      table_data: [],
      table_datac: [],
      new_date_json: [],
      optionsrattr: [],
      optiontype: [],
      model: {
        partition: '',
        name: '',
        type: '',
        desc: '',
        ci: '',
        category: '',
        types: '',
        ciTypeName: ''
      },
      formLabelWidth: '120px',
      optionsr: [],
      optionsrtype: [],
      optionDomainType: [],
      attrActionList: [],
      dataArray: [],
      dataArrays: []
    }
  },
  // 这颗树：一级是产品ns  二级是主题category  三级是类型tag  叶子是对象ci
  computed: {
    ...mapGetters(['sidebar', 'name']),
    containerClass() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened
      }
    }
  },
  watch: {
    details: {
      handler: function(n, o) {
        if (n.details === 'details') {
          this.title = this.$t('metadata.details')
          this.model.category = n.category
          this.model.nullLiteral
          this.model.ci = n.ci
          const params = {
            category: n.category,
            ci: n.ci,
            ns: n.ns
          }
          this.getDetalis(params)
        }
      }
    }
  },
  created() {
    this.model.category = this.details.category
    this.model.ns = this.details.ns
    this.model.ci = this.details.ci
    this.model.types = '2-2'
    const params = {
      category: this.model.category,
      ns: this.model.ns,
      ci: this.model.ci
    }
    this.getDetalis(params)
  },
  mounted: function() {
    // 查询对象属性类型下拉列表
    getAttrType().then(res => {
      this.optionsr = res.data.attrType || []
    })
    // 查询对象能力类型下拉列表
    getActionType().then(res => {
      this.optionsrattr = res.data.actionType || []
    })
    // 查询对象类型下拉列表
    getCiType().then(res => {
      this.optiontype = res.data.ciType || []
    })
    // 查询对象能力服务类别下拉列表
    getDirectionType().then(res => {
      this.optionsrtype = res.data.directionType || []
    })
    // 查询对象能力域下拉列表
    getActionDomainType().then(res => {
      this.optionDomainType = res.data.actionType || []
    })
  },
  methods: {
    // 详情取消
    back() {
      this.model.types = '2-1'
      this.$emit('menu-active', { item: this.model, type: 'cancel' })
    },
    getDetalis(params) {
      getCiDectals(params).then(res => {
        for (let i = 0; i < res.data.attrs.length; i++) {
          res.data.attrs[i].edit = 'false'
        }
        for (let i = 0; i < res.data.actions.length; i++) {
          res.data.actions[i].edit = 'false'
        }
        this.dialogFormVisible = true
        this.table_data = res.data.actions
        this.table_datac = res.data.attrs
        this.model = res.data
        this.indext = 5
      })
    }
  }
}
</script>
