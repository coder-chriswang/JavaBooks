<template>
  <div class="top-menu">
    <div
      ref="metadata"
      class="iconfont icon-peizhi menu-item"
      :class="{'is-active':isActive.metadata}"
      @click="toPath('metadata')"
    >
      {{ $t('route.metadata') }}
    </div>
    <div
      ref="access"
      class="iconfont icon-daping menu-item"
      :class="{'is-active':isActive.access}"
      @click="toPath('/access')"
    >
      {{ $t('route.access') }}
    </div>
    <div
      ref="data"
      class="iconfont icon-tongji menu-item"
      :class="{'is-active':isActive.data}"
      @click="toPath('data')"
    >
      {{ $t('route.data') }}
    </div>
    <div
      ref="system"
      class="iconfont icon-yunwei menu-item"
      :class="{'is-active':isActive.system}"
      @click="toPath('system')"
    >
      {{ $t('route.system') }}
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      route: this.$route,
      isActive: {
        dashboard: false,
        resources: false,
        metadata: false,
        access: false,
        data: false,
        system: false
      }
    }
  },
  watch: {
    '$route.name': function(newVal, oldVal) {
      const routeName = newVal
      this.changeClass(routeName)
    }
  },
  mounted() {
    this.changeClass()
  },
  methods: {
    changeClass(routeName = this.$route.name) {
      this.isActive = {
        data: false,
        dashboard: false,
        resources: false,
        metadata: false,
        access: false,
        system: false
      }
      this.isActive[routeName] = true
    },
    toPath(routeName) {
      this.changeClass(routeName)
      this.$router.push({ path: routeName })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../../styles/variables.scss';
.top-menu {
  display: flex;
  line-height: 63px;
  justify-content: center;
  .menu-item {
    color: #fff;
    padding: 0 20px;
    user-select:none;
  }
  .menu-item:hover{
    background-color: $menuHoverText;
  }
  .is-active  {
    background-color: $menuActiveText;
  }
}
</style>

