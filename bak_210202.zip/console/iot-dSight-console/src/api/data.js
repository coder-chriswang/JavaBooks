import request from '@/utils/request'

// 数据树形目录
export function getTree() {
  return request({
    url: `/urm/v1/meta/data/tree`,
    method: 'post',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询CI元数据
export function getTable(data) {
  return request({
    url: `/urm/v1/meta/data/${data.category}/${data.ci}`,
    method: 'get',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 查询对象属性类型下拉列表
export function getCommand(data) {
  return request({
    url: `/urm/v1/meta/data/command`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

