/*
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-14 14:32:32
 * @Description: file content
 */
import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/auth/unifyLogin',
    method: 'post',
    data
  })
}
export function getInfo(token) {
  return request({
    url: '/user/getPrincipal',
    method: 'get'
  })
}
export function refreshToken(data) {
  return request({
    url: '/auth/refresh',
    method: 'get',
    data: data
  })
}

export function getCodeImage(data) {
  return request({
    url: '/common/codeImage',
    method: 'get',
    params: data
  })
}

export function logout() {
  return request({
    url: '/auth/unifyLogout',
    method: 'get'
  })
}

export function getLocale() {
  return request({
    url: '/mng/v1/i18n?enable=f',
    method: 'get'
  })
}
