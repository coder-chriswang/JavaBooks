import request from '@/utils/request'

// 查询设备数据源信息记录集
export function getProduct(data) {
  return request({
    url: `/gwm/v1/product/products/${data.pageSize}/${data.currentPage}`,
    method: 'post',
    data: {
      deviceType: data.deviceType,
      domain: data.domain,
      tenant: data.tenant,
      protocol: data.protocol
    },
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 新增设备数据源信息
export function addProduct(data) {
  return request({
    url: `/gwm/v1/product`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 编辑设备数据源信息
export function editProduct(data) {
  return request({
    url: `/gwm/v1/product`,
    method: 'put',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除数据源信息
export function delectProduct(data) {
  return request({
    url: `/gwm/v1/product/${data}`,
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 获取服务和属性列表
export function getProductciinfo(data) {
  return request({
    url: `/gwm/v1/product/ciinfo/${data}`,
    method: 'get',
    data
  })
}
// 查看设备数据源信息详情
export function getProductcode(data) {
  return request({
    url: `/gwm/v1/product/${data}`,
    method: 'get',
    data
  })
}
// 获取树结构感知资源
export function getTree() {
  return request({
    url: `/gwm/v1/product/tradetree`,
    method: 'get'
  })
}
// 获取树结构管理资源
export function getCitree() {
  return request({
    url: `/gwm/v1/systemds/citree`,
    method: 'get'
  })
}
// 条件查询设备列表
export function getDinstance(data) {
  return request({
    url: `/gwm/v1/dinstance/dinstances/${data.pageSize}/${data.pageNum}`,
    method: 'post',
    data: {
      deviceds_id: data.deviceds_id,
      onLine: data.onLine,
      status: data.status,
      nativeId: data.nativeId,
      instanceid: data.instanceid
    }
  })
}
// 新增设备
export function addDinstance(data) {
  return request({
    url: `/gwm/v1/dinstance`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 修改设备信息
export function editDinstance(data) {
  return request({
    url: `/gwm/v1/dinstance`,
    method: 'put',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除数据源属性映射信息
export function deleteDinstances(data) {
  return request({
    url: `/gwm/v1/dinstance/${data}`,
    method: 'DELETE',
    data
  })
}

// 批量删除设备
export function delectDinstances(data) {
  return request({
    url: `/gwm/v1/dinstance/dinstances`,
    method: 'post',
    data: data
  })
}
// 获取设备详情
export function getDinstanceId(data) {
  return request({
    url: `/gwm/v1/dinstance/${data}`,
    method: 'get',
    data
  })
}

// 下载导入模板
export function downloadDinstance() {
  return request({
    url: `/gwm/v1/dinstance/download/template`,
    method: 'post',
    responseType: 'blob'
    // headers: {
    //   'Content-Type': 'application/vnd.ms-excel'
    // }
  })
}
// 导出设备信息列表
export function exportDinstance(data) {
  return request({
    url: `/gwm/v1/dinstance/export/data/${data.pageNum}/${data.pageSize}`,
    method: 'post',
    data: data.data,
    responseType: 'blob'
  })
}
// 导入设备数据
export function importDinstance(res) {
  return request({
    url: `/gwm/v1/dinstance/import/data/${res.code}`,
    method: 'post',
    data: res.file
  })
}
// 设备状态
export function getStatus(data) {
  return request({
    url: `/gwm/v1/dictionaries/status/dInstance`,
    method: 'get',
    data
  })
}
// 数据源类型
export function getDstypedata(data) {
  return request({
    url: `/gwm/v1/sinstance/list`,
    method: 'get',
    data
  })
}
// 查询数据源服务映射信息记录集
export function getActionmap(data) {
  return request({
    url: `/gwm/v1/actionmap/actionmaps/${data}`,
    method: 'get',
    data
  })
}

// 新增数据源服务映射信息
export function addActionmap(data) {
  return request({
    url: `/gwm/v1/actionmap`,
    method: 'post',
    data
  })
}

// 编辑数据源服务映射信息
export function editActionmap(data) {
  return request({
    url: `/gwm/v1/actionmap`,
    method: 'put',
    data
  })
}
// 删除数据源服务映射信息
export function deleteActionmap(data) {
  return request({
    url: `/gwm/v1/actionmap/${data.ds_code}/${data.ds_type}/${data.actionid}`,
    method: 'DELETE',
    data
  })
}
// 离线导入模板文件
export function getImport(data) {
  return request({
    url: `/gwm/v1/actionmap/import/template/${data.dsCode}`,
    method: 'post',
    data: data.param
  })
}
// 查询数据源属性映射信息记录集
export function getAttrmap(data) {
  return request({
    url: `/gwm/v1/attrmap/${data}`,
    method: 'get',
    data
  })
}

// 新增数据源属性映射信息
export function addAttrmap(data) {
  return request({
    url: `/gwm/v1/attrmap/`,
    method: 'post',
    data
  })
}

// 编辑数据源属性映射信息
export function editAttrmap(data) {
  return request({
    url: `/gwm/v1/attrmap/`,
    method: 'put',
    data
  })
}
// 删除数据源属性映射信息
export function deleteAttrmap(data) {
  return request({
    url: `/gwm/v1/attrmap/${data.ds_code}/${data.ds_type}/${data.attr_id}`,
    method: 'DELETE',
    data
  })
}
// 产品领域
export function getDsdomains(data) {
  return request({
    url: `/gwm/v1/dictionaries/dsdomains`,
    method: 'get',
    data
  })
}

// 产品租户
export function getTenants(data) {
  return request({
    url: `/gwm/v1/dictionaries/tenants`,
    method: 'get',
    data
  })
}

// 产品类别
export function getDevicetypes(data) {
  return request({
    url: `/gwm/v1/dictionaries/devicetypes`,
    method: 'get',
    data
  })
}
// 通信协议
export function getProtocol(data) {
  return request({
    url: `/gwm/v1/dictionaries/protocol`,
    method: 'get',
    data
  })
}
// 接入方式
export function getAccesstype(data) {
  return request({
    url: `/gwm/v1/dictionaries/accesstype`,
    method: 'get',
    data
  })
}
// 消息格式
export function getMsgtype(data) {
  return request({
    url: `/gwm/v1/dictionaries/msgtype`,
    method: 'get',
    data
  })
}
// 数据源类型
export function getDstype(data) {
  return request({
    url: `/gwm/v1/dictionaries/dstype`,
    method: 'get',
    data
  })
}
// 模板映射方式
export function getMethod(data) {
  return request({
    url: `/gwm/v1/dictionaries/template/method`,
    method: 'get',
    data
  })
}
// 设备在线状态
export function getDInstance(data) {
  return request({
    url: `/gwm/v1/dictionaries/dInstance/online`,
    method: 'get',
    data
  })
}
// 获取感知资源表格数据
export function getMetaData(data) {
  return request({
    url: `/urm/v1/meta/data/${data.category}/${data.ci}`,
    method: 'get',
    data
  })
}
export function getDataCommand(data) {
  return request({
    url: `/urm/v1/meta/data/command`,
    method: 'POST',
    data: data
  })
}

