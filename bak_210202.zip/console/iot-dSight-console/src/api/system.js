import request from '@/utils/request'

// 查询系统数据源实例列表
export function getSinstance(data) {
  let url = `/gwm/v1/sinstance/${data.pageSizeNum}/${data.currentPageNum}/${data.id}/?connectivity=${data.connectivity}`
  if (!data.connectivity) {
    url = `/gwm/v1/sinstance/${data.pageSizeNum}/${data.currentPageNum}/${data.id}`
  }
  return request({
    url: url,
    method: 'post',
    data
  })
}

// 新增数据源属性映射信息
export function addSinstance(data) {
  return request({
    url: `/gwm/v1/sinstance`,
    method: 'post',
    data: {
      'name': data.name,
      'nativeId': data.nativeId, // 域名
      'systemId': data.systemId,
      'instanceId': data.instanceId,
      'ext': JSON.stringify(data.ext)
    },
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 编辑数据源属性映射信息
export function editSinstance(data) {
  return request({
    url: `/gwm/v1/sinstance`,
    method: 'put',
    data: {
      'name': data.name,
      'nativeId': data.nativeId, // 域名
      'systemId': data.systemId,
      'instanceId': data.instanceId,
      'ext': JSON.stringify(data.ext)
    },
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除数据源属性映射信息
export function deleteSinstance(data) {
  return request({
    url: `/gwm/v1/sinstance/${data}`,
    method: 'DELETE',
    data
  })
}
// 查询系统数据源树
export function getTree() {
  return request({
    url: `/gwm/v1/systemds/tree`,
    method: 'get'
  })
}
// 获取系统数据源实例详情
export function getSnstance(data) {
  return request({
    url: `/gwm/v1/sinstance/${data}`,
    method: 'get'
  })
}
// 获取协议
export function getProtocol() {
  return request({
    url: `/gwm/v1/dictionaries/sinstance/protocol`,
    method: 'get'
  })
}
// 获取认证方式
export function getAuthway() {
  return request({
    url: `/gwm/v1/dictionaries/sinstance/authway`,
    method: 'get'
  })
}
// 获取连通性状态
export function getConnectivity() {
  return request({
    url: `/gwm/v1/dictionaries/status/connectivity`,
    method: 'get'
  })
}
// 自定义上传
export function getCertificate(data) {
  return request({
    url: `/gwm/v1/sinstance/upload/certificate/${data}`,
    method: 'post'
  })
}
