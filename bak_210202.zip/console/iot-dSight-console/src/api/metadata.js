import request from '@/utils/request'

// 对象元数据树形目录
export function getTree() {
  return request({
    url: `/urm/v1/meta/catalog/tree`,
    method: 'post',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  })
}
// 查询元数据对象列表
export function getTable(val, params) {
  return request({
    url: `/urm/v1/meta/cis/${val.pageSize}/${val.pageNum}`,
    method: 'post',
    data: params,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 获取指定元数据对象详情
export function getCiDectals(data) {
  return request({
    url: `/urm/v1/meta/ci/${data.ns}/${data.category}/${data.ci}`,
    method: 'get'
  })
}

// 查询对象属性类型下拉列表
export function getAttrType() {
  return request({
    url: `/urm/v1/meta/ci/attrType`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象能力类型下拉列表
export function getActionType() {
  return request({
    url: `/urm/v1/meta/ci/actionType`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象类型下拉列表
export function getCiType() {
  return request({
    url: `/urm/v1/meta/ci/ciType`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除指定元数据对象
export function deleteCiType(data) {
  return request({
    url: `/urm/v1/meta/ci/${data.ns}/${data.category}/${data.ci}`,
    method: 'delete'
  })
}
// 添加元数据对象
export function addCi(data) {
  return request({
    url: `/urm/v1/meta/ci`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 编辑元数据对象
export function editCi(data) {
  return request({
    url: `/urm/v1/meta/ci`,
    method: 'put',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象能力服务类别下拉列表
export function getDirectionType() {
  return request({
    url: `/urm/v1/meta/ci/directionType`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象能力域下拉列表
export function getActionDomainType() {
  return request({
    url: `/urm/v1/meta/ci/actionDomainType`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 属性所支持能力的列表
export function getAttrActions() {
  return request({
    url: `/urm/v1/meta/ci/attrActions`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 服务能力类别组下拉列表
export function getActionGroup() {
  return request({
    url: `/urm/v1/meta/ci/actionGroup`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象标签配置信息记录集
export function getTages(params) {
  return request({
    url: `/urm/v1/meta/tags/${params.pageSizeNum}/${params.currentPageNum}/?ns=${params.type}`,
    method: 'get',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 新增对象标签配置信息
export function addTag(data) {
  return request({
    url: `/urm/v1/meta/tag`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 更新对象标签配置信息
export function editTag(data) {
  return request({
    url: `/urm/v1/meta/tag`,
    method: 'put',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除对象标签配置信息
export function deleteTag(data) {
  return request({
    url: `/urm/v1/meta/tag`,
    method: 'delete',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 下拉框产品列表
export function getNss() {
  return request({
    url: `/urm/v1/meta/nss`,
    method: 'get',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象标签配置信息记录集
export function getNssList(params) {
  return request({
    url: `/urm/v1/meta/nss/${params.pageSizeNum}/${params.currentPageNum}`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 新增对象标签配置信息
export function addNs(data) {
  return request({
    url: `/urm/v1/meta/ns`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 更新对象标签配置信息
export function editNs(data) {
  return request({
    url: `/urm/v1/meta/ns`,
    method: 'put',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除对象标签配置信息
export function deleteNs(data) {
  return request({
    url: `/urm/v1/meta/ns/${data}`,
    method: 'delete',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象标签配置信息记录集
export function getCategorys(params) {
  return request({
    url: `/urm/v1/meta/ns/categorys/${params.pageSizeNum}/${params.currentPageNum}/?ns=${params.type}`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 新增对象标签配置信息
export function addCategorys(data) {
  return request({
    url: `/urm/v1/meta/ns`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 更新对象标签配置信息
export function editCategorys(data) {
  return request({
    url: `/urm/v1/meta/ns`,
    method: 'put',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除对象标签配置信息
export function deleteCategorys(data) {
  return request({
    url: `/urm/v1/meta/ns/category/${data.ns}/${data.category}`,
    method: 'delete',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 查询对象标签配置信息记录集
export function getRelations(params) {
  return request({
    url: `/urm/v1/meta/relations/${params.pageSizeNum}/${params.currentPageNum}`,
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 新增对象标签配置信息
export function addRelations(data) {
  return request({
    url: `/urm/v1/meta/relation`,
    method: 'post',
    dataType: 'json',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

// 更新对象标签配置信息
export function editRelations(data) {
  return request({
    url: `/urm/v1/meta/relation`,
    method: 'put',
    dataType: 'json',
    data: data,
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 删除对象标签配置信息
export function deleteRelations(data) {
  return request({
    url: `/urm/v1/meta/relation/${data}`,
    method: 'delete',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 获取对象关系配置详情
export function getDateils(data) {
  return request({
    url: `/urm/v1/meta/relation/${data}`,
    method: 'get',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}
// 获取模型导航数据
export function getCatalogtree() {
  return request({
    url: `/urm/v1/meta/catalog/tree`,
    method: 'post',
    headers: {
      'Content-Type': 'application/json'
    }
  })
}

