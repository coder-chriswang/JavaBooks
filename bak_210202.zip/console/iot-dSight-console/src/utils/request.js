/*
 * @Author: 刘彦宏
 * @Date: 2019-12-02 11:15:54
 * @LastEditTime: 2020-09-23 17:32:19
 */
import axios from 'axios'
// import { refreshToken } from '@/api/user'
// MessageBox,
import { Message } from 'element-ui'
import store from '@/store'
import { getLanguage, getToken, getRefreshToken } from '@/utils/auth'

// create an axios instance
const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  withCredentials: true, // send cookies when cross-domain requests
  timeout: 5000 // request timeout
})
// service.defaults.withCredentials = true
// request interceptor
service.interceptors.request.use(
  config => {
    config.headers['lang'] = getLanguage() === 'zh' ? 'zh_CN' : 'en_US'
    // 判断是否验证码请求接口，是则传sid
    if (config.data && config.data.isLogin) {
      config.headers['sid'] = sessionStorage.getItem('uuid')
      delete config.data.isLogin
    } else if ((config.data && config.data.isRefresh) || config.url.indexOf('unifyLogout') > -1) { // 判断是否刷新token接口，是则传refreshToken否则传token
      if (config.data && config.data.isRefresh) {
        delete config.data.isRefresh
      }
      config.headers['refreshToken'] = getRefreshToken()
    } else {
      config.headers['authorization'] = 'Bearer' + ' ' + getToken()
    }

    // 系统接口 本地适配
    if (config.url.includes('/mng')) {
      config.url = config.url.replace('/mng', '')
      config.baseURL = process.env.VUE_APP_MNG_API
    }
    // 资源本地接口适配
    if (config.url.includes('/urm')) {
      config.url = config.url.replace('/urm', '')
      config.baseURL = process.env.VUE_APP_URM_API
    }
    if (config.url.includes('/gwm')) {
      config.url = config.url.replace('/gwm', '')
      config.baseURL = process.env.VUE_APP_GWM_API
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  response => {
    let res = response.data

    // if the custom code is not 20000, it is judged as an error.
    if (parseInt(res.code) === 200) {
      return res
    } else if (parseInt(res.code) === 500) {
      Message({
        message: res.message,
        type: 'error',
        duration: 5 * 1000
      })
      return res
    } else {
      if (res.type === 'application/vnd.ms-excel') {
        res = { 'res': response.data, 'headers': response.headers }
        Message({
          message: '文件下载中',
          type: 'success',
          duration: 5 * 1000
        })
        return res
      }
      switch (parseInt(res.code)) {
        case 1006:
          store.dispatch('user/resetToken')
          // return res
          break
        case 1010:
          Message({
            message: res.message,
            type: 'error',
            duration: 5 * 1000
          })
          store.dispatch('user/logout')
          break
        default:
        //   return res
          Message({
            message: res.message,
            type: '',
            duration: 5 * 1000
          })
          break
      }
      return res
    }
  },
  error => {
    Message({
      message: error.message,
      type: 'error',
      duration: 5 * 1000
    })
    return Promise.reject(error)
  }
)

export default service
