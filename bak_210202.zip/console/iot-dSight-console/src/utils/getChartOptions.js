
/*
* chartData 后端接口数据
* chartType 图类型：'line','bar'
* 生成柱状图或折线图的option配置
*/
function lineOrBarChart(chartData, chartType) {
  const option = {
    title: { // 标题
      // top: 20,
      text: chartData.chartTitle,
      textStyle: {
        fontWeight: 'normal',
        fontSize: 16
      },
      left: '1%'
    },
    tooltip: { // 鼠标悬浮显示
      trigger: 'axis'
    },
    legend: { // 图例
      top: 20,
      // icon: 'rect',
      itemWidth: 14,
      itemHeight: 5,
      itemGap: 13,
      data: chartData.data.legend.nameArr,
      right: '4%',
      textStyle: {
        fontSize: 12
      }
    },
    grid: { // 画布布局
      left: '2%',
      right: '2%',
      bottom: '20',
      containLabel: true
    },
    xAxis: [{ // X轴
      type: 'category', // 轴类型： 'value','category','time','log'
      boundaryGap: chartType === 'bar',
      data: chartData.data.xData
    }],
    yAxis: [{ //    Y轴
      type: 'value',
      name: chartData.data.yUnit, // 轴数据单位
      nameTextStyle: { color: '#FFFFFF' },
      axisTick: {
        show: false
      },
      axisLabel: {
        margin: 10,
        textStyle: {
          fontSize: 14
        }
      }
    }],
    series: []
  }
  // 限制最多6条数据
  const seriesNum = chartData.data.legend.keyArr.length < 6 ? chartData.data.legend.keyArr.length : 6
  for (let i = 0; i < seriesNum; i++) {
    const serie = {
      name: chartData.data.legend.nameArr[i],
      type: chartType, // 'line': 折线图，'bar': 柱状图
      stack: chartType === 'bar' ? chartData.data.legend.nameArr[0] : null,
      smooth: true,
      symbol: 'circle',
      symbolSize: 5,
      showSymbol: false,
      lineStyle: {
        normal: {
          width: 1
        }
      },
      data: chartData.data.yData[chartData.data.legend.keyArr[i]]
    }
    option.series.push(serie)
  }
  return option
}

/**
 *  仪表盘chart配置方法
 *
 */
function gaugeChart(chartData) {
  return {
    title: { // 标题
      // top: 20,
      text: chartData.chartTitle,
      textStyle: {
        fontWeight: 'normal',
        fontSize: 16
      },
      left: '1%'
    },
    tooltip: {
      formatter: '{a} <br/>{b} : {c}%'
    },
    series: [
      {
        name: chartData.chartTitle,
        type: 'gauge',
        center: ['50%', '60%'], // 默认全局居中
        radius: '100%',
        startAngle: 200,
        endAngle: -20,
        axisLine: { // 坐标轴线          // 坐标轴线
          lineStyle: { // 属性lineStyle控制线条样式
            color: [[1, '#008ACD']],
            width: 2
            // shadowColor: '#fff', // 默认透明
            // shadowBlur: 10
          }
        },
        axisTick: {
          length: 5
        },

        splitLine: { // 分隔线
          length: 10, // 属性length控制线长
          lineStyle: { // 属性lineStyle（详见lineStyle）控制线条样式
            color: 'auto'
          }
        },
        pointer: {
          width: 2,
          shadowColor: '#fff', // 默认透明
          shadowBlur: 5
        },
        title: {
          show: false
        },
        detail: {
          formatter: '{value}%',
          color: '#eee',
          fontSize: 20
        },
        data: chartData.data
      }
    ]
  }
}

/**
 * 饼图chart配置方法
 */
function pieChart(chartData) {
  return {
    title: {
      text: chartData.chartTitle,
      // subtext: '纯属虚构',
      left: 'left'
    },
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    legend: {
      type: 'scroll',
      orient: 'vertical',
      right: 10,
      top: 20,
      data: chartData.data.legend
    },
    series: [
      {
        name: '访问来源',
        type: 'pie',
        radius: ['55%', '85%'],
        center: ['50%', '50%'],
        data: chartData.data.series.pieData,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0
          }
        }
      }
    ]
  }
}

function getChartOptions(chartData) {
  switch (chartData.chartType) {
    case 'line':
      return lineOrBarChart(chartData, chartData.chartType)
    case 'bar':
      return lineOrBarChart(chartData, chartData.chartType)
    case 'pie':
      return pieChart(chartData)
    case 'gauge':
      return gaugeChart(chartData)
  }
}
export {
  getChartOptions
}
