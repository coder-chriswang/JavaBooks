/*
 * @Author: 刘彦宏
 * @Date: 2020-08-10 15:00:16
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-15 09:56:40
 * @Description: file content
 */
import Vue from 'vue'
import Cookies from 'js-cookie'
import Element from 'element-ui'
import i18n from './lang' // internationalization
import App from './App'
import store from './store'
import router from './router'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets
import 'element-ui/lib/theme-chalk/index.css'
import '@/components/ef/index.css'
import '@/styles/index.scss' // global css
import '@/icons' // icon
import '@/permission' // permission control
import Bus from '@/utils/bus'
import axios from 'axios' // 导入axios
Vue.prototype.$axios = axios // 修改原始数据
Vue.prototype.$bus = Bus

/**
 * If you don't want to use mock-server
 * you want to use MockJs for mock api
 * you can execute: mockXHR()
 *
 * Currently MockJs will be used in the production environment,
 * please remove it before going online ! ! !
 */
// if (process.env.NODE_ENV === 'production') {
//   const { mockXHR } = require('../mock')
//   mockXHR()
// }

Vue.use(Element, {
  size: Cookies.get('size') || 'medium', // set element-ui default size
  i18n: (key, value) => i18n.t(key, value)
})
Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  store,
  i18n,
  render: h => h(App)
  // methods:{

  //   moreChart() {
  //       var options = this.getMoreOptions(this.type);

  //       if (this.chart) {
  //           this.chart.destroy();
  //       };
  //   // 初始化 Highcharts 图表
  //   this.chart = new Highcharts.Chart('highcharts-more', options);
  //   }
  // }
})
