<template>
  <div class="iconfont icon-alarm help">
    {{ $t('navbar.alarm') }}
  </div>
</template>
<script>
export default {

}
</script>

<style lang="scss" scoped>
.help {
  cursor:pointer;
  font-size: 14px;
  color: #fff;
  user-select:none;
  line-height: 15px;
  display: inline-block;
  margin-right: 20px;
}
</style>
