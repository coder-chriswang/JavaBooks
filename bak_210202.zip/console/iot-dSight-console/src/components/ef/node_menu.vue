<template>
  <div ref="tool" class="flow-menu">
    <div v-for="menu in menuList" :key="menu.id">
      <span class="ef-node-pmenu" @click="menu.open = !menu.open"><i :class="{'el-icon-caret-bottom': menu.open,'el-icon-caret-right': !menu.open}" />&nbsp;{{ menu.name }}</span>
      <ul v-show="menu.open">
        <li v-for="subMenu in menu.children" :key="subMenu.id" :type="subMenu.type" :class="{'el-icon-caret-bottom': subMenu.open,'el-icon-caret-right': !subMenu.open}" @click="subMenu.open = !subMenu.open">
          <i :class="subMenu.ico" /> {{ subMenu.name }}
          <ul v-show="!subMenu.open" class="ef-node-menu-ul">
            <li v-for="subMenue in subMenu.children" :key="subMenue.id" class="ef-node-menu-ul" :type="subMenue.type">
              <i :class="subMenue.ico" /> {{ subMenue.name }}
              <ul v-show="menu.open" class="ef-node-menu-ul">
                <!-- <draggable @end="end" @start="move" v-model="subMenue.children" :options="draggableOptions"> -->
                <li v-for="subMenuer in subMenue.children" :key="subMenuer.id" class="ef-node-menu-ul" :type="subMenuer.type">
                  <i :class="subMenuer.ico" /> {{ subMenuer.name }}
                  <ul v-show="menu.open" class="ef-node-menu-ul">
                    <draggable v-model="subMenuer.children" :options="draggableOptions" @end="end" @start="move">
                      <li v-for="subMenuerd in subMenuer.children" :key="subMenuerd.id" class="ef-node-menu-li" :type="subMenuerd.type">
                        <i :class="subMenuerd.ico" /> {{ subMenuerd.name }}
                      </li>
                    </draggable>
                  </ul>
                </li>
                <!-- </draggable> -->
              </ul>
            </li>
          </ul>
        </li>
      </ul>
    </div>
    <div v-for="menu in menuListv" :key="menu.id">
      <span class="ef-node-pmenu" @click="menu.open = !menu.open"><i :class="{'el-icon-caret-bottom': menu.open,'el-icon-caret-right': !menu.open}" />&nbsp;{{ menu.name }}</span>
      <ul v-show="menu.open">
        <draggable v-model="menu.children" :options="draggableOptions" @end="end" @start="move">
          <li v-for="subMenuerd in menu.children" :key="subMenuerd.id" class="ef-node-menu-li" :type="subMenuerd.type">
            <i :class="subMenuerd.ico" /> {{ subMenuerd.name }}
          </li>
        </draggable>
      </ul>
    </div>
  </div>
</template>
<script>
import draggable from 'vuedraggable'

var mousePosition = {
  left: -1,
  top: -1
}

export default {
  components: {
    draggable
  },
  props: {
    // pageSizes
    menuList: {
      type: Array,
      default: () => []
    },
    menuListv: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      activeNames: '1',
      // draggable配置参数参考 https://www.cnblogs.com/weixin186/p/10108679.html
      draggableOptions: {
        preventOnFilter: false,
        sort: false,
        disabled: false,
        ghostClass: 'tt',
        // 不使用H5原生的配置
        forceFallback: true,
        show: true
        // 拖拽的时候样式
        // fallbackClass: 'flow-node-draggable'
      },
      // 默认打开的左侧菜单的id
      defaultOpeneds: ['1', '2'],
      nodeMenu: {}
    }
  },
  created() {
    /**
     * 以下是为了解决在火狐浏览器上推拽时弹出tab页到搜索问题
     * @param event
     */
    if (this.isFirefox()) {
      document.body.ondrop = function(event) {
        // 解决火狐浏览器无法获取鼠标拖拽结束的坐标问题
        mousePosition.left = event.layerX
        mousePosition.top = event.clientY - 50
        event.preventDefault()
        event.stopPropagation()
      }
    }
  },
  methods: {
    // 根据类型获取左侧菜单对象
    getMenuByType(type) {
      for (let i = 0; i < this.menuList.length; i++) {
        const childrenr = this.menuList[i].children
        if (childrenr.length > 0) {
          for (let j = 0; j < childrenr.length; j++) {
            const childrench = childrenr[j].children
            for (let k = 0; k < childrench.length; k++) {
              for (let q = 0; q < childrench[k].children.length; q++) {
                for (let t = 0; t < childrench[k].children[q].children.length; t++) {
                  if (childrench[k].children[q].children[t].type === type) {
                    return childrench[k].children[q].children[t]
                  }
                }
              }
            }
          }
        }
      }
      for (let i = 0; i < this.menuListv.length; i++) {
        const children = this.menuListv[i].children
        if (children.length > 0) {
          for (let j = 0; j < children.length; j++) {
            if (children[j].type === type) {
              return children[j]
            }
          }
        }
      }
    },
    // 拖拽开始时触发
    move(evt, a, b, c) {
      var type = evt.item.attributes.type.nodeValue
      this.nodeMenu = this.getMenuByType(type)
    },
    // 拖拽结束时触发
    end(evt, e) {
      this.$emit('addNode', evt, this.nodeMenu, mousePosition)
    },
    // 是否是火狐浏览器
    isFirefox() {
      var userAgent = navigator.userAgent
      if (userAgent.indexOf('Firefox') > -1) {
        return true
      }
      return false
    }
  }
}
</script>
<style>
.el-dialog__body {
  color: #fff;
  padding: 1px 20px;
}
</style>
