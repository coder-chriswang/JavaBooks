<template>
  <div class="x-bar">
    <div :id="id" :option="option" />
  </div>
</template>
<script>
import Vue from 'vue'
import HighCharts from 'highcharts'
import HighChartsMore from 'highcharts/highcharts-more'
import venn from 'highcharts/modules/venn'
HighChartsMore(HighCharts)
Vue.prototype.$venn = venn
export default {
  // 验证类型
  props: {
    id: {
      type: String
    },
    option: {
      type: Object
    }
  },
  mounted() {
    HighCharts.chart(this.id, this.option)
  }
}
</script>
