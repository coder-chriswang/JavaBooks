<!--
 * @Author: 刘彦宏
 * @Date: 2020-08-26 09:31:31
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-10-14 16:53:38
 * @Description:
 * @params menuList: [
 *    {
 *      label: this.$t('sidebar.notice'), // 菜单名称
 *      icon: 'icon-yunwei',              // 菜单图标
 *      id: '4',                          // 菜单id
 *      url: '/mng/v1/dashboard/view',    // 含有需要懒加载的可展开children内容时的请求url
 *      method: 'post',                   // 请求类型
 *      needActive: true,                 // 需要返回枝节点item时设置为true,
 *      data: {                           // 请求参数
 *        pageNum: 1,
 *        pageSize: 10
 *      },
 *      children: []                      // 子节点数组，有需要懒加载的子项时必传
 *    }
 * ]
-->
<template>
  <!-- @mousedown="mousedown" -->
  <div
    ref="dragArea"
    class="sidebar"
    :class="containerClass"
  >
    <hamburger
      id="hamburger-container"
      :is-active="sidebar.opened"
      class="hamburger-container"
      @toggleClick="toggleSideBar"
    />
    <SidebarItem
      v-for="menu in menuList"
      :key="menu.id"
      :item="menu"
      :is-nest="false"
      :is-show-nest="sidebar.opened"
      @click="menuActive(item)"
    />

  </div>
</template>

<script>
/* eslint-disable vue/require-default-prop */
import Bus from '@/utils/bus'
import { mapGetters } from 'vuex'
import Hamburger from '@/components/Hamburger'
import SidebarItem from './SidebarItem'
export default {
  name: 'Sidebar',
  components: {
    Hamburger,
    SidebarItem
  },
  props: {
    menuList: {
      type: Array,
      defalut: null
    },
    activeId: {
      type: String,
      default: ''
    }
  },
  provide() {
    return {
      rootMenu: this
    }
  },
  data() {
    return {
      activeMenuId: this.activeId,
      isMouseDown: false
    }
  },
  computed: {
    ...mapGetters(['sidebar']),
    containerClass() {
      return this.sidebar.opened ? 'openSidebar' : 'hideSidebar'
    }
  },
  created() {
    if (this.menuList.length > 0) {
      if (this.menuList[0].children) {
        if (this.menuList[0].children && this.menuList[0].children.length > 0) {
          this.activeIndex = this.menuList[0].children[0].id
        } else {
          this.activeIndex = this.menuList[0].id
        }
      }
      this.$emit('menu-active', {
        menuId: this.activeIndex,
        item: this.menuList[0]
      })
    }
  },
  mounted() {
    this.$on('item-click', (item) => {
      this.menuActive(item)
    })
    const ele = this.$refs['dragArea']
    if (!ele) {
      return
    }
    if (!this.sidebar.opened) {
      document.querySelector('#hamburger-container').style.left =
        10 + 'px'
      ele.style.width = 10 + 'px'
      ele.style.marginTop = 15 + 'px'
      document.querySelector('#main_body').style.left =
        65 + 'px'
      ele.style.width = 100 + '%'
      document.querySelector('.Breadcrumb').style.marginLeft =
        115 + 'px'
    } else {
      document.querySelector('#hamburger-container').style.left =
         10 + 'px'
      ele.style.width = 210 + 'px'
      ele.style.marginTop = 15 + 'px'
      document.querySelector('#main_body').style.left =
        210 + 'px'
      document.querySelector('.Breadcrumb').style.marginLeft =
        264 + 'px'
    }
    // this.initDragEvent()
  },
  updated() {
    if (this.menuList[0].children) {
      if (this.menuList[0].children && this.menuList[0].children.length > 0) {
        this.activeIndex = this.menuList[0].children[0].id
      } else {
        this.activeIndex = this.menuList[0].id
      }
    }
  },
  methods: {
    initDragEvent() {
      document.onmousemove = (e) => {
        const ele = this.$refs['dragArea']
        if ((!ele) || (!ele.getBoundingClientRect)) {
          return
        }
        const borderLen = 0 // 左右边框
        const eleLeft = ele.getBoundingClientRect().left // div的左侧到浏览器左边距离
        const rightPos = eleLeft + ele.getBoundingClientRect().width + borderLen
        if (rightPos - 8 <= e.pageX && e.pageX <= rightPos) {
          ele.style.cursor = 'col-resize'
        } else {
          if (!this.isMouseDown) {
            ele.style.cursor = 'auto'
          }
        }
        if (this.isMouseDown) {
          if (e.pageX - eleLeft - borderLen > 61) {
            ele.style.width = e.pageX - eleLeft - borderLen + 'px'
            document.querySelector('#hamburger-container').style.left =
            e.pageX - eleLeft - borderLen + 10 + 'px'
            if (!this.sidebar.opened) {
              this.toggleSideBar('indirect')
            }
          } else {
            if (this.sidebar.opened) {
              this.toggleSideBar('indirect')
            }
          }
          this.$store.commit('app/DRAG_SIDEBAR', ele.style.width)
        }
      }
      document.onmouseup = (e) => {
        this.isMouseDown = false
        // $("#mask").remove();
        const box = document.querySelector('#mask')
        box && box.remove()
      }
    },
    mousedown(e) {
      const ele = this.$refs['dragArea']
      if (!ele) return
      const borderLen = 0 // 左右边框
      const eleLeft = ele.getBoundingClientRect().left // div的左侧到浏览器左边距离
      const rightPos = eleLeft + ele.getBoundingClientRect().width + borderLen // div的右侧到浏览器左边距离
      if (rightPos - 8 <= e.pageX && e.pageX <= rightPos) {
        // e.pageX是鼠标当前位置，也就是说鼠标x位置距离div右侧不超过8并且鼠标位置小于div右侧位置
        // 因为mousedown是在div上绑定的，在div右侧没有绑定mousedown，所以拿不到e.pageX

        this.isMouseDown = true

        // 创建遮罩层，防止mouseup事件被其它元素阻止冒泡，导致mouseup事件无法被body捕获，导致拖动不能停止
        const body = document.querySelector('body')
        const bodyWidth = body.getBoundingClientRect().width
        const bodyHeight = body.getBoundingClientRect().height
        var div = document.createElement('div')
        div.setAttribute('id', 'mask')
        div.style =
          'top:0px;left:0px;position:absolute;z-index:9999;width:' +
          bodyWidth +
          'px;height:' +
          bodyHeight +
          'px;'
        body.appendChild(div)
      }
    },
    toggleSideBar(way) {
      if (way !== 'indirect') {
        const ele = this.$refs['dragArea']
        if (!ele) {
          this.$store.dispatch('app/toggleSideBar')
          Bus.$emit('toggleSideBar')
          return
        }
        if (!this.sidebar.opened) {
          document.querySelector('#main_body').style.left =
              210 + 'px'
          document.querySelector('.Breadcrumb').style.marginLeft =
              264 + 'px'
          document.querySelector('#hamburger-container').style.left =
              10 + 'px'
          ele.style.width = 210 + 'px'
        } else {
          document.querySelector('#hamburger-container').style.left =
              10 + 'px'
          ele.style.width = 61 + 'px'
          document.querySelector('#main_body').style.left =
              65 + 'px'
          ele.style.width = 100 + '%'
          document.querySelector('.Breadcrumb').style.marginLeft =
              115 + 'px'
        }
      }
      this.$store.dispatch('app/toggleSideBar')
      Bus.$emit('toggleSideBar')
    },
    menuActive(item) {
      this.activeMenuId = item.id
      this.$emit('menu-active', { menuId: item.id, item: item })
    }
  }
}
</script>

