<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-25 15:46:48
 * @LastEditors: 张通
 * @LastEditTime: 2020-10-14 14:16:21
 * @Description:
-->
<template>
  <div class="menu-item-div">
    <li v-if="!item.children" :style="indent" class="menu-item" :class="{'is-active': active}" @click="menuActive(item)">
      <i v-if="item.icon" class="menu-icon iconfont" :class="item.icon" />
      <span>{{ item.label }}</span>
    </li>
    <ul v-else class="submenu-item">
      <li :style="indent" class="submenu-item-title" :class="{'is-active': active}" @click="menuActive(item)">
        <i v-if="item.icon" class="menu-icon iconfont" :class="item.icon" />
        <span>{{ item.label }}
          <i v-if="item.children" :class="arrow" class="arrow" />
        </span>
      </li>
      <template v-if="opend">
        <SidebarItem
          v-for="child in item.children"
          :key="child.id"
          :is-nest="true"
          :item="child"
          :depth="depth + 1"
          :class="nestMenu"
          @value-change="handlevalueChange"
          @click="menuActive(item)"
        />
      </template>
    </ul>
  </div>
</template>

<script>
// import request from '@/utils/request'
import Emitter from '@/utils/emitter'
export default {
  name: 'SidebarItem',
  mixins: [Emitter],
  props: {
    item: {
      type: Object,
      default: () => {}
    },
    isNest: {
      type: Boolean,
      default: false
    },
    optional: {
      type: Boolean,
      default: true
    },
    depth: {
      type: Number,
      default: 0
    },
    isShowNest: {
      type: Boolean,
      default: false
    }
  },
  inject: ['rootMenu'],
  data() {
    return {
      opend: false
    }
  },
  computed: {
    indent() {
      return `padding-left:${this.depth * 20 + 20}px`
    },
    arrow() {
      return this.opend ? 'el-icon-arrow-up' : 'el-icon-arrow-down'
    },
    active() {
      return this.item.id === this.rootMenu.activeMenuId
    },
    nestMenu() {
      return this.opend ? 'nest-menu' : 'hide-menu'
    }
  },
  mounted() {
    this.$on('item-click', (item) => {
      this.menuActive(item)
    })
  },
  methods: {
    handlevalueChange(item) {
      this.activeMenuId = item.id
      this.$emit('menu-active', { menuId: item.id, item: item })
    },
    async menuActive(item) {
      this.dispatch('Sidebar', 'item-click', item)
      if (item) {
        this.activeMenuId = item.id
        this.$emit('menu-active', { menuId: item.id, item: item })
        // this.$router.push({name:item.url,params: {title:JSON.stringify(item)} })
        // const requestParam = {
        //   url: item.url,
        //   method: item.method,
        //   data: item.data ? item.data : {}
        // }
        // const res = await request(requestParam)
        // item.children = []
        // res.data.length > 0 && res.data.forEach(re => {
        //   item.children.push({
        //     ...re,
        //     label: re.name,
        //     isActive: true,
        //     id: `${re.id}`
        //   })
        // })
        this.opend = !this.opend

        // this.dispatch('Sidebar', 'item-click', item)
        // request(requestParam).then((result) => {
        //   this.opend = !this.opend
        //   if (!item.children || item.children.length === 0 || item.needActive) {
        //     this.dispatch('Sidebar', 'item-click', item)
        //   }
        // }).catch((err) => {
        // })
      } else {
        this.opend = !this.opend
        //    this.$emit('menu-active', { menuId: item.id, item: item })
        if (!item.children || item.children.length === 0 || item.needActive || item.leaf) {
          //  this.$emit('menu-active', { menuId: item.id, item: item })
          this.dispatch('Sidebar', 'item-click', item)
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
.menu-item-div{
  background: $darkBlue3;
  user-select: none;
  color: $light_gray;
  font-size: 14px;
  li {
    list-style-type:none;
    cursor: pointer;
  }
  ul {
    margin: 0;
    padding: 0;
  }
}
.menu-item, .submenu-item-title{
  line-height: 50px;
  background: $darkBlue1;
}
.menu-item:hover, .submenu-item-title:hover{
  background: $linghtBlue3;
}
.nest-menu{
  .menu-item:hover, .submenu-item-title:hover{
    background: $darkBlue5;
  }
}
.nest-menu{
  .menu-item, .submenu-item-title{
    background: $darkBlue3;
  }
}

.is-active{
  background: $linghtBlue2;
}
.nest-menu{
  .is-active{
    color: $linghtBlue2;
  }
}
.arrow {
  float: right;
  padding-right: 20px;
  line-height: 50px;
}
.hide-menu{
  display: none;
}
</style>
