<!--
 * @Author: 张通
 * @Date: 2020-09-14 14:24:47
 * @LastEditors: 张通
 * @LastEditTime: 2020-09-28 16:57:26
 * @Description: file content
-->
<!--
Table组件使用注意事项(必须在外面写一个固定大小的盒子包裹Table组件)
1、pagination 值为true 时，分页才能够有作用，分页对应的方法才能够使用
2、组件tableData、tableHeader 为必穿参数
3、组件table title label字段为label
4、组件table value 字段为 prop
-->
<template>
  <div id="Table" class="Table">
    <header :class="{headers: !pagination}">
      <el-table
        v-if="pageShow"
        ref="singleTable"
        v-loading="loading"
        element-loading-text="$t('public.loading')"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.6)"
        row-class-name="tableRowClass"
        :highlight-current-row="highlightCurrentRow"
        :data="tableData"
        height="100%"
        style="width: 100%"
        :size="tableSize"
        :cell-style="cellStyle"
        @row-click="rowClick"
        @selection-change="selectDelete"
      >

        <el-table-column
          v-if="select"
          type="selection"
          fixed="left"
          width="55"
        />
        <template v-for="(item,index) in tableHeader">
          <el-table-column
            v-if="!item.typeSlot"
            :key="index"
            align="center"
            :show-overflow-tooltip="true"
            :min-width="item.width ? item.width : `182`"
            :prop="item.id"
            :label="item.name"
          />
          <el-table-column
            v-else
            :key="index"
            align="center"
            :show-overflow-tooltip="true"
            :min-width="item.width ? item.width : `182`"
            :prop="item.id"
            :label="item.name"
          >
            <span><i class="el-icon-s-order" @click="icon_alone()" /></span>
          </el-table-column>
        </template>
        <el-table-column v-if="lastTableColumn" fixed="right" align="center" :label="$t('sidebar.operation')" :width="lastColumnWidth">
          <template slot-scope="scope">
            <slot :scope="scope" />
          </template>
        </el-table-column>

      </el-table>
    </header>
    <footer v-if="pagination">
      <el-pagination
        class="pagination"
        :current-page="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </footer>
  </div>
</template>

<script>
export default {
  components: {},
  props: {
    pageSizes: {
      type: Array,
      default: () => [10, 20, 40, 80]
    },
    // pageSize
    pageSize: {
      type: Number,
      default: () => 10
    },
    // 分页总数
    total: {
      type: Number,
      default: () => 0
    },
    // 当前页
    currentPage: {
      type: Number,
      default: () => 1
    },
    // 表格size
    tableSize: {
      type: String,
      default: () => 'small'
    },
    // 是否展示分页
    pagination: {
      type: Boolean,
      default: () => true
    },
    // 是否多选
    select: {
      type: Boolean,
      default: () => false
    },
    // tableData
    tableData: {
      type: Array,
      default: () => []
    },
    // tableHader
    tableHeader: {
      type: Array,
      default: () => []
    },
    // 高亮当前选中行
    highlightCurrentRow: {
      type: Boolean,
      default: () => true
    },
    cellBorderStyle: {
      type: Boolean,
      default: () => true
    },
    // 是否展示table最后列  当lastTableColumn为 true 时， slot才能起作用
    lastTableColumn: {
      type: Boolean,
      default: () => true
    },
    loading: {
      type: Boolean,
      default: () => false
    },
    lastColumnWidth: {
      type: String,
      default: () => '200'
    }
  },
  data() {
    return {
      page: {
        currentPageNum: this.currentPage,
        pageSizeNum: this.pageSize
      },
      pageShow: true
    }
  },
  methods: {
    // 单元格样式
    cellStyle() {
      if (!this.cellBorderStyle) return
      return {
        borderRight: '2px solid #0f1441',
        borderBottom: '2px solid #0f1441'
      }
    },
    // 每页展示的数量改变
    handleSizeChange(v) {
      // if (this.page.currentPageNum * v > this.total) { // 只有比总数大的情况下需要重新加载分页，不然不需要
      //   this.pageShow = false
      //   this.$nextTick(() => {
      //     this.pageShow = true
      //   })
      // }
      this.page.pageSizeNum = v
      this.page.currentPageNum = 1
      this.$emit('pagination-change', this.page)
    },
    // 当前页数改变
    handleCurrentChange(v) {
      this.page.currentPageNum = v
      this.$emit('pagination-change', this.page)
    },
    rowClick(newRow, column) {
      if (this.highlightCurrentRow) {
        this.$emit('handler-row', newRow, column)
      }
    },
    selectDelete(val) {
      this.$emit('changeDelete', val)
    },
    icon_alone() {
      const servess = true
      this.$emit('serve', servess)
    }
  }
}
</script>

<style lang="scss">
.headers {
  height: 100% !important;
}
.el-icon-s-order{
  color: gray;
  font-size: 20px;
}
.Table {
  height: 100%;
  header {
    height: calc(100% - 75px);
  }
  footer {
    display: flex;
    align-items: flex-end;
    justify-content: flex-end;
    height: 40px;
  }
  // table  style start
  .el-table td {
    border: none;
  }
  .el-table th,
  .el-table tr {
    background: #1c214f;
    color: #ffffff;
  }
  .el-table td,
  .el-table th.is-leaf {
    border: none;
  }
  // table 最底下线
  .el-table--border::after,
  .el-table--group::after,
  .el-table::before {
    background: #1e3675;
  }
  .tableRowClass:nth-child(even) {
    background: #1c214f;
  }
  .tableRowClass:nth-child(odd) {
    background: #111547;
  }
  // 选中时行颜色
  .el-table__body tr.current-row > td {
    background: #037fcd;
  }
  // 鼠标悬停时行颜色无固定列（即无右边操作列）
  .el-table--enable-row-hover .el-table__body tr:hover>td {
    background: #20a3f5;
  }
  // 鼠标悬停时行颜色有固定列（即有右边操作列）
  .el-table__body tr.hover-row.current-row>td, .el-table__body tr.hover-row.el-table__row--striped.current-row>td, .el-table__body tr.hover-row.el-table__row--striped>td, .el-table__body tr.hover-row>td {
    background: #20a3f5;
  }
  .el-table__fixed-right-patch {
    background: none;
  }
  .el-table--border th, .el-table__fixed-right-patch {
    border: none;
  }
  // 固定列（fiex固定列样式）
   .el-table__fixed::before, .el-table__fixed-right::before {
     background: none;
  }
 .el-table .cell {
    white-space: nowrap;   //强制不换行
   overflow: hidden; //溢出隐藏
    text-overflow: ellipsis  //替换为省略号
}
  // 表格背景颜色
  .el-table--scrollable-y .el-table__body-wrapper {
    background: #11164a;
  }
  // 表格头背景颜色
  .el-table__footer-wrapper, .el-table__header-wrapper {
    background: #11164a;
  }
  // 暂无数据时样式
  .el-table__empty-block {
    background: #11164a;
    width: 100% !important;
  }
  .el-table--fit {
    background: none;
  }
  // table  style end
  // pagination style start
  .pagination {
    color: #ffffff;
    padding: 2px 45px;
    .el-pagination__total {
      color: #ffffff;
    }
    button:disabled {
      background: none;
      color: rgba(255,255,255,0.6);
    }
    .btn-prev {
      background: none;
      color: #ffffff;
    }
    .btn-next {
      background: none;
      color: #ffffff;
    }
    .el-pagination__jump {
      color: #ffffff;
    }
    .el-dialog, .el-pager li {
      background: none;
    }
    .el-pagination__editor.el-input .el-input__inner {
      background: none;
      color: #ffffff;
    }
    .el-select .el-input .el-input__inner {
      background: none;
      color: #ffffff;
    }
  }
  // pagination style end
}
</style>
