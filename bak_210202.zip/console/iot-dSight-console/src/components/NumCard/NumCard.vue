<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-09 17:11:22
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-09 17:13:42
 * @Description: file content
-->
<template>
  <div class="num-card-div">数字卡片</div>
</template>

<script>
export default {
  name: 'NumCard'
}
</script>

<style lang="scss" scoped>
  .num-card-div {
    background-image: url('../../assets/chartbox.png');
    width: 100%;
    height: calc((100vh - 115px)/3);
    background-repeat: round;
    padding: 10px 10px 20px;
  }
</style>
