<!--
 * @Author: 张通
 * @Date: 2020-09-14 14:24:47
 * @LastEditors: 张通
 * @LastEditTime: 2020-09-25 09:00:55
 * @Description: file content
-->
<!--
Table组件使用注意事项(必须在外面写一个固定大小的盒子包裹Table组件)
1、pagination 值为true 时，分页才能够有作用，分页对应的方法才能够使用
2、组件tableData、tableHeader 为必穿参数
3、组件table title label字段为label
4、组件table value 字段为 prop
-->
<template>
  <div class="Table">
    <search :search-data="searchData" />
    <div class="button">
      <el-button @click="dialogFormVisible = true">{{ $t('Add To') }}</el-button>
    </div>
    <el-dialog title="添加" :visible.sync="dialogFormVisible" :modal-append-to-body="false">
      <div class="kuang">
        <p class="jichu">能力</p>
        <el-button class="child_button" type="primary" @click="handleAdd()">{{ $t('Add To') }}</el-button>
        <el-table
          ref="mytable"
          :data="table_data"
          style="width: 100%"
        >
          <el-table-column
            v-for="(item,index,key) in gridData"
            :key="key"
            align="center"
            :item="item"
            :index="index"
            :label="item.label"
          >
            <template slot-scope="scope">
              <el-input
                v-if=" scope.row.edit"
                v-model="scope.row[item.prop]"
                size="small"
                :placeholder="'请输入'+item.label"
              />
              <span v-if=" !scope.row.edit">{{ scope.row[item.prop] }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" align="center">
            <template slot-scope="scope">
              <!-- 全局控制的编辑 -->
              <div v-if="is_Edit&&scope.row.add==undefined" style="display: inline-block;">
                <!-- 编辑 -->
                <el-button
                  v-if="!scope.row.edit"
                  size="mini"
                  class="save_button"
                  type="primary"
                  @click="handleEdit(scope.$index, scope.row)"
                ><i class="el-icon-edit-outline" /></el-button>
                <!-- 保存 -->
                <el-button
                  v-if="scope.row.edit"
                  size="mini"
                  type="success"
                  :plain="true"
                  class="save_button"
                  @click="handleSave(scope.$index, scope.row)"
                ><i class="el-icon-finished" /></el-button>
              </div>
              <!-- 添加控制 -->
              <div v-if="scope.row.add!=undefined&&scope.row.add" style="display: inline-block;">
                <!-- 保存 -->
                <el-button
                  v-if="scope.row.edit"
                  size="mini"
                  type="success"
                  :plain="true"
                  class="save_button"
                  @click="handleSave(scope.$index, scope.row)"
                ><i class="el-icon-finished" /></el-button>
              </div>
              <!-- 全局控制删除 -->
              <el-button
                v-if="is_Delete&&scope.row.add==undefined"
                size="mini"
                :plain="true"
                type="danger"
                class="save_button"
                @click="handleDelete(scope.$index, scope.row)"
              ><i class="el-icon-delete" /></el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-dialog></div></template>

<script>
export default {
  components: {},
  props: {
    // pageSizes
    pageSizes: {
      type: Array,
      default: () => [10, 20, 40, 80]
    },
    // pageSize
    pageSize: {
      type: Number,
      default: () => 10
    },
    // 分页总数
    total: {
      type: Number,
      default: () => 0
    },
    dialogFormVisible: {
      type: Boolean,
      default: () => 'false'
    },
    // 当前页
    currentPage: {
      type: Number,
      default: () => 1
    },
    // 表格size
    tableSize: {
      type: String,
      default: () => 'small'
    },
    is_Edit: {
      type: Boolean,
      default: () => 'false'
    }, // 是否可编辑
    is_Delete: {
      type: Boolean,
      default: () => 'false'
    }, // 是否可删除
    // 是否展示分页
    pagination: {
      type: Boolean,
      default: () => true
    },
    // tableData
    dataArray: {
      type: Array,
      default: () => []
    },
    // tableHader
    gridData: {
      type: Array,
      default: () => []
    },
    // 高亮当前选中行
    highlightCurrentRow: {
      type: Boolean,
      default: () => true
    },
    cellBorderStyle: {
      type: Boolean,
      default: () => true
    },
    // 是否展示table最后列  当lastTableColumn为 true 时， slot才能起作用
    lastTableColumn: {
      type: Boolean,
      default: () => true
    },
    loading: {
      type: Boolean,
      default: () => false
    }
  },
  data() {
    return {
      page: {
        currentPageNum: this.currentPage,
        pageSizeNum: this.pageSize
      },
      form: {
        biaoshi: '',
        mingc: '',
        miaoshu: '',
        desc: ''
      }
    }
  },
  watch: {
    // space_color: function() {
    //   //监听数据变化
    //   this.$nextTick(function() {
    //     /////方法
    //     this.tableRowClassName();
    //   });
    // },
    table_data: function() {
      // 监听数据变化f
      this.$nextTick(function() {
        // ///方法
        // this.tableRowClassName();
      })
    }
  },
  mounted: function() {
    this.initEditAttribute()
    // 确保方法在页面渲染后调用
    // this.$nextTick(function() {
    //   /////方法
    //   // this.tableRowClassName();
    // });
  },
  methods: {
    // 单元格样式
    cellStyle() {
      if (!this.cellBorderStyle) return
      return {
        borderRight: '2px solid #0f1441',
        borderBottom: '2px solid #0f1441'
      }
    },
    // 每页展示的数量改变
    handleSizeChange(v) {
      this.page.pageSizeNum = v
      this.$emit('pagination-change', this.page)
    },
    // 当前页数改变
    handleCurrentChange(v) {
      this.page.currentPageNum = v
      this.$emit('pagination-change', this.page)
    },
    rowClick(newRow) {
      if (this.highlightCurrentRow) {
        this.$emit('handler-row', newRow)
      }
    },
    // 编辑
    handleEdit(index, row) {
      row.edit = true
    },
    // 删除
    handleDelete(index, row) {
      this.table_data.splice(index, 1)

      this.$message({
        message: '删除成功！',
        type: 'success'
      })
    },
    // 保存
    handleSave(index, row) {
      row.edit = false

      delete this.table_data[index].add

      this.$message({
        message: '保存成功！',
        type: 'success'
      })
    },
    handleAdd() {
      var addDataJson = {}
      for (var key in this.new_date_json) {
        if (key === 'edit') {
          delete addDataJson[key]
        } else if (key === 'add') {
          delete addDataJson[key]
        } else {
          addDataJson[key] = ''
        }
      }
      addDataJson.edit = true
      addDataJson.add = true
      this.table_data.push(addDataJson)
    },

    // 初始化编辑属性
    initEditAttribute() {
      var self = this
      var edit = self.edit
      // var dataArray = [];

      if (this.dataArray.length > 0) {
        // 添加编辑事件
        for (var index in this.dataArray) {
          this.dataArray[index]['edit'] = false
          this.table_data.push(this.dataArray[index])
        }

        if (Object.keys(this.new_date_json).length === 0) {
          // 新增时，初始化数据结构
          this.initAddDataJson(this.dataArray[0])
        }
      }
    },
    initAddDataJson(dataArray) {
      // 新增时，初始化数据结构
      var dataJson = dataArray
      var newDateJson = {}
      for (var key in dataJson) {
        if (key === 'edit') {
          newDateJson[key] = 'true'
        } else {
          newDateJson[key] = ''
        }
      }
      newDateJson['add'] = true
      this.new_date_json = newDateJson
    }

  }
}
</script>

<style lang="scss">
.headers {
  height: 100% !important;
}
.Table {
  height: 100%;
  header {
    height: calc(100% - 40px);
  }
  footer {
    display: flex;
    align-items: flex-end;
    justify-content: flex-end;
    height: 40px;
  }
  // table  style start
  .el-table td {
    border: none;
  }
  .el-table th,
  .el-table tr {
    background: #1c214f;
    color: #ffffff;
  }
  .el-table td,
  .el-table th.is-leaf {
    border: none;
  }
  // table 最底下线
  .el-table--border::after,
  .el-table--group::after,
  .el-table::before {
    background: #1e3675;
  }
  .tableRowClass:nth-child(even) {
    background: #1c214f;
  }
  .tableRowClass:nth-child(odd) {
    background: rgba(255,255,255, 0);
  }
  // 选中时行颜色
  .el-table__body tr.current-row > td {
    background: #037fcd;
  }
  // 鼠标悬停时行颜色
  .el-table--enable-row-hover .el-table__body tr:hover>td {
    background: #20a3f5;
  }
  // 表格背景颜色
  .el-table--scrollable-y .el-table__body-wrapper {
    background: #11164a;
  }
  // 表格头背景颜色
  .el-table__footer-wrapper, .el-table__header-wrapper {
    background: #11164a;
  }
  // 暂无数据时样式
  .el-table__empty-block {
    background: #11164a;
    width: 100% !important;
  }
  .el-table--fit {
    background: none;
  }
  // table  style end
  // pagination style start
  .pagination {
    color: #ffffff;
    .el-pagination__total {
      color: #ffffff;
    }
    button:disabled {
      background: none;
      color: rgba(255,255,255,0.6);
    }
    .btn-prev {
      background: none;
      color: #ffffff;
    }
    .btn-next {
      background: none;
      color: #ffffff;
    }
    .el-pagination__jump {
      color: #ffffff;
    }
    .el-dialog, .el-pager li {
      background: none;
    }
    .el-pagination__editor.el-input .el-input__inner {
      background: none;
      color: #ffffff;
    }
    .el-select .el-input .el-input__inner {
      background: none;
      color: #ffffff;
    }
  }
  // pagination style end
}
</style>
