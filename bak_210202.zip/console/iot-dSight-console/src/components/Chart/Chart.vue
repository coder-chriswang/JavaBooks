<!--
 * @Author: 刘彦宏
 * @Date: 2020-09-07 10:39:17
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-09-18 10:06:59
 * @Description: file content
-->
<template>
  <div :id="id" style="width: 100%" />
</template>

<script>
import echarts from 'echarts'
export default {
  name: 'Chart',
  props: {
    optionsData: {
      type: Object,
      default: null
    },
    id: {
      type: String,
      default: 'chart'
    },
    sideBarOpend: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      chart: null,
      theme: require('./theme.json'),
      tableHeaderArr: []
    }
  },
  watch: {
    sideBarOpend: {
      handler: function(newVal, oldVal) {
        setTimeout(() => {
          this.chart && this.chart.resize()
        }, 300)
      }
    }
  },
  mounted() {
    this.optionsData.type === 'chart' && setTimeout(() => {
      this.drawEcharts()
    }, 400)
    this.$bus.$on('resize', () => {
      this.chart && this.chart.resize()
    })
  },
  methods: {
    drawEcharts() {
      echarts.registerTheme('walden', this.theme)
      this.chart = echarts.init(document.getElementById(this.id), 'walden')
      this.chart.setOption(this.optionsData.options, true)
    },
    getTableHeaderKey() {
      this.optionsData.options.tableHeader.forEach(item => {
        this.tableHeaderArr.push(item.key)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../styles/variables.scss';
  .largeWidth {
    width: calc((100vw - #{$sideBarWidth} - 55px)/3);
    div {
      margin: 0 auto;
    }
  }
  .smallWidth {
    width: calc((100vw - #{$sideBarHideWidth} - 55px)/3);
    div {
      margin: 0 auto;
      color: #89bd0245
    }
  }
</style>
