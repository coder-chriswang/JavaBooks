<!--
 * @Author: 刘彦宏
 * @Date: 2020-08-12 16:07:08
 * @LastEditors: 刘彦宏
 * @LastEditTime: 2020-08-20 09:53:03
 * @Description: file content
-->
<template>
  <el-dropdown trigger="click" class="international" @command="handleSetLanguage">
    <div
      v-if="hideWords"
      class="iconfont icon-language"
    />
    <div
      v-else
      class="iconfont icon-language inner-span"
    >
      <span style="padding-left: 5px">{{ $t('navbar.lang') }}</span>
      <!-- <span v-if="language==='en'" style="padding-left: 10px">English</span> -->
      <i class="el-icon-caret-bottom" />
    </div>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item :disabled="language==='zh'" command="zh">
        中文
      </el-dropdown-item>
      <el-dropdown-item :disabled="language==='en'" command="en">
        English
      </el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</template>

<script>
export default {
  props: {
    hideWords: {
      type: Boolean,
      defalut: false
    }
  },
  computed: {
    language() {
      return this.$store.getters.language
    }
  },
  methods: {
    handleSetLanguage(lang) {
      this.$i18n.locale = lang
      this.$store.dispatch('app/setLanguage', lang)
      this.$message({
        message: 'Switch Language Success',
        type: 'success'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.international {
  cursor:pointer;
  .inner-span{
    font-size: 14px;
    color: #fff;
    user-select:none;
    line-height: 15px;
  }
}
</style>
