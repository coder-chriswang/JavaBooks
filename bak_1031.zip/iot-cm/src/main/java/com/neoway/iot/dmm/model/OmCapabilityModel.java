package com.neoway.iot.dmm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * <pre>
 * 描述：
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/9/22 15:35
 */
@ApiModel("业务能力对象")
public class OmCapabilityModel implements Serializable {
    @ApiModelProperty(value = "产品域")
    private String ns;

    @ApiModelProperty(value = "ci")
    private String type;

    @ApiModelProperty(value = "om")
    private String om;

    @ApiModelProperty(value = "om名称")
    private String name;

    @ApiModelProperty(value = "描述")
    private String desc;

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOm() {
        return om;
    }

    public void setOm(String om) {
        this.om = om;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
