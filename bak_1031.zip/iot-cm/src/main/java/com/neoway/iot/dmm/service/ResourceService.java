package com.neoway.iot.dmm.service;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.model.OmCapabilityModel;
import com.neoway.iot.dmm.model.ResourceStatus;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：获取om能力
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/9/22 15:33
 */
public interface ResourceService {
    /**
     * 获取对象om能力
     * @param ns
     * @param ci
     * @return
     */
    List<OmCapabilityModel> queryCapability(String ns, String ci);

    /**
     * 获取设备状态实体
     * @param instanceId
     * @return
     */
    List<ResourceStatus> queryStatus(String instanceId);

    /**
     * 查询Tag标签
     * @param ns
     * @param category
     * @return
     */
    List<Map<String, Object>> queryTag(String ns, String category);

    /**
     * 查询Tag叶子节点
     * @param targetId
     * @return
     */
    List<Map<String, Object>> queryTagLeave(String targetId);

    /**
     * 关联查询
     * @param request
     * @return
     */
    List<Map<String, Object>> queryInstance(DMMRequest request);

}
