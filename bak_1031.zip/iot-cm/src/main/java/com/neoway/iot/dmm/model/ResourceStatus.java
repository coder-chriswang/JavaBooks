package com.neoway.iot.dmm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * <pre>
 * 描述：设备状态实体
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/9/24 9:43
 */
@ApiModel("设备状态")
public class ResourceStatus implements Serializable {

    @ApiModelProperty(value = "资源id")
    private String instanceId;

    @ApiModelProperty(value = "指标")
    private String metric;

    @ApiModelProperty(value = "指标名称")
    private String metric_name;

    @ApiModelProperty(value = "指标单位")
    private String metric_unit;

    @ApiModelProperty(value = "指标值" )
    private Float metric_value;

    @ApiModelProperty(value = "更新时间")
    private int lt;

    public Float getMetric_value() {
        return metric_value;
    }

    public void setMetric_value(Float metric_value) {
        this.metric_value = metric_value;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public String getMetric_name() {
        return metric_name;
    }

    public void setMetric_name(String metric_name) {
        this.metric_name = metric_name;
    }

    public String getMetric_unit() {
        return metric_unit;
    }

    public void setMetric_unit(String metric_unit) {
        this.metric_unit = metric_unit;
    }

    public int getLt() {
        return lt;
    }

    public void setLt(int lt) {
        this.lt = lt;
    }
}
