package com.neoway.iot.dmm.handler;

import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @desc: 元数据管理
 * @author: 20200312686
 * @date: 2020/7/21 10:59
 */
public class MetaHandler {
    private DMRunner runner;
    public MetaHandler(){
        this.runner=DMRunner.getInstance();
    }

    private void filter(DMMetaCI metaCI){
        List<DMMetaAttr> filterAttrs=new ArrayList<>();
        List<DMMetaAttr> rmMetaAttr=metaCI.getMetaAttrByGroup(DMMetaEnum.MetaAttrGroupEnum.Rm);
        List<DMMetaAttr> bmMetaAttr=metaCI.getMetaAttrByGroup(DMMetaEnum.MetaAttrGroupEnum.None);
        filterAttrs.addAll(rmMetaAttr);
        filterAttrs.addAll(bmMetaAttr);
        metaCI.setAttrs(filterAttrs);
    }
    /**
     * @desc 查询指定CI元数据
     * @param ns 产品域
     * @param ci ci对象
     * @return
     */
    public DMMetaCI getMetaCI(String ns, String category,String ci){
        if(StringUtils.isEmpty(ns)
                || StringUtils.isEmpty(ci)
                || StringUtils.isEmpty(category)){
            return null;
        }
        DMMetaCI metaCI= runner.getMetaCI(ns, category,ci);
        this.filter(metaCI);
        return metaCI;
    }

    /**
     * @desc 查询指定CI元数据并按sort排序
     * @param ns 产品域
     * @param ci ci对象
     * @return
     */
    public DMMetaCI getMetaCIBySort(String ns, String category,String ci){
        if(StringUtils.isEmpty(ns)
                || StringUtils.isEmpty(ci)
                || StringUtils.isEmpty(category)){
            return null;
        }
        DMMetaCI metaCi = runner.getMetaCI(ns, category, ci);
        List<DMMetaAction> actions = runner.getMetaCI(ns, category, ci).getActions();
        if (CollectionUtils.isEmpty(actions)) {
            return metaCi;
        }
        actions.sort(Comparator.comparing(DMMetaAction::getSort));
        metaCi.setActions(actions);
        this.filter(metaCi);
        return metaCi;
    }

    /**
     * @desc 查询指定条件的元数据
     * @param condition
     * @return
     */
    public List<DMMetaCI> queryMetaCI(DMMetaCI condition) {
        List<DMMetaCI> values=runner.queryMetaCi(condition);
        if(CollectionUtils.isNotEmpty(values)){
            for(DMMetaCI metaCI:values){
                this.filter(metaCI);
            }
        }
        return values;
    }
}
