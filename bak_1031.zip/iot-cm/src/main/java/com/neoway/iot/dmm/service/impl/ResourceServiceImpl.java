package com.neoway.iot.dmm.service.impl;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.api.MetaController;
import com.neoway.iot.dmm.common.Utils;
import com.neoway.iot.dmm.handler.filter.DmmReqFilter;
import com.neoway.iot.dmm.handler.filter.DmmReqValidateFilter;
import com.neoway.iot.dmm.model.OmCapabilityModel;
import com.neoway.iot.dmm.model.ResourceStatus;
import com.neoway.iot.dmm.service.ResourceService;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：实现类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/9/22 15:37
 */
@Service
public class ResourceServiceImpl implements ResourceService {

    private static final String DML_TAG_QUERY = "SELECT * FROM CM_B_TAG WHERE 1=1";
    private static final String DML_TAG_LEAVE_QUERY = "SELECT el FROM CM_B_TAG WHERE 1=1 AND tagid = ?";
    private static final String DML_CI_INSTANCE_RELATIONAL_QUERY = "SELECT * FROM URM_D_INSTANCE INSTANCE LEFT JOIN {0} A ON INSTANCE.instanceid = A.instanceid WHERE 1=1 {1}";
    private static final Logger LOG = LoggerFactory.getLogger(MetaController.class);
    private static final String DML_CI_CAPABILITY_QUERY = "SELECT * FROM CM_B_OMCAPABILITY WHERE NS=? AND TYPE=?";
    private static final String DML_CI_STATUS_QUERY = "SELECT * FROM CM_B_STATUS WHERE INSTANCEID=?";
    private DMRunner runner=DMRunner.getInstance();
    private List<DmmReqFilter> reqFilters=new ArrayList<>();
    @Override
    public List<OmCapabilityModel> queryCapability(String ns, String ci) {
        try {
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns, Utils.R_CM));
            Object[] ciParams={ns,ci};
            List<OmCapabilityModel> omCapabilityModelList = runner.query(DML_CI_CAPABILITY_QUERY,new BeanListHandler<>(OmCapabilityModel.class),ciParams);
            return omCapabilityModelList;
        } catch (Exception e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException("查询CI业务能力出错:" + e.getMessage());
        }
    }

    @Override
    public List<ResourceStatus> queryStatus(String instanceId) {
        try {
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource("ies",Utils.R_CM));
            Object[] ciParams={instanceId};
            List<ResourceStatus> deviceStatus= runner.query(DML_CI_STATUS_QUERY,new BeanListHandler<>(ResourceStatus.class),ciParams);
            return deviceStatus;
        } catch (Exception e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException("查询设备状态出错:" + e.getMessage());
        }
    }

    @Override
    public List<Map<String, Object>> queryTag(String ns, String category) {
        List<Map<String, Object>> mapList = new ArrayList<>();
        try {
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns,category));
            List<Map<String,Object>> values = runner.query(DML_TAG_QUERY,new MapListHandler());
            if (CollectionUtils.isNotEmpty(values)) {
                int i = 0;
                for (Map<String, Object> map : values) {
                    map.put("ci", "Instance");
                    map.put("ns", Utils.R_PRODUCT);
                    map.put("category", Utils.R_CATEGORY);
                    map.put("id", i++);
                    map.put("label", map.get("name"));
                }
            }
            Map<String, Object> result = new HashMap<>();
            result.put("name", "全网");
            result.put("ci", "Instance");
            result.put("ns", Utils.R_PRODUCT);
            result.put("category", Utils.R_CATEGORY);
            result.put("id", "Instance");
            result.put("label", "全网");
            result.put("children", values);
            mapList.add(result);
        } catch (SQLException e) {
            LOG.error("查询Tag标签有误");
        }
        return mapList;
    }

    @Override
    public List<Map<String, Object>> queryTagLeave(String targetId) {
        try {
            String ns = Utils.R_PRODUCT;
            String category = Utils.R_CM;
            QueryRunner runnerDb = new QueryRunner(DMPool.getInstance().getNsDataSource(ns,category));
            List<Object> list  = runnerDb.query(DML_TAG_LEAVE_QUERY, new ColumnListHandler(), targetId);
            List<Map<String,Object>> results=runner.executeSQL(String.valueOf(list.get(0)));
            if (CollectionUtils.isNotEmpty(results)) {
                int i = 0;
                for (Map<String, Object> map : results) {
                    map.put("ns", Utils.R_PRODUCT);
                    map.put("category", Utils.R_CATEGORY);
                    map.put("id", i++);
                    map.put("label", map.get("name"));
                }
            }
            return results;
        } catch (SQLException e) {
            LOG.error("查询Tag叶子节点有误");
        }
        return null;
    }

    @Override
    public List<Map<String, Object>> queryInstance(DMMRequest request) {
        List<Map<String, Object>> mapList = new ArrayList<>();
        try {
            reqFilters.add(new DmmReqValidateFilter());
            for(DmmReqFilter filter:reqFilters){
                filter.filter(request);
            }
            String ns = request.getNs();
            String category = request.getCategory();
            String ci = request.getCi();
            DMMetaCI metaCI=runner.getMetaCI(ns, category,ci);
            Object data=request.getData();
            Map<String,Object> input=(Map<String,Object>)data;
            DMDataPoint point=this.convert(input, metaCI);
            String where = point.buildQueryCondition();
            String[] tables = metaCI.buildTable();
            Object[] queryParams=point.buildParams();
            String sql = MessageFormat.format(DML_CI_INSTANCE_RELATIONAL_QUERY, tables[0], where);
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns,category));
            mapList = runner.query(sql, new MapListHandler(), queryParams);
        } catch (Exception e) {
            LOG.error("关联查询异常");
        }
        return mapList;
    }

    private DMDataPoint convert(Map<String,Object> datas, DMMetaCI metaCI){
        DMDataPoint point=DMDataPoint.builder(metaCI);
        point.buildColumns(datas);
        return point;
    }
}
