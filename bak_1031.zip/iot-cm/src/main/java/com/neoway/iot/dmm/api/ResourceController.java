package com.neoway.iot.dmm.api;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.HttpResult;
import com.neoway.iot.dmm.common.Utils;
import com.neoway.iot.dmm.model.OmCapabilityModel;
import com.neoway.iot.dmm.model.ResourceStatus;
import com.neoway.iot.dmm.service.ResourceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：获取om能力
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/9/22 15:17
 */
@RestController
@RequestMapping("/v1/resource")
@Api(tags = "资源查询")
public class ResourceController {
    private static final Logger LOG = LoggerFactory.getLogger(ResourceController.class);

    @Autowired
    ResourceService resourceService;

    @ApiOperation("查询业务能力")
    @GetMapping("/om/{ns}/{ci}")
    public HttpResult<List<OmCapabilityModel>> queryCapability(@PathVariable("ns") String ns, @PathVariable("ci") String ci) {
        try {
            return HttpResult.returnSuccess(resourceService.queryCapability(ns,ci));
        } catch (Exception e) {
            LOG.error("查询om能力失败！", e);
            return HttpResult.returnFail("查询om能力失败！");
        }
    }

    @ApiOperation("查询设备状态")
    @GetMapping("/status/{instanceId}")
    public HttpResult<List<ResourceStatus>> queryStatus(@PathVariable("instanceId") String instanceId) {
        try {
            return HttpResult.returnSuccess(resourceService.queryStatus(instanceId));
        } catch (Exception e) {
            LOG.error("查询设备状态失败！", e);
            return HttpResult.returnFail("查询设备状态失败！");
        }
    }

    @ApiOperation("查询Tag标签")
    @GetMapping("/tag")
    public HttpResult<List<Map<String, Object>>> queryCmTag(String targetId) {
        try {
            if (StringUtils.isEmpty(targetId)) {
                return HttpResult.returnSuccess(resourceService.queryTag(Utils.R_PRODUCT, Utils.R_CM));
            } else {
                return HttpResult.returnSuccess(resourceService.queryTagLeave(targetId));
            }
        } catch (Exception e) {
            return HttpResult.returnFail("查询Tag标签异常");
        }
    }

    @ApiOperation("关联查询实例数据")
    @PostMapping("/instance")
    public HttpResult<List<Map<String, Object>>> queryInstanceInfo(@RequestBody DMMRequest request) {
        try {
            return HttpResult.returnSuccess(resourceService.queryInstance(request));
        } catch (Exception e) {
            return HttpResult.returnFail("关联查询实例数据异常");
        }
    }
}
