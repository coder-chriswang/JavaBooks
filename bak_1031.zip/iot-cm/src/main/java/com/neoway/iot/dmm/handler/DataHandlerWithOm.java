package com.neoway.iot.dmm.handler;

import cn.hutool.core.date.DateTime;
import com.google.common.collect.Maps;
import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.data.PageInfo;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * @desc: DataOmExecutor
 * @author: 20200312686
 * @date: 2020/7/27 17:04
 */
public class DataHandlerWithOm {
    private static final String ACTION_ADD="Add";
    private static final String ACTION_UPDATE="Update";
    private static final String ACTION_QUERY="Query";
    private static final String ACTION_GET="Get";
    private static final String ACTION_DELETE="Delete";
    private DMRunner runner;
    private DMMetaCI metaCI;
    private DMMRequest req;
    public DataHandlerWithOm(DMMetaCI metaCI,DMMRequest req){
        runner=DMRunner.getInstance();
        this.metaCI=metaCI;
        this.req=req;
    }
    public DMMResponse execute(){
        DMMResponse response=new DMMResponse();
        if(null == metaCI || null == req){
            response.setCode(DMMResponse.NOK);
            response.setMsg("参数错误");
            return response;
        }
        DMMetaAction action=metaCI.buildAssignAction(req.getAction());
        Object data=req.getData();
        if(data instanceof List && ACTION_ADD.equalsIgnoreCase(action.getId())){
            List<Map<String,Object>> inputs=(List<Map<String,Object>>)data;
            List<DMDataPoint> points=this.convert(inputs);
            runner.write(points);
            return response;
        }
        Map<String,Object> input=(Map<String,Object>)data;
        DMDataPoint point=this.convert(input);
        if(ACTION_UPDATE.equalsIgnoreCase(action.getId())){
            runner.write(point);
        }else if(ACTION_GET.equalsIgnoreCase(action.getId())){
            DMDataPoint result=runner.get(point);
            if (null == result) {
                response.setData(null);
            } else {
                response.setData(result.buildMapValue());
            }
        }else if(ACTION_QUERY.equalsIgnoreCase(action.getId())){
            if (req.getPageNum() != null && req.getPageSize() != null) {
                PageInfo<DMDataPoint> pageInfo = runner.pageList(point);
                PageInfo<Map<String, String>> pageInfo1 = new PageInfo<>();
                List<Map<String,Object>> datas=new ArrayList<>();
                if (pageInfo != null) {
                    for(DMDataPoint pv:pageInfo.getList()){
                        datas.add(pv.buildMapValue());
                    }
                    List<Map<String,String>> resultData=new ArrayList<>();
                    for (Map<String, Object> map : datas) {
                        Set<Map.Entry<String, Object>> entries = map.entrySet();
                        Map<String, String> result = Maps.newHashMap();
                        for (Map.Entry<String,Object> entry : entries) {
                            if (entry.getValue() == null) {
                                result.put(entry.getKey(), "");
                            } else {
                                result.put(entry.getKey(), String.valueOf(entry.getValue()));
                            }
                        }
                        convertTimeForm(result);
                        resultData.add(result);
                    }
                    pageInfo1.setTotal(pageInfo.getTotal());
                    pageInfo1.setPageNum(req.getPageNum());
                    pageInfo1.setPageSize(req.getPageSize());
                    pageInfo1.setList(resultData);
                    response.setData(pageInfo1);
                }
            } else {
                List<DMDataPoint> results=runner.list(point);
                List<Map<String,Object>> datas=new ArrayList<>();
                if(CollectionUtils.isNotEmpty(results)){
                    for(DMDataPoint pv:results){
                        datas.add(pv.buildMapValue());
                    }
                    response.setData(datas);
                }
            }

        }else if(ACTION_DELETE.equalsIgnoreCase(action.getId())){
            runner.delete(point);
        }else{
            response=new DataHandlerWithOmSpecial(this.metaCI,this.req).execute();
        }
        return response;
    }

    private void convertTimeForm(Map<String, String> result) {
        if (result.containsKey("lt") && (StringUtils.isNotEmpty(result.get("lt")))) {
            String time = DateTime.of(Long.valueOf(result.get("lt")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("lt", time);
        }
        if (result.containsKey("productiondate") && (StringUtils.isNotEmpty(result.get("productiondate")))) {
            String time = DateTime.of(Long.valueOf(result.get("productiondate")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("productiondate", time);
        }
        if (result.containsKey("production_date") && (StringUtils.isNotEmpty(result.get("production_date")))) {
            String time = DateTime.of(Long.valueOf(result.get("production_date")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("production_date", time);
        }
        if (result.containsKey("install_date") && (StringUtils.isNotEmpty(result.get("install_date")))) {
            String time = DateTime.of(Long.valueOf(result.get("install_date")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("install_date", time);
        }
        if (result.containsKey("create_time") && (StringUtils.isNotEmpty(result.get("create_time")))) {
            String time = DateTime.of(Long.valueOf(result.get("create_time")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("create_time", time);
        }
        if (result.containsKey("event_time") && (StringUtils.isNotEmpty(result.get("event_time")))) {
            String time = DateTime.of(Long.valueOf(result.get("event_time")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("event_time", time);
        }
        if (result.containsKey("rt") && (StringUtils.isNotEmpty(result.get("rt")))) {
            String time = DateTime.of(Long.valueOf(result.get("rt")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("rt", time);
        }
        if (result.containsKey("at") && (StringUtils.isNotEmpty(result.get("at")))) {
            String time = DateTime.of(Long.valueOf(result.get("at")) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            result.put("at", time);
        }
    }

    /**
     * @desc 参数转换
     * @param datas
     * @return
     */
    private DMDataPoint convert(Map<String,Object> datas){
        DMDataPoint point=DMDataPoint.builder(this.metaCI);
        point.buildColumns(datas);
        return point;
    }

    /**
     * @desc 参数转换
     * @param datas
     * @return
     */
    private List<DMDataPoint> convert(List<Map<String,Object>> datas){
        List<DMDataPoint> points=new ArrayList<>();
        for(Map<String,Object> data:datas){
            DMDataPoint point=this.convert(data);
            points.add(point);
        }
        return points;
    }
}
