package com.neoway.iot.bi.model.chart;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("Chart图表查询参数")
public class QueryChartListParam {

    @ApiModelProperty("名称，支持模糊查询")
    private String name;

    @ApiModelProperty("图表类型")
    private String type;

    @ApiModelProperty("当前页，从1开始，传0代表去全部")
    private Integer pageNum;

    @ApiModelProperty("页行数")
    private Integer pageSize;

    @JsonIgnore
    public Integer getOffset() {
        if (pageNum < 0) {
            pageNum = 0;
        }
        return (pageNum - 1) * pageSize;
    }
}
