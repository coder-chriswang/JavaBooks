package com.neoway.iot.bi.common.param;

import lombok.Data;

@Data
public class SqlTemplateRespParam {

	/**
	 * 执行状态  Success-成功  Fail-失败
	 */
	private String status;
}
