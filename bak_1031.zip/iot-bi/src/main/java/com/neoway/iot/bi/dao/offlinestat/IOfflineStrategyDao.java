package com.neoway.iot.bi.dao.offlinestat;

import com.neoway.iot.bi.common.dto.OfflineStrategyDTO;
import com.neoway.iot.bi.common.vo.offlinestrategy.*;
import com.neoway.iot.bi.domain.offlinestat.OfflineStrategy;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IOfflineStrategyDao {

	int insert(@Param("offlineStrategy") OfflineStrategy offlineStrategy);

	int updateBySelective(@Param("offlineStrategy") OfflineStrategy offlineStrategy);

	int delete(OfflineStrategy offlineStrategy);

	OfflineStrategyDTO selectOne(QueryOfflineStrategyVO queryOfflineStrategyVO);

	List<OfflineStrategyDTO> selectList(ListOfflineStrategyVO listOfflineStrategyVO);
}
