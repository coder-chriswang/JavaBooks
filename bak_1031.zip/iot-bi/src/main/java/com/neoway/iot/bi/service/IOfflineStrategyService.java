package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.dto.OfflineStrategyDTO;
import com.neoway.iot.bi.common.vo.offlinestrategy.*;

import java.util.List;

/**
 * 离线统计相关接口
 */
public interface IOfflineStrategyService {

	/**
	 * 添加离线统计策略
	 * @param addOfflineStrategyVO
	 * @return
	 */
	int add(AddOfflineStrategyVO addOfflineStrategyVO);

	/**
	 * 修改离线统计策略
	 * @param editOfflineStrategyVO
	 * @return
	 */
	int edit(EditOfflineStrategyVO editOfflineStrategyVO);

	/**
	 * 删除离线统计策略
	 * @param metric
	 * @return
	 */
	int del(String metric);

	/**
	 * 离线统计策略查询
	 * @param metric
	 * @return
	 */
	OfflineStrategyDTO get(String metric);

	/**
	 * 离线统计策略列表查询
	 * @param listOfflineStrategyVO
	 * @return
	 */
	List<OfflineStrategyDTO> list(ListOfflineStrategyVO listOfflineStrategyVO);

}
