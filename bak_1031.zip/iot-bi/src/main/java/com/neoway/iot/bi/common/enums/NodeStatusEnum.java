package com.neoway.iot.bi.common.enums;

/**
 * 任务节点在线状态
 */
public enum NodeStatusEnum {

    ONLINE("Online", "在线"),

    OFFLINE("Offline", "下线"),

    ;

    public String code;
    public String description;

    NodeStatusEnum (String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode () {
        return code;
    }

    public String getDescription () {
        return description;
    }

    public static NodeStatusEnum getEnumByCode(String code) {
        if (null == code || "".equals(code)) {
            return null;
        }

        NodeStatusEnum responseCode;

        for (int i = 0; i < NodeStatusEnum.values().length; i++) {
            responseCode = NodeStatusEnum.values()[i];
            if (responseCode.code.equals(code)) {
                return responseCode;
            }
        }
        return null;
    }

    public static boolean contains(String code) {
        NodeStatusEnum aggType = NodeStatusEnum.getEnumByCode(code);
        if (aggType == null) {
            return false;
        } else {
            return true;
        }
    }
}
