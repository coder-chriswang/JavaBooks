package com.neoway.iot.bi.task.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.cron.pattern.CronPattern;
import cn.hutool.cron.pattern.CronPatternUtil;
import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.dto.GWRequest;
import com.neoway.iot.bi.common.dto.OfflineStrategyDTO;
import com.neoway.iot.bi.common.dto.OfflineTaskExecuteDTO;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.common.enums.OfflineStatTaskCronEnum;
import com.neoway.iot.bi.common.enums.OfflineStatTaskStatusEnum;
import com.neoway.iot.bi.common.param.SqlTemplateReqParam;
import com.neoway.iot.bi.common.vo.offlinestrategy.ListOfflineStrategyVO;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.domain.node.Node;
import com.neoway.iot.bi.domain.offlinestat.OfflineTask;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.service.IOfflineStrategyService;
import com.neoway.iot.bi.service.IOfflineTaskService;
import com.neoway.iot.bi.util.CommonUtil;
import com.neoway.iot.bi.util.IDWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
public class OfflineStatTaskService {

	@Resource
	private IOfflineStrategyService offlineStrategyService;

	@Resource
	private INodeService nodeService;

	@Resource
	private IOfflineTaskService offlineTaskService;

	@Resource
	private Cache guavaCache;

	@Resource
	private ThreadPoolExecutor threadPoolExecutor;

	@Bean
	private ThreadPoolExecutor threadPoolExecutor() {
		return new ThreadPoolExecutor(5, 30, 10, TimeUnit.SECONDS, new ArrayBlockingQueue<>(20));
	}

	/**
	 * 任务分配
	 */
	public void assignTask() {
		log.info("============开始执行任务分配(每分钟58秒执行)============");
		//查询当前离线统计策略是否有未完成任务，有则跳过，无则添加任务和分配节点
		List<OfflineStrategyDTO> list = offlineStrategyService.list(null);
		AtomicReference<OfflineTask> offlineTask = new AtomicReference<>();
		Integer lt = Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"))));
		Date now = new Date();
		Node node = new Node();
		node.setStatus(NodeStatusEnum.ONLINE.getCode());
		List<Node> nodeList = nodeService.getList(node);
		Integer nodeIndex = 0;
		Integer nodeSize = nodeList.size();
		//添加任务、分配节点
		if (StringUtils.isEmpty(guavaCache.getIfPresent("ip"))) {
			//有可能数据库中数据被删。。
			nodeService.add();
		}
		String ip = guavaCache.getIfPresent("ip").toString();
		Long nid = null;
		//获取本节点索引
		for (int i = 0; i < nodeSize; i++) {
			if (ip.equals(nodeList.get(i).getIp())) {
				nodeIndex = i;
				nid = nodeList.get(i).getNid();
			}
		}
		Integer finalNodeIndex = nodeIndex;
		List<OfflineStrategyDTO> offlineStrategyDTOS1 = new ArrayList<>();
		list.forEach(offlineStrategyDTO -> {
			//如果hash后与本节点索引相同，则将该策略加入本节点运行
			if (CommonUtil.guavaHash(offlineStrategyDTO.getMetric(), nodeSize).equals(finalNodeIndex)) {
				offlineStrategyDTOS1.add(offlineStrategyDTO);
			}
		});
		Long finalNid = nid;
		offlineStrategyDTOS1.forEach(offlineStrategyDTO -> {
			offlineTask.set(new OfflineTask());
			offlineTask.get().setMetric(offlineStrategyDTO.getMetric());
			OfflineTask offlineTask1 = offlineTaskService.getLastOne(offlineTask.get());
			if (StringUtils.isEmpty(offlineTask1) || OfflineStatTaskStatusEnum.SUCCESS.getCode().equals(offlineTask1.getStatus())
					|| OfflineStatTaskStatusEnum.FAIL.getCode().equals(offlineTask1.getStatus())) {
				//分配任务
				offlineTask.get().setId(IDWorker.id.nextId());
				BeanUtil.copyProperties(offlineStrategyDTO, offlineTask.get());
				offlineTask.get().setStatus(OfflineStatTaskStatusEnum.RUNNABLE.getCode());
				offlineTask.get().setNodeid(finalNid);
				offlineTask.get().setLt(lt);
				CronPattern cronPattern = new CronPattern(OfflineStatTaskCronEnum.getEnumByCode(offlineStrategyDTO.getPolicy()).getCron());
				Integer st = Integer.valueOf(String.valueOf(CronPatternUtil.nextDateAfter(cronPattern, now, true).getTime() / 1000));
				offlineTask.get().setSt(st);
				offlineTaskService.add(offlineTask.get());
			} else {
				log.info("当前已存在未完成任务");
			}
		});
		log.info("============结束执行任务分配(每分钟58秒执行)============");
	}

	/**
	 * 执行离线统计任务
	 */
	public void executeTask() {
		log.info("============开始执行离线统计任务(每小时)============");
		//查询出待执行的任务列表，遍历执行
		OfflineTask offlineTask = new OfflineTask();
		offlineTask.setStatus(OfflineStatTaskStatusEnum.RUNNABLE.getCode());
		offlineTask.setSt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
		List<OfflineTaskExecuteDTO> list = offlineTaskService.getTimeUpTaskList(offlineTask);
		AtomicReference<GWRequest> gwRequest = new AtomicReference<>();
		list.forEach(offlineTaskExecuteDTO -> {
			threadPoolExecutor.submit(() -> {
				offlineTaskExecuteDTO.getPolicy();
				offlineTaskExecuteDTO.setStatus(OfflineStatTaskStatusEnum.RUNNING.getCode());
				offlineTaskExecuteDTO.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
				OfflineTask offlineTask2 = new OfflineTask();
				BeanUtil.copyProperties(offlineTaskExecuteDTO, offlineTask2);
				offlineTaskService.update(offlineTask2);
				gwRequest.set(new GWRequest());
				Map<String, Object> body = buildBody(offlineTaskExecuteDTO.getPolicy());
				Map<String, Object> header = new HashMap<>();
				header.put("templateid", offlineTaskExecuteDTO.getAlgorithm());
				gwRequest.get().setBody(body);
				gwRequest.get().setHeader(header);
				Boolean result = offlineTaskService.executeCommandAsyn(gwRequest.get());
				if (result) {
					offlineTaskExecuteDTO.setStatus(OfflineStatTaskStatusEnum.SUCCESS.getCode());
				} else {
					offlineTaskExecuteDTO.setStatus(OfflineStatTaskStatusEnum.FAIL.getCode());
				}
				offlineTaskExecuteDTO.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
				BeanUtil.copyProperties(offlineTaskExecuteDTO, offlineTask2);
				offlineTaskService.update(offlineTask2);
			});
		});
		log.info("===========结束执行离线统计任务(每小时)============");
	}

	/**
	 * 构建body
	 * @param policy
	 * @return
	 */
	private Map<String, Object> buildBody(String policy) {
		Map<String, Object> body = new HashMap<>();
		long st = 0;
		long et = 0;
		switch (policy) {
			case "h":
				st = DateUtil.offsetHour(Date.from(LocalDateTime.now().withMinute(0).withSecond(0).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				et = DateUtil.offsetHour(Date.from(LocalDateTime.now().withMinute(59).withSecond(59).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				break;
			case "d":
				st = DateUtil.offsetDay(Date.from(LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				et = DateUtil.offsetDay(Date.from(LocalDateTime.now().withHour(23).withMinute(59).withSecond(59).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				break;
			case "m":
				Date date = new Date();
				st = DateUtil.offsetMonth(DateUtil.beginOfMonth(date), -1).toTimestamp().getTime() / 1000;
				et = DateUtil.endOfMonth(DateUtil.offsetMonth(new Date(), -1)).toTimestamp().getTime() / 1000;
				break;
			default:
				break;
		}
		body.put("st", st + "");
		body.put("et", et + "");
		return body;
	}

	/**
	 * 清除大于30天的离线统计任务记录
	 */
	public void clearTask() {
		Del30DayBeforeData del30DayBeforeData = new Del30DayBeforeData();
		del30DayBeforeData.setSt(DateUtil.offsetDay(new Date(), -30).toTimestamp().getTime() / 1000);
		offlineTaskService.del30DayBeforeData(del30DayBeforeData);
	}
}
