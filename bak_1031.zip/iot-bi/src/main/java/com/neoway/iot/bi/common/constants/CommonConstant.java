package com.neoway.iot.bi.common.constants;

import cn.hutool.core.net.NetUtil;

public interface CommonConstant {

	String IP = NetUtil.getLocalhost().getHostAddress();

}
