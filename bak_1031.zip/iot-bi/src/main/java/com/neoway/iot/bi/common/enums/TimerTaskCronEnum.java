package com.neoway.iot.bi.common.enums;

public enum TimerTaskCronEnum {

	NODE_STATUS_UPDATE("0 0/1 * * * ?", "nodeStatusUpdate", "节点更新状态"),

	NODE_HEALTH_CHECK("0 0/3 * * * ?", "nodeHealthCheck","节点健康检测"),

	OFFLINE_TASK_ASSIGN("58 * * * * ?", "offlineTaskAssign", "离线统计任务分配"),

	OFFLINE_TASK_EXECUTE("0 0/5 * * * ?", "offlineTaskExecute", "离线统计任务执行"),

	OFFLINE_TASK_CLEAR("0 0 0 * * ?", "offlineTaskClear", "清除大于30天的离线统计任务")

	;

	public String cron;
	private String code;
	public String description;

	TimerTaskCronEnum (String cron, String code, String description) {
		this.cron = cron;
		this.code = code;
		this.description = description;
	}

	public String getCode () {
		return code;
	}

	public String getCron () {
		return cron;
	}

	public String getDescription () {
		return description;
	}

	public static TimerTaskCronEnum getEnumByCron(String cron) {
		if (null == cron || "".equals(cron)) {
			return null;
		}
		TimerTaskCronEnum responseCode;
		for (int i = 0; i < TimerTaskCronEnum.values().length; i++) {
			responseCode = TimerTaskCronEnum.values()[i];
			if (responseCode.cron.equals(cron)) {
				return responseCode;
			}
		}
		return null;
	}

	public static TimerTaskCronEnum getEnumByCode(String code) {
		if (null == code || "".equals(code)) {
			return null;
		}
		TimerTaskCronEnum responseCode;
		for (int i = 0; i < TimerTaskCronEnum.values().length; i++) {
			responseCode = TimerTaskCronEnum.values()[i];
			if (responseCode.code.equals(code)) {
				return responseCode;
			}
		}
		return null;
	}

	public static boolean contains(String cron) {
		TimerTaskCronEnum timerTaskCronEnum = TimerTaskCronEnum.getEnumByCode(cron);
		if (timerTaskCronEnum == null) {
			return false;
		} else {
			return true;
		}
	}
}
