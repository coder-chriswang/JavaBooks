package com.neoway.iot.bi.task;

import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.common.enums.TimerTaskCronEnum;
import com.neoway.iot.bi.task.service.NodeTimeTaskService;
import com.neoway.iot.bi.task.service.OfflineStatTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ScheduledFuture;

@Component
@Slf4j
public class TimerTaskService {
	

    @Resource
    private ThreadPoolTaskScheduler threadPoolTaskScheduler;

    @Resource
    private NodeTimeTaskService nodeTimeTaskService;

    @Resource
    private OfflineStatTaskService offlineStatTaskService;

	@Resource
	private Cache guavaCache;

    private List<ScheduledFuture<?>> robotFutureList=new CopyOnWriteArrayList<>();
 
    @Bean
    public ThreadPoolTaskScheduler threadPoolTaskScheduler() {
        return new ThreadPoolTaskScheduler();
    }


	public void startTimerTask() {
	    List<TimerTaskCronEnum> timerTaskCronEnums = new ArrayList<>();
	    timerTaskCronEnums.add(TimerTaskCronEnum.NODE_STATUS_UPDATE);
	    timerTaskCronEnums.add(TimerTaskCronEnum.NODE_HEALTH_CHECK);
	    timerTaskCronEnums.add(TimerTaskCronEnum.OFFLINE_TASK_ASSIGN);
	    timerTaskCronEnums.add(TimerTaskCronEnum.OFFLINE_TASK_EXECUTE);
	    timerTaskCronEnums.add(TimerTaskCronEnum.OFFLINE_TASK_CLEAR);
	    startTask(timerTaskCronEnums);
	}

	private void startTask (List<TimerTaskCronEnum> timerTaskCronEnums) {
		Long nid = Long.valueOf(String.valueOf(guavaCache.getIfPresent("nid")));
    	if (timerTaskCronEnums.size() > 0) {
    		for (TimerTaskCronEnum timerTaskCronEnum : timerTaskCronEnums) {
			    ScheduledFuture future = threadPoolTaskScheduler.schedule(() -> {
			    	try {
					    switch (timerTaskCronEnum) {
						    case NODE_STATUS_UPDATE:
							    nodeTimeTaskService.updateStatus(nid, NodeStatusEnum.ONLINE.getCode());
							    break;
						    case NODE_HEALTH_CHECK:
							    nodeTimeTaskService.checkNodeHealth();
							    break;
						    case OFFLINE_TASK_ASSIGN:
							    offlineStatTaskService.assignTask();
							    break;
						    case OFFLINE_TASK_EXECUTE:
							    offlineStatTaskService.executeTask();
							    break;
						    case OFFLINE_TASK_CLEAR:
						    	offlineStatTaskService.clearTask();
						    	break;
						    default:
							    break;
					    }
				    } catch (Exception ex) {
			    		log.error("start task error :{}", ex.getMessage());
				    }
			    }
			    , triggerContext -> {
				    CronTrigger trigger = new CronTrigger(timerTaskCronEnum.getCron());
				    Date nextExec = trigger.nextExecutionTime(triggerContext);
				    return nextExec;
			    });
			    robotFutureList.add(future);
		    }
    	}
    }

    /**
     * 停止定时任务
     */
    public void stopTask() {
	    //不会马上停止任务,会等任务执行完 只是执行了interrupt方法
	    robotFutureList.stream().filter(Objects::nonNull).forEach(future -> future.cancel(true));
        robotFutureList.clear();
        log.info("DynamicTask.stopTask()");
    }
 
}