package com.neoway.iot.bi.service.impl;

import com.neoway.iot.bi.common.db.DataSourceType;
import com.neoway.iot.bi.common.db.JdbcPool;
import com.neoway.iot.bi.exception.BiMysqlServiceException;
import com.neoway.iot.bi.service.IBiMysqlService;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.sql.SQLException;
import java.util.Map;

@Service
public class BiMysqlServiceImpl implements IBiMysqlService {
    private JdbcPool biMysqlPool;
//    @Value("${bi.db.mysql.uri}")
//    private String biDbUrl;
//    @Value("${bi.db.mysql.user}")
//    private String biDbUserName;
//    @Value("${bi.db.mysql.pwd}")
//    private String biDbPassword;
//    @Value("${bi.db.mysql.max_conn}")
//    private int biDbMaxConn;
//    @Value("${bi.db.mysql.min_conn}")
//    private int biDbMinConn;
//    @Value("${bi.db.mysql.conn_timeout}")
//    private int biDbConnTimeout;
//    @Value("${bi.db.mysql.idle_timeout}")
//    private int biDbIdleTimeout;

    private JdbcPool dmpMysqlPool;
//    @Value("${dmp.db.mysql.uri}")
//    private String dmpDbUrl;
//    @Value("${dmp.db.mysql.user}")
//    private String dmpDbUserName;
//    @Value("${dmp.db.mysql.pwd}")
//    private String dmpDbPassword;
//    @Value("${dmp.db.mysql.max_conn}")
//    private int dmpDbMaxConn;
//    @Value("${dmp.db.mysql.min_conn}")
//    private int dmpDbMinConn;
//    @Value("${dmp.db.mysql.conn_timeout}")
//    private int dmpDbConnTimeout;
//    @Value("${dmp.db.mysql.idle_timeout}")
//    private int dmpDbIdleTimeout;

    private JdbcPool dataMysqlPool;
//    @Value("${data.db.mysql.uri}")
//    private String dataDbUrl;
//    @Value("${data.db.mysql.user}")
//    private String dataDbUserName;
//    @Value("${data.db.mysql.pwd}")
//    private String dataDbPassword;
//    @Value("${data.db.mysql.max_conn}")
//    private int dataDbMaxConn;
//    @Value("${data.db.mysql.min_conn}")
//    private int dataDbMinConn;
//    @Value("${data.db.mysql.conn_timeout}")
//    private int dataDbConnTimeout;
//    @Value("${data.db.mysql.idle_timeout}")
//    private int dataDbIdleTimeout;

    @PostConstruct
    private void init() {
        JdbcPool.Builder builder = new JdbcPool.Builder();

//        if (StringUtils.isNotEmpty(biDbUrl)) {
//            biMysqlPool = builder.jdbcUri(biDbUrl)
//                    .jdbcUser(biDbUserName)
//                    .jdbcPwd(biDbPassword)
//                    .jdbcMaxConn(biDbMaxConn)
//                    .jdbcMinConn(biDbMinConn)
//                    .jdbcConnTimeOut(biDbConnTimeout)
//                    .jdbcIdelTimeOut(biDbIdleTimeout)
//                    .jdbcReadOnly(false)
//                    .jdbcAutoCommit(true).build();
//            biMysqlPool.start();
//        }
//
//        if (StringUtils.isNotEmpty(dataDbUrl)) {
//            dataMysqlPool = builder.jdbcUri(dataDbUrl)
//                    .jdbcUser(dataDbUserName)
//                    .jdbcPwd(dataDbPassword)
//                    .jdbcMaxConn(dataDbMaxConn)
//                    .jdbcMinConn(dataDbMinConn)
//                    .jdbcConnTimeOut(dataDbConnTimeout)
//                    .jdbcIdelTimeOut(dataDbIdleTimeout)
//                    .jdbcReadOnly(false)
//                    .jdbcAutoCommit(true).build();
//            dataMysqlPool.start();
//        }
//
//        if (StringUtils.isNotEmpty(dmpDbUrl)) {
//            dmpMysqlPool = builder.jdbcUri(dmpDbUrl)
//                    .jdbcUser(dmpDbUserName)
//                    .jdbcPwd(dmpDbPassword)
//                    .jdbcMaxConn(dmpDbMaxConn)
//                    .jdbcMinConn(dmpDbMinConn)
//                    .jdbcConnTimeOut(dmpDbConnTimeout)
//                    .jdbcIdelTimeOut(dmpDbIdleTimeout)
//                    .jdbcReadOnly(false)
//                    .jdbcAutoCommit(true).build();
//            dmpMysqlPool.start();
//        }

    }

    @PreDestroy
    private void destroy() {
        if (biMysqlPool != null) {
            biMysqlPool.close();
        }
    }

    @Override
    public QueryRunner getQueryRunner(DataSourceType type) throws BiMysqlServiceException {
        JdbcPool db = null;
        switch (type) {
            case IOT_BI:
                db = biMysqlPool;
                break;

            case IOT_DMP:
                db = dmpMysqlPool;
                break;

            case IOT_DATA:
                db = dataMysqlPool;
                break;

            default:
                db = biMysqlPool;
        }
        if (db == null) {
            throw new BiMysqlServiceException("数据源不存在");
        }
        return new QueryRunner(db.getDataSource());
    }

    @Override
    public Map<String, Object> executeQuery(DataSourceType type, String sql) throws BiMysqlServiceException {
        try {
            return getQueryRunner(type).query(sql, new MapHandler());
        } catch (SQLException e) {
            throw new BiMysqlServiceException("查询出错");
        }
    }
}
