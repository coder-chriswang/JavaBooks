package com.neoway.iot.bi.util;

import com.google.common.collect.Lists;
import org.springframework.util.CollectionUtils;

import java.util.List;

public class PageHelper {

    public static <T> BiPageModel<T> pagination(final List<T> data, final int pageSize, final int pageNum) {
        if (CollectionUtils.isEmpty(data)) {
            return new BiPageModel<>();
        }
        List<List<T>> lists = Lists.partition(data, pageSize);
        int localPageNum = pageNum;
        if (localPageNum > lists.size()) {
            localPageNum = lists.size();
        }
        return BiPageModel.build(lists.get(localPageNum - 1), pageNum, data.size(), pageSize);
    }
}
