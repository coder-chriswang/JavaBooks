package com.neoway.iot.bi.common.constants;

public interface ErrorConstant {

	String ADD_FAIL = "新增失败";

	String UPDATE_FAIL = "修改失败";

	String DEL_FAIL = "删除失败";

	String QUERY_EMPTY = "查询结果为空";

	String DATA_EXIST_ALREADY = "数据已存在";

	String OFFLINE_STRATEGY_METRIC_NOT_EXIST = "当前指标不存在对应离线统计策略";

}
