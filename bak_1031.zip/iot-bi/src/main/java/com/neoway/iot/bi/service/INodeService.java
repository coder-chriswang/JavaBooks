package com.neoway.iot.bi.service;

import com.neoway.iot.bi.domain.node.Node;

import java.util.List;

public interface INodeService {

	/**
	 * 添加任务节点
	 * @return
	 */
	int add();

	/**
	 * 修改任务节点
	 * @param node
	 * @return
	 */
	int update(Node node);

	/**
	 * 获取任务节点列表
	 * @param node
	 * @return
	 */
	List<Node> getList(Node node);

	/**
	 * 获取任务节点信息
	 * @param node
	 * @return
	 */
	Node get(Node node);

}
