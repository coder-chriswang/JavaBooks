package com.neoway.iot.bi;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.task.TimerTaskService;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;

@MapperScan("com.neoway.iot.bi.dao")
@SpringBootApplication
public class BIApplication implements CommandLineRunner {
	private static final Logger LOG = LoggerFactory.getLogger(BIApplication.class);
	@Autowired
	private Environment env;

	@Resource
	private INodeService nodeService;

	@Resource
	private TimerTaskService timerTaskService;

	public static void main(String[] args) {
		SpringApplication.run(BIApplication.class, args);
	}
	@Override
	public void run(String... strings) throws Exception {
		//自动注册节点
		nodeService.add();
		//开启定时任务
		timerTaskService.startTimerTask();
	}

	@Bean
	public RestTemplate restTemplate(){
		return new RestTemplate();
	}

	@Bean
	public Cache<String, Object> guavaCache() {
		return CacheBuilder.newBuilder().build();
	}
}
