package com.neoway.iot.bi.service.impl;

import cn.hutool.core.net.NetUtil;
import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.constants.CommonConstant;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.dao.node.INodeDao;
import com.neoway.iot.bi.domain.node.Node;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.util.IDWorker;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

@Service
public class NodeServiceImpl implements INodeService {

	@Resource
	private INodeDao nodeDao;

	@Resource
	private Cache guavaCache;

	@Override
	public int add () {
		Node node = new Node();
		String ip = NetUtil.getLocalhost().getHostAddress();
		guavaCache.put("ip", ip);
		node.setIp(ip);
		Node node1 = nodeDao.selectOne(node);
		if (!StringUtils.isEmpty(node1)) {
			guavaCache.put("nid", node1.getNid());
			node1.setStatus(NodeStatusEnum.ONLINE.getCode());
			nodeDao.updateBySelective(node1);
			return 0;
		}
		node.setNid(IDWorker.id.nextId());
		guavaCache.put("nid", node.getNid());
		node.setStatus(NodeStatusEnum.ONLINE.getCode());
		node.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
		return nodeDao.insert(node);
	}

	@Override
	public int update (Node node) {
		node.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
		return nodeDao.updateBySelective(node);
	}

	@Override
	public List<Node> getList (Node node) {
		List<Node> nodes = nodeDao.selectList(node);
		return nodes;
	}

	@Override
	public Node get (Node node) {
		Node node1 = nodeDao.selectOne(node);
		return node1;
	}

}
