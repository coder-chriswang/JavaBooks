package com.neoway.iot.bi.common.vo.offlinetask;

import lombok.Data;

@Data
public class Del30DayBeforeData {

	/**
	 * 30天前时间戳
	 */
	private Long st;
}
