package com.neoway.iot.bi.task.service;

import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.domain.node.Node;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.service.IOfflineTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

@Service
@Slf4j
public class NodeTimeTaskService {


	@Resource
	private INodeService nodeService;

	@Resource
	private IOfflineTaskService offlineTaskService;

	@Resource
	private Cache guavaCache;

	@Value("${node.health.timeout}")
	private Integer nodeHealthTimeout;

	/**
	 * 更新节点状态
	 */
	public void updateStatus(Long nid, String status) {
		log.info("============开始执行节点在线状态更新============status:{}", status);
		Node node = new Node();
		node.setNid(nid);
		node.setStatus(status);
		node.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
		nodeService.update(node);
		log.info("============结束执行节点在线状态更新============");
	}

	/**
	 * 检测节点健康状态
	 */
	public void checkNodeHealth() {
		log.info("============开始执行节点健康状态检测============");
		Long newNid = Long.valueOf(String.valueOf(guavaCache.getIfPresent("nid")));
		Integer currentLt = Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"))));
		List<Node> nodeList = nodeService.getList(null);
		nodeList.forEach(node -> {
			Integer dbLt = node.getLt();
			if (currentLt - dbLt > nodeHealthTimeout) {
				//更新改节点状态
				updateStatus(node.getNid(), NodeStatusEnum.OFFLINE.getCode());
				//节点下的任务转移,目前移至发现节点故障的节点下
				offlineTaskService.offlineTaskTransfer(node.getNid(), newNid);
			}
		});
		log.info("============结束执行节点健康状态检测============");
	}
}
