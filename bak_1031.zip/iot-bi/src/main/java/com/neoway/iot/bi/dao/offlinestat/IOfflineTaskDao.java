package com.neoway.iot.bi.dao.offlinestat;

import com.neoway.iot.bi.common.dto.OfflineTaskExecuteDTO;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.domain.offlinestat.OfflineTask;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IOfflineTaskDao {

	int insert(@Param("offlineTask") OfflineTask offlineTask);

	int updateBySelective(@Param("offlineTask") OfflineTask offlineTask);

	int delete(OfflineTask offlineTask);

	OfflineTask selectOne(OfflineTask offlineTask);

	List<OfflineTask> selectList(OfflineTask offlineTask);

	OfflineTask selectLastOne (OfflineTask offlineTask);

	List<OfflineTaskExecuteDTO> selectTimeUpTaskList(OfflineTask offlineTask);

	int del30DayBeforeDay(Del30DayBeforeData del30DayBeforeData);
}
