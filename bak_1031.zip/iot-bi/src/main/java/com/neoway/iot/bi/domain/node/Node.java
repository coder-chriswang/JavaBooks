package com.neoway.iot.bi.domain.node;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("任务节点实体")
public class Node {

	@ApiModelProperty(value = "节点id")
	private Long nid;

	@ApiModelProperty(value = "ip")
	private String ip;

	@ApiModelProperty(value = "节点状态 （在线、下线）")
	private String status;

	@ApiModelProperty(value = "更新时间")
	private Integer lt;
}
