package com.neoway.iot.bi.util;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.LocalDateTimeUtil;
import com.google.common.base.Charsets;
import com.google.common.hash.Hashing;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class CommonUtil {

	public static Integer guavaHash(String data, int partition) {
		int bucket = Hashing.consistentHash(Hashing.md5().hashString(data, Charsets.UTF_8),partition);
		return bucket;
	}


	public static void main (String[] args) {
//		LocalDateTime localDateTime = LocalDateTimeUtil.
//		System.out.println(DateUtil.offsetHour(new Date(), -1));
		Date st = Date.from(LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0).withNano(0).atZone(ZoneId.systemDefault()).toInstant());
		Date et = Date.from(LocalDateTime.now().withHour(23).withMinute(59).withSecond(59).withNano(0).atZone(ZoneId.systemDefault()).toInstant());
//		System.out.println(DateUtil.offsetHour(st, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetHour(et, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetDay(st, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetDay(et, -1).toTimestamp().getTime() / 1000);
		System.out.println(DateUtil.offsetMonth(DateUtil.beginOfMonth(new Date()), -1).toTimestamp().getTime() / 1000);
		System.out.println(DateUtil.endOfMonth(DateUtil.offsetMonth(new Date(), -1)).toTimestamp().getTime() / 1000);
		System.out.println(DateUtil.offsetDay(et, -1).toTimestamp().getTime() / 1000);
		System.out.println(DateUtil.offsetDay(new Date(), -30).toTimestamp().getTime() / 1000);
	}
}
