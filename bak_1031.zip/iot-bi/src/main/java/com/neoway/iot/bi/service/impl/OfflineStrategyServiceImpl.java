package com.neoway.iot.bi.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.neoway.iot.bi.common.constants.ErrorConstant;
import com.neoway.iot.bi.common.dto.OfflineStrategyDTO;
import com.neoway.iot.bi.common.vo.offlinestrategy.*;
import com.neoway.iot.bi.dao.offlinestat.IOfflineStrategyDao;
import com.neoway.iot.bi.dao.offlinestat.IOfflineTaskDao;
import com.neoway.iot.bi.domain.offlinestat.OfflineStrategy;
import com.neoway.iot.bi.exception.BiException;
import com.neoway.iot.bi.service.IOfflineStrategyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

@Service
@Slf4j
public class OfflineStrategyServiceImpl implements IOfflineStrategyService {

	@Resource
	private IOfflineStrategyDao offlineStrategyDao;


	@Override
	public int add (AddOfflineStrategyVO addOfflineStrategyVO) {
		OfflineStrategy offlineStrategy = new OfflineStrategy();
		BeanUtil.copyProperties(addOfflineStrategyVO, offlineStrategy);
		offlineStrategy.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
		int result = offlineStrategyDao.insert(offlineStrategy);
		if (result == 0) {
			throw new BiException(ErrorConstant.ADD_FAIL);
		}
		return result;
	}

	@Override
	public int edit (EditOfflineStrategyVO editOfflineStrategyVO) {
		OfflineStrategy offlineStrategy = new OfflineStrategy();
		BeanUtil.copyProperties(editOfflineStrategyVO, offlineStrategy);
		offlineStrategy.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
		int result = offlineStrategyDao.updateBySelective(offlineStrategy);
		if (result == 0) {
			throw new BiException(ErrorConstant.UPDATE_FAIL);
		}
		return result;
	}

	@Override
	public int del (String metric) {
		OfflineStrategy offlineStrategy = new OfflineStrategy();
		offlineStrategy.setMetric(metric);
		int result = offlineStrategyDao.delete(offlineStrategy);
		if (result == 0) {
			throw new BiException(ErrorConstant.DEL_FAIL);
		}
		return result;
	}

	@Override
	public OfflineStrategyDTO get (String metric) {
		QueryOfflineStrategyVO queryOfflineStrategyVO = new QueryOfflineStrategyVO();
		queryOfflineStrategyVO.setMetric(metric);
		OfflineStrategyDTO offlineStrategyDTO = offlineStrategyDao.selectOne(queryOfflineStrategyVO);
		if (StrUtil.isEmptyIfStr(offlineStrategyDTO)) {
			throw new BiException(ErrorConstant.QUERY_EMPTY);
		}
		return offlineStrategyDTO;
	}

	@Override
	public List<OfflineStrategyDTO> list (ListOfflineStrategyVO listOfflineStrategyVO) {
		List<OfflineStrategyDTO> offlineStrategyDTOS = offlineStrategyDao.selectList(listOfflineStrategyVO);
		return offlineStrategyDTOS;
	}

}
