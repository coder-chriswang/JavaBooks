package com.neoway.iot.bi.task;

import lombok.Data;

@Data
public class TaskInfo {

	private String cron;


}
