package com.neoway.iot.bi.common.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @desc: GWResponse
 * @author: 20200312686
 * @date: 2020/9/14 16:40
 */
@ApiModel("指令执行报文-响应结构体")
public class GWResponse {
    @ApiModelProperty("错误码")
    private String code="200";
    @ApiModelProperty("错误原因")
    private String msg="";
//    @ApiModelProperty("响应Header")
//    private GWHeader header;
    @ApiModelProperty("响应body")
    private Object data;
    private int ts;
    public GWResponse (){
        Long tsL = System.currentTimeMillis()/1000;
        this.ts=tsL.intValue();
    }
    public GWResponse (String code, String msg) {
        this.code = code;
        this.msg = msg;
        Long tsL = System.currentTimeMillis()/1000;
        this.ts=tsL.intValue();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

//    public GWHeader getHeader() {
//        return header;
//    }
//
//    public void setHeader(GWHeader header) {
//        this.header = header;
//    }

    public int getTs() {
        return ts;
    }
}
