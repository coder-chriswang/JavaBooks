package com.neoway.iot.bi.domain.chart;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.util.Date;

/**
* chart基础数据表
*/
@Data
@ApiModel("chart基础数据")
public class Chart {

    /**
     * ID
     */
    @ApiModelProperty(value = "chartid")
    private String chartid;

    /**
     * 名称
     */
    @ApiModelProperty(value = "name")
    private String name;

    /**
     * 描述
     */
    @ApiModelProperty(value = "desc")
    private String desc;

    /**
     * 统计算法
     */
    @ApiModelProperty(value = "algorithm")
    private String algorithm;

    /**
     * chart类型
     */
    @ApiModelProperty(value = "type")
    private String type;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "lt")
    private Integer lt;


}