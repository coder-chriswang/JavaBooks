package com.neoway.iot.bi.dao.node;

import com.neoway.iot.bi.domain.node.Node;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface INodeDao {

	int insert(@Param("node") Node node);

	int updateBySelective(@Param("node") Node node);

	int delete(Node node);

	Node selectOne(Node node);

	List<Node> selectList(Node node);
}
