package com.neoway.iot.bi.exception;

public class BiException extends RuntimeException {
    private static final long serialVersionUID = 1533704113405490577L;

    public BiException (String message) {
        super(message);
    }
}
