package com.neoway.iot.bi.common.enums;

public enum GwApiEnum {

	Command_Asyn("/v1/command/asyn", "指令执行-异步"),
	Command_Syn("/v1/command/syn", "指令执行-同步"),
	;

	public String url;
	public String description;

	GwApiEnum (String url, String description) {
		this.url = url;
		this.description = description;
	}

	public String getDescription () {
		return description;
	}

	public String getUrl () {
		return url;
	}

	public static GwApiEnum getEnumByCode(String url) {
		if (null == url || "".equals(url)) {
			return null;
		}

		GwApiEnum responseCode;

		for (int i = 0; i < GwApiEnum.values().length; i++) {
			responseCode = GwApiEnum.values()[i];
			if (responseCode.url.equals(url)) {
				return responseCode;
			}
		}
		return null;
	}

	public static boolean contains(String url) {
		GwApiEnum gwmApiEnum = GwApiEnum.getEnumByCode(url);
		if (gwmApiEnum == null) {
			return false;
		} else {
			return true;
		}
	}
}
