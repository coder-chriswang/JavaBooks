package com.neoway.iot.bi.service;

import java.util.Locale;

public interface II18nService {
    String getMessage(String messageCode, Locale locale);
    void clear();
}
