package com.neoway.iot.bi.service.impl;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.json.JSONUtil;
import com.neoway.iot.bi.common.dto.GWRequest;
import com.neoway.iot.bi.common.dto.GWResponse;
import com.neoway.iot.bi.common.enums.GwApiEnum;
import com.neoway.iot.bi.dao.chart.IChartDao;
import com.neoway.iot.bi.domain.BiChart;
import com.neoway.iot.bi.domain.chart.Chart;
import com.neoway.iot.bi.exception.ChartServiceException;
import com.neoway.iot.bi.model.chart.QueryChartListParam;
import com.neoway.iot.bi.service.IChartService;
import com.neoway.iot.bi.util.BiPageModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ChartServiceImpl implements IChartService {
    @Resource
    private IChartDao chartDao;

    @Resource
    private RestTemplate restTemplate;

    @Value("${iot.service.gw.host}")
    private String gwHost;

    @Override
    public BiPageModel<Chart> queryPageList(QueryChartListParam param) throws ChartServiceException {
        if (param == null) {
            throw new ChartServiceException("参数有误");
        }
        Integer count = chartDao.queryCount(param);
        if (count == null || count <= 0) {
            return BiPageModel.build(null, 1, 0, 1);
        }
        List<Chart> chartList = chartDao.queryList(param);
        return BiPageModel.build(chartList, param.getPageNum(), count, param.getPageSize());
    }

    @Override
    public BiChart getChartDetail(String chartId) throws ChartServiceException {
        if (StringUtils.isEmpty(chartId)) {
            throw new ChartServiceException("该chart不存在");
        }
        Chart c = chartDao.queryByKey(chartId);
        if (c == null) {
            throw new ChartServiceException("该chart不存在");
        }
        BiChart biChart = new BiChart();
        biChart.setChartId(c.getChartid());
        biChart.setChartName(c.getName());
        biChart.setChartDesc(c.getDesc());

        // get chart data
        biChart.setChartDs(getDummyData(c));
        return biChart;
    }

    private String getDummyData(Chart c) {
        String url = gwHost + GwApiEnum.Command_Syn.getUrl();
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
        headers.setContentType(type);
        GWRequest gwRequest = new GWRequest();
        Map<String, Object> headerMap = new HashMap<>();
        headerMap.put("templateid", c.getAlgorithm());
        gwRequest.setHeader(headerMap);
        HttpEntity<String> requestEntity = new HttpEntity<>(JSONUtil.toJsonStr(gwRequest), headers);
        ResponseEntity<String> resEntity = null;
        try {
            resEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
        } catch (Exception e) {
            log.info("exception is {}", e.getMessage());
            return null;
        }
        log.info("resEntity is {}", resEntity);
        String resultData = null;
        try {
            String result = new String(resEntity.getBody().getBytes("ISO-8859-1"), "UTF-8");
            GWResponse gwResponse = JSONUtil.toBean(result, GWResponse.class);
            resultData = String.valueOf(gwResponse.getData());
        } catch (UnsupportedEncodingException e) {
            log.info("exception is {}", e.getMessage());
            return null;
        }
        if (resultData != null) {
            return resultData;
        }
        switch (c.getType()) {
            case "Line":
                return "{\"chartType\":\"line\",\"chartTitle\":\"折线图\",\"data\":{\"legend\":{\"nameArr\":[\"图例1\",\"图例2\",\"图例3\"],\"keyArr\":[\"legend1\",\"legend2\",\"legend3\"]},\"xUnit\":\"x单位\",\"yUnit\":\"y单位\",\"xData\":[\"x轴坐标点1\",\"x轴坐标点2\",\"x轴坐标点3\",\"x轴坐标点4\",\"x轴坐标点5\"],\"yData\":{\"legend1\":[80,40,62,45,89],\"legend2\":[89,80,40,62,45],\"legend3\":[45,89,80,40,62]}}}";
            case "Gauge":
                return "{\"chartType\":\"gauge\",\"chartTitle\":\"仪表盘\",\"data\":[{\"name\":\"仪表1\",\"value\":\"14\",\"unit\":\"km/h\",\"min\":0,\"max\":220,\"splitNumber\":11}]}";
            case "Bar":
                return "{\"chartType\":\"bar\",\"chartTitle\":\"柱状图\",\"data\":{\"legend\":{\"nameArr\":[\"图例1\",\"图例2\",\"图例3\"],\"keyArr\":[\"legend1\",\"legend2\",\"legend3\"]},\"xUnit\":\"x单位\",\"yUnit\":\"y单位\",\"xData\":[\"x轴坐标点1\",\"x轴坐标点2\",\"x轴坐标点3\",\"x轴坐标点4\",\"x轴坐标点5\"],\"yData\":{\"legend1\":[80,40,62,45,89],\"legend2\":[89,80,40,62,45],\"legend3\":[45,89,80,40,62]}}}";
            case "Table":
                return "{\"chartType\":\"table\",\"chartTitle\":\"表格\",\"data\":{\"tableHeader\":[{\"name\":\"表头1\",\"id\":\"header1\"},{\"name\":\"表头2\",\"id\":\"header2\"},{\"name\":\"表头3\",\"id\":\"header3\"}],\"tableData\":{\"total\":10,\"pageSize\":10,\"pageNum\":1,\"rows\":[{\"header1\":\"第一列数据\",\"header2\":\"第二列数据\",\"header3\":\"第三列数据\"},{\"header1\":\"第一列数据\",\"header2\":\"第二列数据\",\"header3\":\"第三列数据\"},{\"header1\":\"第一列数据\",\"header2\":\"第二列数据\",\"header3\":\"第三列数据\"},{\"header1\":\"第一列数据1\",\"header2\":\"第二列数据1\",\"header3\":\"第三列数据1\"},{\"header1\":\"第一列数据1\",\"header2\":\"第二列数据1\",\"header3\":\"第三列数据1\"},{\"header1\":\"第一列数据1\",\"header2\":\"第二列数据1\",\"header3\":\"第三列数据1\"},{\"header1\":\"第一列数据2\",\"header2\":\"第二列数据2\",\"header3\":\"第三列数据2\"},{\"header1\":\"第一列数据2\",\"header2\":\"第二列数据2\",\"header3\":\"第三列数据2\"},{\"header1\":\"第一列数据2\",\"header2\":\"第二列数据2\",\"header3\":\"第三列数据2\"},{\"header1\":\"3\",\"header2\":\"3\",\"header3\":\"3\"}]}}}";
            case "Pie":
                return "{\"chartType\":\"pie\",\"chartTitle\":\"饼图\",\"data\":{\"legend\":[\"图例1\",\"图例2\",\"图例3\",\"图例4\",\"图例5\"],\"series\":{\"name\":\"内圈名称\",\"pieData\":[{\"name\":\"图例1\",\"value\":60},{\"name\":\"图例2\",\"value\":" + RandomUtil.randomInt(100) +"}]}}}";
        }
        return "";
    }
}
