package com.neoway.iot.bi.common.vo.offlinestrategy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("离线统计策略查询")
public class QueryOfflineStrategyVO {


	@ApiModelProperty(value = "指标")
	private String metric;
}
