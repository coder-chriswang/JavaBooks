package com.neoway.iot.gwm.api.system;

import cn.hutool.core.util.ObjectUtil;
import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.common.PageInfo;
import com.neoway.iot.gwm.entity.MetaSystemInstance;
import com.neoway.iot.gwm.handler.SystemDataSourcesInstanceHandler;
import com.neoway.iot.gwm.vo.SystemDsInstanceVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @desc: SystemDsInstanceController 系统数据源实例控制器
 * @author: 20200416002
 * @date: 2020/9/17 17:22
 */
@RestController
@RequestMapping("/v1/sinstance")
@Api(tags = "系统数据源实例管理")
public class SystemInstanceController {
    private static final Logger log = LoggerFactory.getLogger(SystemInstanceController.class);
    private SystemDataSourcesInstanceHandler handler = new SystemDataSourcesInstanceHandler();

    @ApiOperation("添加系统数据源实例")
    @PostMapping
    public HttpResult addSystemInstance(@RequestBody MetaSystemInstance systemDsInstance) {
        if (ObjectUtil.isNull(systemDsInstance) || ObjectUtil.isNull(systemDsInstance.getSystemId())) {
            log.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            int result = handler.addSystemDsInstance(systemDsInstance);
            if (2 == result) {
                return HttpResult.returnFail("该系统数据源实例已存在");
            } else if (0 == result){
                return HttpResult.returnFail("添加失败");
            }else {
                return HttpResult.returnSuccess("添加成功");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("添加系统数据源实例失败,失败原因：", e);
            return HttpResult.returnFail("添加失败");
        }
    }

    @ApiOperation("删除系统数据源实例")
    @DeleteMapping("/{instanceId}")
    @ApiImplicitParam(name = "instanceId", value = "系统数据源实例Id", required = true, dataType = "Long")
    public HttpResult deleteSystemInstance(@PathVariable("instanceId") Long instanceId) {
        if (ObjectUtil.isNull(instanceId)) {
            log.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            int result = handler.deleteSystemDsInstance(instanceId);
            if (result == 1) {
                return HttpResult.returnSuccess("删除成功");
            } else if (result == 2) {
                return HttpResult.returnFail("删除失败,该系统数据源实例不存在");
            } else {
                return HttpResult.returnFail("删除失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("删除系统数据源实例失败,失败原因：{}", e.getMessage());
            return HttpResult.returnFail("删除失败");
        }
    }

    @ApiOperation("修改系统数据源实例")
    @PutMapping
    public HttpResult updateSystemInstance(@RequestBody MetaSystemInstance systemDSInstance) {

        if (ObjectUtil.isNull(systemDSInstance) || ObjectUtil.isNull(systemDSInstance.getSystemId())) {
            log.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            int result = handler.updateSystemDsInstance(systemDSInstance);
            if (2 == result) {
                return HttpResult.returnFail("数据模型不存在");
            } else if (0 == result){
                return HttpResult.returnFail("修改失败");
            }else {
                return HttpResult.returnSuccess("修改成功");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("修改系统数据源实例失败,失败原因", e);
        }
        return HttpResult.returnFail("修改失败");
    }

    @ApiOperation("获取系统数据源实例详情")
    @GetMapping("/{instanceId}")
    @ApiImplicitParam(name = "instanceId", value = "系统数据源实例Id", required = true, dataType = "Long")
    public HttpResult<SystemDsInstanceVo> getSystemInstance(@PathVariable("instanceId") Long instanceId) {
        if (ObjectUtil.isNull(instanceId)) {
            log.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        SystemDsInstanceVo systemDSInstance = null;
        try {
            systemDSInstance = handler.getSystemDsInstance(instanceId);
            if (ObjectUtil.isNotNull(systemDSInstance)) {
                return HttpResult.returnSuccess("获取成功", systemDSInstance);
            } else {
                return HttpResult.returnFail("删除失败");
            }
        } catch (Exception e) {
            log.error("获取系统数据源实例详情失败,失败原因：", e);
            return HttpResult.returnFail("获取失败");
        }
    }


    @ApiOperation("上传证书")
    @PostMapping(value = "/upload/certificate/{nativeid}")
    @ApiImplicitParam(name = "nativeid", value = "域名", required = true, dataType = "String")
    public HttpResult uploadCertificate(MultipartFile file, @PathVariable(value = "nativeid")String nativeid) {
        if (file == null) {
            log.error("参数传递错误-文件为空！");
            return HttpResult.returnFail("文件为空，请选择文件！");
        }
        if (file.isEmpty()){
            log.error("参数传递错误-文件为空！");
            return HttpResult.returnFail("文件为空，请选择文件！");
        }
        if (StringUtils.isBlank(nativeid)) {
            log.error("参数传递错误-域名为空！");
            return HttpResult.returnFail("参数传递错误-域名为空！");
        }
        try {
             handler.uploadCertificateFile(file,nativeid);
             return HttpResult.returnSuccess("证书导入成功！");
        } catch (Exception e) {
            log.error("导入证书文件异常！", e);
            return HttpResult.returnFail("导入证书文件发生错误！");
        }
    }
    @ApiOperation("查询系统数据源实例列表")
    @PostMapping("/{pageSize}/{pageNum}/{systemId}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageSize", value = "每页条数", dataType = "Integer", defaultValue = "10"),
            @ApiImplicitParam(name = "pageNum", value = "页码", dataType = "Integer", defaultValue = "1"),
            @ApiImplicitParam(name = "connectivity", value = "连通性（搜索条件，可null）", dataType = "String"),
            @ApiImplicitParam(name = "systemId", value = "系统数据源id（左侧数据源联动,默认加载第一个数据源实例列表）", dataType = "long",required = true)
    })
    public HttpResult<PageInfo<SystemDsInstanceVo>> findSystemInstanceList(
            @PathVariable(value = "pageSize") Integer pageSize,
            @PathVariable(value = "pageNum") Integer pageNum,
            @PathVariable(value = "systemId") Long systemId,
            @RequestParam(value = "systemType", required = false) String systemType,
            @RequestParam(value = "connectivity", required = false) String connectivity) {
        try {
            if (pageSize == null || pageNum == null) {
                return HttpResult.returnFail("参数传递错误！");
            } else {
                return HttpResult.returnSuccess("查询成功！", handler.findSystemDsInstanceList(systemId,systemType,connectivity, pageSize, pageNum));
            }

        } catch (Exception e) {
            log.error("查询系统数据源实例列表失败！", e);
            return HttpResult.returnFail("查询系统数据源实例列表失败！");
        }
    }

    @ApiOperation("查询系统数据源实例列表")
    @GetMapping("/list")
    public HttpResult<List<SystemDsInstanceVo>> findSystemInstanceList() {
        try {
            List<SystemDsInstanceVo> result = handler.findsInstanceList();
            return HttpResult.returnSuccess("查询成功！", result);

        } catch (Exception e) {
            log.error("查询系统数据源实例列表失败！", e);
            return HttpResult.returnFail("查询系统数据源实例列表失败！");
        }
    }
}
