package com.neoway.iot.gwm.vo;

import com.neoway.iot.sdk.dmk.meta.DMMetaColumnDBAnno;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @desc: SystemDsInstanceVo 系统数据源实例Vo
 * @author: 20200416002
 * @date: 2020/9/26 17:30
 */
@ApiModel("系统数据源Vo")
public class SystemDsInstanceVo {
    /**
     * 系统类型
     */
    @ApiModelProperty(value = "系统类型",required = false)
    private String type;

    /**
     * 系统数据源编码
     */
    @ApiModelProperty(value = "系统数据源编码",required = true)
    @DMMetaColumnDBAnno(column = "system_id", type = Long.class)
    private Long systemId;

    /**
     * 系统实例ID
     */
    @ApiModelProperty(value = "系统实例ID",required = true)
    @DMMetaColumnDBAnno(column = "instanceid", type = String.class)
    private String instanceId;

    /**
     * 系统名称
     */
    @ApiModelProperty(value = "系统名称",required = true)
    @DMMetaColumnDBAnno(column = "name", type = String.class)
    private String name;

    /**
     * 系统域名
     */
    @ApiModelProperty(value = "系统域名",required = true)
    @DMMetaColumnDBAnno(column = "nativeid", type = String.class)
    private String nativeId;

    /**
     * 网关分配的ID
     */
    @ApiModelProperty(value = "网关分配的ID",hidden = true)
    private String gwNativeId;

    /**
     * 部署区域
     */
    @ApiModelProperty(value = "部署区域",hidden = true)
    @DMMetaColumnDBAnno(column = "region", type = String.class)
    private String region;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间",hidden = true)
    @DMMetaColumnDBAnno(column = "rt", type = int.class)
    private int rt;

    /**
     * 扩展信息
     */
    @ApiModelProperty(value = "扩展信息",required = true)
    @DMMetaColumnDBAnno(column = "ext", type = String.class)
    private String ext;


    public Long getSystemId() {
        return systemId;
    }


    public void setSystemId(Long systemId) {
        this.systemId = systemId;
    }


    public String getInstanceId() {
        return instanceId;
    }


    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getNativeId() {
        return nativeId;
    }


    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }


    public String getGwNativeId() {
        return gwNativeId;
    }


    public void setGwNativeId(String gwNativeId) {
        this.gwNativeId = gwNativeId;
    }


    public String getRegion() {
        return region;
    }


    public void setRegion(String region) {
        this.region = region;
    }


    public int getRt() {
        return rt;
    }

    public void setRt(int rt) {
        this.rt = rt;
    }

    public String getExt() {
        return ext;
    }


    public void setExt(String ext) {
        this.ext = ext;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
