package com.neoway.iot.gwm.handler;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.neoway.iot.gwm.common.PageInfo;
import com.neoway.iot.gwm.vo.*;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.common.util.DMUtil;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaCache;
import com.neoway.iot.sdk.gwk.entity.DSExt;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.GWKEnum;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *   描述： 设备数据源处理器
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 19:17
 */

public class DeviceDsHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DeviceDsHandler.class);
    private DMRunner runner;

    public DeviceDsHandler() {
        this.runner = DMRunner.getInstance();
    }

    /**
     * 新增设备数据源
     * @param deviceDS
     * @return
     */
    public boolean addDeviceDs(DeviceDS deviceDS) throws SQLException {
        //生成主键code
        String key = deviceDS.getDomain() + deviceDS.getDeviceType() + deviceDS.getTenant() + deviceDS.getDeviceVendor() + deviceDS.getDeviceVersion();
        long code = DMUtil.getHashCode(key);
        LOG.info("开始添加设备数据源，code={}",code);
        // 查询数据源对象
        MetaDeviceDsVO deviceDsInfo = getDeviceDsInfo(code);
        if (null != deviceDsInfo) {
            LOG.error("该数据源已存在，code={}",code);
            return false;
        }
        deviceDS.setCode(code);
        deviceDS.setUpdate_ts((int)(System.currentTimeMillis()/1000));
        DMDataPoint dsPoint = deviceDS.buildDataPoint();
        //插入数据源对象
        runner.write(dsPoint);
        //插入扩展属性表
        LOG.info("产品{}的扩展属性ext={}",deviceDS.getName(),deviceDS.getExt());
        if (StringUtils.isNotBlank(deviceDS.getExt())) {
            Map<String,Object> extMap = new Gson().fromJson(deviceDS.getExt(),Map.class);
            extMap.forEach((k,v) -> {
                DSExt dsExt = new DSExt();
                dsExt.setCode(deviceDS.getCode());
                dsExt.setDs_type(GWKEnum.DsType.DEVICE.name());
                dsExt.setAttr(k);
                dsExt.setValue(String.valueOf(v));
                dsExt.setUpdate_ts(Integer.valueOf(String.valueOf(System.currentTimeMillis()/1000)));
                DMDataPoint extPoint = dsExt.buildDataPoint();
                runner.write(extPoint);

            });
        }
        LOG.info("设备数据源添加完成，code={}",code);
        return true;
    }

    /**
     * 删除设备数据源信息
     * @param code
     * @return 0:删除成功；1：删除失败-无此产品；2：删除失败-该产品下有设备
     */
    public int deleteDeviceDs(Long code) {
        // 先判断该产品下有无设备
        DMDataPoint equNum = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,MetaDeviceInstanceVO.DSCI);
        DMDataColumn equNumColumn = new DMDataColumn("deviceds_id",code);
        equNum.addColumn(equNumColumn);
        List<DMDataPoint> equList = runner.list(equNum);
        if (null != equList) {
            LOG.error("该产品下存在设备无法删除，产品编码code={},设备数量={}",code,equList.size());
            return 2;
        }
        LOG.info("开始删除设备数据源添加完成，code={}",code);
        // 删除数据源对象
        DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceDS.class);
        DMDataPoint conditionDs= DMDataPoint.builder(metaCI.getNs(),metaCI.getCategory(),metaCI.getCi());
        DMDataColumn columnDs = new DMDataColumn("code",code);
        conditionDs.addColumn(columnDs);
        DMDataPoint point = runner.get(conditionDs);
        if (null == point) {
            LOG.error("该产品不存在，code={}",code);
            return 1;
        }
        runner.delete(conditionDs);
        // 删除该数据源下的扩展属性
        DMMetaCI metaCIExt=DMMetaCI.getMetaCI(DSExt.class);
        DMDataPoint conditionEXT= DMDataPoint.builder(metaCIExt.getNs(),metaCIExt.getCategory(),metaCIExt.getCi());
        DMDataColumn columnEXT = new DMDataColumn("code",code);
        conditionEXT.addColumn(columnEXT);
        runner.delete(conditionEXT);
        return 0;
    }
    /**
     * 修改设备数据源信息
     * @param deviceDS
     */
    public boolean updateDeviceDs(DeviceDS deviceDS) {
        LOG.info("开始修改设备数据源(产品)，code={}",deviceDS.getCode());
        DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceDS.class);
        DMDataPoint conditionDs= DMDataPoint.builder(metaCI.getNs(),metaCI.getCategory(),metaCI.getCi());
        DMDataColumn columnDs = new DMDataColumn("code",deviceDS.getCode());
        conditionDs.addColumn(columnDs);
        conditionDs.getMetaCI().setCache(false);
        DMDataPoint point = runner.get(conditionDs);
        DeviceDS ds = (DeviceDS)DMUtil.buildClazzInstance(point,DeviceDS.class);
        if (null == ds) {
            LOG.error("该产品不存在，code={}",deviceDS.getCode());
            return false;
        }
        //插入数据源对象
        deviceDS.setUpdate_ts((int)System.currentTimeMillis()/1000);
        DMDataPoint dsPoint = deviceDS.buildDataPoint();
        runner.write(dsPoint);
        //插入扩展属性表
        LOG.info("修改产品{}的扩展属性ext={}",deviceDS.getName(),deviceDS.getExt());
        if (StringUtils.isNotBlank(deviceDS.getExt())) {
            Map<String,Object> extMap = new Gson().fromJson(deviceDS.getExt(),Map.class);
            extMap.forEach((k,v) -> {
                LOG.info("扩展属性={}，值为={}",k,v);
                DSExt dsExt = new DSExt();
                dsExt.setCode(deviceDS.getCode());
                dsExt.setDs_type(GWKEnum.DsType.DEVICE.name());
                dsExt.setAttr(k);
                dsExt.setValue(String.valueOf(v));
                dsExt.setUpdate_ts(Integer.valueOf(String.valueOf(System.currentTimeMillis()/1000)));
                DMDataPoint extPoint = dsExt.buildDataPoint();
                runner.write(extPoint);
            });
        }LOG.info("修改设备数据源(产品)完成，code={}",deviceDS.getCode());
        return true;
    }
    /**
     * 获取设备数据源详情
     * @param code
     * @return
     */
    public MetaDeviceDsVO getDeviceDsInfo(Long code) throws SQLException {
        LOG.info("开始查询设备数据源详情，code={}",code);
        MetaDeviceDsVO dsVO = new MetaDeviceDsVO();
        // 查询数据源对象
        DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceDS.class);
        DMDataPoint condition= DMDataPoint.builder(metaCI.getNs(),metaCI.getCategory(),metaCI.getCi());
        DMDataColumn column = new DMDataColumn("code",code,true);
        condition.addColumn(column);
        condition.getMetaCI().setCache(false);
        DMDataPoint dsPoint0 = runner.get(condition);
        DeviceDS deviceDS = DeviceDS.buildDeviceDS(dsPoint0,true);
        if (null != deviceDS) {
            BeanUtils.copyProperties(deviceDS,dsVO);
        } else {
            LOG.error("获取设备数据源详情失败，无此设备数据源code={}",code);
            return null;
        }
        //统计该产品下的设备数量
        DMDataPoint equNum = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,MetaDeviceInstanceVO.DSCI);
        DMDataColumn equNumColumn = new DMDataColumn("deviceds_id",code);
        equNum.addColumn(equNumColumn);
        List<DMDataPoint> equList = runner.list(equNum);
        if (null == equList) {
            dsVO.setDeviceNum(0);
        } else {
            dsVO.setDeviceNum(equList.size());

        }
        //获取产品名称
        if (StringUtils.isNotBlank(deviceDS.getDeviceType())) {
            DMMetaCI deviceCi = runner.getMetaCI("ies", "urm", deviceDS.getDeviceType());
            dsVO.setDeviceTypeName(deviceCi != null ? deviceCi.getName():"");
        }

        //获取行业领域名称
        if (StringUtils.isBlank(deviceDS.getDomain())) {
            LOG.error("domain不存在，不查询DOMAIN表，设备数据源详情查询结束，code={}",code);
            return dsVO;
        }
        QueryRunner queryRunner = new QueryRunner(DMPool.getInstance().getNsDataSource("ies", "urm"));
        String sql = "SELECT h_code,h_name,name tenant FROM URM_M_DOMAIN WHERE code=" + "\'"+deviceDS.getDomain() + "\'";
        Map<String, Object> resultMap = queryRunner.query(sql, new MapHandler());
        if (resultMap != null) {
            dsVO.setIndustry(String.valueOf(resultMap.getOrDefault("h_code","")));
            dsVO.setIndustryName(String.valueOf(resultMap.getOrDefault("h_name","")));
            dsVO.setDomainName(String.valueOf(resultMap.getOrDefault("name","")));
        }
        LOG.info("查询设备数据源详情结束，code={}",code);
        return dsVO;
    }

    /**
     * 获取设备数据源记录集
     * @param pageSize
     * @param pageNum
     * @return
     */
    public PageInfo<MetaDeviceDsVO> findDeviceDsList(DeviceDS deviceDS,Integer pageSize, Integer pageNum) throws SQLException {
        LOG.info("开始分页查询设备数据源(产品)记录集！");
        //获取MetaCi
        DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceDS.class);
        if (null == metaCI) {
            String msg = "添加数据失败，原因=元数据不存在。产品域={0},主题={1},ci={2}";
            String errMsg = MessageFormat.format(msg, "ies","gwm","DeviceDS");
            throw new RuntimeException(errMsg);
        }
        DMDataPoint dsPoint = DMDataPoint.builder(metaCI.getNs(),metaCI.getCategory(),metaCI.getCi());
        dsPoint.getMetaCI().setPageNum(pageNum);
        dsPoint.getMetaCI().setPageSize(pageSize);
        //封装搜索条件
        Map<String,Object> searchCondition = Maps.newHashMap();
        if (StringUtils.isNotBlank(deviceDS.getDomain())) {
            searchCondition.put("domain",deviceDS.getDomain());
        }
        if (StringUtils.isNotBlank(deviceDS.getTenant())) {
            searchCondition.put("tenant",deviceDS.getTenant());
        }
        if (StringUtils.isNotBlank(deviceDS.getDeviceType())) {
            searchCondition.put("device_type",deviceDS.getDeviceType());
        }
        if (StringUtils.isNotBlank(deviceDS.getProtocol())) {
            searchCondition.put("protocol",deviceDS.getProtocol());
        }

        dsPoint.buildColumns(searchCondition);
        com.neoway.iot.sdk.dmk.data.PageInfo<DMDataPoint> pointPageInfo = runner.pageList(dsPoint);
        PageInfo<MetaDeviceDsVO> pageInfo = new PageInfo<>();
        int total = pointPageInfo.getTotal();
        // 总页数
        int pageSum=(total-1)/pageSize+1;
        pageInfo.setRecordsTotal(total);
        pageInfo.setPageSum(pageSum);
        List<MetaDeviceDsVO> datas = Lists.newArrayList();

        for(DMDataPoint point:pointPageInfo.getList()){
            DeviceDS deviceDS0 = DeviceDS.buildDeviceDS(point,true);
            MetaDeviceDsVO dsVO = new MetaDeviceDsVO();
            BeanUtils.copyProperties(deviceDS0,dsVO);
            //统计该产品下的设备数量
            DMDataPoint equNum = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,MetaDeviceInstanceVO.DSCI);
            DMDataColumn equNumColumn = new DMDataColumn("deviceds_id",deviceDS0.getCode());
            equNum.addColumn(equNumColumn);
            List<DMDataPoint> equList = runner.list(equNum);
            if (null == equList) {
                dsVO.setDeviceNum(0);
            } else {
                dsVO.setDeviceNum(equList.size());

            }
            //获取产品名称
            if (StringUtils.isNotBlank(deviceDS0.getDeviceType())) {
                DMMetaCI deviceCi = runner.getMetaCI("ies", "urm", deviceDS0.getDeviceType());
                dsVO.setDeviceTypeName(deviceCi != null ? deviceCi.getName():"");
            }

            //获取行业领域名称
            if (StringUtils.isNotBlank(deviceDS0.getDomain())) {
                QueryRunner queryRunner = new QueryRunner(DMPool.getInstance().getNsDataSource("ies", "urm"));
                String sql = "SELECT h_code,h_name,name tenant FROM URM_M_DOMAIN WHERE code=" + "\'"+deviceDS0.getDomain() + "\'";
                Map<String, Object> resultMap = queryRunner.query(sql, new MapHandler());
                if (resultMap != null) {
                    dsVO.setIndustry(String.valueOf(resultMap.getOrDefault("h_code","")));
                    dsVO.setIndustryName(String.valueOf(resultMap.getOrDefault("h_name","")));
                    dsVO.setDomainName(String.valueOf(resultMap.getOrDefault("name","")));
                }
            } else {
                LOG.error("DOMAIN不存在，code={}",deviceDS0.getCode());
            }
            datas.add(dsVO);
        }
        pageInfo.setCurrentPageContent(datas);
        LOG.info("分页查询设备数据源(产品)记录集完成！");
        return pageInfo;
    }

    /**
     * 开始查询行业领域树
     * @return
     */
    public List<TradeTreeVo> tradeTree() throws SQLException {
        // 1 查询行业 2 根据行业code查询领域 3 根据行业和领域查询产品
        LOG.info("开始查询行业领域树");
        QueryRunner queryRunner = new QueryRunner(DMPool.getInstance().getNsDataSource("ies","urm"));
        String hSql = "SELECT DISTINCT h_code,h_name FROM URM_M_DOMAIN";
        List<TradeTreeVo> tradeList = queryRunner.query(hSql, new BeanListHandler<>(TradeTreeVo.class));
        for (TradeTreeVo t : tradeList) {
            String domainSql = "SELECT code,name FROM URM_M_DOMAIN WHERE h_code = " + "\'" + t.getH_code()  + "\'";
            List<DomainTreeVo> domainTreeVoList = queryRunner.query(domainSql, new BeanListHandler<>(DomainTreeVo.class));
            if (domainTreeVoList == null) {
                continue;
            }
            t.setDomainList(domainTreeVoList);
            for (DomainTreeVo d : domainTreeVoList) {
                    DMMetaCI ci = new DMMetaCI();
                    ci.setNs("ies");
                    ci.setCategory("urm");
                    ci.setType("D");
                    List<DMMetaCI> list = runner.queryMetaCi(ci);
//                DMMetaCI metaCI = runner.getMetaCI("ies", "urm", "Swj");
//                List<DMMetaCI> list = Lists.newArrayList();
//                list.add(metaCI);
                d.setDsList(list);
            }
        }
        LOG.info("查询行业领域树结束！");
        return tradeList;

    }

    /**
     * 查询服务和映射列表
     * @param deviceType
     * @return
     */
    public DMMetaCI getDMMetaCi(String deviceType) {
        LOG.info("开始查询服务映射列表！");
        DMMetaCI metaCI = runner.getMetaCI("ies", "urm", deviceType);
        LOG.info("查询服务映射列表结束！");
        return metaCI;
    }
}
