package com.neoway.iot.gwm.api.service;

import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.handler.DsActionMapHandler;
import com.neoway.iot.gwm.vo.MetaActionMappingVo;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * <pre>
 *    描述：服务映射控制器
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 19:01
 */
@RestController
@RequestMapping("/v1/actionmap")
@Api(tags = "服务映射管理")
public class DsActionMapController {
    private static final Logger LOG = LoggerFactory.getLogger(DsActionMapController.class);
    private DsActionMapHandler handler = new DsActionMapHandler();
    @ApiOperation("新增数据源服务映射信息")
    @PostMapping
    public HttpResult addDsActionMap(@RequestBody MetaActionMappingVo actionMap) {
        if (null == actionMap.getDs_code() || StringUtils.isBlank(actionMap.getDs_type()) || StringUtils.isBlank(actionMap.getAction_id())) {
            LOG.error("参数传递错误！");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result = handler.addDsActionMap(actionMap);
            if (result) {
                return HttpResult.returnSuccess("服务映射信息添加成功！");
            } else {
                return HttpResult.returnFail("重复添加了服务映射信息");
            }
        } catch (Exception e) {
            LOG.error("数据源服务映射信息添加异常！", e);
            return HttpResult.returnFail("数据源服务映射信息添加异常！");
        }
    }

    @ApiOperation("删除数据源服务映射信息")
    @DeleteMapping("/{dsCode}/{dsType}/{actionId}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "dsCode",value = "产品标识",dataType = "Long",required = true),
            @ApiImplicitParam(name = "dsType",value = "数据源类型",dataType = "String",required = true),
            @ApiImplicitParam(name = "actionId",value = "服务标识",dataType = "String",required = true)
    })
    public HttpResult deleteDsActionMap(@PathVariable(value = "dsCode") Long dsCode,@PathVariable(value = "dsType") String dsType,@PathVariable(value = "actionId") String actionId ) {
        if (null == dsCode || StringUtils.isBlank(dsType) || StringUtils.isBlank(actionId)) {
            LOG.error("参数传递错误！");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result = handler.deleteDsActionMap(dsCode,dsType,actionId);
            if (result) {
                return HttpResult.returnSuccess("服务映射删除成功！");
            } else {
                return HttpResult.returnFail("删除失败--该服务映射不存在");
            }

        } catch (Exception e) {
            LOG.error("数据源服务映射信息删除失败！", e);
            return HttpResult.returnFail("数据源服务映射信息删除失败！");
        }
    }

    @ApiOperation("编辑数据源服务映射信息")
    @PutMapping
    public HttpResult updateDsActionMap(@RequestBody MetaActionMappingVo actionMap) {
        if (null == actionMap.getDs_code() || StringUtils.isBlank(actionMap.getDs_type()) || StringUtils.isBlank(actionMap.getAction_id())) {
            LOG.error("参数传递错误！");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result = handler.updateDsActionMap(actionMap);
            if (result) {
                return HttpResult.returnSuccess("修改成功");
            } else {
                return HttpResult.returnFail("修改失败--该记录不存在!");
            }

        } catch (Exception e) {
            LOG.error("数据源服务映射信息更新异常！", e);
            return HttpResult.returnFail("数据源服务映射信息更新异常！");
        }
    }


    @ApiOperation("查询数据源服务映射信息记录集")
    @GetMapping("/actionmaps/{dsCode}")
    @ApiImplicitParam(name = "dsCode",value = "产品标识",dataType = "Long",required = true)
            public HttpResult<List<MetaActionMappingVo>> findDsActionMap(@PathVariable(value = "dsCode") Long dsCode) {
        try {
            List<MetaActionMappingVo> result = handler.findDsActionMapList(dsCode);
            return HttpResult.returnSuccess("服务映射记录集查询成功",result);
        } catch (Exception e) {
            LOG.error("数据源服务映射记录集查询失败！", e);
            return HttpResult.returnFail("数据源服务映射记录集查询失败！");
        }
    }
    @ApiOperation("查看模板详情")
    @GetMapping("/{templateId}")
    @ApiImplicitParam(name = "templateId",value = "模板Id",dataType = "String",required = true)
    public HttpResult<String> findTemplate(@PathVariable(value = "templateId") String templateId) {
        try {
            if (StringUtils.isBlank(templateId)) {
                return HttpResult.returnFail("参数传递错误！");
            }
            String templateXml = handler.getTemplateInfo(templateId);
            if (StringUtils.isNotBlank(templateXml)) {
                return HttpResult.returnSuccess("服务映射记录集查询成功",templateXml);
            } else {
                return HttpResult.returnFail("服务映射记录集查询失败");
            }


        } catch (Exception e) {
            LOG.error("模板详情查询失败！", e);
            return HttpResult.returnFail("模板详情查询失败！");
        }
    }


    @ApiOperation("离线导入模板文件")
    @PostMapping(value = "/import/template/{dsCode}/{dsType}/{actionId}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "dsCode",value = "数据源编码",dataType = "Long",required = true),
            @ApiImplicitParam(name = "dsType",value = "数据源类型",dataType = "String",required = true),
            @ApiImplicitParam(name = "actionId",value = "服务标识",dataType = "String",required = true)
    })
    public HttpResult<MetaTemplate> importData(MultipartFile file,@PathVariable(value = "dsCode") Long dsCode,@PathVariable(value = "dsType")String dsType,@PathVariable(value = "actionId")String actionId) {
        if (file == null) {
            LOG.error("参数传递错误-文件为空！");
            return HttpResult.returnFail("参数传递错误-文件为空！");
        }
        if (null == dsCode || StringUtils.isBlank(dsType) || StringUtils.isBlank(actionId)) {
            LOG.error("参数传递错误-数据源编码为空！");
            return HttpResult.returnFail("参数传递错误-数据源编码为空！");
        }
        if (!file.isEmpty()){
            if (!file.getOriginalFilename().endsWith(".xml")){
                LOG.error("参数传递错误-文件格式错误！");
                return HttpResult.returnFail("文件格式错误！请传xml格式文件！");
            }
        } else {
            LOG.error("参数传递错误-文件为空！");
            return HttpResult.returnFail("文件为空，请选择文件！");
        }

        try {
            MetaTemplate template = handler.uploadTemplateFile(file,dsCode,dsType,actionId);
            if (null != template) {
                return HttpResult.returnSuccess("模板文件导入成功！", template);
            } else {
                return HttpResult.returnFail("模板文件导入失败！");
            }

        } catch (Exception e) {
            LOG.error("导入模板文件异常！", e);
            return HttpResult.returnFail("导入模板文件异常！");
        }
    }
}
