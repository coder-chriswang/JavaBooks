package com.neoway.iot.gwm.api.system;

import cn.hutool.core.util.ObjectUtil;
import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.handler.SystemDataSourcesHandler;
import com.neoway.iot.gwm.vo.MetaCiTreeVo;
import com.neoway.iot.gwm.vo.SystemDsVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @desc: SystemDsController 系统数据源控制器
 * @author: 20200416002
 * @date: 2020/9/17 17:22
 */
@RestController
@RequestMapping("/v1/systemds")
@Api(tags = "系统数据源管理")
public class SystemDsController {
    private static final Logger log = LoggerFactory.getLogger(SystemDsController.class);
    private SystemDataSourcesHandler handler = new SystemDataSourcesHandler();


    @ApiOperation("获取系统数据源详情")
    @GetMapping("/{code}")
    @ApiImplicitParam(name = "code",value = "系统数据源编码",dataType = "Long",required = true)
    public HttpResult<SystemDsVo> getSystemDS(@PathVariable("code") Long code) {
        if (ObjectUtil.isNull(code)) {
            log.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        SystemDsVo systemDsVo = null;
        try {
            systemDsVo = handler.getSystemDS(code);
            if (ObjectUtil.isNotNull(systemDsVo)) {
                return HttpResult.returnSuccess(systemDsVo);
            } else {
                return HttpResult.returnFail("获取失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("获取系统数据源失败,失败原因：", e);
            return HttpResult.returnFail("获取失败");
        }
    }

    @ApiOperation("查询系统数据源树")
    @GetMapping("/tree")
    public HttpResult<List<SystemDsVo>> findSystemDSList(){
        try {
            return HttpResult.returnSuccess("获取成功",handler.tree());
        } catch (Exception e) {
            e.printStackTrace();
            return HttpResult.returnFail("获取失败");
        }
    }

    @ApiOperation("系统数据源连通性检测")
    @PostMapping("connectivity/{code}")
    @ApiImplicitParam(name = "code",value = "系统数据源编码",dataType = "Long",required = true)
    public HttpResult checkSystemDsConnectivity(@PathVariable(value = "code") Long code) {
        String result;
        try {
            result = handler.checkSystemDsConnectivity(code);
            if (StringUtils.isNotBlank(result)) {
                return HttpResult.returnSuccess("连通性检测成功",result);
            } else {
                return HttpResult.returnSuccess("连通性检测失败！");
            }
        } catch (Exception e) {
            log.error("系统数据源连通性检测失败！", e);
            return HttpResult.returnFail("系统数据源连通性检测失败！");
        }
    }
    @ApiOperation("管理资源树")
    @GetMapping("/citree")
    public HttpResult<MetaCiTreeVo> getMangeCiTree() {
        try {
            return HttpResult.returnSuccess("管理资源树获取成功",handler.ciTree());
        } catch (Exception e) {
            log.error("获取管理资源树发生错误，异常信息：",e);
            return HttpResult.returnFail("获取管理资源树发生错误");
        }
    }
}
