package com.neoway.iot.gwm.entity;

import com.neoway.iot.sdk.dmk.meta.DMMetaColumnDBAnno;

/**
 * <pre>
 *   描述：设备数据源实例实体类
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/26 18:01
 */

public class MetaDeviceInstance {
    @DMMetaColumnDBAnno(column = "deviceds_id",type = long.class)
    private long deviceds_id;
    @DMMetaColumnDBAnno(column = "instanceid",type = long.class)
    private long instanceid;
    @DMMetaColumnDBAnno(column = "name",type = String.class)
    private String name;
    @DMMetaColumnDBAnno(column = "nativeid",type = String.class)
    private String nativeId;
    @DMMetaColumnDBAnno(column = "gw_nativeid",type = String.class)
    private String gw_nativeid;
    @DMMetaColumnDBAnno(column = "region",type = String.class)
    private String region;
    @DMMetaColumnDBAnno(column = "rt",type = int.class)
    private int rt;
    @DMMetaColumnDBAnno(column = "at",type = int.class)
    private int at;
    @DMMetaColumnDBAnno(column = "lt",type = int.class)
    private int lt;
    @DMMetaColumnDBAnno(column = "status",type = String.class)
    private String status;
    @DMMetaColumnDBAnno(column = "location",type = String.class)
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public long getDeviceds_id() {
        return deviceds_id;
    }

    public void setDeviceds_id(long deviceds_id) {
        this.deviceds_id = deviceds_id;
    }

    public long getInstanceid() {
        return instanceid;
    }

    public void setInstanceid(long instanceid) {
        this.instanceid = instanceid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

    public String getGw_nativeid() {
        return gw_nativeid;
    }

    public void setGw_nativeid(String gw_nativeid) {
        this.gw_nativeid = gw_nativeid;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }


    public int getRt() {
        return rt;
    }

    public void setRt(int rt) {
        this.rt = rt;
    }

    public int getAt() {
        return at;
    }

    public void setAt(int at) {
        this.at = at;
    }

    public int getLt() {
        return lt;
    }

    public void setLt(int lt) {
        this.lt = lt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
