package com.neoway.iot.gwm.vo;

import com.google.common.collect.Maps;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Map;

/**
 * <pre>
 *   描述：数据源属性映射
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 20:01
 */
@ApiModel("属性映射实体")
public class MetaAttrMappingVo {

    @ApiModelProperty(value ="数据源标识",required = true)
    private Long ds_code;
    @ApiModelProperty(value ="数据源类型",required = true)
    private String ds_type;
    @ApiModelProperty(value ="消息属性ID",required = true)
    private String attr_id;
    @ApiModelProperty(value ="标准属性标识",required = true)
    private String meta_attr_id;
    @ApiModelProperty(value ="标准属性名称")
    private String meta_attr_Name;
    @ApiModelProperty(value ="标准属性类型")
    private String meta_attr_Type;
    @ApiModelProperty(value ="更新时间")
    private int update_ts;

    public Long getDs_code() {
        return ds_code;
    }

    public void setDs_code(Long ds_code) {
        this.ds_code = ds_code;
    }

    public String getDs_type() {
        return ds_type;
    }

    public void setDs_type(String ds_type) {
        this.ds_type = ds_type;
    }

    public String getAttr_id() {
        return attr_id;
    }

    public void setAttr_id(String attr_id) {
        this.attr_id = attr_id;
    }

    public String getMeta_attr_id() {
        return meta_attr_id;
    }

    public void setMeta_attr_id(String meta_attr_id) {
        this.meta_attr_id = meta_attr_id;
    }

    public String getMeta_attr_Name() {
        return meta_attr_Name;
    }

    public void setMeta_attr_Name(String meta_attr_Name) {
        this.meta_attr_Name = meta_attr_Name;
    }

    public String getMeta_attr_Type() {
        return meta_attr_Type;
    }

    public void setMeta_attr_Type(String meta_attr_Type) {
        this.meta_attr_Type = meta_attr_Type;
    }

    public int getUpdate_ts() {
        return update_ts;
    }

    public void setUpdate_ts(int update_ts) {
        this.update_ts = update_ts;
    }

    /**
     * 构建添加时的参数
     * @return
     */
    public Map<String,Object> buildAddParamsMap() {
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",this.getDs_code());
        conditionMap.put("ds_type",this.getDs_type());
        conditionMap.put("attr_id",this.getAttr_id());
        conditionMap.put("meta_attr_id",this.getMeta_attr_id());
        conditionMap.put("update_ts",this.getUpdate_ts());
        return conditionMap;

    }
}
