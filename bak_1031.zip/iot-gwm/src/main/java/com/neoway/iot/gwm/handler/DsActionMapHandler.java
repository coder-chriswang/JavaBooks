package com.neoway.iot.gwm.handler;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neoway.iot.gwm.vo.MetaActionMappingVo;
import com.neoway.iot.gwm.vo.MetaDeviceInstanceVO;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.util.DMUtil;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.ActionMapping;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 *   描述：数据源服务映射处理器
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 19:19
 */

public class DsActionMapHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DsActionMapHandler.class);
    private DMRunner runner;

    public DsActionMapHandler() {
        this.runner = DMRunner.getInstance();
    }

    /**
     * 新增服务映射信息
     * @param actionMap
     * @return
     */
    public boolean addDsActionMap(MetaActionMappingVo actionMap) {
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"ActionMapping");
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",actionMap.getDs_code());
        conditionMap.put("ds_type",actionMap.getDs_type());
        conditionMap.put("action_id",actionMap.getAction_id());
        condition.buildColumns(conditionMap);
        condition.getMetaCI().setCache(false);
        DMDataPoint actionPoint = runner.get(condition);
        ActionMapping actionMapping = (ActionMapping)DMUtil.buildClazzInstance(actionPoint,ActionMapping.class);
        if (null != actionMapping) {
            LOG.error("添加失败-该服务映射信息已经存在-actionId={}",actionMap.getAction_id());
            return false;
        }
        actionMap.setUpdate_ts((int)(System.currentTimeMillis()/1000));
        Map<String,Object> addMap = actionMap.buildAddParamsMap();
        DMDataPoint addCondition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"ActionMapping");
        addCondition.buildColumns(addMap);
        //插入数据源对象
        runner.write(addCondition);
        LOG.info("服务映射添加失败-actionId={}",actionMap.getAction_id());
        return true;
    }
    /**
     * 删除服务映射
     * @param dsCode
     * @param dsType
     * @param actionId
     * @return
     */
    public boolean deleteDsActionMap(Long dsCode, String dsType, String actionId) {
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"ActionMapping");
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",dsCode);
        conditionMap.put("ds_type",dsType);
        conditionMap.put("action_id",actionId);
        condition.buildColumns(conditionMap);
        condition.getMetaCI().setCache(false);
        DMDataPoint actionPoint = runner.get(condition);
        ActionMapping actionMapping = (ActionMapping)DMUtil.buildClazzInstance(actionPoint,ActionMapping.class);
        if (null == actionMapping) {
            LOG.error("删除失败-该服务映射信息不存在-dsType={},dsCode={},actionId={}",dsCode,dsType,actionId);
            return false;
        } else {
            runner.delete(condition);
            LOG.info("删除成功-dsType={},dsCode={},actionId={}",dsCode,dsType,actionId);
            return true;
        }
    }
    /**
     * 修改服务映射记录
     * @param actionMap
     * @return
     */
    public boolean updateDsActionMap(MetaActionMappingVo actionMap) {
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"ActionMapping");
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",actionMap.getDs_code());
        conditionMap.put("ds_type",actionMap.getDs_type());
        conditionMap.put("action_id",actionMap.getAction_id());
        condition.buildColumns(conditionMap);
        condition.getMetaCI().setCache(false);
        DMDataPoint actionPoint = runner.get(condition);
        ActionMapping actionMapping = (ActionMapping)DMUtil.buildClazzInstance(actionPoint,ActionMapping.class);
        if (null == actionMapping) {
            LOG.error("修改失败-该服务映射信息不存在-dsType={},dsCode={},actionId={}",actionMap.getDs_type(),actionMap.getDs_code(),actionMap.getAction_id());
            return false;
        } else {
            actionMap.setUpdate_ts((int)(System.currentTimeMillis()/1000));
            Map<String,Object> addMap = actionMap.buildAddParamsMap();
            DMDataPoint updateCondition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"ActionMapping");
            updateCondition.buildColumns(addMap);
            //更新数据源对象
            runner.write(updateCondition);
            LOG.info("修改成功-dsType={},dsCode={},actionId={}",actionMap.getDs_type(),actionMap.getDs_code(),actionMap.getAction_id());
            return true;
        }
    }
    /**
     * 查找服务映射列表
     * @return
     */
    public List<MetaActionMappingVo> findDsActionMapList(Long code) {
        DMDataPoint point = DMDataPoint.builder("ies","gwm","ActionMapping");
        DMDataColumn column = new DMDataColumn("ds_code",code);
        point.addColumn(column);
        List<DMDataPoint> actionPointList = runner.list(point);
        if (CollectionUtils.isEmpty(actionPointList)) {
            LOG.error("数据库中无指令映射信息！");
            return null;
        }
        List<MetaActionMappingVo> voList = Lists.newArrayList();

        for (int i = 0; i < actionPointList.size(); i++) {
            ActionMapping tempAction = ActionMapping.buildActionMapping(actionPointList.get(i));
            if (null == tempAction || StringUtils.isEmpty(tempAction.getMeta_action_id()) || StringUtils.isEmpty(tempAction.getDs_code())) {
                LOG.error("数据源属性映射记录查询失败!");
                continue;
            }
            MetaActionMappingVo vo = new MetaActionMappingVo();
            BeanUtils.copyProperties(tempAction,vo);
            //查询产品类型作为CI
            Map<String,Object> keys = Maps.newHashMap();
            keys.put("NS","ies");
            keys.put("CATEGORY","urm");
            keys.put("ID",tempAction.getMeta_action_id());
            DMDataPoint dsPoint = DMDataPoint.builder("ies","gwm","DeviceDS");
            DMDataColumn codeColumn = new DMDataColumn("code",tempAction.getDs_code());
            dsPoint.addColumn(codeColumn);
            dsPoint.getMetaCI().setCache(false);
            DMDataPoint dsData = runner.get(dsPoint);
            DeviceDS deviceDS = DeviceDS.buildDeviceDS(dsData, false);
            if (null != deviceDS) {
                keys.put("CI",deviceDS.getDeviceType());
                // 查询标准指令详情
                DMMetaAction metaAction = runner.getMetaAction(keys);
                if (null != metaAction) {
                    vo.setMeta_action_name(metaAction.getName());
                    vo.setMeta_action_type(metaAction.getType());
                    vo.setMeta_action_direction(metaAction.getDirection());
                }
                // 根据标准指令ID查询该指令对应的标准属性
                DMMetaCI ci = runner.getMetaCI("ies","urm",deviceDS.getDeviceType());
                if(ci == null) {
                    continue;
                }
                Set<DMMetaAttr> metaAttrs = ci.buildSupportAttr(tempAction.getMeta_action_id());
                if (!CollectionUtils.isEmpty(metaAttrs)) {
                    vo.setMeta_attr_list(metaAttrs);
                }
            } else {
                LOG.error("数据源指令映射记录查询失败-无该数据源信息，dsCode={}",tempAction.getDs_code());
            }
            voList.add(vo);
        }

        return voList;
    }

    /**
     * 导入模板文件，并解析入库
     * @param file
     * @return
     */
    public MetaTemplate uploadTemplateFile(MultipartFile file,Long dsCode,String dsType,String actionId) {
        MetaTemplate template = null;
        // 获取文件名
        String fileName = file.getOriginalFilename();
        //临时路径
        String filePath = "deployment/template";
        try {
            File fileTemp = new File(filePath);
            if (fileTemp.mkdirs()) {
                saveFileFromInputStream(file.getInputStream(),filePath,fileName);
                template = MetaTemplate.build(filePath + File.separator + fileName, dsCode);
                if (null != template) {
                    List<DMDataPoint> templatePoints = createTemplatePoints(template);
                    runner.write(templatePoints);
                    LOG.info("将模板ID写入服务映射表中,templateId={}",template.getTemplateid());

//                    String sql = "UPDATE ies_gwm.GWM_B_ACTIONMAPPING AM SET AM.TEMPLATE_ID="+"\'" +template.getTemplateid()+ "\'"+" WHERE AM.DS_CODE="+ dsCode +
//                            " AND AM.DS_TYPE=" + "\'"+dsType+"\'"  +" AM.AND ACTION_ID=" +"\'"+actionId+"\'";
                    String sql = "UPDATE ies_gwm.GWM_B_ACTIONMAPPING AM SET AM.TEMPLATE_ID=" +template.getTemplateid()+" WHERE AM.DS_CODE="+ dsCode +
                            " AND AM.DS_TYPE=" +dsType +" AM.AND ACTION_ID=" +actionId;
                    runner.executeSQL(sql);
                }
            }
        } catch (Exception e) {
            LOG.error("模板文件导入异常，e",e);
        } finally {
            deleteFile(filePath);
        }
        return template;
    }

    /**
     * 保存文件到指定目录
     * @param stream
     * @param path
     * @param fileName
     * @throws IOException
     */
    private void saveFileFromInputStream(InputStream stream, String path, String fileName) throws IOException {
        FileOutputStream fs = new FileOutputStream( path + File.separator + fileName);
        byte[] buffer =new byte[1024*1024];
        int byteSum = 0;
        int byteRead;
        while ((byteRead = stream.read(buffer))!=-1) {
            byteSum += byteRead;
            fs.write(buffer,0,byteRead);
            fs.flush();
        }
        fs.close();
        stream.close();
    }

    /**
     * 删除文件或文件夹
     * @param delPath
     */
    private void deleteFile(String delPath) {
        File file = new File(delPath);
        if (file.isDirectory()) {
            String[] fileList = file.list();
            for (String delFile : fileList) {
                File delfile = new File(delPath + File.separator + delFile);
                if (delfile.isDirectory()) {
                    deleteFile(delPath + File.separator + delFile);
                } else {
                    LOG.info("正在删除文件：" + delfile.getPath() + ",删除是否成功：" + delfile.delete());
                }
            }
            LOG.info("正在删除空文件夹：" + file.getPath() + ",删除是否成功：" + file.delete());
        } else {
            LOG.info("正在删除文件：" + file.getPath() + ",删除是否成功：" + file.delete());
        }
    }
    /**
     * 生成模板数据集
     * @param template
     * @return
     */
    private List<DMDataPoint> createTemplatePoints(MetaTemplate template){
        List<DMDataPoint> points=new ArrayList<>();
        DMDataPoint point=template.buildDataPoint();
        points.add(point);
        if(null != template.getEndpoint()){
            point=template.getEndpoint().buildDataPoint();
            points.add(point);
        }
        if(null != template.getHeader()){
            point=template.getHeader().buildDataPoint();
            points.add(point);
        }
        if(null != template.getEvent()){
            point=template.getEvent().buildDataPoint();
            points.add(point);
        }
        if(null != template.getRequest()){
            point=template.getRequest().buildDataPoint();
            points.add(point);
        }
        if(null != template.getResponse()){
            point=template.getResponse().buildDataPoint();
            points.add(point);
        }
        return points;
    }

    /**
     * 查询模板详情
     * @param templateId
     * @return
     */
    public String getTemplateInfo(String templateId) {
        DMMetaCI metaCI=DMMetaCI.getMetaCI(MetaTemplate.class);
        DMDataPoint point= DMDataPoint.builder(metaCI.getNs(),metaCI.getCategory(),metaCI.getCi());
        DMDataColumn column = new DMDataColumn("templateid",templateId,true);
        point.addColumn(column);
        DMDataPoint templatePoint = runner.get(point);
        MetaTemplate template = MetaTemplate.buildTemplate(templatePoint, true);
        return template.buildAsXml();
    }
}
