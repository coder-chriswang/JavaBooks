package com.neoway.iot.gwm.handler;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neoway.iot.gwm.vo.MetaAttrMappingVo;
import com.neoway.iot.gwm.vo.MetaDeviceInstanceVO;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.util.DMUtil;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.AttrMapping;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *   描述：数据源属性映射处理器
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 19:20
 */

public class DsAttrMapHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DsAttrMapHandler.class);
    private DMRunner runner;

    public DsAttrMapHandler() {
        this.runner = DMRunner.getInstance();
    }

    /**
     * 添加数据源属性映射记录
     * @param attrMap
     * @return
     */
    public boolean addDsAttrMap(MetaAttrMappingVo attrMap) {
        // 查询属性映射
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"AttrMapping");
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",attrMap.getDs_code());
        conditionMap.put("ds_type",attrMap.getDs_type());
        conditionMap.put("attr_id",attrMap.getAttr_id());
        condition.buildColumns(conditionMap);
        condition.getMetaCI().setCache(false);
        DMDataPoint attrPoint = runner.get(condition);
        AttrMapping attrMapping = (AttrMapping)DMUtil.buildClazzInstance(attrPoint,AttrMapping.class);
        if (null != attrMapping) {
            LOG.error("添加失败-该属性映射信息已经存在-attrId={}",attrMap.getAttr_id());
            return false;
        }
        attrMap.setUpdate_ts((int)(System.currentTimeMillis()/1000));
        Map<String,Object> addMap = attrMap.buildAddParamsMap();
        DMDataPoint addCondition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"AttrMapping");
        addCondition.buildColumns(addMap);
        //插入数据源对象
        runner.write(addCondition);
        return true;
    }
    /**
     * 删除数据源属性映射记录
     * @param dsCode
     * @param dsType
     * @param attrId
     * @return
     */
    public boolean deleteDsAttrMap(Long dsCode, String dsType, String attrId) {
        // 查询属性映射
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"AttrMapping");
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",dsCode);
        conditionMap.put("ds_type",dsType);
        conditionMap.put("attr_id",attrId);
        condition.buildColumns(conditionMap);
        DMDataPoint attrPoint = runner.get(condition);
        AttrMapping attrMap = (AttrMapping)DMUtil.buildClazzInstance(attrPoint, AttrMapping.class);
        if (null == attrMap) {
            LOG.error("删除失败-该属性映射信息不存在-dsType={},dsCode={},attrId={}",dsCode,dsType,attrId);
            return false;
        } else {
            runner.delete(condition);
            LOG.error("删除成功-dsType={},dsCode={},attrId={}",dsCode,dsType,attrId);
            return true;
        }
    }
    /**
     * 修改数据源属性映射
     * @param attrMap
     * @return
     */
    public boolean updateDsAttrMap(MetaAttrMappingVo attrMap) {
        // 查询属性映射
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"AttrMapping");
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",attrMap.getDs_code());
        conditionMap.put("ds_type",attrMap.getDs_type());
        conditionMap.put("attr_id",attrMap.getAttr_id());
        condition.buildColumns(conditionMap);
        condition.getMetaCI().setCache(false);
        DMDataPoint attrPoint = runner.get(condition);
        if (null == attrPoint) {
            LOG.error("更新失败-该属性映射信息不存在-dsType={},dsCode={},attrId={}",attrMap.getDs_type(),attrMap.getDs_code(),attrMap.getAttr_id());
            return false;
        }
        attrMap.setUpdate_ts((int)(System.currentTimeMillis()/1000));
        Map<String,Object> addMap = attrMap.buildAddParamsMap();
        DMDataPoint addCondition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS,MetaDeviceInstanceVO.DSCATEGORY,"AttrMapping");
        addCondition.buildColumns(addMap);
        //更新数据源对象
        runner.write(addCondition);
        LOG.info("更新成功--dsType={},dsCode={},attrId={}",attrMap.getDs_type(),attrMap.getDs_code(),attrMap.getAttr_id());
        return true;
    }
    /**
     * 查询数据源属性映射记录信息
     * @return
     */
    public List<MetaAttrMappingVo> findDsAttrMapList(Long dsCode) {
        DMDataPoint point = DMDataPoint.builder("ies","gwm","AttrMapping");
        DMDataColumn code = new DMDataColumn("ds_code",dsCode);
        point.addColumn(code);
        List<DMDataPoint> attrPointList = runner.list(point);
        if (CollectionUtils.isEmpty(attrPointList)) {
            LOG.error("数据库中无属性映射信息！");
            return null;
        }
        List<MetaAttrMappingVo> voList = Lists.newArrayList();

        for (int i = 0; i < attrPointList.size(); i++) {
            AttrMapping tempAttr = AttrMapping.buildAttrMapping(attrPointList.get(i));
            if (null == tempAttr || StringUtils.isEmpty(tempAttr.getMeta_attr_id()) || StringUtils.isEmpty(tempAttr.getDs_code())) {
                LOG.error("数据源属性映射记录查询失败-标准属性ID={},数据源编码={}",tempAttr.getMeta_attr_id(),tempAttr.getDs_code());
                continue;
            }
            MetaAttrMappingVo vo = new MetaAttrMappingVo();
            // 组装VO
            BeanUtils.copyProperties(tempAttr,vo);
            //查询产品类型作为CI
            Map<String,Object> keys = Maps.newHashMap();
            keys.put("NS","ies");
            keys.put("CATEGORY","urm");
            keys.put("ID",tempAttr.getMeta_attr_id());
            DMDataPoint dsPoint = DMDataPoint.builder("ies","gwm","DeviceDS");
            DMDataColumn codeColumn = new DMDataColumn("code",tempAttr.getDs_code());
            dsPoint.addColumn(codeColumn);
            DMDataPoint dsData = runner.get(dsPoint);
            DeviceDS deviceDS = DeviceDS.buildDeviceDS(dsData, false);
            if (null != deviceDS) {
                keys.put("CI",deviceDS.getDeviceType());
                // 查询标准属性详情
                DMMetaAttr metaAttr = runner.getMetaAttr(keys);
                if (null != metaAttr) {
                    vo.setMeta_attr_Name(metaAttr.getName());
                    vo.setMeta_attr_Type(metaAttr.getType());
                }
            } else {
                LOG.error("数据源属性映射记录查询失败-无该数据源信息，dsCode={}",tempAttr.getDs_code());
            }
            voList.add(vo);
        }
        return voList;
    }

}
