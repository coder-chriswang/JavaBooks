package com.neoway.iot.gwm.api.dictionary;

import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.handler.EnumDataHandler;
import com.neoway.iot.gwm.vo.DomainTreeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *    描述：统一接入管理枚举数据控制类
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/10/19 11:21
 */
@RestController
@RequestMapping("/v1/dictionaries")
@Api(tags = "统一接入管理下拉选择框数据管理")
public class DataDictionaryController {
    private static final Logger LOG = LoggerFactory.getLogger(DataDictionaryController.class);
    private EnumDataHandler handler = new EnumDataHandler();
    @ApiOperation("通信协议")
    @GetMapping("/protocol")
    public HttpResult<List<Map<String,String>>> getDeviceAccessProtocol() {
        try {
            List<Map<String,String>> protocol = handler.getDeviceAccessProtocol();
            return HttpResult.returnSuccess("通信协议获取成功！",protocol);
        } catch (Exception e) {
            LOG.error("通信协议获取异常！", e);
            return HttpResult.returnFail("通信协议获取异常！");
        }
    }

    @ApiOperation("接入方式")
    @GetMapping("/accesstype")
    public HttpResult<List<Map<String,String>>> getDeviceAccessType() {
        try {
            List<Map<String,String>> result = handler.getDeviceAccessType();
            return HttpResult.returnSuccess("接入方式获取成功！",result);
        } catch (Exception e) {
            LOG.error("接入方式获取异常！", e);
            return HttpResult.returnFail("接入方式获取异常！");
        }
    }
    @ApiOperation("消息格式")
    @GetMapping("/msgtype")
    public HttpResult<List<Map<String,String>>> getDeviceMsgType() {
        try {
            List<Map<String,String>> result = handler.getDeviceMsgType();
            return HttpResult.returnSuccess("消息类型获取成功！",result);
        } catch (Exception e) {
            LOG.error("消息类型获取异常！", e);
            return HttpResult.returnFail("消息类型获取异常！");
        }
    }

    @ApiOperation("产品领域")
    @GetMapping("/dsdomains")
    public HttpResult<List<DomainTreeVo>> getDeviceDomain() {
        try {
            List<DomainTreeVo> result = handler.getDeviceDomain();
            return HttpResult.returnSuccess("产品领域获取成功！",result);
        } catch (Exception e) {
            LOG.error("产品领域获取异常！", e);
            return HttpResult.returnFail("产品领域获取异常！");
        }
    }
    @ApiOperation("产品类别")
    @GetMapping("/devicetypes")
    public HttpResult<List<Map<String,String>>> getDeviceType() {
        try {
            List<Map<String,String>> result = handler.getDeviceType();
            return HttpResult.returnSuccess("产品类别获取成功！",result);
        } catch (Exception e) {
            LOG.error("产品类别获取异常！", e);
            return HttpResult.returnFail("产品类别获取异常！");
        }
    }
    @ApiOperation("产品租户")
    @GetMapping("/tenants")
    public HttpResult<List<Object>> getTenants() {
        try {
            List<Object> result = handler.getTenant();
            return HttpResult.returnSuccess("产品租户获取成功！",result);
        } catch (Exception e) {
            LOG.error("产品租户获取异常！", e);
            return HttpResult.returnFail("产品租户获取异常！");
        }
    }

    @ApiOperation("设备状态")
    @GetMapping("/status/dInstance")
    public HttpResult<List<Map<String, String>>> getDInstanceStatus() {
        try {
            List<Map<String, String>> result = handler.getDInstanceStatus();
            return HttpResult.returnSuccess("设备状态获取成功！",result);
        } catch (Exception e) {
            LOG.error("设备状态获取异常！", e);
            return HttpResult.returnFail("设备状态获取异常！");
        }
    }
    @ApiOperation("设备在线状态")
    @GetMapping("/dInstance/online")
    public HttpResult<List<Map<String, String>>> getDInstanceOnLine() {
        try {
            List<Map<String, String>> result = handler.getDInstanceOnLine();
            return HttpResult.returnSuccess("设备在线状态值获取成功！",result);
        } catch (Exception e) {
            LOG.error("设备在线状态值获取异常！", e);
            return HttpResult.returnFail("设备在线状态值获取异常！");
        }
    }

    @ApiOperation("连通性状态")
    @GetMapping("/status/connectivity")
    public HttpResult<List<Map<String, String>>> getConnectivityStatus() {
        try {
            List<Map<String, String>> result = handler.getConnectivityStatus();
            return HttpResult.returnSuccess("连通性状态获取成功！",result);
        } catch (Exception e) {
            LOG.error("连通性状态获取异常！", e);
            return HttpResult.returnFail("联通性状态获取异常！");
        }
    }

    @ApiOperation("RESTFUL_3RD_MENU")
    @GetMapping("/sinstance/menu")
    public HttpResult<List<Map<String, String>>> getRestful3rdMenu() {
        try {
            List<Map<String, String>> result = handler.getRestful3rdMenu();
            return HttpResult.returnSuccess("第三方数据源菜单获取成功！",result);
        } catch (Exception e) {
            LOG.error("第三方数据源菜单获取异常！", e);
            return HttpResult.returnFail("第三方数据源菜单获取异常！");
        }
    }

    @ApiOperation("RESTFUL_3RD接入协议类型")
    @GetMapping("/sinstance/protocol")
    public HttpResult<List<Map<String, String>>> getRestful3rdProcotol() {
        try {
            List<Map<String, String>> result = handler.getRestful3rdProcotol();
            return HttpResult.returnSuccess("第三方数据源协议类型获取成功！",result);
        } catch (Exception e) {
            LOG.error("第三方数据源协议类型获取异常！", e);
            return HttpResult.returnFail("第三方数据源协议类型获取异常！");
        }
    }

    @ApiOperation("RESTFUL_3RD接入--认证方式")
    @GetMapping("/sinstance/authway")
    public HttpResult<List<Map<String, String>>> getAuthWay() {
        try {
            List<Map<String, String>> result = handler.getAuthWay();
            return HttpResult.returnSuccess("第三方数据源实例认证方式获取成功！",result);
        } catch (Exception e) {
            LOG.error("第三方数据源实例认证方式获取异常！", e);
            return HttpResult.returnFail("第三方数据源实例认证方式获取异常！");
        }
    }

    @ApiOperation("模板映射方式")
    @GetMapping("/template/method")
    public HttpResult<List<Map<String, String>>> getTemplateMethod() {
        try {
            List<Map<String, String>> result = handler.getTemplateMethod();
            return HttpResult.returnSuccess("模板映射方式获取成功！",result);
        } catch (Exception e) {
            LOG.error("模板映射方式获取异常！", e);
            return HttpResult.returnFail("模板映射方式获取异常！");
        }
    }
    @ApiOperation("数据源类型")
    @GetMapping("/dstype")
    public HttpResult<List<Map<String, String>>> getDsType() {
        try {
            List<Map<String, String>> result = handler.getDsType();
            return HttpResult.returnSuccess("数据源类型获取成功！",result);
        } catch (Exception e) {
            LOG.error("数据源类型获取异常！", e);
            return HttpResult.returnFail("数据源类型获取异常！");
        }
    }
}
