package com.neoway.iot.gwm.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.neoway.iot.sdk.dmk.meta.DMMetaColumnDBAnno;

import java.io.Serializable;

/**
 * <pre>
 *  描述：设备数据源信息导出模板类
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/27 18:02
 */
@ContentRowHeight(15)
@HeadRowHeight(20)
@ColumnWidth(25)
public class DeviceInfoModelExport implements Serializable {
    private static final long serialVersionUID = 4627959105276925539L;
    @ExcelProperty(value = "设备数据源编码", index = 0)
    private String deviceds_id;
    @ExcelProperty(value = "设备名称", index = 1)
    private String name;
    @ExcelProperty(value = "设备ID", index = 2)
    private String instanceId;
    @ExcelProperty(value = "产品类别", index = 3)
    private String device_type;
    @ExcelProperty(value = "租户", index = 4)
    private String tenant;
    @ExcelProperty(value = "IMEI", index = 5)
    private String nativeId;
    @ExcelProperty(value ="创建时间", index = 6)
    private int rt;
    @ExcelProperty(value ="最后连接时间", index = 7)
    private int lt;
    @ExcelProperty(value = "设备状态", index = 8)
    private String status;
    @ExcelProperty(value = "在线状态", index = 9)
    private String onLine;

    public String getDeviceds_id() {
        return deviceds_id;
    }

    public void setDeviceds_id(String deviceds_id) {
        this.deviceds_id = deviceds_id;
    }

    public String getDevice_type() {
        return device_type;
    }

    public void setDevice_type(String device_type) {
        this.device_type = device_type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

    public int getRt() {
        return rt;
    }

    public void setRt(int rt) {
        this.rt = rt;
    }

    public int getLt() {
        return lt;
    }

    public void setLt(int lt) {
        this.lt = lt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOnLine() {
        return onLine;
    }

    public void setOnLine(String onLine) {
        this.onLine = onLine;
    }
}
