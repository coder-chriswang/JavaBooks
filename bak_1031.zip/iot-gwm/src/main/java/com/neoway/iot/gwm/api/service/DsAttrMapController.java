package com.neoway.iot.gwm.api.service;

import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.handler.DsAttrMapHandler;
import com.neoway.iot.gwm.vo.MetaAttrMappingVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <pre>
 *  描述：属性映射管理
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 19:02
 */
@RestController
@RequestMapping("/v1/attrmap")
@Api(tags = "属性映射管理")
public class DsAttrMapController {
    private static final Logger LOG = LoggerFactory.getLogger(DsAttrMapController.class);
    private DsAttrMapHandler handler = new DsAttrMapHandler();
    @ApiOperation("新增数据源属性映射信息")
    @PostMapping
    public HttpResult addDsAttrMap(@RequestBody MetaAttrMappingVo attrMap) {
        if (null == attrMap.getDs_code() || StringUtils.isBlank(attrMap.getDs_type()) || StringUtils.isBlank(attrMap.getAttr_id())) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result = handler.addDsAttrMap(attrMap);
            if (result) {
                return HttpResult.returnSuccess("属性映射信息添加成功！");
            } else {
                return HttpResult.returnFail("重复添加了属性映射信息");
            }
        } catch (Exception e) {
            LOG.error("数据源属性映射信息添加异常！", e);
            return HttpResult.returnFail("数据源属性映射信息添加异常！");
        }
    }

    @ApiOperation("删除数据源属性映射信息")
    @DeleteMapping("/{dsCode}/{dsType}/{attrId}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "dsCode",value = "数据源编码",dataType = "Long",required = true),
            @ApiImplicitParam(name = "dsType",value = "数据源类型",dataType = "String",required = true),
            @ApiImplicitParam(name = "attrId",value = "属性ID",dataType = "String",required = true)
    })
    public HttpResult deleteDsAttrMap(@PathVariable(value = "dsCode") Long dsCode,@PathVariable(value = "dsType") String dsType,@PathVariable(value = "attrId") String attrId) {
        if (dsCode == null || StringUtils.isBlank(dsType) || StringUtils.isBlank(attrId)) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result = handler.deleteDsAttrMap(dsCode,dsType,attrId);
            if (result) {
                return HttpResult.returnSuccess("属性映射删除成功！");
            } else {
                return HttpResult.returnFail("删除失败--该属性映射不存在");
            }
        } catch (Exception e) {
            LOG.error("数据源属性映射信息删除失败！", e);
            return HttpResult.returnFail("数据源属性映射信息删除失败！");
        }
    }

    @ApiOperation("编辑数据源属性映射信息")
    @PutMapping
    public HttpResult updateDsAttrMap(@RequestBody MetaAttrMappingVo attrMap) {
        if (null == attrMap.getDs_code() || StringUtils.isBlank(attrMap.getDs_type()) || StringUtils.isBlank(attrMap.getAttr_id())) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }

        try {
            boolean result = handler.updateDsAttrMap(attrMap);
            if (result) {
                return HttpResult.returnSuccess("修改成功");
            } else {
                return HttpResult.returnFail("修改失败--该记录不存在!");
            }
        } catch (Exception e) {
            LOG.error("数据源属性映射信息更新异常！", e);
            return HttpResult.returnFail("数据源属性映射信息更新异常！");
        }
    }
    @ApiOperation("查询数据源属性映射信息记录集")
    @GetMapping("/{dsCode}")
    @ApiImplicitParam(name = "dsCode",value = "产品标识",dataType = "Long",required = true)
    public HttpResult<List<MetaAttrMappingVo>> findDsAttrMap(@PathVariable(value = "dsCode") Long dsCode) {
        try {
            List<MetaAttrMappingVo> result = handler.findDsAttrMapList(dsCode);
            return HttpResult.returnSuccess("属性映射记录集查询成功",result);

        } catch (Exception e) {
            LOG.error("数据源属性映射记录集查询失败！", e);
            return HttpResult.returnFail("数据源属性映射记录集查询失败！");
        }
    }
}
