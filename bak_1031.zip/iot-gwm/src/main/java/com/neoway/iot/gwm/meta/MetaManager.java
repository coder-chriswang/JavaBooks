package com.neoway.iot.gwm.meta;

import com.neoway.iot.gwm.common.GwmEnv;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.gwk.GWKRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileFilter;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: 产品域模型管理
 * @author: 20200312686
 * @date: 2020/8/28 15:35
 */
public class MetaManager {
    private static final Logger LOG = LoggerFactory.getLogger(MetaManager.class);
    private static final String MODELS_DIR_DEVICE="etc"+File.separator+"models-adapter-device";
    private static final String MODELS_DIR_SERVICE="etc"+File.separator+"models-adapter-service";
    private static final String SCHEDULER_NAME="gwm-scan-models";
    private static final int DEFAULT_INTERVAL=60;
    private static MetaManager manager=null;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private GWKRunner runner;
    private MetaManager() {
        this.runner = GWKRunner.getInstance();
    }
    public static MetaManager getInstance() {
        if (manager == null) {
            synchronized (MetaManager.class) {
                if (manager == null) {
                    manager = new MetaManager();
                }
            }
        }
        return manager;
    }

    /**
     * 启动
     */
    public void start(){
        if(isStarted.get()){
            return;
        }
        this.initModelsDeviceAdapter();
        this.initModelsServiceAdapter();
        this.initRunner(DEFAULT_INTERVAL);
        isStarted.set(true);
    }
    /**
     * 设备模型包初始化
     * @return
     */
    public void initModelsDeviceAdapter(){
        LOG.info("开始进行设备适配模型包初始化");
        try{
            String modelPath=GwmEnv.getInstance().getEnv("models.adapter.device");
            File f=new File(modelPath);
            if(!f.exists()){
                return;
            }
            File[] extDirs=f.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    return pathname.isDirectory();
                }
            });

            for(File extDir:extDirs){
                String extModelDir=extDir.getAbsolutePath()+File.separator+MODELS_DIR_DEVICE;
                File extModelFile=new File(extModelDir);
                if(!extModelFile.exists()){
                    continue;
                }
                File[] extModels=extModelFile.listFiles(new FileFilter() {
                    @Override
                    public boolean accept(File pathname) {
                        return pathname.isDirectory();
                    }
                });
                LOG.info("项目定制包:{} 设备数据源开始初始化",extDir.getName());
                for(File dsFile:extModels){
                    this.runner.addTemplateDeviceDs(dsFile.getAbsolutePath());
                }
                LOG.info("项目定制包:{} 设备数据源结束初始化",extDir.getName());
            }
        }finally {
            LOG.info("结束进行设备适配模型包初始化");
        }


    }
    /**
     * 系统模型包初始化
     * @return
     */
    public void initModelsServiceAdapter(){
        LOG.info("开始系统设备适配模型包初始化");
        try{
            String modelPath=GwmEnv.getInstance().getEnv("models.adapter.service");
            File f=new File(modelPath);
            if(!f.exists()){
                return;
            }
            File[] extDirs=f.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    return pathname.isDirectory();
                }
            });
            for(File extDir:extDirs){
                String extModelDir=extDir.getAbsolutePath()+File.separator+MODELS_DIR_SERVICE;
                File extModelFile=new File(extModelDir);
                if(!extModelFile.exists()){
                    continue;
                }
                File[] extModels=extModelFile.listFiles(new FileFilter() {
                    @Override
                    public boolean accept(File pathname) {
                        return pathname.isDirectory();
                    }
                });
                LOG.info("项目定制包:{} 系统数据源开始初始化",extDir.getName());
                for(File dsFile:extModels){
                    this.runner.addTemplateSystemDs(dsFile.getAbsolutePath());
                }
                LOG.info("项目定制包:{} 系统数据源结束初始化",extDir.getName());
            }
        }finally {
            LOG.info("结束进行系统适配模型包初始化");
        }


    }

    /**
     * @desc 定时执行初始化
     * @param interval
     * @return 定时器服务
     */
    public ScheduledExecutorService initRunner(int interval){
        ScheduledExecutorService initRunner = Executors.newSingleThreadScheduledExecutor(
                (r) -> {
                    Thread t = new Thread(r, SCHEDULER_NAME);
                    t.setDaemon(true);
                    return t;
                }
        );
        initRunner.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try{
                    initModelsDeviceAdapter();
                    initModelsServiceAdapter();
                }catch (Exception e){
                    LOG.error(e.getMessage(),e);
                }

            }
        }, interval, interval, TimeUnit.SECONDS);
        return initRunner;
    }
}
