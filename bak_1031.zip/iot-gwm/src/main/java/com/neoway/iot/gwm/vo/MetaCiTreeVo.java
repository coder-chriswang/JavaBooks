package com.neoway.iot.gwm.vo;

import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * <pre>
 *   描述：管理资源VO
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/10/14 20:03
 */
@ApiModel("管理资源VO")
public class MetaCiTreeVo {
    @ApiModelProperty(value = "管理对象类型")
    private String type;
    @ApiModelProperty(value = "管理对象列表")
    private List<DMMetaCI> ciList;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<DMMetaCI> getCiList() {
        return ciList;
    }

    public void setCiList(List<DMMetaCI> ciList) {
        this.ciList = ciList;
    }
}
