package com.neoway.iot.gwm.handler;

import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.hash.Hashing;
import com.neoway.iot.gwm.common.ExcelUtil;
import com.neoway.iot.gwm.common.PageInfo;
import com.neoway.iot.gwm.entity.DeviceInfoModelExport;
import com.neoway.iot.gwm.entity.DeviceInfoModelImport;
import com.neoway.iot.gwm.entity.MetaDeviceInstance;
import com.neoway.iot.gwm.handler.listener.UploadDeviceInfoListener;
import com.neoway.iot.gwm.vo.MetaDeviceInstanceVO;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.common.db.DMSQL;
import com.neoway.iot.sdk.dmk.common.util.DMUtil;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.DeviceInstance;
import com.neoway.iot.sdk.gwk.entity.GWKEnum;
import com.neoway.iot.sdk.gwk.entity.Status;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *   描述：设备数据源实例处理器
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 19:18
 */

public class DeviceInstanceHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DeviceInstanceHandler.class);
    private DMRunner runner;

    public DeviceInstanceHandler() {
        this.runner = DMRunner.getInstance();
    }

    /**
     * 查询设备详情总记录数
     */
    private static String DML_DEVICEINSTANCE_GET_TOTAL="SELECT COUNT(*) FROM GWM_B_DEVICEINSTANCE di LEFT JOIN GWM_B_DEVICEDS ds ON " +
            "di.`deviceds_id` = ds.`code` LEFT JOIN GWM_B_STATUS st ON di.`instanceid` = st.`instanceid`  WHERE 1=1 {0}";

    /**
     * 分页查询设备数据源实例列表
     */
    private static String DML_DEVICEINSTANCE_QUERY = "SELECT di.`name`,di.`instanceid`,di.`nativeid`,di.`deviceds_id`,di.`rt`,di.`lt`," +
                                     "ds.`device_type`,ds.`tenant`,di.`status`,st.`status` as onLine FROM GWM_B_DEVICEINSTANCE di LEFT JOIN" +
                                     " GWM_B_DEVICEDS ds ON di.`deviceds_id` = ds.`code` LEFT JOIN GWM_B_STATUS st ON di.`instanceid` = st.`instanceid`  WHERE 1=1 {0} LIMIT ?,?";



    /**
     * 增加设备
     *
     * @param dInstance
     * @return
     */
    public boolean addDeviceInstance(MetaDeviceInstanceVO dInstance) {
        //生成主键code
        String key = RandomStringUtils.random(15, true, true)+ System.currentTimeMillis();
        long instanceId = DMUtil.getHashCode(key);
        // 查询设备
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, MetaDeviceInstanceVO.DSCI);
        DMDataColumn column = new DMDataColumn("instanceid", String.valueOf(instanceId));
        condition.addColumn(column);
        condition.getMetaCI().setCache(false);
        DMDataPoint dsInstancePoint = runner.get(condition);
        DeviceInstance dsInstance = (DeviceInstance)DMUtil.buildClazzInstance(dsInstancePoint,DeviceInstance.class);
        if (null != dsInstance) {
            LOG.error("该设备已存在，重复添加，name={},nativeId={}", dInstance.getName(), dInstance.getNativeId());
            return false;
        }
        dInstance.setInstanceid(instanceId);
        dInstance.setStatus(GWKEnum.DsInstanceStatus.DSINSTANCE_INACTIVE.name());
        dInstance.setRt(Integer.valueOf(String.valueOf(System.currentTimeMillis()/1000)));
        DMDataPoint device = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, MetaDeviceInstanceVO.DSCI);
        //封装参数
        Map<String, Object> paramColumns = dInstance.builderCloumns();
        device.buildColumns(paramColumns);
        //插入数据源实例对象
        LOG.info("插入设备数据源实例记录，instanceid={}",instanceId);
        runner.write(device);
        LOG.info("插入设备状态记录，instanceid={}",instanceId);
        Status status = new Status();
        status.setDs_type(GWKEnum.DsType.DEVICE.name());
        status.setInstanceid(instanceId);
        status.setStatus(GWKEnum.DsStatus.UNKOWN.name());
        status.setLt((int) (System.currentTimeMillis()/1000));
        DMDataPoint statusPoint = status.buildDataPoint();
        runner.write(statusPoint);
        return true;

    }

    /**
     * 根据设备Id删除设备记录
     *
     * @param instanceId
     */
    public boolean deleteDeviceDs(String instanceId) {
        //查看该设备是否存在
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, MetaDeviceInstanceVO.DSCI);
        DMDataColumn column = new DMDataColumn("instanceId", instanceId,true);
        condition.addColumn(column);
        condition.getMetaCI().setCache(false);
        DMDataPoint point = runner.get(condition);
        DeviceInstance deviceInstance = (DeviceInstance)DMUtil.buildClazzInstance(point,DeviceInstance.class);
        if (null == deviceInstance) {
            LOG.error("删除失败--该设备不存在，设备ID={}", instanceId);
            return false;
        }
        condition.getMetaCI().setCache(false);
        runner.delete(condition);
        // 删除状态表中对应的记录
        DMDataPoint statusPoint = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, "Status");
        DMDataColumn column1 = new DMDataColumn("instanceId", instanceId);
        statusPoint.addColumn(column1);
        runner.delete(statusPoint);
        return true;
    }

    /**
     * 更新设备数据源实例
     *
     * @param dInstance 设备数据源实例
     * @return
     */
    public boolean updateDeviceInstance(MetaDeviceInstanceVO dInstance) {
        //查看该设备是否存在
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, MetaDeviceInstanceVO.DSCI);
        DMDataColumn column = new DMDataColumn("instanceid", dInstance.getInstanceid(),true);
        condition.addColumn(column);
        condition.getMetaCI().setCache(false);
        DMDataPoint point = runner.get(condition);
        DeviceInstance deviceInstance = (DeviceInstance)DMUtil.buildClazzInstance(point,DeviceInstance.class);
        if (null == deviceInstance) {
            LOG.error("更新失败--该设备不存在，设备ID={}", dInstance.getInstanceid());
            return false;
        }
        DMDataPoint device = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, MetaDeviceInstanceVO.DSCI);
        Map<String, Object> paramColumns = dInstance.builderCloumns();
        device.buildColumns(paramColumns);
        runner.write(device);
        return true;
    }

    /**
     * 获取设备数据源实例详情
     *
     * @param instanceId 设备数据源实例id
     * @return
     */
    public MetaDeviceInstanceVO getDeviceDSInstance(Long instanceId) {
        MetaDeviceInstanceVO dsInstanceVo = new MetaDeviceInstanceVO();
        DMDataPoint condition = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, MetaDeviceInstanceVO.DSCI);
        DMDataColumn column = new DMDataColumn("instanceid", instanceId,true);
        condition.addColumn(column);
        condition.getMetaCI().setCache(false);
        DMDataPoint point = runner.get(condition);
        MetaDeviceInstance dInstance = (MetaDeviceInstance) DMUtil.buildClazzInstance(point, MetaDeviceInstance.class);
        if (null != dInstance) {
            BeanUtils.copyProperties(dInstance, dsInstanceVo);
            //获取设备数据源信息
            DMDataPoint ds = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, "DeviceDS");
            DMDataColumn columnDs = new DMDataColumn("code", dInstance.getDeviceds_id());
            condition.addColumn(columnDs);
            ds.getMetaCI().setCache(false);
            DMDataPoint dsPoint = runner.get(ds);
            if (null != dsPoint) {
                DeviceDS deviceDS = DeviceDS.buildDeviceDS(dsPoint, true);
                dsInstanceVo.setDevice_type(deviceDS.getDeviceType());
                dsInstanceVo.setTenant(deviceDS.getTenant());
            }
            //获取设备在线状态
            DMDataPoint status = DMDataPoint.builder(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY, "Status");
            Map<String, Object> columns = Maps.newHashMap();
            columns.put("ds_type", GWKEnum.DsType.DEVICE.getDesc());
            columns.put("instanceid", instanceId);
            status.buildColumns(columns);
            status.getMetaCI().setCache(false);
            DMDataPoint statusPoint = runner.get(status);
            Map<String, Object> statusMap = statusPoint.buildMapValue();
            if (null != statusMap) {
                dsInstanceVo.setOnLine((String) statusMap.getOrDefault("status",""));
            }
        } else {
            LOG.error("获取设备详情失败，无此设备instanceId={}", instanceId);
            return null;
        }
        return dsInstanceVo;
    }

    /**
     * 条件查询设备数据源实例列表
     * 封装查询条件
     * 设备表：GWM_B_DEVICEINSTANCE as di,涉及的搜索条件：设备状态，IMEI,设备ID
     * 产品表：GWM_B_DEVICEDS    as  ds,涉及的搜索条件：产品类型
     * 状态表：GWM_B_STATUS  as st, 涉及的搜索条件：在线状态
     *
     * @param pageSize 每一页条数
     * @param pageNum  当前第几页
     * @return
     */
    public PageInfo<MetaDeviceInstanceVO> findDeviceDsInstanceList(MetaDeviceInstanceVO dsInstanceVo, Integer pageSize, Integer pageNum) {
        try {
            LOG.info("开始分页查询设备记录，pageSize={},pageNum={}", pageSize, pageNum);
            PageInfo<MetaDeviceInstanceVO> pageInfo = new PageInfo<>();
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY));
            //获取总记录数
            Connection cnn = DMPool.getInstance().getNsDataSource(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY).getConnection();
            Map<String, Object> paramMap = getWhere(dsInstanceVo);
            //格式SQL
            String where = (String) paramMap.get("where");
            String sqlTotal = MessageFormat.format(DML_DEVICEINSTANCE_GET_TOTAL,where);
            String sqlList = MessageFormat.format(DML_DEVICEINSTANCE_QUERY,where);
            List<Object> columnList = (List<Object>)paramMap.get("columnList");
            try {
                //获取记录总数
                Object[] totalParams = columnList.toArray();
                long total = (long) runner.query(cnn,sqlTotal, new ScalarHandler(1),totalParams);;
                int pageSum = Integer.valueOf(Long.toString(total)) / pageSize + 1;
                //获取列表数据
                columnList.add((pageNum - 1) * pageSize);
                columnList.add(pageSize);
                List<MetaDeviceInstanceVO> pageData;
                Object[] listParams = columnList.toArray();
                pageData = runner.query(sqlList, new BeanListHandler<>(MetaDeviceInstanceVO.class), listParams);
                pageInfo.setPageSum(pageSum);
                pageInfo.setRecordsTotal(Integer.valueOf(Long.toString(total)));
                pageInfo.setCurrentPageContent(pageData);
            } finally {
                if (cnn != null) {
                    cnn.close();
                }
            }
            LOG.info("分页查询设备记录完成");
            return pageInfo;
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
            throw new RuntimeException("分页查询设备详情记录列表出错:" + e.getMessage());
        }
    }


    /**
     * 下载设备信息模板
     *
     * @param response
     */
    public void exportDeviceInfoModeL(HttpServletResponse response) throws Exception {
        ExcelUtil.export(response, "DeviceInfo-Template", "设备信息模板", DeviceInfoModelImport.class, new ArrayList<>());
    }

    /**
     * 导入设备信息
     *
     * @param file
     * @return
     */
    public List<String> uploadDeviceInfoData(MultipartFile file,Long code) {
        try {
            UploadDeviceInfoListener listener = new UploadDeviceInfoListener();
            listener.setCode(code);
            ExcelUtil.upload(file, DeviceInfoModelImport.class, listener);
            return listener.getErrorInfo();
        } catch (ExcelAnalysisException e) {
            LOG.error("导入设备信息数据失败！", e);
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            LOG.error("导入设备信息数据失败！", e);
            throw new RuntimeException("导入设备信息数据失败！");
        }
    }

    /**
     * 批量导入数据
     *
     * @param instanceVOList
     * @return 错误信息
     */
    public String batchAdd(List<MetaDeviceInstanceVO> instanceVOList) {
        StringBuilder sb = new StringBuilder();
        if (!CollectionUtils.isEmpty(instanceVOList)) {
            instanceVOList.forEach(r -> {
                boolean result = addDeviceInstance(r);
                if (!result) {
                    sb.append("设备IMEI：").append(r.getNativeId()).append("已存在！");
                }
            });
        }
        return sb.toString();
    }

    /**
     * 导出设备详情信息
     *
     * @param deviceInstance
     * @param response
     */
    public void exportDeviceInfoList(MetaDeviceInstanceVO deviceInstance, int pageSize, int pageNum, HttpServletResponse response) {
        try {
            LOG.info("开始导出设备信息！");
            List<DeviceInfoModelExport> deviceInfoList;
            QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY));
            Map<String, Object> paramMap = getWhere(deviceInstance);
            //格式SQL
            String where = (String) paramMap.get("where");
            String sqlList = MessageFormat.format(DML_DEVICEINSTANCE_QUERY,where);
            List<Object> columnList = (List<Object>)paramMap.get("columnList");
            //获取列表数据
            columnList.add((pageNum - 1) * pageSize);
            columnList.add(pageSize);

            Object[] listParams = columnList.toArray();
            deviceInfoList = runner.query(sqlList, new BeanListHandler<>(DeviceInfoModelExport.class), listParams);
            ExcelUtil.export(response, "DeviceInfoList", "设备信息", DeviceInfoModelExport.class, deviceInfoList);
            LOG.info("导出设备信息完成！");
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
            throw new RuntimeException("分页查询设备详情记录列表出错:" + e.getMessage());
        } catch (Exception e) {
            LOG.error("导处设备信息数据！", e);
            throw new RuntimeException("导入设备信息数据失败！");
        }
    }

    private String getWhereString(MetaDeviceInstanceVO dsInstanceVo) {
        String where = null;
        if (StringUtils.isNotBlank(dsInstanceVo.getStatus())) {
            where = " AND di.`status` = " + "\'" +dsInstanceVo.getStatus()+ "\'";
        }

        if (StringUtils.isNotBlank(dsInstanceVo.getNativeId()) && StringUtils.isNotBlank(where)) {
            where = where + " AND di.`nativeid` = " + "\'" + dsInstanceVo.getNativeId()+ "\'";
        } else if (StringUtils.isNotBlank(dsInstanceVo.getNativeId()) && StringUtils.isBlank(where)) {
            where = " AND di.`nativeid` = " + "\'" + dsInstanceVo.getNativeId() + "\'";
        }

//        if (dsInstanceVo.getInstanceid() != 0 && StringUtils.isNotBlank(where)) {
//            where = where + " AND di.`instanceid` = " + dsInstanceVo.getInstanceid();
//        } else if (dsInstanceVo.getInstanceid() != 0 && StringUtils.isBlank(where)) {
//            where = " AND di.`instanceid` = " + dsInstanceVo.getInstanceid();
//        }
        if (StringUtils.isNotBlank(dsInstanceVo.getDevice_type()) && StringUtils.isNotBlank(where)) {
            where = where + " AND ds.`device_type` = " + "\'" + dsInstanceVo.getDevice_type()+ "\'";
        } else if (StringUtils.isNotBlank(dsInstanceVo.getDevice_type()) && StringUtils.isBlank(where)) {
            where = " AND ds.`device_type` = "+ "\'"  + dsInstanceVo.getDevice_type()+ "\'";
        }
        if (StringUtils.isNotBlank(dsInstanceVo.getOnLine()) && StringUtils.isNotBlank(where)) {
            where = where + " AND st.`status` = "+ "\'"  + dsInstanceVo.getOnLine()+ "\'";
        } else if (StringUtils.isNotBlank(dsInstanceVo.getOnLine()) && StringUtils.isBlank(where)) {
            where = " AND st.`status` = " + "\'" + dsInstanceVo.getOnLine()+ "\'";
        }
        return where;
    }

    /**
     * dsInstanceVo.getDeviceds_id()一定有值
     * @param dInstanceVO
     * @return
     * @throws SQLException
     */
    public PageInfo<MetaDeviceInstanceVO> findList(MetaDeviceInstanceVO dInstanceVO,int pageSize,int pageNum) throws SQLException {
        /**
         * 查询设备详情总记录数
         */
        String DML_DEVICEINSTANCE_GET_TOTAL="SELECT COUNT(*) FROM GWM_B_DEVICEINSTANCE di LEFT JOIN GWM_B_DEVICEDS ds ON " +
                "di.`deviceds_id` = ds.`code` LEFT JOIN GWM_B_STATUS st ON di.`instanceid` = st.`instanceid`  WHERE 1=1 {0}";
        /**
         * 分页查询设备数据源实例列表
         */
         String DML_DEVICEINSTANCE_QUERY = "SELECT di.`name`,di.`instanceid`,di.`nativeid`,di.`deviceds_id`,di.`lt`," +
                "ds.`device_type`,ds.`tenant`,di.`status`,st.`status` as onLine FROM GWM_B_DEVICEINSTANCE di LEFT JOIN" +
                " GWM_B_DEVICEDS ds ON di.`deviceds_id` = ds.`code` LEFT JOIN GWM_B_STATUS st ON di.`instanceid` = st.`instanceid`  WHERE 1=1 {0} LIMIT ?,?";
        Map<String, Object> paramMap = getWhere(dInstanceVO);
        //格式SQL
        String where = (String) paramMap.get("where");
        String sqlTotal = MessageFormat.format(DML_DEVICEINSTANCE_GET_TOTAL,where);
        String sqlList = MessageFormat.format(DML_DEVICEINSTANCE_QUERY,where);
        List<Object> columnList = (List<Object>)paramMap.get("columnList");
        Object[] totalParams = columnList.toArray();
        //构建列表查询参数
//        columnList.add();

        PageInfo<MetaDeviceInstanceVO> pageInfo = new PageInfo<>();
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY));
        //获取总记录数
        Connection cnn = DMPool.getInstance().getNsDataSource(MetaDeviceInstanceVO.DSNS, MetaDeviceInstanceVO.DSCATEGORY).getConnection();
        long total = (long) runner.query(cnn, sqlTotal, new ScalarHandler(1),totalParams);
        LOG.info("总记录数={}",total);
        return null;
    }
    private Map<String,Object> getWhere(MetaDeviceInstanceVO dsInstanceVo) {
        Map<String,Object> result = Maps.newHashMap();
        StringBuilder where = new StringBuilder();
        List<Object> columnList = Lists.newArrayList();
        if (StringUtils.isNotBlank(dsInstanceVo.getStatus())) {
            where.append(" AND di.`status` = ?");
            columnList.add(dsInstanceVo.getStatus());
        }
        if (StringUtils.isNotBlank(dsInstanceVo.getNativeId()) ) {
            where.append(" AND di.`nativeid` = ?");
            columnList.add(dsInstanceVo.getNativeId());
        }

        if (dsInstanceVo.getInstanceid() != null) {
           where.append(" AND di.`instanceid` = ?");
            columnList.add(dsInstanceVo.getInstanceid());
        }
        if (StringUtils.isNotBlank(dsInstanceVo.getDevice_type())) {
            where.append(" AND ds.`device_type` = ?");
            columnList.add(dsInstanceVo.getDevice_type());

        }
        if (StringUtils.isNotBlank(dsInstanceVo.getOnLine())) {
            where.append(" AND st.`status` = ?");
            columnList.add(dsInstanceVo.getOnLine());
        }
        if (dsInstanceVo.getDeviceds_id() != null) {
            where.append(" AND ds.`code` = ?");
            columnList.add(dsInstanceVo.getDeviceds_id());
        }
        if (StringUtils.isNotBlank(where.toString())) {
            result.put("where",where.toString());
        }
        if (columnList.size() > 0) {
            result.put("columnList",columnList);
        }
        return result;
    }

    /**
     * p
     * @param instanceIds
     * @return
     */
    public String batchDelete(String[] instanceIds) {
        LOG.info("开始批量删除设备记录！");
        StringBuilder error = new StringBuilder();
        for (int i = 0; i < instanceIds.length; i++) {
            boolean result = deleteDeviceDs(instanceIds[i]);
            if (!result) {
                LOG.error("设备删除失败，instanceid={}",instanceIds[i]);
                error.append(String.valueOf(instanceIds[i])).append(",");
            }
        }
        String result = error.toString();
        if (StringUtils.isNotBlank(result)) {
            result = result.substring(0,result.length()-1);
        }
        LOG.info("批量删除设备记录完成！");
        return result;
    }
}
