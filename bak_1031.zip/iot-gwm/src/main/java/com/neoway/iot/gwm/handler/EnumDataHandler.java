package com.neoway.iot.gwm.handler;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neoway.iot.gwm.vo.DomainTreeVo;
import com.neoway.iot.gwm.vo.TradeTreeVo;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.GWKEnum;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ColumnListHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * <pre>
 *   描述：枚举类数据handler
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/10/19 13:41
 */

public class EnumDataHandler {
    public static final Logger LOG = LoggerFactory.getLogger(EnumDataHandler.class);
    private DMRunner runner;

    public EnumDataHandler() {
        this.runner = DMRunner.getInstance();
    }
    /**
     * 获取数据源类型
     *
     * @return
     */
    public List<Map<String, String>> getDsType() {
        LOG.info("开始查询数据源类型");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.DsType[] dsTypes = GWKEnum.DsType.values();
        if (dsTypes.length == 0) {
            LOG.error("数据源类型不存在");
            return null;
        }
        for (GWKEnum.DsType type : dsTypes) {
            if (StringUtils.isNotBlank(type.name())&&StringUtils.isNotBlank(type.getDesc())) {
                Map<String, String> protocolMap = Maps.newHashMap();
                protocolMap.put("value",type.name());
                protocolMap.put("label",type.getDesc());
                list.add(protocolMap);
            }
        }

        LOG.info("查询数据源类型结束！");
        return list;
    }

    /**
     * 获取设备接入协议
     *
     * @return
     */
    public List<Map<String, String>> getDeviceAccessProtocol() {
        LOG.info("开始查询设备接入协议类型");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.DeviceAccessProtocol[] protocols = GWKEnum.DeviceAccessProtocol.values();
        if (protocols.length == 0) {
            LOG.error("设备接入协议不存在");
            return null;
        }
        for (GWKEnum.DeviceAccessProtocol protocol : protocols) {
            if (StringUtils.isNotBlank(protocol.name())&&StringUtils.isNotBlank(protocol.getDesc())) {
                Map<String, String> protocolMap = Maps.newHashMap();
                protocolMap.put("value",protocol.name());
                protocolMap.put("label",protocol.getDesc());
                list.add(protocolMap);
            }
        }

        LOG.info("查询设备接入协议类型结束！");
        return list;
    }
    /**
     * 获取设备接入方式
     *
     * @return
     */
    public List<Map<String, String>> getDeviceAccessType() {
        LOG.info("开始查询设备接入方式");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.DeviceAccessType[] accessTypes = GWKEnum.DeviceAccessType.values();
        if (accessTypes.length == 0) {
            LOG.error("设备接入方式不存在");
            return null;
        }
        for (GWKEnum.DeviceAccessType type : accessTypes) {
            if (StringUtils.isNotBlank(type.name())&&StringUtils.isNotBlank(type.getDesc())) {
                Map<String, String> typeMap = Maps.newHashMap();
                typeMap.put("value",type.name());
                typeMap.put("label",type.getDesc());
                list.add(typeMap);
            }
        }
        LOG.info("查询设备接入方式结束！");
        return list;
    }

    /**
     * 获取设备接入-消息类型
     *
     * @return
     */
    public List<Map<String, String>> getDeviceMsgType() {
        LOG.info("开始查询设备接入-消息类型");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.DeviceMsgType[] msgTypes = GWKEnum.DeviceMsgType.values();
        if (msgTypes.length == 0) {
            LOG.error("设备接入-消息类型不存在");
            return null;
        }
        for (GWKEnum.DeviceMsgType type : msgTypes) {
            if (StringUtils.isNotBlank(type.name())&&StringUtils.isNotBlank(type.getDesc())) {
                Map<String, String> msgTypeMap = Maps.newHashMap();
                msgTypeMap.put("value",type.name());
                msgTypeMap.put("label",type.getDesc());
                list.add(msgTypeMap);
            }
        }
        LOG.info("查询设备接入-消息类型结束！");
        return list;
    }

    /**
     * 获取产品领域
     *
     * @return
     */
    public List<DomainTreeVo> getDeviceDomain() throws SQLException {
        LOG.info("开始查询产品领域信息！");
        QueryRunner queryRunner = new QueryRunner(DMPool.getInstance().getNsDataSource("ies", "urm"));
        String domainSql = "SELECT code,name FROM URM_M_DOMAIN";
        List<DomainTreeVo> domainTreeVoList = queryRunner.query(domainSql, new BeanListHandler<>(DomainTreeVo.class));
        LOG.info("查询产品领域信息结束，result={}！",domainTreeVoList);
        return domainTreeVoList;
    }

    /**
     * 产品类型
     * @return
     */
    public List<Map<String,String>> getDeviceType() {
        LOG.info("开始查询产品类型信息");
        List<Map<String, String>> resultList = Lists.newArrayList();
        DMMetaCI ci = new DMMetaCI();
        ci.setNs("ies");
        ci.setCategory("urm");
        ci.setType("D");
        List<DMMetaCI> list = runner.queryMetaCi(ci);
        if (list == null || list.size()==0) {
            LOG.error("产品类型数据不存在");
            return null;
        }
        list.forEach(c -> {
            if (StringUtils.isNotBlank(c.ci)&&StringUtils.isNotBlank(c.name)) {
                Map<String, String> map = Maps.newHashMap();
                map.put("value",c.ci);
                map.put("label",c.name);
                resultList.add(map);
            }
        });

        LOG.info("查询产品类型信息结束！");
        return resultList;

    }

    /**
     * 获取租户列表
     * @return
     */
    public List<Object> getTenant() throws SQLException {
        LOG.info("开始查询产品租户信息！");
        QueryRunner queryRunner = new QueryRunner(DMPool.getInstance().getNsDataSource("ies", "gwm"));
        Connection conn = DMPool.getInstance().getNsDataSource("ies", "gwm").getConnection();
        try {
            String tenantSql = "SELECT DISTINCT tenant FROM GWM_B_DEVICEDS";
            List<Object> tenantList = queryRunner.query(conn,tenantSql,new ColumnListHandler("tenant"));
            LOG.info("查询产品租户信息结束，result={}！",tenantList);
            return tenantList;
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    /**
     * 获取设备状态值
     * @return
     */
    public List<Map<String, String>> getDInstanceStatus() {
        LOG.info("开始查询设备状态值！");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.DsInstanceStatus[] statuses = GWKEnum.DsInstanceStatus.values();
        if (statuses.length == 0) {
            LOG.error("设备状态值不存在");
            return null;
        }
        for (GWKEnum.DsInstanceStatus status : statuses) {
            if (StringUtils.isNotBlank(status.name())&&StringUtils.isNotBlank(status.getDesc())) {
                Map<String, String> statusMap = Maps.newHashMap();
                statusMap.put("value",status.name());
                statusMap.put("label",status.getDesc());
                list.add(statusMap);
            }
        }
        LOG.info("查询设备状态值结束！");
        return list;
    }

    /**
     * 获取设备在线状态
     * @return
     */
    public List<Map<String, String>> getDInstanceOnLine() {
        LOG.info("开始查询设备在线状态值！");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.DsStatus[] statuses = GWKEnum.DsStatus.values();
        if (statuses.length == 0) {
            LOG.error("设备状态值不存在");
            return null;
        }
        for (GWKEnum.DsStatus status : statuses) {
            if (StringUtils.isNotBlank(status.name())&&StringUtils.isNotBlank(status.getDesc())) {
                Map<String, String> statusMap = Maps.newHashMap();
                statusMap.put("value",status.name());
                statusMap.put("label",status.getDesc());
                list.add(statusMap);
            }
        }
        LOG.info("查询设备在线状态值结束！");
        return list;
    }

    /**
     * 获取系统数据源实例连通性状态值
     * @return
     */
    public List<Map<String,String>> getConnectivityStatus() {
        LOG.info("开始查询连通性状态值！");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.DsConnStatus[] statuses = GWKEnum.DsConnStatus.values();
        if (statuses.length == 0) {
            LOG.error("连通性状态值不存在");
            return null;
        }
        for (GWKEnum.DsConnStatus status : statuses) {
            if (StringUtils.isNotBlank(status.name())&&StringUtils.isNotBlank(status.getDesc())) {
                Map<String, String> statusMap = Maps.newHashMap();
                statusMap.put("value",status.name());
                statusMap.put("label",status.getDesc());
                list.add(statusMap);
            }
        }
        LOG.info("查询连通性性状态值结束！");
        return list;
    }

    /**
     * 获取第三方系统数据源菜单
     * @return
     */
    public List<Map<String,String>> getRestful3rdMenu() {
        LOG.info("开始查询第三方系统数据源菜单值！");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.Restful3rdMenu[] menus = GWKEnum.Restful3rdMenu.values();
        if (menus.length == 0) {
            LOG.error("开始查询第三方系统数据源菜单值不存在");
            return null;
        }
        for (GWKEnum.Restful3rdMenu menu : menus) {
            if (StringUtils.isNotBlank(menu.name())&&StringUtils.isNotBlank(menu.getDesc())) {
                Map<String, String> menuMap = Maps.newHashMap();
                menuMap.put("value",menu.name());
                menuMap.put("label",menu.getDesc());
                list.add(menuMap);
            }
        }
        LOG.info("查询第三方系统数据源菜单值结束！");
        return list;
    }

    /**
     * 获取第三方系统数据源接入协议类型
     * @return
     */
    public List<Map<String,String>> getRestful3rdProcotol() {
        LOG.info("开始查询第三方系统数据源接入协议类型！");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.Restful3rdProtocol[] menus = GWKEnum.Restful3rdProtocol.values();
        if (menus.length == 0) {
            LOG.error("第三方系统数据源接入协议类型不存在");
            return null;
        }
        for (GWKEnum.Restful3rdProtocol protocol : menus) {
            if (StringUtils.isNotBlank(protocol.name())&&StringUtils.isNotBlank(protocol.getDesc())) {
                Map<String, String> protocolMap = Maps.newHashMap();
                protocolMap.put("value",protocol.name());
                protocolMap.put("label",protocol.getDesc());
                list.add(protocolMap);
            }
        }
        LOG.info("查询第三方系统数据源接入协议类型结束！");
        return list;
    }

    /**
     * 获取第三方系统数据源接入协议类型
     * @return
     */
    public List<Map<String,String>> getAuthWay() {
        LOG.info("开始查询第三方系统数据源接入认证方式！");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.AuthWay[] auths = GWKEnum.AuthWay.values();
        if (auths.length == 0) {
            LOG.error("第三方系统数据源接入认证方式不存在");
            return null;
        }
        for (GWKEnum.AuthWay auth : auths) {
            if (StringUtils.isNotBlank(auth.name())&&StringUtils.isNotBlank(auth.getDesc())) {
                Map<String, String> protocolMap = Maps.newHashMap();
                protocolMap.put("value",auth.name());
                protocolMap.put("label",auth.getDesc());
                list.add(protocolMap);
            }
        }
        LOG.info("查询第三方系统数据源接入认证方式结束！");
        return list;
    }

    /**
     * 获取模板映射方式
     * @return
     */
    public List<Map<String,String>> getTemplateMethod() {
        LOG.info("开始查询模板映射方式！");
        List<Map<String, String>> list = Lists.newArrayList();
        GWKEnum.TemplateMethod[] methods = GWKEnum.TemplateMethod.values();
        if (methods.length == 0) {
            LOG.error("模板映射方式不存在！");
            return null;
        }
        for (GWKEnum.TemplateMethod method : methods) {
            if (StringUtils.isNotBlank(method.name())&&StringUtils.isNotBlank(method.getDesc())) {
                Map<String, String> protocolMap = Maps.newHashMap();
                protocolMap.put("value",method.name());
                protocolMap.put("label",method.getDesc());
                list.add(protocolMap);
            }
        }
        LOG.info("查询模板映射方式结束！");
        return list;
    }

}