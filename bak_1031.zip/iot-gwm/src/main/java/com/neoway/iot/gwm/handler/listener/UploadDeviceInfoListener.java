package com.neoway.iot.gwm.handler.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.excel.exception.ExcelDataConvertException;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.neoway.iot.gwm.entity.DeviceInfoModelImport;
import com.neoway.iot.gwm.handler.DeviceInstanceHandler;
import com.neoway.iot.gwm.vo.MetaDeviceInstanceVO;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <pre>
 *   描述：设备信息导入监听类
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/27 15:30
 */

public class UploadDeviceInfoListener extends AnalysisEventListener<DeviceInfoModelImport> {
    private static final Logger LOG = LoggerFactory.getLogger(UploadDeviceInfoListener.class);
    private DeviceInstanceHandler deviceInstanceHandler = new DeviceInstanceHandler();
    /**
     * 产品标识
     */
    private Long code;
    /**
     * 每隔50条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 1;
//    private static final String COLUMN_NAME_0 = "产品标识";
    private static final String COLUMN_NAME_1 = "设备名称";
    private static final String COLUMN_NAME_2 = "设备IMEI";
    private static final String COLUMN_NAME_3 = "第三方ID";
    private static final String COLUMN_NAME_4 = "设备位置";
    /**
     * 行号
     */
    private int rowNum = 1;
    /**
     * 错误信息类别
     */
    private List<String> errorInfo = new ArrayList<>();
    /**
     * 判断Excel表头数据是否有误
     */
    private Boolean hasStart = false;
    /**
     * 带插入数据库的设备信息列表
     */
    private List<MetaDeviceInstanceVO> deviceInfoList = Lists.newArrayList();
    @Override
    public void invoke(DeviceInfoModelImport deviceInfoModelImport, AnalysisContext analysisContext) {
        rowNum += 1;
        StringBuilder sb = new StringBuilder();
        if (!hasStart) {
            LOG.error("表头数据存在问题！请下载模板进行数据导入！");
            return;
        }
        if (deviceInfoModelImport == null) {
            LOG.error("数据为空！");
            return;
        }
        if (StringUtils.isEmpty(sb)){
            // 封装数据对象
            MetaDeviceInstanceVO deviceInstanceVO = new MetaDeviceInstanceVO();
            deviceInstanceVO.setDeviceds_id(this.getCode());
            deviceInstanceVO.setName(deviceInfoModelImport.getName());
            deviceInstanceVO.setNativeId(deviceInfoModelImport.getNativeId());
            deviceInstanceVO.setGw_nativeid(deviceInfoModelImport.getGw_nativeid());
            deviceInstanceVO.setLocation(deviceInfoModelImport.getLocation());
            deviceInfoList.add(deviceInstanceVO);
            if (deviceInfoList.size() >= BATCH_COUNT) {
                List<String> temp = new ArrayList<>();
                List<MetaDeviceInstanceVO> uniqueList = deviceInfoList.stream().filter(
                        di -> {
                            if (!temp.contains(di.getNativeId())) {
                                temp.add(di.getNativeId());
                                return true;
                            } else {
                                sb.append("excel表格中设备IMEI:").append(di.getNativeId()).append("重复添加！");
                                return false;
                            }
                        }
                ).collect(Collectors.toList());

                if (!CollectionUtils.isEmpty(uniqueList)) {
                    String error = deviceInstanceHandler.batchAdd(uniqueList);
                    if (StringUtils.isNotBlank(error)) {
                        sb.append(error);
                    }

                    uniqueList.forEach(c -> {
                        System.out.println("设备名称："+c.getName()+"  设备IMEI:"+c.getNativeId());
                    });
                }

                deviceInfoList.clear();
            }
        } else {
            sb.insert(0,"第" + rowNum + "行数据存在错误！");
            errorInfo.add(sb.toString());
        }

    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        if (CollectionUtils.isEmpty(deviceInfoList)) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        List<String> temp = new ArrayList<>();
        List<MetaDeviceInstanceVO> uniqueList = deviceInfoList.stream().filter(
                di -> {
                    if (!temp.contains(di.getNativeId())) {
                        temp.add(di.getNativeId());
                        return true;
                    } else {
                        sb.append("excel表格中设备序列号:").append(di.getNativeId()).append("重复添加！");
                        return false;
                    }
                }
        ).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(uniqueList)) {
            uniqueList.forEach(c -> {
                System.out.println("设备名称："+c.getName()+"  设备IMEI:"+c.getNativeId());
            });
        }
        LOG.info("所有数据解析导入完成！");

    }
    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        hasStart = true;
        StringBuilder sb = new StringBuilder();
        LOG.info("解析到一条头数据:{}", new Gson().toJson(headMap));
        String columnName0 = headMap.get(0);
        String columnName1 = headMap.get(1);
        String columnName2 = headMap.get(2);
        String columnName3 = headMap.get(3);
        if (CollectionUtils.isEmpty(headMap) || headMap.size() == 0 || headMap.size() != 4
                ||  !COLUMN_NAME_1.equals(columnName0) || !COLUMN_NAME_2.equals(columnName1)
                || !COLUMN_NAME_3.equals(columnName2) || !COLUMN_NAME_4.equals(columnName3)) {
            sb.append("Excel表格与模板不符，请先下载模板！");
            hasStart = false;
        }
        if (hasStart.equals(false)) {
            errorInfo.add(sb.toString());
        }
    }

    @Override
    public void onException(Exception exception, AnalysisContext context) {
        LOG.error("解析导入失败，问题是:{}", exception.getMessage());
        if (exception instanceof ExcelDataConvertException) {
            ExcelDataConvertException excelDataConvertException = (ExcelDataConvertException) exception;
            LOG.error("第{}行，第{}列解析异常，数据为:{}", excelDataConvertException.getRowIndex(),
                    excelDataConvertException.getColumnIndex(), excelDataConvertException.getCellData());
        }
        throw new ExcelAnalysisException(exception.getMessage());
    }

    public List<String> getErrorInfo() {
        return errorInfo;
    }

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }
}
