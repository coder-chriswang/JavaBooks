package com.neoway.iot.gwm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <pre>
 *   描述：设备数据源VO
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/23 08:30
 */
@ApiModel("产品实体类")
public class MetaDeviceDsVO {
    @ApiModelProperty(value = "设备数量")
    private Integer deviceNum;
    @ApiModelProperty(value = "产品标识")
    private Long code;
    @ApiModelProperty(value = "产品行业编码")
    private String industry;
    @ApiModelProperty(value = "产品行业名称")
    private String industryName;
    @ApiModelProperty(value = "产品领域编码")
    private String domain;
    @ApiModelProperty(value = "产品领域名称")
    private String domainName;
    @ApiModelProperty(value = "产品类别")
    private String deviceType;
    @ApiModelProperty(value = "产品类别名称")
    private String deviceTypeName;
    @ApiModelProperty(value = "产品名称")
    private String name;
    @ApiModelProperty(value = "产品租户")
    private String tenant;
    @ApiModelProperty(value = "产品描述")
    private String desc;
    @ApiModelProperty(value = "设备商")
    private String deviceVendor;
    @ApiModelProperty(value = "设备商名称")
    private String deviceVendorName;
    @ApiModelProperty(value = "设备型号")
    private String deviceVersion;
    @ApiModelProperty(value = "通信协议",required = true)
    private String protocol;
    @ApiModelProperty(value = "接入方式",required = true)
    private String accessType;
    @ApiModelProperty(value = "消息类型",example = "枚举：Json或Binary")
    private String payloadType;
    @ApiModelProperty(value = "创建时间")
    private Integer update_ts;
    @ApiModelProperty(value = "白名单配置",example = "Json,只有接入类型为非直连设备的时候需要配置")
    private String ext;

    public String getIndustryName() {
        return industryName;
    }

    public void setIndustryName(String industryName) {
        this.industryName = industryName;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public Integer getDeviceNum() {
        return deviceNum;
    }

    public String getDeviceTypeName() {
        return deviceTypeName;
    }

    public void setDeviceTypeName(String deviceTypeName) {
        this.deviceTypeName = deviceTypeName;
    }

    public void setDeviceNum(int deviceNum) {
        this.deviceNum = deviceNum;
    }

    public Long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public String getDeviceVendor() {
        return deviceVendor;
    }

    public void setDeviceVendor(String deviceVendor) {
        this.deviceVendor = deviceVendor;
    }

    public String getDeviceVendorName() {
        return deviceVendorName;
    }

    public void setDeviceVendorName(String deviceVendorName) {
        this.deviceVendorName = deviceVendorName;
    }

    public String getDeviceVersion() {
        return deviceVersion;
    }

    public void setDeviceVersion(String deviceVersion) {
        this.deviceVersion = deviceVersion;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getAccessType() {
        return accessType;
    }

    public void setAccessType(String accessType) {
        this.accessType = accessType;
    }

    public String getPayloadType() {
        return payloadType;
    }

    public void setPayloadType(String payloadType) {
        this.payloadType = payloadType;
    }


    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }

    public Integer getUpdate_ts() {
        return update_ts;
    }

    public void setUpdate_ts(Integer update_ts) {
        this.update_ts = update_ts;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }
}
