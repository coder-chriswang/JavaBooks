package com.neoway.iot.gwm.handler;

import cn.hutool.core.util.ObjectUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.neoway.iot.gwm.common.GsonUtil;
import com.neoway.iot.gwm.common.PageInfo;
import com.neoway.iot.gwm.entity.MetaSystemInstance;
import com.neoway.iot.gwm.vo.SystemDsInstanceVo;
import com.neoway.iot.gwm.vo.SystemDsVo;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.util.DMUtil;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaCache;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import com.neoway.iot.sdk.gwk.entity.SystemDS;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: MetaDeviceInstanceController 数据源设备实例处理器
 * @author: 20200416002
 * @date: 2020/9/17 17:22
 */
public class SystemDataSourcesInstanceHandler {
    private static final Logger LOG = LoggerFactory.getLogger(SystemDataSourcesInstanceHandler.class);
    private DMRunner runner;

    public SystemDataSourcesInstanceHandler() {
        this.runner = DMRunner.getInstance();
    }

    /**
     * 添加系统数据源实例
     *
     * @param systemDsInstance
     * @return
     */
    public int addSystemDsInstance(MetaSystemInstance systemDsInstance) {
        //生成实例id
        String key = systemDsInstance.getSystemId() + systemDsInstance.getNativeId();
        long instanceId = DMUtil.getHashCode(key);
        //查询系统数据源实例对象
        DMDataPoint dataPoint = DMDataPoint.builder(MetaSystemInstance.NS,MetaSystemInstance.CATEGORY,MetaSystemInstance.CI);
        dataPoint.addColumn(new DMDataColumn("instanceid", instanceId));
        dataPoint.getMetaCI().setCache(false);
        DMDataPoint systemInstancePoint = runner.get(dataPoint);
        MetaSystemInstance systemInstance = (MetaSystemInstance)DMUtil.buildClazzInstance(systemInstancePoint,MetaSystemInstance.class);
        if (null != systemInstance) {
            return 2;
        }
        try {
            dataPoint.addColumn(new DMDataColumn("ext", systemDsInstance.getExt()));
            dataPoint.addColumn(new DMDataColumn("system_id", systemDsInstance.getSystemId()));
            dataPoint.addColumn(new DMDataColumn("name", systemDsInstance.getName()));
            dataPoint.addColumn(new DMDataColumn("nativeId", systemDsInstance.getNativeId()));
            dataPoint.addColumn(new DMDataColumn("gw_nativeid", systemDsInstance.getGwNativeId()));
            dataPoint.addColumn(new DMDataColumn("region", systemDsInstance.getRegion()));
            dataPoint.addColumn(new DMDataColumn("rt", (int) (System.currentTimeMillis() / 1000)));
            //插入系统数据源实例
            runner.write(dataPoint);
            return 1;
        } catch (JsonSyntaxException e) {
            LOG.error("添加系统数据源实例失败--扩展信息ext字段为非法的JSON格式:",e);
        } catch (Exception e) {
            LOG.error("添加系统数据源实例发生错误:",e);
        }
        return 0;
    }

    /**
     * 删除系统数据源实例
     *
     * @param instanceId
     * @return
     */
    public int deleteSystemDsInstance(Long instanceId) {
        try {
            DMDataPoint dataPoint = DMDataPoint.builder(MetaSystemInstance.NS,MetaSystemInstance.CATEGORY,MetaSystemInstance.CI);
            dataPoint.addColumn(new DMDataColumn("instanceid", instanceId));
            dataPoint.getMetaCI().setCache(false);
            DMDataPoint point = runner.get(dataPoint);
            MetaSystemInstance systemInstance = (MetaSystemInstance)DMUtil.buildClazzInstance(point,MetaSystemInstance.class);
            if (null == systemInstance) {
                LOG.error("删除失败--该系统数据源实例不存在，instanceId={}", instanceId);
                return 2;
            }
            runner.delete(dataPoint);
            return 1;
        } catch (Exception e) {
            LOG.error("删除系统数据源实例发生错误instanceId={},异常信息为:", instanceId,e);
        }
        return 0;
    }

    /**
     * 修改系统数据源实例
     *
     * @param systemDsInstance
     * @return
     */
    public int updateSystemDsInstance(MetaSystemInstance systemDsInstance) {
        DMDataPoint dataPoint = DMDataPoint.builder(MetaSystemInstance.NS,MetaSystemInstance.CATEGORY,MetaSystemInstance.CI);
        dataPoint.addColumn(new DMDataColumn("instanceid", systemDsInstance.getInstanceId()));
        dataPoint.getMetaCI().setCache(false);
        DMDataPoint dataResult = runner.get(dataPoint);
        MetaSystemInstance systemInstance = (MetaSystemInstance)DMUtil.buildClazzInstance(dataResult,MetaSystemInstance.class);
        if (null == systemInstance) {
            LOG.error("更新失败--该系统数据源实例不存在，instanceId={}", systemDsInstance.getSystemId());
            return 2;
        }
        try {
            dataPoint.addColumn(new DMDataColumn("ext", systemDsInstance.getExt()));
            dataPoint.addColumn(new DMDataColumn("system_id", systemDsInstance.getSystemId()));
            dataPoint.addColumn(new DMDataColumn("name", systemDsInstance.getName()));
            dataPoint.addColumn(new DMDataColumn("nativeId", systemDsInstance.getNativeId()));
            dataPoint.addColumn(new DMDataColumn("gw_nativeid", systemDsInstance.getGwNativeId()));
            dataPoint.addColumn(new DMDataColumn("region", systemDsInstance.getRegion()));
            dataPoint.addColumn(new DMDataColumn("rt", (int) (System.currentTimeMillis() / 1000)));
            //插入系统数据源实例
            runner.write(dataPoint);
            return 1;
        } catch (JsonSyntaxException e) {
            LOG.error("更新系统数据源实例失败--扩展信息ext字段为非法的JSON格式:",e);
        } catch (Exception e) {
            LOG.error("更新系统数据源实例发生错误:",e);
        }
        return 0;
    }

    /**
     * 获取系统数据源实例详情
     *
     * @param instanceId
     * @return
     */
    public SystemDsInstanceVo getSystemDsInstance(Long instanceId) {
        SystemDsInstanceVo systemDsInstanceVo = new SystemDsInstanceVo();
        DMDataPoint dataPoint = DMDataPoint.builder(MetaSystemInstance.NS,MetaSystemInstance.CATEGORY,MetaSystemInstance.CI);
        dataPoint.addColumn(new DMDataColumn("instanceid", instanceId));
        dataPoint.getMetaCI().setCache(false);
        DMDataPoint dataResult = runner.get(dataPoint);
        MetaSystemInstance systemInstance = (MetaSystemInstance) DMUtil.buildClazzInstance(dataResult, MetaSystemInstance.class);
        if (systemInstance == null) {
            LOG.error("获取系统数据源实例失败--不存在该实例,instanceid={}",instanceId);
        }
        BeanUtils.copyProperties(systemInstance,systemDsInstanceVo);
        DMDataPoint systemDs = DMDataPoint.builder(SystemDsVo.NS,SystemDsVo.CATEGORY,SystemDsVo.CI);
        systemDs.addColumn(new DMDataColumn("code", systemInstance.getSystemId()));
        DMDataPoint systemDsPoint = runner.get(systemDs);
        SystemDS systemDS = (SystemDS) DMUtil.buildClazzInstance(systemDsPoint, SystemDS.class);
        if (systemDS == null) {
            LOG.error("该系统数据源不存在，code={}",systemInstance.getSystemId());
        } else {
            systemDsInstanceVo.setType(systemDS.getSystemType());
        }
        return systemDsInstanceVo;
    }

    /**
     * 获取分页系统数据源实例
     * @param systemType 系统类型
     * @param connectivity 连通性
     * @param pageSize 每页条数
     * @param pageNum 页码
     * @return
     */
    public PageInfo<SystemDsInstanceVo> findSystemDsInstanceList(Long systemId,String systemType,String connectivity,Integer pageSize, Integer pageNum) {
        //获取MetaCi
        DMMetaCI metaCI = DMMetaCache.getInstance().getMetaCI(MetaSystemInstance.NS,MetaSystemInstance.CATEGORY,MetaSystemInstance.CI);
        if (null == metaCI) {
            String msg = "获取数据失败，原因=元数据不存在。产品域={0},主题={1},ci={2}";
            String errMsg = MessageFormat.format(msg, MetaSystemInstance.NS,MetaSystemInstance.CATEGORY,MetaSystemInstance.CI);
            throw new RuntimeException(errMsg);
        }
        PageInfo<SystemDsInstanceVo> pageInfo = new PageInfo<>();
        // 总记录数
        int categoryTotal = 0;
        // 当前查询页数据
        List<SystemDsInstanceVo> currentData = new ArrayList<>();
        List<Map<String, Object>> allData = new ArrayList<>();
        List<Map<String, Object>> currentPageMaps = new ArrayList<>();
        if (StringUtils.isBlank(systemType) && StringUtils.isBlank(connectivity)){
            allData = runner.executeSQL("SELECT INSTANCEID FROM ies_gwm.GWM_B_SYSTEMINSTANCE WHERE SYSTEM_ID = "+systemId);
            currentPageMaps = runner.executeSQL("SELECT GBS.TYPE AS TYPE,GBSI.* FROM ies_gwm.GWM_B_SYSTEMINSTANCE GBSI\n" +
                    "LEFT JOIN ies_gwm.GWM_B_SYSTEMDS GBS ON GBSI.SYSTEM_ID = GBS.`CODE` WHERE GBSI.SYSTEM_ID = "+systemId+" LIMIT "+(pageNum - 1)*pageSize+","+pageSize);

        }
        if (StringUtils.isBlank(systemType) && StringUtils.isNotBlank(connectivity)){
            allData = runner.executeSQL("SELECT\n" +
                    "\tGBS.TYPE AS '系统类型',\n" +
                    "\tGBSI.* \n" +
                    "FROM\n" +
                    "\ties_gwm.GWM_B_SYSTEMINSTANCE GBSI\n" +
                    "\tLEFT JOIN ies_gwm.GWM_B_SYSTEMDS GBS ON GBSI.SYSTEM_ID = GBS.\n" +
                    "\tCODE LEFT JOIN GWM_B_STATUS GBSS ON GBSI.INSTANCEID = GBSS.INSTANCEID \n" +
                    "WHERE GBSI.SYSTEM_ID = "+systemId+" and\n" +
                    "\tGBSS.INSTANCEID IN ( SELECT INSTANCEID FROM ies_gwm.GWM_B_STATUS GBSSS WHERE GBSSS.STATUS = '"+connectivity+"')");
            currentPageMaps = runner.executeSQL("SELECT\n" +
                    "\tGBS.TYPE AS '系统类型',\n" +
                    "\tGBSI.* \n" +
                    "FROM\n" +
                    "\ties_gwm.GWM_B_SYSTEMINSTANCE GBSI\n" +
                    "\tLEFT JOIN ies_gwm.GWM_B_SYSTEMDS GBS ON GBSI.SYSTEM_ID = GBS.\n" +
                    "\tCODE LEFT JOIN ies_gwm.GWM_B_STATUS GBSS ON GBSI.INSTANCEID = GBSS.INSTANCEID \n" +
                    "WHERE GBSI.SYSTEM_ID = "+systemId+" and\n" +
                    "\tGBSS.INSTANCEID IN ( SELECT INSTANCEID FROM ies_gwm.GWM_B_STATUS GBSSS WHERE GBSSS.STATUS = '"+connectivity+"' ) \n" +
                    "\tLIMIT "+(pageNum-1)*pageSize+","+pageSize);
        }
        if (StringUtils.isNotBlank(systemType) && StringUtils.isBlank(connectivity)){
            allData = runner.executeSQL("SELECT\n" +
                    "\tGBS.TYPE AS '系统类型',\n" +
                    "\tGBSI.* \n" +
                    "FROM\n" +
                    "\ties_gwm.GWM_B_SYSTEMINSTANCE GBSI\n" +
                    "\tLEFT JOIN ies_gwm.GWM_B_SYSTEMDS GBS ON GBSI.SYSTEM_ID = GBS.\n" +
                    "\tCODE LEFT JOIN ies_gwm.GWM_B_STATUS GBSS ON GBSI.INSTANCEID = GBSS.INSTANCEID \n" +
                    "WHERE GBSI.SYSTEM_ID = "+systemId+" and\n" +
                    "\tGBSS.INSTANCEID IN ( SELECT INSTANCEID FROM ies_gwm.GWM_B_STATUS GBSSS WHERE GBSSS.DS_TYPE = '"+systemType+"')");
            currentPageMaps = runner.executeSQL("SELECT\n" +
                    "\tGBS.TYPE AS '系统类型',\n" +
                    "\tGBSI.* \n" +
                    "FROM\n" +
                    "\ties_gwm.GWM_B_SYSTEMINSTANCE GBSI\n" +
                    "\tLEFT JOIN ies_gwm.GWM_B_SYSTEMDS GBS ON GBSI.SYSTEM_ID = GBS.\n" +
                    "\tCODE LEFT JOIN ies_gwm.GWM_B_STATUS GBSS ON GBSI.INSTANCEID = GBSS.INSTANCEID \n" +
                    "WHERE GBSI.SYSTEM_ID = "+systemId+" and\n" +
                    "\tGBSS.INSTANCEID IN ( SELECT INSTANCEID FROM ies_gwm.GWM_B_STATUS GBSSS WHERE GBSSS.DS_TYPE = '"+systemType+"' ) \n" +
                    "\tLIMIT "+(pageNum-1)*pageSize+","+pageSize);
        }
        if (StringUtils.isNotBlank(systemType) && StringUtils.isNotBlank(connectivity)){
            allData = runner.executeSQL("SELECT\n" +
                    "\tGBS.TYPE AS '系统类型',\n" +
                    "\tGBSI.* \n" +
                    "FROM\n" +
                    "\ties_gwm.GWM_B_SYSTEMINSTANCE GBSI\n" +
                    "\tLEFT JOIN ies_gwm.GWM_B_SYSTEMDS GBS ON GBSI.SYSTEM_ID = GBS.\n" +
                    "\tCODE LEFT JOIN ies_gwm.GWM_B_STATUS GBSS ON GBSI.INSTANCEID = GBSS.INSTANCEID \n" +
                    "WHERE GBSI.SYSTEM_ID = "+systemId+" and\n" +
                    "\tGBSS.INSTANCEID IN ( SELECT INSTANCEID FROM ies_gwm.GWM_B_STATUS GBSSS WHERE GBSSS.STATUS = '"+connectivity+"' AND GBSSS.DS_TYPE = '"+systemType+"')");
            currentPageMaps = runner.executeSQL("SELECT\n" +
                    "\tGBS.TYPE AS '系统类型',\n" +
                    "\tGBSI.* \n" +
                    "FROM\n" +
                    "\ties_gwm.GWM_B_SYSTEMINSTANCE GBSI\n" +
                    "\tLEFT JOIN ies_gwm.GWM_B_SYSTEMDS GBS ON GBSI.SYSTEM_ID = GBS.\n" +
                    "\tCODE LEFT JOIN ies_gwm.GWM_B_STATUS GBSS ON GBSI.INSTANCEID = GBSS.INSTANCEID \n" +
                    "WHERE GBSI.SYSTEM_ID = "+systemId+" and\n" +
                    "\tGBSS.INSTANCEID IN ( SELECT INSTANCEID FROM ies_gwm.GWM_B_STATUS GBSSS WHERE GBSSS.STATUS = '"+connectivity+"' AND GBSSS.DS_TYPE = '"+systemType+"' ) \n" +
                    "\tLIMIT "+(pageNum-1)*pageSize+","+pageSize);
        }
        categoryTotal = allData.size();
        for (Map<String, Object> currentPageMap : currentPageMaps) {
            SystemDsInstanceVo systemDsInstanceVo = GsonUtil.mapToEntity(currentPageMap, SystemDsInstanceVo.class);
            if (ObjectUtil.isNotNull(currentPageMap.get("system_id"))){
                systemDsInstanceVo.setSystemId((long)currentPageMap.get("system_id"));
            }
            if (ObjectUtil.isNotNull(currentPageMap.get("rt"))){
                systemDsInstanceVo.setRt((int)currentPageMap.get("rt"));
            }
            currentData.add(systemDsInstanceVo);
        }
        // 总页数
        int pageSum = (categoryTotal - 1) / pageSize + 1;
        // 组装返回结果
        pageInfo.setRecordsTotal(categoryTotal);
        pageInfo.setPageSum(pageSum);
        pageInfo.setCurrentPageContent(currentData);
        return pageInfo;
    }

    /**
     * 上传证书
     * @param file
     * @param nativeid
     */
    public void uploadCertificateFile(MultipartFile file, String nativeid) throws IOException {
        // 获取文件名
        String fileName = file.getOriginalFilename();
        //获取项目根目录的绝对路径
        String target = new File(this.getClass().getResource("/").getPath()).getParent();
        String parent = new File(target).getParent();
        String filePath = parent + File.separator + "deployment" + File.separator + "etc" + File.separator + nativeid;
        File fileTemp = new File(filePath);
        if (fileTemp.exists()) {
            saveFileFromInputStream(file.getInputStream(),filePath,fileName);
        } else {
            fileTemp.mkdirs();
            saveFileFromInputStream(file.getInputStream(),filePath,fileName);
        }
    }

    /**
     * 保存文件到指定目录
     * @param stream
     * @param path
     * @param fileName
     * @throws IOException
     */
    private void saveFileFromInputStream(InputStream stream, String path, String fileName) throws IOException {
        FileOutputStream fs = new FileOutputStream( path + File.separator + fileName);
        byte[] buffer =new byte[1024*1024];
        int byteSum = 0;
        int byteRead;
        while ((byteRead = stream.read(buffer))!=-1) {
            byteSum += byteRead;
            fs.write(buffer,0,byteRead);
            fs.flush();
        }
        fs.close();
        stream.close();
    }

    /**
     * 获取系统数据源列表
     * @return
     */
    public List<SystemDsInstanceVo> findsInstanceList() {
        List<SystemDsInstanceVo> voList = Lists.newArrayList();
        List<Map<String,Object>> voMap = runner.executeSQL("SELECT * FROM ies_gwm.GWM_B_SYSTEMINSTANCE");
        for (Map<String, Object> vo : voMap) {
            SystemDsInstanceVo systemDsInstanceVo = GsonUtil.mapToEntity(vo, SystemDsInstanceVo.class);
            if (ObjectUtil.isNotNull(vo.get("system_id"))){
                systemDsInstanceVo.setSystemId((long)vo.get("system_id"));
            }
            if (ObjectUtil.isNotNull(vo.get("rt"))){
                systemDsInstanceVo.setRt((int)vo.get("rt"));
            }
            voList.add(systemDsInstanceVo);
        }
        return voList;
    }
}
