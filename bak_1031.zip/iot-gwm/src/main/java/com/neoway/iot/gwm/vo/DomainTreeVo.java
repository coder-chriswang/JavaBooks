package com.neoway.iot.gwm.vo;

import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * <pre>
 *  描述：领域树
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/10/15 10:58
 */
@ApiModel("领域树")
public class DomainTreeVo {
    @ApiModelProperty("领域编码")
    private String code;
    @ApiModelProperty("领域名称")
    private String name;
    private List<DMMetaCI> dsList;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<DMMetaCI> getDsList() {
        return dsList;
    }

    public void setDsList(List<DMMetaCI> dsList) {
        this.dsList = dsList;
    }
}
