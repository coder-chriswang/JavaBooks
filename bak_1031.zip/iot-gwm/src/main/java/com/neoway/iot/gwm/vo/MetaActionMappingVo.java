package com.neoway.iot.gwm.vo;

import com.google.common.collect.Maps;
import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Map;
import java.util.Set;

/**
 * <pre>
 *   描述：数据源服务映射
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 20:08
 */
@ApiModel("服务映射实体")
public class MetaActionMappingVo {

    @ApiModelProperty(value = "数据源标识",required = true)
    private Long ds_code;
    @ApiModelProperty(value ="数据源类型",required = true)
    private String ds_type;
    @ApiModelProperty(value ="服务标识",required = true)
    private String action_id;
    @ApiModelProperty(value ="标准服务标识",required = true)
    private String meta_action_id;
    @ApiModelProperty(value ="服务名称")
    private String meta_action_name;
    @ApiModelProperty(value ="服务类型")
    private String meta_action_type;
    @ApiModelProperty(value ="服务类别")
    private String meta_action_direction;
    @ApiModelProperty(value ="服务参数列表")
    private Set<DMMetaAttr> meta_attr_list;
    @ApiModelProperty(value ="映射模板方式",required = true)
    private String template_method;
    @ApiModelProperty(value ="模板ID")
    private String template_id;
    @ApiModelProperty(value ="更新时间")
    private int update_ts;

    public Long getDs_code() {
        return ds_code;
    }

    public void setDs_code(Long ds_code) {
        this.ds_code = ds_code;
    }

    public String getDs_type() {
        return ds_type;
    }

    public void setDs_type(String ds_type) {
        this.ds_type = ds_type;
    }

    public String getAction_id() {
        return action_id;
    }

    public void setAction_id(String action_id) {
        this.action_id = action_id;
    }

    public String getMeta_action_id() {
        return meta_action_id;
    }

    public void setMeta_action_id(String meta_action_id) {
        this.meta_action_id = meta_action_id;
    }

    public String getMeta_action_name() {
        return meta_action_name;
    }

    public void setMeta_action_name(String meta_action_name) {
        this.meta_action_name = meta_action_name;
    }

    public String getMeta_action_type() {
        return meta_action_type;
    }

    public void setMeta_action_type(String meta_action_type) {
        this.meta_action_type = meta_action_type;
    }

    public String getMeta_action_direction() {
        return meta_action_direction;
    }

    public void setMeta_action_direction(String meta_action_direction) {
        this.meta_action_direction = meta_action_direction;
    }

    public Set<DMMetaAttr> getMeta_attr_list() {
        return meta_attr_list;
    }

    public void setMeta_attr_list(Set<DMMetaAttr> meta_attr_list) {
        this.meta_attr_list = meta_attr_list;
    }

    public String getTemplate_method() {
        return template_method;
    }

    public void setTemplate_method(String template_method) {
        this.template_method = template_method;
    }

    public String getTemplate_id() {
        return template_id;
    }

    public void setTemplate_id(String template_id) {
        this.template_id = template_id;
    }

    public int getUpdate_ts() {
        return update_ts;
    }

    public void setUpdate_ts(int update_ts) {
        this.update_ts = update_ts;
    }

    /**
     * 构建添加时的参数
     * @return
     */
    public Map<String,Object> buildAddParamsMap() {
        Map<String,Object> conditionMap = Maps.newHashMap();
        conditionMap.put("ds_code",this.getDs_code());
        conditionMap.put("ds_type",this.getDs_type());
        conditionMap.put("action_id",this.getAction_id());
        conditionMap.put("meta_action_id",this.getMeta_action_id());
        conditionMap.put("template_method",this.getTemplate_method());
        conditionMap.put("update_ts",this.getUpdate_ts());
        return conditionMap;

    }
}
