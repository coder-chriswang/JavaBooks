package com.neoway.iot.gwm.vo;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.neoway.iot.sdk.dmk.meta.DMMetaColumnDBAnno;
import com.neoway.iot.sdk.gwk.entity.SystemDS;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;


/**
 * @desc: SystemDSVo 数据源设备实例控制器
 * @author: 20200416002
 * @date: 2020/9/17 17:22
 */
public class SystemDsVo extends SystemDS implements Serializable {
    public static final String NS = "ies";
    public static final String CATEGORY = "gwm";
    public static final String CI = "systemds";

    @ApiModelProperty(
            value = "数据源编码",
            hidden = true
    )
    @DMMetaColumnDBAnno(
            column = "code",
            type = long.class
    )
    @JsonSerialize(using = ToStringSerializer.class)
    private long code;
    @ApiModelProperty(
            value = "系统类型",
            required = true,
            reference = "type"
    )
    @DMMetaColumnDBAnno(
            column = "type",
            type = String.class
    )
    private String systemType;
    @ApiModelProperty("租户")
    @DMMetaColumnDBAnno(
            column = "tenant",
            type = String.class
    )
    private String tenant;
    @ApiModelProperty(
            value = "系统版本",
            required = true
    )
    @DMMetaColumnDBAnno(
            column = "version",
            type = String.class
    )
    private String version;
    @ApiModelProperty(
            value = "接入协议",
            required = true,
            reference = "protocol"
    )
    @DMMetaColumnDBAnno(
            column = "protocol",
            type = String.class
    )
    private String protocol;
    @ApiModelProperty(
            value = "连通性检测周期",
            hidden = true
    )
    @DMMetaColumnDBAnno(
            column = "health_interval",
            type = int.class
    )
    private int health_interval = 60;
    @ApiModelProperty(
            value = "连通性检测模板",
            hidden = true
    )
    @DMMetaColumnDBAnno(
            column = "health_templateid",
            type = String.class
    )
    private String health_templateid;
    @ApiModelProperty(
            value = "更新时间",
            hidden = true
    )
    @DMMetaColumnDBAnno(
            column = "update_ts",
            type = Integer.class
    )
    private int update_ts;
    @ApiModelProperty(
            value = "扩展属性",
            required = true
    )
    private String ext;

    @Override
    public long getCode() {
        return code;
    }

    @Override
    public void setCode(long code) {
        this.code = code;
    }

    @Override
    public String getSystemType() {
        return systemType;
    }

    @Override
    public void setSystemType(String systemType) {
        this.systemType = systemType;
    }

    @Override
    public String getTenant() {
        return tenant;
    }

    @Override
    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    @Override
    public String getVersion() {
        return version;
    }

    @Override
    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public String getProtocol() {
        return protocol;
    }

    @Override
    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    @Override
    public int getHealth_interval() {
        return health_interval;
    }

    @Override
    public void setHealth_interval(int health_interval) {
        this.health_interval = health_interval;
    }

    @Override
    public String getHealth_templateid() {
        return health_templateid;
    }

    @Override
    public void setHealth_templateid(String health_templateid) {
        this.health_templateid = health_templateid;
    }

    @Override
    public int getUpdate_ts() {
        return update_ts;
    }

    public void setUpdate_ts(Integer update_ts) {
        this.update_ts = update_ts;
    }

    @Override
    public String getExt() {
        return ext;
    }

    @Override
    public void setExt(String ext) {
        this.ext = ext;
    }
}
