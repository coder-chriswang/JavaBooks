package com.neoway.iot.gwm.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;

import java.io.Serializable;

/**
 * <pre>
 *   描述：设备数据源实例信息导入模板类(EXCEL文件)
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/27 15:10
 */
@ContentRowHeight(15)
@HeadRowHeight(20)
@ColumnWidth(25)
public class DeviceInfoModelImport implements Serializable {
    private static final long serialVersionUID = -6917281029803660316L;
//    @ExcelProperty(value = "产品标识", index = 0)
//    private long deviceds_id;
    @ExcelProperty(value = "设备名称", index = 0)
    private String name;
    @ExcelProperty(value = "设备IMEI", index = 1)
    private String nativeId;
    @ExcelProperty(value = "第三方ID", index = 2)
    private String gw_nativeid;
    @ExcelProperty(value = "设备位置", index = 3)
    private String location;

//    public long getDeviceds_id() {
//        return deviceds_id;
//    }
//
//    public void setDeviceds_id(long deviceds_id) {
//        this.deviceds_id = deviceds_id;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

    public String getGw_nativeid() {
        return gw_nativeid;
    }

    public void setGw_nativeid(String gw_nativeid) {
        this.gw_nativeid = gw_nativeid;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
