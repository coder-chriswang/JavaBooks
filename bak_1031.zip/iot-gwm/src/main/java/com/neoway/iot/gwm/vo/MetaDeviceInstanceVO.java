package com.neoway.iot.gwm.vo;

import com.google.common.collect.Maps;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * <pre>
 *  描述：设备数据源实例
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 20:11
 */
@ApiModel("设备实体")
public class MetaDeviceInstanceVO {
    public static final String DSNS = "ies";
    public static final String DSCATEGORY = "gwm";
    public static final String DSCI = "DeviceInstance";
    @ApiModelProperty(value = "产品标识",required = true)
    private Long deviceds_id;
    @ApiModelProperty(value = "设备ID",required = true)
    private Long instanceid;
    @ApiModelProperty(value ="设备名称",required = true)
    private String name;
    @ApiModelProperty(value ="IMEI",required = true)
    private String nativeId;
    @ApiModelProperty(value ="第三方ID")
    private String gw_nativeid;
    @ApiModelProperty(value ="部署区域",hidden = true)
    private String region;
    @ApiModelProperty(value ="创建时间")
    private Integer rt;
    @ApiModelProperty(value ="激活时间",hidden = true)
    private Integer at;
    @ApiModelProperty(value ="最后连接时间")
    private Integer lt;
    @ApiModelProperty(value = "产品类型")
    private String device_type;
    @ApiModelProperty(value = "产品租户")
    private String tenant;
    @ApiModelProperty(value = "设备状态")
    private String status;
    @ApiModelProperty(value = "在线状态")
    private String onLine;
    @ApiModelProperty(value = "设备位置")
    private String location;


    public Long getDeviceds_id() {
        return deviceds_id;
    }

    public void setDeviceds_id(Long deviceds_id) {
        this.deviceds_id = deviceds_id;
    }

    public Long getInstanceid() {
        return instanceid;
    }

    public void setInstanceid(Long instanceid) {
        this.instanceid = instanceid;
    }

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

    public String getGw_nativeid() {
        return gw_nativeid;
    }

    public void setGw_nativeid(String gw_nativeid) {
        this.gw_nativeid = gw_nativeid;
    }

    public String getDevice_type() {
        return device_type;
    }

    public void setDevice_type(String device_type) {
        this.device_type = device_type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Integer getRt() {
        return rt;
    }

    public void setRt(Integer rt) {
        this.rt = rt;
    }

    public Integer getAt() {
        return at;
    }

    public void setAt(Integer at) {
        this.at = at;
    }

    public Integer getLt() {
        return lt;
    }

    public void setLt(Integer lt) {
        this.lt = lt;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOnLine() {
        return onLine;
    }

    public void setOnLine(String onLine) {
        this.onLine = onLine;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Map<String,Object> builderCloumns() {
        Map<String,Object> cloumns = Maps.newHashMap();
        if (0 != this.getDeviceds_id()) {
            cloumns.put("deviceds_id",this.getDeviceds_id());
        }
        if (0 != this.getInstanceid()) {
            cloumns.put("instanceid",this.getInstanceid());
        }
        if (StringUtils.isNotBlank(this.getName())) {
            cloumns.put("name",this.getName());
        }
        if (StringUtils.isNotBlank(this.getNativeId())) {
            cloumns.put("nativeid",this.getNativeId());
        }
        if (StringUtils.isNotBlank(this.getGw_nativeid())) {
            cloumns.put("gw_nativeid",this.getGw_nativeid());
        }
        if (StringUtils.isNotBlank(this.getRegion())) {
            cloumns.put("region",this.getRegion());
        }
        if (StringUtils.isNotBlank(this.getStatus())) {
            cloumns.put("status",this.getStatus());
        }

        if (StringUtils.isNotBlank(this.getLocation())) {
            cloumns.put("location",this.getLocation());
        }
        cloumns.put("rt",this.getRt());
        cloumns.put("at",this.getAt());
        cloumns.put("lt",this.getLt());

        return cloumns;
    }
}
