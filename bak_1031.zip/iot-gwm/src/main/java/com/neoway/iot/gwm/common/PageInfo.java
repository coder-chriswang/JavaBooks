package com.neoway.iot.gwm.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * <pre>
 *   描述:分页页面实体
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/20 18:28
 */
@ApiModel(value = "分页页面信息")
public class PageInfo<T> {
    @ApiModelProperty("总记录数")
    private int recordsTotal;
    @ApiModelProperty("总页数")
    private int pageSum;
    @ApiModelProperty("当前页数据")
    private List<T> currentPageContent;

    public int getRecordsTotal() {
        return recordsTotal;
    }

    public void setRecordsTotal(int recordsTotal) {
        this.recordsTotal = recordsTotal;
    }

    public int getPageSum() {
        return pageSum;
    }

    public void setPageSum(int pageSum) {
        this.pageSum = pageSum;
    }

    public List<T> getCurrentPageContent() {
        return currentPageContent;
    }

    public void setCurrentPageContent(List<T> currentPageContent) {
        this.currentPageContent = currentPageContent;
    }
}
