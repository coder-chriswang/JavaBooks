package com.neoway.iot.gwm.api.device;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.ObjectUtil;
import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.common.PageInfo;
import com.neoway.iot.gwm.handler.DeviceInstanceHandler;
import com.neoway.iot.gwm.vo.MetaDeviceInstanceVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <pre>
 *   描述：设备数据源实例控制器
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 19:00
 */
@RestController
@RequestMapping("/v1/dinstance")
@Api(tags = "设备管理")
public class DeviceInstanceController {
    private static final Logger LOG = LoggerFactory.getLogger(DeviceInstanceController.class);
    private DeviceInstanceHandler handler = new DeviceInstanceHandler();
    @ApiOperation("新增设备")
    @PostMapping
    public HttpResult addDeviceInstance(@RequestBody MetaDeviceInstanceVO dInstance) {
        if (0 == dInstance.getDeviceds_id() || StringUtils.isBlank(dInstance.getNativeId()) || StringUtils.isBlank(dInstance.getName())) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result =  handler.addDeviceInstance(dInstance);
            if (result) {
                return HttpResult.returnSuccess("设备添加成功！");
            } else {
                return HttpResult.returnFail("重复添加了设备");
            }

        } catch (Exception e) {
            LOG.error("设备添加异常！", e);
            return HttpResult.returnFail("设备添加异常！");
        }
    }


    @ApiOperation("删除设备信息")
    @DeleteMapping("/{instanceId}")
    @ApiImplicitParam(name = "instanceId",value = "设备Id",dataType = "String",required = true)
    public HttpResult deleteDeviceDs(@PathVariable(value = "instanceId") String instanceId) {
        if (StringUtils.isBlank(instanceId)) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result = handler.deleteDeviceDs(instanceId);
            if (result) {
                return HttpResult.returnSuccess("设备信息删除成功！");
            } else {
                return HttpResult.returnFail("删除失败--该设备不存在");
            }
        } catch (Exception e) {
            LOG.error("设备数据源实例信息删除失败！", e);
            return HttpResult.returnFail("设备数据源实例信息删除失败！");
        }
    }
    @ApiOperation("批量删除设备")
    @PostMapping("/dinstances")
    public HttpResult batchDeleteDeviceInstance(@RequestBody String[] instanceIds) {
        if (ArrayUtil.isEmpty(instanceIds)) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            String result = handler.batchDelete(instanceIds);
            if (StringUtils.isNotBlank(result)) {
                return HttpResult.returnFail("存在删除失败的设备",result);
            } else {
                return HttpResult.returnSuccess("设备数据源实例信息删除成功！");
            }
        } catch (Exception e) {
            LOG.error("批量删除设备异常！", e);
            return HttpResult.returnFail("批量删除设备异常！");
        }
    }
    @ApiOperation("修改设备信息")
    @PutMapping
    public HttpResult updateDeviceInstance(@RequestBody MetaDeviceInstanceVO dInstance) {
        if (0 == dInstance.getDeviceds_id() || StringUtils.isBlank(dInstance.getNativeId())
                || StringUtils.isBlank(dInstance.getName()) || 0 == dInstance.getInstanceid()) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            boolean result = handler.updateDeviceInstance(dInstance);
            if (!result) {
                LOG.error("修改失败--name={}不存在！",dInstance.getName());
                return HttpResult.returnFail("修改失败--设备instanceId="+String.valueOf(dInstance.getInstanceid()) + "不存在!");
            }
           return HttpResult.returnSuccess("修改成功");
        } catch (Exception e) {
            LOG.error("修改设备数据源实例失败,失败原因",e);
            return HttpResult.returnFail("设备信息修改失败");
        }
    }

    @ApiOperation("获取设备详情")
    @GetMapping("/{instanceId}")
    @ApiImplicitParam(name = "instanceId",value = "设备数据源实例Id",dataType = "Long",required = true)
    public HttpResult<MetaDeviceInstanceVO> getDeviceInstanceInfo(@PathVariable("instanceId") Long instanceId) {
        if (ObjectUtil.isNull(instanceId)){
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            MetaDeviceInstanceVO deviceInstance = handler.getDeviceDSInstance(instanceId);
            if (ObjectUtil.isNotNull(deviceInstance)){
                return HttpResult.returnSuccess("获取设备详情成功",deviceInstance);
            }else {
                return HttpResult.returnFail("获取设备详情失败--不存在该设备");
            }
        } catch (Exception e) {
            LOG.error("获取设备详情信息失败,instanceId={},失败原因：",instanceId,e);
            return HttpResult.returnFail("获取设备详情信息失败");
        }
    }


    @ApiOperation("条件查询设备列表")
    @PostMapping("/dinstances/{pageSize}/{pageNum}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageSize",value = "每页条数",dataType = "Integer",defaultValue = "10"),
            @ApiImplicitParam(name = "pageNum",value = "页码",dataType = "Integer",defaultValue = "1")
    })
    public HttpResult<PageInfo<MetaDeviceInstanceVO>> findDeviceInstanceList(@RequestBody MetaDeviceInstanceVO deviceInstance,
                                                                             @PathVariable(value = "pageSize") Integer pageSize, @PathVariable(value = "pageNum") Integer pageNum) {
        try {
            if (pageSize == null || pageNum == null || deviceInstance.getDeviceds_id()==null) {
                return HttpResult.returnFail("参数传递错误！");
            } else {
                return HttpResult.returnSuccess("查询成功！", handler.findDeviceDsInstanceList(deviceInstance,pageSize, pageNum));
            }

        } catch (Exception e) {
            LOG.error("查询设备数据源实例列表失败！", e);
            return HttpResult.returnFail("查询设备数据源实例列表失败！");
        }
    }

    @ApiOperation("下载导入模板")
    @PostMapping(value = "/download/template")
    public void exportDeviceInfoModeL(HttpServletResponse response) {
        try {
            handler.exportDeviceInfoModeL(response);
        } catch (Exception e) {
            LOG.error("设备信息模板文件下载异常！", e);
        }
    }

    @ApiOperation("导入设备数据")
    @PostMapping(value = "/import/data/{code}")
    @ApiImplicitParam(name = "code",value = "产品标识",dataType = "Long",required = true)
    public HttpResult importData(MultipartFile file,@PathVariable(value = "code") Long code) {
        if (file == null) {
            LOG.error("参数传递错误-文件为空！");
            return HttpResult.returnFail("文件为空，请选择文件！");
        }
        if (!file.isEmpty()){
            if (!file.getOriginalFilename().endsWith(".xlsx")){
                LOG.error("参数传递错误-文件格式错误！");
                return HttpResult.returnFail("文件格式错误！请传xlsx格式文件！");
            }
        }
        try {
            List<String> errorInfo = handler.uploadDeviceInfoData(file,code);
            if (CollectionUtils.isEmpty(errorInfo)){
                return HttpResult.returnSuccess("设备信息数据导入成功！");
            } else {
                return HttpResult.returnFail("导入失败的设备信息：",errorInfo);
            }
        } catch (Exception e) {
            LOG.error("设备信息数据导入异常！", e);
            return HttpResult.returnFail("设备信息数据导入异常！");
        }
    }

    @ApiOperation("导出设备信息列表")
    @PostMapping(value = "/export/data/{pageSize}/{pageNum}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageSize",value = "每页条数",dataType = "Integer",defaultValue = "10"),
            @ApiImplicitParam(name = "pageNum",value = "页码",dataType = "Integer",defaultValue = "1")
    })
    public void exportData(@RequestBody MetaDeviceInstanceVO deviceInstance,
                           @PathVariable(value = "pageSize") Integer pageSize, @PathVariable(value = "pageNum") Integer pageNum,HttpServletResponse response) {
        try {
            handler.exportDeviceInfoList(deviceInstance,pageSize,pageNum,response);
        } catch (Exception e) {
            LOG.error("设备详情列表信息导出异常！", e);
        }

    }

}
