package com.neoway.iot.gwm.api.device;

import com.neoway.iot.gwm.common.HttpResult;
import com.neoway.iot.gwm.common.PageInfo;
import com.neoway.iot.gwm.vo.MetaDeviceDsVO;
import com.neoway.iot.gwm.handler.DeviceDsHandler;

import com.neoway.iot.gwm.vo.MetaDeviceInstanceVO;
import com.neoway.iot.gwm.vo.TradeTreeVo;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import io.swagger.annotations.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <pre>
 *   描述：设备数据源控制器
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/09/17 18:59
 */
@RestController
@RequestMapping("/v1/product")
@Api(tags = "产品管理")
public class DeviceDsController {
    private static final Logger LOG = LoggerFactory.getLogger(DeviceDsController.class);
    private DeviceDsHandler handler = new DeviceDsHandler();
    @ApiOperation("新增产品")
    @PostMapping
    public HttpResult addDeviceDs(@RequestBody DeviceDS deviceDS) {
        try {
            String validateResult = validateDS(deviceDS);
            if (StringUtils.isNotBlank(validateResult)) {
                return HttpResult.returnFail(validateResult);
            }
            boolean result = handler.addDeviceDs(deviceDS);
            if (result) {
                return HttpResult.returnSuccess("产品信息添加成功！");
            } else {
                return HttpResult.returnFail("重复添加了产品");
            }

        } catch (Exception e) {
            LOG.error("设备数据源信息添加异常！", e);
            return HttpResult.returnFail("设备数据源信息添加异常！");
        }
    }


    @ApiOperation("删除产品")
    @DeleteMapping("/{code}")
    @ApiImplicitParam(name = "code",value = "产品",dataType = "Long",required = true)
    public HttpResult deleteDeviceDs(@PathVariable(value = "code") Long code) {
        if (null == code) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            int result = handler.deleteDeviceDs(code);
            if (0 == result) {
                return HttpResult.returnSuccess("设备数据源信息删除成功！");
            } else if (1 == result) {
                return HttpResult.returnFail("删除失败--该产品不存在！");
            }else if (2 == result){
                return HttpResult.returnFail("删除失败--该产品下已添加设备，无法删除！");
            } else {
                return HttpResult.returnFail("删除失败--原因未知！");
            }
        } catch (Exception e) {
            LOG.error("设备数据源信息删除失败！", e);
            return HttpResult.returnFail("设备数据源信息删除失败！");
        }
    }

    @ApiOperation("编辑产品信息")
    @PutMapping
    public HttpResult updateDeviceDs(@RequestBody DeviceDS deviceDS) {
        if (0 == deviceDS.getCode()) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误，code为必传！");
        }

        try {
            boolean result = handler.updateDeviceDs(deviceDS);
            if (result) {
                return HttpResult.returnSuccess("设备数据源信息更新成功！");
            } else {
                return HttpResult.returnFail("更新失败--无此产品！");
            }

        } catch (Exception e) {
            LOG.error("设备数据源信息更新异常！", e);
            return HttpResult.returnFail("设备数据源信息更新异常！");
        }
    }

    @ApiOperation("查看产品详情")
    @GetMapping("/{code}")
    @ApiImplicitParam(name = "code",value = "产品标识",dataType = "Long",required = true)
    public HttpResult<MetaDeviceDsVO> getDeviceDsInfo(@PathVariable(value = "code") Long code) {
        if (null == code) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            MetaDeviceDsVO deviceDS = handler.getDeviceDsInfo(code);
            return HttpResult.returnSuccess("设备数据源详情查询成功！",deviceDS);
        } catch (Exception e) {
            LOG.error("设备数据源信息查询失败！code={}",code, e);
            return HttpResult.returnFail("设备数据源信息查询失败！");
        }
    }

    @ApiOperation("查询产品记录集")
    @PostMapping("/products/{pageSize}/{pageNum}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageSize",value = "每页条数",dataType = "Integer",defaultValue = "10"),
            @ApiImplicitParam(name = "pageNum",value = "页码",dataType = "Integer",defaultValue = "1")
    })
    public HttpResult<PageInfo<MetaDeviceDsVO>> findDeviceDs(@RequestBody DeviceDS deviceDS,@PathVariable(value = "pageSize") Integer pageSize, @PathVariable(value = "pageNum") Integer pageNum) {
        try {
            if (pageSize == null || pageNum == null ) {
                return HttpResult.returnFail("参数传递错误！");
            }
            PageInfo<MetaDeviceDsVO> pageInfo = handler.findDeviceDsList(deviceDS,pageSize,pageNum);
            return HttpResult.returnSuccess("设备数据源记录集查询成功！",pageInfo);

        } catch (Exception e) {
            LOG.error("设备数据源记录集查询失败！", e);
            return HttpResult.returnFail("设备数据源记录集查询失败！");
        }
    }

    @ApiOperation("行业领域树")
    @GetMapping("/tradetree")
    public HttpResult<List<TradeTreeVo>> getMangeCiTree() {
        try {
            return HttpResult.returnSuccess("行业领域树获取成功",handler.tradeTree());
        } catch (Exception e) {
            LOG.error("行业领域树发生错误，异常信息：",e);
            return HttpResult.returnFail("行业领域树发生错误");
        }
    }

    @ApiOperation("获取标准服务和属性列表")
    @GetMapping("/ciinfo/{deviceType}")
    @ApiImplicitParam(name = "deviceType",value = "产品类别",required = true)
    public HttpResult<DMMetaCI> getDMMetaCi(@PathVariable(value = "deviceType") String deviceType) {
        if (StringUtils.isBlank(deviceType)) {
            LOG.error("参数传递错误");
            return HttpResult.returnFail("参数传递错误！");
        }
        try {
            DMMetaCI result = handler.getDMMetaCi(deviceType);
            if (result != null) {
                LOG.info("服务属性列表查询成功！");
                return HttpResult.returnSuccess("服务属性列表查询成功",result);
            } else {
                LOG.error("服务属性列表查询失败！");
                return HttpResult.returnFail("服务属性列表信息不存在");
            }

        } catch (Exception e) {
            LOG.error("服务属性列表查询异常，异常信息：",e);
            return HttpResult.returnFail("服务属性列表查询异常");
        }
    }

    public String validateDS(DeviceDS deviceDS) {
        String msg = null;
        if (StringUtils.isEmpty(deviceDS.getDomain())) {
            LOG.error("参数传递错误-domain属性不能为空！");
            msg = "参数传递错误-domain属性不能为空！";
        }
        if (StringUtils.isEmpty(deviceDS.getDeviceType())) {
            LOG.error("参数传递错误-device_type属性不能为空！");
            msg = "参数传递错误-device_type属性不能为空！";
        }
        if (StringUtils.isEmpty(deviceDS.getTenant())) {
            LOG.error("参数传递错误-tenant属性不能为空！");
            msg = "参数传递错误-tenant属性不能为空！";
        }
        if (StringUtils.isEmpty(deviceDS.getDeviceVendor())) {
            LOG.error("参数传递错误-vendor属性不能为空！");
            msg = "参数传递错误-vendor属性不能为空！";
        }
        if (StringUtils.isEmpty(deviceDS.getDeviceVersion())) {
            LOG.error("参数传递错误-version属性不能为空！");
            msg = "参数传递错误-version属性不能为空！";
        }
        if (StringUtils.isEmpty(deviceDS.getProtocol())) {
            LOG.error("参数传递错误-protocol属性不能为空！");
            msg = "参数传递错误-protocol属性不能为空！";
        }
        if (StringUtils.isEmpty(deviceDS.getAccessType())) {
            LOG.error("参数传递错误-access_type属性不能为空！");
            msg = "参数传递错误-access_type属性不能为空！";
        }
        return msg;
    }


}
