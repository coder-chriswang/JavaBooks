package com.neoway.iot.gwm;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @desc: Swagger2Config
 * @author: 20200312686
 * @date: 2020/7/8 12:57
 */
@Configuration
@EnableSwagger2
public class Swagger2Config {
    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.neoway.iot.gwm.api"))
                .paths(PathSelectors.any())
                .build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Ares-统一接入管理-1.0 API文档")
                .version("1.0")
                .build();
    }

    /**
     * 分组---设备数据源
     * @return
     */
    @Bean
    public Docket createDeviceApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("设备数据源")
                .apiInfo(apiDeviceInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.neoway.iot.gwm.api.device"))
                .build();
    }
    private ApiInfo apiDeviceInfo() {
        return new ApiInfoBuilder()
                .title("设备数据源管理")
                .description("设备数据源管理相关的接口")
                .version("1.0")
                .build();
    }

    /**
     * 分组---系统数据源
     * @return
     */
    @Bean
    public Docket createSystemApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("系统数据源")
                .apiInfo(apiSystemInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.neoway.iot.gwm.api.system"))
                .build();
    }
    private ApiInfo apiSystemInfo() {
        return new ApiInfoBuilder()
                .title("系统数据源管理")
                .description("系统数据源管理相关的接口")
                .version("1.0")
                .build();
    }
    /**
     * 分组---服务
     * @return
     */
    @Bean
    public Docket createModelTreeApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("服务")
                .apiInfo(apiModelTreeInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.neoway.iot.gwm.api.service"))
                .build();
    }
    private ApiInfo apiModelTreeInfo() {
        return new ApiInfoBuilder()
                .title("服务管理")
                .description("服务管理相关的接口")
                .version("1.0")
                .build();
    }

    /**
     * 分组---数据字典
     * @return
     */
    @Bean
    public Docket createDictionaryInfoApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("下拉选择框数据管理")
                .apiInfo(apiDictionaryInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.neoway.iot.gwm.api.dictionary"))
                .build();
    }
    private ApiInfo apiDictionaryInfo() {
        return new ApiInfoBuilder()
                .title("下拉选择框数据管理")
                .description("下拉选择框数据管理的接口")
                .version("1.0")
                .build();
    }
}
