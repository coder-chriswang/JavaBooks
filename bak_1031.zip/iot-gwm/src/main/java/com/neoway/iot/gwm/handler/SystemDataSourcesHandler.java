package com.neoway.iot.gwm.handler;


import com.neoway.iot.gwm.vo.MetaCiTreeVo;
import com.neoway.iot.gwm.vo.SystemDsVo;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.util.DMUtil;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.SystemDS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @desc: MetaDeviceInstanceController 数据源设备实例控制器
 * @author: 20200416002
 * @date: 2020/9/17 17:22
 */
public class SystemDataSourcesHandler {
    private static final Logger LOG = LoggerFactory.getLogger(SystemDataSourcesHandler.class);
    private DMRunner runner;

    public SystemDataSourcesHandler() {
        this.runner = DMRunner.getInstance();
    }

    /**
     * 获取系统数据源详情
     *
     * @param code
     * @return
     */
    public SystemDsVo getSystemDS(Long code) {
        SystemDsVo systemDSVo = new SystemDsVo();
        DMDataPoint condition = DMDataPoint.builder(SystemDsVo.NS, SystemDsVo.CATEGORY, SystemDsVo.CI);
        DMDataColumn conditionColumn = new DMDataColumn("code", code,true);
        condition.addColumn(conditionColumn);
        DMDataPoint dataPoint = runner.get(condition);
        SystemDS systemDs = SystemDsVo.buildSystemDS(dataPoint, false);
        if (null != systemDs) {
            BeanUtils.copyProperties(systemDs, systemDSVo);
        } else {
            systemDSVo = null;
        }
        return systemDSVo;
    }

    /**
     * 系统数据源连通性检测
     *
     * @param code
     * @return
     */
    public String checkSystemDsConnectivity(Long code) {
        LOG.info("开始进行系统数据源连通性检测！");
        DMDataPoint condition = DMDataPoint.builder(SystemDsVo.NS, SystemDsVo.CATEGORY, SystemDsVo.CI);
        condition.addColumn(new DMDataColumn("code",code));
        DMDataPoint dataPoint = runner.get(condition);
        SystemDS systemDs = SystemDsVo.buildSystemDS(dataPoint, false);
        if (systemDs == null) {
            return "OFFLINE";
        }
        String templateId = "";
        if (null != dataPoint) {
            templateId = systemDs.getHealth_templateid();
        }
        //调用gw的Restful接口检测连通性，传入templateId
        LOG.info("系统数据源连通性检测结束！");
        return "ONLINE";
    }

    /**
     * 系统数据源树
     *
     * @return
     */

    public List<SystemDsVo> tree() {
        DMDataPoint condition = DMDataPoint.builder(SystemDsVo.NS, SystemDsVo.CATEGORY, SystemDsVo.CI);
        condition.getMetaCI().setCache(false);
        List<DMDataPoint> dataPoint = runner.list(condition);
        if (dataPoint == null || dataPoint.size() == 0) {
            return null;
        }
        List<SystemDsVo> resultList = new ArrayList<>();

        dataPoint.forEach(p -> {
            SystemDsVo systemDsVo =(SystemDsVo) DMUtil.buildClazzInstance(p, SystemDsVo.class);
            if (systemDsVo != null) {
                resultList.add(systemDsVo);
            }
        });
        return resultList;
    }

    /**
     * 管理资源树
     * @return
     */
    public MetaCiTreeVo ciTree() {
        MetaCiTreeVo treeVo = new MetaCiTreeVo();
        DMMetaCI ci = new DMMetaCI();
        ci.setType("M");
        List<DMMetaCI> list = runner.queryMetaCi(ci);
        treeVo.setCiList(list);
        treeVo.setType("M");
        return treeVo;
    }
}
