package com.neoway.iot.gwm.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * <pre>
 *   描述：行业领域树
 * </pre>
 *
 * @author Baron(ouyangxiaotong)
 * @version 1.0.0
 * @date 2020/10/15 09:52
 */
@ApiModel("行业领域树")
public class TradeTreeVo {
    @ApiModelProperty("行业编码")
    private String h_code;
    @ApiModelProperty("行业名称")
    private String h_name;
    @ApiModelProperty("领域集合")
    private List<DomainTreeVo> domainList;

    public String getH_code() {
        return h_code;
    }

    public void setH_code(String h_code) {
        this.h_code = h_code;
    }

    public String getH_name() {
        return h_name;
    }

    public void setH_name(String h_name) {
        this.h_name = h_name;
    }

    public List<DomainTreeVo> getDomainList() {
        return domainList;
    }

    public void setDomainList(List<DomainTreeVo> domainList) {
        this.domainList = domainList;
    }
}
