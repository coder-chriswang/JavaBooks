package com.neoway.iot.gw.input.connector;

/**
 * @desc: ConnectorType
 * @author: 20200312686
 * @date: 2020/6/30 15:59
 */
public enum ConnectorType {
    JT808("com.neoway.iot.gw.input.connector.jt808.JT808Connector"),
    HJ212("com.neoway.iot.gw.input.connector.hj212.HJ212Connector"),
    MQTT("com.neoway.iot.gw.input.connector.mqtt.MQTTConnector"),
    HTTP("com.neoway.iot.gw.input.connector.restful.HTTPConnector"),
    HTTPS("com.neoway.iot.gw.input.connector.restful.HTTPSConnector"),
    EMPTY("com.neoway.iot.gw.input.connector.empty.EmptyConnector"),
    SL651("com.neoway.iot.gw.input.connector.sl651.SL651Connector"),
    DMK("com.neoway.iot.gw.input.connector.dmk.DMKConnector"),
    JDBC("com.neoway.iot.gw.input.connector.jdbc.JDBCConnector"),
    OTHER(null);
    private final String connectorClassName;

    private ConnectorType(String connectorClassName) {
        this.connectorClassName = connectorClassName;
    }

    public String getConnectorClassName() {
        return connectorClassName;
    }
}
