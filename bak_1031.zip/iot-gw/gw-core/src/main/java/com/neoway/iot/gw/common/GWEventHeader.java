package com.neoway.iot.gw.common;

import com.neoway.iot.sdk.dmk.meta.DMMetaEnum;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * @desc: GWEventHeader
 * @author: 20200312686
 * @date: 2020/9/14 16:58
 */
public class GWEventHeader {
    public static final String CMDID="cmdId";
    //原始请求结构体
    private GWRequest request;
    private String cmdId;
    //指令分组
    private DMMetaEnum.MetaActionEnum cmdGroup;
    //header扩展信息
    private Map<String,Object> ext=new HashMap<>();
    private int ts;
    private String reqId;

    public GWEventHeader(){

    }
    public GWEventHeader(GWRequest request){
        this.request=request;
        this.ext=request.getHeader().getExt();
        this.cmdGroup=request.getHeader().getActionGroup();
        this.cmdId=request.getHeader().getActionGroup().name();
        if(DMMetaEnum.MetaActionEnum.CustomeEvent == cmdGroup){
            Map<String,Object> cmdMap=request.getHeader().getExt();
            if(cmdMap.containsKey(CMDID)){
                String cmdId=(String)cmdMap.get(CMDID);
                this.cmdId=cmdId;
            }
        }
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GWEventHeader that = (GWEventHeader) o;
        return Objects.equals(reqId, that.reqId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reqId);
    }

    public DMMetaEnum.MetaActionEnum getCmdGroup() {
        return cmdGroup;
    }

    public void setCmdGroup(DMMetaEnum.MetaActionEnum cmdGroup) {
        this.cmdGroup = cmdGroup;
    }

    public GWRequest getRequest() {
        return request;
    }

    public void setRequest(GWRequest request) {
        this.request = request;
    }

    public int getTs() {
        return ts;
    }

    public void setTs(int ts) {
        this.ts = ts;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public Map<String, Object> getExt() {
        return ext;
    }

    public void setExt(Map<String, Object> ext) {
        this.ext = ext;
    }

    public String getCmdId() {
        return cmdId;
    }

    public void setCmdId(String cmdId) {
        this.cmdId = cmdId;
    }

    public GWEventHeader build(String reqId, int ts){
        if(StringUtils.isEmpty(reqId)){
            this.reqId= UUID.randomUUID().toString();
        }else{
            this.reqId=reqId;
        }
        if(ts <= 0){
            Long tsmil=System.currentTimeMillis()/1000;
            this.ts=tsmil.intValue();
        }else{
            this.ts=ts;
        }
        return this;
    }
}
