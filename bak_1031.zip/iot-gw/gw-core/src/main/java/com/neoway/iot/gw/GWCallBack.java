package com.neoway.iot.gw;

import com.neoway.iot.sdk.dmk.data.DMDataCallBack;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @desc: DGCallBack
 * @author: 20200312686
 * @date: 2020/9/2 10:19
 */
public class GWCallBack implements DMDataCallBack {
    private static final Logger LOG = LoggerFactory.getLogger(GWCallBack.class);
    @Override
    public void callBack(DMDataOper oper, DMDataPoint point) {
        //DM数据变更通知。对于DGW来说只关注SystemDS、DeviceDS
        DMMetaCI metaCI=point.getMetaCI();
        if(null == metaCI){
            return;
        }
        /*if(!metaCI.getCategory().equalsIgnoreCase(DeviceDS.DSCATEGORY)){
            return;
        }
        if(metaCI.getCi().equalsIgnoreCase(MetaDeviceDS.DSCI)){
            MetaDeviceDS deviceDS=MetaDeviceDS.buildMetaDeviceDS(point);
            ConnectorManager.getInstance().dynamicDeviceConnector(oper,deviceDS);
        }else if(metaCI.getCi().equalsIgnoreCase(MetaSystemDS.DSCI)){
            MetaSystemDS systemDS=MetaSystemDS.buildMetaSystemDS(point);
            ConnectorManager.getInstance().dynamicSystemConnector(oper,systemDS);
        }else{
            return;
        }*/

    }
}
