package com.neoway.iot.gw.common.router;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.gson.Gson;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.common.utils.GWUtils;
import com.neoway.iot.gw.input.template.TemplateManager;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.ActionMapping;
import com.neoway.iot.sdk.gwk.entity.DeviceInstance;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @desc: 上行-模板定位路由表
 * @author: Chris(wangchao)
 * @date: 2020/9/14 19:28
 */
public class UplinkRouterTemplateMem implements CacheRouter<RouteUplinkTemplate> {
    private static final Logger LOG = LoggerFactory.getLogger(UplinkRouterTemplateMem.class);
    private static final String CACHE_SPLIT="@##@";
    // 模板定位路由表
    private LoadingCache<String, RouteUplinkTemplate> templateLoadingCache;
    private DMRunner runner;
    @Override
    public void start(GWConfig config) {
        int cacheMaxSize=500000;
        int cacheInitSize=1000;
        this.runner=DMRunner.getInstance();
        templateLoadingCache= CacheBuilder.newBuilder()
                .maximumSize(cacheMaxSize)
                .recordStats()
                .initialCapacity(cacheInitSize)
                .build(new CacheLoader<String, RouteUplinkTemplate>() {
                    @Override
                    public RouteUplinkTemplate load(String s) throws Exception {
                        LOG.debug("数据缓存不存在，从数据库加载:s={}",s);
                        // 加载单个未命中的缓存，从数据库根据s(key)进行查询返回该对象
                        RouteUplinkTemplate routeUplinkTemplate;
                        String[] params = s.split(CACHE_SPLIT);
                        String querySql = MessageFormat.format(SQL, params[0], params[1]);
                        try {
                            List<Map<String, Object>> result = runner.executeSQL(querySql);
                            if (CollectionUtils.isEmpty(result)) {
                                LOG.error("查询数据库模板不存在！");
                                routeUplinkTemplate = null;
                            } else {
                                Map<String, Object> map = result.get(0);
                                routeUplinkTemplate = new RouteUplinkTemplate();
                                routeUplinkTemplate.setDeviceDsCode(Long.valueOf(String.valueOf(map.get("deviceDsCode"))));
                                routeUplinkTemplate.setMetaActionId(String.valueOf(map.get("metaActionId")));
                                routeUplinkTemplate.setNativeActionId(String.valueOf(map.get("nativeActionId")));
                                routeUplinkTemplate.setNativeId(String.valueOf(map.get("nativeid")));
                                routeUplinkTemplate.setInstanceid(Long.valueOf(String.valueOf(map.get("instanceid"))));
                                routeUplinkTemplate.setTemplateId(String.valueOf(map.get("templateId")));
                                // DbUtils支持别名后，可直接由map转routeUplinkTemplate
                            }
                        } catch (Exception e) {
                            LOG.error("查询错误！", e);
                            routeUplinkTemplate = null;
                        }
                        return routeUplinkTemplate;
                    }
                });
        // 加载缓存
        this.load();
    }

    /**
     * @desc 生成缓存KEY
     * @param nativeid 设备唯一标识
     * @param cmdId 原始服务标识
     * @return
     */
    private String buildCacheKey(String nativeid, String cmdId) {
        StringBuilder sb = new StringBuilder();
        sb.append(nativeid).append(CACHE_SPLIT).append(cmdId);
        return sb.toString();
    }

    @Override
    public void load() {
        try {
            DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceInstance.class);
            DMDataPoint condition=DMDataPoint.builder(metaCI.getNs(), metaCI.getCategory(),metaCI.getCi());
            // 查询出deviceInstance所有实例
            List<DMDataPoint> points = runner.list(condition);
            if (CollectionUtils.isEmpty(points)) {
                return;
            }
            List<RouteUplinkTemplate> routeUplinkTemplates = new ArrayList<>();
            DMMetaCI actionMappingMetaCI=DMMetaCI.getMetaCI(ActionMapping.class);
            for (DMDataPoint point : points) {
                DeviceInstance metaDeviceInstance = DeviceInstance.buildDeviceInstance(point);
                if (metaDeviceInstance == null) {
                    continue;
                }
                condition=DMDataPoint.builder(
                        actionMappingMetaCI.getNs(),
                        actionMappingMetaCI.getCategory(),
                        actionMappingMetaCI.getCi());
                DMDataColumn column=new DMDataColumn("ds_code", metaDeviceInstance.getDeviceDSId());
                condition.addColumn(column);
                List<DMDataPoint> actionPoints=runner.list(condition);
                List<ActionMapping> actionMappingList=new ArrayList<>();
                for(DMDataPoint actionPoint:actionPoints){
                    ActionMapping actionMapping=ActionMapping.buildActionMapping(actionPoint);
                    actionMappingList.add(actionMapping);
                }
                if (CollectionUtils.isEmpty(actionMappingList)) {
                    continue;
                }
                for (ActionMapping actionMapping : actionMappingList) {
                    RouteUplinkTemplate routeUplinkTemplate = new RouteUplinkTemplate();
                    routeUplinkTemplate.setDeviceDsCode(metaDeviceInstance.getDeviceDSId());
                    routeUplinkTemplate.setMetaActionId(actionMapping.getMeta_action_id());
                    routeUplinkTemplate.setNativeActionId(actionMapping.getAction_id());
                    routeUplinkTemplate.setNativeId(metaDeviceInstance.getNativeid());
                    routeUplinkTemplate.setInstanceid(metaDeviceInstance.getInstanceid());
                    routeUplinkTemplate.setTemplateId(actionMapping.getTemplate_id());
                    routeUplinkTemplates.add(routeUplinkTemplate);
                }
                if (CollectionUtils.isEmpty(routeUplinkTemplates)) {
                    LOG.warn("未查询到有效RouteUplinkTemplate");
                    return;
                }
                routeUplinkTemplates.stream().distinct().collect(Collectors.toList());
                // 进缓存
                routeUplinkTemplates.forEach(r -> {
                    TemplateManager manager = TemplateManager.getInstance();
                    MetaTemplate tpl = manager.getTemplate(r.getTemplateId());
                    if (tpl != null) {
                        templateLoadingCache.put(buildCacheKey(r.getNativeId(), r.getNativeActionId()), r);
                    }
                });
            }
        } catch (Exception e) {
            LOG.error("加载缓存失败！", e);
        }
    }

    @Override
    public void clear() {
        templateLoadingCache.cleanUp();
    }

    @Override
    public RouteUplinkTemplate get(String k) {
        RouteUplinkTemplate routeUplinkTemplate = null;
        try {
            routeUplinkTemplate = templateLoadingCache.get(k);
        } catch (Exception e) {
            LOG.error("查询不到模板路由！", e);
        }
        return routeUplinkTemplate;
    }


    private static final String SQL = "SELECT\n" +
            "\ta.instanceid AS instanceid,\n" +
            "\ta.deviceds_id AS deviceDsCode,\n" +
            "\ta.nativeid AS nativeid,\n" +
            "\tb.template_id AS templateId,\n" +
            "\tb.meta_action_id AS metaActionId,\n" +
            "\tb.action_id AS nativeActionId \n" +
            "FROM\n" +
            "\ties_gwm.GWM_B_DEVICEINSTANCE a\n" +
            "\tLEFT JOIN ies_gwm.GWM_B_ACTIONMAPPING b ON a.deviceds_id = b.ds_code \n" +
            "WHERE\n" +
            "\ta.nativeid = ''{0}'' \n" +
            "\tAND b.action_id = ''{1}'';";
}
