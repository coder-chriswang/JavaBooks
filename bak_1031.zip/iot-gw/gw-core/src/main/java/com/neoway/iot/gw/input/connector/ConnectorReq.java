package com.neoway.iot.gw.input.connector;

import com.neoway.iot.gw.common.utils.GWUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: ConnectorReq
 * @author: 20200312686
 * @date: 2020/6/29 17:34
 */
public class ConnectorReq {
    private Map<String,Object> header=new HashMap<>();
    private String endpoint;
    private String request;
    public ConnectorReq(){

    }
    public ConnectorReq(String header, String endpoint, String request) {
        this.header = GWUtils.getJsonUtil().fromJson(header,Map.class);
        this.endpoint = endpoint;
        this.request = request;
    }

    public Map<String, Object> getHeader() {
        return header;
    }

    public void setHeader(Map<String, Object> header) {
        this.header = header;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public void buildHeader(String header){
        this.header = GWUtils.getJsonUtil().fromJson(header,Map.class);
    }
}
