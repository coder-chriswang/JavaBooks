package com.neoway.iot.gw.common.plugin;

import com.neoway.iot.gw.common.GWRequest;

import java.util.Map;

/**
 * @desc: RtPluginJs
 * @author: 20200312686
 * @date: 2020/9/17 9:36
 */
public class RtPluginJs implements RtPlugin {
    @Override
    public void start() {

    }

    @Override
    public String name() {
        return null;
    }

    @Override
    public Map<String, Object> executePlugin(String plugin, GWRequest request) {
        return null;
    }
}
