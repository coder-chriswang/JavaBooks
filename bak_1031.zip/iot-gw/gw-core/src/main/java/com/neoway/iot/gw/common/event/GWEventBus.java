package com.neoway.iot.gw.common.event;

import com.google.common.eventbus.AsyncEventBus;
import com.google.common.eventbus.EventBus;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

import java.util.concurrent.*;

/**
 * <pre>
 *  描述: Guava消息总线Center
 *  消息发布-订阅类
 *  EventBus是将消息队列放入到内存中的，listener消费这个消息队列，故系统重启之后，保存或者堆积在队列中的消息丢失。
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/08 16:35
 */
public class GWEventBus {
    private static final int QUEUE_SIZE = 1024;
    private static final int CORE_POOL_SIZE = 2;
    private static final int MAX_POOL_SIZE = 5;
    private static final int KEEP_ALIVE_TIME = 5;
    private static final String POOL_NAME = "dgw_eventbus";
    private static EventBus eventBus;
    static {
        ThreadFactory threadFactory = new ThreadFactoryBuilder().setNameFormat(POOL_NAME).build();
        BlockingQueue<Runnable> queue = new LinkedBlockingDeque<>(QUEUE_SIZE);
        ExecutorService pool = new ThreadPoolExecutor(CORE_POOL_SIZE, MAX_POOL_SIZE, KEEP_ALIVE_TIME, TimeUnit.MILLISECONDS, queue, threadFactory, new ThreadPoolExecutor.AbortPolicy());
        eventBus = new AsyncEventBus(pool);
    }
    /**
     * 注册
     * 只有通过@Subscribe注解的方法才会被注册进EventBus
     * @param obj 观察者
     */
    public static void register(Object obj) {
        eventBus.register(obj);
    }

    /**
     * 销毁
     * @param obj 观察者
     */
    public static void unregister(Object obj) {
        eventBus.unregister(obj);
    }

    /**
     * 发布
     * 注意：post() 不支持自动装箱功能
     * 交给有@Subscribe注解的方法去处理
     * 多个方法可以同时处理一个消息，可以理解为多播
     * @param event 消息（这里我们可以直接指定DGWEvent对象）
     */
    public static void post(GWBusEvent event) {
        eventBus.post(event);
    }
}
