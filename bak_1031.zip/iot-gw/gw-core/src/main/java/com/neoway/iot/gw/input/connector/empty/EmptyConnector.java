package com.neoway.iot.gw.input.connector.empty;

import com.neoway.iot.gw.input.connector.Connector;
import com.neoway.iot.gw.input.connector.ConnectorReq;
import com.neoway.iot.gw.input.connector.ConnectorRsp;

import java.util.Map;

/**
 * @desc: EmptyConnector
 * @author: 20200312686
 * @date: 2020/9/17 15:38
 */
public class EmptyConnector extends Connector {
    @Override
    public String name() {
        return "input-connector-empty";
    }
    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        ConnectorRsp rsp=new ConnectorRsp();
        rsp.setHeader(request.getHeader());
        return rsp;
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }
}
