package com.neoway.iot.gw.input.connector.hj212.model;

/**
 * <pre>
 *  描述: HJ212DeviceSession
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/09/10 15:05
 */
public class HJ212DeviceSession {

    public HJ212DeviceSession() {
    }
    /**
     * 设备唯一标识
     */
    private String mn;

    public HJ212DeviceSession(String mn) {
        this.mn = mn;
    }
}
