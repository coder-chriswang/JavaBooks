package com.neoway.iot.gw.api;

import com.neoway.iot.gw.channel.Channel;
import com.neoway.iot.gw.channel.ChannelManager;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.input.Input;
import com.neoway.iot.gw.input.InputManager;
import com.neoway.iot.gw.output.Output;
import com.neoway.iot.gw.output.OutputManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: 管理API
 * @author: 20200312686
 * @date: 2020/6/23 9:02
 */
@RestController
@RequestMapping("/v1/manage")
@Api(tags = "管理")
public class ManageController {

    @ApiOperation("查询系统中加载的插件列表")
    @GetMapping("/plugins")
    public GWResponse queryPlugin() {
        GWResponse response = new GWResponse();
        List<Input> inputs = InputManager.getInstance().getInputs();
        List<Map<String,Object>> plugins=new ArrayList<>();
        Map<String, Object> result = new HashMap<>();
        for (Input input : inputs) {
            Map<String, Object> inputResult = new HashMap<>();
            inputResult.put("name", input.name());
            inputResult.put("enable", input.isEnable());
            inputResult.put("configuration", input.configuration());
            plugins.add(inputResult);
        }
        result.put("input",plugins);
        plugins=new ArrayList<>();
        List<Channel> channels = ChannelManager.getInstance().getChannels();
        for (Channel channel : channels) {
            Map<String, Object> channelResult = new HashMap<>();
            channelResult.put("name", channel.name());
            channelResult.put("enable", true);
            channelResult.put("configuration", channel.configuration());
            plugins.add(channelResult);
        }
        result.put("channel",plugins);
        plugins=new ArrayList<>();
        List<Output> outputs = OutputManager.getInstance().getOutputs();
        for (Output output : outputs) {
            Map<String, Object> outputResult = new HashMap<>();
            outputResult.put("name", output.name());
            outputResult.put("enable", output.isEnable());
            outputResult.put("configuration", output.configuration());
            plugins.add(outputResult);
        }
        result.put("output",plugins);
        response.setData(result);
        return response;
    }

    @ApiOperation("获取当前统计数据")
    @GetMapping("/stats")
    public GWResponse getStats() {
        return null;
    }

}
