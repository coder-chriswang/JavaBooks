package com.neoway.iot.gw;

import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.config.GWConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @desc: 组件生命周期管理基类
 * @author: 20200312686
 * @date: 2020/6/22 12:32
 */
public abstract class GWAbstractLifecycleComponent implements GWLifecycleComponent {
    private static final Logger LOG = LoggerFactory.getLogger(GWAbstractLifecycleComponent.class);
    protected GWAbstractLifecycleComponent() {}
    @Override
    public void start() throws GWException {
        LOG.info("组件：{} 开始启动", this.name());
        GWConfig config= GWConfig.getInstance();
        try{
            doStart(config);
            LOG.info("组件：{} 启动成功", this.name());
        }catch (GWException e){

        }

    }

    protected abstract void doStart(GWConfig env) throws GWException;

    protected abstract String name();
    @Override
    public void stop() {
        LOG.info("组件：{} 停止", this.name());
    }


}
