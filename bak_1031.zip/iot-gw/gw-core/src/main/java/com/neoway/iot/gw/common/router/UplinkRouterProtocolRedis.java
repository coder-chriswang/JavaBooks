package com.neoway.iot.gw.common.router;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.common.redis.JedisUtil;
import com.neoway.iot.gw.input.template.TemplateManager;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.DSExt;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * @desc: 上行-协议解析路由表
 * @author: Chris(wangchao)
 * @date: 2020/9/14 19:28
 */
public class UplinkRouterProtocolRedis implements CacheRouter<RouteUplinkProtocol> {
    private static final Logger LOG = LoggerFactory.getLogger(UplinkRouterProtocolRedis.class);
    private static final String CACHE_SPLIT="@##@";
    private static final String PATTER = "*" + CACHE_SPLIT + "*";
    private DMRunner runner;
    private JedisPool pool;
    private static final String CONFIGURATION_DB="router.protocol.redis.db";
    private static final String CONFIGURATION_HOST="router.protocol.redis.host";
    private static final String CONFIGURATION_PORT="router.protocol.redis.port";
    private static final String CONFIGURATION_PWD="router.protocol.password";
    private static final String CONFIGURATION_TIMEOUT="router.protocol.redis.timeout";
    private static final String CONFIGURATION_MAX_ACTIVE="router.protocol.redis.max_active";
    private static final String CONFIGURATION_MAX_WAIT="router.protocol.redis.max_wait";
    private static final String CONFIGURATION_MAX_IDEL="router.protocol.redis.max_idel";
    private static final String CONFIGURATION_MIN_IDEL="router.protocol.redis.min_idel";

    @Override
    public void start(GWConfig config) {
        this.runner = DMRunner.getInstance();
        JedisUtil.Builder builder=JedisUtil.builder();
        builder = builder.buildURI((String)config.getValue(CONFIGURATION_HOST),
                String.valueOf(config.getValue(CONFIGURATION_PORT)),
                String.valueOf(config.getValue(CONFIGURATION_TIMEOUT)),
                String.valueOf(config.getValue(CONFIGURATION_PWD)),
                String.valueOf(config.getValue(CONFIGURATION_DB)));
        builder = builder.buildPool(String.valueOf(config.getValue(CONFIGURATION_MAX_ACTIVE)),
                String.valueOf(config.getValue(CONFIGURATION_MAX_WAIT)),
                String.valueOf(config.getValue(CONFIGURATION_MAX_IDEL)),
                String.valueOf(config.getValue(CONFIGURATION_MIN_IDEL)));
        JedisUtil utils = new JedisUtil();
        utils.start(builder);
        this.pool=utils.getJedisPool();
        // 加载router缓存
        this.load();
    }
    /**
     * @desc 生成缓存KEY
     * @param protocol
     * @param topic
     * @return
     */
    private String buildCacheKey(String protocol,String topic) {
        StringBuilder sb = new StringBuilder();
        sb.append(protocol).append(CACHE_SPLIT).append(topic);
        return sb.toString();
    }

    @Override
    public void load() {
        DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceDS.class);
        DMDataPoint condition=DMDataPoint.builder(metaCI.getNs(), metaCI.getCategory(),metaCI.getCi());
        // 查询出deviceDS所有实例
        List<DMDataPoint> points = runner.list(condition);
        if (CollectionUtils.isEmpty(points)) {
            return;
        }
        List<RouteUplinkProtocol> routeUplinkProtocols = new ArrayList<>();
        for (DMDataPoint point : points) {
            DeviceDS deviceDS = DeviceDS.buildDeviceDS(point,true);
            if (deviceDS == null) {
                continue;
            }
            // 得到该deviceDS实例下attr=topic的集合,集合元素有一个
            DSExt.MQTTExt mqttExt= deviceDS.getMQTTExt();
            if (mqttExt == null) {
                continue;
            }
            if (mqttExt == null) {
                continue;
            }
            RouteUplinkProtocol uplinkProtocol = new RouteUplinkProtocol();
            uplinkProtocol.setTopic(mqttExt.getTopic());
            uplinkProtocol.setProtocol(deviceDS.getProtocol());
            uplinkProtocol.setAccessType(deviceDS.getAccessType());
            uplinkProtocol.setTemplateId(RouterConstant.UplinkTemplateId.getTemplateIdByAccessType(uplinkProtocol.getAccessType(),
                    uplinkProtocol.getProtocol()));
            routeUplinkProtocols.add(uplinkProtocol);
        }
        if (CollectionUtils.isEmpty(routeUplinkProtocols)) {
            LOG.warn("未查询到有效RouteUplinkProtocol");
            return;
        }
        // 集合去重
        routeUplinkProtocols.stream().distinct().collect(Collectors.toList());
        Gson gson = new Gson();
        // 放入缓存
        try (Jedis jedis = this.pool.getResource()) {
            routeUplinkProtocols.forEach(r -> {
                TemplateManager manager = TemplateManager.getInstance();
                MetaTemplate tpl = manager.getTemplate(r.getTemplateId());
                // 模板存在，放入缓存
                if (tpl != null) {
                    jedis.set(buildCacheKey(r.getProtocol(), r.getTopic()), gson.toJson(r));
                }
            });
        } catch (Exception e) {
            LOG.error("RouteUplinkProtocol写入Redis缓存失败", e);
        }
    }

    @Override
    public void clear() {
        try (Jedis jedis = this.pool.getResource()) {
            // 清除缓存
            Set<String> keys = jedis.keys(PATTER);
            keys.forEach(jedis::del);
        } catch (Exception e) {
            LOG.error("RouteUplinkProtocol删除Redis缓存失败", e);
        }
    }

    @Override
    public RouteUplinkProtocol get(String k) {
        RouteUplinkProtocol routeUplinkProtocol = null;
        Gson gson = new Gson();
        try (Jedis jedis = this.pool.getResource()) {
            String result = jedis.get(k);
            routeUplinkProtocol = gson.fromJson(result, new TypeToken<RouteUplinkProtocol>() {}.getType());
        } catch (Exception e) {
            LOG.error("获取RouteUplinkProtocol失败", e);
        }
        return routeUplinkProtocol;
    }
}
