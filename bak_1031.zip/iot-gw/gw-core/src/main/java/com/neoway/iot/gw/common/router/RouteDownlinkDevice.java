package com.neoway.iot.gw.common.router;

import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;

/**
 * @desc: 下行-设备路由结构
 * @author: 20200312686
 * @date: 2020/9/15 13:51
 */
public class RouteDownlinkDevice {
    /**
     * 资源ID
     */
    private long instanceid;
    /**
     * 产品域
     */
    private String ns;
    /**
     * 主题
     */
    private String category;
    /**
     * 对象
     */
    private String ci;
    /**
     * 设备数据源编码
     */
    private String deviceDsCode;
    /**
     * 标准服务ID
     */
    private String metaActionId;
    /**
     * 资源分区
     */
    private String region;
    /**
     * 模板ID
     */
    private String templateId;

    //对象元数据
    private transient DMMetaCI metaCI;
    //设备数据源
    private transient DeviceDS deviceDS;
    //数据源实例
    private transient DMDataPoint point;

    public long getInstanceid() {
        return instanceid;
    }

    public void setInstanceid(long instanceid) {
        this.instanceid = instanceid;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getDeviceDsCode() {
        return deviceDsCode;
    }

    public void setDeviceDsCode(String deviceDsCode) {
        this.deviceDsCode = deviceDsCode;
    }

    public String getMetaActionId() {
        return metaActionId;
    }

    public void setMetaActionId(String metaActionId) {
        this.metaActionId = metaActionId;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public DMMetaCI getMetaCI() {
        return metaCI;
    }

    public void setMetaCI(DMMetaCI metaCI) {
        this.metaCI = metaCI;
    }


    public DeviceDS getDeviceDS() {
        return deviceDS;
    }

    public void setDeviceDS(DeviceDS deviceDS) {
        this.deviceDS = deviceDS;
    }

    public DMDataPoint getPoint() {
        return point;
    }

    public void setPoint(DMDataPoint point) {
        this.point = point;
    }
}
