package com.neoway.iot.gw.channel;

import com.neoway.iot.gw.GWAbstractLifecycleComponent;
import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.sdk.dmk.meta.DMMetaEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: ChannelManager
 * @author: 20200312686
 * @date: 2020/6/23 10:03
 */
public class ChannelManager extends GWAbstractLifecycleComponent {
    private static final Logger LOG = LoggerFactory.getLogger(ChannelManager.class);
    public static final String BACKEND = "dgw.channel.backend";
    private static ChannelManager manager=null;
    private List<Channel> channelsModules=new ArrayList<>();
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private ChannelManager() {

    }

    @Override
    protected void doStart(GWConfig env) throws GWException {
        if(isStarted.get()){
            return;
        }
        List<ChannelType> channelTypes=new ArrayList<>();
        channelTypes.add(ChannelType.DIRECT);
        String backend = String.valueOf(env.getValue(BACKEND));
        if (ChannelType.REDIS.name().toLowerCase().equals(backend)) {
            channelTypes.add(ChannelType.REDIS);
        }else{
            channelTypes.add(ChannelType.MEMORY);
        }
        for(ChannelType channelType:channelTypes){
            Channel channel=this.create(channelType.name(),channelType.getChannelClassName());
            channelsModules.add(channel);
            channel.start(env);
        }
        isStarted.set(true);
    }

    @Override
    protected String name() {
        return "module-channel";
    }

    public static ChannelManager getInstance() {
        if (manager == null) {
            synchronized (ChannelManager.class) {
                if (manager == null) {
                    manager = new ChannelManager();
                }
            }
        }
        return manager;
    }

    /**
     * @desc channel实例化
     * @param name
     * @param type
     * @return
     * @throws GWException
     */
    private Channel create(String name, String type) throws GWException {
        LOG.info("创建channel实例 类型={} clazz={}", name, type);
        Class<? extends Channel> channelClass = getClass(name);
        try {
            return channelClass.newInstance();
        } catch (Exception ex) {
            throw new GWException("",ex.getMessage());
        }
    }

    /**
     * @desc 获取channel clazz
     * @param type
     * @return
     * @throws GWException
     */
    private Class<? extends Channel> getClass(String type) throws GWException {
        String channelClassName = type;
        ChannelType channelType = ChannelType.OTHER;
        try {
            channelType=ChannelType.valueOf(type.toUpperCase(Locale.ENGLISH));
        } catch (IllegalArgumentException ex) {
            LOG.error("Channel类型非内置，属于自定义", type);
        }
        if (!channelType.equals(channelType.OTHER)) {
            channelClassName = channelType.getChannelClassName();
        }
        try {
            return (Class<? extends Channel>) Class.forName(channelClassName);
        } catch (Exception ex) {
            throw new GWException("",ex.getMessage());
        }
    }

    /**
     * @desc 获取订阅topic的channel
     * @param cmd
     * @return
     */
    public Channel getChannel(DMMetaEnum.MetaActionEnum cmd){
        if(DMMetaEnum.MetaActionEnum.MgrOper == cmd){
            return channelsModules.get(0);
        }else{
            return channelsModules.get(1);
        }
    }

    public List<Channel> getChannels(){
        return this.channelsModules;
    }
}
