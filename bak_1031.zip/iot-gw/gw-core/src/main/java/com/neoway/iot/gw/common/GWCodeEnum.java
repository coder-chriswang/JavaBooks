package com.neoway.iot.gw.common;

/**
 * @desc: DGW 统一错误码
 * @author: 20200312686
 * @date: 2020/6/23 10:43
 */
public enum GWCodeEnum {
    SUCCESS_CODE("0","Success."),
    EXCEPTION_CODE("500","Unkown Exception.");
    private String code;
    private String msg;

    GWCodeEnum(String code, String msg) {
        this.code = code;
        this.msg=msg;
    }

    public String getCode() {
        return code;
    }

    /**
     * 国际化翻译
     * @param args 参数
     * @return
     */
    public String getMsg(Object[] args) {
        //TODO 国际化翻译
        return msg;
    }
}
