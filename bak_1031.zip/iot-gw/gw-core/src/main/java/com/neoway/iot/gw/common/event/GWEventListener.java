package com.neoway.iot.gw.common.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * <pre>
 *  描述: 公共事件订阅者统一管理
 *  先留着，以备不时之需
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/08 17:20
 */
@Component
public class GWEventListener {
    private static final Logger LOG = LoggerFactory.getLogger(GWEventListener.class);
}
