package com.neoway.iot.gw.common.router;

import org.apache.commons.lang3.StringUtils;

/**
 * <pre>
 *  描述: RouterConstant
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/09/24 13:30
 */
public interface RouterConstant {

    enum UplinkTemplateId {
        ONENET("OneNet", "MQTT", "IoT_MQTT_OneNet_ProtocolDecode"),
        CTWING("CTWing", "MQTT","IoT_MQTT_CTWing_ProtocolDecode"),
        ;

        UplinkTemplateId(String accessType, String protocol,String templateId) {
            this.accessType = accessType;
            this.protocol = protocol;
            this.templateId = templateId;
        }

        private String accessType;
        private String protocol;
        private String templateId;

        public String getAccessType() {
            return accessType;
        }

        public String getTemplateId() {
            return templateId;
        }

        public String getProtocol() {
            return protocol;
        }

        public void setProtocol(String protocol) {
            this.protocol = protocol;
        }

        /**
         * 获取TemplateId
         * @param accessType accessType
         * @param protocol protocol
         * @return templateId
         */
        public static String getTemplateIdByAccessType(String accessType, String protocol) {
            if (StringUtils.isBlank(accessType) || StringUtils.isBlank(protocol)) {
                return "";
            }
            for (UplinkTemplateId t : UplinkTemplateId.values()) {
                if (accessType.equals(t.getAccessType()) && protocol.equals(t.getProtocol())) {
                    return t.getTemplateId();
                }
            }
            return "";
        }

    }
}
