package com.neoway.iot.gw.common.utils;

import cn.hutool.core.util.StrUtil;
import com.google.common.hash.Hashing;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import com.neoway.iot.gw.common.GWResponse;
import io.netty.channel.epoll.Epoll;
import org.apache.commons.codec.Charsets;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @desc: DGWUtils
 * @author: 20200312686
 * @date: 2020/7/6 9:47
 */
public class GWUtils {
    private static final Logger LOG = LoggerFactory.getLogger(GWUtils.class);

    public static String replaceBlank(String str){
        String dest="";
        if(str == null){
            return dest;
        }
        Pattern p=Pattern.compile("\\s{2,}|\t|\r|\n");
        Matcher m=p.matcher(str);
        dest=m.replaceAll("");
        return StringUtils.stripToEmpty(StringUtils.trimToEmpty(dest));
    }

    public static Gson getJsonUtil(){
        Gson gson=new GsonBuilder()
                .setDateFormat("yyyy-MM-dd HH:mm:ss")
                .setLongSerializationPolicy(LongSerializationPolicy.STRING)
                .create();
        return gson;

    }

    public static String crc16(byte[] datas,int length){
        // 检验寄存器
        int crcReg = 0xFFFF;
        int check;
        for(int i=0; i<length; i++) {
            crcReg =( (crcReg >> 8) ^ datas[i]);
            for (int j = 0; j < 8; j++) {
                check = crcReg & 0x0001;
                crcReg =  crcReg >> 1;
                if(check == 0x0001){
                    crcReg  =  crcReg^ 0xA001;
                }
            }
        }
        return StrUtil.fillBefore(Integer.toHexString(crcReg),'0',4).toUpperCase();
    }

    public static boolean useEpoll() {
        return isLinuxPlatform() && Epoll.isAvailable();
    }

    public static boolean isLinuxPlatform() {
        String osName = System.getProperty("os.name");
        return StringUtils.isNotBlank(osName) && osName.toLowerCase().contains("linux");
    }

    public static int parseIntFromBytes(byte[] data, int startIndex, int length) {
        return parseIntFromBytes(data, startIndex, length, 0);
    }

    public static int parseIntFromBytes(byte[] data, int startIndex, int length, int defaultVal) {
        try {
            // 字节数大于4,从起始索引开始向后处理4个字节,其余超出部分丢弃
            final int len = length > 4 ? 4 : length;
            byte[] tmp = new byte[len];
            System.arraycopy(data, startIndex, tmp, 0, len);
            return byteToInteger(tmp);
        } catch (Exception e) {
            return defaultVal;
        }
    }

    public static String parseBcdStringFromBytes(byte[] data, int startIndex, int length) {
        return parseBcdStringFromBytes(data, startIndex, length, null);
    }

    public static String parseBcdStringFromBytes(byte[] data, int startIndex, int length, String defaultVal) {
        try {
            byte[] tmp = new byte[length];
            System.arraycopy(data, startIndex, tmp, 0, length);
            return bcd2String(tmp);
        } catch (Exception e) {
            return defaultVal;
        }
    }

    public static String parseStringFromBytes(byte[] data, int startIndex, int length) {
        try {
            Gson gson = new Gson();
            byte[] tmp = new byte[length];
            System.arraycopy(data, startIndex, tmp, 0, length);
            return gson.toJson(tmp);
        } catch (Exception e) {
            return null;
        }
    }

    public static byte[] getDataBytes(byte[] data, int startIndex, int length) {
        try {
            byte[] tmp = new byte[length];
            System.arraycopy(data, startIndex, tmp, 0, length);
            return tmp;
        } catch (Exception e) {
            return null;
        }
    }
    public static String bcd2String(byte[] bytes) {
        StringBuilder temp = new StringBuilder(bytes.length * 2);
        for (int i = 0; i < bytes.length; i++) {
            // 高四位
            temp.append((bytes[i] & 0xf0) >>> 4);
            // 低四位
            temp.append(bytes[i] & 0x0f);
        }
        return temp.toString();
    }


    public static int byteToInteger(byte[] value) {
        int result;
        if (value.length == 1) {
            result = oneByteToInteger(value[0]);
        } else if (value.length == 2) {
            result = twoBytesToInteger(value);
        } else if (value.length == 3) {
            result = threeBytesToInteger(value);
        } else if (value.length == 4) {
            result = fourBytesToInteger(value);
        } else {
            result = fourBytesToInteger(value);
        }
        return result;
    }

    public static int oneByteToInteger(byte value) {
        return (int) value & 0xFF;
    }


    public static int twoBytesToInteger(byte[] value) {
        // if (value.length < 2) {
        // throw new Exception("Byte array too short!");
        // }
        int temp0 = value[0] & 0xFF;
        int temp1 = value[1] & 0xFF;
        return ((temp0 << 8) + temp1);
    }

    public static int threeBytesToInteger(byte[] value) {
        int temp0 = value[0] & 0xFF;
        int temp1 = value[1] & 0xFF;
        int temp2 = value[2] & 0xFF;
        return ((temp0 << 16) + (temp1 << 8) + temp2);
    }

    public static int fourBytesToInteger(byte[] value) {
        int temp0 = value[0] & 0xFF;
        int temp1 = value[1] & 0xFF;
        int temp2 = value[2] & 0xFF;
        int temp3 = value[3] & 0xFF;
        return ((temp0 << 24) + (temp1 << 16) + (temp2 << 8) + temp3);
    }

    /**
     * 整形转16进制
     * @param data
     * @param byteNum
     * @return
     */
    public static String toHexString(long data, int byteNum) {

        StringBuilder sb = new StringBuilder("");
        for (int m = 0; m < byteNum; m++) {
            sb.append("00");
        }
        int totalLen = byteNum * 2;
        String tmp = Long.toHexString(data);
        sb.replace(totalLen - tmp.length(), totalLen, tmp);
        return sb.toString();
    }
    /**
     * @desc 获取主机IP
     * @return
     */
    public static String getIPV4(){
        List<String> iplist=new ArrayList<>();
        try{
            Enumeration<NetworkInterface> networkInterfaces=NetworkInterface.getNetworkInterfaces();
            if(null != networkInterfaces){

                while(networkInterfaces.hasMoreElements()){
                    NetworkInterface networkInterface=networkInterfaces.nextElement();
                    Enumeration<InetAddress> inetAddresses=networkInterface.getInetAddresses();
                    while (inetAddresses.hasMoreElements()){
                        InetAddress inetAddress=inetAddresses.nextElement();
                        if(inetAddress != null && inetAddress instanceof Inet4Address){
                            String ip=inetAddress.getHostAddress();
                            iplist.add(ip);
                        }
                    }
                }
            }

        }catch (Exception e){
            LOG.error(e.getMessage(),e);
        }
        if(CollectionUtils.isEmpty(iplist)){
            return iplist.get(0);
        }else{
            return "127.0.0.1";
        }
    }
    public static void main(String[] args) {
//        String input="hello nihao";
//        long code=Hashing.murmur3_128().hashString(input, Charsets.UTF_8).asLong();
//        Map<String,Object> test=new HashMap<>();
//        test.put("code",-296524923920622784L);
//        System.out.println(new Gson().toJson(test));
        String data = "    { \"code\":\"200\", \"msg\":\"执行SQL成功！\", \"data\":[{\"count\":1,\"instanceId\":3}] }";
        GWResponse gwResponse = GWUtils.getJsonUtil().fromJson(data, GWResponse.class);
        System.out.println(gwResponse.getData());
    }

}
