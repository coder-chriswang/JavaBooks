package com.neoway.iot.gw.common.plugin;

import com.neoway.iot.gw.common.GWHeader;
import com.neoway.iot.gw.common.GWRequest;
import com.neoway.iot.gw.common.config.GWConfig;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 兼容OneNet MQTT场景下 协议解析插件
 *
 * OneNet平台支持connect、subscribe、publish、ping、unsubscribe、disconnect等报文
 * OneNet订阅 topic                                       订阅效果
 * $sys/{pid}/{device-name}/dp/post/json/accepted   订阅设备数据点上报成功的消息
 * $sys/{pid}/{device-name}/dp/post/json/rejected   订阅设备数据点上报失败的消息
 * $sys/{pid}/{device-name}/dp/post/json/+          订阅设备数据点上报结果
 * $sys/{pid}/{device-name}/cmd/request/+           订阅设备所有命令消息
 * $sys/{pid}/{device-name}/cmd/response/+/+        订阅设备所有命令应答结果消息
 * $sys/{pid}/{device-name}/cmd/#                   订阅设备所有命令相关消息
 * $sys/{pid}/{device-name}/#                       订阅设备所有相关消息
 *
 * $sys/{pid}/{device-name}/dp/post/json  设备上报数据点信息
 * payload :
 * {
 *     "id": 123, // 消息id
 *     "dp": {
 *         "temperatrue": [{
 *             "v": 30,
 *             "t": 1552289676
 *         }],
 *         "power": [{
 *             "v": 4.5,
 *             "t": 1552289676
 *         }],
 *         "status": [{
 *                 "v": {
 *                     "color": "blue"
 *                 },
 *                 "t": 1552289677
 *             },
 *             {
 *                 "v": {
 *                     "color": "red"
 *                 },
 *                 "t": 1552289678
 *             }
 *         ]
 *     }
 * }
 * dp 数据点中的数据结构不是定的
 *
 * pid : 设备所属产品id      确定的
 * device-name : 设备名称   确定的
 *
 * 设备名称产品内具有唯一性，采用设备sn、mac地址、IMEI等信息命名设备
 *
 * 2020/9/17 9:43
 */
public class PluginOnenetMQTT implements IPlugin {
    private static final Logger LOG = LoggerFactory.getLogger(PluginOnenetMQTT.class);
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private GWConfig config;

    /**
     * OneNet设备标识
     */
    private static final String DEVICE_ID_KEY = "clientId";
    /**
     * OneNet产品标识
     */
    private static final String PRODUCT_ID_KEY = "userName";

    @Override
    public void start(GWConfig config){
        if (isStarted.get()) {
            return;
        }
        this.config = config;
        LOG.info("PluginOnenetMQTT开始启动");
        try {

        } catch (Exception e) {
            LOG.error("PluginOnenetMQTT启动失败");
            throw new RuntimeException("PluginOnenetMQTT启动失败");
        }
        isStarted.set(true);
        LOG.info("PluginOnenetMQTT启动成功");

    }

    @Override
    public String name() {
        return "common-plugin-OnenetMQTT";
    }

    @Override
    public void execute(String plugin, GWRequest request) {
        if (request == null) {
            return;
        }
        Map<String, Object> body = request.getBody();
        if (MapUtils.isEmpty(body)) {
            LOG.error("body内容为空！");
            return;
        }
        // 通过设备标识 + 产品标识唯一确定
        String deviceId = (String) body.get(DEVICE_ID_KEY);
        String pId = (String) body.get(PRODUCT_ID_KEY);
        LOG.info("OneNet-MQTT数据上报执行解析！deviceId={}, productId={}", deviceId, pId);
        GWHeader header = request.getHeader();
        if (header == null) {
            LOG.info("GWHeader为空！");
            return;
        }
        // 设置设备唯一标识
        header.setInstanceid(deviceId);

    }
}
