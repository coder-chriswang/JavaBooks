package com.neoway.iot.gw.common.config;

import com.google.gson.Gson;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.common.notify.NotifyClient;
import com.neoway.iot.sdk.dmk.data.DMCache;
import com.neoway.iot.sdk.mok.MOKRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: DGW运行配置参数
 * @author: 20200312686
 * @date: 2020/6/23 10:08
 */
public class GWConfig {
    private static final Logger LOG = LoggerFactory.getLogger(GWConfig.class);
    public static final String JDBC_HOST="jdbc.host";
    public static final String JDBC_PORT="jdbc.port";
    public static final String JDBC_DB="jdbc.db";
    public static final String JDBC_MAX_CONN="jdbc.max_conn";
    public static final String JDBC_USER="jdbc.user";
    public static final String JDBC_PWD="jdbc.pwd";
    public static final String JDBC_CONN_TIMEOUT="jdbc.conn_timeout";
    public static final String JDBC_IDEL_TIMEOUT="jdbc.idel_timeout";
    public static final String JDBC_MIN_CONN="jdbc.min_conn";
    public static final String CACHE_KEY="data.cache";
    public static final String CACHE_MAX="data.max";
    public static final String CACHE_INIT="data.init";
    private static GWConfig env=null;
    private Map<String,Object> pro;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private GWConfig(){
    }
    public static GWConfig getInstance(){
        if(env == null){
            env=new GWConfig();
        }
        return env;
    }
    public void start(String etc) throws Exception{
        Yaml dgwYml=new Yaml();
        File f=new File(etc);
        Map<String,Object> result=dgwYml.load(new FileInputStream(f));
        this.pro=result;
        this.startRunner();
        LOG.debug("DGW配置加载：{}", new Gson().toJson(this.pro));
    }
    private void startRunner() {
        if (isStarted.get()) {
            return;
        }
        DMRunner runner = DMRunner.getInstance();
        Map<String,Object> pro=new HashMap<>();
        pro.put(DMPool.JDBC_HOST,this.getValue(JDBC_HOST));
        pro.put(DMPool.JDBC_PORT,this.getValue(JDBC_PORT));
        pro.put(DMPool.JDBC_DB,this.getValue(JDBC_DB));
        pro.put(DMPool.JDBC_MAX_CONN,this.getValue(JDBC_MAX_CONN));
        pro.put(DMPool.JDBC_MIN_CONN,this.getValue(JDBC_MIN_CONN));
        pro.put(DMPool.JDBC_USER,this.getValue(JDBC_USER));
        pro.put(DMPool.JDBC_PWD,this.getValue(JDBC_PWD));
        pro.put(DMPool.JDBC_CONN_TIMEOUT,this.getValue(JDBC_CONN_TIMEOUT));
        pro.put(DMPool.JDBC_IDEL_TIMEOUT,this.getValue(JDBC_IDEL_TIMEOUT));
        pro.put(DMCache.CACHE_KEY,this.getValue(CACHE_KEY));
        pro.put(DMCache.CACHE_MAX,this.getValue(CACHE_MAX));
        pro.put(DMCache.CACHE_INIT,this.getValue(CACHE_INIT));
        pro.put(NotifyClient.CONFIGURATION_DB,this.getValue(NotifyClient.CONFIGURATION_DB));
        pro.put(NotifyClient.CONFIGURATION_HOST,this.getValue(NotifyClient.CONFIGURATION_HOST));
        pro.put(NotifyClient.CONFIGURATION_MAX_ACTIVE,this.getValue(NotifyClient.CONFIGURATION_MAX_ACTIVE));
        pro.put(NotifyClient.CONFIGURATION_MAX_IDEL,this.getValue(NotifyClient.CONFIGURATION_MAX_IDEL));
        pro.put(NotifyClient.CONFIGURATION_MAX_WAIT,this.getValue(NotifyClient.CONFIGURATION_MAX_WAIT));
        pro.put(NotifyClient.CONFIGURATION_MIN_IDEL,this.getValue(NotifyClient.CONFIGURATION_MIN_IDEL));
        pro.put(NotifyClient.CONFIGURATION_PORT,this.getValue(NotifyClient.CONFIGURATION_PORT));
        pro.put(NotifyClient.CONFIGURATION_PWD,this.getValue(NotifyClient.CONFIGURATION_PWD));
        pro.put(NotifyClient.CONFIGURATION_TIMEOUT,this.getValue(NotifyClient.CONFIGURATION_TIMEOUT));
        runner.start(pro);
        isStarted.set(true);
    }

    public void stop(){
        this.pro.clear();
    }

    public Object getValue(String key){
        String[] values = key.split("\\.");
        Map m = pro;
        for (int i = 0; i < values.length - 1; i++) {
            if (m.containsKey(values[i])) {
                m = (Map) m.get(values[i]);
            } else {
                return null;
            }
        }
        return m.get(values[values.length - 1]);
    }

    public Map<String, Object> getPro() {
        return pro;
    }
}
