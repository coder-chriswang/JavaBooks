package com.neoway.iot.gw.api;

import com.neoway.iot.gw.common.GWRequest;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.input.scheduler.ExecutorDownlink;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @desc: 指令执行接口
 * @author: 20200312686
 * @date: 2020/6/23 9:27
 */
@RestController
@RequestMapping("/v1/command")
@Api(tags = "指令执行")
public class ExecutorController {

    @ApiOperation("指令执行-同步")
    @PostMapping("/syn")
    public GWResponse command(@RequestBody GWRequest req) {
        return ExecutorDownlink.downlink(req);
    }
    @ApiOperation("指令执行-异步")
    @PostMapping("/asyn")
    public GWResponse asynCommand(@RequestBody GWRequest req) {
        return ExecutorDownlink.downlinkSyn(req);
    }
}
