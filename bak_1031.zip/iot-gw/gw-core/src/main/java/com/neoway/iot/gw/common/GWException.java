package com.neoway.iot.gw.common;

/**
 * @desc: DGWException
 * @author: 20200312686
 * @date: 2020/6/23 10:42
 */
public class GWException extends Exception {
    private String code;
    public GWException(Throwable cause) {
        super(cause);
    }
    public GWException(String code, String msg) {
        super(msg);
        this.code=code;
    }

    public String getCode() {
        return code;
    }
}
