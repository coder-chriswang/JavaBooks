package com.neoway.iot.gw.common.router;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.common.redis.JedisUtil;
import com.neoway.iot.gw.input.template.TemplateManager;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.ActionMapping;
import com.neoway.iot.sdk.gwk.entity.DeviceInstance;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * @desc: 上行-模板定位路由表
 * @author: Chris(wangchao)
 * @date: 2020/9/14 19:28
 */
public class UplinkRouterTemplateRedis implements CacheRouter<RouteUplinkTemplate> {
    private static final Logger LOG = LoggerFactory.getLogger(UplinkRouterTemplateRedis.class);
    private static final String CACHE_SPLIT="@##@";
    private static final String PATTER = "*" + CACHE_SPLIT + "*";
    private DMRunner runner;
    private JedisPool pool;
    private static final String CONFIGURATION_DB="router.template.redis.db";
    private static final String CONFIGURATION_HOST="router.template.redis.host";
    private static final String CONFIGURATION_PORT="router.template.redis.port";
    private static final String CONFIGURATION_PWD="router.template.password";
    private static final String CONFIGURATION_TIMEOUT="router.template.redis.timeout";
    private static final String CONFIGURATION_MAX_ACTIVE="router.template.redis.max_active";
    private static final String CONFIGURATION_MAX_WAIT="router.template.redis.max_wait";
    private static final String CONFIGURATION_MAX_IDEL="router.template.redis.max_idel";
    private static final String CONFIGURATION_MIN_IDEL="router.template.redis.min_idel";

    @Override
    public void start(GWConfig config) {
        this.runner = DMRunner.getInstance();
        JedisUtil.Builder builder=JedisUtil.builder();
        builder = builder.buildPool(String.valueOf(config.getValue(CONFIGURATION_MAX_ACTIVE)),
                String.valueOf(config.getValue(CONFIGURATION_MAX_WAIT)),
                String.valueOf(config.getValue(CONFIGURATION_MAX_IDEL)),
                String.valueOf(config.getValue(CONFIGURATION_MIN_IDEL)));
        builder = builder.buildURI((String)config.getValue(CONFIGURATION_HOST),
                String.valueOf(config.getValue(CONFIGURATION_PORT)),
                String.valueOf(config.getValue(CONFIGURATION_TIMEOUT)),
                String.valueOf(config.getValue(CONFIGURATION_PWD)),
                String.valueOf(config.getValue(CONFIGURATION_DB)));
        JedisUtil utils = new JedisUtil();
        utils.start(builder);
        this.pool=utils.getJedisPool();
        // 加载router缓存
        this.load();
    }
    /**
     * @desc 生成缓存KEY
     * @param nativeid 设备唯一标识
     * @param cmdId 原始服务标识
     * @return
     */
    private String buildCacheKey(String nativeid, String cmdId) {
        StringBuilder sb = new StringBuilder();
        sb.append(nativeid).append(CACHE_SPLIT).append(cmdId);
        return sb.toString();
    }

    @Override
    public void load() {
        try {
            DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceInstance.class);
            DMDataPoint condition=DMDataPoint.builder(metaCI.getNs(), metaCI.getCategory(),metaCI.getCi());
            // 查询出deviceInstance所有实例
            List<DMDataPoint> points = runner.list(condition);
            if (CollectionUtils.isEmpty(points)) {
                return;
            }
            List<RouteUplinkTemplate> routeUplinkTemplates = new ArrayList<>();
            DMMetaCI actionMappingMetaCI=DMMetaCI.getMetaCI(ActionMapping.class);
            for (DMDataPoint point : points) {
                DeviceInstance metaDeviceInstance = DeviceInstance.buildDeviceInstance(point);
                if (metaDeviceInstance == null) {
                    continue;
                }
                condition=DMDataPoint.builder(
                        actionMappingMetaCI.getNs(),
                        actionMappingMetaCI.getCategory(),
                        actionMappingMetaCI.getCi());
                DMDataColumn column=new DMDataColumn("ds_code", metaDeviceInstance.getDeviceDSId());
                condition.addColumn(column);
                List<DMDataPoint> actionPoints=runner.list(condition);
                List<ActionMapping> actionMappingList=new ArrayList<>();
                for(DMDataPoint actionPoint:actionPoints){
                    ActionMapping actionMapping=ActionMapping.buildActionMapping(actionPoint);
                    actionMappingList.add(actionMapping);
                }
                if (CollectionUtils.isEmpty(actionMappingList)) {
                    continue;
                }
                for (ActionMapping actionMapping : actionMappingList) {
                    RouteUplinkTemplate routeUplinkTemplate = new RouteUplinkTemplate();
                    routeUplinkTemplate.setDeviceDsCode(metaDeviceInstance.getDeviceDSId());
                    routeUplinkTemplate.setMetaActionId(actionMapping.getMeta_action_id());
                    routeUplinkTemplate.setNativeActionId(actionMapping.getAction_id());
                    routeUplinkTemplate.setNativeId(metaDeviceInstance.getNativeid());
                    routeUplinkTemplate.setInstanceid(metaDeviceInstance.getInstanceid());
                    routeUplinkTemplate.setTemplateId(actionMapping.getTemplate_id());
                    routeUplinkTemplates.add(routeUplinkTemplate);
                }
                if (CollectionUtils.isEmpty(routeUplinkTemplates)) {
                    LOG.warn("未查询到有效RouteUplinkTemplate");
                    return;
                }
                routeUplinkTemplates.stream().distinct().collect(Collectors.toList());
                Gson gson = new Gson();
                try(Jedis jedis = this.pool.getResource()) {
                    // 进缓存
                    routeUplinkTemplates.forEach(r -> {
                        TemplateManager manager = TemplateManager.getInstance();
                        MetaTemplate tpl = manager.getTemplate(r.getTemplateId());
                        if (tpl != null) {
                            jedis.set(buildCacheKey(r.getNativeId(), r.getNativeActionId()), gson.toJson(r));
                        }
                    });
                } catch (Exception e) {
                    LOG.error("RouteUplinkTemplate写入Redis缓存失败", e);
                }
            }
        } catch (Exception e) {
            LOG.error("加载缓存失败！", e);
        }

    }

    @Override
    public void clear() {
        try (Jedis jedis = this.pool.getResource()) {
            // 清除缓存
            Set<String> keys = jedis.keys(PATTER);
            keys.forEach(jedis::del);
        } catch (Exception e) {
            LOG.error("RouteUplinkTemplate删除Redis缓存失败", e);
        }
    }

    @Override
    public RouteUplinkTemplate get(String k) {
        RouteUplinkTemplate routeUplinkTemplate = null;
        Gson gson = new Gson();
        try (Jedis jedis = this.pool.getResource()) {
            String result = jedis.get(k);
            routeUplinkTemplate = gson.fromJson(result, new TypeToken<RouteUplinkTemplate>() {}.getType());
        } catch (Exception e) {
            LOG.error("获取RouteUplinkTemplate失败", e);
        }
        return routeUplinkTemplate;
    }
}
