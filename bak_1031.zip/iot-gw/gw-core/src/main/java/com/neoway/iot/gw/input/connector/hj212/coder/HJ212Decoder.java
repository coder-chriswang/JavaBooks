package com.neoway.iot.gw.input.connector.hj212.coder;

import cn.hutool.core.util.StrUtil;
import com.neoway.iot.gw.common.utils.GWUtils;
import com.neoway.iot.gw.input.connector.hj212.model.HJ212Request;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageDecoder;

import java.util.List;

/**
 * <pre>
 *  描述: HJ212Decoder
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/09/10 13:35
 */
@ChannelHandler.Sharable
public class HJ212Decoder extends MessageToMessageDecoder<String> {
    /**
     *  数据长度位 下标开始-下标结束
     */
    private final Integer[] ITEM_LENGTH_INDEX = {2,6};

    /**
     * 长度位 长度
     */
    private final Integer ITEM_LENGTH_LENGTH = 4;
    /**
     * 校验位 长度
     */
    private final Integer ITEM_CRC_LENGTH = 4;
    /**
     * 消息头
     */
    private final String HEAD = "##";
    /**
     * 头部 长度
     */
    private final Integer ITEM_HEAD_LENGTH = HEAD.length();

    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext, String s, List<Object> list) throws Exception {
        HJ212Request hj212Request = new HJ212Request();
        // 校验长度
        int contentLength = validLength(s, hj212Request);
        // 头部校验
        validHeader(s, hj212Request);
        // 校验位检验
        validCRC(contentLength, s, hj212Request);
        list.add(hj212Request);
    }

    private int validLength(String data, HJ212Request hj212Request){
        // 原始数据长度
        int dataLength = data.length();
        // 解析到的 内容体长度
        String cutContentLength = data.substring(ITEM_LENGTH_INDEX[0],ITEM_LENGTH_INDEX[1]);
        int contentLength = Integer.parseInt(cutContentLength);
        // 数据长度 = 头（2）+ 长度(4) + 数据(N) + crc(4)
        if((dataLength-ITEM_HEAD_LENGTH-ITEM_LENGTH_LENGTH-ITEM_CRC_LENGTH) != contentLength){
            throw new RuntimeException("数据异常，数据长度验证存在问题");
        }
        hj212Request.setLength(cutContentLength);
        return contentLength;
    }

    private void validHeader(String data, HJ212Request hj212Request){
        if(!data.startsWith(HEAD)){
            throw new RuntimeException("数据异常，缺少头部##");
        }
        hj212Request.setHeader(HEAD);
    }

    private String validCRC(int contentLength ,String data, HJ212Request hj212Request){
        String content = StrUtil.sub(data,ITEM_HEAD_LENGTH+ITEM_LENGTH_LENGTH,ITEM_HEAD_LENGTH+ITEM_LENGTH_LENGTH+contentLength);
        // 计算校验位
        String calcCRC = GWUtils.crc16(content.getBytes(),content.length());
        String cutCRC = StrUtil.sub(data,ITEM_HEAD_LENGTH+ITEM_LENGTH_LENGTH+contentLength,ITEM_HEAD_LENGTH+ITEM_LENGTH_LENGTH+contentLength+ITEM_CRC_LENGTH);
        if(!cutCRC.equals(calcCRC)){
            throw new RuntimeException("数据异常，校验码错误");
        }
        hj212Request.setCrc(cutCRC);
        hj212Request.setContents(content);
        return content;
    }
}
