package com.neoway.iot.gw.common.utils;

import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * <pre>
 *  描述: 时间戳工具
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/9/10 17:47
 */
public class TimeUtils {


    public static long getCurrentTime() {
        return LocalDateTime.now().atZone(ZoneId.systemDefault()).toEpochSecond();
    }

    public static int getCurrentTimeInSecond() {
        return (int) (LocalDateTime.now().atZone(ZoneId.systemDefault()).toEpochSecond());
    }
}
