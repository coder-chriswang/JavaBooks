package com.neoway.iot.gw.api;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.gw.channel.direct.DirectChannel;
import com.neoway.iot.gw.common.*;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.common.utils.GWUtils;
import com.neoway.iot.gw.input.scheduler.ExecutorDownlink;
import com.neoway.iot.gw.input.scheduler.ExecutorUplink;
import com.neoway.iot.gw.output.pm.handler.PmCmdHandlerRuleCompute;
import com.neoway.iot.sdk.mok.entity.FmValue;
import com.neoway.iot.sdk.mok.entity.PmValue;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/test")
@Api(tags = "测试")
public class TestController {

    @Autowired
    private Environment env;

    @PostMapping("/pm")
    public GWResponse pmHandle() throws Exception{

        GWResponse response = new GWResponse();

        PmCmdHandlerRuleCompute compute = PmCmdHandlerRuleCompute.getInstance(GWConfig.getInstance());
        long instanceId = Long.parseLong("-9216364826891327137");
        long metric = Long.parseLong("6028777113453219256");
//        compute.queryPoints(1603533130, 1603533470, instanceId, metric);

        // 测试指标数据订阅
        PmValue pmValue = new PmValue();
        pmValue.setInstanceid(123456789);
        pmValue.setMetric(123456);
        pmValue.setValue(200);
        pmValue.setTs(1603854931);
        pmValue.setTags("");
        compute.publishPoint(pmValue);

//        String templdateId = "IES_MO_FmValue_UplinkData";
//        GWHeader gwHeader = new GWHeader(templdateId);
//        gwHeader.setNs("ies");
//        gwHeader.setCategory("mo");
//        gwHeader.setCi("Fm_Value");
//        gwHeader.setAction("Query");
//        gwHeader.setTemplateid(templdateId);
//
//        GWRequest request = new GWRequest(gwHeader);
//        FmValue fmValue = new FmValue();
//
//        fmValue.setSerialNo(666666666);
//        fmValue.setAlarmId("temperature");
//        fmValue.setNs("ies");
//        fmValue.setType("MicroWeather");
//        fmValue.setInstanceId(123456789);
//        fmValue.setInstanceName("设备");
//        fmValue.setAlarmName("设备故障");
//        fmValue.setAlarmSeverity(0);
//        fmValue.setAlarmCategory("设备指标告警");
//        fmValue.setAlarmCauseText("指标超过上限");
//        fmValue.setAlarmRepireText("更换设备");
//        fmValue.setAlarmEffectBusiness("影响业务数据");
//        fmValue.setAlarmEffectDevice("Device123");
//        fmValue.setAlarmSt(1603445700);
//        fmValue.setAlarmEt(1603445725);
//        fmValue.setAlarmCt(0);
//        fmValue.setAlarmStatus(0);
//        fmValue.setAlarmCount(1);
//        fmValue.setAlarmCType("Auto");
//        fmValue.setTenantId("1001");
//        fmValue.setNativeId("123456789");
//
//        Gson gson=GWUtils.getJsonUtil();
//        String json=gson.toJson(fmValue);
//        Map<String,Object> body=gson.fromJson(json,new TypeToken<Map<String,Object>>(){}.getType());
//        request.setBody(body);
//
//        response = ExecutorUplink.uplink(request);
        return response;
    }
}
