package com.neoway.iot.gw.common;

import com.google.gson.Gson;
import com.neoway.iot.gw.common.utils.GWUtils;
import org.apache.commons.collections4.MapUtils;

import java.util.*;

/**
 * @desc: GWEvent
 * @author: 20200312686
 * @date: 2020/9/14 16:58
 */
public class GWEvent {
    private static final int DEFAULT_OUTPUT_INTERVAL = 30;
    public static final String CONTEXT_BODY="data";
    private GWEventHeader header;
    private Map<String,Object> data;
    public GWEvent(){
    }
    public GWEvent(GWRequest request,GWResponse response) {
        GWHeader gwHeader=request.getHeader();
        this.header=new GWEventHeader(request);
        this.header.build(gwHeader.getReqId(),gwHeader.getTs());
        this.data=new HashMap<>();
        if (response != null){
            data.put(CONTEXT_BODY,response.getData());
        }
    }

    public GWEvent(GWEventHeader header,Map<String,Object> data){
        this.header=header;
        this.data=data;
    }
    public GWEventHeader getHeader() {
        return header;
    }

    public void setHeader(GWEventHeader header) {
        this.header = header;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    @Override
    public GWEvent clone() {
        Gson gson= GWUtils.getJsonUtil();
        GWEvent context = gson.fromJson(gson.toJson(this),GWEvent.class);
        return context;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        GWEvent context = (GWEvent) o;
        return Objects.equals(header, context.header);
    }

    @Override
    public int hashCode() {
        return Objects.hash(header);
    }

    /**
     * @desc 解码数据
     * @return
     */
    public List<Map<String,Object>> decodeData(){
        List<Map<String,Object>> values=new ArrayList<>();
        if(MapUtils.isEmpty(this.data)){
            return values;
        }
        Object value=this.data.get(CONTEXT_BODY);
        if(List.class.isInstance(value)){
            List<Map<String,Object>> vv=(List)value;
            for(Map<String,Object> singleD:vv){
                values.add(singleD);
            }
        } else {
            Map<String,Object> vMap=(Map<String, Object>)value;
            values.add(vMap);
        }
        return values;
    }
}
