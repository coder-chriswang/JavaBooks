package com.neoway.iot.gw.common.router;

import com.google.gson.Gson;

import java.util.Objects;

/**
 * @desc: 上行模板定位路由表
 * @author: 20200312686
 * @date: 2020/9/15 9:16
 */
public class RouteUplinkTemplate {

    /**
     * 设备唯一标识
     */
    private long instanceid;
    /**
     * 设备原始标识
     */
    private String nativeId;
    /**
     * 设备数据源编码
     */
    private long deviceDsCode;
    /**
     * 原始服务标识
     */
    private String nativeActionId;
    /**
     * 标准服务标识
     */
    private String metaActionId;
    /**
     * 模板ID
     */
    private String templateId;

    public String getNativeId() {
        return nativeId;
    }

    public void setNativeId(String nativeId) {
        this.nativeId = nativeId;
    }

    public long getDeviceDsCode() {
        return deviceDsCode;
    }

    public void setDeviceDsCode(long deviceDsCode) {
        this.deviceDsCode = deviceDsCode;
    }

    public String getNativeActionId() {
        return nativeActionId;
    }

    public void setNativeActionId(String nativeActionId) {
        this.nativeActionId = nativeActionId;
    }

    public String getMetaActionId() {
        return metaActionId;
    }

    public void setMetaActionId(String metaActionId) {
        this.metaActionId = metaActionId;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public long getInstanceid() {
        return instanceid;
    }

    public void setInstanceid(long instanceid) {
        this.instanceid = instanceid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RouteUplinkTemplate that = (RouteUplinkTemplate) o;
        return Objects.equals(nativeId, that.nativeId) &&
                Objects.equals(deviceDsCode, that.deviceDsCode) &&
                Objects.equals(nativeActionId, that.nativeActionId) &&
                Objects.equals(metaActionId, that.metaActionId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nativeId, deviceDsCode, nativeActionId, metaActionId, templateId);
    }

    @Override
    public RouteUplinkTemplate clone() {
        Gson gson=new Gson();
        RouteUplinkTemplate object = new Gson().fromJson(gson.toJson(this), RouteUplinkTemplate.class);
        return object;
    }
}
