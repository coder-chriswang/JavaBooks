package com.neoway.iot.gw.input.connector.dmk;

import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.input.connector.Connector;
import com.neoway.iot.gw.input.connector.ConnectorReq;
import com.neoway.iot.gw.input.connector.ConnectorRsp;
import com.neoway.iot.sdk.dmk.DMRunner;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * <pre>
 *  描述: DMKJDBCConnector——处理感知平台报表SQL执行
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/09/18 11:45
 */
public class DMKConnector extends Connector {
    private static final Logger LOG = LoggerFactory.getLogger(DMKConnector.class);
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private GWConfig env;

    @Override
    public void start(GWConfig env) throws GWException {
        if (isStarted.get()) {
            return;
        }
        this.env = env;
        LOG.info("DMKConnector开始启动");
        isStarted.set(true);
        LOG.info("DMKConnector启动成功");
    }

    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        if (request == null) {
            LOG.error("参数为空！");
            return null;
        }
        if (StringUtils.isBlank(request.getRequest())) {
            LOG.error("执行SQL为空！");
            return null;
        }
        ConnectorRsp connectorRsp;
        DMRunner runner = DMRunner.getInstance();
        try {
            List<Map<String, Object>> result = runner.executeSQL(request.getRequest());
            //模板遍历嵌套CaseInsensitiveHashMap对象会报ConcurrentModificationException,临时办法先转成hashmap
            List<Map<String, Object>> resultMap = new ArrayList<>();
            result.forEach(map -> {
                Map<String, Object> map1 = new HashMap<>();
                map1.putAll(map);
                resultMap.add(map1);
            });
            connectorRsp = new ConnectorRsp();
            Map<String, Object> body = new HashMap<>(1);
            body.put("result", resultMap);
            connectorRsp.setHeader(request.getHeader());
            connectorRsp.setBody(body);
        } catch (Exception e) {
            LOG.error("执行SQL失败！", e);
            connectorRsp = new ConnectorRsp();
            Map<String, Object> header = new HashMap<>(2);
            header.put("code", 500);
            header.put("message","执行SQL失败！");
            connectorRsp.setHeader(header);
            connectorRsp.setBody(null);
        }
        return connectorRsp;
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public String name() {
        return "input-connector-dmk";
    }
}
