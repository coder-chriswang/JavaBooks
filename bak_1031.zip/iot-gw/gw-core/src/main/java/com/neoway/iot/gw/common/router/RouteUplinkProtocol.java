package com.neoway.iot.gw.common.router;

import com.google.gson.Gson;

import java.util.Objects;

/**
 * @desc: 上行-协议解析路由表
 * @author: 20200312686
 * @date: 2020/9/15 9:13
 */
public class RouteUplinkProtocol {
    /**
     * 原始服务标识
     */
    private String topic;
    /**
     * 协议
     */
    private String protocol;
    /**
     * 接入方式
     */
    private String accessType;
    /**
     * 协议解析模板
     */
    private String templateId;

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getAccessType() {
        return accessType;
    }

    public void setAccessType(String accessType) {
        this.accessType = accessType;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RouteUplinkProtocol that = (RouteUplinkProtocol) o;
        return Objects.equals(accessType, that.accessType) &&
                Objects.equals(topic, that.topic);
    }

    @Override
    public int hashCode() {
        return Objects.hash(topic, protocol, accessType, templateId);
    }

    @Override
    public RouteUplinkProtocol clone() {
        Gson gson=new Gson();
        RouteUplinkProtocol object = new Gson().fromJson(gson.toJson(this), RouteUplinkProtocol.class);
        return object;
    }
}
