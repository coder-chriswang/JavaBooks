package com.neoway.iot.gw;

import com.neoway.iot.gw.common.GWCodeEnum;
import com.neoway.iot.gw.common.GWHeader;
import com.neoway.iot.gw.common.GWRequest;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.input.scheduler.ExecutorDownlink;
import com.neoway.iot.gw.input.template.TemplateManager;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @desc: springboot事件监听器。用于监听启动、销毁等事件来完成业务初始化
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
@Component
public class GWListener implements ApplicationListener {
    private static final Logger LOG = LoggerFactory.getLogger(GWListener.class);
    private static final String INIT_SCHEDULER_NAME="input-template-init";
    private static final String CYCLE_SCHEDULER_NAME="input-template-scheudler";
    private static final int DEFAULT_INTERVAL=60;
    private static final int DEFAULT_INTERVAL_SCHEDULER=1;
    private List<GWLifecycleComponent> comps=new ArrayList<GWLifecycleComponent>();
    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        if(event instanceof ApplicationReadyEvent){
            LOG.info("GW开始业务初始化",event.toString());
            this.initExecuteTemplate();
//            this.initRunner(DEFAULT_INTERVAL);
//            this.initSchedulerRunner(DEFAULT_INTERVAL_SCHEDULER);
            LOG.info("GW业务初始化成功",event.toString());
        }
    }

    /**
     * @desc 静默自动化执行模板
     */
    private void initExecuteTemplate(){
        //2:静默执行模板自动执行
        TemplateManager manager= TemplateManager.getInstance();
        List<MetaTemplate> tpls=manager.getInitTemplateQueue();
        for(MetaTemplate template:tpls){
            GWHeader header=new GWHeader(template.getTemplateid());
            GWRequest request=new GWRequest(header);
            GWResponse rsp= ExecutorDownlink.downlinkSyn(request);
            if(rsp.getCode().equals(GWCodeEnum.SUCCESS_CODE.getCode())){
                manager.commit(template);
            }else{
                LOG.error("模板静默自动化执行失败,一分钟后重试,错误码={},错误原因={},产品={}，模板ID={}",
                        rsp.getCode(),rsp.getMsg(),header.getTemplateid());
            }
        }
    }

    /**
     * @desc 定时执行初始化
     * @param interval
     * @return 定时器服务
     */
    public ScheduledExecutorService initRunner(int interval){
        ScheduledExecutorService initRunner = Executors.newSingleThreadScheduledExecutor(
                (r) -> {
                    Thread t = new Thread(r, INIT_SCHEDULER_NAME);
                    t.setDaemon(true);
                    return t;
                }
        );
        initRunner.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try{
                    initExecuteTemplate();
                }catch (Exception e){
                    LOG.error(e.getMessage(),e);
                }

            }
        }, 0, interval, TimeUnit.SECONDS);
        return initRunner;
    }

    /**
     * @desc 定时执行初始化
     * @param interval
     * @return 定时器服务
     */
    public ScheduledExecutorService initSchedulerRunner(int interval){
        ScheduledExecutorService initRunner = Executors.newSingleThreadScheduledExecutor(
                (r) -> {
                    Thread t = new Thread(r, CYCLE_SCHEDULER_NAME);
                    t.setDaemon(true);
                    return t;
                }
        );
        initRunner.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try{
                    TemplateManager manager= TemplateManager.getInstance();
                    List<MetaTemplate> schedulerTemplates=manager.getCycleTemplate();
                    LOG.info("模板周期自动化执行={}",schedulerTemplates.size());
                    if(CollectionUtils.isEmpty(schedulerTemplates)){
                        return;
                    }
                    for(MetaTemplate template:schedulerTemplates){
                        GWHeader header=new GWHeader(template.getTemplateid());
                        GWRequest request=new GWRequest(header);
                        GWResponse rsp= ExecutorDownlink.downlinkSyn(request);
                        if(!rsp.getCode().equals(GWCodeEnum.SUCCESS_CODE.getCode())){
                            LOG.error("模板周期自动化执行失败,错误码={},错误原因={},产品={}，模板ID={}",
                                    rsp.getCode(),rsp.getMsg(),header.getTemplateid());
                        }
                    }
                }catch (Exception e){
                    LOG.error(e.getMessage(),e);
                }

            }
        }, 1, interval, TimeUnit.MINUTES);
        return initRunner;
    }
}
