package com.neoway.iot.gw.input.connector.hj212;

import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.common.utils.GWUtils;
import com.neoway.iot.gw.input.connector.Connector;
import com.neoway.iot.gw.input.connector.hj212.coder.HJ212Decoder;
import com.neoway.iot.gw.input.connector.hj212.coder.HJ212Encoder;
import com.neoway.iot.gw.input.connector.hj212.handler.HJ212MessageHandler;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.*;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollServerSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.LineBasedFrameDecoder;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.handler.timeout.IdleStateHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * <pre>
 *  描述: HJ212BootstrapServer
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/09/09 15:53
 */
public class HJ212BootstrapServer {
    private static final Logger LOG = LoggerFactory.getLogger(HJ212BootstrapServer.class);
    private EventLoopGroup bossGroup;

    private EventLoopGroup workGroup;
    // 启动辅助类
    ServerBootstrap bootstrap = null ;
    private static final String HJ212_PORT="input.tcp.hj212.port";
    private static final String HJ212_KEEPALIVE="input.tcp.hj212.keepalive";
    private static final String HJ212_REUSEADDR="input.tcp.hj212.reuseaddr";
    private static final String HJ212_TCPNODELAYE="input.tcp.hj212.tcpNodelay";
    private static final String HJ212_SNDBUF="input.tcp.hj212.sndbuf";
    private static final String HJ212_REVBUF="input.tcp.hj212.revbuf";
    private static final String HJ212_HEART="input.tcp.hj212.heart";
    private static final String HJ212_BACKLOG="input.tcp.hj212.backlog";
    private static final int HJ212_DATA_SIZE = 1036;

    private int port;
    private boolean keepAlive;
    private boolean reuseAddr;
    private boolean tcpNodelay;
    private int sndBuf;
    private int revBuf;
    private int heart;
    private int backlog;
    private int bossThread;
    private int workThread;

    public HJ212BootstrapServer(GWConfig env) {
        this.setPort((Integer) env.getValue(HJ212_PORT));
        this.setKeepAlive(Boolean.valueOf(String.valueOf(env.getValue(HJ212_KEEPALIVE))));
        this.setReuseAddr(Boolean.valueOf(String.valueOf(env.getValue(HJ212_REUSEADDR))));
        this.setTcpNodelay(Boolean.valueOf(String.valueOf(env.getValue(HJ212_TCPNODELAYE))));
        this.setSndBuf((Integer) env.getValue(HJ212_SNDBUF));
        this.setRevBuf((Integer) env.getValue(HJ212_REVBUF));
        this.setHeart((Integer) env.getValue(HJ212_HEART));
        this.setBacklog((Integer) env.getValue(HJ212_BACKLOG));
        this.setBossThread(Runtime.getRuntime().availableProcessors());
        this.setWorkThread(2 * Runtime.getRuntime().availableProcessors());
    }

    public void start(Connector connector) {
        initEventPool();
        int heartBeat = this.getHeart();
        boolean keepAlive = this.isKeepAlive();
        bootstrap.group(bossGroup, workGroup)
                .channel(GWUtils.useEpoll() ? EpollServerSocketChannel.class: NioServerSocketChannel.class)
                // 地址复用
                .option(ChannelOption.SO_REUSEADDR, this.isReuseAddr())
                // Socket参数，服务端接受连接的队列长度，如果队列已满，客户端连接将被拒绝。
                .option(ChannelOption.SO_BACKLOG, this.getBacklog())

                .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                .option(ChannelOption.SO_RCVBUF, this.getRevBuf())
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline channelPipeline = ch.pipeline();
                        channelPipeline.addLast("lineDecoder",new LineBasedFrameDecoder(HJ212_DATA_SIZE))
                                .addLast("stringDecoder",new StringDecoder())
                                .addLast("bisDecoder",new HJ212Decoder())
                                .addFirst("bisEncoder",new HJ212Encoder())
                                .addFirst("stringEncoder",new StringEncoder())
                                .addLast(new IdleStateHandler(heartBeat,0,0))
                                .addLast(new HJ212MessageHandler(connector));
                    }
                })
                // 立即发送
                .childOption(ChannelOption.TCP_NODELAY, this.isTcpNodelay())
                // Socket参数，连接保活，默认值为False。
                // 启用该功能时，TCP会主动探测空闲连接的有效性。
                // 可以将此功能视为TCP的心跳机制
                // 需要注意的是：默认的心跳间隔是7200s即2小时。Netty默认关闭该功能
                .childOption(ChannelOption.SO_KEEPALIVE, keepAlive)
                .childOption(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);

        bootstrap.bind(this.getPort()).addListener((ChannelFutureListener) channelFuture -> {
            if (channelFuture.isSuccess()){
                LOG.info("HJ212接入服务端启动成功!端口为={}", this.getPort());
            } else{
                LOG.error("HJ212接入服务端启动失败!");
            }
        });
    }

    public void shutdown() {
        if (workGroup != null && bossGroup != null){
            try {
                LOG.info("HJ212接入服务端关闭！");
                bossGroup.shutdownGracefully().sync();
                workGroup.shutdownGracefully().sync();
            } catch (InterruptedException e) {
                LOG.error("HJ212接入服务端关闭资源失败！");
            }
        }
    }

    /**
     * 初始化EnentPool 参数
     */
    private void  initEventPool(){
        bootstrap= new ServerBootstrap();
        if (GWUtils.useEpoll()) {
            bossGroup = new EpollEventLoopGroup(this.getBossThread(), new ThreadFactory() {
                private AtomicInteger index = new AtomicInteger(0);
                @Override
                public Thread newThread(Runnable r) {
                    return new Thread(r, "LINUX_BOSS_" + index.incrementAndGet());
                }
            });
            workGroup = new EpollEventLoopGroup(this.getWorkThread(), new ThreadFactory() {
                private AtomicInteger index = new AtomicInteger(0);
                @Override
                public Thread newThread(Runnable r) {
                    return new Thread(r, "LINUX_WORK_" + index.incrementAndGet());
                }
            });

        } else {
            bossGroup = new NioEventLoopGroup(this.getBossThread(), new ThreadFactory() {
                private AtomicInteger index = new AtomicInteger(0);
                @Override
                public Thread newThread(Runnable r) {
                    return new Thread(r, "BOSS_" + index.incrementAndGet());
                }
            });
            workGroup = new NioEventLoopGroup(this.getWorkThread(), new ThreadFactory() {
                private AtomicInteger index = new AtomicInteger(0);
                @Override
                public Thread newThread(Runnable r) {
                    return new Thread(r, "WORK_" + index.incrementAndGet());
                }
            });
        }
    }

    private boolean useEpoll() {
        return this.isLinuxPlatform() && Epoll.isAvailable();
    }

    private boolean isLinuxPlatform() {
        String osName = System.getProperty("os.name");
        return StringUtils.isNotBlank(osName) && osName.toLowerCase().contains("linux");
    }

    public EventLoopGroup getBossGroup() {
        return bossGroup;
    }

    public void setBossGroup(EventLoopGroup bossGroup) {
        this.bossGroup = bossGroup;
    }

    public EventLoopGroup getWorkGroup() {
        return workGroup;
    }

    public void setWorkGroup(EventLoopGroup workGroup) {
        this.workGroup = workGroup;
    }

    public ServerBootstrap getBootstrap() {
        return bootstrap;
    }

    public void setBootstrap(ServerBootstrap bootstrap) {
        this.bootstrap = bootstrap;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public boolean isKeepAlive() {
        return keepAlive;
    }

    public void setKeepAlive(boolean keepAlive) {
        this.keepAlive = keepAlive;
    }

    public boolean isReuseAddr() {
        return reuseAddr;
    }

    public void setReuseAddr(boolean reuseAddr) {
        this.reuseAddr = reuseAddr;
    }

    public boolean isTcpNodelay() {
        return tcpNodelay;
    }

    public void setTcpNodelay(boolean tcpNodelay) {
        this.tcpNodelay = tcpNodelay;
    }

    public int getSndBuf() {
        return sndBuf;
    }

    public void setSndBuf(int sndBuf) {
        this.sndBuf = sndBuf;
    }

    public int getRevBuf() {
        return revBuf;
    }

    public void setRevBuf(int revBuf) {
        this.revBuf = revBuf;
    }

    public int getHeart() {
        return heart;
    }

    public void setHeart(int heart) {
        this.heart = heart;
    }

    public int getBacklog() {
        return backlog;
    }

    public void setBacklog(int backlog) {
        this.backlog = backlog;
    }

    public int getBossThread() {
        return bossThread;
    }

    public void setBossThread(int bossThread) {
        this.bossThread = bossThread;
    }

    public int getWorkThread() {
        return workThread;
    }

    public void setWorkThread(int workThread) {
        this.workThread = workThread;
    }
}
