package com.neoway.iot.gw.input.connector.hj212.handler;

import cn.hutool.core.util.StrUtil;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.common.router.RouteUplinkTemplate;
import com.neoway.iot.gw.input.connector.Connector;
import com.neoway.iot.gw.input.connector.PayloadHead;
import com.neoway.iot.gw.input.connector.hj212.model.HJ212Request;
import com.neoway.iot.gw.input.template.TemplateManager;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.LongAdder;

/**
 * <pre>
 *  描述: HJ212MessageHandler
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/09/10 14:21
 */
@ChannelHandler.Sharable
public class HJ212MessageHandler extends SimpleChannelInboundHandler<HJ212Request> {
    private static final Logger LOG = LoggerFactory.getLogger(HJ212MessageHandler.class);
    private Connector connector;
    private TemplateManager manager;
    private LongAdder linkDeviceCounter = new LongAdder();
    /**
     *  内容体 属性头
     */
    private final String[] CONTENT_PREFIX = {"QN","ST","CN","PW","MN","Flag","PNUM","PNO","CP"};
    /**
     * 设备序列号
     */
    private static final String CONTENT_MN = "MN";
    /**
     * 命令编码
     */
    private static final String CONTENT_CN = "CN";
    /**
     * 响应OK
     */
    private static final String HJ212_RESP_OK = "OK";

    public HJ212MessageHandler(Connector connector){
        this.connector=connector;
        this.manager= TemplateManager.getInstance();
    }
    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, HJ212Request hj212Request) throws Exception {
        Map<String,Object> contentMap = new HashMap<>(32);
        String msg=hj212Request.getContents();
        // 组装数据体
        String[] kvs = msg.split(";");
        int index;
        LOG.info("开始组装数据体");
        for (String kv : kvs) {
            for (String contentPrefix : CONTENT_PREFIX) {
                index = kv.indexOf(contentPrefix + "=");
                if (-1 != index) {
                    contentMap.put(contentPrefix, StrUtil.subAfter(kv, contentPrefix + "=", false));
                }
            }
        }
        LOG.info("HJ212的设备上报的数据为：" + contentMap.toString());
        String mn = String.valueOf(contentMap.get(CONTENT_MN));
        String cn = String.valueOf(contentMap.get(CONTENT_CN));
        PayloadHead head = new PayloadHead(mn,cn);
        RouteUplinkTemplate routeUplinkTemplate = connector.locateTemplate(head.getNativeId(), head.getCmdId());
        MetaTemplate metaTemplate = this.manager.getTemplate(routeUplinkTemplate.getTemplateId());
        LOG.info("接收到HJ212消息报文，原始指令={},资源ID={},",head.getCmdId(),head.getNativeId());
        if(null != metaTemplate &&metaTemplate.isDebugger()){
            LOG.info("接收到HJ212消息报文，原始指令={},资源ID={},报文={}",head.getCmdId(),head.getNativeId(),msg);
        }
        GWResponse response=connector.doUplink(routeUplinkTemplate,contentMap);
        LOG.info("接收到的HJ212消息处理结果:原始指令={},资源ID={},响应码={},错误消息={}",head.getCmdId(),head.getNativeId(),response.getCode(),response.getMsg());
        channelHandlerContext.writeAndFlush(HJ212_RESP_OK);
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        LOG.info("HJ212接入服务有连接创建={}", ctx.channel().remoteAddress().toString());
        linkDeviceCounter.increment();
        LOG.info("HJ212接入服务当前总连接数={}", linkDeviceCounter.longValue());
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        LOG.info("HJ212接入服务有连接断开={}", ctx.channel().remoteAddress().toString());
        linkDeviceCounter.decrement();
        LOG.info("HJ212接入服务当前总连接数={}", linkDeviceCounter.longValue());
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        super.userEventTriggered(ctx, evt);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        LOG.error(cause.getMessage());
        if(cause.getMessage().startsWith(RuntimeException.class.getName())) {
            // 需要关闭
            LOG.error("异常关闭连接");
            ctx.close();
        }
    }
}
