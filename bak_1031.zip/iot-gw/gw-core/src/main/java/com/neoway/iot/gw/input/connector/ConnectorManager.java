package com.neoway.iot.gw.input.connector;


import com.google.gson.Gson;
import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.input.AbstractInput;
import com.neoway.iot.sdk.dmk.data.DMDataCallBack;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.SystemDS;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: Connector构造工厂
 * @author: 20200312686
 * @date: 2020/6/23 14:11
 */
public class ConnectorManager extends AbstractInput {
    private static final Logger LOG = LoggerFactory.getLogger(ConnectorManager.class);
    private static ConnectorManager factory=null;
    private Map<String,Connector> connectorMap=new HashMap<>();
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private ConnectorManager() {

    }
    public static ConnectorManager getInstance() {
        if (factory == null) {
            synchronized (ConnectorManager.class) {
                if (factory == null) {
                    factory = new ConnectorManager();
                }
            }
        }
        return factory;
    }
    @Override
    public void start(GWConfig env) throws GWException {
        if(isStarted.get()){
            return;
        }
        for(ConnectorType connectorType:ConnectorType.values()){
            if(connectorType == ConnectorType.OTHER){
                continue;
            }
            try {
                Connector connector=create(connectorType.name(),connectorType.getConnectorClassName());
                if(connector.isEnable()){
                    connectorMap.put(connectorType.name().toLowerCase(),connector);
                    connector.start(env);
                }
            } catch (GWException e) {
                LOG.error(e.getMessage());
            }
        }
        isStarted.set(true);
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> values=new HashMap<>();
        for(Connector connector:connectorMap.values()){
            values.put(connector.name(),connector.configuration());
        }
        return values;
    }

    private Connector create(String name, String type) throws GWException {
        LOG.info("创建Connector实例 类型={} clazz={}", name, type);
        Class<? extends Connector> clazz = getClass(name);
        try {
            return clazz.newInstance();
        } catch (Exception ex) {
            LOG.error("创建Connector实例失败！clazz={}", type);
            throw new GWException("",ex.getMessage());
        }
    }

    /**
     * @desc 获取channel clazz
     * @param type
     * @return
     * @throws GWException
     */
    private Class<? extends Connector> getClass(String type) throws GWException {
        String clazzName = type;
        ConnectorType connectorType=ConnectorType.OTHER;
        try {
            connectorType=ConnectorType.valueOf(type.toUpperCase(Locale.ENGLISH));
        } catch (IllegalArgumentException ex) {
            LOG.error("Connector类型非内置，属于自定义", type);
        }
        if (!connectorType.equals(connectorType.OTHER)) {
            clazzName = connectorType.getConnectorClassName();
        }
        try {
            return (Class<? extends Connector>) Class.forName(clazzName);
        } catch (Exception ex) {
            LOG.error("找不到对应的类路径！");
            throw new GWException("",ex.getMessage());
        }
    }

    @Override
    public String name() {
        return "module-input-connector";
    }

    public Connector getConnector(String protocol){
       return connectorMap.get(StringUtils.trim(protocol).toLowerCase());
    }
    /**
     * @desc 动态调整connector
     * @param oper
     * @param ds
     */
    public void dynamicDeviceConnector(DMDataCallBack.DMDataOper oper, DeviceDS ds){
        if(StringUtils.isEmpty(ds.getExt())){
            return;
        }
        Map<String,Object> extParams=new Gson().fromJson(ds.getExt(),Map.class);
        Connector connector=connectorMap.get(ds.getProtocol().toUpperCase());
        if(null != connector){
            connector.dynamic(extParams);
        }
    }
    /**
     * @desc 动态调整connector
     * @param oper
     * @param ds
     */
    public void dynamicSystemConnector(DMDataCallBack.DMDataOper oper, SystemDS ds){

    }
}
