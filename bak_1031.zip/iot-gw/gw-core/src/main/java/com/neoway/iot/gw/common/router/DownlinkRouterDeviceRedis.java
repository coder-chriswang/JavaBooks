package com.neoway.iot.gw.common.router;

import com.neoway.iot.gw.common.config.GWConfig;

/**
 * @desc: DownlinkRouterDeviceMem
 * @author: 20200312686
 * @date: 2020/9/15 13:57
 */
public class DownlinkRouterDeviceRedis implements CacheRouter<RouteDownlinkDevice> {
    @Override
    public void start(GWConfig config) {

    }

    @Override
    public void load() {

    }

    @Override
    public void clear() {

    }

    @Override
    public RouteDownlinkDevice get(String k) {
        return null;
    }
}
