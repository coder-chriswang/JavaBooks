package com.neoway.iot.gw.common.plugin;

import com.neoway.iot.gw.common.GWRequest;
import com.neoway.iot.gw.common.config.GWConfig;

import java.util.Map;

/**
 * @desc: 这个是插件类型为java的时候的接口
 * @author: 20200312686
 * @date: 2020/9/17 9:32
 */
public interface IPlugin {
    /**
     * @desc 插件初始化
     * @param config
     */
    void start(GWConfig config);

    /**
     * 插件名称
     * @return
     */
    String name();

    /**
     * @desc 插件执行
     * @param plugin 插件
     * @param request 上下文
     */
    void execute(String plugin, GWRequest request);
}
