package com.neoway.iot.gw.common.freemarker;

import com.neoway.iot.sdk.mok.util.IDWorker;
import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;
import java.util.Random;

/**
 * @desc: 流水号
 * @author: 20200312686
 * @date: 2020/7/15 16:36
 */
public class FreeMarkerWorkerNo implements TemplateDirectiveModel {
    private static IDWorker worker=new IDWorker();
    @Override
    public void execute(Environment environment, Map params, TemplateModel[] templateModels, TemplateDirectiveBody templateDirectiveBody) throws TemplateException, IOException {
        long num=worker.nextId();
        Writer out=environment.getOut();
        out.write(String.valueOf(num));
    }
}
