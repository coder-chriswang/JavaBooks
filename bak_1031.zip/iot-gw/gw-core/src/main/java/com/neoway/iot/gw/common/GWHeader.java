package com.neoway.iot.gw.common;

import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaEnum;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.SystemDS;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @desc:
 * 1：对象实例ID与来源系统ID二选一。如果都存在以对象实例ID为准
 * 2：当模板ID不为空的时候，则其它属性可以为空
 * @author: 20200312686
 * @date: 2020/9/14 15:54
 */
@ApiModel("指令执行报文-header结构体")
public class GWHeader {
    @ApiModelProperty("产品域")
    private String ns;
    @ApiModelProperty("主题")
    private String category;
    @ApiModelProperty("对象")
    private String ci;
    @ApiModelProperty("对象实例ID")
    private String instanceid;
    @ApiModelProperty("对象原始标识")
    private String nativeid;
    @ApiModelProperty("来源系统ID")
    private String systemid;
    @ApiModelProperty("标准操作指令ID")
    private String action;
    @ApiModelProperty("模板ID")
    private String templateid;
    @ApiModelProperty(hidden = true )
    private String reqId;
    private int ts;
    //对象元数据
    private DMMetaCI metaCI;
    //系统数据源
    private SystemDS systemDS;
    //设备数据源
    private DeviceDS deviceDS;
    //数据源实例
    private DMDataPoint point;
    private Map<String,Object> ext=new HashMap<>();
    public GWHeader(){
        this.reqId= UUID.randomUUID().toString();
        Long tsmil=System.currentTimeMillis()/1000;
        this.ts=tsmil.intValue();
    }

    public GWHeader(String templdateId){
        this.templateid=templdateId;
        this.reqId= UUID.randomUUID().toString();
        Long tsmil=System.currentTimeMillis()/1000;
        this.ts=tsmil.intValue();
    }
    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getInstanceid() {
        return instanceid;
    }

    public void setInstanceid(String instanceid) {
        this.instanceid = instanceid;
    }

    public String getSystemid() {
        return systemid;
    }

    public void setSystemid(String systemid) {
        this.systemid = systemid;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getTemplateid() {
        return templateid;
    }

    public void setTemplateid(String templateid) {
        this.templateid = templateid;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public int getTs() {
        return ts;
    }

    public void setTs(int ts) {
        this.ts = ts;
    }

    public DMMetaCI getMetaCI() {
        return metaCI;
    }

    public void setMetaCI(DMMetaCI metaCI) {
        this.metaCI = metaCI;
    }

    public SystemDS getSystemDS() {
        return systemDS;
    }

    public void setSystemDS(SystemDS systemDS) {
        this.systemDS = systemDS;
    }

    public DeviceDS getDeviceDS() {
        return deviceDS;
    }

    public void setDeviceDS(DeviceDS deviceDS) {
        this.deviceDS = deviceDS;
    }

    public DMDataPoint getPoint() {
        return point;
    }

    public void setPoint(DMDataPoint point) {
        this.point = point;
    }

    public Map<String, Object> getExt() {
        return ext;
    }

    public void setExt(Map<String, Object> ext) {
        this.ext = ext;
    }

    public String getNativeid() {
        return nativeid;
    }

    public void setNativeid(String nativeid) {
        this.nativeid = nativeid;
    }

    public void addExtData(Map<String,Object> extData){
        this.ext.putAll(extData);
    }
    public DMMetaEnum.MetaActionEnum getActionGroup(){
        if(null != this.metaCI){
            DMMetaAction metaAction=this.metaCI.buildAssignAction(this.action);
            if(null != metaAction){
                return DMMetaEnum.MetaActionEnum.getMetaActionEnum(metaAction.group);
            }else{
                return null;
            }
        }else{
            return DMMetaEnum.MetaActionEnum.MgrOper;
        }
    }

    public boolean needFillMetaCI(){
        return (this.metaCI == null
                && StringUtils.isNotEmpty(this.ns)
                && StringUtils.isNotEmpty(this.category)
                && StringUtils.isNotEmpty(this.ci));
    }
}
