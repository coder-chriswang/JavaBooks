package com.neoway.iot.gw.input.connector.hj212.coder;

import cn.hutool.core.util.StrUtil;
import com.neoway.iot.gw.common.utils.GWUtils;
import com.neoway.iot.gw.input.connector.hj212.model.HJ212Request;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageEncoder;

import java.util.List;


/**
 * <pre>
 *  描述: HJ212Encoder
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/09/10 13:58
 */
public class HJ212Encoder extends MessageToMessageEncoder<HJ212Request> {

    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext, HJ212Request hj212Request, List<Object> list) throws Exception {
        StringBuilder sb = new StringBuilder();
        String contents= hj212Request.getContents();
        int length;
        if(StrUtil.isBlank(contents)) {
            length = 0;
        } else {
            length = contents.length();
        }
        String lengthStr = StrUtil.fillBefore(""+(length),'0',4);
        String calcCrc = GWUtils.crc16(StrUtil.utf8Bytes(contents),length);
        sb.append("##").append(lengthStr).append(contents).append(calcCrc).append("\r\n");
    }
}
