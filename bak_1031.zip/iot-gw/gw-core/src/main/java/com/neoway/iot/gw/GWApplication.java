package com.neoway.iot.gw;

import com.neoway.iot.gw.channel.ChannelManager;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.input.InputManager;
import com.neoway.iot.gw.output.OutputManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class GWApplication implements CommandLineRunner {
	private static final Logger LOG = LoggerFactory.getLogger(GWApplication.class);

	@Autowired
	private Environment env;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LOG.info("开始启动");
		SpringApplication.run(GWApplication.class, args);
		LOG.info("启动成功");
	}

	@Override
	public void run(String... strings) throws Exception {
		LOG.info("注册配置");
		GWConfig.getInstance().start(env.getProperty("dgw.config"));
		LOG.info("配置注册成功");
		LOG.info("GW开始初始化");
		GWLifecycleComponent outputComponent= OutputManager.getInstance();
		GWLifecycleComponent channelComponent= ChannelManager.getInstance();
		GWLifecycleComponent inputComponent= InputManager.getInstance();
		outputComponent.start();
		channelComponent.start();
		inputComponent.start();
		LOG.info("GW初始化成功");
	}
}
