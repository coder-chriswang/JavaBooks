package com.neoway.iot.gw.input.connector;

import com.google.gson.Gson;
import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.GWHeader;
import com.neoway.iot.gw.common.GWRequest;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.common.router.CacheRouter;
import com.neoway.iot.gw.common.router.CacheRouterBuilder;
import com.neoway.iot.gw.common.router.RouteUplinkProtocol;
import com.neoway.iot.gw.common.router.RouteUplinkTemplate;
import com.neoway.iot.gw.input.AbstractInput;
import com.neoway.iot.gw.input.health.HealthCheckerManager;
import com.neoway.iot.gw.input.scheduler.ExecutorUplink;
import com.neoway.iot.gw.input.template.TemplateManager;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.GWKEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;


public abstract class Connector extends AbstractInput {
    private static final Logger LOG = LoggerFactory.getLogger(Connector.class);
    private CacheRouterBuilder cacheRouterBuilder;
    private HealthCheckerManager healthCheckerManager;
    private TemplateManager templateManager;
    private static final String CACHE_SPLIT = "@##@";
    @Override
    public void start(GWConfig config) throws GWException {
        super.start(config);
        this.cacheRouterBuilder = CacheRouterBuilder.getInstance();
        this.cacheRouterBuilder.start();
        this.templateManager = TemplateManager.getInstance();
        this.healthCheckerManager=HealthCheckerManager.getInstance();
        this.healthCheckerManager.start();
    }

    @Override
    public void stop() {
        super.stop();
    }

    public void dynamic(Map<String,Object> extParam){
        LOG.info("Connector-{} 参数动态调整：{}",this.name(),new Gson().toJson(extParam));
    }
    @Override
    public GWResponse uplink(GWRequest req) {
        GWHeader gwHeader=req.getHeader();
        healthCheckerManager.triggerStatus(Long.valueOf(gwHeader.getInstanceid()), GWKEnum.DsStatus.ONLINE,gwHeader.getTs());
        return ExecutorUplink.uplink(req);
    }

    /**
     * @desc 上报数据
     * @param routeUplinkTemplate 模板路由对象
     * @param data 原始报文
     * @return 执行结果
     */
    public GWResponse doUplink(RouteUplinkTemplate routeUplinkTemplate, Object data) {
        GWRequest request=new GWRequest();
        GWHeader gwHeader=new GWHeader();
        gwHeader.setTemplateid(routeUplinkTemplate.getTemplateId());
        gwHeader.setInstanceid(String.valueOf(routeUplinkTemplate.getInstanceid()));
        gwHeader.setAction(routeUplinkTemplate.getMetaActionId());
        gwHeader.setNativeid(routeUplinkTemplate.getNativeId());
        gwHeader.setNs("ies");
        gwHeader.setCategory("urm");
        //查询设备数据源信息（产品信息）
        DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceDS.class);
        DMDataPoint condition=DMDataPoint.builder(metaCI.getNs(), metaCI.getCategory(),metaCI.getCi());
        DMDataColumn column=new DMDataColumn("code", routeUplinkTemplate.getDeviceDsCode());
        condition.addColumn(column);
        DMDataPoint dsDP= DMRunner.getInstance().get(condition);
        DeviceDS deviceDS=DeviceDS.buildDeviceDS(dsDP,true);
        gwHeader.setDeviceDS(deviceDS);
        gwHeader.setCi(deviceDS.getDeviceType());
        request.setHeader(gwHeader);
        Map<String,Object> bodyMap=new HashMap<>();
        bodyMap.put("data",data);
        request.setBody(bodyMap);
        return this.uplink(request);
    }

    /**
     * @desc 上行-协议解析
     * @param protocol 协议
     * @param method 接口
     * @param context 报文数据
     * @return 设备原始ID
     */
    public PayloadHead uplinkDecodeProtocol(String protocol, String method, Map<String,Object> context) {
        String key = protocol + CACHE_SPLIT + method;
        RouteUplinkProtocol routeUplinkProtocol = (RouteUplinkProtocol) cacheRouterBuilder.getCache(CacheRouter.ROUTE_UPLINK_PROTOCOL).get(key);
        if (null == routeUplinkProtocol || !protocol.equals(routeUplinkProtocol.getProtocol()) || !method.equals(routeUplinkProtocol.getTopic())) {
            LOG.error("协议路由定位失败！协议={}，接口={}, 报文数据={}", protocol, method, context);
            return null;
        }
        // 封装PayloadHead
        String accessType = routeUplinkProtocol.getAccessType();
        PayloadHead payloadHead = new PayloadHead(protocol, method);
        payloadHead.setAccessType(accessType);
        return payloadHead;
    }

    /**
     * @desc 根据资源原始ID定位模板
     * @param imei 资源原始标识
     * @param cmdId 原始服务标识
     * @return 模板ID
     */
    public RouteUplinkTemplate locateTemplate(String imei,String cmdId) {
        String key = imei + CACHE_SPLIT + cmdId;
        RouteUplinkTemplate routeUplinkTemplate = (RouteUplinkTemplate) cacheRouterBuilder.getCache(CacheRouter.ROUTE_UPLINK_TEMPLATE).get(key);
        if (null == routeUplinkTemplate) {
            LOG.error("模板定位失败！原始资源标识={},原始服务标识={}", imei,cmdId);
            return null;
        }
        return routeUplinkTemplate;
    }

    /**
     * 执行
     * @param request
     * @return
     */
    public abstract ConnectorRsp downlink(ConnectorReq request);

}
