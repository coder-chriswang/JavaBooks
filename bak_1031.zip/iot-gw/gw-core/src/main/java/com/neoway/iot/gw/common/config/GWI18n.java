package com.neoway.iot.gw.common.config;

import com.neoway.iot.gw.common.GWException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: 国际化词条
 * @author: 20200312686
 * @date: 2020/7/6 13:21
 */
public class GWI18n {
    private static final Logger LOG = LoggerFactory.getLogger(GWI18n.class);
    private static final String SPILIT="@#@";
    private static GWI18n env=null;
    private Map<String,Object> i18n=new HashMap<>();
    private GWI18n(){
    }
    public static GWI18n getInstance(){
        if (env == null) {
            synchronized (GWI18n.class) {
                if (env == null) {
                    env = new GWI18n();
                }
            }
        }
        return env;
    }

    /**
     * @desc 添加国际化词条
     * @param paths
     * @param proName
     * @throws GWException
     */
    public void add(List<String> paths,String proName) throws GWException {
        Yaml dgwYml=new Yaml();
        try{
            for(String path:paths){
                File f=new File(path);
                if(!f.exists()){
                    continue;
                }
                String lan=f.getName().replace("i18n_","");
                Map<String,Object> result=dgwYml.load(new FileInputStream(f));
                StringBuilder sb=new StringBuilder();
                sb.append(proName).append(SPILIT).append(lan).append(SPILIT);
                for(Map.Entry entry:result.entrySet()){
                    i18n.put(sb.toString()+SPILIT+entry.getKey(),entry.getValue());
                }

            }
        }catch (IOException e){
            LOG.error(e.getMessage(),e);
            throw new GWException("",e.getMessage());
        }
    }

    /**
     * @desc 获取国际化词条
     * @param proName
     * @param lan
     * @param key
     * @return
     */
    public String getValue(String proName,String lan,String key){
        StringBuilder sb=new StringBuilder();
        sb.append(proName).append(SPILIT).append(lan).append(SPILIT).append(key);
        return i18n.get(sb.toString()).toString();
    }
}
