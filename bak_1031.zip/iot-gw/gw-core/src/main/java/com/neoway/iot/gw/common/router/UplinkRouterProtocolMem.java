package com.neoway.iot.gw.common.router;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.common.utils.GWUtils;
import com.neoway.iot.gw.input.template.TemplateManager;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.DSExt;
import com.neoway.iot.sdk.gwk.entity.DeviceDS;
import com.neoway.iot.sdk.gwk.entity.MetaTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @desc: 上行-协议解析路由表
 * @author: Chris(wangchao)
 * @date: 2020/9/14 19:28
 */
public class UplinkRouterProtocolMem implements CacheRouter<RouteUplinkProtocol> {
    private static final Logger LOG = LoggerFactory.getLogger(UplinkRouterProtocolMem.class);
    private static final String CACHE_SPLIT="@##@";
    // 协议解析路由表
    private LoadingCache<String, RouteUplinkProtocol> protocolLoadingCache;
    private DMRunner runner;
    @Override
    public void start(GWConfig config) {
        int cacheMaxSize=500000;
        int cacheInitSize=1000;
        this.runner=DMRunner.getInstance();
        protocolLoadingCache= CacheBuilder.newBuilder()
                .maximumSize(cacheMaxSize)
                .recordStats()
                .initialCapacity(cacheInitSize)
                .build(new CacheLoader<String, RouteUplinkProtocol>() {
                    @Override
                    public RouteUplinkProtocol load(String s) throws Exception {
                        LOG.debug("数据缓存不存在，从数据库加载:s={}",s);
                        RouteUplinkProtocol routeUplinkProtocol;
                        String[] params = s.split(CACHE_SPLIT);
                        String querySql = MessageFormat.format(SQL, params[0], params[1]);
                        try {
                            List<Map<String, Object>> result = runner.executeSQL(querySql);
                            if (CollectionUtils.isEmpty(result)) {
                                LOG.error("查询数据库模板不存在！");
                                routeUplinkProtocol = null;
                            } else {
                                Gson gson = GWUtils.getJsonUtil();
                                Map<String, Object> map = result.get(0);
                                routeUplinkProtocol = gson.fromJson(gson.toJson(map), new TypeToken<RouteUplinkProtocol>() {}.getType());
                            }
                        } catch (Exception e) {
                            LOG.error("查询错误！", e);
                            routeUplinkProtocol = null;
                        }
                        return routeUplinkProtocol;
                    }
                });
    }

    /**
     * @desc 生成缓存KEY
     * @param protocol
     * @param topic
     * @return
     */
    private String buildCacheKey(String protocol,String topic) {
        StringBuilder sb = new StringBuilder();
        sb.append(protocol).append(CACHE_SPLIT).append(topic);
        return sb.toString();
    }


    @Override
    public void load() {
        DMMetaCI metaCI=DMMetaCI.getMetaCI(DeviceDS.class);
        DMDataPoint condition=DMDataPoint.builder(metaCI.getNs(), metaCI.getCategory(),metaCI.getCi());
        // 查询出deviceDS所有实例
        List<DMDataPoint> points = runner.list(condition);
        if (CollectionUtils.isEmpty(points)) {
            return;
        }
        List<RouteUplinkProtocol> routeUplinkProtocols = new ArrayList<>();
        for (DMDataPoint point : points) {
            DeviceDS deviceDS = DeviceDS.buildDeviceDS(point,true);
            if (deviceDS == null) {
                continue;
            }
            // 得到该deviceDS实例下attr=topic的集合,集合元素有一个
            DSExt.MQTTExt mqttExt= deviceDS.getMQTTExt();
            if (mqttExt == null) {
                continue;
            }
            RouteUplinkProtocol uplinkProtocol = new RouteUplinkProtocol();
            uplinkProtocol.setTopic(mqttExt.getTopic());
            uplinkProtocol.setProtocol(deviceDS.getProtocol());
            uplinkProtocol.setAccessType(deviceDS.getAccessType());
            uplinkProtocol.setTemplateId(RouterConstant.UplinkTemplateId.getTemplateIdByAccessType(uplinkProtocol.getAccessType(),
                    uplinkProtocol.getProtocol()));
            routeUplinkProtocols.add(uplinkProtocol);
        }
        // RouteUplinkProtocol唯一标识是(accessType+topic),且accessType与topic一一对应
        if (CollectionUtils.isEmpty(routeUplinkProtocols)) {
            LOG.warn("未查询到有效RouteUplinkProtocol");
            return;
        }
        // 集合去重
        routeUplinkProtocols.stream().distinct().collect(Collectors.toList());
        // 放入缓存
        routeUplinkProtocols.forEach(r -> {
            TemplateManager manager = TemplateManager.getInstance();
            MetaTemplate tpl = manager.getTemplate(r.getTemplateId());
            // 模板存在，放入缓存
            if (tpl != null) {
                protocolLoadingCache.put(buildCacheKey(r.getProtocol(), r.getTopic()), r);
                }
            });
    }

    @Override
    public void clear() {
        protocolLoadingCache.cleanUp();
    }

    @Override
    public RouteUplinkProtocol get(String k) {
        RouteUplinkProtocol routeUplinkProtocol = null;
        try {
            routeUplinkProtocol = protocolLoadingCache.get(k);
        } catch (Exception e) {
            LOG.error("查询不到协议路由！", e);
        }
        return routeUplinkProtocol;
    }


    private static final String SQL = "SELECT\n" +
            "\ta.protocol AS protocol,\n" +
            "\ta.access_type AS accessType,\n" +
            "\tb.attr AS attr,\n" +
            "\tb.value AS ext\n" +
            "FROM\n" +
            "\ties_gwm.GWM_B_DEVICEDS a\n" +
            "\tLEFT JOIN ies_gwm.GWM_B_DSEXT b ON a.code = b.code\n" +
            "WHERE a.protocol = ''{0}'' AND b.attr = \"topic\" AND CONTAINS(b.value, ''{1}'');";
}
