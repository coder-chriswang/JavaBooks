package com.neoway.iot.gw.input.connector.hj212;

import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.input.connector.Connector;
import com.neoway.iot.gw.input.connector.ConnectorReq;
import com.neoway.iot.gw.input.connector.ConnectorRsp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: HJ212Connector
 * @author: Chris(wangchao)
 * @date: 2020/9/9 15:45
 */
public class HJ212Connector extends Connector {
    private static final Logger LOG = LoggerFactory.getLogger(HJ212Connector.class);
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private GWConfig env;

    @Override
    public void start(GWConfig env) throws GWException {
        if(isStarted.get()){
            return;
        }
        this.env = env;
        LOG.info("HJ212Connector开始启动");
        HJ212BootstrapServer hj212BootstrapServer = new HJ212BootstrapServer(env);
        try {
            hj212BootstrapServer.start(this);
        } catch (Exception e) {
            LOG.error(e.getMessage(),e);
            throw new GWException("",e.getMessage());
        }
        isStarted.set(true);
        super.start(env);
        LOG.info("HJ212Connector启动成功");
    }

    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        return null;
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }
    @Override
    public String name() {
        return "input-connector-hj212";
    }
}
