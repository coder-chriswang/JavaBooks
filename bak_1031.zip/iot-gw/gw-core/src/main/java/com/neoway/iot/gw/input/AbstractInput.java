package com.neoway.iot.gw.input;

import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.GWRequest;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.common.config.GWConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @desc: AbstractInput
 * @author: 20200312686
 * @date: 2020/6/23 16:10
 */
public abstract class AbstractInput implements Input{
    private static final Logger LOG = LoggerFactory.getLogger(AbstractInput.class);
    @Override
    public void start(GWConfig config) throws GWException {
        LOG.info("插件：{} 启动成功", this.name());
    }

    @Override
    public void stop() {
        LOG.info("插件：{} 停止成功", this.name());
    }

    @Override
    public boolean isEnable() {
        return true;
    }

    @Override
    public String name() {
        return "module-input";
    }
    @Override
    public GWResponse uplink(GWRequest req) {
        return null;
    }
}
