package com.neoway.iot.gw.input.connector;

import com.neoway.iot.gw.common.utils.GWUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @desc: connector response响应体
 * @author: 20200312686
 * @date: 2020/6/29 17:35
 */
public class ConnectorRsp {
    private Map<String,Object> header=new HashMap<>();
    private Map<String,Object> body=new ConcurrentHashMap<>();

    public Map<String, Object> getHeader() {
        return header;
    }

    public void setHeader(Map<String, Object> header) {
        this.header = header;
    }

    public Map<String, Object> getBody() {
        return body;
    }

    public void setBody(Map<String, Object> body) {
        this.body = body;
    }

    public String getHeaderJson(){
        return GWUtils.getJsonUtil().toJson(this.header);
    }
}
