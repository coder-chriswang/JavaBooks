package com.neoway.iot.gw.channel;

import com.neoway.iot.gw.common.GWEvent;
import com.neoway.iot.gw.common.event.GWBusEvent;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: channel通道存储结构
 * @author: 20200312686
 * @date: 2020/7/7 11:10
 */
public class ChannelEvent implements Serializable {
    public String eventId;
    public GWEvent context;
    //K：topic boolean为是否消费成功的标识
    public Map<String, Boolean> status=new HashMap<>();
    public ChannelEvent(){

    }
    public ChannelEvent(GWEvent context, Map<String,Boolean> status){
        this.context=context;
        this.eventId=context.getHeader().getReqId();
        this.status=status;
    }

    public GWEvent getContext() {
        return context;
    }

    public void setContext(GWEvent context) {
        this.context = context;
    }

    public Map<String, Boolean> getStatus() {
        return status;
    }

    public void setStatus(Map<String, Boolean> status) {
        this.status = status;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }
}
