package com.neoway.iot.gw;

import com.neoway.iot.gw.common.GWException;

/**
 * @desc: 组件生命周期管理接口
 * @author: 20200312686
 * @date: 2020/6/22 12:27
 */
public interface GWLifecycleComponent {
    void start() throws GWException;
    void stop();
}
