package com.neoway.iot.gw.channel.direct;

import com.neoway.iot.gw.channel.AbstractChannel;
import com.neoway.iot.gw.channel.ChannelEvent;
import com.neoway.iot.gw.common.GWEvent;
import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.output.OutputProcessor;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: 透传channel
 * @author: 20200312686
 * @date: 2020/6/23 9:27
 */
public class DirectChannel extends AbstractChannel {
    OutputProcessor processor= OutputProcessor.getInstance();
    @Override
    public GWResponse process(GWEvent context) {
        List<ChannelEvent> events=new ArrayList<>();
        List<Map<String,Object>> values=context.decodeData();
        for(Map<String,Object> value:values){
            GWEvent cc=new GWEvent(context.getHeader(),value);
            ChannelEvent event=new ChannelEvent(cc,null);
            events.add(event);
        }
        return this.doProcess(events);
    }

    @Override
    public String name() {
        return "channel-plugin-direct";
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public GWResponse doProcess(List<ChannelEvent> events) {
        if(CollectionUtils.isNotEmpty(events)){
            return processor.process(events);
        }
        return new GWResponse();
    }

    @Override
    public List<GWEvent> take() throws GWException {
        return null;
    }

    @Override
    public void commit(String eventId, String topic, boolean status){
        return;
    }

}
