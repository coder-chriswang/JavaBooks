package com.neoway.iot.gw.channel;

import com.neoway.iot.gw.common.GWEvent;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.common.config.GWConfig;
import com.neoway.iot.gw.output.Output;
import com.neoway.iot.gw.output.OutputManager;
import com.neoway.iot.sdk.dmk.meta.DMMetaEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: AbstractChannel
 * @author: 20200312686
 * @date: 2020/6/23 10:01
 */
public abstract class AbstractChannel implements Channel {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractChannel.class);
    private OutputManager outputManager;

    @Override
    public void start(GWConfig config) {
        this.outputManager=OutputManager.getInstance();
        LOG.info("channel插件：{} 启动成功", this.name());
    }

    @Override
    public void stop() {
        LOG.info("channel插件：{} 停止成功", this.name());
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public GWResponse process(GWEvent context) {
        String cmd=context.getHeader().getCmdId();
        List<Output> outputs=this.outputManager.getOutputs(cmd);
        if(CollectionUtils.isEmpty(outputs)){
            LOG.warn("消息cmdId={},reqId={}没有接收的output插件",
                    context.getHeader().getCmdGroup().name(),context.getHeader().getReqId());
            return new GWResponse();
        }
        Map<String,Boolean> status=new HashMap<>();
        for(Output out:outputs){
            status.put(out.name(),false);
        }
        List<Map<String,Object>> values=context.decodeData();
        List<ChannelEvent> events=new ArrayList<>();
        for(Map<String,Object> value:values){
            GWEvent cc=new GWEvent(context.getHeader(),value);
            ChannelEvent event=new ChannelEvent(cc,status);
            events.add(event);
        }
        return this.doProcess(events);

    }

    /**
     * @desc
     * @param events
     */
    public abstract GWResponse doProcess(List<ChannelEvent> events);
}
