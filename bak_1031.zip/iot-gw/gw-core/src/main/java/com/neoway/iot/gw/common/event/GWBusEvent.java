package com.neoway.iot.gw.common.event;

import com.neoway.iot.gw.common.GWHeader;

import java.io.Serializable;
import java.util.Map;

/**
 * @desc: 内部事件消息结构体
 * @author: 20200312686
 * @date: 2020/7/1 15:19
 */
public class GWBusEvent implements Serializable {
    public String source;
    public GWHeader header;
    public Map<String,Object> message;
    public GWBusEvent(){

    }
    public GWBusEvent(Builder build){
        this.source=build.source;
        this.message=build.message;
    }
    public static Builder builder(){
        return new Builder();
    }
    public static final class Builder {
        private String source;
        private String product;
        private String topic;
        private String cmdId;
        private Map<String,Object> message;
        private Builder() {
        }
        public Builder source(String source){
            this.source =this.source;
            return this;
        }
        public Builder header(String product,String topic,String cmdId){
            this.product=product;
            this.topic=topic;
            this.cmdId=cmdId;
            return this;
        }
        public Builder message(Map<String,Object> message){
            this.message =message;
            return this;
        }
        public GWBusEvent build() {
            return new GWBusEvent(this);
        }
    }
}
