package com.neoway.iot.gw.common.router;

import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.gwk.entity.SystemDS;

/**
 * @desc: 下行-系统路由结构
 * @author: 20200312686
 * @date: 2020/9/15 13:51
 */
public class RouteDownlinkSystem {
    /**
     * 系统ID
     */
    private long systemid;
    /**
     * 系统数据源
     */
    private long systemDsCode;
    /**
     * 标准服务ID
     */
    private String metaActionId;
    /**
     * 资源分区
     */
    private String region;
    /**
     * 模板ID
     */
    private String templateId;

    //对象元数据
    private transient DMMetaCI metaCI;
    //系统数据源
    private transient SystemDS systemDS;
    //数据源实例
    private transient DMDataPoint point;

    public long getSystemid() {
        return systemid;
    }

    public void setSystemid(long systemid) {
        this.systemid = systemid;
    }

    public long getSystemDsCode() {
        return systemDsCode;
    }

    public void setSystemDsCode(long systemDsCode) {
        this.systemDsCode = systemDsCode;
    }

    public String getMetaActionId() {
        return metaActionId;
    }

    public void setMetaActionId(String metaActionId) {
        this.metaActionId = metaActionId;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public DMMetaCI getMetaCI() {
        return metaCI;
    }

    public void setMetaCI(DMMetaCI metaCI) {
        this.metaCI = metaCI;
    }

    public SystemDS getSystemDS() {
        return systemDS;
    }

    public void setSystemDS(SystemDS systemDS) {
        this.systemDS = systemDS;
    }

    public DMDataPoint getPoint() {
        return point;
    }

    public void setPoint(DMDataPoint point) {
        this.point = point;
    }
}
