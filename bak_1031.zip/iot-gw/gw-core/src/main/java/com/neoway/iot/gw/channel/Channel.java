package com.neoway.iot.gw.channel;

import com.neoway.iot.gw.common.GWEvent;
import com.neoway.iot.gw.common.GWException;
import com.neoway.iot.gw.common.GWResponse;
import com.neoway.iot.gw.common.config.GWConfig;

import java.util.List;
import java.util.Map;

public interface Channel{
    /**
     * @desc 获取插件名称
     * @return 插件名称
     */
    String name();

    /**
     * @desc 启动
     * @param config
     */
    void start(GWConfig config);

    /**
     * @desc 停止
     */
    void stop();

    /**
     * @desc 获取配置
     * @return
     */
    Map<String,Object> configuration();

    /**
     * @desc 写数据
     * @param context
     * @throws GWException
     */
    GWResponse process(GWEvent context);

    /**
     * @desc 读取数据
     * @return
     * @throws GWException
     */
    List<GWEvent> take() throws GWException;

    /**
     * @desc 结果提交
     * @param eventId 事件ID
     * @param topic 订阅主题
     * @param status 消费结果
     * @throws GWException
     */
    void commit(String eventId, String topic, boolean status) throws GWException;
}
