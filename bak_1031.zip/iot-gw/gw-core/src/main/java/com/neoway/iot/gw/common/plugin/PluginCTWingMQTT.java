package com.neoway.iot.gw.common.plugin;

import com.neoway.iot.gw.common.GWRequest;
import com.neoway.iot.gw.common.config.GWConfig;

import java.util.Map;

/**
 * @desc: 兼容CTWing MQTT场景下 协议解析插件
 * @author: 20200312686
 * @date: 2020/9/17 9:43
 */
public class PluginCTWingMQTT implements IPlugin {
    @Override
    public void start(GWConfig config) {

    }

    @Override
    public String name() {
        return null;
    }

    @Override
    public void execute(String plugin, GWRequest request) {
    }
}
