package com.neoway.iot.gw.common.plugin;

import com.neoway.iot.gw.common.GWRequest;

import java.util.Map;

/**
 * @desc: RtPlugin
 * @author: 20200312686
 * @date: 2020/9/17 9:29
 */
public interface RtPlugin {
    /**
     * 支持的插件运行时
     */
    enum RtPluginType{
        JS,
        JAVA,
        LUA,
        PYTHON
    }
    /**
     * 插件初始化
     */
    void start();

    /**
     * 插件名称
     * @return
     */
    String name();

    /**
     * @desc 插件执行
     * @param plugin
     * @return
     */
    Map<String,Object> executePlugin(String plugin, GWRequest request);
}
