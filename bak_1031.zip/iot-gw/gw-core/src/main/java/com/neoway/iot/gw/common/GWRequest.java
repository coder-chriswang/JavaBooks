package com.neoway.iot.gw.common;

import com.neoway.iot.gw.common.utils.GWUtils;
import com.neoway.iot.gw.input.connector.ConnectorRsp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: GWRequest
 * @author: 20200312686
 * @date: 2020/9/14 16:40
 */
@ApiModel("指令执行报文")
public class GWRequest {
    @ApiModelProperty("消息Header")
    private GWHeader header;
    @ApiModelProperty("消息Body")
    private Map<String,Object> body=new HashMap<>();
    //req插件输出
    private Map<String,Object> req_plugin_context;
    //rsp插件输出
    private Map<String,Object> rsp_plugin_context;
    //rsp输出
    private ConnectorRsp rsp_connector_context;
    public GWRequest(){

    }
    public GWRequest(GWHeader header){
        this.header=header;
    }
    public GWHeader getHeader() {
        return header;
    }

    public void setHeader(GWHeader header) {
        this.header = header;
    }

    public Map<String, Object> getBody() {
        return body;
    }

    public void setBody(Map<String, Object> body) {
        this.body = body;
    }

    public Map<String, Object> getReq_plugin_context() {
        return req_plugin_context;
    }

    public void setReq_plugin_context(Map<String, Object> req_plugin_context) {
        this.req_plugin_context = req_plugin_context;
    }

    public Map<String, Object> getRsp_plugin_context() {
        return rsp_plugin_context;
    }

    public void setRsp_plugin_context(Map<String, Object> rsp_plugin_context) {
        this.rsp_plugin_context = rsp_plugin_context;
    }

    public ConnectorRsp getRsp_connector_context() {
        return rsp_connector_context;
    }

    public void setRsp_connector_context(ConnectorRsp rsp_connector_context) {
        this.rsp_connector_context = rsp_connector_context;
        if(null != this.header){
            String headJson=rsp_connector_context.getHeaderJson();
            GWHeader header= GWUtils.getJsonUtil().fromJson(headJson,GWHeader.class);
            if(StringUtils.isEmpty(this.header.getNs())){
                this.header.setNs(header.getNs());
            }
            if(StringUtils.isEmpty(this.header.getCategory())){
                this.header.setCategory(header.getCategory());
            }
            if(StringUtils.isEmpty(this.header.getCi())){
                this.header.setCi(header.getCi());
            }
            if(StringUtils.isEmpty(this.header.getAction())){
                this.header.setAction(header.getAction());
            }
            this.header.addExtData(header.getExt());
        }
    }
}
