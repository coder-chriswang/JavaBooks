package com.neoway.iot.gw.common.router;

import com.neoway.iot.gw.common.config.GWConfig;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: RouterCacheBuilder
 * @author: 20200312686
 * @date: 2020/9/15 13:24
 */
public class CacheRouterBuilder {
    private static CacheRouterBuilder builder=null;
    private Map<String, CacheRouter> caches;
    private GWConfig env;
    private CacheRouterBuilder(){
        env=GWConfig.getInstance();
        this.caches=build();
    }
    public static CacheRouterBuilder getInstance(){
        if (builder == null) {
            synchronized (CacheRouterBuilder.class) {
                if (builder == null) {
                    builder = new CacheRouterBuilder();
                }
            }
        }
        return builder;
    }
    private Map<String, CacheRouter> build(){
        Map<String, CacheRouter> caches=new HashMap<>();
        if(CacheRouter.CACHE_REDIS.equals(env.getValue(CacheRouter.CACHE_KEY))) {
            caches.put(CacheRouter.ROUTE_UPLINK_TEMPLATE,new UplinkRouterTemplateRedis());
            caches.put(CacheRouter.ROUTE_UPLINK_PROTOCOL,new UplinkRouterProtocolRedis());
            caches.put(CacheRouter.ROUTE_DOWNLINK_DEVICE,new DownlinkRouterDeviceRedis());
            caches.put(CacheRouter.ROUTE_DOWNLINK_SYSTEM,new DownlinkRouterSystemRedis());
        } else {
            caches.put(CacheRouter.ROUTE_UPLINK_TEMPLATE,new UplinkRouterTemplateMem());
            caches.put(CacheRouter.ROUTE_UPLINK_PROTOCOL,new UplinkRouterProtocolMem());
            caches.put(CacheRouter.ROUTE_DOWNLINK_DEVICE,new DownlinkRouterDeviceMem());
            caches.put(CacheRouter.ROUTE_DOWNLINK_SYSTEM,new DownlinkRouterSystemMem());
        }

        return caches;
    }
    public CacheRouter getCache(String type) {
        return caches.get(type);
    }

    public void start(){
        for(CacheRouter cache:caches.values()){
            cache.start(env);
        }
    }
    public void stop(){
        for(CacheRouter cache:caches.values()){
            cache.clear();
        }
    }
}
