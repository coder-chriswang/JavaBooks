package com.neoway.iot.gw.common.router;


import com.neoway.iot.gw.common.config.GWConfig;

/**
 * @desc: RouterCache
 * @author: 20200312686
 * @date: 2020/9/15 13:25
 */
public interface CacheRouter<T> {
    String CACHE_KEY="intput.router.cache";
    String CACHE_REDIS="redis";
    String CACHE_MEM="mem";
    String CACHE_MAX="gw_route_cache_max";
    String CACHE_INIT="gw_route_cache_init";
    String ROUTE_UPLINK_PROTOCOL="UplinkProtocol";
    String ROUTE_UPLINK_TEMPLATE="UplinkTemplate";
    String ROUTE_DOWNLINK_DEVICE="DownlinkDevice";
    String ROUTE_DOWNLINK_SYSTEM="DownlinkSystem";
    void start(GWConfig config);
    void load();
    void clear();
    T get(String k);
}
