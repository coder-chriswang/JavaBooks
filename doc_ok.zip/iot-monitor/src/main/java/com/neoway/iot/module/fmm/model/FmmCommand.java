package com.neoway.iot.module.fmm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *  描述: 告警操作参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/31 11:23
 */
@ApiModel("告警操作参数")
@Data
public class FmmCommand implements Serializable {
    private static final long serialVersionUID = 5336906871146415148L;

    @ApiModelProperty("元素列表")
    List<FmmCommandItem> items;

    @ApiModelProperty("操作指令(清除：Clear,转单：Transport,重置：Reset,挂起：Pend)")
    private String action;
}
