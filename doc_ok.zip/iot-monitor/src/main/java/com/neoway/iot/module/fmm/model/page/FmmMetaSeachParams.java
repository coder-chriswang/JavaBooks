package com.neoway.iot.module.fmm.model.page;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 静态告警数据
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/31 10:45
 */
@ApiModel("静态告警数据")
@Data
public class FmmMetaSeachParams implements Serializable {
    private static final long serialVersionUID = -4305973565303817937L;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页行数")
    private Integer pageSize;
}
