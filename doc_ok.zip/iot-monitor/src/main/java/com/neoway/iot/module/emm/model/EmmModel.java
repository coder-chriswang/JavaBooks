package com.neoway.iot.module.emm.model;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: EmmModel
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 9:50
 */
@Data
@ApiModel("事件模型")
public class EmmModel implements Serializable {
    private static final long serialVersionUID = -5076919253350137121L;

    @ExcelProperty(value = "事件流水号", index = 0)
    @ApiModelProperty("事件流水号")
    private long eventNo;

    @ApiModelProperty("instanceId")
    private String instanceId;

    @ExcelProperty(value = "事件ID", index = 1)
    @ApiModelProperty("事件ID")
    private String eventId;

    @ExcelProperty(value = "事件名称", index = 2)
    @ApiModelProperty("事件名称")
    private String eventName;

    @ExcelProperty(value = "事件分类", index = 3)
    @ApiModelProperty("事件分类")
    private String eventCategory;

    @ExcelProperty(value = "事件类型", index = 4)
    @ApiModelProperty("事件类型")
    private String eventType;

    @ExcelProperty(value = "事件级别", index = 5)
    @ApiModelProperty("事件级别")
    private String eventSeverity;

    @ExcelProperty(value = "事件详情", index = 6)
    @ApiModelProperty("事件详情")
    private String eventInfo;

    @ExcelProperty(value = "事件开始时间", index = 7)
    @ApiModelProperty("事件开始时间")
    private long eventSt;

    @ExcelProperty(value = "时间结束时间", index = 8)
    @ApiModelProperty("事件结束时间")
    private long eventEt;

    @ExcelProperty(value = "事件结果", index = 9)
    @ApiModelProperty("事件结果")
    private String eventResult;

    @ExcelProperty(value = "客户端IP", index = 10)
    @ApiModelProperty("客户端IP")
    private String clientIp;

}
