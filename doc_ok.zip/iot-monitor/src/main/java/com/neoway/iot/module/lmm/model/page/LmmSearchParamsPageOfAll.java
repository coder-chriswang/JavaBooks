package com.neoway.iot.module.lmm.model.page;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 分页-根据上报时间区间查询参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 16:07
 */
@Data
@ApiModel("位置轨迹查询参数")
public class LmmSearchParamsPageOfAll implements Serializable {
    private static final long serialVersionUID = -7708988652051539958L;

    @ApiModelProperty("开始时间")
    private long from;

    @ApiModelProperty("结束时间")
    private long to;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页行数")
    private Integer pageSize;

    @ApiModelProperty(value = "instanceId",required = true)
    private String instanceId;
}
