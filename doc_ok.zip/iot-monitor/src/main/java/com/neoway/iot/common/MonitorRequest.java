package com.neoway.iot.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 统一查询请求实参
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:20
 */
@Data
@ApiModel("统一查询请求实参")
public class MonitorRequest implements Serializable {
    private static final long serialVersionUID = 1988302573126118937L;

//    @ApiModelProperty("索引名称:简单索引(ARES_EM or ARES_LM)或是时间戳索引")
//    private String indexName;
//
//    @ApiModelProperty("索引类型:event或是location")
//    private String indexType;


}
