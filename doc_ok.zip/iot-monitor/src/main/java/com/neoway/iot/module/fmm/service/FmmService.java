package com.neoway.iot.module.fmm.service;


import com.neoway.iot.module.fmm.model.FmmCommand;
import com.neoway.iot.module.fmm.model.FmmMeta;
import com.neoway.iot.module.fmm.model.FmmModel;
import com.neoway.iot.module.fmm.model.page.FmmMetaSeachParams;
import com.neoway.iot.module.fmm.model.page.FmmSearchParamsPageOfAll;
import com.neoway.iot.util.MonitorPageModel;

import java.util.List;

/**
 * <pre>
 *  描述: 告警service
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:22
 */
public interface FmmService {

    /**
     * 查询告警信息
     * @param searchParams
     * @return
     */
    MonitorPageModel<FmmModel> queryForList(FmmSearchParamsPageOfAll searchParams);

    /**
     * 查询告警详情
     * @param instanceId
     * @param serialNo
     * @return
     */
    FmmModel queryForOne(String instanceId, long serialNo);

    /**
     * 查询静态告警数据
     * @return
     */
    List<FmmMeta> queryForMetas();

    /**
     * 查询静态告警数据详情
     * @param code
     * @return
     */
    FmmMeta queryForMetaForOne(long code);

    /**
     * 告警操作
     * @param fmmCommand
     */
    void dataCommand(FmmCommand fmmCommand);

    /**
     * 删除静态告警数据
     * @param code
     */
    void deleteMeta(long code);
}
