package com.neoway.iot.module.emm.mapper;

import com.neoway.iot.module.emm.model.EmmModel;
import com.neoway.iot.module.emm.model.page.EmmSearchParamsPageOfAll;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述: EMM管理Mapper
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:25
 */
@Mapper
public  interface EmmMapper {

    /**
     * 查询列表
     * @param tableName
     * @param emmSearchParamsPageOfAll
     * @return
     */
    List<EmmModel> findAll(@Param("tableName") String tableName, @Param("emmSearchParamsPageOfAll") EmmSearchParamsPageOfAll emmSearchParamsPageOfAll);

    /**
     * 根据事件No查询详情
     * @param eventNo
     * @param tableName
     * @return
     */
    EmmModel findByNo(@Param("tableName") String tableName, @Param("eventNo") long eventNo);
    /**
     * 根据设备ID查询列表
     * @param tableName
     * @param deviceId
     * @param timeType
     * @param from
     * @param to
     * @return
     */
    List<EmmModel> findAllByDeviceId(@Param("tableName") String tableName, @Param("deviceId") String deviceId, @Param("timeType") int timeType, @Param("from") long from, @Param("to") long to);

    /**
     * 根据instanceID查询列表
     * @param tableName
     * @param instanceId
     * @param timeType
     * @param from
     * @param to
     * @return
     */
    List<EmmModel> findAllByInstanceId(@Param("tableName") String tableName, @Param("instanceId") String instanceId, @Param("timeType") int timeType, @Param("from") long from, @Param("to") long to);

    /**
     * 根据产品域查询列表
     * @param tableName
     * @param ns
     * @param timeType
     * @param from
     * @param to
     * @return
     */
    List<EmmModel> findAllByNs(@Param("tableName") String tableName, @Param("ns") String ns, @Param("timeType") int timeType, @Param("from") long from, @Param("to") long to);
}
