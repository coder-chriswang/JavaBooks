package com.neoway.iot.module.pmm.domain;

import java.util.List;
import java.util.Map;

/**
 * @desc: PmDataRsp
 * @author: 20200312686
 * @date: 2020/7/30 14:37
 */
public class PmDataRsp {
    //指标
    private String metric;
    //标签
    private Map<String,Object> tags;
    //数据
    private Map<Integer,Float> dps;

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public Map<String, Object> getTags() {
        return tags;
    }

    public void setTags(Map<String, Object> tags) {
        this.tags = tags;
    }

    public Map<Integer, Float> getDps() {
        return dps;
    }

    public void setDps(Map<Integer, Float> dps) {
        this.dps = dps;
    }

    public static PmDataRsp buildRsp(List<Map<String,Object>> values){
        return null;
    }
}
