package com.neoway.iot.module.fmm.mapper;


import com.neoway.iot.module.fmm.model.FmmMeta;
import com.neoway.iot.module.fmm.model.FmmModel;
import com.neoway.iot.module.fmm.model.page.FmmSearchParamsPageOfAll;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述: 告警管理Mapper
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:25
 */
@Mapper
public  interface FmmMapper {

    /**
     * 查询活动告警数据
     * @param tableName
     * @param fmmSearchParamsPageOfAll
     * @return
     */
    List<FmmModel> queryFmmModels(@Param("tableName") String tableName, @Param("fmmSearchParamsPageOfAll") FmmSearchParamsPageOfAll fmmSearchParamsPageOfAll);

    /**
     * 查询告警详情
     * @param tableName
     * @param serialNo
     * @return
     */
    FmmModel queryForOne(@Param("tableName") String tableName, @Param("serialNo") long serialNo);

    /**
     * 查询静态告警数据
     * @return
     */
    List<FmmMeta> queryFmmMetas();

    /**
     * 查询静态告警数据详情
     * @param code
     * @return
     */
    FmmMeta queryMetaForOne(@Param("code") long code);

    /**
     * 清除告警信息
     * @param tableName
     * @param serialNo
     * @param status
     */
    void clearFmData(@Param("tableName") String tableName, @Param("serialNo") long serialNo, @Param("status") int status);

    /**
     * 删除告警静态数据
     * @param code
     */
    void deleteMeta(@Param("code") long code);
}
