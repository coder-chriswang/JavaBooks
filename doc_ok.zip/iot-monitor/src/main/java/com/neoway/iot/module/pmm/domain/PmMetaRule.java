package com.neoway.iot.module.pmm.domain;

import io.swagger.annotations.ApiModelProperty;

/**
 * @desc: 阈值规则
 * @author: 20200312686
 * @date: 2020/7/30 14:08
 */
public class PmMetaRule {
    //指标编码
    @ApiModelProperty(value = "指标编码")
    private int code;
    //发生检测周期
    @ApiModelProperty(value = "检测周期")
    private int oPeriod;
    @ApiModelProperty(value = "阈值")
    private int oThreahold;
    //触发动作
    @ApiModelProperty(value = "触发动作")
    private String oAction;
    //关闭检测周期
    @ApiModelProperty(value = "恢复检测周期")
    private int cPeriod;
    //关闭阈值门限
    @ApiModelProperty(value = "恢复阈值")
    private int cThreahold;
    //关闭触发动作
    @ApiModelProperty(value = "恢复触发动作")
    private String cAction;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getoPeriod() {
        return oPeriod;
    }

    public void setoPeriod(int oPeriod) {
        this.oPeriod = oPeriod;
    }

    public int getoThreahold() {
        return oThreahold;
    }

    public void setoThreahold(int oThreahold) {
        this.oThreahold = oThreahold;
    }

    public String getoAction() {
        return oAction;
    }

    public void setoAction(String oAction) {
        this.oAction = oAction;
    }

    public int getcPeriod() {
        return cPeriod;
    }

    public void setcPeriod(int cPeriod) {
        this.cPeriod = cPeriod;
    }

    public int getcThreahold() {
        return cThreahold;
    }

    public void setcThreahold(int cThreahold) {
        this.cThreahold = cThreahold;
    }

    public String getcAction() {
        return cAction;
    }

    public void setcAction(String cAction) {
        this.cAction = cAction;
    }
}
