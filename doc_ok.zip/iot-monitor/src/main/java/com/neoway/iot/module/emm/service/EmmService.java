package com.neoway.iot.module.emm.service;

import com.neoway.iot.module.emm.model.EmmModel;
import com.neoway.iot.module.emm.model.page.EmmSearchParamsPageOfAll;
import com.neoway.iot.util.MonitorPageModel;

import javax.servlet.http.HttpServletResponse;

/**
 * <pre>
 *  描述:EmmService
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:22
 */
public interface EmmService {

    /**
     * 查询返回列表
     * @param emmSearchParamsPageOfAll
     * @return
     */
    MonitorPageModel<EmmModel> queryForList(EmmSearchParamsPageOfAll emmSearchParamsPageOfAll);

    /**
     * 根据事件No查询详情
     * @param instanceId
     * @param eventNo
     * @return
     */
    EmmModel queryForOne(String instanceId, long eventNo);

    /**
     * 导出事件数据
     * @param searchCondition
     * @param response
     */
    void exportExcel(EmmSearchParamsPageOfAll searchCondition, HttpServletResponse response);
}
