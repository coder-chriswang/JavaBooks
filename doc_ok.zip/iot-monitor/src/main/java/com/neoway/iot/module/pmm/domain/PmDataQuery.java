package com.neoway.iot.module.pmm.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @desc: 监控数据查询条件。语义与opentsdb一致（opentsdb的query接口的裁剪版）
 * @author: 20200312686
 * @date: 2020/7/30 14:23
 */
@ApiModel("监控数据查询结构")
public class PmDataQuery {
    @ApiModelProperty(value = "查询起始时间",required = true)
    private int st;
    @ApiModelProperty(value = "查询结束时间",required = true)
    private int et;
    @ApiModelProperty(value = "子查询结构",required = true)
    private List<PmDataQuerySub> queries;

    public int getSt() {
        return st;
    }

    public void setSt(int st) {
        this.st = st;
    }

    public int getEt() {
        return et;
    }

    public void setEt(int et) {
        this.et = et;
    }

    public List<PmDataQuerySub> getQueries() {
        return queries;
    }

    public void setQueries(List<PmDataQuerySub> queries) {
        this.queries = queries;
    }
}
