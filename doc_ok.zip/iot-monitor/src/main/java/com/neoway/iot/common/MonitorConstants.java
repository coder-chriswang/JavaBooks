package com.neoway.iot.common;

import org.apache.commons.lang3.StringUtils;

/**
 * <pre>
 *  描述: Monitor常量集合
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/15 9:45
 */
public interface MonitorConstants {

    /**
     * EM 表名前缀
     */
    String EM_TABLE_NAME_PREFIX = "EM_VALUE";

    /**
     * FM 表名前缀
     */
    String FM_TABLE_NAME_PREFIX = "FM_VALUE";

    /**
     * LM 表名前缀
     */
    String LM_TABLE_NAME_PREFIX = "LM_VALUE";

    /**
     * PM 表名前缀
     */
    String PM_TABLE_NAME_PREFIX = "PM_VALUE";

    /**
     * 告警清除
     */
    String FM_CLAER = "Clear";

    /**
     * 告警转单
     */
    String FM_TRANSPORT = "Transport";

    /**
     * 告警重置
     */
    String FM_RESET = "Reset";

    /**
     * 告警挂起
     */
    String FM_Pend = "Pend";

    /**
     * 并行任务超时时间
     */
    long CONCURRENT_EXECUTOR_TIME_OUT = 2000;

    enum FmmCommandEnum {
        CLEAR("Clear","手动清除"),
        TRANSPORT("Transport","转单"),
        RESET("Reset","重置"),
        PEND("Pend","挂起"),
        ;

        FmmCommandEnum(String action, String desc) {
            this.action = action;
            this.desc = desc;
        }

        private String action;
        private String desc;

        public String getAction() {
            return action;
        }

        public String getDesc() {
            return desc;
        }

        /**
         * 获取desc
         * @param action key
         * @return desc
         */
        public static String getDescByAction(String action) {
            if (StringUtils.isEmpty(action)) {
                return "";
            }
            for (FmmCommandEnum t : FmmCommandEnum.values()) {
                if (action.equals(t.getAction())) {
                    return t.getDesc();
                }
            }
            return "";
        }
        /**
         * action是否存在
         * @param action
         * @return
         */
        public static boolean include(String action) {
            if(StringUtils.isEmpty(action)) {
                return false;
            }
            for (FmmCommandEnum t : FmmCommandEnum.values()) {
                if (t.getAction().equals(action)) {
                    return true;
                }
            }
            return false;
        }
    }

    enum FmmDataStatusEnum {
        PROCESSING(1,"告警产生中"),
        CLEARED(2,"告警已经清除"),
        ;

        FmmDataStatusEnum(int status, String desc) {
            this.status = status;
            this.desc = desc;
        }

        private int status;
        private String desc;

        public int getStatus() {
            return status;
        }

        public String getDesc() {
            return desc;
        }
    }

}
