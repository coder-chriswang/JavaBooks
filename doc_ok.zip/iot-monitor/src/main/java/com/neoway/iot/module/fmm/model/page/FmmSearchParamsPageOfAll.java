package com.neoway.iot.module.fmm.model.page;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 动态告警查询参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/30 20:01
 */
@Data
@ApiModel("动态告警查询参数")
public class FmmSearchParamsPageOfAll implements Serializable {
    private static final long serialVersionUID = 6092317010514039989L;

    @ApiModelProperty("告警ID")
    private String alarmId;

    @ApiModelProperty(value = "instanceId",required = true)
    private String instanceId;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页行数")
    private Integer pageSize;

    @ApiModelProperty("时间条件类别，默认为0，选择发生置1，选择结束置2")
    private Integer timeType;

    @ApiModelProperty("开始时间")
    private long from;

    @ApiModelProperty("结束时间")
    private long to;

    @ApiModelProperty("资源CI")
    private String ci;

    @ApiModelProperty("告警等级(Major,Normal)")
    private String alarmSeverity;

    @ApiModelProperty("告警类别(OM,Device)")
    private String alarmCategory;

    @ApiModelProperty("告警来源(Device,Platform)")
    private String alarmSource;

    @ApiModelProperty("告警状态")
    private Integer alarmStatus;
}
