package com.neoway.iot.util;

import com.google.common.collect.Lists;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * <pre>
 *  描述: 基于Guava分页工具
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 13:54
 */
public class MonitorPageHelper {

    public static <T> MonitorPageModel<T> pagination(final List<T> data, final int pageSize, final int pageNum) {
        if (CollectionUtils.isEmpty(data)) {
            return new MonitorPageModel<>();
        }
        List<List<T>> lists = Lists.partition(data, pageSize);
        int localPageNum = pageNum;
        if (localPageNum > lists.size()) {
            localPageNum = lists.size();
        }
        return MonitorPageModel.build(lists.get(localPageNum - 1), pageNum, data.size(), pageSize);
    }
}
