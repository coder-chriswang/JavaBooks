package com.neoway.iot.module.pmm.mapper;

import com.neoway.iot.module.pmm.domain.PmDataQuerySub;
import com.neoway.iot.module.pmm.domain.PmMetaMetric;
import com.neoway.iot.module.pmm.domain.PmMetaRule;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @desc: PmmMapper
 * @author: 20200312686
 * @date: 2020/7/30 18:42
 */
@Mapper
public interface PmmMapper {
    /**
     * 查询元数据列表
     * @return
     */
    List<PmMetaMetric> queryMetas(@Param("start") int start, @Param("limit") int limit,@Param("metaMetric") PmMetaMetric metaMetric);

    /**
     * @desc 查询元数据详情
     * @param code
     * @return
     */
    PmMetaMetric getMeta(@Param("code") String code);

    /**
     * @desc 查询阈值规则
     * @param code
     * @return
     */
    PmMetaRule getMetaRule(@Param("code") String code);

    /**
     * @desc 配置阈值规则
     * @param metaRule
     */
    void writeMetaRule(@Param("metaRule") PmMetaRule metaRule);

    /**
     * @desc 删除阈值规则
     * @param code
     */
    void deleteMetaRule(@Param("code") String code);

    /**
     * @desc 通用查询
     * @param querySub
     * @return
     */
    List<Map<String,Object>> commonQuery(@Param("querySub")PmDataQuerySub querySub);

    /**
     * 评估数据量
     * @param instanceid
     * @param st
     * @param et
     * @return
     */
    int getTsdCount(@Param("tableName") String tableName,@Param("instanceid") long instanceid,@Param("st") int st,@Param("et") int et);

}
