package com.neoway.iot.util;

import java.util.Collections;
import java.util.List;

/**
 * <pre>
 *  描述: Monitor内存分页
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 13:45
 */
public class MonitorPageUtil<T> {

    /**
     * 每页显示条数
     */
    private int pageSize;

    /**
     * 总页数
     */
    private int totalPage;

    /**
     * 集合
     */
    private List<T> data;

    public MonitorPageUtil(List<T> data, int pageSize) {
        if (data == null || data.isEmpty()) {
            throw new IllegalArgumentException("数据为空!");
        }
        this.data = data;
        this.pageSize = pageSize;
        this.totalPage = data.size() / pageSize;
        if(data.size() % pageSize != 0) {
            this.totalPage++;
        }
    }

    public MonitorPageUtil(List<T> data, int pageSize, int pageNum) {
        if (data == null || data.isEmpty()) {
            throw new IllegalArgumentException("数据为空!");
        }
        this.pageSize = pageSize;
        this.totalPage = data.size() / pageSize;
        if(data.size() % pageSize != 0) {
            this.totalPage++;
        }
        int fromIndex = (pageNum - 1) * pageSize;
        if (fromIndex >= data.size()) {
            this.data = null;
        }
        int toIndex = pageNum * pageSize;
        if (toIndex >= data.size()) {
            toIndex = data.size();
        }
        this.data = data.subList(fromIndex, toIndex);
    }

    /**
     * 得到分页后的数据
     *
     * @param pageNum 当前页
     * @return 分页后结果
     */
    public List<T> getPagedList(int pageNum) {
        int fromIndex = (pageNum - 1) * pageSize;
        if (fromIndex >= data.size()) {
            return Collections.emptyList();
        }

        int toIndex = pageNum * pageSize;
        if (toIndex >= data.size()) {
            toIndex = data.size();
        }
        return data.subList(fromIndex, toIndex);
    }

    public int getPageSize() {
        return pageSize;
    }

    public List<T> getData() {
        return data;
    }

    public int getTotalPage() {
        return totalPage;
    }
}
