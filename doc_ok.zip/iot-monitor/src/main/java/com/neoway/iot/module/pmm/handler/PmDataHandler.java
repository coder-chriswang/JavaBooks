package com.neoway.iot.module.pmm.handler;

import com.google.common.base.Charsets;
import com.google.common.hash.Hashing;
import com.neoway.iot.module.pmm.domain.PmDataQuery;
import com.neoway.iot.module.pmm.domain.PmDataQuerySub;
import com.neoway.iot.module.pmm.domain.PmDataRsp;
import com.neoway.iot.module.pmm.mapper.PmmMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: PmDataHandler
 * @author: 20200312686
 * @date: 2020/7/31 12:46
 */
@Service
public class PmDataHandler {
    private static final String TABLE_NAME = "PM_VALUE";
    @Value("${pmm.mysql.table.count}")
    private String tableCount;
    @Autowired
    private PmmMapper pmmMapper;

    private static final Logger LOG = LoggerFactory.getLogger(PmDataHandler.class);
    public List<PmDataRsp> query(PmDataQuery query){
        if(null == query){
            throw new RuntimeException("参数错误");
        }
        List<PmDataQuerySub> subQuerys=query.getQueries();
        if(CollectionUtils.isEmpty(subQuerys)){
            throw new RuntimeException("参数错误:子查询不能为空");
        }
        List<PmDataRsp> rsps=new ArrayList<>();
        for(PmDataQuerySub subQuery:query.getQueries()){
            List<Map<String,Object>> values=pmmMapper.commonQuery(subQuery);
            PmDataRsp rsp=PmDataRsp.buildRsp(values);
            rsps.add(rsp);
        }
        return rsps;
    }

    private void fillParam(PmDataQuery query){
        for(PmDataQuerySub subQuery:query.getQueries()){
            subQuery.setStart(query.getSt());
            subQuery.setEnd(query.getEt());
            String table=getTable(String.valueOf(subQuery.getInstanceid()));
            int preCount=pmmMapper.getTsdCount(
                    table,
                    subQuery.getInstanceid(),
                    subQuery.getStart(),
                    subQuery.getEnd()
            );
            subQuery.buildDownInterval(preCount);

        }
    }
    /**
     * @desc 定位数据表
     * @param instanceid
     * @return
     */
    private String getTable(String instanceid){
        int partition= Integer.valueOf(this.tableCount);
        int bucket= Hashing.consistentHash(Hashing.md5().hashString(instanceid, Charsets.UTF_8),partition);
        String table=TABLE_NAME+"_"+bucket;
        return table;
    }
}
