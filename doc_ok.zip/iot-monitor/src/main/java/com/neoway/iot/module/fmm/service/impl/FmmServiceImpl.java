package com.neoway.iot.module.fmm.service.impl;

import com.neoway.iot.common.MonitorException;
import com.neoway.iot.module.fmm.mapper.FmmMapper;
import com.neoway.iot.module.fmm.model.FmmCommand;
import com.neoway.iot.module.fmm.model.FmmCommandItem;
import com.neoway.iot.module.fmm.model.FmmMeta;
import com.neoway.iot.module.fmm.model.FmmModel;
import com.neoway.iot.module.fmm.model.page.FmmSearchParamsPageOfAll;
import com.neoway.iot.module.fmm.service.FmmService;
import com.neoway.iot.util.MonitorCommonUtils;
import com.neoway.iot.util.MonitorPageHelper;
import com.neoway.iot.util.MonitorPageModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.neoway.iot.common.MonitorConstants.*;

/**
 * <pre>
 *  描述: 告警service实现类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:22
 */
@Service
@Slf4j
public class FmmServiceImpl implements FmmService {

    @Value("${fmm.mysql.table.count}")
    private String fmmTableCount;

    @Autowired
    private FmmMapper fmmMapper;

    @Override
    public MonitorPageModel<FmmModel> queryForList(FmmSearchParamsPageOfAll searchParams) {
        try {
            String tableName = MonitorCommonUtils.getTableTable(searchParams.getInstanceId(), Integer.valueOf(fmmTableCount), FM_TABLE_NAME_PREFIX);
            return MonitorPageHelper.pagination(fmmMapper.queryFmmModels(tableName, searchParams), searchParams.getPageSize(), searchParams.getPageNum());
        } catch (Exception e) {
            log.error("查询告警数据失败！", e);
            throw new MonitorException("查询告警数据失败！");
        }
    }

    @Override
    public FmmModel queryForOne(String instanceId, long serialNo) {
        try {
            String tableName = MonitorCommonUtils.getTableTable(instanceId, Integer.valueOf(fmmTableCount), FM_TABLE_NAME_PREFIX);
            return fmmMapper.queryForOne(tableName, serialNo);
        } catch (Exception e) {
            log.error("查询告警详情失败！", e);
            throw new MonitorException("查询告警详情失败！");
        }
    }

    @Override
    public List<FmmMeta> queryForMetas() {
        try {
            return fmmMapper.queryFmmMetas();
        } catch (Exception e) {
            log.error("查询静态告警数据失败！", e);
            throw new MonitorException("查询静态告警数据失败！");
        }
    }

    @Override
    public FmmMeta queryForMetaForOne(long code) {
        try {
            return fmmMapper.queryMetaForOne(code);
        } catch (Exception e) {
            log.error("查询静态告警详情失败！", e);
            throw new MonitorException("查询静态告警详情失败！");
        }
    }

    @Override
    public void dataCommand(FmmCommand fmmCommand) {
        List<FmmCommandItem> items = fmmCommand.getItems();
        try {
            for (FmmCommandItem item : items) {
                String tableName = MonitorCommonUtils.getTableTable(item.getInstanceId(),Integer.valueOf(fmmTableCount),FM_TABLE_NAME_PREFIX);
                switch (fmmCommand.getAction()) {
                    case FM_CLAER:
                        log.info("告警清除！");
                        fmmMapper.clearFmData(tableName, item.getSerialNo(), FmmDataStatusEnum.CLEARED.getStatus());
                        break;
                    // TODO 其他指令操作相关业务
                    default:
                        log.info("其他");
                        break;
                }
            }
        } catch (Exception e) {
            log.error("告警操作失败！", e);
            throw new MonitorException("告警操作失败！");
        }
    }

    @Override
    public void deleteMeta(long code) {
        try {
            fmmMapper.deleteMeta(code);
        } catch (Exception e) {
            log.error("删除静态告警数据失败！", e);
        }
    }
}
