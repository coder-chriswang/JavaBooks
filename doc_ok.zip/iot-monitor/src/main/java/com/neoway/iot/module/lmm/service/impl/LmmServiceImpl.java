package com.neoway.iot.module.lmm.service.impl;


import com.neoway.iot.common.MonitorException;
import com.neoway.iot.module.lmm.mapper.LmmMapper;
import com.neoway.iot.module.lmm.model.LmmModel;
import com.neoway.iot.module.lmm.model.page.LmmSearchParamsPageOfAll;
import com.neoway.iot.module.lmm.service.LmmService;
import com.neoway.iot.util.MonitorCommonUtils;
import com.neoway.iot.util.MonitorPageHelper;
import com.neoway.iot.util.MonitorPageModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static com.neoway.iot.common.MonitorConstants.LM_TABLE_NAME_PREFIX;

/**
 * <pre>
 *  描述: LmmServiceImpl
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:22
 */
@Service
@Slf4j
public class LmmServiceImpl implements LmmService {
    @Value("${lmm.mysql.table.count}")
    private String lmmTableCount;

    @Autowired
    private LmmMapper lmmMapper;

    @Override
    public MonitorPageModel<LmmModel> queryForList(LmmSearchParamsPageOfAll lmmSearchParamsPageOfAll) {
        try {
            String tableName = MonitorCommonUtils.getTableTable(lmmSearchParamsPageOfAll.getInstanceId(), Integer.valueOf(lmmTableCount), LM_TABLE_NAME_PREFIX);
            return MonitorPageHelper.pagination(lmmMapper.findAll(tableName, lmmSearchParamsPageOfAll.getFrom(), lmmSearchParamsPageOfAll.getTo()), lmmSearchParamsPageOfAll.getPageSize(), lmmSearchParamsPageOfAll.getPageNum());
        } catch (Exception e) {
            log.error("查询位置轨迹信息失败！", e);
            throw new MonitorException("查询位置轨迹信息失败！");
        }
    }
}
