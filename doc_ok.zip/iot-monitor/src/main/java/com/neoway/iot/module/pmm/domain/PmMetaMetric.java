package com.neoway.iot.module.pmm.domain;

import io.swagger.annotations.ApiModelProperty;


/**
 * @desc: PmMetaMetric
 * @author: 20200312686
 * @date: 2020/7/30 13:47
 */
public class PmMetaMetric {
    //五中度量类型
    //只有一个返回值，用来记录一些对象的瞬时值，例如某个服务目前开通的城市个数
    private static final String METRIC_TYPE_GAUGES="gauges";
    //计数器，可以增加或减少
    private static final String METRIC_TYPE_COUNTERS="counters";
    //只能自增的计数器，通常用来度量一系列事件发生的比率。例如统计每分钟内多少次请求
    private static final String METRIC_TYPE_METERS="meters";
    //用来度量流数据中value的分布情况，可以计算最大值、最小值、平均值、方差、分位数。
    private static final String METRIC_TYPE_HISTOGRAMS="histograms";
    //计时器，是histograms和meter的组合。典型使用场景：请求时延、磁盘读时延
    private static final String METRIC_TYPE_TIMERS="timers";

    private static final String SPILITE="#";
    //产品域
    @ApiModelProperty(value = "产品域")
    private String ns;
    //对象类型
    @ApiModelProperty(value = "资源类型")
    private String ci;
    //指标
    @ApiModelProperty(hidden = true)
    private String metric;
    //指标组
    @ApiModelProperty(hidden = true)
    private String group;
    //指标组名称
    @ApiModelProperty(hidden = true)
    private String groupName;
    //指标名称
    @ApiModelProperty(hidden = true)
    private String metricName;
    //指标显示类型
    @ApiModelProperty(hidden = true)
    private String type;
    //指标单位
    @ApiModelProperty(hidden = true)
    private String unit;
    //指标描述
    @ApiModelProperty(hidden = true)
    private String desc;
    //指标编码
    @ApiModelProperty(hidden = true)
    private int code;

    public PmMetaMetric() {
    }

    public PmMetaMetric(String metric) {
        this.metric = metric;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public String getMetricName() {
        return metricName;
    }

    public void setMetricName(String metricName) {
        this.metricName = metricName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
