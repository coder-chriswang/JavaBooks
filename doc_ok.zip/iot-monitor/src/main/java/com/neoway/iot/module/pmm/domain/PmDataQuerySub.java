package com.neoway.iot.module.pmm.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


/**
 * @desc: PmDataQuerySub
 * @author: 20200312686
 * @date: 2020/7/30 14:26
 */
@ApiModel("监控数据子查询结构")
public class PmDataQuerySub {
    @ApiModelProperty(value = "指标编码",required = true)
    private String metric;
    @ApiModelProperty(value = "资源ID",hidden = true)
    private long instanceid;

    @ApiModelProperty(value = "起始时间",hidden = true)
    private int start;
    @ApiModelProperty(value = "结束时间",hidden = true)
    private int end;
    @ApiModelProperty(value = "下采样间隔",hidden = true)
    private int downInterval;
    @ApiModelProperty(value = "下采样聚合方式",hidden = true)
    private String downAgg= "avg";

    public int getDownInterval() {
        return downInterval;
    }

    public void setDownInterval(int downInterval) {
        this.downInterval = downInterval;
    }

    public long getInstanceid() {
        return instanceid;
    }

    public void setInstanceid(long instanceid) {
        this.instanceid = instanceid;
    }

    public String getDownAgg() {
        return downAgg;
    }

    public void setDownAgg(String downAgg) {
        this.downAgg = downAgg;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getEnd() {
        return end;
    }

    public void setEnd(int end) {
        this.end = end;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public void buildDownInterval(int count){

    }
}
