package com.neoway.iot.util;

import com.neoway.iot.common.MonitorException;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * <pre>
 *  描述: Monitor并行执行器
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 13:13
 */
public class MonitorConcurrentExecutor {
    private static ThreadPoolTaskExecutor threadPoolTaskExecutor;

    static {
        threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        threadPoolTaskExecutor.setCorePoolSize(5);
        threadPoolTaskExecutor.setMaxPoolSize(10);
        threadPoolTaskExecutor.setQueueCapacity(50);
        threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        threadPoolTaskExecutor.setThreadNamePrefix("XMMExecutor-");
        threadPoolTaskExecutor.initialize();
    }
    /**
     * 执行一组有返回值的任务
     *
     * @param callableList
     * @param <T> 任务列表
     * @param timeout 任务超时时间，单位毫秒
     * @param threadPoolExecutor 构造executor
     * @return
     */
    public static <T> List<T> execute(List<Callable<T>> callableList, long timeout, ThreadPoolTaskExecutor threadPoolExecutor) {
        if (callableList == null || callableList.isEmpty()) {
            return null;
        }
        List<T> resultList = new ArrayList<>();
        List<Future<T>> futureList = new ArrayList<>();
        for (Callable<T> callable : callableList) {
            Future<T> future = threadPoolExecutor.submit(callable);
            futureList.add(future);
        }
        for (Future<T> future : futureList) {
            try {
                T result = future.get(timeout, TimeUnit.MILLISECONDS);
                if (result != null) {
                    resultList.add(result);
                }
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                e.printStackTrace();
                throw new MonitorException("多线程执行异常");
            }
        }
        return resultList;
    }

    /**
     * 执行一组有返回值的任务
     * @param callableList 任务列表
     * @param timeout 任务超时时间，单位毫秒
     * @param <T>
     * @return
     */
    public static <T> List<T> execute(List<Callable<T>> callableList, long timeout) {
        if (callableList == null || callableList.isEmpty()) {
            return null;
        }
        List<T> resultList = new ArrayList<>();
        List<Future<T>> futureList = new ArrayList<>();
        for (Callable<T> callable : callableList) {
            Future<T> future = threadPoolTaskExecutor.submit(callable);
            futureList.add(future);
        }
        for (Future<T> future : futureList) {
            try {
                T result = future.get(timeout, TimeUnit.MILLISECONDS);
                if (result != null) {
                    resultList.add(result);
                }
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                e.printStackTrace();
                throw new MonitorException("多线程执行异常");
            }
        }
        return resultList;
    }

    /**
     * 执行一组没有返回值的任务
     *
     * @param runnableList 任务列表
     * @param timeout 任务超时时间，单位毫秒
     */
    public static void submit(List<Runnable> runnableList, long timeout, ThreadPoolTaskExecutor threadPoolTaskExecutor) {
        if (runnableList == null || runnableList.isEmpty()) {
            return;
        }
        List<Future<?>> futureList = new ArrayList<>();
        for (Runnable runnable : runnableList) {
            Future future = threadPoolTaskExecutor.submit(runnable);
        }
        for (Future<?> future : futureList) {
            try {
                future.get(timeout, TimeUnit.MILLISECONDS);
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                e.printStackTrace();
                throw new MonitorException("多线程执行异常");
            }
        }
    }
}
