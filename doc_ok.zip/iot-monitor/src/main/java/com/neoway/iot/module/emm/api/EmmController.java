package com.neoway.iot.module.emm.api;

import com.neoway.iot.common.HttpResult;
import com.neoway.iot.common.MonitorException;
import com.neoway.iot.module.emm.model.EmmModel;
import com.neoway.iot.module.emm.model.page.EmmSearchParamsPageOfAll;
import com.neoway.iot.module.emm.service.EmmService;
import com.neoway.iot.util.MonitorPageModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

/**
 * <pre>
 *  描述: 事件查询REST接口
 *  1、第一阶段，按照具体查询方式输出数据
 *  2、第二阶段，整合ES API模式，统一通用调用接口，此部分需要抽象OUTPUT data模型，涉及业务对象整合
 *  3、或者，后续各业务查询，封装ES API
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:20
 */
@RestController
@RequestMapping("/v1/em")
@Slf4j
@Api(tags = "事件" , description = "事件管理接口：数据查询")
public class EmmController {
    @Autowired
    private EmmService emmService;

    @ApiOperation("查询事件数据")
    @PostMapping("/data")
    public HttpResult<MonitorPageModel<EmmModel>> queryPageForList(@RequestBody EmmSearchParamsPageOfAll emmSearchParamsPageOfAll) {
        try {
            if (emmSearchParamsPageOfAll == null
                    || StringUtils.isEmpty(emmSearchParamsPageOfAll.getInstanceId())
                    || emmSearchParamsPageOfAll.getTimeType() == null
                    || emmSearchParamsPageOfAll.getTimeType() < 0
                    || emmSearchParamsPageOfAll.getPageNum() == null
                    || emmSearchParamsPageOfAll.getPageSize() == null) {
                return HttpResult.returnFail("参数存在问题！");
            }
            return HttpResult.returnSuccess(emmService.queryForList(emmSearchParamsPageOfAll));
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("事件详情查询")
    @GetMapping("/data/{instanceId}/{evenNo}")
    public HttpResult<EmmModel> queryForOne(@PathVariable("instanceId") String instanceId, @PathVariable("evenNo") long evenNo) {
        try {
            EmmModel emmModel = emmService.queryForOne(instanceId, evenNo);
            if (emmModel == null) {
                return HttpResult.returnSuccess("暂无数据！", null);
            }
            return HttpResult.returnSuccess(emmModel);
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("导出数据")
    @PostMapping("/export")
    public void exportData(@RequestBody EmmSearchParamsPageOfAll searchCondition, HttpServletResponse response) {
        emmService.exportExcel(searchCondition, response);
    }

}
