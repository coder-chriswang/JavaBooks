package com.neoway.iot.manager.model.common.fdfs;

import org.springframework.web.multipart.MultipartFile;

/**
 * <pre>
 *  描述: FastDfs操作客户端
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 12:36
 */

public interface FdfsClient {

    String saveFile(MultipartFile multipartFile) throws Exception;

    void deleteFile(String url) throws Exception;

    byte[] downFile(String fileUrl) throws Exception;
}

