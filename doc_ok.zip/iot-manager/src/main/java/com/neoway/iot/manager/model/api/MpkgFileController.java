package com.neoway.iot.manager.model.api;

import com.neoway.iot.manager.common.HttpResult;
import com.neoway.iot.manager.model.bean.MpkgFile;
import com.neoway.iot.manager.model.common.ModelException;
import com.neoway.iot.manager.model.service.MpkgFileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <pre>
 *  描述: 模型包文件操作接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 16:59
 */
@RestController
@RequestMapping("/v1/mpkg")
@Api(tags = "模型包管理", description = "模型包管理")
public class MpkgFileController {

    @Autowired
    private MpkgFileService mpkgFileService;

    @ApiOperation("上传模型包")
    @PostMapping("/upload")
    public HttpResult<MpkgFile> upload(@RequestParam("file") MultipartFile file) {
        try {
            return HttpResult.returnSuccess(mpkgFileService.upload(file));
        } catch (ModelException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("下载模型包")
    @GetMapping("/download")
    public void download(@RequestParam("fileUrl") String fileUrl, HttpServletResponse response) {
        mpkgFileService.download(fileUrl, response);
    }

    @ApiOperation("卸载模型包")
    @GetMapping("/uninstall")
    public HttpResult uninstall(@RequestParam("fileUrl") String fileUrl){
        try {
            mpkgFileService.uninstall(fileUrl);
            return HttpResult.returnSuccess();
        } catch (Exception e) {
            return HttpResult.returnFail("卸载模型包文件失败！");
        }

    }

    @ApiOperation("批量卸载模型包")
    @PostMapping("/batchUninstall")
    public HttpResult batchUninstall(@RequestBody List<MpkgFile> files) {
        try {
            mpkgFileService.batchUninstall(files);
            return HttpResult.returnSuccess();
        } catch (Exception e) {
            return HttpResult.returnFail("批量卸载模型包文件失败！");
        }
    }

    @ApiOperation("批量加载模型包")
    @PostMapping("/batchInstall")
    public HttpResult batchInstall(@RequestBody List<MpkgFile> files) {
        try {
            mpkgFileService.batchInstall(files);
            return HttpResult.returnSuccess("批量加载模型包文件成功！");
        } catch (Exception e){
            return HttpResult.returnFail("批量加载模型包文件失败！");
        }
    }


}
