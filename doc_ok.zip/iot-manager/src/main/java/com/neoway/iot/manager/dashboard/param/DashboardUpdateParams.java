package com.neoway.iot.manager.dashboard.param;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * <pre>
 *  描述: 更新Dashboard视图入参
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/19 15:19
 */
@Data
@ApiModel("更新Dashboard视图入参")
public class DashboardUpdateParams implements Serializable {
    private static final long serialVersionUID = -884935163375863480L;

    @NotBlank(message = "code不能为空")
    @ApiModelProperty("视图编码")
    private String code;

    @NotBlank(message = "name不能为空")
    @ApiModelProperty("视图名称")
    private String name;

    @ApiModelProperty("描述")
    private String desc;

    @NotEmpty(message = "chart不能为空")
    @ApiModelProperty("chart信息")
    private JSONObject chart;
}
