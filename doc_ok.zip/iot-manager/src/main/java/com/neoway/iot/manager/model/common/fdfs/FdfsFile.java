package com.neoway.iot.manager.model.common.fdfs;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: FastDfs文件封装
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 12:36
 */
@Data
public class FdfsFile implements Serializable {
    private static final long serialVersionUID = 8193645600770514703L;

    private String name;

    private byte[] content;

    private String ext;

    private String md5;

    private String author;

    public FdfsFile(String name, byte[] content, String ext) {
        super();
        this.name = name;
        this.content = content;
        this.ext = ext;
    }

    public FdfsFile() {
        super();
    }
}
