package com.neoway.iot.manager.common.handler;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * <pre>
 *  描述: mybatis Json类型处理工具
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/19 14:01
 */
@Slf4j
public class JSONHandler<T> extends BaseTypeHandler {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private Class<T> clazz;

    static {
        MAPPER.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    public JSONHandler(Class<T> clazz) {
        if (clazz == null) {
            throw new NullPointerException("Type argument cannot be null");
        }
        this.clazz = clazz;
    }

    /**
     * object转jsonString
     * @param object
     * @return
     */
    private String toJSONString(Object object) {
        try {
            String string = MAPPER.writeValueAsString(object);
            log.info("json handler string:{}", string);
            return string;
        } catch (Exception e) {
            log.error("convert object to json string failed, error message: ", e.getMessage());
        }
        return null;
    }

    private T toObject(String json, Class<T> clazz) throws JsonProcessingException {
        if (json != null && json !="") {
            return MAPPER.readValue(json, clazz);
        }
        return null;
    }


    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, Object o, JdbcType jdbcType) throws SQLException {
        try {
            preparedStatement.setString(i, toJSONString(o));
        } catch (Exception e) {
            log.error("preparedStatement set string failed, error message:{}", e.getMessage());
        }
    }

    @Override
    public Object getNullableResult(ResultSet resultSet, String s) throws SQLException {
        try {
            return toObject(resultSet.getString(s), clazz);
        } catch (Exception e) {
            log.error("convert son string to object failed, error message:{}", e.getMessage());
        }
        return null;
    }

    @Override
    public Object getNullableResult(ResultSet resultSet, int i) throws SQLException {
        try {
            return toObject(resultSet.getString(i), clazz);
        } catch (Exception e) {
            log.error("convert son string to object failed, error message:{}", e.getMessage());
        }
        return null;
    }

    @Override
    public Object getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        try {
            return toObject(callableStatement.getString(i), clazz);
        } catch (Exception e) {
            log.error("convert son string to object failed, error message:{}", e.getMessage());
        }
        return null;
    }
}
