package com.neoway.iot.manager.i18n.api;

import com.neoway.iot.manager.common.HttpResult;
import com.neoway.iot.manager.i18n.service.I18nService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @desc: I18nController
 * @author: 20200312686
 * @date: 2020/8/3 14:59
 */

@Slf4j
@RestController
@RequestMapping("/v1/i18n")
@Api(tags = "国际化",description = "国际化词条管理接口")
public class I18nController {


    @Autowired
    private I18nService i18nServiceImpl;


    @ApiOperation("词条查询接口")
    @GetMapping("")
    public HttpResult<Map<String,Map<String,String>>> queryI18n(@RequestParam(value="enable", defaultValue = "") String enable,
                                     @RequestHeader(value = "lang", defaultValue = "zh_CN") String language) {
        try{
            return HttpResult.returnSuccess(i18nServiceImpl.queryI18n(language, enable));
        }catch (Exception e){
            log.error(e.getMessage(),e);
            return HttpResult.returnFail("查询失败！");
        }

    }
}
