package com.neoway.iot.manager.i18n.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @desc: i18n
 * @author: 20200312686
 * @date: 2020/8/3 15:04
 */
@Data
@ApiModel("国际化词条结构")
public class I18n implements Serializable {
    private static final long serialVersionUID = -3426823299752581870L;

    @ApiModelProperty(value = "产品域")
    private String ns;

    @ApiModelProperty(value = "语言")
    private String lan;

    @ApiModelProperty(value = "词条Key")
    private String k;

    @ApiModelProperty(value = "词条Value")
    private String v;

    @ApiModelProperty(value = "使能点(前端=f、后端=b)", required = true)
    private String enable;

    @ApiModelProperty(value = "更新时间")
    private long updateTs;

}
