package com.neoway.iot.manager.dashboard.service;

import com.neoway.iot.manager.dashboard.bean.Dashboard;
import com.neoway.iot.manager.dashboard.param.DashboardAddParams;
import com.neoway.iot.manager.dashboard.param.DashboardUpdateParams;

import java.util.List;

/**
 * <pre>
 *  描述:DashboardService接口
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/18 14:26
 */
public interface DashboardService {

    /**
     * 获取Dashboard视图列表
     * @return
     */
    List<Dashboard> queryDashboardList();

    /**
     * 获取Dashboard视图信息
     * @param viewId
     * @return
     */
    Dashboard queryDashboardByKey(String viewId);

    /**
     * 创建Dashboard视图
     * @param dashboard
     */
    void addDashboard(DashboardAddParams dashboard) throws Exception;

    /**
     * 更新Dashboard视图信息
     * @param dashboard
     */
    void updateDashboard(DashboardUpdateParams dashboard) throws Exception;

    /**
     * 保存Dashboard视图布局
     * @param dashboard
     */
    void saveDashboard(Dashboard dashboard);

    /**
     * 删除Dashboard视图
     * @param viewId
     */
    void deleteDashboard(String viewId) throws Exception;
}
