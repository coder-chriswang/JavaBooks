package com.neoway.iot.manager.dashboard.api;

import com.neoway.iot.manager.common.HttpResult;
import com.neoway.iot.manager.dashboard.bean.Dashboard;
import com.neoway.iot.manager.dashboard.param.DashboardAddParams;
import com.neoway.iot.manager.dashboard.param.DashboardUpdateParams;
import com.neoway.iot.manager.dashboard.service.DashboardService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @desc: DashboardController
 * @author: 20200312686
 * @date: 2020/8/3 15:50
 */
@RestController
@RequestMapping("/v1/dashboard")
@Api(tags = "dashboard",description = "dashboard管理接口")
@Slf4j
public class DashboardController {

    @Autowired
    private DashboardService dashboardServiceImpl;

    @ApiOperation("获取视图列表")
    @GetMapping("/view")
    public HttpResult<List<Dashboard>> queryViewList() {
        try{
            return HttpResult.returnSuccess(dashboardServiceImpl.queryDashboardList());
        }catch (Exception e){
            log.error(e.getMessage(), e);
            return HttpResult.returnFail("查询失败！");
        }
    }

    @ApiOperation("获取视图信息")
    @GetMapping("/view/{viewId}")
    public HttpResult<Dashboard> queryView(@PathVariable("viewId") String viewId) {
        try{
            return HttpResult.returnSuccess(dashboardServiceImpl.queryDashboardByKey(viewId));
        }catch (Exception e){
            log.error(e.getMessage(), e);
            return HttpResult.returnFail("查询失败！");
        }
    }

    @ApiOperation("添加视图信息")
    @PostMapping("/view/add")
    public HttpResult addView(@RequestBody @Valid DashboardAddParams dashboard) {
        try{
            dashboardServiceImpl.addDashboard(dashboard);
            return HttpResult.returnSuccess("添加视图成功！");
        }catch (Exception e){
            log.error(e.getMessage(), e);
            return HttpResult.returnFail("添加失败！");
        }
    }

    @ApiOperation("更新视图信息")
    @PostMapping("/view/update")
    public HttpResult updateView(@RequestBody @Valid DashboardUpdateParams dashboard) {
        try{
            dashboardServiceImpl.updateDashboard(dashboard);
            return HttpResult.returnSuccess("更新视图成功");
        }catch (Exception e){
            log.error(e.getMessage(), e);
            return HttpResult.returnFail("更新失败！");
        }
    }

    @ApiOperation("保存视图布局")
    @PostMapping("/view/{viewId}")
    public HttpResult saveView(@PathVariable("viewId") String viewId) {
        try{
            //todo 暂不实现
            return HttpResult.returnSuccess("保存视图布局成功");
        }catch (Exception e){
            log.error(e.getMessage(), e);
            return HttpResult.returnFail("保存失败！");
        }
    }

    @ApiOperation("删除视图信息")
    @DeleteMapping("/view/{viewId}")
    public HttpResult deleteView(@PathVariable("viewId") String viewId) {
        try{
            dashboardServiceImpl.deleteDashboard(viewId);
            return HttpResult.returnSuccess("删除视图成功");
        }catch (Exception e){
            log.error(e.getMessage(), e);
            return HttpResult.returnFail("删除失败！");
        }
    }
}
