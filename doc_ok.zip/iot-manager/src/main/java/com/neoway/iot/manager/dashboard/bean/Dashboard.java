package com.neoway.iot.manager.dashboard.bean;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @desc: Dashboard
 * @author: 20200312686
 * @date: 2020/8/3 15:51
 */
@Data
@ApiModel("Dashboard视图")
public class Dashboard {

    @ApiModelProperty("编码")
    private String code;

    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("描述")
    private String desc;

    @ApiModelProperty("图表")
    private JSONObject chart;

    @ApiModelProperty("更新时间")
    private long lt;

}
