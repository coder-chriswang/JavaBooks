package com.neoway.iot.manager.model.service;

/**
 * <pre>
 *  描述: EMQ发布接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 17:42
 */
public interface EmqService {
    /**
     * 发布消息
     *
     * @param topic
     * @param content
     * @return
     */
    Boolean publish(String topic, String content);
}
