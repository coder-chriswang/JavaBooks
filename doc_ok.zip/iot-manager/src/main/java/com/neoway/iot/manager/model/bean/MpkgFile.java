package com.neoway.iot.manager.model.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 模型包文件对象
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 13:04
 */
@Data
@ApiModel("模型包文件对象")
public class MpkgFile implements Serializable {
    private static final long serialVersionUID = -2633495817046932023L;

    @ApiModelProperty("id")
    private int id;

    @ApiModelProperty("产品域")
    private String ns;

    @ApiModelProperty("文件类型")
    private int fileType;

    @ApiModelProperty("文件名")
    private String fileName;

    @ApiModelProperty("存储方式")
    private int storeType;

    @ApiModelProperty("文件路径")
    private String fileUrl;

    @ApiModelProperty("fdfsServer")
    private String fdfsServer;

    @ApiModelProperty("上传用户id")
    private String uploadUserId;

    @ApiModelProperty("文件状态")
    private int fileStatus;

    @ApiModelProperty("文件扩展信息")
    private String fileExtensionName;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("更新时间")
    private Date updateTime;

}
