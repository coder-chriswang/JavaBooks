package com.neoway.iot.manager.dashboard.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.neoway.iot.manager.dashboard.bean.Dashboard;
import com.neoway.iot.manager.dashboard.mapper.DashboardMapper;
import com.neoway.iot.manager.dashboard.param.DashboardAddParams;
import com.neoway.iot.manager.dashboard.param.DashboardUpdateParams;
import com.neoway.iot.manager.dashboard.service.DashboardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

/**
 * <pre>
 *  描述: Dashboard Service实现
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/18 14:35
 */
@Service
@Slf4j
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    private DashboardMapper dashboardMapper;

    @Override
    public List<Dashboard> queryDashboardList() {
        log.debug("查询dashboard视图列表");
        return dashboardMapper.queryDashboardList();
    }

    @Override
    public Dashboard queryDashboardByKey(String code) {
        log.debug("查询dashboard视图,code={}", code);
        return dashboardMapper.queryDashboardByKey(code);
    }

    @Override
    public void addDashboard(DashboardAddParams params) throws Exception {
        Dashboard dashboard = new Dashboard();
        BeanUtil.copyProperties(params, dashboard);
        dashboard.setLt(LocalDateTime.now().atZone(ZoneId.systemDefault()).toEpochSecond());
        log.info("添加dashboard，{}", dashboard);
        int add = dashboardMapper.addDashboard(dashboard);
        if (add == 0) {
            log.error("添加dashboard失败, dashboard = {}", dashboard);
            throw new Exception("添加dashboard失败");
        }
        log.info("添加dashboard成功");
    }

    @Override
    public void updateDashboard(DashboardUpdateParams params) throws Exception {
        Dashboard dashboard = new Dashboard();
        BeanUtil.copyProperties(params, dashboard);
        dashboard.setLt(LocalDateTime.now().atZone(ZoneId.systemDefault()).toEpochSecond());
        log.info("更新dashboard，{}", dashboard);
        int update = dashboardMapper.updateDashboard(dashboard);
        if (update == 0) {
            throw new Exception("更新dashboard失败");
        }
        log.info("更新dashboard成功");
    }

    @Override
    public void saveDashboard(Dashboard dashboard) {
        //本期暂不做
    }

    @Override
    public void deleteDashboard(String code) throws Exception {
        log.info("删除dashboard,code={}", code);
        int delete = dashboardMapper.deleteDashboard(code);
        if (delete == 0) {
            throw new Exception("删除dashboard失败");
        }
        log.info("删除dashboard成功，code={}", code);
    }
}
