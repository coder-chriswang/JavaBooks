package com.neoway.iot.manager.model.service.impl;

import cn.hutool.core.io.FileUtil;
import com.alibaba.fastjson.JSON;
import com.neoway.iot.manager.model.bean.MpkgFile;
import com.neoway.iot.manager.model.common.ConstantParams;
import com.neoway.iot.manager.model.common.ModelException;
import com.neoway.iot.manager.model.common.MpkgFileUtil;
import com.neoway.iot.manager.model.common.fdfs.FdfsClient;
import com.neoway.iot.manager.model.mapper.MpkgFileMapper;
import com.neoway.iot.manager.model.service.EmqService;
import com.neoway.iot.manager.model.service.MpkgFileService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;

/**
 * <pre>
 *  描述: MpkgFileServiceImpl
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 13:46
 */
@Service
@Slf4j
public class MpkgFileServiceImpl implements MpkgFileService {

    @Autowired
    private MpkgFileMapper mpkgFileMapper;

    @Autowired
    private FdfsClient fdfsClient;

    @Autowired
    private EmqService emqService;

    @Value("${fdfs.server}")
    private String fdfsServer;

    @Value("${start.fdfs.store}")
    private String storeType;

    @Value("${direct.store.path}")
    private String savePath;

    @Override
    public MpkgFile upload(MultipartFile mpkgFile) {
        // 获取模型包上传文件类型
        int fileType = MpkgFileUtil.getFileType(mpkgFile.getOriginalFilename());
        // 不支持的类型
        if (fileType == -1) {
            throw new ModelException("上传模型包文件格式不支持！");
        }
        // 上传模型包文件
        return add(mpkgFile, fileType);
    }

    @Override
    public void batchInstall(List<MpkgFile> mpkgFiles) {
        mpkgFileMapper.batchAdd(mpkgFiles);
        // 发送消息至DGW，让其加载相关模型包文件
        emqService.publish(ConstantParams.TOPIC_MPKG_INSTALL, JSON.toJSONString(mpkgFiles));
    }

    @Override
    public void download(String url, HttpServletResponse response) {
        MpkgFile mpkgFile = mpkgFileMapper.findFileByUrl(url);
        try {
            if (mpkgFile == null) {
                return;
            }
            String name = java.net.URLEncoder.encode(mpkgFile.getFileName(), "UTF-8");
            response.setContentType("application/octet-stream;charset=utf-8");
            response.setHeader("Content-Disposition","attachment;filename=" + name);
            if (MpkgFileUtil.isFdfsStore(storeType)) {
                IOUtils.write(fdfsClient.downFile(url), response.getOutputStream());
            } else {
                IOUtils.write(FileUtil.readBytes(url), response.getOutputStream());
            }
        } catch (Exception e) {
            log.error("下载模型包文件失败,url={}", url, e);
        }
    }

    @Override
    public void uninstall(String url) {
        try {
            mpkgFileMapper.updateFileStatus(url);
            MpkgFile mpkgFile = mpkgFileMapper.findFileByUrl(url);
            if (MpkgFileUtil.isFdfsStore(storeType)) {
                fdfsClient.deleteFile(url);
            } else {
                FileUtil.del(url);
            }
            // 发送消息至DGW，让其卸载相关模型包文件
            emqService.publish(ConstantParams.TOPIC_MPKG_UNINSTALL, JSON.toJSONString(mpkgFile));
        } catch (Exception e) {
            log.error("卸载模型包文件失败,url={}", url, e);
        }
    }

    @Override
    public void batchUninstall(List<MpkgFile> mpkgFiles) {
        try {
            mpkgFileMapper.batchUpdateFileStatus(mpkgFiles);
            for (MpkgFile mpkgFile : mpkgFiles) {
                if (MpkgFileUtil.isFdfsStore(storeType)) {
                    fdfsClient.deleteFile(mpkgFile.getFileUrl());
                } else {
                    FileUtil.del(mpkgFile.getFileUrl());
                }
            }
            // 发送消息至DGW，让其卸载相关模型包文件
            emqService.publish(ConstantParams.TOPIC_MPKG_UNINSTALL, JSON.toJSONString(mpkgFiles));
        } catch (Exception e) {
            log.error("批量卸载模型包文件失败！", e);
        }
    }

    private MpkgFile add(MultipartFile file, int fileType) {
        MpkgFile mpkgFile = new MpkgFile();
        String url;
        try {
            if (MpkgFileUtil.isFdfsStore(storeType)) {
                url = fdfsClient.saveFile(file);
                mpkgFile.setStoreType(1);
            } else {
                url = MpkgFileUtil.saveFile(file, savePath);
                mpkgFile.setStoreType(2);
            }
            mpkgFile.setFileUrl(url);
            mpkgFile.setFileType(fileType);
            mpkgFile.setFileName(file.getOriginalFilename());
            mpkgFile.setFileExtensionName(FilenameUtils.getExtension(file.getOriginalFilename()));
            mpkgFile.setCreateTime(new Date());
            mpkgFile.setFdfsServer(fdfsServer);
            return mpkgFile;
        } catch (Exception e) {
            log.error("上传模型包文件失败,name={}", file.getOriginalFilename(), e);
            throw new ModelException("上传模型包文件失败！");
        }
    }
}
