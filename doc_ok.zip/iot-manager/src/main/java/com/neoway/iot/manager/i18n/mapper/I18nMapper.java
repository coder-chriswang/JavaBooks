package com.neoway.iot.manager.i18n.mapper;

import com.neoway.iot.manager.i18n.bean.I18n;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述: I18nMapper
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/13 17:09
 */

@Mapper
public interface I18nMapper {
    List<I18n> queryI18nList(@Param("lan") String lan, @Param("enable") String enable);
}
