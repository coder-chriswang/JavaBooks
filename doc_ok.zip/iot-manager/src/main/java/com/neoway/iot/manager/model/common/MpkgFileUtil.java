package com.neoway.iot.manager.model.common;

import cn.hutool.core.io.FileUtil;
import cn.hutool.crypto.digest.DigestUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

/**
 * <pre>
 *  描述: 模型包文件验证工具
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 13:09
 */
@Slf4j
public class MpkgFileUtil {

    private static final String ZIP_FILE_NAMES = "zip";

    public static int getFileType(String fileName) {
        String fileExName = FilenameUtils.getExtension(fileName);
        if (ZIP_FILE_NAMES.contains(fileExName)) {
            return ConstantParams.FileType.ZIP_FILE.getType();
        } else {
            return -1;
        }
    }

    public static String saveFile(MultipartFile multipartFile, String savePath) {
        String url = "";
        try {
            String md5 = DigestUtil.md5Hex(multipartFile.getInputStream());
            File localFile  = new File(savePath, md5);
            if (!FileUtil.exist(localFile)) {
                // 创建一个新文件
                File attachFile = FileUtil.touch(savePath, md5);
                // 将文件流写入文件中
                FileUtil.writeFromStream(multipartFile.getInputStream(), attachFile);
                // 获取文件的绝对路径
                url = attachFile.getAbsolutePath();
            }
        } catch (Exception e) {
            log.error("直接存储模型包文件失败！", e);
        }
        return url;
    }

    public static boolean isFdfsStore(String storeType) {
        return (StringUtils.isBlank(storeType) || Boolean.TRUE.toString().equals(storeType));
    }
}
