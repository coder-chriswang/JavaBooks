package com.neoway.iot.manager.common.config.datasource;

import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

/**
 * <pre>
 *  描述: 配置Aresm数据库连接
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/18 16:22
 */
@Configuration
@MapperScan(basePackages = AresmDataSourceConfig.PACKAGE, sqlSessionFactoryRef = "aresmSqlSessionFactory")
public class AresmDataSourceConfig {

    static final String PACKAGE = "com.neoway.iot.manager.i18n.mapper";
    static final String MAPPER_LOCATION = "mapper/i18n/*Mapper.xml";

    @Value("${aresm.datasource.url}")
    private String url;

    @Value("${aresm.datasource.username}")
    private String user;

    @Value("${aresm.datasource.password}")
    private String password;

    @Value("${aresm.datasource.driver-class-name}")
    private String driverClassName;

    @Value("${spring.datasource.hikari.pool-name}")
    private String poolName;

    @Value("${spring.datasource.hikari.maximum-pool-size}")
    private int maximumPoolSize;

    @Value("${spring.datasource.hikari.minimum-idle}")
    private int minimumIdle;

    @Value("${spring.datasource.hikari.idle-timeout}")
    private long idleTimeout;

    @Value("${spring.datasource.hikari.auto-commit}")
    private boolean isAutoCommit;

    @Value("${spring.datasource.hikari.max-lifetime}")
    private long maxLifetime;

    @Value("${spring.datasource.hikari.connection-timeout}")
    private long connectionTimeout;

    @Value("${spring.datasource.hikari.connection-test-query}")
    private String connectionTestQuery;

    @Bean(name = "aresmDaraSource")
    @Primary
    public DataSource aresmDaraSource() {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(url);
        dataSource.setUsername(user);
        dataSource.setPassword(password);
        dataSource.setDriverClassName(driverClassName);
        dataSource.setPoolName(poolName);
        dataSource.setMaximumPoolSize(maximumPoolSize);
        dataSource.setMinimumIdle(minimumIdle);
        dataSource.setIdleTimeout(idleTimeout);
        dataSource.setAutoCommit(isAutoCommit);
        dataSource.setMaxLifetime(maxLifetime);
        dataSource.setConnectionTimeout(connectionTimeout);
        dataSource.setConnectionTestQuery(connectionTestQuery);
        return dataSource;
    }

    @Bean(name = "aresmTransactionManager")
    @Primary
    public DataSourceTransactionManager aresmTransactionManager() {
        return new DataSourceTransactionManager(aresmDaraSource());
    }

    @Bean(name = "aresmSqlSessionFactory")
    @Primary
    public SqlSessionFactory aresmSqlSessionFactory(@Qualifier("aresmDaraSource") DataSource aresmDaraSource)
            throws Exception{
        final SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
        sqlSessionFactory.setDataSource(aresmDaraSource);
        sqlSessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver()
                .getResources(AresmDataSourceConfig.MAPPER_LOCATION));
        return sqlSessionFactory.getObject();
    }

}
