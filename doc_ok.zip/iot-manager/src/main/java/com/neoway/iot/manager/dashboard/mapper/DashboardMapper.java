package com.neoway.iot.manager.dashboard.mapper;

import com.neoway.iot.manager.dashboard.bean.Dashboard;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述:
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/18 14:55
 */
@Mapper
public interface DashboardMapper {
    /**
     * 获取Dashboard视图列表
     * @return
     */
    List<Dashboard> queryDashboardList();

    /**
     * 获取Dashboard视图信息
     * @param code
     * @return
     */
    Dashboard queryDashboardByKey(@Param("code") String code);

    /**
     * 创建Dashboard视图
     * @param dashboard
     * @return
     */
    int addDashboard(@Param("dashboard") Dashboard dashboard);

    /**
     * 更新Dashboard视图信息
     * @param dashboard
     * @return
     */
    int updateDashboard(@Param("dashboard") Dashboard dashboard);

    /**
     * 保存Dashboard视图布局
     * @param dashboard
     * @return
     */
    int saveDashboard(@Param("dashboard") Dashboard dashboard);

    /**
     * 删除Dashboard视图
     * @param code
     * @return
     */
    int deleteDashboard(@Param("code") String code);
}
