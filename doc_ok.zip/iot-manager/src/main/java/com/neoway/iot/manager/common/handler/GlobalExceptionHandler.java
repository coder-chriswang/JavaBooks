package com.neoway.iot.manager.common.handler;

import com.neoway.iot.manager.common.HttpResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

/**
 * <pre>
 *  描述: 全局异常处理
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/19 16:47
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ResponseBody
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public HttpResult methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException e) {
        String errorMsg = e.getBindingResult().getAllErrors().get(0).getDefaultMessage();
        log.error("参数检验错误，{}", errorMsg);
        return HttpResult.returnFail(errorMsg);
    }
}
