package com.neoway.iot.manager.i18n.service;

import com.neoway.iot.manager.i18n.bean.I18n;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: i18n Service层接口
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/13 17:09
 */
public interface I18nService {

    /**
     * 获取国际化提条列表
     * @param lan
     * @param enable
     * @return
     */
    List<I18n> queryI18nList(String lan, String enable);

    /**
     * 获取国际化词条，以Map<ns,Map<k,v>>形式返回
     * @param lan
     * @param enable
     * @return
     */
    Map<String, Map<String,String>> queryI18n(String lan, String enable);
}
