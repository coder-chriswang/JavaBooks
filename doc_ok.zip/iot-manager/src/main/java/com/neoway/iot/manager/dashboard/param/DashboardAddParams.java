package com.neoway.iot.manager.dashboard.param;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * <pre>
 *  描述: 创建Dashboard视图入参
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/19 15:18
 */
@Data
@ApiModel("创建Dashboard视图入参")
public class DashboardAddParams implements Serializable {
    private static final long serialVersionUID = 6061099983796597830L;

    @NotBlank(message = "code不能为空")
    @ApiModelProperty("视图编码")
    private String code;

    @NotBlank(message = "name不能为空")
    @ApiModelProperty("视图名称")
    private String name;

    @ApiModelProperty("描述")
    private String desc;

    @NotEmpty(message = "chart不能为空")
    @ApiModelProperty("chart信息")
    private JSONObject chart;
}
