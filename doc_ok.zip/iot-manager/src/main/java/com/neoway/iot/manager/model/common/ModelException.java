package com.neoway.iot.manager.model.common;

/**
 * <pre>
 *  描述:
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 16:34
 */
public class ModelException extends RuntimeException {
    private static final long serialVersionUID = -2982833756402670534L;

    public ModelException(String message) {
        super(message);
    }
}
