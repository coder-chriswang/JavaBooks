package com.neoway.iot.manager.model.mapper;

import com.neoway.iot.manager.model.bean.MpkgFile;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述: 模型包文件操作Mapper
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 14:04
 */
@Mapper
public interface MpkgFileMapper {
    /**
     * 插入模型包文件信息
     * @param file
     * @return 插入数据主键
     */
    int add(@Param("file") MpkgFile file);

    /**
     * 批量插入模型包文件信息
     * @param files
     * @return
     */
    void batchAdd(@Param("files") List<MpkgFile> files);

    /**
     * 获取Ns下模型包文件列表
     * @param ns
     * @return
     */
    List<MpkgFile> findFilesByNs(@Param("ns") String ns);

    /**
     * 获取不同状态下的模型包文件列表
     * @param status
     * @return
     */
    List<MpkgFile> findFilesByStatus(@Param("status") int status);

    /**
     * 查询模型包文件
     * @param fileUrl
     * @return
     */
    MpkgFile findFileByUrl(@Param("fileUrl") String fileUrl);

    /**
     * 卸载模型包文件
     * @param fileUrl
     */
    void updateFileStatus(@Param("fileUrl") String fileUrl);

    /**
     * 批量卸载模型包文件
     * @param files
     */
    void batchUpdateFileStatus(@Param("files") List<MpkgFile> files);

}
