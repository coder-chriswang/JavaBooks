package com.neoway.iot.manager.model.common;

/**
 * <pre>
 *  描述: Consultation常量
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 13:11
 */
public interface ConstantParams {

    String TOPIC_MPKG_INSTALL = "installMpkg";
    String TOPIC_MPKG_UNINSTALL = "uninstallMpkg";


    enum FileType {
        ZIP_FILE(1,"zip文件"),
        OTHER_FILE(2,"其他文件"),
        ;


        private int type;
        private String desc;

        FileType(int type, String desc) {
            this.type = type;
            this.desc = desc;
        }

        public int getType() {
            return type;
        }

        public String getDesc() {
            return desc;
        }
    }
}
