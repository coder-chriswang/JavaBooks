package com.neoway.iot.manager.model.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * <pre>
 *  描述: 配置类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/08/26 15:04
 */
@Component
@ConfigurationProperties(prefix = "mqtt")
@Data
public class MqttConfiguration {
    /**
     * broker地址
     */
    private String host;

    /**
     * broker用户名
     */
    private String username;

    /**
     * broker密码
     */
    private String password;

    /**
     * 消息质量等级
     */
    private Integer qos;

    /**
     * 服务器列表
     */
    private String[] hosts;

    /**
     * 连接超时时间
     */
    private Integer connectionTimeout;

    /**
     * 心跳时间
     */
    private Integer keepAliveInterval;

    /**
     * 发布者id
     */
    private String publishClientId;

    /**
     * 订阅者id
     */
    private String subscribeClientId;

    /**
     * 是否保留
     */
    private boolean retained;
}
