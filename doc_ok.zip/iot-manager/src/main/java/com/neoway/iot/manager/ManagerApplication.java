package com.neoway.iot.manager;

import com.github.tobato.fastdfs.FdfsClientConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication(scanBasePackages = "com.neoway.iot.manager", excludeName = "DataSourceAutoConfiguration.class")
@Import({FdfsClientConfig.class})
public class ManagerApplication {
    /**
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(ManagerApplication.class, args);
    }

}
