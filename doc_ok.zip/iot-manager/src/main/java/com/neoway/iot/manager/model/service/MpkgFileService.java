package com.neoway.iot.manager.model.service;

import com.neoway.iot.manager.model.bean.MpkgFile;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <pre>
 *  描述: 模型包文件处理Service
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/24 12:55
 */
public interface MpkgFileService {
    /**
     * 上传模型包文件
     * @param mpkgFile
     * @return
     */
    MpkgFile upload(MultipartFile mpkgFile);


    /**
     * 批量加载模型包文件信息
     * @param mpkgFiles
     * @return
     */
    void batchInstall(List<MpkgFile> mpkgFiles);


    /**
     * 下载模型包文件
     * @param url
     * @param response
     */
    void download(String url, HttpServletResponse response);

    /**
     * 卸载模型包文件
     * @param url
     */
    void uninstall(String url);

    /**
     * 批量卸载模型包文件
     * @param mpkgFiles
     */
    void batchUninstall(List<MpkgFile> mpkgFiles);
}
