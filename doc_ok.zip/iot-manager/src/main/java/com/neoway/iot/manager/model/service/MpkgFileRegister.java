package com.neoway.iot.manager.model.service;

import cn.hutool.core.io.FileTypeUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ArrayUtil;
import com.alibaba.fastjson.JSON;
import com.neoway.iot.manager.model.bean.MpkgFile;
import com.neoway.iot.manager.model.common.ConstantParams;
import com.neoway.iot.manager.model.mapper.MpkgFileMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <pre>
 *  描述: 模型包静态加载
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/28 16:59
 */
@Component
@Slf4j
@EnableScheduling
public class MpkgFileRegister {

    @Value("${direct.store.path}")
    private String storePath;

    @Autowired
    private MpkgFileMapper mpkgFileMapper;

    @Autowired
    private EmqService emqService;

    /**
     * 每隔10s扫描文件路径
     */
    private static final int RESCAN_FIXED_RATE = 1000 * 10;

//    @Scheduled(fixedRate = RESCAN_FIXED_RATE)
    public void scanFilesToRegister() {
        try {
            File[] fileArray = FileUtil.ls(storePath);
            if (ArrayUtil.isEmpty(fileArray)) {
                log.warn("指定路径下不存在文件或是文件夹！");
                return;
            }
            List<File> fileList = new ArrayList<>(Arrays.asList(fileArray));
            fileList.stream().filter(f -> "zip".equals(FileTypeUtil.getType(f))).collect(Collectors.toList());
            // 数据库中查询已加载的模型包文件
            List<MpkgFile> mpkgFileList = mpkgFileMapper.findFilesByStatus(1);
            if (CollectionUtils.isEmpty(fileList)) {
                log.warn("指定路径下不存在相关模型包文件！");
                return;
            }
            List<File> tempFileList = new ArrayList<>();
            if (CollectionUtils.isEmpty(mpkgFileList)) {
                tempFileList = fileList;
            } else {
                for (File file : fileList) {
                    for (MpkgFile mpkgFile : mpkgFileList) {
                        if (!file.getName().equals(mpkgFile.getFileName())) {
                            tempFileList.add(file);
                        }
                    }
                }
            }
            if (CollectionUtils.isEmpty(tempFileList)) {
                log.warn("无新增加载模型包文件！");
                return;
            }
            // 组装相关对象
            List<MpkgFile> resultList = new ArrayList<>();
            for (File file : tempFileList) {
                MpkgFile mpkgFile = new MpkgFile();
                mpkgFile.setFileUrl(file.getAbsolutePath());
                mpkgFile.setStoreType(2);
                mpkgFile.setFileName(file.getName());
                mpkgFile.setFileType(1);
                mpkgFile.setFileStatus(1);
                mpkgFile.setCreateTime(new Date());
                resultList.add(mpkgFile);
            }
            // 加载至数据库信息存储
            mpkgFileMapper.batchAdd(resultList);
            // 将新增模型包文件进行静默加载并发送消息至DGW
            emqService.publish(ConstantParams.TOPIC_MPKG_INSTALL, JSON.toJSONString(resultList));
        } catch (Exception e) {
            log.error("定时加载模型包任务失败！", e);
        }
    }
}
