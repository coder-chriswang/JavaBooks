package com.neoway.iot.manager.i18n.service.impl;

import com.neoway.iot.manager.i18n.bean.I18n;
import com.neoway.iot.manager.i18n.mapper.I18nMapper;
import com.neoway.iot.manager.i18n.service.I18nService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: I18nService实现
 * </pre>
 *
 * @author: 20190712525
 * @date: 2020/8/13 17:13
 */

@Slf4j
@Service
public class I18nServiceImpl implements I18nService {

    @Autowired
    private I18nMapper i18nMapper;

    @Override
    public List<I18n> queryI18nList(String lan, String enable) {
        return i18nMapper.queryI18nList(lan, enable);
    }

    @Override
    public Map<String, Map<String, String>> queryI18n(String lan, String enable) {

        // todo lan enable 条件判定
        log.info("获取国际化词条，lan={}, enable={}", lan, enable);
        HashMap<String, Map<String, String>> result = new HashMap<>();

        List<I18n> i18nList = queryI18nList(lan, enable);

        for (I18n i18n : i18nList) {
            if (result.keySet().contains(i18n.getNs())) {
                result.get(i18n.getNs()).put(i18n.getK(), i18n.getV());
            } else {
                HashMap<String, String> map = new HashMap<>();
                map.put(i18n.getK(), i18n.getV());
                result.put(i18n.getNs(), map);
            }
        }

        return result;
    }
}
