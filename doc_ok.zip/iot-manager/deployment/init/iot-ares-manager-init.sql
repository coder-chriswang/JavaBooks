-- ----------------------------
-- Table structure for MODEL_FILE
-- ----------------------------
DROP TABLE IF EXISTS `CI_B_MODELPACKAGE`;
CREATE TABLE `CI_B_MODELPACKAGE`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `ns` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品域',
  `file_type` tinyint(2) DEFAULT NULL COMMENT '文件类型（1：zip）',
  `store_type` tinyint(2) DEFAULT NULL COMMENT '存储类型（1：fdfs，2：direct）',
  `file_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '文件名称',
  `file_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '存放路径',
  `upload_user_id` varbinary(32) DEFAULT NULL COMMENT '上传用户id',
  `file_status` tinyint(2) DEFAULT NULL COMMENT '文件状态（1：加载使用中，2：已卸载）',
  `create_time` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(20) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ns`(`ns`) USING BTREE COMMENT '产品域',
  INDEX `fileName`(`file_name`) USING BTREE COMMENT '文件名称',
  INDEX `fileStatus`(`file_status`) USING BTREE COMMENT '文件状态'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

