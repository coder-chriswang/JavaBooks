package com.neoway.iot.simulator.template;

import com.neoway.iot.simulator.SimRequest;
import com.neoway.iot.simulator.common.FreeMarkerTemplate;
import com.neoway.iot.simulator.common.SimUtils;
import com.neoway.iot.simulator.scheduler.SimTask;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 模板-header对象
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
public class MetaHeader {
    private static final Logger LOG = LoggerFactory.getLogger(MetaHeader.class);
    private static final String TPL = "<#if template.header??>${template.header}</#if>";
    //header模板
    private String headerText;

    public String getHeaderText() {
        return this.headerText;
    }

    /**
     *
     * 解析模板文件
     * @param data 模板数据
     * @return
     */
    public static MetaHeader build(Map<String,Object> data){
        try{
            String transValue= FreeMarkerTemplate.transform(TPL,data);
            MetaHeader header = new MetaHeader();
            transValue= SimUtils.replaceBlank(transValue);
            header.headerText= SimUtils.replaceBlank(transValue);
            if(StringUtils.isEmpty(transValue)){
                return null;
            }
            return header;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        }

    }

    /**
     * 模板翻译
     * @param req
     * @return
     */
    public String transfter(SimTask req){
        try {
            Map<String,Object> contextMap=new HashMap<>();
            contextMap.put("task",req);
            return FreeMarkerTemplate.transform(this.getHeaderText(),contextMap);
        } catch (IOException e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        } catch (TemplateException e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        } catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
