package com.neoway.iot.simulator;

/**
 * @desc: SimResponse
 * @author: 20200312686
 * @date: 2020/7/14 19:03
 */
public class SimResponse {
    private int code=0;
    private String errMsg;
    private Object data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
