package com.neoway.iot.simulator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.Map;


/**
 * @desc: SimConfig
 * @author: 20200312686
 * @date: 2020/7/14 19:19
 */
public class SimConfig {
    private static SimConfig env=null;
    private Environment pro;
    private SimConfig(){
    }

    public static SimConfig getInstance(){
        if(env == null){
            env=new SimConfig();
        }
        return env;
    }

    public Environment getPro() {
        return pro;
    }

    public void start(Environment pro){
        this.pro=pro;
    }
    public Object getValue(String key,String defaultValue){
        return pro.getProperty(key,defaultValue);
    }
    public Object getValue(String key){
        return pro.getProperty(key);
    }
    public Map<String,Object> getCategoryParams(){
        Map<String,Object> prams=new HashMap<>();
        prams.put("simulator_connector_restful_uri",getValue("simulator_connector_restful_uri",""));
        prams.put("simulator_channel_4g_cron",getValue("simulator_channel_4g_cron","300"));
        prams.put("simulator_channel_4g_count",getValue("simulator_channel_4g_count","10"));
        return prams;
    }
}
