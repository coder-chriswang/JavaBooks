package com.neoway.iot.simulator.common;

import com.google.common.base.Charsets;
import com.google.common.hash.Hashing;
import com.neoway.iot.simulator.SimConfig;
import freemarker.cache.MruCacheStorage;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: FreeMarkerTemplate
 * @author: 20200312686
 * @date: 2020/7/15 9:16
 */
public class FreeMarkerTemplate {
    private static Configuration configuration;
    public static void init(SimConfig config) throws Exception{
        Map<String,Object> values=config.getCategoryParams();
        configuration=Configuration.getDefaultConfiguration();
        configuration.setDefaultEncoding("UTF-8");
        configuration.setNumberFormat("#");
        configuration.setSharedVariable("env",values);
        configuration.setSharedVariable("sim_random",new FreeMarkerSimRandom());
        configuration.setCacheStorage(new MruCacheStorage(20,50));
        StringTemplateLoader loader= new StringTemplateLoader();
        configuration.setTemplateLoader(loader);
    }


    /**
     * @desc 模板翻译
     * @param tpl 模板
     * @param context 数据上下文
     * @return 翻译后字符串
     * @throws IOException
     * @throws TemplateException
     */
    public static String transform(String tpl,Object context) throws IOException, TemplateException {
        String tplName= Hashing.md5().hashString(tpl, Charsets.UTF_8).toString();

        Template template=configuration.getTemplate(tplName, null, null,
                null, true, true);
        if(null == template){
            StringTemplateLoader loader=(StringTemplateLoader)configuration.getTemplateLoader();
            template=new Template(tplName,tpl,configuration);
            loader.putTemplate(tplName,tpl);
        }
        StringWriter writer = null;
        try{
            writer=new StringWriter();
            template.process(context,writer);
            String result=writer.toString();
            writer.flush();

            result=StringUtils.stripToEmpty(result);
            result=StringUtils.trimToEmpty(result);
            return result;
        }finally {
            if(null != writer){
                writer.close();
            }
        }

    }
}
