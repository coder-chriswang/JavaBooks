package com.neoway.iot.simulator.connector;

import com.neoway.iot.simulator.SimConfig;
import com.neoway.iot.simulator.connector.mqtt.MQTTConnector;
import com.neoway.iot.simulator.connector.restful.HttpConnector;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: Connector构造工厂
 * @author: 20200312686
 * @date: 2020/6/23 14:11
 */
public class ConnectorManager {
    private static ConnectorManager factory=null;
    private Map<String,Connector> connectorMap=new HashMap<>();
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private ConnectorManager() {

    }
    public static ConnectorManager getInstance() {
        if (factory == null) {
            synchronized (ConnectorManager.class) {
                if (factory == null) {
                    factory = new ConnectorManager();
                }
            }
        }
        return factory;
    }
    public void start() {
        if(isStarted.get()){
            return;
        }
        SimConfig config=SimConfig.getInstance();
        Connector connector=new MQTTConnector();
        connector.start(config);
        Connector httpConnector=new HttpConnector();
        httpConnector.start(config);
        connectorMap.put(ConnectorType.MQTT.name(),connector);
        connectorMap.put(ConnectorType.RESTFUL.name(),httpConnector);
        isStarted.set(true);
    }
    public Connector getConnector(String protocol){
       return connectorMap.get(StringUtils.trim(protocol).toUpperCase());
    }
}
