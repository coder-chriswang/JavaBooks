package com.neoway.iot.simulator.connector;

import com.neoway.iot.simulator.SimConfig;

public interface Connector{

    void start(SimConfig config);

    /**
     * 执行
     * @param request
     * @return
     */
    ConnectorRsp downlink(ConnectorReq request) throws Exception;

}
