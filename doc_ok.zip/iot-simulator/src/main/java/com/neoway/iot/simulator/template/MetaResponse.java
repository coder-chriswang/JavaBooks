package com.neoway.iot.simulator.template;

import com.neoway.iot.simulator.SimResponse;
import com.neoway.iot.simulator.common.FreeMarkerTemplate;
import com.neoway.iot.simulator.common.SimUtils;
import com.neoway.iot.simulator.connector.Connector;
import com.neoway.iot.simulator.connector.ConnectorRsp;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 模板-response对象
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
public class MetaResponse {
    private static final Logger LOG = LoggerFactory.getLogger(MetaResponse.class);
    private static final String TPL = "<#if template.response??>${template.response}</#if>";
    //response模板
    private String responseText;

    public String getResponseText() {
        return responseText;
    }

    /**
     * 创建response对象
     * @param data
     * @return
     */
    public static MetaResponse build(Map<String,Object> data) {
        try{
            String transValue= FreeMarkerTemplate.transform(TPL,data);
            MetaResponse response = new MetaResponse();
            response.responseText= SimUtils.replaceBlank(transValue);
            if(StringUtils.isEmpty(response.getResponseText())){
                return null;
            }
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        }

    }

    /**
     * 模板翻译
     * @param rsp
     * @return
     */
    public String transfter(ConnectorRsp rsp){
        try {
            Map<String,Object> context=new HashMap<>();
            context.put("response",rsp);
            return FreeMarkerTemplate.transform(this.getResponseText(),context);
        } catch (IOException e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        } catch (TemplateException e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        } catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
