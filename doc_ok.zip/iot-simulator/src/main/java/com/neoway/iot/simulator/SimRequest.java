package com.neoway.iot.simulator;

/**
 * @desc: SimRequest
 * @author: 20200312686
 * @date: 2020/7/14 19:02
 */
public class SimRequest {
    public static final String ACTION_START="Start";
    public static final String ACTION_STOP="Stop";
    private String jobId;
    private String ns;
    private String action;

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
