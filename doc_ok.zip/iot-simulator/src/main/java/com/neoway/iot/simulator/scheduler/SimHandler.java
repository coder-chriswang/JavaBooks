package com.neoway.iot.simulator.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;

/**
 * @desc: 模板执行
 * @author: 20200312686
 * @date: 2020/7/15 10:20
 */
public class SimHandler {
    private static final Logger LOG = LoggerFactory.getLogger(SimHandler.class);
    private SimJob job;
    private Map<String,SimTask> tasks=new HashMap<>();
    private int finishedNum;
    private final Object lock=new Object();
    public SimHandler(SimJob job){
        this.job=job;
        Map<String,Object> jobParam=job.getParams();
        int count=Float.valueOf(jobParam.get("count").toString()).intValue();
        for(int index=1;index<count+1;index++){
            SimTask task=new SimTask(job);
            task.buildParam(job);
            tasks.put(task.getTaskid(),task);
        }
        finishedNum=tasks.size();
    }

    public void execute(){
        ExecutorService executor=job.getThreadPool();
        for(Map.Entry<String,SimTask> entry:tasks.entrySet()){
            SimTask task=entry.getValue();
            SimTaskExecutor taskExecutor=new SimTaskExecutor(entry.getValue(),this);
            executor.execute(taskExecutor);
            task.setStatus(SimTask.STATUS_DOING);
        }
        synchronized (lock){
            try{
                lock.wait();
            }catch (Exception e){
                LOG.error(e.getMessage(),e);
            }

        }
    }

    /**
     * @desc 任务执行结果通知
     * @param task
     */
    public void commit(SimTask task){
        synchronized (lock){
            finishedNum--;
            SimTask simTask=tasks.get(task.getTaskid());
            simTask.setStatus(task.getStatus());
            simTask.setMsg(task.getMsg());
            if(finishedNum == 0){
                lock.notify();
            }
        }

    }
}
