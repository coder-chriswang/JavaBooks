package com.neoway.iot.simulator.scheduler;

import java.beans.Transient;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: SimJob
 * @author: 20200312686
 * @date: 2020/7/14 19:56
 */
public class SimJob {
    public static final String STATUS_STOPED="Stoped";
    public static final String STATUS_INIT="Init";
    public static final String STATUS_STARTED="Started";
    private transient AtomicInteger count = new AtomicInteger();
    //产品
    private String ns;
    //任务ID
    private String jobId;
    //任务名称
    private String jobName;
    //任务状态[init(初始化)，started(运行中),stoped(已停止)]
    private String jobStatus;
    private boolean autoStart;
    //任务执行间隔（秒）
    private int interval;
    //任务参数
    private Map<String,Object> params=new HashMap<>();
    //作业线程池
    private transient ExecutorService threadPool;

    public SimJob(){

    }
    public SimJob(String ns,String jobId){
        this.ns=ns;
        this.jobId=jobId;
        this.jobStatus=STATUS_INIT;
    }
    public SimJob(String ns,String jobId,String jobName){
        this.ns=ns;
        this.jobId=jobId;
        this.jobStatus=STATUS_INIT;
        this.jobName=jobName;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SimJob simJob = (SimJob) o;
        return Objects.equals(ns, simJob.ns) &&
                Objects.equals(jobId, simJob.jobId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ns, jobId);
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(String jobStatus) {
        this.jobStatus = jobStatus;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    /**
     * 构建线程池
     * @param count
     */
    public void buildThreadPool(int count){
        threadPool= Executors.newFixedThreadPool(count,(r) -> {
            Thread t = new Thread(r, this.jobId);
            t.setDaemon(true);
            return t;
        });
    }

    public ExecutorService getThreadPool() {
        return threadPool;
    }

    public void close(){
        threadPool.shutdownNow();
        this.count.set(0);
    }

    public int getCount() {
        return this.count.incrementAndGet();
    }
    public int getCurrentCount() {
        return this.count.get();
    }

    public boolean isAutoStart() {
        return autoStart;
    }

    public void setAutoStart(boolean autoStart) {
        this.autoStart = autoStart;
    }
}
