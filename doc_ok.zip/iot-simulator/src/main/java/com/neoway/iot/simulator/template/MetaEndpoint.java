package com.neoway.iot.simulator.template;

import com.google.gson.Gson;
import com.neoway.iot.simulator.SimRequest;
import com.neoway.iot.simulator.common.FreeMarkerTemplate;
import com.neoway.iot.simulator.common.SimUtils;
import com.neoway.iot.simulator.scheduler.SimTask;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 模板-endpoint对象
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
public class MetaEndpoint {
    private static final Logger LOG = LoggerFactory.getLogger(MetaEndpoint.class);
    private static final String TPL = "{<#if template.endpoint??>" +
            "\"connTimeOut\":${template.endpoint.conn_timeout}," +
            "\"transferTimeOut\":${template.endpoint.transfer_timeOut}," +
            "\"endpointText\":\"${template.endpoint.content}\"" +
            "<#else>" +
            "\"connTimeOut\":0," +
            "\"transferTimeOut\":0," +
            "\"endpointText\":\"\"" +
            "</#if>}";
    private static final int MAX_TIMEOUT = 300;
    //连接超时
    private long connTimeOut;
    //传输超时
    private long transferTimeOut;
    //连接模板
    private String endpointText = "";

    public long getConnTimeOut() {
        return connTimeOut;
    }
    public long getTransferTimeOut() {
        return transferTimeOut;
    }
    public String getEndpointText() {
        return endpointText;
    }

    public static MetaEndpoint build(Map<String,Object> data) {
        try{
            String transValue= FreeMarkerTemplate.transform(TPL,data);
            MetaEndpoint endpoint = new Gson().fromJson(transValue,MetaEndpoint.class);
            endpoint.endpointText= SimUtils.replaceBlank(endpoint.endpointText);
            if(StringUtils.isEmpty(endpoint.getEndpointText())){
                return null;
            }
            return endpoint;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        }


    }
    public String transfter(SimTask req) {
        try {
            Map<String,Object> contextMap=new HashMap<>();
            contextMap.put("task",req);
            return FreeMarkerTemplate.transform(this.getEndpointText(), contextMap);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        } catch (TemplateException e) {
            LOG.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
