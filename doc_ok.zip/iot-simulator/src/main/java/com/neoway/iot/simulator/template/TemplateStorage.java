package com.neoway.iot.simulator.template;

import java.util.List;

/**
 * @desc: DGW 模板存储接口
 * @author: 20200312686
 * @date: 2020/6/23 10:43
 */
public interface TemplateStorage {
    String STYPE="dgw.model.storage";
    String STYPE_REDIS="redis";
    //增加模板
    void addTempate(MetaTemplate tpl);

    //删除模板
    void deleteTemplate(String pro, String id);

    //查询指定ns下的模板列表
    List<MetaTemplate> listTemplates(String ns);

    //查询指定模板的详情
    MetaTemplate getTemplate(String pro, String id);

    //获取所有的模板列表
    List<MetaTemplate> listAll();

    void clean();

}
