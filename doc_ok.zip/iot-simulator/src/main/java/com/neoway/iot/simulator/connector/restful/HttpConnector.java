package com.neoway.iot.simulator.connector.restful;

import com.neoway.iot.simulator.SimConfig;
import com.neoway.iot.simulator.connector.Connector;
import com.neoway.iot.simulator.connector.ConnectorReq;
import com.neoway.iot.simulator.connector.ConnectorRsp;

/**
 * @desc: HttpConnector
 * @author: 20200312686
 * @date: 2020/7/14 19:12
 */
public class HttpConnector implements Connector {
    @Override
    public void start(SimConfig config) {

    }

    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        return null;
    }
}
