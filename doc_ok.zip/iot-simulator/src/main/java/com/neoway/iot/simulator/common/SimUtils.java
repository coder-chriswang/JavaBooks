package com.neoway.iot.simulator.common;

import com.google.common.hash.Hashing;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @desc: SimUtils
 * @author: 20200312686
 * @date: 2020/7/15 9:40
 */
public class SimUtils {
    private static final Logger LOG = LoggerFactory.getLogger(SimUtils.class);

    public static String replaceBlank(String str){
        String dest="";
        if(str == null){
            return dest;
        }
        Pattern p=Pattern.compile("\\s+|\t|\r|\n");
        Matcher m=p.matcher(str);
        dest=m.replaceAll("");
        return StringUtils.stripToEmpty(StringUtils.trimToEmpty(dest));
    }
}
