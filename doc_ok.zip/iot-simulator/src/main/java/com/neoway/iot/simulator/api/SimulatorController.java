package com.neoway.iot.simulator.api;

import com.neoway.iot.simulator.SimRequest;
import com.neoway.iot.simulator.SimResponse;
import com.neoway.iot.simulator.scheduler.SimJob;
import com.neoway.iot.simulator.scheduler.SimJobManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @desc: 指令执行接口
 * @author: 20200312686
 * @date: 2020/6/23 9:27
 */
@RestController
@RequestMapping("/v1/manage")
@Api(tags = "任务管理")
public class SimulatorController {

    @ApiOperation("任务启停")
    @PostMapping("/command")
    public SimResponse command(@RequestBody SimRequest req) {
        //任务启动/停止
        SimJob job=new SimJob(req.getNs(),req.getJobId());
        if(req.getAction().equals(SimRequest.ACTION_START)){
            SimJobManager.getInstance().startJob(job);
        }else{
            SimJobManager.getInstance().stopJob(job);
        }
        return new SimResponse();
    }
    @ApiOperation("任务查询")
    @GetMapping("/tasks")
    public SimResponse queryTask() {
        //模板执行
        List<SimJob> jobs=SimJobManager.getInstance().queryJob();
        SimResponse response=new SimResponse();
        response.setData(jobs);
        return response;
    }
}
