package com.neoway.iot.simulator.scheduler;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @desc: SimTask
 * @author: 20200312686
 * @date: 2020/7/15 13:49
 */
public class SimTask {
    public static final String STATUS_INIT="Init";
    public static final String STATUS_DOING="Running";
    public static final String STATUS_OK="Success";
    public static final String STATUS_NOK="Failed";
    private long baseid;
    private String ns;
    private String jobid;
    private String jobname;
    private String taskid;
    private String status;
    private String msg;
    private Map<String,Object> taskparams=new HashMap<>();
    public SimTask(){

    }
    public SimTask(SimJob job){
        this.jobid=job.getJobId();
        this.jobname=job.getJobName();
        this.status=STATUS_INIT;
        this.ns=job.getNs();

        Map<String,Object> params=job.getParams();
        long base=((Double)params.get("base")).longValue();
        this.baseid=base+job.getCount();
        this.taskid=jobid+"##"+this.baseid;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public long getBaseid() {
        return baseid;
    }

    public void setBaseid(long baseid) {
        this.baseid = baseid;
    }

    public String getJobid() {
        return jobid;
    }

    public void setJobid(String jobid) {
        this.jobid = jobid;
    }

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname;
    }

    public String getTaskid() {
        return taskid;
    }

    public void setTaskid(String taskid) {
        this.taskid = taskid;
    }

    public Map<String, Object> getTaskparams() {
        return taskparams;
    }

    public void setTaskparams(Map<String, Object> taskparams) {
        this.taskparams = taskparams;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void buildParam(SimJob job){
        Map<String,Object> params=job.getParams();
        this.taskparams.putAll(params);
    }
}
