package com.neoway.iot.simulator.connector.mqtt;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.simulator.SimConfig;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @desc: MQTTClient
 * @author: 20200312686
 * @date: 2020/6/29 20:07
 */
public class MQTTClient {
    private static final Logger LOG = LoggerFactory.getLogger(MQTTClient.class);

    public static final String MQTT_URI="simulator_connector_mqtt_uri";
    public static final String MQTT_CLIENTID="simulator_connector_mqtt_client_id";
    public static final String MQTT_USER="simulator_connector_mqtt_user";
    public static final String MQTT_PWD="simulator_connector_mqtt_pwd";
    public static final String MQTT_RECONNECT="simulator_connector_mqtt_reconnect";
    public static final String MQTT_KEEPALIVED="simulator_connector_mqtt_keepalived";
    public static final String MQTT_CONNTIMEOUT="simulator_connector_mqtt_conn_timeout";
    public static final String MQTT_TOPIC_MODEL_SUBCRIBE="simulator_connector_mqtt_topic_subcribe";
    private String serviceURI;
    private String clientId;
    private String username;
    private String password;
    private boolean isReconnect = true;
    private int keepAlivedInternal = 10;
    private int connTimeout = 5;
    private List<MQTTTopic> mqttTopics=new ArrayList<>();
    private MqttConnectOptions options;
    private MqttAsyncClient client;

    public MQTTClient(SimConfig env){
        this.setServiceURI(String.valueOf(env.getValue(MQTT_URI)));
        this.setClientId(String.valueOf(env.getValue(MQTT_CLIENTID)));
        this.setKeepAlivedInternal(String.valueOf(env.getValue(MQTT_KEEPALIVED)));
        this.setConnTimeout(String.valueOf(env.getValue(MQTT_CONNTIMEOUT)));
        String topicStr =String.valueOf(env.getValue(MQTT_TOPIC_MODEL_SUBCRIBE));
        String[] topics=topicStr.split(",");
        for(String topic:topics){
            MQTTTopic mqttTopic=new MQTTTopic(topic);
            mqttTopics.add(mqttTopic);
        }
        this.setReconnect(String.valueOf(env.getValue(MQTT_RECONNECT)));
        this.setUsername(String.valueOf(env.getValue(MQTT_USER)));
        this.setPassword(String.valueOf(env.getValue(MQTT_PWD)));
        this.setConnTimeout(String.valueOf(env.getValue(MQTT_CONNTIMEOUT)));
    }

    public void init(MQTTConnector connector){
        try{
            client=new MqttAsyncClient(this.getServiceURI(),this.getClientId(),new MemoryPersistence());
            options=new MqttConnectOptions();
            options.setCleanSession(true);
            options.setUserName(this.getUsername());
            options.setPassword(this.getPassword().toCharArray());
            options.setConnectionTimeout(10);
            options.setKeepAliveInterval(this.getKeepAlivedInternal());
            options.setAutomaticReconnect(this.isReconnect());
            options.setConnectionTimeout(this.getConnTimeout());
            //默认是10.发送频率太快会报异常
            options.setMaxInflight(1000);
            //client.setTimeToWait(3000);
            client.connect(options);
            /*for(MQTTTopic topic:this.getMqttTopics()){
                LOG.info("订阅主题：topic={},name={},qos={}",topic.getTopic(),topic.getName(),topic.getQos());
                client.subscribe(topic.getTopic(),topic.getQos());
                client.setCallback(new MQTTCallBack(this,topic,connector));
            }*/
        }catch (MqttException e){
            throw new RuntimeException(e);
        }
    }
    public String getServiceURI() {
        return serviceURI;
    }

    public void setServiceURI(String serviceURI) {
        this.serviceURI = serviceURI;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId + UUID.randomUUID().toString();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isReconnect() {
        return isReconnect;
    }

    public void setReconnect(String reconnect) {
        if (StringUtils.isNotEmpty(reconnect)) {
            isReconnect = Boolean.valueOf(reconnect);
        }

    }

    public int getKeepAlivedInternal() {
        return keepAlivedInternal;
    }

    public void setKeepAlivedInternal(String keepAlivedInternal) {
        if (StringUtils.isNotEmpty(keepAlivedInternal)) {
            this.keepAlivedInternal = Integer.valueOf(keepAlivedInternal);
        }

    }

    public List<MQTTTopic> getMqttTopics() {
        return mqttTopics;
    }

    public void setMqttTopics(List<MQTTTopic> mqttTopics) {
        this.mqttTopics = mqttTopics;
    }

    public int getConnTimeout() {
        return connTimeout;
    }

    public void setConnTimeout(String connTimeout) {
        if (StringUtils.isNotEmpty(connTimeout)) {
            this.connTimeout = Integer.valueOf(connTimeout);
        }

    }

    public MqttAsyncClient getClient() {
        return client;
    }
}
