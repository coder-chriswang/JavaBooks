package com.neoway.iot.simulator.connector.mqtt;

/**
 * @desc: MQTTTopic
 * @author: 20200312686
 * @date: 2020/6/29 18:51
 */
public class MQTTTopic {
    private String topic;
    private String name;
    private int qos=2;
    private String tplid;
    private String ns;
    public MQTTTopic(){

    }
    public MQTTTopic(String topic){
        this.topic=topic;
    }
    public MQTTTopic(String topic, String name, int qos, String tplid,String ns) {
        this.topic = topic;
        this.name = name;
        this.qos = qos;
        this.tplid = tplid;
        this.ns=ns;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQos() {
        return qos;
    }

    public void setQos(int qos) {
        this.qos = qos;
    }

    public String getTplid() {
        return tplid;
    }

    public void setTplid(String tplid) {
        this.tplid = tplid;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }
}
