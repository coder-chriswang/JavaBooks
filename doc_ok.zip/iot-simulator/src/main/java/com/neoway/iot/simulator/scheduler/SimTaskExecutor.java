package com.neoway.iot.simulator.scheduler;

import com.google.gson.Gson;
import com.neoway.iot.simulator.SimRequest;
import com.neoway.iot.simulator.SimResponse;
import com.neoway.iot.simulator.connector.Connector;
import com.neoway.iot.simulator.connector.ConnectorManager;
import com.neoway.iot.simulator.connector.ConnectorReq;
import com.neoway.iot.simulator.connector.ConnectorRsp;
import com.neoway.iot.simulator.template.MetaTemplate;
import com.neoway.iot.simulator.template.TemplateManager;
import com.neoway.iot.simulator.template.TemplateStorage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * @desc: SimTaskExecutor
 * @author: 20200312686
 * @date: 2020/7/15 15:07
 */
public class SimTaskExecutor implements Runnable {
    private static final Logger LOG = LoggerFactory.getLogger(SimTaskExecutor.class);
    private SimTask task;
    private SimHandler handler;

    public SimTaskExecutor(SimTask task,SimHandler handler){
        this.task=task;
        this.handler=handler;
    }

    @Override
    public void run() {
        try{
            Thread curThread=Thread.currentThread();
            curThread.setName(task.getTaskid());
            TemplateStorage storage = TemplateManager.getInstance().getStorage();
            MetaTemplate tpl = storage.getTemplate(task.getNs(), task.getJobid());
            ConnectorReq cReq=new ConnectorReq();
            if (null != tpl.getEndpoint()) {
                String endPoint = tpl.getEndpoint().transfter(task);
                cReq.setEndpoint(endPoint);
            }
            if (null != tpl.getHeader()) {
                String header = tpl.getHeader().transfter(task);
                Gson gson = new Gson();
                cReq.setHeader(gson.fromJson(header, Map.class));
            }
            if (null != tpl.getRequest()) {
                String req = tpl.getRequest().transfter(task);
                cReq.setRequest(req);
            }
            //获取connector实例
            Connector connector = ConnectorManager.getInstance().getConnector(tpl.getProtocol());
            //执行connector
            ConnectorRsp rsp = connector.downlink(cReq);
            //connector响应报文翻译
            if(null != tpl.getResponse()){
                String response = tpl.getResponse().transfter(rsp);
                SimResponse result = new Gson().fromJson(response, SimResponse.class);
                if(result.getCode() != 0){
                    task.setStatus(SimTask.STATUS_NOK);
                    task.setMsg(result.getErrMsg());
                }else{
                    task.setStatus(SimTask.STATUS_OK);
                }
            }
            handler.commit(task);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            task.setStatus(SimTask.STATUS_NOK);
            task.setMsg(e.getMessage());
        }finally {
            handler.commit(task);
        }

    }
}
