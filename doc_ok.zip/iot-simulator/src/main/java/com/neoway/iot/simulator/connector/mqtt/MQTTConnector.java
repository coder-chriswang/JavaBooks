package com.neoway.iot.simulator.connector.mqtt;

import com.neoway.iot.simulator.SimConfig;
import com.neoway.iot.simulator.connector.Connector;
import com.neoway.iot.simulator.connector.ConnectorReq;
import com.neoway.iot.simulator.connector.ConnectorRsp;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class MQTTConnector implements Connector {
    private static final Logger LOG = LoggerFactory.getLogger(MQTTConnector.class);
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private MqttAsyncClient client;
    private SimConfig env;
    @Override
    public void start(SimConfig env) {
        if(isStarted.get()){
            return;
        }
        this.env=env;
        LOG.info("MQTTClient开始启动");
        MQTTClient client=new MQTTClient(env);

        client.init(this);
        this.client=client.getClient();
        isStarted.set(true);
        LOG.info("MQTTClient启动成功");
    }

    @Override
    public ConnectorRsp downlink(ConnectorReq request) throws Exception{
        Map<String,Object> param=(Map)request.getHeader().get("params");
        String topic=param.get("topic").toString();
        LOG.info("发送MQTT的报文:topic={},Payload={}",topic,request.getRequest());
        MqttMessage message=new MqttMessage(request.getRequest().getBytes());
        message.setQos(2);
        client.publish(topic,message);
        return new ConnectorRsp();
    }
}
