package com.neoway.iot.dgw.common;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.freemarker.FreeMarkerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @desc: 产品定义对象
 * @author: 20200312686
 * @date: 2020/7/4 10:37
 */
public class DGWProduct {
    private static final Logger LOG = LoggerFactory.getLogger(DGWProduct.class);
    private static final String TPL = "{\"id\":\"${Product.ID}\",\"name\":\"${Product.Name}\"," +
            "\"desc\":\"${Product.Desc}\",\"vendor\":\"${Product.Vendor}\"," +
            "\"vendorName\":\"${Product.VendorName}\"," +
            "\"namespace\":\"${Product.Namespace}\",\"language\":\"${Product.Language}\"}";
    //项目URL
    private String id;
    private String name;
    private String desc;
    private String vendor;
    private String vendorName;
    private String namespace;
    private String language;
    private String path;
    private boolean createDB=true;
    private List<DGWProModle> models=new ArrayList<>();

    /**
     * 解析模板文件
     * @param path
     * @return
     * @throws DGWException
     */
    public static DGWProduct build(String path) throws DGWException {
        File f=new File(path);
        if(!f.exists()){
            return null;
        }
        try{
            SAXReader reader = new SAXReader();
            Document doc = reader.read(f);
            JSONObject xmlJson= XML.toJSONObject(doc.asXML());
            String transValue= FreeMarkerTemplate.transform(TPL,xmlJson);
            DGWProduct product = new Gson().fromJson(transValue,DGWProduct.class);
            product.path=f.getParent();
            if(StringUtils.isEmpty(product.getId())){
                return null;
            }
            return product;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }

    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public String getVendor() {
        return vendor;
    }

    public String getVendorName() {
        return vendorName;
    }

    public String getNamespace() {
        return namespace;
    }

    public String getLanguage() {
        return language;
    }

    public String getPath() {
        return path;
    }

    public boolean isCreateDB() {
        return createDB;
    }

    public List<DGWProModle> getModels() {
        return models;
    }

    public void addModle(DGWProModle modle){
        this.models.add(modle);
    }
}
