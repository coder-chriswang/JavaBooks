package com.neoway.iot.dgw.common.elastic;

/**
 * @desc: ElasticIndexNameBuilder
 * @author: 20200312686
 * @date: 2020/7/1 15:39
 */
public interface ElasticIndexNameBuilder {
    /**
     * @desc 获取索引名称
     * 内置提供两种索引构建器，一种为根据配置，按整月/年创建索引。另一中直接为一个索引。
     * @param event 数据
     * @return
     */
    String getIndexName(ElasticPoint event);
}
