package com.neoway.iot.dgw.common.elastic;

import java.io.Serializable;

/**
 * <pre>
 *  描述: Es抽象数据结构
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/08 9:40
 */
public class ElasticPoint implements Serializable {

    private static final long serialVersionUID = 3121418862306109845L;
    /**
     * 时间戳毫秒级（System.currentTimeMillis()）
     */
    private long ts;

    /**
     * 存储至ES的对象JSON
     */
    private String value;

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
