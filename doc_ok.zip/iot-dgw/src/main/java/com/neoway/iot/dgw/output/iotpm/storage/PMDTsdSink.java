package com.neoway.iot.dgw.output.iotpm.storage;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.tsd.TSDClient;
import com.neoway.iot.dgw.common.tsd.TSDConfig;
import com.neoway.iot.dgw.common.tsd.TSDPoint;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: PMDBackendTSD
 * @author: 20200312686
 * @date: 2020/7/1 9:53
 */
public class PMDTsdSink extends PMDAbstractSink {
    private static final Logger LOG = LoggerFactory.getLogger(PMDTsdSink.class);
    public static final String TSD_HOST="dgw.output.pm.opentsdb.host";
    public static final String TSD_PORT="dgw.output.pm.opentsdb.port";
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private TSDClient client;
    private DGWConfig env;
    @Override
    public void start(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        super.start(env);
        this.env=env;
        String host=String.valueOf(env.getValue(TSD_HOST));
        String port=String.valueOf(env.getValue(TSD_PORT));
        if(StringUtils.isEmpty(host) || StringUtils.isEmpty(port)){
            LOG.error("启动失败，配置参数:{}或{}不存在",TSD_HOST,TSD_PORT);
            return;
        }
        try{
            int tsdPort=Integer.valueOf(port);
            TSDConfig.Builder builder=new TSDConfig.Builder(host,tsdPort).batchPutCallBack(new PMDPutCallBackFile());
            TSDConfig config=builder.config();
            this.client=new TSDClient(config);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }
        isStarted.set(true);
        LOG.info("pm-out-tsdb-sink启动成功");
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration=new HashMap<>();
        configuration.put(TSD_HOST,env.getValue(TSD_HOST));
        configuration.put(TSD_PORT,env.getValue(TSD_PORT));
        return configuration;
    }

    @Override
    void doWrite(List<TSDPoint> points) {
        try{
            this.client.putSyncWithCallBack(points);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            //TODO 发送告警
        }

    }


}
