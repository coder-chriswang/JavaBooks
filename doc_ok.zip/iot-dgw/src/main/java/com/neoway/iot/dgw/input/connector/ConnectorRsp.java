package com.neoway.iot.dgw.input.connector;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: connector response响应体
 * @author: 20200312686
 * @date: 2020/6/29 17:35
 */
public class ConnectorRsp {
    private Map<String,Object> header=new HashMap<>();
    private Map<String,Object> body=new HashMap<>();
}
