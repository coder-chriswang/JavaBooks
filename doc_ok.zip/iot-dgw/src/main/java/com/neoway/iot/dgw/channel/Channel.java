package com.neoway.iot.dgw.channel;

import com.neoway.iot.dgw.common.DGWContext;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;

import java.util.List;
import java.util.Map;

public interface Channel{
    /**
     * @desc 获取插件名称
     * @return 插件名称
     */
    String name();

    /**
     * @desc 启动
     * @param config
     */
    void start(DGWConfig config);

    /**
     * @desc 停止
     */
    void stop();

    /**
     * @desc 获取配置
     * @return
     */
    Map<String,Object> configuration();

    /**
     * @desc 写数据
     * @param context
     * @throws DGWException
     */
    DGWResponse process(DGWContext context);

    /**
     * @desc 读取数据
     * @return
     * @throws DGWException
     */
    List<DGWContext> take() throws DGWException;

    /**
     * @desc 结果提交
     * @param eventId 事件ID
     * @param topic 订阅主题
     * @param status 消费结果
     * @throws DGWException
     */
    void commit(String eventId,String topic,boolean status) throws DGWException;
}
