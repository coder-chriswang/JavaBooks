package com.neoway.iot.dgw.output.iotpm.storage;

import com.google.common.hash.Hashing;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import org.apache.commons.codec.Charsets;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * @desc: 指标元数据
 * @author: 20200312686
 * @date: 2020/7/20 12:44
 */
public class PmMetaMetric {
    //五中度量类型
    //只有一个返回值，用来记录一些对象的瞬时值，例如某个服务目前开通的城市个数
    private static final String METRIC_TYPE_GAUGES="gauges";
    //计数器，可以增加或减少
    private static final String METRIC_TYPE_COUNTERS="counters";
    //只能自增的计数器，通常用来度量一系列事件发生的比率。例如统计每分钟内多少次请求
    private static final String METRIC_TYPE_METERS="meters";
    //用来度量流数据中value的分布情况，可以计算最大值、最小值、平均值、方差、分位数。
    private static final String METRIC_TYPE_HISTOGRAMS="histograms";
    //计时器，是histograms和meter的组合。典型使用场景：请求时延、磁盘读时延
    private static final String METRIC_TYPE_TIMERS="timers";

    private static final String SPILITE="#";
    //产品域
    private String ns;
    //对象类型
    private String ci;
    //指标
    private String metric;
    //指标组
    private String group;
    //指标组名称
    private String groupName;
    //指标名称
    private String metricName;
    //指标显示类型
    private String type;
    //指标单位
    private String unit;
    //指标描述
    private String desc;
    //指标编码
    private int code;

    public PmMetaMetric() {
    }

    public PmMetaMetric(String metric) {
        this.metric = metric;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public String getMetricName() {
        return metricName;
    }

    public void setMetricName(String metricName) {
        this.metricName = metricName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    /**
     * @desc 编码生成
     */
    public void buildCode(){
        int code=Hashing.murmur3_128().hashString(this.metric, Charsets.UTF_8).asInt();
        this.code=code;
    }

    /**
     * @desc 属性校验
     * @throws DGWException
     */
    public void validate() throws DGWException {
        if(!(this.type.equals(METRIC_TYPE_COUNTERS)
                || this.type.equals(METRIC_TYPE_GAUGES)
                || this.type.equals(METRIC_TYPE_HISTOGRAMS)
                || this.type.equals(METRIC_TYPE_METERS)
                || this.type.equals(METRIC_TYPE_TIMERS))){
            String msg="模型配置错误，错误属性=type,当前值为"+this.type;
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
        if(StringUtils.isEmpty(this.ns)
                || StringUtils.isEmpty(this.ci)
                || StringUtils.isEmpty(this.metric)
                || StringUtils.isEmpty(this.metricName)){
            String msg="模型配置错误，必填属性存在空值";
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
    }

    public Object[] getParam(){
        Object[] param=new Object[]{
                this.getCode(),
                this.getNs(),
                this.getCi(),
                this.getMetric(),
                this.getMetricName(),
                this.getGroup(),
                this.getGroupName(),
                this.getType(),
                this.getUnit(),
                this.getDesc()};
        return param;
    }

    public static PmMetaMetric buildMetaMetric(Map<String,Object> dbResult){
        PmMetaMetric metaMetric=new PmMetaMetric();
        metaMetric.setNs(dbResult.get("ns").toString());
        metaMetric.setCi(dbResult.get("ci").toString());
        metaMetric.setMetric(dbResult.get("metric").toString());
        metaMetric.setMetricName(dbResult.get("metric_name").toString());
        metaMetric.setCode((Integer) dbResult.get("code"));
        metaMetric.setGroup(dbResult.get("group").toString());
        metaMetric.setGroupName(dbResult.get("group_name").toString());
        metaMetric.setType(dbResult.get("type").toString());
        metaMetric.setUnit(dbResult.get("unit").toString());
        return metaMetric;
    }

}
