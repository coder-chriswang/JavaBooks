package com.neoway.iot.dgw.common.freemarker;

import com.google.common.hash.Hashing;
import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
import org.apache.commons.codec.Charsets;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

/**
 * @desc: 用于资源instanceid的生成。hash存在小概率碰撞的情况，看到此处代码的人别怨我。赶时间，后面instanceid走缓存获取。
 * @author: 20200312686
 * @date: 2020/7/14 16:24
 */
public class FreemarkerDgwHash implements TemplateDirectiveModel {
    @Override
    public void execute(Environment environment, Map params, TemplateModel[] templateModels,
                        TemplateDirectiveBody templateDirectiveBody) throws TemplateException, IOException {

        String code=params.get("code").toString();
        long hashCode= Hashing.murmur3_128().hashString(code, Charsets.UTF_8).asLong();
        Writer out=environment.getOut();
        out.write(String.valueOf(hashCode));
    }
}
