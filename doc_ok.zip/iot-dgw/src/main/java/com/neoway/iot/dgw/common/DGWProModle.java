package com.neoway.iot.dgw.common;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.freemarker.FreeMarkerTemplate;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: DGWProModle
 * @author: 20200312686
 * @date: 2020/7/23 11:17
 */
public class DGWProModle {
    private static final Logger LOG = LoggerFactory.getLogger(DGWProduct.class);
    private static final String TPL = "{\"id\":\"${Model.ID}\",\"name\":\"${Model.Name}\"," +
            "\"desc\":\"${Model.Desc}\",\"vendor\":\"${Model.Vendor}\"," +
            "\"vendor_Name\":\"${Model.VendorName}\"}";
    //项目URL
    private String ci="NS";
    private String id;
    private String name;
    private String desc;
    private String vendor;
    private String vendor_Name;
    private String path;
    private List<String> cis=new ArrayList<>();

    /**
     * 解析模板文件
     * @param path
     * @return
     * @throws DGWException
     */
    public static DGWProModle build(String path) throws DGWException {
        File f=new File(path);
        if(!f.exists()){
            LOG.warn("文件不存在:{}",path);
            return null;
        }
        try{
            SAXReader reader = new SAXReader();
            Document doc = reader.read(f);
            JSONObject xmlJson= XML.toJSONObject(doc.asXML());
            String transValue= FreeMarkerTemplate.transform(TPL,xmlJson);
            DGWProModle model = new Gson().fromJson(transValue,DGWProModle.class);
            model.path=f.getParent();
            if(StringUtils.isEmpty(model.getId())){
                return null;
            }
            return model;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }

    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public String getVendor() {
        return vendor;
    }

    public String getVendor_Name() {
        return vendor_Name;
    }

    public String getCi() {
        return ci;
    }

    public String getPath() {
        return path;
    }

    public List<String> getCis() {
        return cis;
    }

    public void addCis(String ci){
        this.cis.add(ci);
    }
    public String getCiString(){
        StringBuilder sb=new StringBuilder();
        int index=0;
        for(String ci:this.cis){
            sb.append(ci);
            index++;
            if(index<this.cis.size()){
                sb.append(",");
            }

        }
        return sb.toString();
    }
    public Map<String,Object> buildColumn(){
        Map<String,Object> column=new HashMap<>();
        column.put("ci",this.ci);
        column.put("id",this.id);
        column.put("name",this.name);
        column.put("desc",this.desc);
        column.put("vendor",this.vendor);
        column.put("vendor_name",this.vendor_Name);
        column.put("cis",this.getCiString());
        return column;
    }
}
