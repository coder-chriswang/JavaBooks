package com.neoway.iot.dgw.common.tsd;

import java.util.List;

/**
 * @desc: TSDResult
 * @author: 20200312686
 * @date: 2020/6/30 19:41
 */
public class TSDResult {
    private List<ErrorPoint> errors;
    private int failed;
    private int success;
    public static class ErrorPoint{
        private TSDPoint datapoint;
        private String error;

    }

    public int getFailed() {
        return failed;
    }

    public int getSuccess() {
        return success;
    }
}
