package com.neoway.iot.dgw.output.iotpm;

/**
 * @desc: PmCmd
 * @author: 20200312686
 * @date: 2020/7/17 15:13
 */
public enum  PmCmd {
    UPLINK_PM_DATA("上报性能数据"),
    SUBCRIBE_DM_DATA("上报性能数据-订阅资源数据"),
    UPLINK_PM_META("注册指标模型"),
    CMD_RULE_COMPUTE("阈值告警计算");
    private final String desc;

    private PmCmd(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
