package com.neoway.iot.dgw.input.connector.restful;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.input.connector.Connector;
import com.neoway.iot.dgw.input.connector.ConnectorReq;
import com.neoway.iot.dgw.input.connector.ConnectorRsp;
import org.reactivestreams.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.HttpHandler;
import org.springframework.http.server.reactive.ReactorHttpHandlerAdapter;
import org.springframework.web.reactive.function.server.*;
import reactor.ipc.netty.http.server.HttpServer;
import reactor.ipc.netty.http.server.HttpServerOptions;
import reactor.ipc.netty.http.server.HttpServerRequest;
import reactor.ipc.netty.http.server.HttpServerResponse;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiFunction;

/**
 * @desc: HTTP Server
 * @author: 20200312686
 * @date: 2020/6/30 9:53
 */
public class HTTPConnector extends Connector {
    private static final Logger LOG = LoggerFactory.getLogger(HTTPConnector.class);
    private static final String CF_PORT="dgw.input.restful.server.port";
    private static final String CF_ADDRESS="dgw.input.restful.server.bind";
    private static final String CF_HEAD_SIZE="dgw.input.restful.server.header_size";
    private static final String CF_BUFFER_SIZE="dgw.input.restful.server.buffer_size";
    private static final String CF_TRUNCK_SIZE="dgw.input.restful.server.trunck_size";
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private DGWConfig env;
    private String bindAddress;
    private int port;
    private int headSize;
    private int bufferSize;
    private int trunckSize;
    @Override
    public String name() {
        return "input-connector-http";
    }

    @Override
    public void start(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        this.env=env;
        this.bindAddress=(String)env.getValue(CF_ADDRESS);
        this.port= (Integer) env.getValue(CF_PORT);
        this.headSize=(Integer)env.getValue(CF_HEAD_SIZE);
        this.bufferSize=(Integer) env.getValue(CF_BUFFER_SIZE);
        this.trunckSize=(Integer) env.getValue(CF_TRUNCK_SIZE);
        LOG.info("HTTPConnector开始启动");
        try{
            RouterFunction<ServerResponse> route = buildResultRouter();
            HttpHandler httpHandler = RouterFunctions.toHttpHandler(route);
            ReactorHttpHandlerAdapter httpHandlerAdapter = new ReactorHttpHandlerAdapter(httpHandler);
            HttpServer server = HttpServer.builder().bindAddress(this.bindAddress)
                    .port(this.port)
                    .options(builder1 -> HttpServerOptions.builder().initialBufferSize(this.bufferSize).maxHeaderSize(this.headSize).maxChunkSize(this.trunckSize))
                    .build();
            // start the netty http server
            server.newHandler((BiFunction)httpHandlerAdapter).block();

        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }
        isStarted.set(true);
        LOG.info("HTTPConnector启动成功");

    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration=new HashMap<>();
        configuration.put(CF_ADDRESS,env.getValue(CF_ADDRESS));
        configuration.put(CF_PORT,env.getValue(CF_PORT));
        configuration.put(CF_HEAD_SIZE,env.getValue(CF_HEAD_SIZE));
        configuration.put(CF_BUFFER_SIZE,env.getValue(CF_BUFFER_SIZE));
        configuration.put(CF_TRUNCK_SIZE,env.getValue(CF_TRUNCK_SIZE));
        return configuration;
    }

    /**
     * @desc 创建Restful路由
     * @return
     */
    private RouterFunction<ServerResponse> buildResultRouter() {
        return RouterFunctions
                .route(RequestPredicates.POST("/uplink")
                        .and(RequestPredicates.accept(MediaType.APPLICATION_JSON)), UplinkHandler::uplinkEvent);
    }

    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        return null;
    }
}
