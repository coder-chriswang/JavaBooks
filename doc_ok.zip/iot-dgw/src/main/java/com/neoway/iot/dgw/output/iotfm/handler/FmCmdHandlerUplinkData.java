package com.neoway.iot.dgw.output.iotfm.handler;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotfm.storage.FMDPoint;
import com.neoway.iot.dgw.output.iotfm.storage.FMDSink;
import com.neoway.iot.dgw.output.iotfm.FmCmd;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: FmCmdHandlerUplinkData
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 16:41
 */
public class FmCmdHandlerUplinkData implements FmCmdHandler{
    private static final Logger LOG = LoggerFactory.getLogger(FmCmdHandlerUplinkData.class);

    private FMDSink sink;

    public FmCmdHandlerUplinkData (FMDSink sink) {
        this.sink = sink;
    }

    @Override
    public String name() {
        return FmCmd.UPLINK_FM_DATA.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> events = event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(events)){
            return response;
        }
        Gson gson = new Gson();
        try{
            String pointArrJson = gson.toJson(events);
            List<FMDPoint> points = gson.fromJson(pointArrJson,new TypeToken<List<FMDPoint>>(){}.getType());
            this.sink.write(points);
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }
}
