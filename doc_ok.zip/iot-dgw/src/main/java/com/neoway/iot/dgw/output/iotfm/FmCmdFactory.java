package com.neoway.iot.dgw.output.iotfm;

import com.neoway.iot.dgw.output.iotfm.handler.FmCmdHandler;
import com.neoway.iot.dgw.output.iotfm.handler.FmCmdHandlerUplinkData;
import com.neoway.iot.dgw.output.iotfm.handler.FmCmdHandlerUplinkMeta;
import com.neoway.iot.dgw.output.iotfm.storage.FMDSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * <pre>
 *  描述: FmFactory
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 16:38
 */
public class FmCmdFactory {
    private static final Logger LOG = LoggerFactory.getLogger(FmCmdFactory.class);
    private static Map<FmCmd, FmCmdHandler> handlers = new HashMap<>();

    public static FmCmdHandler buildHandler(String cmdId, FMDSink sink){
        FmCmd cmd = FmCmd.valueOf(cmdId.toUpperCase());
        FmCmdHandler handler = handlers.get(cmd);
        if(null != handler){
            return handler;
        } else if(cmd == FmCmd.UPLINK_FM_DATA) {
            handler = new FmCmdHandlerUplinkData(sink);
        } else if(cmd == FmCmd.UPLINK_FM_META) {
            handler = new FmCmdHandlerUplinkMeta(sink);
        } else {
            return null;
        }
        LOG.info("cmdId={},desc={}",cmd.name(),cmd.getDesc());
        handlers.put(cmd,handler);
        return handler;
    }
}
