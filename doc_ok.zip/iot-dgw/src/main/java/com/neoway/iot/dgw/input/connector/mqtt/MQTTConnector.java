package com.neoway.iot.dgw.input.connector.mqtt;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.input.connector.Connector;
import com.neoway.iot.dgw.input.connector.ConnectorReq;
import com.neoway.iot.dgw.input.connector.ConnectorRsp;
import org.eclipse.paho.client.mqttv3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class MQTTConnector extends Connector {
    private static final Logger LOG = LoggerFactory.getLogger(MQTTConnector.class);
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private MqttClient client;
    private DGWConfig env;
    @Override
    public void start(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        this.env=env;
        LOG.info("MQTTClient开始启动");
        MQTTClient client=new MQTTClient(env);

        client.init(this);
        this.client=client.getClient();
        isStarted.set(true);
        super.start(env);
        LOG.info("MQTTClient启动成功");
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration=new HashMap<>();
        configuration.put(MQTTClient.MQTT_URI,env.getValue(MQTTClient.MQTT_URI));
        configuration.put(MQTTClient.MQTT_CLIENTID,env.getValue(MQTTClient.MQTT_CLIENTID));
        configuration.put(MQTTClient.MQTT_KEEPALIVED,env.getValue(MQTTClient.MQTT_KEEPALIVED));
        configuration.put(MQTTClient.MQTT_CONNTIMEOUT,env.getValue(MQTTClient.MQTT_CONNTIMEOUT));
        configuration.put(MQTTClient.MQTT_RECONNECT,env.getValue(MQTTClient.MQTT_RECONNECT));
        configuration.put(MQTTClient.MQTT_USER,env.getValue(MQTTClient.MQTT_USER));
        configuration.put(MQTTClient.MQTT_PWD,env.getValue(MQTTClient.MQTT_PWD));
        configuration.put(MQTTClient.MQTT_CONNTIMEOUT,env.getValue(MQTTClient.MQTT_CONNTIMEOUT));
        configuration.put(MQTTClient.MQTT_TOPIC_MODEL_SUBCRIBE,env.getValue(MQTTClient.MQTT_TOPIC_MODEL_SUBCRIBE));
        return configuration;
    }

    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        return null;
    }

    @Override
    public String name() {
        return "input-connector-mqtt";
    }

}
