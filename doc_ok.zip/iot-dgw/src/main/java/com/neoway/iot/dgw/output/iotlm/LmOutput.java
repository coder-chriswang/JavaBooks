package com.neoway.iot.dgw.output.iotlm;

import com.neoway.iot.dgw.common.DGWCmd;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWHeader;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.output.AbstractOutput;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotlm.handler.LmCmdHandler;
import com.neoway.iot.dgw.output.iotlm.storage.LMDElasticSink;
import com.neoway.iot.dgw.output.iotlm.storage.LMDMysqlSink;
import com.neoway.iot.dgw.output.iotlm.storage.LMDSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * <pre>
 *  描述: LmOutput
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/07 11:40
 */
public class LmOutput extends AbstractOutput {
    private static final Logger LOG = LoggerFactory.getLogger(LmOutput.class);
    private static final String BACKEND = "dgw.output.lm.backend";
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private LMDSink sink;

    @Override
    public void start(DGWConfig config) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        String backend = String.valueOf(config.getValue(BACKEND));
        if (LMDSink.BACKEND_MYSQL.equals(backend)) {
            sink = new LMDMysqlSink();
        } else if (LMDSink.BACKEND_ELASTIC.equals(backend)) {
            sink = new LMDElasticSink();
        } else {
            sink = new LMDMysqlSink();
        }
        sink.start(config);
        super.start(config);

    }
    @Override
    public DGWResponse doProcess(OutputEvent event) throws DGWException{
        String topic = event.getHeader().getTopic();
        LmCmdHandler handler;
        if (DGWCmd.MSG_LM.name().equals(topic)) {
            DGWHeader head = event.getHeader();
            handler = LmCmdFactory.buildHandler(head.getCmdId(),this.sink);
        } else {
            handler = LmCmdFactory.buildHandler(topic, this.sink);
        }
        DGWResponse rsp = new DGWResponse();
        if(null == handler){
            LOG.warn("Topic非法：topic={}",topic);
            return rsp;
        }
        return handler.execute(event);
    }

    @Override
    public String name() {
        return "output-plugin-lm";
    }

    @Override
    public List<String> getTopics() {
        return Arrays.asList(DGWCmd.UPLINK_LM_DATA.name(),
                DGWCmd.UPLINK_LM_META.name(),
                DGWCmd.MSG_LM.name());
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }
}
