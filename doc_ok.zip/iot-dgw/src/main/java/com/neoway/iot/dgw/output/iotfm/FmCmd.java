package com.neoway.iot.dgw.output.iotfm;

/**
 * <pre>
 *  描述: FmCmd
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 16:37
 */
public enum FmCmd {

    UPLINK_FM_DATA("上报告警数据"),
    UPLINK_FM_META("静态告警数据");
    private final String desc;

    private FmCmd(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
