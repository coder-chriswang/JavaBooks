package com.neoway.iot.dgw.output.iotpm.handler;

import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;

/**
 * @desc: PmCmdHandler
 * @author: 20200312686
 * @date: 2020/7/17 15:06
 */
public interface PmCmdHandler {
    /**
     * @desc
     * @return cmd指令名称
     */
    String name();

    /**
     * @desc 指令处理
     * @param event 数据
     * @return
     */
    DGWResponse execute(OutputEvent event);
}
