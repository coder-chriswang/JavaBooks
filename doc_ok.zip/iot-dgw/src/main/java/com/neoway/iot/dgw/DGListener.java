package com.neoway.iot.dgw;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.event.DGWEvent;
import com.neoway.iot.dgw.common.event.DGWEventBus;
import com.neoway.iot.dgw.input.scheduler.ScheudlerAtoExecutor;
import com.neoway.iot.dgw.input.template.MetaTemplate;
import com.neoway.iot.dgw.input.template.TemplateManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @desc: springboot事件监听器。用于监听启动、销毁等事件来完成业务初始化
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
@Component
public class DGListener implements ApplicationListener {
    private static final Logger LOG = LoggerFactory.getLogger(DGListener.class);
    private static final String SCHEDULER_NAME="input-template-init";
    private static final int DEFAULT_INTERVAL=60;
    private List<DGLifecycleComponent> comps=new ArrayList<DGLifecycleComponent>();
    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        if(event instanceof ApplicationReadyEvent){
            LOG.info("DGW开始业务初始化",event.toString());
            this.initExecuteModel();
            this.initExecuteTemplate();
            this.initRunner(DEFAULT_INTERVAL);
            LOG.info("DGW业务初始化成功",event.toString());
        }
    }

    /**
     * @desc 模型包自动注册
     */
    private void initExecuteModel(){
        TemplateManager manager=TemplateManager.getInstance();
        Map<String, DGWProduct> productMap=manager.getProMap();
        Gson gson=new Gson();
        for(DGWProduct product:productMap.values()){
            String json=gson.toJson(product);
            Map<String,Object> message=gson.fromJson(json,Map.class);
            DGWEvent event=DGWEvent.builder()
                    .header(product.getId(),DGWCmd.UPLINK_DM_META.name(),"init")
                    .source(this.getClass().getName()).message(message).build();
            DGWEventBus.post(event);
            LOG.debug("发送的消息={}",new Gson().toJson(event));
        }
        try{
            Thread.sleep(3000);
        }catch (InterruptedException e){
            LOG.error(e.getMessage(),e);
        }

    }

    /**
     * @desc 静默自动化执行模板
     */
    private void initExecuteTemplate(){
        //2:静默执行模板自动执行
        TemplateManager manager=TemplateManager.getInstance();
        List<MetaTemplate> tpls=manager.getInitTemplateQueue();
        for(MetaTemplate template:tpls){
            DGWRequest request=new DGWRequest(template.getPro(),template.getId());
            DGWResponse rsp=ScheudlerAtoExecutor.uplink(request);
            if(rsp.getCode().equals(DGWCodeEnum.SUCCESS_CODE.getCode())){
                manager.commit(template);
            }else{
                LOG.error("模板静默自动化执行失败,一分钟后重试,错误码={},错误原因={},产品={}，模板ID={}",
                        rsp.getCode(),rsp.getMsg(),request.getProduct(),request.getTemplateid());
            }
        }
    }

    /**
     * @desc 定时执行初始化
     * @param interval
     * @return 定时器服务
     */
    public ScheduledExecutorService initRunner(int interval){
        ScheduledExecutorService initRunner = Executors.newSingleThreadScheduledExecutor(
                (r) -> {
                    Thread t = new Thread(r, SCHEDULER_NAME);
                    t.setDaemon(true);
                    return t;
                }
        );
        initRunner.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try{
                    initExecuteTemplate();
                }catch (Exception e){
                    //TODO 发送
                }

            }
        }, 0, interval, TimeUnit.SECONDS);
        return initRunner;
    }
}
