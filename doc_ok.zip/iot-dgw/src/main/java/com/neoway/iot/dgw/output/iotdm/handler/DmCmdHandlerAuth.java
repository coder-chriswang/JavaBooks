package com.neoway.iot.dgw.output.iotdm.handler;

import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotdm.DmCmd;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataColumn;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

/**
 * @desc: 设备登录鉴权
 * @author: 20200312686
 * @date: 2020/7/17 10:21
 */
public class DmCmdHandlerAuth implements DmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DmCmdHandlerAuth.class);
    @Override
    public String name() {
        return DmCmd.CMD_AUTH.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> values=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(values)){
            return response;
        }
        Map<String,Object> value=values.get(0);
        String ns=event.getHeader().getProduct();
        //根据资源ID查询热点缓存数据
        String ci=(String)value.get("ci");
        String tenent="";
        if(value.containsKey("tenent")){
            tenent=(String)value.get("tenent");
        }else{
            tenent= DMMetaCI.DEFAULT_TENENT;
        }
        String authCode=(String)value.get("auth_code");
        try{
            DMRunner runner=DMRunner.getInstance();
            DMDataPoint point=DMDataPoint.builder(ns,tenent,ci);
            point=point.buildColumns(value);
            point=runner.getHotByPrimary(point);
            //资源不存在，则激活失败
            if(null == point){
                response.setCode("101");
                response.setMsg("资源不存在");
                return response;
            }
            DMDataColumn column=point.getDataColumn("auth_code");
            if(null == column){
                String errMsgTpl="模型中不存在auth_code属性。产品域={0},tenent={1},ci={1}";
                String errMsg= MessageFormat.format(errMsgTpl,ns,tenent,ci);
                LOG.error(errMsg);
                response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
                response.setMsg(errMsg);
                return response;
            }
            if(authCode.equals(String.valueOf(column.value))){
                //更新最后连接时间和在线状态
            }else{
                response.setCode("102");
                response.setMsg("鉴权码无效");
                //更新最后连接时间和在线状态
            }
        }catch (RuntimeException e){
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
        }
        return response;
    }
}
