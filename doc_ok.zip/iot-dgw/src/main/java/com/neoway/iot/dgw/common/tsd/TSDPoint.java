package com.neoway.iot.dgw.common.tsd;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @desc: TSDPoint
 * @author: 20200312686
 * @date: 2020/6/30 18:39
 */
public class TSDPoint {
    private String metric;
    private Map<String, String> tags = new HashMap<>();
    private Object value;
    private long timestamp;
    public static MetricBuilder metric(String metric) {
        return new MetricBuilder(metric);
    }
    public static class MetricBuilder {
        private String metric;
        private Map<String, String> tags = new HashMap<>();
        private Object value;
        private long timestamp;
        public MetricBuilder(String metric) {
            if (StringUtils.isBlank(metric)) {
                throw new IllegalArgumentException("metric不能为空");
            }
            this.metric = metric;
        }
        public MetricBuilder value(long timestamp, Object value) {
            if (timestamp == 0) {
                throw new IllegalArgumentException("timestamp必须大于0");
            }
            Objects.requireNonNull(value);
            this.timestamp = timestamp;
            this.value = value;
            return this;
        }
        public MetricBuilder tag(final String tagName, final String value) {
            if (StringUtils.isNoneBlank(tagName) && StringUtils.isNoneBlank(value)) {
                tags.put(tagName, value);
            }
            return this;
        }
        public MetricBuilder tag(final Map<String, String> tags) {
            if (!MapUtils.isEmpty(tags)) {
                this.tags.putAll(tags);
            }
            return this;
        }

        public TSDPoint build() {
            TSDPoint point = new TSDPoint();
            point.metric = this.metric;
            if (MapUtils.isEmpty(tags)) {
                throw new IllegalArgumentException("tags不能为空");
            }
            point.tags = this.tags;
            point.timestamp = this.timestamp;
            point.value = this.value;
            return point;
        }

    }

    public String getMetric() {
        return metric;
    }

    public Map<String, String> getTags() {
        return tags;
    }

    public Object getValue() {
        return value;
    }

    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        try{
            return TSDJson.writeValueAsString(this);
        }catch (JsonProcessingException e){
            return "";
        }

    }
}
