package com.neoway.iot.dgw.input.template;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @desc: DGW 模板存储接口实现-内存模式
 * @author: 20200312686
 * @date: 2020/6/23 10:43
 */
public class TemplateStorageMem implements TemplateStorage {
    private static final String INDEX_SPLITE="#$@";
    private static TemplateStorageMem instance = null;
    private Map<String,Map<String,MetaTemplate>> indexMap=
            new ConcurrentHashMap<String,Map<String,MetaTemplate>>();
    private TemplateStorageMem() {

    }

    public static TemplateStorageMem getInstance() {
        if (instance == null) {
            synchronized (TemplateStorageMem.class) {
                if (instance == null) {
                    instance = new TemplateStorageMem();
                }
            }
        }
        return instance;
    }

    /**
     * 生成模板唯一标识
     * @param pro
     * @param id
     * @return
     */
    private String gernateIndex(String pro,String id){
        StringBuilder sb=new StringBuilder();
        sb.append(pro).append(INDEX_SPLITE).append(id);
        return sb.toString();
    }

    public void addTempate(MetaTemplate tpl) {
        String index=gernateIndex(tpl.getPro(),tpl.getId());
        Map<String,MetaTemplate> tplMap=indexMap.get(tpl.getPro());
        if(null == tplMap){
            tplMap=new HashMap<String, MetaTemplate>();
            indexMap.put(tpl.getPro(),tplMap);
        }
        tplMap.put(index,tpl);
    }

    public void deleteTemplate(String ns, String id) {
        String index=gernateIndex(ns,id);
        Map<String,MetaTemplate> tplMap=indexMap.get(ns);
        if(null == tplMap){
            return;
        }
        tplMap.remove(index);
    }

    public List<MetaTemplate> listTemplates(String ns) {
        Map<String,MetaTemplate> tplMap=indexMap.get(ns);
        Collection<MetaTemplate> cols=tplMap.values();
        Gson gson=new Gson();
        return gson.fromJson(gson.toJson(cols),new TypeToken<List<MetaTemplate>>() {}.getType());
    }

    public MetaTemplate getTemplate(String ns, String id) {
        String index=gernateIndex(ns,id);
        Map<String,MetaTemplate> tplMap=indexMap.get(ns);
        if(null == tplMap){
            return null;
        }
        Gson gson=new Gson();
        return gson.fromJson(gson.toJson(tplMap.get(index)),MetaTemplate.class);
    }

    public List<MetaTemplate> listAll() {
        List<MetaTemplate> values=new ArrayList<MetaTemplate>();
        Gson gson=new Gson();
        for(Map<String,MetaTemplate> map:indexMap.values()){
            values.addAll(gson.fromJson(gson.toJson(map.values()),new TypeToken<List<MetaTemplate>>() {}.getType()));
        }
        return values;
    }

    public void clean() {
        indexMap.clear();
    }
}
