package com.neoway.iot.dgw.common;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @desc: DGWRequest
 * @author: 20200312686
 * @date: 2020/6/23 9:30
 */
public class DGWRequest {
    private String product;
    private String templateid;
    private String reqId;
    private long ts;
    private String message;
    private Map<String,Object> data=new HashMap<>();

    public DGWRequest(){
        this.reqId= UUID.randomUUID().toString();
        this.ts=System.currentTimeMillis();
    }
    public DGWRequest(String product, String templateid) {
        this.product = product;
        this.templateid = templateid;
        this.reqId= UUID.randomUUID().toString();
        this.ts=System.currentTimeMillis()/1000L;
    }

    public String getReqId() {
        return reqId;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getTemplateid() {
        return templateid;
    }

    public void setTemplateid(String templateid) {
        this.templateid = templateid;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public long getTs() {
        return ts;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

