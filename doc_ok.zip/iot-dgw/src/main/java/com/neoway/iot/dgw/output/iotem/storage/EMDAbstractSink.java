package com.neoway.iot.dgw.output.iotem.storage;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.jdbc.JdbcPool;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * @desc: EMDAbstractSink
 * @author: 20200312686
 * @date: 2020/7/20 17:09
 */
public abstract class EMDAbstractSink implements EMDSink {
    private static final Logger LOG = LoggerFactory.getLogger(EMDAbstractSink.class);
    //建表语句
    public static final String CREATE_TABLE_META =
            "CREATE TABLE IF NOT EXISTS EM_META_EVENT ( "
                    + "`ns` VARCHAR(64) NOT NULL, "
                    + "`event_id` int(10) NOT NULL, "
                    + "`event_name` VARCHAR(64) NOT NULL, "
                    + "`category` VARCHAR(32) NOT NULL, "
                    + "`type` VARCHAR(32) NOT NULL, "
                    + "`severity` VARCHAR(32) NOT NULL, "
                    + "PRIMARY KEY(`ns`,`event_id`) "
                    + " ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='事件元数据' ROW_FORMAT=DYNAMIC;";

    //批量插入语句
    public static final String BATCH_INSERT_META=
            "REPLACE INTO EM_META_EVENT(`ns`,`event_id`,`event_name`,`category`,`type`,`severity`) VALUES(?,?,?,?,?,?)";
    public static final String GET_META=
            "SELECT * FROM EM_META_EVENT WHERE EVENT_ID=?";
    public static final String QUERY_META=
            "SELECT * FROM EM_META_EVENT";

    public static final String JDBC_URI = "dgw.output.em.mysql.uri";
    public static final String JDBC_MAX_CONN = "dgw.output.em.mysql.max_conn";
    public static final String JDBC_USER = "dgw.output.em.mysql.user";
    public static final String JDBC_PWD = "dgw.output.em.mysql.pwd";
    public static final String JDBC_CONN_TIMEOUT = "dgw.output.em.mysql.conn_timeout";
    public static final String JDBC_IDEL_TIMEOUT = "dgw.output.em.mysql.idel_timeout";
    public static final String JDBC_MIN_NUM = "dgw.output.em.mysql.min_conn";
    protected JdbcPool client;
    protected DGWConfig env;

    //元数据缓存
    private LoadingCache<Integer, EMMeta> metaCache;

    @Override
    public void start(DGWConfig env) throws DGWException {
        try {
            JdbcPool.Builder builder = new JdbcPool.Builder();
            this.client = builder.jdbcUri(env.getValue(JDBC_URI).toString()).jdbcUser(env.getValue(JDBC_USER).toString())
                    .jdbcPwd(env.getValue(JDBC_PWD).toString()).jdbcMaxConn(Integer.valueOf(env.getValue(JDBC_MAX_CONN).toString()))
                    .jdbcMinConn(Integer.valueOf(env.getValue(JDBC_MIN_NUM).toString()))
                    .jdbcConnTimeOut(Integer.valueOf(env.getValue(JDBC_CONN_TIMEOUT).toString()))
                    .jdbcIdelTimeOut(Integer.valueOf(env.getValue(JDBC_IDEL_TIMEOUT).toString()))
                    .jdbcReadOnly(false).jdbcAutoCommit(true).build();
            this.client.start();
            this.env=env;
            this.createTableMeta();
            metaCache= CacheBuilder.newBuilder()
                    .maximumSize(100)
                    .recordStats()
                    .initialCapacity(100)
                    .build(new CacheLoader<Integer, EMMeta>() {
                        @Override
                        public EMMeta load(Integer eventId) throws Exception {
                            LOG.info("EventMeta缓存不存在，从数据库加载:K={}",eventId);
                            EMMeta meta=loadMeta(eventId);
                            return meta;
                        }
                    });
            this.loadMetas();

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new DGWException("", e.getMessage());
        }
    }
    /**
     * @desc 创建元数据表
     * @throws SQLException
     */
    private void createTableMeta() throws SQLException {
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        runner.update(CREATE_TABLE_META);
    }
    private EMMeta loadMeta(int eventId) throws SQLException{
        Object[] param=new Object[]{eventId};
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        Map<String,Object> result=runner.query(GET_META,new MapHandler(),param);
        EMMeta metaMetric= EMMeta.buildMeta(result);
        return metaMetric;
    }
    private void loadMetas() throws Exception{
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        List<Map<String,Object>> eventMaps=runner.query(QUERY_META,new MapListHandler());
        if(CollectionUtils.isEmpty(eventMaps)){
            return;
        }
        for(Map<String,Object> eventMap:eventMaps){
            EMMeta meta= EMMeta.buildMeta(eventMap);
            metaCache.put(meta.getEventId(),meta);
        }
    }

    /**
     * 模型注册
     * @param metas
     * @throws DGWException
     */
    public void registerMeta(List<EMMeta> metas) throws DGWException{
        if(CollectionUtils.isEmpty(metas)){
            return;
        }
        Object[][] params=new Object[metas.size()][];
        int index=0;
        for(EMMeta meta:metas){
            params[index]=meta.getParam();
            index++;
        }
        try{
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            runner.batch(BATCH_INSERT_META,params);
        }catch (SQLException e){
            LOG.error(e.getSQLState(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }
    }

    /**
     * @desc 获取meta信息
     * @param eventId 事件ID
     * @return
     * @throws DGWException
     */
    public EMMeta getMeta(int eventId){
        try{
            return metaCache.get(eventId);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return null;
        }
    }

    @Override
    public void write(List<EMDPoint> points) throws DGWException {
        // 数据补齐
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        for(EMDPoint point:points){
            EMMeta meta=this.getMeta(point.getEventId());
            if(null == meta){
                continue;
            }
            point.setEventCategory(meta.getEventCategory());
            point.setEventName(meta.getEventName());
            point.setEventSeverity(meta.getEventSeverity());
            point.setEventType(meta.getEventType());
        }
        doWrite(points);
    }
    abstract void doWrite(List<EMDPoint> points) throws DGWException;

}
