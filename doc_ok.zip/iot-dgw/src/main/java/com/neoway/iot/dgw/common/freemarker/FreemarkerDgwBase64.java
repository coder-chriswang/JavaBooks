package com.neoway.iot.dgw.common.freemarker;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
import java.io.IOException;
import java.io.Writer;
import java.util.Base64;
import java.util.Map;

/**
 * @desc: FreemarkerDgwBase64
 * @author: 20200312686
 * @date: 2020/7/21 9:31
 */
public class FreemarkerDgwBase64 implements TemplateDirectiveModel {
    private Base64.Encoder encoder=Base64.getEncoder();
    @Override
    public void execute(Environment environment, Map params, TemplateModel[] templateModels, TemplateDirectiveBody templateDirectiveBody) throws TemplateException, IOException {
        String content=params.get("content").toString();
        byte[] contentByte=content.getBytes("UTF-8");
        String result=encoder.encodeToString(contentByte);
        Writer out=environment.getOut();
        out.write(result);
    }
}
