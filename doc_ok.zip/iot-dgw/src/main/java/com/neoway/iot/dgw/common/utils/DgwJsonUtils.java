package com.neoway.iot.dgw.common.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collection;

/**
 * @desc: DgwJsonUtils
 * @author: 20200312686
 * @date: 2020/7/20 20:11
 */
public class DgwJsonUtils {
    private static final ObjectMapper instance;
    static {
        instance = new ObjectMapper();
        // 支持java8
        instance.registerModule(new JavaTimeModule())
                .registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module());
        instance.findAndRegisterModules();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        instance.setDateFormat(dateFormat);
        // 允许对象忽略json中不存在的属性
        instance.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        // 允许出现特殊字符和转义符
        instance.configure(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS, true);
        // 允许出现单引号
        instance.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
        // 忽视为空的属性
        instance.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

    }

    /***
     * 将对象序列化为json字符串
     * @param value 具体对象
     * @return
     * @throws JsonProcessingException
     */
    public static String writeValueAsString(Object value) throws JsonProcessingException {
        return instance.writeValueAsString(value);
    }

    /***
     * 将json字符串反序列化为T类型的对象
     * @param content json字符串
     * @param valueType 数据类型
     * @param <T>
     * @return
     * @throws IOException
     */
    public static <T> T readValue(String content, Class<T> valueType) throws IOException {
        return instance.readValue(content, valueType);
    }

    /***
     * 将json反序列化为集合，集合类型是collectionClass，泛型是elementClass
     * @param content json字符串
     * @param collectionClass 集合类型
     * @param elementClass  泛型
     */
    public static <T> T readValue(String content, Class<? extends Collection> collectionClass,
                                  Class<?> elementClass) throws IOException {
        CollectionType collectionType = instance.getTypeFactory()
                .constructCollectionType(collectionClass, elementClass);
        return instance.readValue(content, collectionType);
    }
}
