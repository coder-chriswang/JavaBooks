package com.neoway.iot.dgw.output.iotem;

/**
 * @desc: EmCmd
 * @author: 20200312686
 * @date: 2020/7/20 17:11
 */
public enum EmCmd {
    UPLINK_EM_DATA("上报事件数据"),
    UPLINK_EM_META("注册事件模型");
    private final String desc;

    private EmCmd(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
