package com.neoway.iot.dgw.input.template;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWRequest;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.freemarker.FreeMarkerTemplate;
import com.neoway.iot.dgw.common.utils.DGWUtils;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: MetaEvent
 * @author: 20200312686
 * @date: 2020/7/20 18:59
 */
public class MetaTemplateEvent {
    private static final Logger LOG = LoggerFactory.getLogger(MetaTemplateEvent.class);
    private static final String TPL = "<#if template.event??>${template.event}</#if>";
    //request模板
    private String eventText;

    public String getEventText() {
        return eventText;
    }
    public static MetaTemplateEvent build(Map<String,Object> data) throws DGWException {
        try{
            String transValue= FreeMarkerTemplate.transform(TPL,data);
            MetaTemplateEvent event = new MetaTemplateEvent();
            event.eventText= DGWUtils.replaceBlank(transValue);
            if(StringUtils.isEmpty(event.getEventText())){
                return null;
            }
            return event;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }
    }
    /**
     * 模板翻译
     * @param req
     * @return
     * @throws DGWException
     */
    public String transfter(DGWRequest req, DGWResponse response) throws DGWException{
        try {
            Map<String,Object> contextMap=new HashMap<>();
            contextMap.put("request",req);
            contextMap.put("response",response);
            return FreeMarkerTemplate.transform(this.getEventText(),contextMap);
        } catch (IOException e) {
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        } catch (TemplateException e) {
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        } catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }
    }
}
