package com.neoway.iot.dgw.output.iotem;

import com.neoway.iot.dgw.output.iotem.handler.EmCmdHandler;
import com.neoway.iot.dgw.output.iotem.handler.EmCmdHandlerUplinkData;
import com.neoway.iot.dgw.output.iotem.handler.EmCmdHandlerUplinkMeta;
import com.neoway.iot.dgw.output.iotem.storage.EMDSink;
import com.neoway.iot.dgw.output.iotpm.PmCmd;
import com.neoway.iot.dgw.output.iotpm.handler.*;
import com.neoway.iot.dgw.output.iotpm.storage.PMDSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: DmCmdFactory
 * @author: 20200312686
 * @date: 2020/7/17 10:33
 */
public class EmCmdFactory {
    private static final Logger LOG = LoggerFactory.getLogger(EmCmdFactory.class);
    private static Map<EmCmd,EmCmdHandler> handlers=new HashMap<>();
    /**
     * @desc
     * @param cmdId
     * @return
     */
    public static EmCmdHandler buildHandler(String cmdId, EMDSink sink){
        EmCmd cmd=EmCmd.valueOf(cmdId.toUpperCase());;
        EmCmdHandler handler=handlers.get(cmd);
        if(null != handler){
            return handler;
        }else if(cmd == EmCmd.UPLINK_EM_DATA) {
            handler=new EmCmdHandlerUplinkData(sink);
        }else if(cmd == EmCmd.UPLINK_EM_META) {
            handler=new EmCmdHandlerUplinkMeta(sink);
        }else{
            return null;
        }
        LOG.info("cmdId={},desc={}",cmd.name(),cmd.getDesc());
        handlers.put(cmd,handler);
        return handler;
    }
}
