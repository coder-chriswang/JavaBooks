package com.neoway.iot.dgw.common.utils;

import com.google.common.hash.Hashing;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;
import org.apache.commons.codec.Charsets;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @desc: DGWUtils
 * @author: 20200312686
 * @date: 2020/7/6 9:47
 */
public class DGWUtils {
    private static final Logger LOG = LoggerFactory.getLogger(DGWUtils.class);

    public static String replaceBlank(String str){
        String dest="";
        if(str == null){
            return dest;
        }
        Pattern p=Pattern.compile("\\s{2,}|\t|\r|\n");
        Matcher m=p.matcher(str);
        dest=m.replaceAll("");
        return StringUtils.stripToEmpty(StringUtils.trimToEmpty(dest));
    }

    public static Gson getJsonUtil(){
        Gson gson=new GsonBuilder()
                .setDateFormat("yyyy-MM-dd HH:mm:ss")
                .setLongSerializationPolicy(LongSerializationPolicy.STRING)
                .create();
        return gson;

    }
    public static void main(String[] args) {
        String input="hello nihao";
        long code=Hashing.murmur3_128().hashString(input, Charsets.UTF_8).asLong();
        Map<String,Object> test=new HashMap<>();
        test.put("code",-296524923920622784L);
        System.out.println(new Gson().toJson(test));
        System.out.println(DGWUtils.getJsonUtil().toJson(test));
    }

}
