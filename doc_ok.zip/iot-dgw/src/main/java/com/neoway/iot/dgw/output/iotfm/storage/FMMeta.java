package com.neoway.iot.dgw.output.iotfm.storage;

import com.google.common.hash.Hashing;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import org.apache.commons.codec.Charsets;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * <pre>
 *  描述: FMMeta
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/22 18:39
 */
public class FMMeta {
    private static final String CATEGORY_OM="OM";
    private static final String CATEGORY_DEVICE="Device";
    private static final String SEVERITY_MAJOR="Major";
    private static final String SEVERITY_NORMAL="Normal";

    private int code;

    private String ci;

    private String ns;
    /**
     * 告警id
     */
    private String alarmId;
    /**
     * 告警名称
     */
    private String alarmName;

    /**
     * 事件分类 【OM,Device】
     */
    private String alarmCategory;

    /**
     * 事件级别 【Major，Normal】
     */
    private String alarmSeverity;

    /**
     * 告警引发原因
     */
    private String alarmCauseText;

    /**
     * 告警修复建议
     */
    private String alarmRepairText;

    /**
     * 告警商业影响
     */
    private String alarmEffectBusiness;

    /**
     * 告警设备影响
     */
    private String alarmEffectDevice;

    /**
     * 告警创建时间
     */
    private long ts;

    public Object[] getParam(){
        Object[] param = new Object[]{
                this.getCode(),
                this.getNs(),
                this.getCi(),
                this.getAlarmId(),
                this.getAlarmName(),
                this.getAlarmSeverity(),
                this.getAlarmCategory(),
                this.getAlarmCauseText(),
                this.getAlarmRepairText(),
                this.getAlarmEffectBusiness(),
                this.getAlarmEffectDevice(),
                this.getTs()
        };
        return param;
    }

    /**
     * @desc 编码生成
     */
    public void buildCode(){
        int code= Hashing.murmur3_128().hashString((this.ns + this.ci + this.alarmId), Charsets.UTF_8).asInt();
        this.code=code;
    }

    public static FMMeta buildMeta(Map<String,Object> dbResult){
        FMMeta fmMeta = new FMMeta();
        fmMeta.setCode((Integer) dbResult.get("code"));
        fmMeta.setNs(dbResult.get("ns").toString());
        fmMeta.setAlarmId(dbResult.get("alarm_id").toString());
        fmMeta.setAlarmName(dbResult.get("alarm_name").toString());
        fmMeta.setAlarmSeverity(dbResult.get("alarm_severity").toString());
        fmMeta.setAlarmCategory(dbResult.get("alarm_category").toString());
        fmMeta.setAlarmCauseText(dbResult.get("alarm_cause_text").toString());
        fmMeta.setAlarmRepairText(dbResult.get("alarm_repair_text").toString());
        fmMeta.setAlarmEffectBusiness(dbResult.get("alarm_effect_business").toString());
        fmMeta.setAlarmEffectDevice(dbResult.get("alarm_effect_device").toString());
        return fmMeta;
    }

    public void validate() throws DGWException {
        if(StringUtils.isEmpty(this.alarmId)
                || StringUtils.isEmpty(this.alarmName)
                || StringUtils.isEmpty(this.ns)
                || StringUtils.isEmpty(this.alarmCauseText)
                || StringUtils.isEmpty(this.alarmRepairText)
                || StringUtils.isEmpty(this.alarmEffectBusiness)
                || StringUtils.isEmpty(this.alarmEffectDevice)){
            String msg = "模型配置错误，必填属性存在空值";
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
        if(!(this.alarmCategory.equals(CATEGORY_DEVICE) || this.alarmCategory.equals(CATEGORY_OM))){
            String msg = "模型配置错误，category属性非法,category={}" + this.alarmCategory;
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
        if(!(this.alarmSeverity.equals(SEVERITY_MAJOR) || this.alarmSeverity.equals(SEVERITY_NORMAL))){
            String msg="模型配置错误，severity属性非法,severity={}"+this.alarmSeverity;
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),msg);
        }
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getAlarmId() {
        return alarmId;
    }

    public void setAlarmId(String alarmId) {
        this.alarmId = alarmId;
    }

    public String getAlarmName() {
        return alarmName;
    }

    public void setAlarmName(String alarmName) {
        this.alarmName = alarmName;
    }

    public String getAlarmCategory() {
        return alarmCategory;
    }

    public void setAlarmCategory(String alarmCategory) {
        this.alarmCategory = alarmCategory;
    }

    public String getAlarmSeverity() {
        return alarmSeverity;
    }

    public void setAlarmSeverity(String alarmSeverity) {
        this.alarmSeverity = alarmSeverity;
    }

    public String getAlarmCauseText() {
        return alarmCauseText;
    }

    public void setAlarmCauseText(String alarmCauseText) {
        this.alarmCauseText = alarmCauseText;
    }

    public String getAlarmRepairText() {
        return alarmRepairText;
    }

    public void setAlarmRepairText(String alarmRepairText) {
        this.alarmRepairText = alarmRepairText;
    }

    public String getAlarmEffectBusiness() {
        return alarmEffectBusiness;
    }

    public void setAlarmEffectBusiness(String alarmEffectBusiness) {
        this.alarmEffectBusiness = alarmEffectBusiness;
    }

    public String getAlarmEffectDevice() {
        return alarmEffectDevice;
    }

    public void setAlarmEffectDevice(String alarmEffectDevice) {
        this.alarmEffectDevice = alarmEffectDevice;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }
}
