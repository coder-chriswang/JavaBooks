package com.neoway.iot.dgw.output.iotem.storage;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;

import java.util.List;

/**
 * @desc: EMDSink
 * @author: 20200312686
 * @date: 2020/7/1 16:43
 */
public interface EMDSink {
    String BACKEND_MYSQL="mysql";
    String BACKEND_ELASTIC="elastic";
    void start(DGWConfig env) throws DGWException;
    /**
     * @desc 数据写入
     * @param points 数据点
     */
    void write(List<EMDPoint> points) throws DGWException;

    /**
     * 模型注册
     * @param metas
     * @throws DGWException
     */
    void registerMeta(List<EMMeta> metas) throws DGWException;

    /**
     * @desc 获取meta信息
     * @param eventId 事件ID
     * @return
     * @throws DGWException
     */
    EMMeta getMeta(int eventId);
}
