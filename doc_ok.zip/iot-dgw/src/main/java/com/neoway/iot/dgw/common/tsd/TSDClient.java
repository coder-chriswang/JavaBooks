package com.neoway.iot.dgw.common.tsd;

import com.google.common.collect.Lists;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.Charset;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * @desc: OpenTSDBClient
 * @author: 20200312686
 * @date: 2020/6/30 18:16
 */
public class TSDClient {
    private static final Logger LOG = LoggerFactory.getLogger(TSDClient.class);
    private final TSDConfig config;
    private final HttpClient httpClient;

    public TSDClient(TSDConfig config) throws IOReactorException {
        this.config = config;
        this.httpClient = HttpClientFactory.createHttpClient(config);
        this.httpClient.start();
        LOG.debug("the httpclient has started");
    }

    /***
     * 同步写入
     * @param point
     */
    public void putSync(TSDPoint point) throws IOException, ExecutionException, InterruptedException {
        this.putSync(Lists.newArrayList(point));
    }

    /***
     * 同步写入
     * @param points
     */
    public void putSync(List<TSDPoint> points) throws IOException, ExecutionException, InterruptedException {
        Future<HttpResponse> future = httpClient.post(
                TSDApi.PUT.getPath(),
                TSDJson.writeValueAsString(points),
                new TSDputHttpCallback()
        );
        HttpResponse httpResponse = future.get();
        this.getContent(httpResponse);
    }

    /***
     * 同步写入,将会使用创建opentsdbClient时默认的callback
     * @param point
     */
    public void putSyncWithCallBack(TSDPoint point) throws IOException, ExecutionException, InterruptedException {
        this.putSyncWithCallBack(Lists.newArrayList(point));
    }

    /***
     * 同步写入,将会使用创建opentsdbClient时默认的callback
     * @param points
     */
    public void putSyncWithCallBack(List<TSDPoint> points) throws IOException, ExecutionException, InterruptedException {
        Future<HttpResponse> future = httpClient.post(
                TSDApi.PUT.getPath(),
                TSDJson.writeValueAsString(points),
                new TSDputHttpCallback(config.getPutCallBack(), points)
        );
        HttpResponse httpResponse = future.get();
        this.getContent(httpResponse);
    }
    public void closed() throws IOException {
        this.httpClient.gracefulClose();
    }
    /***
     * 解析响应的内容
     * @param response 响应内容
     * @return
     * @throws IOException
     */
    private String getContent(HttpResponse response) throws IOException {
        StatusLine statusLine = response.getStatusLine();
        int statusCode = statusLine.getStatusCode();
        if(statusCode >= 400){
            HttpEntity entity = response.getEntity();
            if(null == entity){
                String errMsg=MessageFormat.format(
                        "调用OpenTSDB http api发生错误，响应码:{0},错误信息:{1}",
                        statusCode,"Http请求异常");
                throw new RuntimeException(errMsg);
            }
            String msg= EntityUtils.toString(entity, Charset.defaultCharset());
            Map<String,Object> errRsp= TSDJson.readValue(msg,Map.class);
            Map<String,Object> errInfoMap=(Map<String,Object>)errRsp.get("error");
            int code=(Integer) errInfoMap.get("code");
            String message=(String)errInfoMap.get("message");
            String errMsg=MessageFormat.format(
                    "调用OpenTSDB http api发生错误，响应码:{0},错误信息:{1}",
                    code,message);
            throw new RuntimeException(errMsg);

        }else{
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, Charset.defaultCharset());
            }
            return null;
        }
    }

}
