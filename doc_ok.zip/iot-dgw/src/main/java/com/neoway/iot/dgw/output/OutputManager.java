package com.neoway.iot.dgw.output;

import com.neoway.iot.dgw.DGAbstractLifecycleComponent;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: Output插件管理
 * @author: 20200312686
 * @date: 2020/6/22 11:38
 */
public class OutputManager extends DGAbstractLifecycleComponent {
    private static final Logger LOG = LoggerFactory.getLogger(OutputManager.class);
    private static OutputManager manager=null;
    private List<Output> outputPlugins=new ArrayList<Output>();
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private OutputManager() {

    }

    @Override
    protected void doStart(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        for(OutputType outputType:OutputType.values()){
            if(outputType == OutputType.OTHER){
                continue;
            }
            Output out=create(outputType.name(),outputType.getOutputClassName());
            if(out.isEnable()){
                outputPlugins.add(out);
                out.start(env);
            }
        }
        OutputProcessor.getInstance().doStart(env);
        isStarted.set(true);
    }

    private Output create(String name, String type) throws DGWException {
        LOG.info("创建Output实例 类型={} clazz={}", name, type);
        Class<? extends Output> clazz = getClass(name);
        try {
            return clazz.newInstance();
        } catch (Exception ex) {
            throw new DGWException("",ex.getMessage());
        }
    }

    /**
     * @desc 获取channel clazz
     * @param type
     * @return
     * @throws DGWException
     */
    private Class<? extends Output> getClass(String type) throws DGWException {
        String clazzName = type;
        OutputType outputType = OutputType.OTHER;
        try {
            outputType=OutputType.valueOf(type.toUpperCase(Locale.ENGLISH));
        } catch (IllegalArgumentException ex) {
            LOG.error("Output类型非内置，属于自定义", type);
        }
        if (!outputType.equals(outputType.OTHER)) {
            clazzName = outputType.getOutputClassName();
        }
        try {
            return (Class<? extends Output>) Class.forName(clazzName);
        } catch (Exception ex) {
            throw new DGWException("",ex.getMessage());
        }
    }

    @Override
    protected String name() {
        return "module-output";
    }

    public static OutputManager getInstance() {
        if (manager == null) {
            synchronized (OutputManager.class) {
                if (manager == null) {
                    manager = new OutputManager();
                }
            }
        }
        return manager;
    }

    /**
     * @desc 获取订阅topic的所有Output
     * @param topic
     * @return
     */
    public List<Output> getOutputs(String topic){
        List<Output> values=new ArrayList<>();
        for(Output out:outputPlugins){
            if(out.getTopics().contains(topic)){
                values.add(out);
            }
        }
        return values;
    }

    /**
     * @desc 根据插件名称获取插件
     * @param name
     * @return
     */
    public Output getOutPut(String name){
        for(Output out:outputPlugins){
            if(out.name().equals(name)){
                return out;
            }
        }
        return null;
    }
    public List<Output> getOutputs(){
        return this.outputPlugins;
    }
}
