package com.neoway.iot.dgw.common.jdbc;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * @desc: JdbcPool
 * @author: 20200312686
 * @date: 2020/7/1 11:17
 */
public class JdbcPool {
    private String jdbcDriver;
    private String jdbcUri;
    //连接池允许的最大连接数
    private int jdbcMaxConn;
    private String jdbcUser;
    private String jdbcPwd;
    private boolean jdbcReadOnly;
    //等待连接池分配连接的最大时长：30秒
    private int jdbcConnTimeOut;
    //一个idle状态的连接超时时长 10分钟
    private int jdbcIdelTimeOut;
    private int jdbcMinConn;
    private boolean jdbcAutoCommit;
    private HikariDataSource dataSource;
    private ThreadLocal<Connection> container = new ThreadLocal<>();
    private JdbcPool(){

    }
    public static class Builder {
        private String jdbcDriver = "com.mysql.cj.jdbc.Driver";
        private String jdbcUri;
        private int jdbcMaxConn = 60;
        private int jdbcMinConn = 2;
        private String jdbcUser;
        private String jdbcPwd;
        private boolean jdbcReadOnly = false;
        private int jdbcConnTimeOut = 30000;
        private int jdbcIdelTimeOut = 600000;
        private boolean jdbcAutoCommit=false;
        public Builder() {
        }

        public JdbcPool build() {
            JdbcPool config = new JdbcPool();
            config.jdbcDriver = this.jdbcDriver;
            config.jdbcUri = this.jdbcUri;
            config.jdbcMaxConn = this.jdbcMaxConn;
            config.jdbcUser = this.jdbcUser;
            config.jdbcPwd = this.jdbcPwd;
            config.jdbcReadOnly = this.jdbcReadOnly;
            config.jdbcConnTimeOut = this.jdbcConnTimeOut;
            config.jdbcIdelTimeOut = this.jdbcIdelTimeOut;
            config.jdbcMinConn = this.jdbcMinConn;
            config.jdbcAutoCommit=this.jdbcAutoCommit;
            return config;
        }

        public Builder jdbcUri(String jdbcUri) {
            this.jdbcUri = jdbcUri;
            return this;
        }

        public Builder jdbcMaxConn(int jdbcMaxConn) {
            this.jdbcMaxConn = jdbcMaxConn;
            return this;
        }

        public Builder jdbcUser(String jdbcUser) {
            this.jdbcUser = jdbcUser;
            return this;
        }

        public Builder jdbcPwd(String jdbcPwd) {
            this.jdbcPwd = jdbcPwd;
            return this;
        }

        public Builder jdbcReadOnly(boolean jdbcReadOnly) {
            this.jdbcPwd = jdbcPwd;
            return this;
        }

        public Builder jdbcConnTimeOut(int jdbcConnTimeOut) {
            this.jdbcConnTimeOut = jdbcConnTimeOut;
            return this;
        }

        public Builder jdbcIdelTimeOut(int jdbcIdelTimeOut) {
            this.jdbcIdelTimeOut = jdbcIdelTimeOut;
            return this;
        }

        public Builder jdbcMinConn(int jdbcMinConn) {
            this.jdbcMinConn = jdbcMinConn;
            return this;
        }
        public Builder jdbcAutoCommit(boolean jdbcAutoCommit) {
            this.jdbcAutoCommit = jdbcAutoCommit;
            return this;
        }
    }

    public void start() {
        HikariConfig config = new HikariConfig();
        config.setDriverClassName(this.jdbcDriver);
        config.setJdbcUrl(this.jdbcUri);
        config.setUsername(this.jdbcUser);
        config.setPassword(this.jdbcPwd);
        config.setMaximumPoolSize(this.jdbcMaxConn);
        config.setConnectionTimeout(this.jdbcConnTimeOut);
        config.setIdleTimeout(this.jdbcIdelTimeOut);
        config.setMinimumIdle(this.jdbcMinConn);
        config.setReadOnly(this.jdbcReadOnly);
        config.setAutoCommit(this.jdbcAutoCommit);
        this.dataSource = new HikariDataSource(config);
    }

    public void stop() {
        this.container = null;
        this.dataSource = null;
    }

    public HikariDataSource getDataSource() {
        return dataSource;
    }

    public ThreadLocal<Connection> getContainer() {
        return container;
    }

    public void startTransaction() {
        Connection conn = container.get();
        if (conn == null) {
            conn = getConnection();
            container.set(conn);
        }
        try {
            conn.setAutoCommit(false);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void commit() {
        Connection conn = container.get();
        if (conn != null) {
            try {
                conn.commit();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void rollback() {
        Connection conn = container.get();
        if (conn != null) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void close() {
        Connection conn = container.get();
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } finally {
                container.remove();
            }
        }
    }

    private Connection getConnection() {
        try {
            return this.dataSource.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
