package com.neoway.iot.dgw.input.connector.jt808;

import com.neoway.iot.dgw.input.connector.Connector;
import com.neoway.iot.dgw.input.connector.ConnectorReq;
import com.neoway.iot.dgw.input.connector.ConnectorRsp;

import java.util.Map;

public class JT808Connector extends Connector {

    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        return null;
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public String name() {
        return "input-connector-jt808";
    }
}
