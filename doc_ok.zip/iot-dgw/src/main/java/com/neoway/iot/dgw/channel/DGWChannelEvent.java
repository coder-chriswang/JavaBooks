package com.neoway.iot.dgw.channel;

import com.neoway.iot.dgw.common.DGWContext;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: channel通道存储结构
 * @author: 20200312686
 * @date: 2020/7/7 11:10
 */
public class DGWChannelEvent implements Serializable {
    public String eventId;
    public DGWContext context;
    //K：topic boolean为是否消费成功的标识
    public Map<String, Boolean> status=new HashMap<>();
    public DGWChannelEvent(){

    }
    public DGWChannelEvent(DGWContext context,Map<String,Boolean> status){
        this.context=context;
        this.eventId=context.getHeader().getReqId();
        this.status=status;
    }

    public DGWContext getContext() {
        return context;
    }

    public void setContext(DGWContext context) {
        this.context = context;
    }

    public Map<String, Boolean> getStatus() {
        return status;
    }

    public void setStatus(Map<String, Boolean> status) {
        this.status = status;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }
}
