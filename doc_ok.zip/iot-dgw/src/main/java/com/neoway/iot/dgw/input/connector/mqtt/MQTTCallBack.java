package com.neoway.iot.dgw.input.connector.mqtt;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.DGWRequest;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.input.template.MetaTemplate;
import com.neoway.iot.dgw.input.template.TemplateManager;
import com.neoway.iot.dgw.input.template.TemplateStorage;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.internal.wire.MqttWireMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * @desc: MQTTCallBack
 * @author: 20200312686
 * @date: 2020/6/29 20:04
 */
public class MQTTCallBack implements MqttCallbackExtended {
    private static final Logger LOG = LoggerFactory.getLogger(MQTTCallBack.class);
    private MQTTClient mclient;
    private MqttClient client;
    private MQTTConnector connector;
    private TemplateStorage storage;
    public MQTTCallBack(MQTTClient client,MQTTConnector connector){
        this.mclient=client;
        this.client=mclient.getClient();
        this.connector=connector;
        this.storage=TemplateManager.getInstance().getStorage();
    }
    @Override
    public void connectComplete(boolean b, String s) {
        LOG.info("连接完成");
        try{
            Map<String,MQTTTopic> topics=mclient.getMqttTopics();
            for(MQTTTopic topic:topics.values()){
                LOG.info("开始订阅topic:topic={},名称={},QoS={}",topic.getTopic(),topic.getName(),topic.getQos());
                client.subscribe(topic.getTopic(),topic.getQos());
            }
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
        }
    }
    @Override
    public void connectionLost(Throwable throwable) {
        LOG.info("失去连接：errorMsg={}",throwable.getMessage());
        LOG.error(throwable.getMessage(),throwable);
    }
    @Override
    public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
        String data= StringUtils.trimToEmpty(new String(mqttMessage.getPayload()));
        MQTTTopic topic=mclient.getTopicByK(s);
        MetaTemplate metaTemplate= this.storage.getTemplate(topic.getNs(),topic.getTplid());
        if(null != metaTemplate &&metaTemplate.isDebugger()){
            LOG.info("接收到EMQ消息报文，topic={},名称={},报文={}",s,topic.getName(),data);
        }else{
            LOG.info("接收到EMQ消息，topic={},名称={},消息ID={}",s,topic.getName(),mqttMessage.getId());
        }
        DGWRequest request=new DGWRequest(topic.getNs(),topic.getTplid());
        request.setData(new Gson().fromJson(data, Map.class));
        request.setMessage(data);
        DGWResponse response=connector.uplink(request);
        LOG.info("接收到的EMQ消息处理结果:响应码={},错误消息={}",response.getCode(),response.getMsg());
    }
    @Override
    public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {

        try{
            MqttMessage message=iMqttDeliveryToken.getMessage();
            MqttException exception=iMqttDeliveryToken.getException();
            MqttWireMessage rsp=iMqttDeliveryToken.getResponse();
            String data=new String(message.getPayload());
            LOG.warn("失去连接：消息ID={},Payload={},异常={}",rsp.getMessageId(),data,exception.getMessage());
            LOG.error(exception.getMessage(),exception);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
        }
    }
}
