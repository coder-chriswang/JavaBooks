package com.neoway.iot.dgw.output.iotpm.storage;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.tsd.TSDPoint;

import java.util.List;
import java.util.Map;


/**
 * @desc: PMDBackend
 * @author: 20200312686
 * @date: 2020/7/1 9:52
 */
public interface PMDSink {
    String BACKEND_MYSQL="mysql";
    String BACKEND_OPENTSDB="opentsdb";

    /**
     * @desc 启动
     * @param env
     * @throws DGWException
     */
    void start(DGWConfig env) throws DGWException;

    Map<String,Object> configuration();
    /**
     * @desc 数据写入
     * @param points 数据点
     */
    void write(List<TSDPoint> points) throws DGWException;

    /**
     * 模型注册
     * @param metas
     * @throws DGWException
     */
    void registerMeta(List<PmMetaMetric> metas) throws DGWException;

    /**
     * @desc 获取metric meta信息
     * @param metric 指标
     * @return
     * @throws DGWException
     */
    PmMetaMetric getMeta(String metric) throws DGWException;
}
