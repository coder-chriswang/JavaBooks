package com.neoway.iot.dgw.input.template;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.input.AbstractInput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: AbstractInput
 * @author: 20200312686
 * @date: 2020/6/23 16:10
 */
public class TemplateManager extends AbstractInput {
    private static final Logger LOG = LoggerFactory.getLogger(TemplateManager.class);
    private static final String PRODUCT_F_NAME="product.xml";
    private static final String MODEL_PATH="dgw.model";
    private static TemplateManager manager=null;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private TemplateStorage storage=null;
    private Map<String,DGWProduct> proMap=new HashMap<>();
    //静默执行的模板队列
    private List<MetaTemplate> initTemplateQueue=new ArrayList<MetaTemplate>();
    private DGWConfig env;
    private TemplateManager() {

    }
    public static TemplateManager getInstance() {
        if (manager == null) {
            synchronized (TemplateManager.class) {
                if (manager == null) {
                    manager = new TemplateManager();
                }
            }
        }
        return manager;
    }

    @Override
    public String name() {
        return "module-input-template";
    }
    public TemplateStorage getStorage() {
        return storage;
    }

    /**
     * @desc 系统启动阶段，加载本地的模型文件
     * @param env
     */
    @Override
    public void start(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        String stype=String.valueOf(env.getValue(TemplateStorage.STYPE));
        if(TemplateStorage.STYPE_REDIS.equals(stype)){
            this.storage=TemplateStorageMem.getInstance();
        }else{
            this.storage=TemplateStorageMem.getInstance();
        }
        String dir=String.valueOf(env.getValue(MODEL_PATH));

        this.load(dir);
        this.env=env;
        super.start(env);
    }
    @Override
    public DGWResponse uplink(DGWRequest req) {
        //处理全局配置和dgw配置
        DGWResponse response=new DGWResponse();
        try{
            this.load(String.valueOf(env.getValue(MODEL_PATH)));
            return response;
        }catch (DGWException e){
            response.setCode(e.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }
    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration=new HashMap<>();
        configuration.put(TemplateStorage.STYPE,env.getValue(TemplateStorage.STYPE));
        configuration.put(MODEL_PATH,env.getValue(MODEL_PATH));
        return configuration;
    }

    /**
     * @desc 模板加载
     * @param path 模板路径
     */
    private void load(String path) throws DGWException{
        File dir=new File(path);
        if(!dir.exists()){
            try{
                LOG.info("模型包目录不存在:{}",path);
                dir.createNewFile();
                return;
            }catch (IOException e){
                LOG.error(e.getMessage(),e);
            }

        }
        initPro(dir);
        initTemplate();
    }

    /**
     * @desc 初始化产品域信息
     * @param dir
     * @return
     */
    private void initPro(File dir) throws DGWException{
        File[] fs=dir.listFiles();
        if(null == fs || fs.length == 0){
            return;
        }
        try{
            for(File f:fs){
                String path=f.getCanonicalPath();
                String proPath=path+File.separator+PRODUCT_F_NAME;
                DGWProduct pro=DGWProduct.build(proPath);
                if(null == pro){
                    throw new DGWException("","");
                }
                proMap.put(pro.getId(),pro);
            }
        }catch (IOException e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }catch (DGWException e){
            throw e;
        }

    }

    /**
     * @desc 初始化模板
     * @throws DGWException
     */
    private void initTemplate() throws DGWException{
        for(DGWProduct product:proMap.values()){
            String dgwDir=product.getPath()+File.separator+"mapping";
            File f=new File(dgwDir);
            if(!f.exists()){
                LOG.info("产品域:{}下不涉及gw模板",product.getId());
                return;
            }
            File[] files=f.listFiles();
            for(File ff:files){
                MetaTemplate template=MetaTemplate.build(ff,product,null);
                this.storage.addTempate(template);
                if(template.getPolicy().equals(MetaTemplate.POLICY_INIT)){
                    this.initTemplateQueue.add(template);
                }
            }
            initExtTemplate(product);
        }
    }

    /**
     * @desc 初始化扩展模型的模板
     * @throws DGWException
     */
    private void initExtTemplate(DGWProduct product) throws DGWException{
        String dgwExtDir=product.getPath()+File.separator+"ext";
        File f=new File(dgwExtDir);
        if(!f.exists()){
            LOG.info("产品域:{}下不涉及扩展模型模板",product.getId());
            return;
        }
        File[] files=f.listFiles();
        for(File ff:files){
            //解析models
            String modelPath=ff.getAbsolutePath()+File.separator+"model.xml";
            DGWProModle model=DGWProModle.build(modelPath);
            if(null == model){
                continue;
            }
            product.addModle(model);
            //解析mapping
            String pathName=ff.getAbsolutePath()+File.separator+"mapping";
            File mappingF=new File(pathName);
            if(!mappingF.exists()){
                continue;
            }
            File[] extFiles=mappingF.listFiles();
            if(null == extFiles){
                continue;
            }
            for(File extFile:extFiles){
                MetaTemplate template=MetaTemplate.build(extFile,product,model);
                this.storage.addTempate(template);
                if(template.getPolicy().equals(MetaTemplate.POLICY_INIT)){
                    this.initTemplateQueue.add(template);
                }
            }

        }
    }

    public List<MetaTemplate> getInitTemplateQueue() {
        Gson gson=new Gson();
        String json=gson.toJson(this.initTemplateQueue);
        List<MetaTemplate> queues=gson.fromJson(json,new TypeToken<List<MetaTemplate>>() {}.getType());
        return queues;
    }

    public synchronized void commit(MetaTemplate template){
        this.initTemplateQueue.remove(template);
    }

    public Map<String, DGWProduct> getProMap() {
        return proMap;
    }
}
