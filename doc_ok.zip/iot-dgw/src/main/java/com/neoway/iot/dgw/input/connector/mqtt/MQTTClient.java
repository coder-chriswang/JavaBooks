package com.neoway.iot.dgw.input.connector.mqtt;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * @desc: MQTTClient
 * @author: 20200312686
 * @date: 2020/6/29 20:07
 */
public class MQTTClient {
    private static final Logger LOG = LoggerFactory.getLogger(MQTTClient.class);

    public static final String MQTT_URI="dgw.input.mqtt.uri";
    public static final String MQTT_CLIENTID="dgw.input.mqtt.client_id";
    public static final String MQTT_USER="dgw.input.mqtt.user";
    public static final String MQTT_PWD="dgw.input.mqtt.pwd";
    public static final String MQTT_RECONNECT="dgw.input.mqtt.reconnect";
    public static final String MQTT_KEEPALIVED="dgw.input.mqtt.keepalived";
    public static final String MQTT_CONNTIMEOUT="dgw.input.mqtt.conn_timeout";
    public static final String MQTT_TOPIC_MODEL_SUBCRIBE="dgw.input.mqtt.topic.subcribe";
    private String serviceURI;
    private String clientId;
    private String username;
    private String password;
    private boolean isReconnect = true;
    private int keepAlivedInternal = 10;
    private int connTimeout = 5;
    private Map<String,MQTTTopic> mqttTopics=new HashMap<>();
    private MqttConnectOptions options;
    private MqttClient client;

    public MQTTClient(DGWConfig env){
        this.setServiceURI(String.valueOf(env.getValue(MQTT_URI)));
        this.setClientId(String.valueOf(env.getValue(MQTT_CLIENTID)));
        this.setKeepAlivedInternal(String.valueOf(env.getValue(MQTT_KEEPALIVED)));
        this.setConnTimeout(String.valueOf(env.getValue(MQTT_CONNTIMEOUT)));
        List<Map<String,Object>> topicMap=(List<Map<String, Object>>) env.getValue(MQTT_TOPIC_MODEL_SUBCRIBE);
        Gson gson=new Gson();
        String json=gson.toJson(topicMap);
        List<MQTTTopic> topics=gson.fromJson(json,new TypeToken<List<MQTTTopic>>() {}.getType());
        for(MQTTTopic topic:topics){
            this.mqttTopics.put(topic.getTopic(),topic);
        }
        this.setReconnect(String.valueOf(env.getValue(MQTT_RECONNECT)));
        this.setUsername(String.valueOf(env.getValue(MQTT_USER)));
        this.setPassword(String.valueOf(env.getValue(MQTT_PWD)));
        this.setConnTimeout(String.valueOf(env.getValue(MQTT_CONNTIMEOUT)));
    }

    public void init(MQTTConnector connector) throws DGWException{
        try{
            client=new MqttClient(this.getServiceURI(),this.getClientId(),new MemoryPersistence());
            options=new MqttConnectOptions();
            options.setCleanSession(true);
            options.setUserName(this.getUsername());
            options.setPassword(this.getPassword().toCharArray());
            options.setConnectionTimeout(10);
            options.setKeepAliveInterval(this.getKeepAlivedInternal());
            options.setAutomaticReconnect(this.isReconnect());
            options.setConnectionTimeout(this.getConnTimeout());
            //默认是10.发送频率太快会报异常
            options.setMaxInflight(1000);
            client.setTimeToWait(3000);
            client.connect(options);
            for(MQTTTopic topic:mqttTopics.values()){
                LOG.info("开始订阅topic:topic={},名称={},QoS={}",topic.getTopic(),topic.getName(),topic.getQos());
                client.subscribe(topic.getTopic(),topic.getQos());
            }
            client.setCallback(new MQTTCallBack(this,connector));
        }catch (MqttException e){
            throw new DGWException("",e.getMessage());
        }
    }
    public String getServiceURI() {
        return serviceURI;
    }

    public void setServiceURI(String serviceURI) {
        this.serviceURI = serviceURI;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId + UUID.randomUUID().toString();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isReconnect() {
        return isReconnect;
    }

    public void setReconnect(String reconnect) {
        if (StringUtils.isNotEmpty(reconnect)) {
            isReconnect = Boolean.valueOf(reconnect);
        }

    }

    public int getKeepAlivedInternal() {
        return keepAlivedInternal;
    }

    public void setKeepAlivedInternal(String keepAlivedInternal) {
        if (StringUtils.isNotEmpty(keepAlivedInternal)) {
            this.keepAlivedInternal = Integer.valueOf(keepAlivedInternal);
        }

    }

    public Map<String, MQTTTopic> getMqttTopics() {
        return mqttTopics;
    }

    public void setMqttTopics(Map<String, MQTTTopic> mqttTopics) {
        this.mqttTopics = mqttTopics;
    }

    public int getConnTimeout() {
        return connTimeout;
    }

    public void setConnTimeout(String connTimeout) {
        if (StringUtils.isNotEmpty(connTimeout)) {
            this.connTimeout = Integer.valueOf(connTimeout);
        }

    }

    public MqttClient getClient() {
        return client;
    }

    public MQTTTopic getTopicByK(String topic){
        return this.mqttTopics.get(topic);
    }
}
