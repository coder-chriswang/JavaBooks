package com.neoway.iot.dgw.output.iotlm.storage;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;

/**
 * @desc: LMDAbstractSink
 * @author: 20200312686
 * @date: 2020/7/1 16:46
 */
public abstract class LMDAbstractSink implements LMDSink {
    @Override
    public void start(DGWConfig env) throws DGWException {

    }

    @Override
    public void write(List<LMDPoint> points) throws DGWException {
        // 数据补齐
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        /*for(LMDPoint point:points){
            DMDHot hot= DMRunner.getInstance().getHot(point.getNativeID());
            point.setInstanceId(hot.getInstanceId());
        }*/
        doWrite(points);
    }
    abstract void doWrite(List<LMDPoint> points) throws DGWException;

}
