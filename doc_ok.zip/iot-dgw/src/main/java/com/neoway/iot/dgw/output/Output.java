package com.neoway.iot.dgw.output;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.config.DGWConfig;

import java.util.List;
import java.util.Map;

public interface Output {
    /**
     * @desc 获取插件名称
     * @return 插件名称
     */
    String name();

    /**
     * @desc 是否启用
     * @return
     */
    boolean isEnable();

    List<String> getTopics();
    /**
     * @desc 插件启动
     * @param config
     */
    void start(DGWConfig config) throws DGWException;

    /**
     * @desc 获取配置
     * @return
     */
    Map<String,Object> configuration();
    /**
     * @desc 插件停止
     */
    void stop();

    /**
     * @desc 数据处理
     * @param event
     * @return 响应结果
     */
    DGWResponse process(OutputEvent event);

}
