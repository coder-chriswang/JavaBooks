package com.neoway.iot.dgw.output;

/**
 * @desc: OutputType
 * @author: 20200312686
 * @date: 2020/6/30 16:03
 */
public enum OutputType {
    IOTDM("com.neoway.iot.dgw.output.iotdm.DmOutput"),
    IOTEM("com.neoway.iot.dgw.output.iotem.EmOutput"),
    IOTFM("com.neoway.iot.dgw.output.iotfm.FmOutput"),
    IOTLM("com.neoway.iot.dgw.output.iotlm.LmOutput"),
    IOTPM("com.neoway.iot.dgw.output.iotpm.PmOutput"),
    OTHER(null);
    private final String outputClassName;

    private OutputType(String outputClassName) {
        this.outputClassName = outputClassName;
    }

    public String getOutputClassName() {
        return outputClassName;
    }
}
