package com.neoway.iot.dgw.common.elastic;

/**
 * <pre>
 *  描述: Es配置信息
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/08 11:40
 */
public class ElasticConfig {

    /**
     * 客户端类型
     */
    private String clientType;

    /**
     * 集群主机IP
     */
    private String[] hostNames;

    /**
     * 集群名称
     */
    private String clusterName;

    /**
     * rest端口
     */
    private int restPort;

    /**
     * transport端口
     */
    private int transportPort;

    /**
     * restScheme
     */
    private String restScheme;

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public String[] getHostNames() {
        return hostNames;
    }

    public void setHostNames(String[] hostNames) {
        this.hostNames = hostNames;
    }

    public String getClusterName() {
        return clusterName;
    }

    public void setClusterName(String clusterName) {
        this.clusterName = clusterName;
    }

    public int getRestPort() {
        return restPort;
    }

    public void setRestPort(int restPort) {
        this.restPort = restPort;
    }

    public int getTransportPort() {
        return transportPort;
    }

    public void setTransportPort(int transportPort) {
        this.transportPort = transportPort;
    }

    public String getRestScheme() {
        return restScheme;
    }

    public void setRestScheme(String restScheme) {
        this.restScheme = restScheme;
    }
}
