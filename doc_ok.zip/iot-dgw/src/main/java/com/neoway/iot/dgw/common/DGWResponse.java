package com.neoway.iot.dgw.common;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: DGW 响应结构体
 * @author: 20200312686
 * @date: 2020/6/23 9:06
 */
public class DGWResponse {
    private String code=DGWCodeEnum.SUCCESS_CODE.getCode();
    private String msg="";
    private int ts;
    private Map<String,String> header=new HashMap<>();
    private Object data;

    public DGWResponse(){

    }
    public DGWResponse(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Map<String, String> getHeader() {
        return header;
    }

    public void setHeader(Map<String, String> header) {
        this.header = header;
    }

    public int getTs() {
        return ts;
    }

    public void buildTs() {
        Long tsL = System.currentTimeMillis()/1000;
        this.ts=tsL.intValue();
    }
}
