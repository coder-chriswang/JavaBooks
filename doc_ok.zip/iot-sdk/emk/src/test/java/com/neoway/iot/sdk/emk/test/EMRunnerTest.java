package com.neoway.iot.sdk.emk.test;

import com.neoway.iot.sdk.emk.EMRunner;
import com.neoway.iot.sdk.emk.common.db.EMPool;
import com.neoway.iot.sdk.emk.model.EMMetaModel;
import com.neoway.iot.sdk.emk.model.EMModel;
import com.neoway.iot.sdk.emk.params.EMModelQueryParam;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EMRunnerTest {

    @BeforeClass
    public static void init() {
        Map<String,Object> pro = new HashMap<>();
        pro.put(EMPool.JDBC_HOST, "192.168.69.14");
        pro.put(EMPool.JDBC_PORT, "9000");
        pro.put(EMPool.JDBC_DB, "aresd");
        pro.put(EMPool.JDBC_USER, "root");
        pro.put(EMPool.JDBC_PWD, "hera@321");
        pro.put(EMRunner.EVENT_TABLE_COUNT, "2");
        EMRunner.getInstance().start(pro);
    }

    @AfterClass
    public static void destroy() {
        EMRunner.getInstance().stop();
    }

    @Test
    public void testListEventMeta() throws Exception {
        List<EMMetaModel> r =  EMRunner.getInstance().listEventMeta(null);
        System.out.println(r);
    }

    @Test
    public void testAddEventMeta() throws Exception {
        EMMetaModel item = new EMMetaModel();
        item.setNs("default");
        item.setEventId("20010");
        item.setEventName("DGW数据处理");
        item.setCategory("API");
        item.setType("System");
        item.setSeverity("Major");
        System.out.println(EMRunner.getInstance().addEventMeta(item));
    }

    @Test
    public void testBatchAddEventMeta() throws Exception {
        List<EMMetaModel> list = new ArrayList<>();

        EMMetaModel item = new EMMetaModel();
        item.setNs("default");
        item.setEventId("20011");
        item.setEventName("DGW数据处理");
        item.setCategory("API");
        item.setType("System");
        item.setSeverity("Major");
        list.add(item);

        item = new EMMetaModel();
        item.setNs("default");
        item.setEventId("20012");
        item.setEventName("DGW数据处理");
        item.setCategory("API");
        item.setType("System");
        item.setSeverity("Major");
        list.add(item);
        System.out.println(EMRunner.getInstance().batchAddEventMeta(list));
    }

    @Test
    public void testListEvent() throws Exception {
        EMModelQueryParam param = new EMModelQueryParam();
        param.setInstanceId("2992924626134495246");
        param.setEventId("20010");
        param.setEventNo(352270326825332736L);
        param.setOffset(0);
        param.setCount(10);
        List<EMModel> r =  EMRunner.getInstance().listEvent(param);
        for (EMModel m: r) {
            System.out.println(m);
        }
    }

    @Test
    public void testAddEvent() throws Exception {
        EMModel item = new EMModel();
        item.setEventId("20010");
        item.setEventName("设备上报数据");
        item.setEventCategory("Device");
        item.setEventType("System");
        item.setEventSeverity("Major");
        item.setEventInfo("eyJoZWFkZXIiOnsiaW1laSI6IjEwMDAwMDkzIiwgsImx0ZVBDSSI6NDAsImx0ZUFSRkNOIjoyNywibHRlUlNS...");
        item.setEventSt((int) (System.currentTimeMillis() * 1000));
        item.setEventEt(0);
        item.setEventResult("code=0,msg=");
        item.setClientIp("192.168.69.14");
        item.setInstanceId("2992924626134495246");

        System.out.println(EMRunner.getInstance().addEvent(item));
    }
}
