package com.neoway.iot.sdk.emk.common.db;

import com.neoway.iot.sdk.emk.EMEnv;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 数据库连接池配置
 */
public class EMPool {
    private static final Logger LOG = LoggerFactory.getLogger(EMPool.class);
    public static final String JDBC_HOST="jdbc_host";
    public static final String JDBC_PORT="jdbc_port";
    public static final String JDBC_DB="jdbc_db";
    public static final String JDBC_MAX_CONN="jdbc_max_conn";
    public static final String JDBC_USER="jdbc_user";
    public static final String JDBC_PWD="jdbc_pwd";
    public static final String JDBC_CONN_TIMEOUT="jdbc_conn_timeout";
    public static final String JDBC_IDEL_TIMEOUT="jdbc_idel_timeout";
    public static final String JDBC_MIN_CONN="jdbc_min_conn";

    private static EMPool pool=null;
    private EMEnv env;
    private HikariDataSource dataSource;
    private ThreadLocal<Connection> container=new ThreadLocal<>();
    private EMPool(){
        env=EMEnv.getInstance();
    }
    public static EMPool getInstance(){
        if(pool == null){
            synchronized (EMPool.class){
                if(pool == null){
                    pool=new EMPool();
                }
            }
        }
        return pool;
    }

    public void start(){
        EMPoolConfig.Builder builder= EMPoolConfig.build();
        builder.jdbcUri(env.getValue(JDBC_HOST),env.getValue(JDBC_PORT),env.getValue(JDBC_DB))
                .jdbcAuth(env.getValue(JDBC_USER),env.getValue(JDBC_PWD))
                .jdbcPool(env.getValue(JDBC_MAX_CONN),env.getValue(JDBC_MIN_CONN))
                .jdbcTimeOut(env.getValue(JDBC_CONN_TIMEOUT),env.getValue(JDBC_IDEL_TIMEOUT));
        EMPoolConfig dmConfig=builder.config();
        HikariConfig config=this.initHikariConfig(dmConfig);
        this.dataSource=new HikariDataSource(config);
    }

    public void stop(){
        if (this.dataSource != null && !this.dataSource.isClosed()) {
            this.dataSource.close();;
        }
        this.container=null;
        this.dataSource=null;
    }

    public HikariDataSource getDataSource() {
        return dataSource;
    }

    private HikariConfig initHikariConfig(EMPoolConfig dmConfig){
        HikariConfig config=new HikariConfig();
        config.setDriverClassName(dmConfig.getJdbcDriver());
        config.setJdbcUrl(dmConfig.getJdbcUri());
        config.setUsername(dmConfig.getJdbcUser());
        config.setPassword(dmConfig.getJdbcPwd());
        config.setMaximumPoolSize(dmConfig.getJdbcMaxConn());
        config.setConnectionTimeout(dmConfig.getJdbcConnTimeOut());
        config.setIdleTimeout(dmConfig.getJdbcIdelTimeOut());
        config.setMinimumIdle(dmConfig.getJdbcMinNum());
        config.setReadOnly(dmConfig.isJdbcReadOnly());
        config.setAutoCommit(dmConfig.isJdbcAutoCommit());
        config.setPoolName(dmConfig.getPoolName());
        return config;
    }

    public ThreadLocal<Connection> getContainer() {
        return container;
    }
    public void startTransaction(){
        Connection conn=container.get();
        if(conn == null){
            conn=getConnection();
            container.set(conn);
        }
        try{
            conn.setAutoCommit(false);
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    public void commit(){
        Connection conn=container.get();
        if(conn != null){
            try{
                conn.commit();
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }
    }

    public void rollback(){
        Connection conn=container.get();
        if(conn != null){
            try{
                conn.rollback();
            }catch (SQLException e){
                throw new RuntimeException(e);
            }
        }
    }
    public void close(){
        Connection conn=container.get();
        if(conn != null){
            try{
                conn.close();
            }catch (SQLException e){
                throw new RuntimeException(e);
            }finally {
                container.remove();
            }
        }
    }

    private Connection getConnection() {
        try{
            return this.dataSource.getConnection();
        }catch (SQLException e){
            throw new RuntimeException(e);
        }

    }

}
