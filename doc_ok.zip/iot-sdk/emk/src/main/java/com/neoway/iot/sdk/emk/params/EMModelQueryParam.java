package com.neoway.iot.sdk.emk.params;

import lombok.Data;

@Data
public class EMModelQueryParam {
    /**
     * 资源ID，必须传
     */
    private String instanceId;
    /**
     * 流水号
     */
    private Long eventNo;
    /**
     * 事件ID
     */
    private String eventId;
    /**
     * 事件发生时间
     */
    private Integer eventSt;
    /**
     * 事件结束时间
     */
    private Integer eventEt;

    private Integer offset;
    private Integer count;
}
