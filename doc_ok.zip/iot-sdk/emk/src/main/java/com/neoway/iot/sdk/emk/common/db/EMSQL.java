package com.neoway.iot.sdk.emk.common.db;

public enum EMSQL {
    //产品域资源库JDBC连接URI
    JDBC_URL("jdbc:mysql://{0}:{1}/{2}?useSSL=false&useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai","JDBC_URI"),





    //ARES库下创建产品域表
    DDL_ARES_CREATE_TABLE_NS("CREATE TABLE IF NOT EXISTS CMDB_META_NS(\n" +
            "  `id` varchar(64) NOT NULL COMMENT '产品表标识',\n" +
            "  `name` varchar(128) NOT NULL COMMENT '产品名称',\n" +
            "  `desc` varchar(512) DEFAULT NULL COMMENT '产品描述',\n" +
            "  `vendor` varchar(64) NOT NULL COMMENT '产品提供商',\n" +
            "  `vendor_name` varchar(128) NOT NULL COMMENT '产品提供商名称',\n" +
            "  `use_db` boolean COMMENT '是否创建DB',\n" +
            "  `update_ts` int(10) NOT NULL COMMENT '更新时间',\n" +
            "   PRIMARY KEY (`id`) USING BTREE\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品域' ROW_FORMAT=DYNAMIC;","创建产品域存储表"),
    //Ares库下创建国际化词条表
    DDL_ARES_CREATE_TABLE_I18N("CREATE TABLE IF NOT EXISTS CMDB_META_I18N (\n" +
            "  `ns` varchar(64) NOT NULL COMMENT '产品标识',\n" +
            "  `lan` varchar(64) NOT NULL COMMENT '语言类型',\n" +
            "  `k` varchar(128) NOT NULL COMMENT '词条K',\n" +
            "  `v` varchar(512) DEFAULT NULL COMMENT '词条V',\n" +
            "  `enable` varchar(32) DEFAULT NULL COMMENT '使能(前端=f、后端=b)',\n" +
            "  `update_ts` int(10) DEFAULT NULL COMMENT '更新时间',\n" +
            "   PRIMARY KEY (`ns`,`lan`,`k`) USING BTREE\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='国际化词条' ROW_FORMAT=DYNAMIC;","创建国际化词条存储表"),
    //ARES库下创建CI元数据表
    DDL_ARES_CREATE_TABLE_CI("CREATE TABLE IF NOT EXISTS CMDB_META_CI(\n" +
            "  `ns` varchar(64) NOT NULL COMMENT '产品域',\n" +
            "  `tenent` varchar(64) NOT NULL COMMENT '租户域',\n" +
            "  `ci` varchar(64) NOT NULL COMMENT '对象类型',\n" +
            "  `name` varchar(128) NOT NULL COMMENT '对象名称',\n" +
            "  `type` varchar(32) NOT NULL COMMENT '对象表类型',\n" +
            "  `desc` varchar(256) COMMENT '对象描述',\n" +
            "  `cache` boolean COMMENT '是否进行数据缓存',\n" +
            "  `update_ts` int(10) NOT NULL COMMENT '更新时间',\n" +
            "   PRIMARY KEY (`ns`,`tenent`,`ci`) USING BTREE\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='对象元数据' ROW_FORMAT=DYNAMIC;","创建对象元数据存储表"),
    //ARES库下创建属性元数据表
    DDL_ARES_CREATE_TABLE_ATTR("CREATE TABLE IF NOT EXISTS CMDB_META_ATTR(\n" +
            "  `ns` varchar(64) NOT NULL COMMENT '产品域',\n" +
            "  `tenent` varchar(64) NOT NULL COMMENT '租户域',\n" +
            "  `ci` varchar(64) NOT NULL COMMENT '对象类型',\n" +
            "  `id` varchar(64) NOT NULL COMMENT '对象属性',\n" +
            "  `name` varchar(128) NOT NULL COMMENT '对象属性名称',\n" +
            "  `desc` varchar(512) COMMENT '对象属性描述',\n" +
            "  `validate` varchar(512) COMMENT '对象属性校验',\n" +
            "  `type` varchar(32) NOT NULL COMMENT '对象属性类型',\n" +
            "  `is_primary` boolean COMMENT '是否主键',\n" +
            "  `is_index` boolean COMMENT '是否索引键',\n" +
            "  `support_actions` varchar(256) COMMENT '支持的操作指令集',\n" +
            "  `ext` json COMMENT '扩展项',\n" +
            "  `update_ts` int(10) NOT NULL COMMENT '更新时间',\n" +
            "   PRIMARY KEY (`ns`,`tenent`,`ci`,`id`) USING BTREE\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='对象属性元数据' ROW_FORMAT=DYNAMIC;","创建对象属性元数据存储表"),
    //ARES库下创建指令元数据表
    DDL_ARES_CREATE_TABLE_ACTION("CREATE TABLE IF NOT EXISTS CMDB_META_ACTION(\n" +
            "  `ns` varchar(64) NOT NULL COMMENT '产品域',\n" +
            "  `tenent` varchar(64) NOT NULL COMMENT '租户域',\n" +
            "  `ci` varchar(64) NOT NULL COMMENT '对象类型',\n" +
            "  `id` varchar(64) NOT NULL COMMENT '对象指令',\n" +
            "  `name` varchar(128) NOT NULL COMMENT '对象指令名称',\n" +
            "  `desc` varchar(512) COMMENT '对象指令描述',\n" +
            "  `domain` varchar(32) NOT NULL COMMENT '对象指令域',\n" +
            "  `type` varchar(32) NOT NULL COMMENT '对象指令类型',\n" +
            "  `severity` varchar(32) COMMENT '对象指令级别',\n" +
            "  `templateid` varchar(64) COMMENT '关联的模板ID',\n" +
            "  `condition` text COMMENT '指令条件',\n" +
            "  `update_ts` int(10) NOT NULL COMMENT '更新时间',\n" +
            "   PRIMARY KEY (`ns`,`tenent`,`ci`,`id`) USING BTREE\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='对象指令元数据' ROW_FORMAT=DYNAMIC;","创建对象指令元数据存储表"),
    //ARES库下创建指令元数据表
    DDL_ARES_CREATE_TABLE_RELATION("CREATE TABLE IF NOT EXISTS CMDB_META_RELATION(\n" +
            "  `src_ci` varchar(64) NOT NULL COMMENT '源CI',\n" +
            "  `rel_type` varchar(64) NOT NULL COMMENT '关系类型',\n" +
            "  `rel_name` varchar(64) NOT NULL COMMENT '关系名称',\n" +
            "  `dst_ci` varchar(64) NOT NULL COMMENT '目标CI',\n" +
            "  `update_ts` int(10) NOT NULL COMMENT '更新时间',\n" +
            "   PRIMARY KEY (`src_ci`,`rel_type`,`dst_ci`) USING BTREE\n" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='对象关系元数据' ROW_FORMAT=DYNAMIC;","创建对象关系元数据存储表"),

    //创建产品域资源库
    DDL_NS_CREATE_DATABASE("CREATE DATABASE IF NOT EXISTS `{0}` DEFAULT CHARACTER SET utf8;","创建产品域资源库"),
    DML_NS_INSERT("INSERT INTO CMDB_META_NS(`id`,`name`,`desc`,`vendor`,`vendor_name`,`use_db`,`update_ts`)" +
            " VALUES(?,?,?,?,?,?,?)","添加产品域记录"),
    //查询产品域记录
    DML_NS_QUERY("SELECT * FROM CMDB_META_NS","查询产品域记录集"),
    //查询产品域记录
    DML_NS_GET("SELECT * FROM CMDB_META_NS WHERE ID=?","查询指定产品域记录"),

    //根据元数据创建CI实例表
    DDL_INSTANCE_CREATE_TABLE("CREATE TABLE IF NOT EXISTS {0}({1})" +
            "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT={2} ROW_FORMAT=DYNAMIC;","创建CI实例表"),
    DDL_INSTANCE_CREATE_TABLE_PRIMARY("PRIMARY KEY ({0}) USING BTREE","建表主键语句"),
    DDL_INSTANCE_CREATE_TABLE_INDEX("INDEX `{0}`(`{1}`) USING BTREE","建表索引语句"),

    //添加CI元数据
    DML_META_CI_INSERT("REPLACE INTO CMDB_META_CI(`ns`,`tenent`,`ci`,`name`,`type`,`desc`,`cache`,`update_ts`)" +
            " VALUES(?,?,?,?,?,?,?,?)","添加CI元数据记录"),

    DML_META_ATTR_INSERT("REPLACE INTO CMDB_META_ATTR(`ns`,`tenent`,`ci`,`id`,`name`,`desc`," +
            "`validate`,`type`,`is_primary`,`is_index`,`support_actions`,`ext`,`update_ts`)" +
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)","添加Attr元数据记录"),

    DML_META_ACTION_INSERT("REPLACE INTO CMDB_META_ACTION(`ns`,`tenent`,`ci`,`id`,`name`,`desc`," +
            "`domain`,`type`,`severity`,`templateId`,`condition`,`update_ts`)" +
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)","添加Action元数据记录"),
    //查询CI元数据列表
    DML_META_CI_QUERY("SELECT * FROM CMDB_META_CI WHERE NS=? ","查询CI元数据记录"),
    //查询CI元数据
    DML_META_CI_GET("SELECT * FROM CMDB_META_CI WHERE NS=? AND TENENT=? AND CI=?","查询CI元数据"),
    //查询CI-属性元数据
    DML_META_ATTR_QUERY("SELECT * FROM CMDB_META_ATTR WHERE NS=? AND TENENT=? AND CI=? ","查询Attr元数据记录"),
    //查询CI-指令元数据
    DML_META_ACTION_QUERY("SELECT * FROM CMDB_META_ACTION WHERE NS=? AND TENENT=? AND CI=?","查询Action元数据记录"),

    //根据实例ID查询产品域资源库下CI实例记录
    DML_CI_INSTANCE_GET("SELECT * FROM {0} WHERE 1=1 {1}","查询CI实例数据详情"),
    //根据指定条件查询产品域资源库下CI实例记录集
    DML_CI_INSTANCES_QUERY("SELECT * FROM {0} WHERE 1=1 {1}","条件查询CI实例数据列表"),
    //添加CI实例数据
    DML_CI_INSTANCE_INSERT("REPLACE INTO {0}({1}) VALUES({2})","添加CI实例数据");


    private String sql;
    private String name;
    private EMSQL(String sql, String name){
        this.sql=sql;
        this.name=name;
    }

    public String getSql() {
        return sql;
    }

    public String getName() {
        return name;
    }
}
