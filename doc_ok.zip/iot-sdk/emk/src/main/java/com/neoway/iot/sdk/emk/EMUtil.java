package com.neoway.iot.sdk.emk;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.*;


public class EMUtil {
    private static final Logger LOG = LoggerFactory.getLogger(EMUtil.class);
    public static Set<Field> getFieldsIncludeSuperClass(Class clazz) {
        Set<Field> fields = new LinkedHashSet<Field>();
        Class current = clazz;
        while (current != null) {
            Field[] currentFields = current.getDeclaredFields();
            for (Field currentField : currentFields) {
                fields.add(currentField);
            }
            current = current.getSuperclass();
        }
        return fields;
    }
    public static<T> List<T> invokeObject(List<Map<String,Object>> columnMaps, T clazz){
        if (columnMaps == null) {
            return null;
        }
        List<T> rs = new ArrayList<>();
        for (Map<String,Object> item: columnMaps) {
            Object obj = invokeObject(item, clazz.getClass());
            if (obj != null) {
                rs.add((T) obj);
            }
        }
        return rs;
    }

    /**
     * @desc 数据库字段映射到实体类
     * @param columnMap
     * @return
     */
    public static Object invokeObject(Map<String,Object> columnMap, Class clazz){
        Object instance;
        try {
            instance=clazz.newInstance();
        } catch (Exception ex) {
            LOG.error(ex.getMessage(),ex);
            String errTpl="设置对象属性值发生异常,无法实例化对象。对象={0}";
            String err= MessageFormat.format(errTpl,clazz.getName());
            throw new RuntimeException(err);
        }

        columnMap = uniformColumnName(columnMap);
        Set<Field> fields= EMUtil.getFieldsIncludeSuperClass(clazz);
        for (Field field : fields) {
            try{
                Method method=getSetterMethod(clazz,field);
                if(null == method){
                    continue;
                }
                String column=field.getName();
                Object value=columnMap.get(column);
                method.invoke(instance, value);
            }catch (Exception e){
                e.printStackTrace();
                LOG.error(e.getMessage(),e);
                String errTpl="设置对象属性值发生异常。对象={0}，属性={1}";
                String err= MessageFormat.format(errTpl,clazz.getName(),field.getName());
                throw new RuntimeException(err);
            }
        }
        return instance;
    }

    private static Map<String,Object> uniformColumnName(Map<String,Object> columnMap) {
        if (columnMap == null) {
            return null;
        }
        Map<String,Object> r = new HashMap<>();
        for (String key: columnMap.keySet()) {
            String newKey = key;
            while (newKey.contains("_")) {
                int idx = newKey.indexOf('_');
                if (idx > 0) {
                    newKey = newKey.substring(0, idx) + newKey.substring(idx + 1, idx + 2).toUpperCase() + newKey.substring(idx + 2);
                }
            }
            r.put(newKey, columnMap.get(key));
        }
        return r;
    }

    /**
     * @desc 根据对象属性获取属性方法
     * @param clazz 对象类型
     * @param field 对象属性
     * @return 方法
     */
    public static Method getSetterMethod(Class clazz, Field field) {
        Class fieldType=field.getType();
        String name = "set" + StringUtils.capitalize(field.getName());
        try {
            Method declaredMethod = clazz.getDeclaredMethod(name, fieldType);
            declaredMethod.setAccessible(true);
            return declaredMethod;
        } catch (NoSuchMethodException e) {
            /*LOG.error(e.getMessage(),e);
            String errTpl="设置对象属性值发生异常：原因为找不到对象set方法。对象={0}，属性={1}";
            String err= MessageFormat.format(errTpl,clazz.getName(),field.getName());
            throw new RuntimeException(err);*/
            return null;
        }
    }
}
