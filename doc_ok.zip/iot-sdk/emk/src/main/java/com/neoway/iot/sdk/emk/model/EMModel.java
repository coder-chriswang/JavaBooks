package com.neoway.iot.sdk.emk.model;

import lombok.Data;
import java.util.Date;

/**
* 数据模型
*/
@Data
public class EMModel {

    /**
     * 流水号
     */
    private Long eventNo;

    /**
     * 事件ID
     */
    private String eventId;

    /**
     * 事件名称
     */
    private String eventName;

    /**
     * 事件分类(OM,Device)
     */
    private String eventCategory;

    /**
     * 事件类型(System,Operate)
     */
    private String eventType;

    /**
     * 事件级别(Major,Normal)
     */
    private String eventSeverity;

    /**
     * 事件详情
     */
    private String eventInfo;

    /**
     * 事件发生时间
     */
    private Integer eventSt;

    /**
     * 事件结束时间
     */
    private Integer eventEt;

    /**
     * 事件处理结果
     */
    private String eventResult;

    /**
     * 客户端IP
     */
    private String clientIp;

    /**
     * 资源ID
     */
    private String instanceId;


}