package com.neoway.iot.sdk.emk.sharding;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 数据库
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 10:15
 */
@Data
public class Database implements Serializable {
    private static final long serialVersionUID = -8099764471752160383L;
    /**
     * 数据库连接
     */
    private String jdbcUrl;
    /**
     * 数据库名
     */
    private String dbName;
    /**
     * 用户名
     */
    private String user;
    /**
     * 密码
     */
    private String password;
}
