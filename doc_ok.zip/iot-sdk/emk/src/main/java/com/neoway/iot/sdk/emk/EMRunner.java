package com.neoway.iot.sdk.emk;

import com.neoway.iot.sdk.emk.common.db.EMPool;
import com.neoway.iot.sdk.emk.model.EMMetaModel;
import com.neoway.iot.sdk.emk.model.EMModel;
import com.neoway.iot.sdk.emk.model.constant.ConstantVariable;
import com.neoway.iot.sdk.emk.params.EMModelQueryParam;
import com.neoway.iot.sdk.emk.sharding.Partition;
import com.neoway.iot.sdk.emk.util.IDWorker;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import com.neoway.iot.sdk.emk.params.EMMetaModelQueryParam;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.neoway.iot.sdk.emk.EMUtil.invokeObject;

/**
 * 事件SDK操作入口类
 */
public class EMRunner {
    private static final Logger LOG = LoggerFactory.getLogger(EMRunner.class);
    private static EMRunner runner=null;
    private EMRunner(){
    }
    public static EMRunner getInstance(){
        if(runner == null){
            synchronized (EMRunner.class){
                if(runner == null){
                    runner=new EMRunner();
                }
            }
        }
        return runner;
    }

    public static final String EVENT_TABLE_COUNT = "event_table_count";
    private Partition partition;
    public void initPartition(String tableCount) {
        if (StringUtils.isEmpty(tableCount)) {
            tableCount = "1";
        }
        partition = new Partition();
        partition.setDatabaseCount(ConstantVariable.EVENT_DATABASE_COUNT);
        partition.setTableCount(Integer.valueOf(tableCount));
        partition.setTablePrefix(ConstantVariable.EVENT_TABLE_PREFIX);
    }

    /**
     * @desc emk启动初始化
     * @param pro emk初始化变量
     */
    public void start(Map<String,Object> pro){
        initPartition((String) pro.get(EVENT_TABLE_COUNT));
        EMEnv.getInstance().start(pro);
        EMPool.getInstance().start();
        LOG.error("EMK初始化成功");
    }

    /**
     * @desc emk停止
     */
    public void stop(){
        EMPool.getInstance().stop();
        EMEnv.getInstance().stop();
    }

    public List<EMMetaModel> listEventMeta(EMMetaModelQueryParam param) {
        String sql = "select * from EM_META_EVENT where 1=1";
        if (param != null) {
            if (StringUtils.isNotEmpty(param.getNs())) {
                sql += " and EM_META_EVENT.ns = "+ param.getNs();
            }
            if (StringUtils.isNotEmpty(param.getEventId())) {
                sql += " and EM_META_EVENT.event_id = "+ param.getEventId();
            }
        }
        QueryRunner runner = new QueryRunner(EMPool.getInstance().getDataSource());
        List<Map<String,Object>> values = null;
        try {
            values = runner.query(sql, new MapListHandler());
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return EMUtil.invokeObject(values, new EMMetaModel());
    }

    public boolean addEventMeta(EMMetaModel item) {
        if (item == null) {
            return false;
        }
        String sql = "insert into EM_META_EVENT (ns,event_id,event_name,category,type,severity) values (?,?,?,?,?,?)";
        QueryRunner runner = new QueryRunner(EMPool.getInstance().getDataSource());
        int result = 0;
        try {
            result = runner.update(sql,
                    item.getNs(), item.getEventId(), item.getEventName(), item.getCategory(), item.getType(), item.getSeverity());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result > 0;
    }

    public int batchAddEventMeta(List<EMMetaModel> items) {
        if (items == null) {
            return 0;
        }
        String sql = "insert into EM_META_EVENT (ns,event_id,event_name,category,type,severity) values (?,?,?,?,?,?)";
        Object[][] params = new Object[items.size()][6];
        for (int i = 0; i < items.size(); i++) {
            params[i][0] = items.get(i).getNs();
            params[i][1] = items.get(i).getEventId();
            params[i][2] = items.get(i).getEventName();
            params[i][3] = items.get(i).getCategory();
            params[i][4] = items.get(i).getType();
            params[i][5] = items.get(i).getSeverity();
        }

        QueryRunner runner = new QueryRunner(EMPool.getInstance().getDataSource());
        int result = 0;
        try {
            int[] r = runner.batch(sql, params);
            for (int rs: r) {
                result += rs;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public List<EMModel> listEvent(EMModelQueryParam param) {
        if (param == null || StringUtils.isEmpty(param.getInstanceId())) {
            return null;
        }
        String tableName = partition.getTable(param.getInstanceId()).getTableName();
        if (StringUtils.isEmpty(tableName)) {
            return null;
        }
        String sql = MessageFormat.format("select * from {0} where instance_id={1}", tableName, param.getInstanceId());
        if (param.getEventNo() != null && param.getEventNo() > 0) {
            sql += " and event_no = "+ param.getEventNo();
        }
        if (StringUtils.isNotEmpty(param.getEventId())) {
            sql += " and event_id = "+ param.getEventId();
        }
        if (param.getEventSt() != null && param.getEventEt() != null && param.getEventEt() > param.getEventSt()) {
            sql += " and event_st between  "+ param.getEventSt() + " and " + param.getEventEt();
        }
        if (param.getOffset() != null && param.getCount() != null) {
            sql += " limit  "+ param.getOffset() + "," + param.getCount();
        }
        QueryRunner runner = new QueryRunner(EMPool.getInstance().getDataSource());
        List<Map<String,Object>> values = null;
        try {
            values = runner.query(sql, new MapListHandler());
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        return EMUtil.invokeObject(values, new EMModel());
    }

    public Long addEvent(EMModel item) {
        if (item == null || StringUtils.isEmpty(item.getInstanceId())) {
            return null;
        }
        String tableName = partition.getTable(item.getInstanceId()).getTableName();
        if (StringUtils.isEmpty(tableName)) {
            return null;
        }
        item.setEventNo(IDWorker.id.nextId());
        String sql = "insert into {0} (event_no,event_id,event_name,event_category,event_type,event_severity,event_info,event_st,event_et,event_result,client_ip,instance_id) values (?,?,?,?,?,?,?,?,?,?,?,?)";
        sql = MessageFormat.format(sql, tableName);
        QueryRunner runner = new QueryRunner(EMPool.getInstance().getDataSource());
        int result = 0;
        try {
            result = runner.update(sql,
                    item.getEventNo(),
                    item.getEventId(),
                    item.getEventName(),
                    item.getEventCategory(),
                    item.getEventType(),
                    item.getEventSeverity(),
                    item.getEventInfo(),
                    item.getEventSt(),
                    item.getEventEt(),
                    item.getEventResult(),
                    item.getClientIp(),
                    item.getInstanceId());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (result > 0) {
            return item.getEventNo();
        }
        return null;
    }
}
