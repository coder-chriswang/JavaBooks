package com.neoway.iot.sdk.emk.model.constant;

/**
 * <pre>
 *  描述: SQL 语句定义
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/02 16:18
 */
public interface ConstantVariable {

    String EVENT_TABLE_PREFIX = "EM_VALUE";

    int EVENT_DATABASE_COUNT = 1;
}
