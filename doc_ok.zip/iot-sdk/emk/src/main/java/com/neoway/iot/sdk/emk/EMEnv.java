package com.neoway.iot.sdk.emk;

import java.util.HashMap;
import java.util.Map;

/**
 * 环境变量
 */
public class EMEnv {
    private static EMEnv env=null;
    private Map<String,Object> pro=new HashMap<>();
    private EMEnv(){
    }
    public static EMEnv getInstance(){
        if (env == null) {
            synchronized (EMEnv.class) {
                if (env == null) {
                    env = new EMEnv();
                }
            }
        }
        return env;
    }
    public void start(Map<String,Object> pro){
        this.pro=pro;
    }
    public void stop(){
        this.pro=null;
    }
    public String getValue(String key){
        if(pro.containsKey(key)){
            return String.valueOf(pro.get(key));
        }
        return "";

    }
}
