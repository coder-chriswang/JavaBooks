package com.neoway.iot.sdk.emk.params;

import lombok.Data;

@Data
public class EMMetaModelQueryParam {
    private String ns;
    private String eventId;
}
