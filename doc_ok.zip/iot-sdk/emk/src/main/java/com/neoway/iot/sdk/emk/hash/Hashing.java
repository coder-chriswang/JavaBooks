package com.neoway.iot.sdk.emk.hash;

/**
 * <pre>
 *  描述: Hash接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 10:19
 */
public interface Hashing {
    /**
     * hash运算
     *
     * @param key
     * @return
     */
    long hash(String key);

    /**
     * hash运算
     *
     * @param key
     * @return
     */
    long hash(byte[] key);

}
