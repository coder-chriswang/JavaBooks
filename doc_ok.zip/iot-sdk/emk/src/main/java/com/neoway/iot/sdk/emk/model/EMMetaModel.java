package com.neoway.iot.sdk.emk.model;

import lombok.Data;
import java.util.Date;

/**
* 事件元数据
*/
@Data
public class EMMetaModel {

    /**
     * 域
     */
    private String ns;

    /**
     * 事件ID
     */
    private String eventId;

    /**
     * 事件名称
     */
    private String eventName;

    /**
     * 分类
     */
    private String category;

    /**
     * 类别
     */
    private String type;

    /**
     * 等级
     */
    private String severity;


}