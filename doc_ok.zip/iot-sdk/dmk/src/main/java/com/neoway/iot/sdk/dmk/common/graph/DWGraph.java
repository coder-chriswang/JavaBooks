package com.neoway.iot.sdk.dmk.common.graph;

import java.util.*;

/**
 * 作者:angie_hawk7
 * 日期:2019/3/12 14:14
 * 描述:有向无环加权图数据结构和算法
 */
public class DWGraph implements Graph {
    private static final long serialVersionUID = 2459648624867648584L;
    //图标识
    private String name;
    //图形顶点集合
    private Map<String, DWGraphVertex> graphVertexs = new HashMap<>();

    public DWGraph() {

    }

    public DWGraph(String label) {
        this.name = label;
    }

    @Override
    public String getId() {
        return this.name;
    }

    @Override
    public synchronized int getVertexCount() {
        return graphVertexs.size();
    }

    @Override
    public synchronized int getEdgeCount() {
        int count = 0;
        for (GraphVertex v : graphVertexs.values()) {
            count += v.getEdges().size();
        }
        return count;
    }

    @Override
    public synchronized boolean addGraphElement(String src, String dst, int weight, Map<String, Object> ext) {
        DWGraphVertex srcVertex = graphVertexs.get(src);
        DWGraphVertex dstVertex = graphVertexs.get(dst);
        if (null == srcVertex) {
            srcVertex = new DWGraphVertex(src);
            graphVertexs.put(src, srcVertex);
        }
        if (null == dstVertex) {
            dstVertex = new DWGraphVertex(dst);
            graphVertexs.put(dst, dstVertex);
        }
        DWGraphEdge edge = new DWGraphEdge(srcVertex, dstVertex, weight, ext);
        srcVertex.addEdge(edge);
        return true;
    }

    @Override
    public synchronized boolean deleteGraphElement(String src, String dst, boolean force) {
        DWGraphVertex srcVertex = graphVertexs.get(src);
        return srcVertex.removeEdge(dst);

    }

    @Override
    public synchronized boolean removeGraphver(String id) {
        GraphVertex vertex = graphVertexs.get(id);
        if (null != vertex) {
            vertex.removeEdge(id);
            graphVertexs.remove(id);
        }
        return true;
    }

    @Override
    public synchronized GraphVertex getGraphVer(String id) {
        return graphVertexs.get(id);
    }

    @Override
    public synchronized List<Stack<GraphVertex>> getRoute(
            String startId, String endId, GraphCondition condition){
        List<Stack<GraphVertex>> routes = this.getAllRoute(startId, endId);
        return filter(routes, condition);
    }

    @Override
    public synchronized int getW(Stack<GraphVertex> route) {
        if (route == null || route.size() == 0) {
            return -1;
        }
        GraphVertex startVertex = route.get(0);
        int sum = 0;
        synchronized (route) {
            for (int index = 1; index < route.size(); index++) {
                GraphEdge edge = startVertex.getGraphEdge(route.get(index).getId());
                if (null == edge) {
                    return -1;
                } else {
                    sum += edge.getW();
                }
                startVertex = route.get(index);
            }
        }
        return sum;
    }

    @Override
    public int getW(String[] route) {
        if (route == null || route.length == 0) {
            return -1;
        }
        String startVerId = route[0];
        GraphVertex startVertex = this.getGraphVer(startVerId);
        int sum = 0;
        synchronized (route) {
            for (int index = 1; index < route.length; index++) {
                GraphEdge edge = startVertex.getGraphEdge(route[index]);
                if (null == edge) {
                    return -1;
                } else {
                    sum += edge.getW();
                }
                startVertex = this.getGraphVer(route[index]);
            }
        }
        return sum;
    }

    @Override
    public Stack<GraphVertex> generateMinTree() {
        //访问每一个顶点 权重最小的路径为最小生成树.普里姆算法和克鲁斯卡算法。本实现采用普里姆算法。

        return null;
    }

    @Override
    public boolean iscycle() {
        //采用拓扑排序
        return false;
    }

    @Override
    public String showRoute(Stack<GraphVertex> route) {
        StringBuilder sb = new StringBuilder();
        int index = 0;
        for (GraphVertex v : route) {
            sb.append(v.getId());
            index++;
            if (index != route.size()) {
                sb.append("->");
            }

        }
        return sb.toString();
    }

    /**
     * @param routes
     * @param condition
     * @return
     * @description 获取路径过滤
     */
    public List<Stack<GraphVertex>> filter(List<Stack<GraphVertex>> routes,
                                           GraphCondition condition){
        if (condition == null) {
            return routes;
        }
        List<Stack<GraphVertex>> filterRoutes = new ArrayList<>();
        if (GraphCondition.PrivateKey.NODE_COUNT == condition.getKey()) {
            for (Stack<GraphVertex> route : routes) {
                if (condition.getWhere() == GraphCondition.Where.EQUALS
                        && route.size() == condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.LT
                        && route.size() < condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.GT
                        && route.size() > condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.LET
                        && route.size() <= condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.GET
                        && route.size() >= condition.getValue()) {
                    filterRoutes.add(route);
                }
            }
        } else if (GraphCondition.PrivateKey.WEIGHT == condition.getKey()) {
            for (Stack<GraphVertex> route : routes) {
                if (condition.getWhere() == GraphCondition.Where.EQUALS
                        && this.getW(route) == condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.LT
                        && this.getW(route) < condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.GT
                        && this.getW(route) > condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.LET
                        && this.getW(route) <= condition.getValue()) {
                    filterRoutes.add(route);
                } else if (condition.getWhere() == GraphCondition.Where.GET
                        && this.getW(route) >= condition.getValue()) {
                    filterRoutes.add(route);
                }
            }
        } else {
            return filterRoutes;
        }
        return filterRoutes;


    }

    @Override
    public Stack<GraphVertex> getMinRoute(String startVerId, String endVerId){
        List<Stack<GraphVertex>> routes = this.getAllRoute(startVerId, endVerId);
        if (null == routes || routes.size() == 0) {
            return null;
        }
        Stack<GraphVertex> minRoute = null;
        int min = -1;
        for (Stack<GraphVertex> route : routes) {
            if (route == null || route.size() == 0) {
                continue;
            }
            int thw = this.getW(route);
            if (-1 == min || thw < min || (thw == min && route.size() < minRoute.size())) {
                min = thw;
                minRoute = route;
            }
        }
        return minRoute;
    }

    /**
     * @param startVerId
     * @param endVerId
     * @return
     * @description 获取所有可达路径
     */
    public synchronized List<Stack<GraphVertex>> getAllRoute(String startVerId, String endVerId) {
        GraphVertex start = this.getGraphVer(startVerId);
        GraphVertex end = this.getGraphVer(endVerId);
        if (null == start || null == end) {
            return null;
        }
        List<Stack<GraphVertex>> routes = new ArrayList<>();
        Stack<GraphVertex> stack = new Stack<>();
        stack.push(start);
        Stack<GraphVertex> visited = new Stack<>();
        GraphVertex preVertex = null;
        while (!stack.empty()) {
            if (stack.peek().equals(end) &&
                    visited.contains(stack.peek())) {
                routes.add((Stack) stack.clone());
                preVertex = stack.pop();
                visited.remove(preVertex);
                continue;
            }
            GraphVertex nextUnVisitedVer = this.getNextVertex(stack.peek(), preVertex);
            if (null == nextUnVisitedVer ||
                    visited.contains(nextUnVisitedVer)) {
                preVertex = stack.pop();
                visited.remove(preVertex);
            } else {
                stack.push(nextUnVisitedVer);
                visited.push(nextUnVisitedVer);
                preVertex = null;
            }

        }
        return routes;
    }

    /**
     * @param startVerId
     * @return
     * @description 指定起始点获取所有环路
     */
    public synchronized List<Stack<GraphVertex>> getCycleRoute(String startVerId) {
        List<Stack<GraphVertex>> cycles = new ArrayList<>();
        //起始顶点
        GraphVertex vertexStart = this.getGraphVer(startVerId);
        Stack<GraphVertex> stack = new Stack<>();
        stack.push(vertexStart);
        //栈顶节点刚刚访问过的接邻节点
        GraphVertex preVertex = null;
        while (!stack.empty()) {
            //获取从栈顶出发的下一个临界节点(preVertex之后的临界节点)
            GraphVertex unvisitedVector = this.getNextVertex(stack.peek(), preVertex);
            if (null == unvisitedVector) {
                preVertex = stack.pop();
            } else if (stack.contains(unvisitedVector)) {
                //打印 stack中unvisitedVector索引之后的路径
                int starIndex = stack.indexOf(unvisitedVector);
                Stack<GraphVertex> cycle = new Stack<>();
                for (int index = starIndex + 1, seq = 0; index < stack.size(); index++, seq++) {
                    cycle.push(stack.get(index));
                }
                cycle.push(unvisitedVector);
                cycles.add(cycle);
                preVertex = stack.pop();
            } else {
                stack.push(unvisitedVector);
                preVertex = null;
            }
        }
        return cycles;
    }


    /**
     * @param currentV
     * @param preVertex
     * @return
     * @description 获取指定顶点的下一个临接顶点
     */
    private synchronized GraphVertex getNextVertex(GraphVertex currentV,
                                                   GraphVertex preVertex) {
        Collection<GraphEdge> edges = currentV.getEdges();
        if (edges == null || edges.size() == 0) {
            return null;
        }
        if (null == preVertex) {
            Iterator<GraphEdge> iter = edges.iterator();
            while (iter.hasNext()) {
                return iter.next().getDstVertex();
            }
        } else {
            Iterator<GraphEdge> iter = edges.iterator();
            while (iter.hasNext()) {
                if (!iter.next().getDstVertex().getId().
                        equals(preVertex.getId())) {
                    continue;
                }
                if (iter.hasNext()) {
                    return iter.next().getDstVertex();
                }
            }
        }
        return null;

    }

    static class DWGraphVertex implements GraphVertex {
        private static final long serialVersionUID = -5294058806279139587L;
        private String id;
        private Map<String, Object> lables = new HashMap<>();
        private Map<String, GraphEdge> edges = new LinkedHashMap<>();

        public DWGraphVertex(String id, Map<String, GraphEdge> edges, Map<String, Object> lables) {
            this.id = id;
            if (edges != null) {
                this.edges = edges;
            }
            if (null != lables) {
                this.lables = lables;
            }

        }

        public DWGraphVertex(String id) {
            this(id, null, null);
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public Collection<GraphEdge> getEdges() {
            return edges.values();
        }

        @Override
        public Map<String, Object> getLables() {
            return lables;
        }

        @Override
        public synchronized boolean addEdge(GraphEdge edge) {
            if (this.edges.containsKey(edge.getId())) {
                this.removeEdge(edge.getId());
            }
            this.edges.put(edge.getId(), edge);
            return true;

        }

        @Override
        public synchronized boolean removeEdge(String id) {
            this.edges.remove(id);
            return true;
        }

        @Override
        public synchronized GraphEdge getGraphEdge(String dstId) {
            Iterator<GraphEdge> iter = this.getEdges().iterator();
            while (iter.hasNext()) {
                GraphEdge edge = iter.next();
                if (edge.getDstVertex().getId().equals(dstId)) {
                    return edge;
                }
            }
            return null;
        }
    }

    static class DWGraphEdge implements GraphEdge {
        private static final long serialVersionUID = 1923088483992835003L;
        private GraphVertex srcVer;
        private GraphVertex dstVer;
        private int weight;
        private Map<String, Object> extension;

        public DWGraphEdge(GraphVertex srcVer, GraphVertex dstVer, int weight, Map<String, Object> ext) {
            this.srcVer = srcVer;
            this.dstVer = dstVer;
            this.weight = weight;
            this.extension = ext;
        }

        public DWGraphEdge(GraphVertex inVer, GraphVertex outVer) {
            this(inVer, outVer, 0, null);
        }

        @Override
        public GraphVertex getDstVertex() {
            return dstVer;
        }

        @Override
        public GraphVertex getSrcVertex() {
            return srcVer;
        }

        @Override
        public Map<String, Object> getExtension() {
            return extension;
        }

        public int getW() {
            return this.weight;
        }
    }
}
