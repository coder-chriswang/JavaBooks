package com.neoway.iot.sdk.dmk;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: DM 环境变量
 * @author: 20200312686
 * @date: 2020/6/22 13:57
 */
public class DMEnv {
    private static DMEnv env=null;
    private Map<String,Object> pro=new HashMap<>();
    private DMEnv(){
    }
    public static DMEnv getInstance(){
        if (env == null) {
            synchronized (DMEnv.class) {
                if (env == null) {
                    env = new DMEnv();
                }
            }
        }
        return env;
    }
    public void start(Map<String,Object> pro){
        this.pro=pro;
    }
    public void stop(){
        this.pro=null;
    }
    public String getValue(String key){
        if(pro.containsKey(key)){
            return String.valueOf(pro.get(key));
        }
        return "";

    }
}
