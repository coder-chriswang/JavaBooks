package com.neoway.iot.sdk.dmk.data;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.gson.Gson;
import com.neoway.iot.sdk.dmk.DMEnv;
import com.neoway.iot.sdk.dmk.meta.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: DMCache-Guava实现类
 * @author: 20200312686
 * @date: 2020/6/22 13:49
 */
public class DMCacheWithGuava implements DMCache {
    private static final String CACHE_SPLIT="@##@";

    private static final Logger LOG = LoggerFactory.getLogger(DMCacheWithGuava.class);
    private DMMetaCache metaCache;
    private DMEnv env;
    private LoadingCache<String, List<DMDataColumn>> cache;

    @Override
    public void start() {
        env=DMEnv.getInstance();
        metaCache=DMMetaCache.getInstance();
        String cacheMax=env.getValue(CACHE_MAX);
        String cacheInit=env.getValue(CACHE_INIT);
        int cacheMaxSize=500000;
        int cacheInitSize=1000;
        if(StringUtils.isNotEmpty(cacheMax)){
            cacheMaxSize=Integer.valueOf(cacheMax);
        }
        if(StringUtils.isNotEmpty(cacheInit)){
            cacheInitSize=Integer.valueOf(cacheInit);
        }
        cache= CacheBuilder.newBuilder()
                .maximumSize(cacheMaxSize)
                .recordStats()
                .initialCapacity(cacheInitSize)
                .build(new CacheLoader<String, List<DMDataColumn>>() {
                    @Override
                    public List<DMDataColumn> load(String s) throws Exception {
                        LOG.debug("数据缓存不存在，从数据库加载:s={}",s);
                        return getColumnValue(s);
                    }
                });
    }

    @Override
    public void load() {
        //查找所有ci元数据，获取哪些ci需要缓存。
        Map<String, DMMetaCI> metaMap=metaCache.getAllMetaCI();
        if(MapUtils.isEmpty(metaMap)){
            return;
        }
        for(DMMetaCI metaCI:metaMap.values()){
            if(!metaCI.isCache()){
                continue;
            }
            try{
                DMDataPoint point=DMDataPoint.builder(metaCI);
                List<Map<String,Object>> values=DMDml.query(point);
                if(CollectionUtils.isEmpty(values)){
                    continue;
                }
                for(Map<String,Object> columnMap:values){
                    point=DMDataPoint.builder(metaCI);
                    point.buildColumns(columnMap);
                    String key=buildCacheKey(point);
                    cache.put(key,point.getColumns());
                }
            }catch (Exception e){
                LOG.error(e.getMessage(),e);
            }
        }
        LOG.info("装载的数据记录数量为:{}",cache.size());
    }

    /**
     * 根据缓存KEY查询数据
     * @param key
     * @return
     */
    private List<DMDataColumn> getColumnValue(String key){
        String[] params=key.split(CACHE_SPLIT);
        String ns=params[0];
        String tenent=params[1];
        String ci=params[2];
        DMMetaCI metaCI=metaCache.getMetaCI(ns,tenent,ci);
        DMDataPoint point=DMDataPoint.builder(metaCI);
        List<DMMetaAttr> primarys=metaCI.buildPrimaryAttr();
        for(int index=3;index<params.length;index++){
            DMMetaAttr metaAttr=primarys.get(index-3);
            DMDataColumn column=new DMDataColumn(metaAttr.getId(),params[index]);
            point.addColumn(column);
        }
        try{
            Map<String,Object> columnMap= DMDml.get(point);
            if(MapUtils.isEmpty(columnMap)){
                return new ArrayList<>();
            }
            point=DMDataPoint.builder(metaCI);
            point.buildColumns(columnMap);
            return point.getColumns();
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return null;
        }


    }
    /**
     * @desc 构建数据缓存key
     * @param point
     * @return
     */
    public String buildCacheKey(DMDataPoint point){
        StringBuilder sb=new StringBuilder();
        DMMetaCI metaCI=point.getMetaCI();
        sb.append(metaCI.getNs().toLowerCase()).append(CACHE_SPLIT)
                .append(metaCI.getTenent())
                .append(CACHE_SPLIT).append(metaCI.getCi());
        for(DMDataColumn column:point.getColumns()){
            if(column.isPrimary){
                sb.append(CACHE_SPLIT).append(column.value.toString());
            }
        }
        return sb.toString();
    }

    @Override
    public void clear() {
        this.cache.cleanUp();
    }

    @Override
    public void write(DMDataPoint data) {
        String key=buildCacheKey(data);
        cache.put(key,data.getColumns());
    }

    @Override
    public DMDataPoint read(DMDataPoint data) {
        String key=buildCacheKey(data);
        try{
            DMDataPoint point=DMDataPoint.builder(data.getMetaCI());
            List<DMDataColumn> columnValues= cache.get(key);
            point.setColumns(columnValues);
            return SerializationUtils.clone(point);
        }catch (Exception e){
            LOG.warn("缓存数据获取异常。指定key={}",key);
            return null;
        }

    }

    @Override
    public void remove(DMDataPoint data) {
        String key=buildCacheKey(data);
        cache.refresh(key);
    }
}
