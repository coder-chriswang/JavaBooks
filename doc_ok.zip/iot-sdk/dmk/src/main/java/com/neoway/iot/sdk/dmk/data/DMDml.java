package com.neoway.iot.sdk.dmk.data;

import com.google.gson.Gson;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.common.db.DMSQL;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: DM DML操作
 * @author: 20200312686
 * @date: 2020/6/22 13:19
 */
public class DMDml {
    private static final Logger LOG = LoggerFactory.getLogger(DMDml.class);
    /**
     * @param point 数据
     * @desc 数据写入操作
     */
    public static void addData(DMDataPoint point) throws SQLException {
        //3：写入对象详情表
        String ns=point.getMetaCI().getNs();
        if(point.getMetaCI().isCache()){
            DMCache cache=DMCacheBuilder.getInstance().getCache();
            DMDataPoint cachePoint=cache.read(point);
            if(null != cachePoint && CollectionUtils.isNotEmpty(cachePoint.getColumns())){
                cachePoint.unionColumns(point.getColumns());
                point=cachePoint;
            }
        }
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns));
        String sql= point.buildAddSQL();
        Object[] params= point.buildAddParams();
        runner.update(sql,params);
    }

    /**
     * @param points 数据集
     * @desc 批量写入数据
     */
    public static void addDatas(List<DMDataPoint> points) throws SQLException {
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        DMCache cache=DMCacheBuilder.getInstance().getCache();
        DMDataPoint headPoint=null;
        Object[][] params=new Object[points.size()][];
        for(int index=0;index<points.size();index++){
            DMDataPoint point= points.get(index);
            if(point.getMetaCI().isCache()){
                DMDataPoint cachePoint=cache.read(point);
                if(null == cachePoint || CollectionUtils.isEmpty(cachePoint.getColumns())){
                    //TODO 补齐属性 当查询为空 则会出现headPoint 列和数据不对应  写库失败
                    LOG.info("缓存不存在：{}",new Gson().toJson(point.getColumns()));
                }else{
                    cachePoint.unionColumns(point.getColumns());
                    point=cachePoint;
                }
            }
            params[index]= point.buildAddParams();
            if(null == headPoint){
                headPoint=point;
            }
        }
        String sql=headPoint.buildAddSQL();
        String ns=headPoint.getMetaCI().getNs();
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns));
        runner.batch(sql,params);
    }

    /**
     * @param point 查询条件
     * @return 对象详情
     * @desc 查询详情
     */
    public static Map<String,Object> get(DMDataPoint point) throws SQLException {
        String ns=point.getMetaCI().getNs();
        String table=point.getMetaCI().buildTable();
        String where=point.buildQueryCondition();
        String sql= MessageFormat.format(DMSQL.DML_CI_INSTANCE_GET.getSql(),
                table,where);
        Object[] param=point.buildParams();
        LOG.debug("查询语句={},条件={}",sql,param);
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns));
        Map<String, Object> value = runner.query(sql, new MapHandler(),param);
        return value;
    }

    /**
     * @param point 查询条件
     * @return 数据集
     * @desc 条件查询
     */
    public static List<Map<String,Object>> query(DMDataPoint point) throws SQLException {
        String ns=point.getMetaCI().getNs();
        String where=point.buildQueryCondition();
        String table=point.getMetaCI().buildTable();
        String sql= MessageFormat.format(DMSQL.DML_CI_INSTANCES_QUERY.getSql(),
                table,where);
        Object[] param=point.buildParams();
        LOG.debug("查询语句={},条件={}",sql,param);
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ns));
        List<Map<String,Object>> values = runner.query(sql,new MapListHandler(),param);
        return values;
    }

    /**
     * @desc 执行的sql语句
     * @param sql
     * @return
     * @throws SQLException
     */
    public static List<Map<String,Object>> search(String sql) throws SQLException{
        LOG.debug("执行的SQL语句={}",sql);
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        List<Map<String,Object>> values = runner.query(sql,new MapListHandler());
        return values;
    }
}
