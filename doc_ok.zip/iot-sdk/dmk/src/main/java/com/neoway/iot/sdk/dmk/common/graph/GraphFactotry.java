package com.neoway.iot.sdk.dmk.common.graph;

import com.opencsv.CSVParser;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 作者:angie_hawk7
 * 日期:2019/3/12 17:13
 * 描述:xxx
 */
public class GraphFactotry {

    public enum GraphType {
        DIRECT,
        CYCLE_DIRECT,
        NODIRECT
    }

    /**
     * @param sql  图形数据源SQL
     * @param name 图形名称
     * @param type 图形类型
     * @return graph实例
     * @description创建图形实例
     */
    public static Graph buildGraphWithSQL(String sql, String name, GraphType type) {
        //TODO
        return null;
    }

    /**
     * @param name   图形名称
     * @param points 图形数据
     * @param type   图形类型
     * @return graph实例
     * @description创建图形实例
     */
    public static Graph buildGraph(List<GraphDataPoint> points, String name, GraphType type)
            throws IllegalAccessException, InstantiationException {
        Graph graph = null;
        if (null == points && points.size() == 0) {
            return null;
        }
        if (GraphType.NODIRECT == type) {

        } else if (GraphType.CYCLE_DIRECT == type) {
            graph = new DWCycleGraph(name);
        } else {
            graph = new DWGraph(name);
        }
        for (GraphDataPoint point : points) {
            graph.addGraphElement(point.getSrc(), point.getDst(),
                    point.getWeight(), point.getEdgeInfos());
        }
        return graph;
    }

    /**
     * @param name 图形名称
     * @param path 图形数据文件绝对路径 CSV数据格式
     * @param type 图形类型
     * @return graph实例
     * @description创建图形实例
     */
    public static Graph buildGraphWithFile(String path, String name, GraphType type)
            throws IllegalAccessException, InstantiationException, IOException {
        CSVReader reader = new CSVReader(new FileReader(path), CSVParser.DEFAULT_SEPARATOR);
        Iterator<String[]> iter = reader.iterator();
        List<GraphDataPoint> dataPoints = new ArrayList<>();
        while (iter.hasNext()) {
            String[] data = iter.next();
            GraphDataPoint point = new GraphDataPoint(data[0], data[1], Integer.valueOf(data[2]));
            point.setEdgeInfos(null);
            dataPoints.add(point);
        }
        return buildGraph(dataPoints, name, type);
    }
}
