package com.neoway.iot.sdk.dmk.meta;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Element;
import org.dom4j.Node;

import java.io.Serializable;
import java.text.MessageFormat;

/**
 * @desc: 元数据-对象操作指令
 * @author: 20200312686
 * @date: 2020/6/22 13:02
 */
public class DMMetaAction implements Serializable {
    public static final String TYPE_SYSTEM="System";
    public static final String TYPE_DEVICE="Device";
    //产品域
    public String ns;
    //租户域
    public String tenent;
    //对象类型
    public String ci;
    //指令ID
    public String id;
    //指令域
    public String domain;
    //指令名称
    public String name;
    //指令描述
    public String desc;
    //指令类型
    public String type;
    //指令级别
    public String severity;
    //指令关联的模板ID
    public String templateid;
    //指令条件
    public String condition;

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getTemplateid() {
        return templateid;
    }

    public void setTemplateid(String templateid) {
        this.templateid = templateid;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getTenent() {
        return tenent;
    }

    public void setTenent(String tenent) {
        this.tenent = tenent;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    /**
     * @desc 获取insert参数
     * @return
     */
    public Object[] buildParams(){
        Object[] params={this.getNs(),this.getTenent(),this.getCi(),this.getId(),this.getName(),
                this.getDesc(),this.getDomain(),this.getType(),this.getSeverity(),this.getTemplateid(),
                this.getCondition(),System.currentTimeMillis()/1000};
        return params;
    }
    /**
     * @param node
     * @param metaCI
     * @return
     * @desc
     */
    public static DMMetaAction buildMetaAction(Node node, DMMetaCI metaCI) {
        DMMetaAction action = new DMMetaAction();
        action.setCi(metaCI.getCi());
        action.setNs(metaCI.getNs());
        action.setTenent(metaCI.getTenent());
        Element root = (Element) node;
        Element el = root.element("id");
        action.setId(el.getTextTrim());
        el = root.element("name");
        if (null != el) {
            action.setName(el.getTextTrim());
        }
        el = root.element("desc");
        if (null != el) {
            action.setDesc(el.getTextTrim());
        }
        el = root.element("type");
        if (null != el) {
            action.setType(el.getTextTrim());
        }
        el = root.element("templateid");
        if (null != el) {
            action.setTemplateid(el.getTextTrim());
        }
        el = root.element("domain");
        if (null != el) {
            action.setDomain(el.getTextTrim());
        }
        el = root.element("severity");
        if (null != el) {
            action.setSeverity(el.getTextTrim());
        }
        el = root.element("condition");
        if (null != el) {
            action.setCondition(el.getTextTrim());
        }
        return action;
    }
    public void validate(){
        if(StringUtils.isEmpty(this.id)){
            String erMsgTpl="attr属性非法。ns={0},ci={1},id为空！";
            String errMsg= MessageFormat.format(erMsgTpl,this.ns,this.ci);
            throw new RuntimeException(errMsg);
        }
        if(StringUtils.isEmpty(this.name)){
            String erMsgTpl="attr属性-name为空。ns={0},ci={1},指令id={2}！";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci,this.id);
            throw new RuntimeException(errMsg);
        }
        if(!(TYPE_DEVICE.equals(this.type) || TYPE_SYSTEM.equals(this.type))){
            String erMsgTpl="action属性-type非法。ns={0},ci={1},指令id={2}！";
            String errMsg=MessageFormat.format(erMsgTpl,this.ns,this.ci,this.id);
            throw new RuntimeException(errMsg);
        }
    }
}
