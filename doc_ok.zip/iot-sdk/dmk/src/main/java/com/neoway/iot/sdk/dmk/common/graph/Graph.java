package com.neoway.iot.sdk.dmk.common.graph;

import java.io.Serializable;
import java.util.*;

/**
 * 作者:angie_hawk7
 * 日期:2019/3/12 13:11
 * 描述:图数据结构
 */
public interface Graph extends Serializable {

    /**
     * @return 图形名称
     * @description: 获取图形名称
     */
    String getId();

    /**
     * @return 图顶点数量
     * @description 获取图形顶点数量
     */
    int getVertexCount();

    /**
     * @return 图边数量
     * @description 获取图形边数量
     */
    int getEdgeCount();

    /**
     * 添加图形元素
     *
     * @param src    源顶点ID
     * @param dst    目标顶点ID
     * @param weight 权重
     * @param ext    扩展信息
     * @return
     */
    boolean addGraphElement(String src, String dst, int weight, Map<String, Object> ext);

    /**
     * 移除图形元素
     *
     * @param src
     * @param dst
     * @param force 当移除元素后，如果顶点变为了孤点，是否强制删除孤点
     * @return
     */
    boolean deleteGraphElement(String src, String dst, boolean force);

    /**
     * @param id 顶点ID
     * @return 成功或失败
     * @description 移除图形顶点
     */
    boolean removeGraphver(String id);

    /**
     * @param id 顶点ID
     * @return 图形顶点
     * @description 根据图形顶点ID查询图形顶点
     */
    GraphVertex getGraphVer(String id);

    /**
     * @param startId 起始顶点
     * @param endId   目标顶点
     * @return 所有可达路径
     * @description 获取所有可达路径
     */
    List<Stack<GraphVertex>> getRoute(String startId, String endId, GraphCondition condition);

    /**
     * @param startId 起始顶点
     * @param endId   目标顶点
     * @return 最短路径
     * @description 获取最短路径
     */
    Stack<GraphVertex> getMinRoute(String startId, String endId);

    /**
     * @param route
     * @return
     * @description 指定路径获取权重
     */
    int getW(Stack<GraphVertex> route);

    /**
     * @param route
     * @return
     * @description 指定路径获取权重
     */
    int getW(String[] route);

    /**
     * @return
     * @description 获取最小生成数
     */
    Stack<GraphVertex> generateMinTree();

    /**
     * @return true存在，else不存在
     * @description 是否存在环路
     */
    boolean iscycle();

    /**
     * @param route
     * @return
     * @description 打印路径显示格式
     */
    default String showRoute(Stack<GraphVertex> route) {
        StringBuilder sb = new StringBuilder();
        int index = 0;
        for (GraphVertex v : route) {
            sb.append(v.getId());
            index++;
            if (index != route.size()) {
                sb.append("->");
            }

        }
        return sb.toString();
    }


    /**
     * @description 图顶点数据结构
     */
    interface GraphVertex extends Serializable, Cloneable {
        /**
         * @return 顶点ID
         * @description 获取顶点ID
         */
        String getId();

        /**
         * @return 弧出边集合
         * @description 获取弧出边
         */
        Collection<GraphEdge> getEdges();

        /**
         * @return 附加信息
         * @description 获取所有附加信息 如果K为对象，则K必须实现hashcode与equals方法
         */
        Map<String, Object> getLables();

        /**
         * @param edge 边信息
         * @return 添加结果 true或false
         * @description 添加弧出边
         */
        boolean addEdge(GraphEdge edge);

        /**
         * @param id 移除的边ID
         * @return 移除结果 true 或false
         * @description 移除弧出边
         */
        boolean removeEdge(String id);


        /**
         * @param outVerId 弧出顶点ID
         * @return 边
         * @description 根据弧出顶点ID返回边信息
         */
        GraphEdge getGraphEdge(String outVerId);
    }

    /**
     * @description 图边结构
     */
    interface GraphEdge extends Serializable, Cloneable {
        /**
         * @return
         * @description 获取边ID
         */
        default String getId() {
            return getSrcVertex().getId() + getDstVertex().getId() + getW();
        }

        /**
         * @return 出度顶点ID
         * @description 获取入度顶点ID
         */
        GraphVertex getDstVertex();

        /**
         * @return 入度顶点ID
         * @description获取出度顶点ID
         */
        GraphVertex getSrcVertex();

        /**
         * @return 扩展信息
         * @description 获取边的扩展信息
         */
        Map<String, Object> getExtension();

        /**
         * @return 返回权重
         * @description 获取权重
         */
        default int getW() {
            return 0;
        }

    }
}
