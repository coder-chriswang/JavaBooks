package com.neoway.iot.sdk.dmk;

import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.data.*;
import com.neoway.iot.sdk.dmk.meta.DMMMetaNs;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaCache;
import com.neoway.iot.sdk.dmk.meta.DMMetaDdl;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: DMK操作入口类
 * @author: 20200312686
 * @date: 2020/6/22 19:45
 */
public class DMRunner {
    private static final Logger LOG = LoggerFactory.getLogger(DMRunner.class);
    private static DMRunner runner=null;
    private DMMetaCache cache;
    private DMCache dcache;
    private DMRunner(){
    }
    public static DMRunner getInstance(){
        if(runner == null){
            synchronized (DMRunner.class){
                if(runner == null){
                    runner=new DMRunner();
                }
            }
        }
        return runner;
    }

    /**
     * @desc dmk启动初始化
     * @param pro dmk初始化变量
     */
    public void start(Map<String,Object> pro){
        DMEnv.getInstance().start(pro);
        DMPool.getInstance().start();
        try{
            DMMetaDdl.createAresTable();
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="创建Ares元数据存储表失败,失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }
        this.cache=DMMetaCache.getInstance();
        this.cache.start();
        DMCacheBuilder.getInstance().start();
        this.dcache=DMCacheBuilder.getInstance().getCache();
    }

    /**
     * @desc dmk停止
     */
    public void stop(){
        DMCacheBuilder.getInstance().stop();
        this.cache.stop();
        DMPool.getInstance().stop();
        DMEnv.getInstance().stop();
    }
    /**
     * 添加模型
     * @param path 模型文件目录
     * @param ns 产品域
     */
    public List<DMMetaCI> addMeta(String path,DMMMetaNs ns) throws RuntimeException{
        List<DMMetaCI> metaCis=new ArrayList<>();
        File f = new File(path);
        if (!f.exists()) {
            this.addMetaNs(ns);
            String erMsgTpl="dm模型目录文件不存在。ns={0},文件路径={1}";
            String errMsg= MessageFormat.format(erMsgTpl,ns.getId(),path);
            LOG.warn(errMsg);
            return null;
        }
        File[] fs = f.listFiles();
        if (null == fs) {
            this.addMetaNs(ns);
            LOG.warn("目录下未发现dm模型文件.ns={}，文件路径={}",ns.getId(),path);
            return null;
        }
        for (File dmf : fs) {
            DMMetaCI metaCI = DMMetaCI.buildMetaCI(dmf.getAbsolutePath(), ns);
            this.addMeta(ns,metaCI);
            metaCis.add(metaCI);
        }
        //初始化ns模型空间
        return metaCis;
    }

    /**
     * @desc 添加产品域
     * @param ns
     */
    public void addMetaNs(DMMMetaNs ns){
        LOG.info("添加产品域对象:ns={}",ns.getId());
        try{
            //判断是否已经创建了该产品域库模型
            if(this.cache.exsitNs(ns.getId())){
                return;
            }
            if(ns.isNeedCreateDB()){
                //创建产品域资源库
                DMMetaDdl.initNSDB(ns);
            }
            //更新缓存
            this.cache.writeNsCache(ns);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="初始化产品域失败。ns={0},失败原因={1}";
            String errMsg= MessageFormat.format(erMsgTpl,ns.getId(),e.getMessage());
            throw new RuntimeException(errMsg);
        }finally {
            LOG.info("添加产品域对象结束:ns={}",ns.getId());
        }

    }

    /**
     * @desc 添加ci模型
     * @param metaCi
     */
    public void addMetaCI(DMMetaCI metaCi){
        LOG.info("添加模型对象:ns={},ci={}",metaCi.getNs(),metaCi.getCi());
        try{
            /*if(this.cache.exsitMetaCI(metaCi)){
                return;
            }*/
            //创建产品域资源库表
            DMMetaDdl.createMetaTable(metaCi);
            //添加资源模型源数据
            DMMetaDdl.addMetaCI(metaCi);
            //更新缓存模型
            this.cache.write(metaCi);

        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="初始化模型失败。ns={0},ci={1},失败原因={2}";
            String errMsg= MessageFormat.format(erMsgTpl,metaCi.getNs(),metaCi.getCi(),e.getMessage());
            throw new RuntimeException(errMsg);
        }finally {
            LOG.info("添加模型对象结束:ns={},ci={}",metaCi.getNs(),metaCi.getCi());
        }
    }
    /**
     * @desc 添加模型
     * @param ns
     * @param metaCi
     * @throws Exception
     */
    public void addMeta(DMMMetaNs ns,DMMetaCI metaCi){
        addMetaNs(ns);
        addMetaCI(metaCi);

    }
    /**
     * @desc 对象数据写入(添加或更新)
     * @param datas 资源列表
     */
    public void write(List<DMDataPoint> datas){
        if(CollectionUtils.isEmpty(datas)){
            return;
        }
        Map<DMMetaCI,List<DMDataPoint>> group=new HashMap<>();
        for(DMDataPoint point:datas){
            List<DMDataPoint> groupDatas=group.get(point.getMetaCI());
            if(CollectionUtils.isEmpty(groupDatas)){
                groupDatas=new ArrayList<>();
                group.put(point.getMetaCI(),groupDatas);
            }
            groupDatas.add(point);
        }
        try{
            for(List<DMDataPoint> values:group.values()){
                DMDml.addDatas(values);
            }
        }catch (SQLException e){
            e.printStackTrace();
            LOG.error(e.getMessage(),e);
            String erMsgTpl="资源写入失败。失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }
    }
    /**
     * @desc 对象数据写入
     * @param data 资源
     */
    public void write(DMDataPoint data){
        try{
            DMDml.addData(data);
        }catch (SQLException e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="资源写入失败。失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }
    }
    /**
     * @desc 对象数据列表查询
     * @param condition 查询条件
     * @return 资源列表
     */
    public List<DMDataPoint> list(DMDataPoint condition){
        try{
            List<DMDataPoint> result=new ArrayList<>();
            List<Map<String,Object>> values=DMDml.query(condition);
            if(CollectionUtils.isEmpty(values)){
                return null;
            }
            for(Map<String,Object> value:values){
                DMDataPoint dataPoint=DMDataPoint.builder(condition.getMetaCI()).buildColumns(value);
                result.add(dataPoint);
            }
            return result;
        }catch (SQLException e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="对象列表查询失败。失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }

    }

    /**
     * @desc 对象数据详情查询
     * @param condition
     * @return
     */
    public DMDataPoint get(DMDataPoint condition){
        try{
            Map<String,Object> value= DMDml.get(condition);
            if(MapUtils.isEmpty(value)){
                return null;
            }
            return DMDataPoint.builder(condition.getMetaCI()).buildColumns(value);
        }catch (SQLException e){
            LOG.error(e.getMessage(),e);
            String erMsgTpl="对象详情查询失败。失败原因={0}";
            String errMsg= MessageFormat.format(erMsgTpl,e.getMessage());
            throw new RuntimeException(errMsg);
        }
    }

    /**
     * @desc 对象数据条件删除
     * @param condition 删除条件
     */
    public void delete(DMDataPoint condition){

    }
    /**
     * @desc 根据原始ID查询资源缓存数据
     * @param data
     * @return
     */
    public DMDataPoint getHotByPrimary(DMDataPoint data){
        return this.dcache.read(data);
    }


    /**
     * @desc 添加国际化词条
     * @param ns 产品域
     * @param lan 语言
     * @param value 词条信息
     */
    public void addI18n(String ns,String lan,Map<String,Object> value){

    }

    /**
     * @desc 获取指定ci的元数据
     * @param ns 产品域
     * @param tenent 租户
     * @param ci ci
     * @return
     */
    public DMMetaCI getMetaCI(String ns,String tenent,String ci){
        try{
            DMMetaCI metaCI= DMMetaDdl.getMetaCI(ns,tenent,ci);
            return metaCI;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException("查询CI元数据出错:"+e.getMessage());
        }

    }

    /**
     * @desc sql语句执行。
     * @param sql  sql语句需指定完整的数据库
     * @return
     */
    public List<Map<String,Object>> search(String sql){
        try{
            return DMDml.search(sql);
        }catch (SQLException e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException("查询数据出错:"+e.getMessage());
        }

    }
    /**
     * @desc 获取所有CI元数据
     * @return
     */
    public List<DMMetaCI> queryMetaCi(){
        try {
            return DMMetaDdl.queryAllMetaCI();
        } catch (SQLException e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException("查询所有CI元数据出错:"+e.getMessage());
        }
    }
}
