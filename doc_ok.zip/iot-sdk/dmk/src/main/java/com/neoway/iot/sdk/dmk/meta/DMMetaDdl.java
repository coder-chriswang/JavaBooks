package com.neoway.iot.sdk.dmk.meta;

import com.neoway.iot.sdk.dmk.DMUtil;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.common.db.DMSQL;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: DM DDL操作
 * @author: 20200312686
 * @date: 2020/6/22 13:13
 */
public class DMMetaDdl {
    private static final Logger LOG = LoggerFactory.getLogger(DMMetaDdl.class);
    /**
     * @desc 创建ARES元数据表
     * @throws SQLException
     */
    public static void createAresTable() throws SQLException{
        LOG.info("开始创建Ares元数据表");
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        runner.update(DMSQL.DDL_ARES_CREATE_TABLE_NS.getSql());
        runner.update(DMSQL.DDL_ARES_CREATE_TABLE_CI.getSql());
        runner.update(DMSQL.DDL_ARES_CREATE_TABLE_ATTR.getSql());
        runner.update(DMSQL.DDL_ARES_CREATE_TABLE_ACTION.getSql());
        runner.update(DMSQL.DDL_ARES_CREATE_TABLE_I18N.getSql());
        runner.update(DMSQL.DDL_ARES_CREATE_TABLE_RELATION.getSql());
        LOG.info("创建Ares元数据表结束");
    }

    /**
     * @desc 创建产品域资源库
     * @param ns
     * @throws SQLException
     */
    public static void initNSDB(DMMMetaNs ns) throws SQLException {
        LOG.info("开始创建产品域资源库");
        //创建产品库
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        String sql= MessageFormat.format(DMSQL.DDL_NS_CREATE_DATABASE.getSql(),ns.getId().toLowerCase());
        runner.update(sql);
        //写入产品域记录集
        Object[] params=ns.getParams();
        runner.update(DMSQL.DML_NS_INSERT.getSql(),params);
        LOG.info("创建产品域资源库结束");
    }

    /**
     * 查询产品域记录集
     * @return
     * @throws SQLException
     */
    public static List<DMMMetaNs> queryNS() throws SQLException {
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        return runner.query(DMSQL.DML_NS_QUERY.getSql(),new BeanListHandler<>(DMMMetaNs.class));
    }

    /**
     * 查询指定产品域记录
     * @param id
     * @return
     * @throws SQLException
     */
    public static DMMMetaNs getNS(String id) throws SQLException {
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        return runner.query(DMSQL.DML_NS_GET.getSql(),new BeanHandler<>(DMMMetaNs.class));
    }

    /**
     * @desc 根据元数据创建表
     * @param ci 对象元数据
     */
    public static void createMetaTable(DMMetaCI ci) throws SQLException{
        LOG.info("开始根据元数据创建产品域资源库表:产品域={},对象={}",ci.getNs(),ci.getCi());
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getNsDataSource(ci.getNs()));
        String table=ci.buildTable();
        String tableCol=buildTableColumn(ci);
        String commet="'"+ci.getName()+"'";
        String sql= MessageFormat.format(DMSQL.DDL_INSTANCE_CREATE_TABLE.getSql(),table,tableCol,commet);
        LOG.debug("产品域={},对象={},建表SQL={}",ci.getNs(),ci.getCi(),sql);
        runner.update(sql);
        LOG.info("根据元数据创建产品域资源库表结束:产品域={},对象={}",ci.getNs(),ci.getCi());
    }

    /**
     * @desc 构建数据表字段
     * @param ci
     * @return
     */
    public static String buildTableColumn(DMMetaCI ci){
        StringBuilder sb=new StringBuilder();
        List<DMMetaAttr> metaAttrs=ci.getAttrs();
        if(CollectionUtils.isEmpty(metaAttrs)){
            throw new RuntimeException("对象属性列表为空");
        }
        List<String> primaryK=new ArrayList<>();
        List<String> indexK=new ArrayList<>();
        //构建SQL列语句
        for(DMMetaAttr metaAttr:metaAttrs){
            if(metaAttr.isPrimary()){
                primaryK.add(metaAttr.getId());
            }
            if(metaAttr.isIndex()){
                indexK.add(metaAttr.getId());
            }
            String column=metaAttr.buildAttrColumn();
            if(StringUtils.isEmpty(column)){
                String err= MessageFormat.format("对象属性类型非法,属性ID={0},属性类型={1}",metaAttr.getId(),metaAttr.getType());
                throw new RuntimeException(err);
            }
            sb.append(column).append(",");
        }
        //构建主键语句
        String primary=buildTablePrimary(primaryK);
        sb.append(primary);

        //构建索引语句
        String index=buildTableIndex(indexK);
        sb.append(index);
        return sb.toString();
    }

    /**
     * @desc 构建主键语句
     * @param primaryAttrs
     * @return
     */
    public static String buildTablePrimary(List<String> primaryAttrs){
        StringBuilder sb=new StringBuilder();
        int index=0;
        for(String primary:primaryAttrs){
            index++;
            sb.append("`").append(primary.toLowerCase()).append("`");
            if(index < primaryAttrs.size()){
                sb.append(",");
            }
        }
        String primarySQL= MessageFormat.format(DMSQL.DDL_INSTANCE_CREATE_TABLE_PRIMARY.getSql(),sb.toString());
        return primarySQL;
    }

    /**
     * @desc 构建索引语句
     * @param indexAttrs
     * @return
     */
    public static String buildTableIndex(List<String> indexAttrs){
        StringBuilder sb=new StringBuilder();
        for(String index:indexAttrs){
            sb.append(",");
            String indexName="index_"+ index;
            String indexSQL= MessageFormat.format(DMSQL.DDL_INSTANCE_CREATE_TABLE_INDEX.getSql(),indexName,index);
            sb.append(indexSQL);
        }
        return sb.toString();
    }
    /**
     * @desc 添加元数据
     * @throws SQLException
     */
    public static void addMetaCI(DMMetaCI ci) throws SQLException{
        LOG.info("开始元数据记录：产品域={},对象={}",ci.getNs(),ci.getCi());
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        Object[] params=ci.buildParams();
        //单条
        runner.update(DMSQL.DML_META_CI_INSERT.getSql(),params);
        //批量写入attr表
        runner.batch(DMSQL.DML_META_ATTR_INSERT.getSql(),ci.buildAttrParams());
        //批量写入action表
        runner.batch(DMSQL.DML_META_ACTION_INSERT.getSql(),ci.buildActionsParams());
        LOG.info("元数据记录添加结束：产品域={},对象={}",ci.getNs(),ci.getCi());
    }

    /**
     * @desc 查询MetaCI详情
     * @param ns
     * @param tenent
     * @param ci
     * @return
     * @throws SQLException
     */
    public static DMMetaCI getMetaCI(String ns,String tenent,String ci) throws SQLException{
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        Object[] ciParams={ns,tenent,ci};
        DMMetaCI metaCI= runner.query(DMSQL.DML_META_CI_GET.getSql(),new BeanHandler<>(DMMetaCI.class),ciParams);
        Object[] params={metaCI.getNs(),metaCI.getTenent(),metaCI.getCi()};
        List<Map<String,Object>> metaAttrMaps= runner.query(DMSQL.DML_META_ATTR_QUERY.getSql(),new MapListHandler(),params);
        if(CollectionUtils.isNotEmpty(metaAttrMaps)){
            List<DMMetaAttr> metaAttrs=new ArrayList<>();
            for(Map<String,Object> metaAttr:metaAttrMaps){
                DMMetaAttr dmMetaAttr=(DMMetaAttr) DMUtil.invokeObject(metaAttr,DMMetaAttr.class);
                metaAttrs.add(dmMetaAttr);
            }
            metaCI.setAttrs(metaAttrs);
        }
        List<Map<String,Object>> metaActionMaps=runner.query(DMSQL.DML_META_ACTION_QUERY.getSql(),new MapListHandler(),params);
        if(CollectionUtils.isNotEmpty(metaActionMaps)){
            List<DMMetaAction> metaActions=new ArrayList<>();
            for(Map<String,Object> metaAction:metaActionMaps){
                DMMetaAction dmMetaAction=(DMMetaAction) DMUtil.invokeObject(metaAction,DMMetaAction.class);
                metaActions.add(dmMetaAction);
            }
            metaCI.setActions(metaActions);
        }
        return metaCI;
    }
    /**
     * @desc 查询metaCI元数据
     * @param ns
     * @return
     * @throws SQLException
     */
    public static List<DMMetaCI> queryMetaCI(String ns) throws SQLException{
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        Object[] ciParams={ns};
        List<DMMetaCI> metaCIS= runner.query(DMSQL.DML_META_CI_QUERY.getSql(),new BeanListHandler<>(DMMetaCI.class),ciParams);
        for(DMMetaCI metaCI:metaCIS){
            Object[] params={metaCI.getNs(),metaCI.getTenent(),metaCI.getCi()};
            List<Map<String,Object>> metaAttrMaps= runner.query(DMSQL.DML_META_ATTR_QUERY.getSql(),new MapListHandler(),params);
            if(CollectionUtils.isNotEmpty(metaAttrMaps)){
                List<DMMetaAttr> metaAttrs=new ArrayList<>();
                for(Map<String,Object> metaAttr:metaAttrMaps){
                    DMMetaAttr dmMetaAttr=(DMMetaAttr) DMUtil.invokeObject(metaAttr,DMMetaAttr.class);
                    metaAttrs.add(dmMetaAttr);
                }
                metaCI.setAttrs(metaAttrs);
            }
            List<Map<String,Object>> metaActionMaps=runner.query(DMSQL.DML_META_ACTION_QUERY.getSql(),new MapListHandler(),params);
            if(CollectionUtils.isNotEmpty(metaActionMaps)){
                List<DMMetaAction> metaActions=new ArrayList<>();
                for(Map<String,Object> metaAction:metaActionMaps){
                    DMMetaAction dmMetaAction=(DMMetaAction) DMUtil.invokeObject(metaAction,DMMetaAction.class);
                    metaActions.add(dmMetaAction);
                }
                metaCI.setActions(metaActions);
            }
        }
        return metaCIS;
    }

    /**
     * 查询所有metaCI元数据
     * @return list
     * @throws SQLException
     */
    public static List<DMMetaCI> queryAllMetaCI() throws SQLException {
        QueryRunner runner = new QueryRunner(DMPool.getInstance().getDataSource());
        List<DMMetaCI> metaCIS= runner.query(DMSQL.DML_META_CI_QUERY_ALL.getSql(),new BeanListHandler<>(DMMetaCI.class));
        for(DMMetaCI metaCI:metaCIS){
            Object[] params={metaCI.getNs(),metaCI.getTenent(),metaCI.getCi()};
            List<Map<String,Object>> metaAttrMaps= runner.query(DMSQL.DML_META_ATTR_QUERY.getSql(),new MapListHandler(),params);
            if(CollectionUtils.isNotEmpty(metaAttrMaps)){
                List<DMMetaAttr> metaAttrs=new ArrayList<>();
                for(Map<String,Object> metaAttr:metaAttrMaps){
                    DMMetaAttr dmMetaAttr=(DMMetaAttr) DMUtil.invokeObject(metaAttr,DMMetaAttr.class);
                    metaAttrs.add(dmMetaAttr);
                }
                metaCI.setAttrs(metaAttrs);
            }
            List<Map<String,Object>> metaActionMaps=runner.query(DMSQL.DML_META_ACTION_QUERY.getSql(),new MapListHandler(),params);
            if(CollectionUtils.isNotEmpty(metaActionMaps)){
                List<DMMetaAction> metaActions=new ArrayList<>();
                for(Map<String,Object> metaAction:metaActionMaps){
                    DMMetaAction dmMetaAction=(DMMetaAction) DMUtil.invokeObject(metaAction,DMMetaAction.class);
                    metaActions.add(dmMetaAction);
                }
                metaCI.setActions(metaActions);
            }
        }
        return metaCIS;
    }

    /**
     * @desc 删除产品域库
     * @param ns
     * @throws SQLException
     */
    public static void dropDatabaseNS(DMMMetaNs ns) throws SQLException {

    }

    /**
     * @desc 删除资源实例数据表
     * @param ci 对象元数据
     */
    public static void dropTableNSCI(String ns,DMMetaCI ci){

    }

}
