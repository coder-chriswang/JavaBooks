package com.neoway.iot.sdk.dmk.data;

/**
 * @desc: DMCache
 * @author: 20200312686
 * @date: 2020/6/22 13:46
 */
public interface DMCache {
    String CACHE_KEY="dm.data.cache";
    String CACHE_REDIS="redis";
    String CACHE_MEM="mem";
    String CACHE_MAX="dmk_cache_max";
    String CACHE_INIT="dmk_cache_init";
    void start();
    void load();
    void clear();
    void write(DMDataPoint data);
    DMDataPoint read(DMDataPoint data);
    void remove(DMDataPoint data);
}
