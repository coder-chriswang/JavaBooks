package com.neoway.iot.sdk.dmk.common.graph;

import java.io.Serializable;
import java.util.Map;

/**
 * 作者:angie_hawk7
 * 日期:2019/3/12 17:25
 * 描述:xxx
 */
public class GraphDataPoint implements Serializable {
    private String src;
    private String dst;
    private int weight;
    private Map<String, Object> edgeInfos;

    public GraphDataPoint(String src, String dst) {
        this.src = src;
        this.dst = dst;
        this.weight = 0;
    }

    public GraphDataPoint(String src, String dst, int weight) {
        this(src, dst);
        this.weight = weight;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getDst() {
        return dst;
    }

    public void setDst(String dst) {
        this.dst = dst;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Map<String, Object> getEdgeInfos() {
        return edgeInfos;
    }

    public void setEdgeInfos(Map<String, Object> edgeInfos) {
        this.edgeInfos = edgeInfos;
    }
}
