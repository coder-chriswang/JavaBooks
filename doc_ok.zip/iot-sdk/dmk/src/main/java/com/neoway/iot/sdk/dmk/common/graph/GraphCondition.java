package com.neoway.iot.sdk.dmk.common.graph;

/**
 * 作者:angie_hawk7
 * 日期:2019/3/12 18:49
 * 描述:xxx
 */
public class GraphCondition {
    /**
     * 关键字
     */
    public enum PrivateKey {
        //顶点附加信息
        VEREX,

        //边附加信息
        EDEX,

        //顶点数量
        NODE_COUNT,

        //边数量
        EDGE_COUNT,

        //权重
        WEIGHT;

    }

    public enum Where {
        MIN,
        //等于
        EQUALS,

        //小于
        LT,

        //大于
        GT,

        //小于等于
        LET,

        //大于等于
        GET;

    }

    private PrivateKey key;
    private Where where;
    private int value;

    public static GraphCondition build(PrivateKey key, Where where, int value) {
        GraphCondition condition = new GraphCondition();
        condition.key = key;
        condition.where = where;
        condition.value = value;
        return condition;
    }

    public PrivateKey getKey() {
        return key;
    }

    public Where getWhere() {
        return where;
    }

    public int getValue() {
        return value;
    }
}
