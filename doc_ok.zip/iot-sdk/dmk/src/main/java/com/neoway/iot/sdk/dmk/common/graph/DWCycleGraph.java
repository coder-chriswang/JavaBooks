package com.neoway.iot.sdk.dmk.common.graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * 作者:angie_hawk7
 * 日期:2019/3/12 17:02
 * 描述:有向环路加权图
 */
public class DWCycleGraph extends DWGraph {
    public DWCycleGraph() {
        super();
    }

    public DWCycleGraph(String label) {
        super(label);
    }

    @Override
    public List<Stack<GraphVertex>> getRoute(
            String startVerId, String endVerId, GraphCondition condition){
        List<Stack<GraphVertex>> routes = super.getAllRoute(startVerId, endVerId);
        List<Stack<GraphVertex>> lastResults = this.filter(routes, condition);
        GraphVertex endVertex = this.getGraphVer(endVerId);
        List<Stack<GraphVertex>> newResults = getRouteHasCycle(routes, endVertex);
        if (lastResults.size() > 0) {
            newResults = this.filter(newResults, condition);
        }
        if (null == newResults || newResults.size() == 0) {
            return lastResults;
        }
        while (lastResults.size() < newResults.size()) {
            lastResults = newResults;
            List<Stack<GraphVertex>> newAll = getRouteHasCycle(newResults, endVertex);
            newResults = this.filter(newAll, condition);
        }
        return newResults;
    }


    /**
     * @param routes    迭代计算结果集
     * @param endVertex 终点顶点
     * @return 路径全集
     * @throws Exception
     * @description 获取指定起始顶点和目标顶点的路径集合(含回环)
     */
    private List<Stack<GraphVertex>> getRouteHasCycle(
            List<Stack<GraphVertex>> routes, GraphVertex endVertex) {
        List<Stack<GraphVertex>> originResults = new ArrayList<>();
        List<String> contains = new ArrayList<>();
        for (Stack<GraphVertex> route : routes) {
            contains.add(this.showRoute(route));
            originResults.add(route);
        }
        //2:根据回环路径，复制结果集合
        List<Stack<GraphVertex>> cycles = this.getCycleRoute(endVertex.getId());
        if (null != cycles) {
            for (List<GraphVertex> cycle : cycles) {
                GraphVertex vertex = cycle.get(0);
                endVertex.getEdges();
                boolean needAdd = false;
                for (GraphEdge edge : endVertex.getEdges()) {
                    if (vertex.getId().equals(edge.getDstVertex().getId())) {
                        needAdd = true;
                        break;
                    }
                }
                if (!needAdd) {
                    continue;
                }
                for (Stack<GraphVertex> route : routes) {
                    Stack<GraphVertex> routeCopy = (Stack) route.clone();
                    routeCopy.addAll(cycle);
                    String key_cycle = this.showRoute(routeCopy);
                    if (!contains.contains(key_cycle)) {
                        contains.add(key_cycle);
                        originResults.add(routeCopy);
                    }
                }
            }

        }
        return originResults;
    }
}
