package com.neoway.iot.sdk.fmk.handler;

import com.neoway.iot.sdk.fmk.model.AlarmInfoVo;
import com.neoway.iot.sdk.fmk.model.BaseAlarmInfo;
import com.neoway.iot.sdk.fmk.model.constant.ConstantVariable;
import com.neoway.iot.sdk.fmk.model.params.DeleteParams;
import com.neoway.iot.sdk.fmk.model.params.SearchParams;
import com.neoway.iot.sdk.fmk.sharding.Partition;
import com.neoway.iot.sdk.fmk.util.CommonDbUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 *  描述: Mysql数据handler
 *  QueryRunner有两种方式来管理连接，一种是在构建QueryRunner实例时通过构造方法传递一个数据源DataSource实例；
 *  另一种则是在调用相应的操作方法，如query、update、batch等这些方法时传入一个Connection对象。
 *  这两种方式有什么区别呢？
 *  对于DataSource的管理，在每次执行完相应操作后，DbUtils会自动关闭数据源的连接对象。
 *  而在调用相应的操作方法时传入的Connection对象，在使用完之后是需要我们手动去关闭这个资源的。
 *  在fmk工程中，我们都将使用DataSource的方式进行操作。
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 18:56
 */
@Slf4j
@Service("mysqlDataHandler")
public class MysqlDataHandler implements DataHandler {
    /**
     * 例如 jdbc:mysql://localhost:3306/ares?user=root&password=hera@321
     */
    @Value("fmk.jdbc.url")
    private String jdbcUrl;

    @Resource(name = "alarmInfoPartition")
    private Partition alarmInfoPartition;

    @Override
    public List<AlarmInfoVo> getAlarmInfoList(SearchParams searchParams) {
        if (searchParams == null) {
            return null;
        }
        List<AlarmInfoVo> resultList = null;
        String sql = String.format(ConstantVariable.SELECT_ALARM_INFO_SQL, alarmInfoPartition.getTable(searchParams.getInstanceId()).getTableName());
        try {
            ResultSetHandler<List<AlarmInfoVo>> rsh = new BeanListHandler<>(AlarmInfoVo.class);
            DataSource dataSource = CommonDbUtils.getDataSource(jdbcUrl);
            QueryRunner qr = new QueryRunner(dataSource);
            sql = generateSqlString(searchParams, sql);
            log.info("查询SQL=", sql);
            resultList = qr.query(sql, rsh);
        } catch (SQLException e) {
            log.error("查询全部告警数据失败！", e);
        }
        return resultList;
    }

    @Override
    public int insert(AlarmInfoVo alarmInfoVo) {
        if (alarmInfoVo == null) {
            return 0;
        }
        String sql = String.format(ConstantVariable.INSERT_ALARM_INFO_SQL, alarmInfoPartition.getTable(alarmInfoVo.getInstanceId()).getTableName());
        log.info("新增SQL=", sql);
        int result = 0;
        try {
            DataSource dataSource = CommonDbUtils.getDataSource(jdbcUrl);
            QueryRunner qr = new QueryRunner(dataSource);
            result = qr.update(sql, alarmInfoVo.getAlarmId(),alarmInfoVo.getAlarmSource(),alarmInfoVo.getAlarmSt(),alarmInfoVo.getAlarmEt(),
                    alarmInfoVo.getAlarmStatus(),alarmInfoVo.getAlarmCount(),alarmInfoVo.getAlarmDesc(), alarmInfoVo.getDeviceId(),alarmInfoVo.getTenantId());
        } catch (SQLException e) {
            log.error("插入告警数据失败！", e);
        }
        return result;
    }
    
    @Override
    public int batchInsert(List<AlarmInfoVo> alarmInfoVos) {
        if (CollectionUtils.isEmpty(alarmInfoVos)) {
           return 0;
        }
        DataSource dataSource = CommonDbUtils.getDataSource(jdbcUrl);
        int result = 0;
        // 告警instanceId有变化，导致数据表名称变化
        for (AlarmInfoVo alarmInfoVo : alarmInfoVos) {
            String sql = String.format(ConstantVariable.INSERT_ALARM_INFO_SQL, alarmInfoPartition.getTable(alarmInfoVo.getInstanceId()).getTableName());
            try {
                QueryRunner qr = new QueryRunner(dataSource);
                qr.update(sql, alarmInfoVo.getAlarmId(),alarmInfoVo.getAlarmSource(),alarmInfoVo.getAlarmSt(),alarmInfoVo.getAlarmEt(),
                        alarmInfoVo.getAlarmStatus(),alarmInfoVo.getAlarmCount(),alarmInfoVo.getAlarmDesc(), alarmInfoVo.getDeviceId(),alarmInfoVo.getTenantId());
                result = result + 1;
            } catch (SQLException e) {
                log.error("插入告警数据失败！", e);
            }
        }
        return result;
    }

    @Override
    public int update(AlarmInfoVo alarmInfoVo) {
        if (alarmInfoVo == null) {
            return 0;
        }
        String sql = String.format(ConstantVariable.UPDATE_ALARM_INFO_SQL, alarmInfoPartition.getTable(alarmInfoVo.getInstanceId()).getTableName());
        log.info("更新SQL=", sql);
        int result = 0;
        try {
            DataSource dataSource = CommonDbUtils.getDataSource(jdbcUrl);
            QueryRunner qr = new QueryRunner(dataSource);
            result = qr.update(sql,alarmInfoVo.getAlarmStatus(), alarmInfoVo.getAlarmEt(), alarmInfoVo.getSerialNo());
        } catch (SQLException e) {
            log.error("更新告警数据失败！", e);
        }
        return result;
    }

    @Override
    public int delete(DeleteParams deleteParams) {
        if (deleteParams == null) {
           return 0;
        }
        String sql = String.format(ConstantVariable.DELETE_ALARM_INFO_SQL, alarmInfoPartition.getTable(deleteParams.getInstanceId()).getTableName());
        log.info("删除SQL=", sql);
        int result = 0;
        try {
            DataSource dataSource = CommonDbUtils.getDataSource(jdbcUrl);
            QueryRunner qr = new QueryRunner(dataSource);
            result = qr.update(sql, deleteParams.getSerialNo());
        } catch (SQLException e) {
            log.error("删除告警数据失败");
        }
        return result;
    }

    @Override
    public List<BaseAlarmInfo> getStaticAlarmInfo(List<String> alarmIds) {
        List<BaseAlarmInfo> resultList = new ArrayList<>();
        String sql = ConstantVariable.SELECT_STATIC_ALARM_INFO_SQL;
        try {
            ResultSetHandler<List<BaseAlarmInfo>> rsh = new BeanListHandler<>(BaseAlarmInfo.class);
            DataSource dataSource = CommonDbUtils.getDataSource(jdbcUrl);
            QueryRunner qr = new QueryRunner(dataSource);
            log.info("查询SQL=", sql);
            List<BaseAlarmInfo> baseAlarmInfos = qr.query(sql, rsh);
            if (CollectionUtils.isEmpty(baseAlarmInfos)) {
                return null;
            }
            if (CollectionUtils.isEmpty(alarmIds)) {
                return baseAlarmInfos;
            }
            for (String alarmId : alarmIds) {
                for (BaseAlarmInfo baseAlarmInfo : baseAlarmInfos) {
                    if (alarmId.equals(baseAlarmInfo.getAlarmId())) {
                        resultList.add(baseAlarmInfo);
                    }
                }
            }
        } catch (SQLException e) {
            log.error("查询静态告警数据失败！", e);
        }

        return resultList;
    }

    private String generateSqlString(SearchParams searchParams, String sql) {
        if (!StringUtils.isBlank(searchParams.getAlarmId())) {
            sql = sql + "AND a.alarm_id = ?" + " ";
        }
        if (!StringUtils.isBlank(searchParams.getSerialNo())) {
            sql = sql + "AND a.serial_no = ?" + " ";
        }
        if (!StringUtils.isBlank(searchParams.getDeviceId())) {
            sql = sql + "AND a.device_id = ?" + " ";
        }
        if (!StringUtils.isBlank(searchParams.getTenantId())) {
            sql = sql + "AND a.tenant_id = ?" + " ";
        }
        if (searchParams.getAlarmCategory() != null) {
            sql = sql + "AND a.alarm_category = ?" + " ";
        }
        if (searchParams.getAlarmStatus() != null) {
            sql = sql + "AND a.alarm_status = ?" + " ";
        }
        if (searchParams.getAlarmSt() != null) {
            sql = sql + "AND a.alarm_st > ?" + " ";
        }
        if (searchParams.getAlarmEt() != null) {
            sql = sql + "AND a.alarm_et < ?" + " ";
        }
        return sql;
    }
}
