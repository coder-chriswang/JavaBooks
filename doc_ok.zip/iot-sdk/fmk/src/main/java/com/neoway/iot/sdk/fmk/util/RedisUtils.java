package com.neoway.iot.sdk.fmk.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *  描述: Redis操作类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/03 8:55
 */
@Slf4j
@Component
public class RedisUtils {
    @Autowired
    private StringRedisTemplate template;

    /**
     * 增更缓存
     * @param key 键
     * @param value 值
     * @param expire 失效时间
     */
    public void replace(String key, Map<String, String> value, long expire) {
        template.boundHashOps(key).putAll(value);
        if (expire > 0) {
            template.boundHashOps(key).expire(expire, TimeUnit.SECONDS);
        }
    }

    /**
     * 获取缓存
     * @param key 键
     * @return 对象
     */
    public Map<String, String> find(String key) {
        return template.<String, String>boundHashOps(key).entries();
    }

    /**
     * 删除缓存
      * @param key
     */
    public void delete(String key) {
        template.delete(key);
    }
}
