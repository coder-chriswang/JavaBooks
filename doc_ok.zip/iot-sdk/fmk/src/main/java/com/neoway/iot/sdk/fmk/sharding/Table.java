package com.neoway.iot.sdk.fmk.sharding;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 分区表
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 10:21
 */
@Data
public class Table implements Serializable {
    private static final long serialVersionUID = 2419376382845144036L;
    /**
     * 表名前缀
     */
    private String tableName;
}
