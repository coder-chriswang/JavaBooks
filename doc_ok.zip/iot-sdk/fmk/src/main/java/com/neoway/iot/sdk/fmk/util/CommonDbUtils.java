package com.neoway.iot.sdk.fmk.util;


import com.neoway.iot.sdk.fmk.model.constant.ConstantVariable;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * <pre>
 *  描述: 数据库连接工具类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 14:07
 */
@Slf4j
public class CommonDbUtils {
    /**
     * 对于DataSource的管理，在每次执行完相应操作后，DbUtils会自动关闭数据源的连接对象
     * @param jdbcUrl
     * @return
     */
    public static DataSource getDataSource(String jdbcUrl) {
        HikariDataSource hikariDataSource = new HikariDataSource();
        hikariDataSource.setJdbcUrl(jdbcUrl);
        hikariDataSource.setMinimumIdle(5);
        hikariDataSource.setMaximumPoolSize(15);
        hikariDataSource.setAutoCommit(true);
        hikariDataSource.setIdleTimeout(30000);
        hikariDataSource.setPoolName("fmkHikariCP");
        hikariDataSource.setMaxLifetime(1800000);
        hikariDataSource.setConnectionTimeout(30000);
        hikariDataSource.setConnectionTestQuery("SELECT 1");
        return hikariDataSource;
    }

    /**
     * 初始化告警数据表
     * @param jdbcUrl
     * @param tableCount
     * @return
     */
    public static boolean initAlarmInfoDataTable(String jdbcUrl, int tableCount) {
        DataSource dataSource = getDataSource(jdbcUrl);
        QueryRunner qr = new QueryRunner(dataSource);
        try {
            // 创建告警静态表
            qr.update(ConstantVariable.INIT_TBL_ALARM_IDENTIFY_DICT);
            // TODO 插入告警静态数据
            // 创建告警数据活动表
            for (int i = 1; i <= tableCount; i++) {
                qr.update(String.format(ConstantVariable.INIT_TBL_ALARM_INFO_DATA, i));
            }
            return true;
        } catch (SQLException e) {
            log.error("初始化告警数据表错误！", e);
            return false;
        }
    }

    /**
     * 这边我们也提供单独传入connection的方式
     * @param jdbcUrl
     * @return
     */
    public static Connection getConnection(String jdbcUrl) {
        Connection connection = null;
        try {
            HikariDataSource hikariDataSource = (HikariDataSource) getDataSource(jdbcUrl);
            connection = hikariDataSource.getConnection();
        } catch (SQLException e) {
            log.error("建立数据库连接失败！", e);
        }
        return connection;
    }

    /**
     * 断开Connection连接，释放资源
     * @param connection
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            DbUtils.closeQuietly(connection);
        }
    }
}
