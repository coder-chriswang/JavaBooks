package com.neoway.iot.sdk.fmk.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 告警Vo对象
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/29 11:17
 */
@Data
public class AlarmInfoVo extends BaseAlarmInfo implements Serializable {
    private static final long serialVersionUID = -2487116502097655544L;

    /**
     * instanceId
     */
    private String instanceId;

    /**
     * 告警流水号
     */
    private long serialNo;

    /**
     * 告警来源
     */
    private String alarmSource;

    /**
     * 告警开始时间
     */
    private Long alarmSt;

    /**
     * 告警结束时间
     */
    private Long alarmEt;

    /**
     * 告警次数
     */
    private Long alarmCount;

    /**
     * 告警状态
     */
    private Integer alarmStatus;

    /**
     * 告警描述
     */
    private String alarmDesc;

    /**
     * 设备ID
     */
    private String deviceId;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备类型
     */
    private String deviceCi;

    /**
     * 告警类型名称
     */
    private String deviceCiName;

    /**
     * 设备位置信息
     */
    private String deviceLocation;

    /**
     * 租户ID
     */
    private String tenantId;
}
