package com.neoway.iot.sdk.fmk.model.params;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 查询参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/02 15:48
 */
@Data
public class SearchParams implements Serializable {
    private static final long serialVersionUID = 5620724734395163010L;

    /**
     * instanceId
     */
    private String instanceId;

    /**
     * 告警序列号
     */
    private String serialNo;

    /**
     * 设备ID
     */
    private String deviceId;

    /**
     * 租户ID
     */
    private String tenantId;

    /**
     * 告警ID
     */
    private String alarmId;

    /**
     * 告警状态
     */
    private Integer alarmStatus;

    /**
     * 告警类型
     */
    private Integer alarmCategory;

    /**
     * 告警开始时间
     */
    private Long alarmSt;

    /**
     * 告警结束时间
     */
    private Long alarmEt;
}
