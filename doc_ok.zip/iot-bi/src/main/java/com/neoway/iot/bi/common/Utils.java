package com.neoway.iot.bi.common;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;

/**
 * @desc: Utils
 * @author: 20200312686
 * @date: 2020/7/21 17:00
 */
public class Utils {
    public static Gson getJsonUtil(){
        Gson gson=new GsonBuilder()
                .setDateFormat("yyyy-MM-dd HH:mm:ss")
                .setLongSerializationPolicy(LongSerializationPolicy.STRING)
                .create();
        return gson;

    }
}
