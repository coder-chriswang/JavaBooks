package com.neoway.iot.bi.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @desc: BiChart
 * @author: 20200312686
 * @date: 2020/8/4 13:26
 */
@ApiModel("chart结构")
public class BiChart {
    @ApiModelProperty(value = "chart ID")
    private String chartId;
    @ApiModelProperty(value = "chart 名称")
    private String chartName;
    @ApiModelProperty(value = "chart 描述")
    private String chartDesc;
    @ApiModelProperty(value = "chart 数据源")
    private String chartDs;

    public String getChartId() {
        return chartId;
    }

    public void setChartId(String chartId) {
        this.chartId = chartId;
    }

    public String getChartName() {
        return chartName;
    }

    public void setChartName(String chartName) {
        this.chartName = chartName;
    }

    public String getChartDesc() {
        return chartDesc;
    }

    public void setChartDesc(String chartDesc) {
        this.chartDesc = chartDesc;
    }

    public String getChartDs() {
        return chartDs;
    }

    public void setChartDs(String chartDs) {
        this.chartDs = chartDs;
    }
}
