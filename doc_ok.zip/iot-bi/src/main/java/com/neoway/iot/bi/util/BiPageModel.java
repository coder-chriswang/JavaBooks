package com.neoway.iot.bi.util;

import lombok.Data;

import java.util.Collections;
import java.util.List;

/**
 * <pre>
 *  描述: Monitor分页模型
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 13:51
 */
@Data
public class BiPageModel<T> {
    /**
     * 当前页
     */
    private int currentPage;

    /**
     * 总页数
     */
    private int totalPage;

    /**
     * 页面容量
     */
    private int pageSize;

    /**
     * 总数据数
     */
    private int totalRecordCount;

    /**
     * 当前页数据集
     */
    private List<T> records = Collections.emptyList();


    public static <T> BiPageModel<T> build(List<T> records, int current, int totalRecordCount, int pageSize) {
        if (pageSize <= 0) {
            pageSize = 1;
        }
        if (current <= 0) {
            current = 1;
        }
        BiPageModel<T> pageModel = new BiPageModel<T>();
        pageModel.setCurrentPage(current);
        pageModel.setPageSize(pageSize);
        pageModel.setRecords(records);
        pageModel.setTotalRecordCount(totalRecordCount);
        int pages = totalRecordCount / pageSize;
        pageModel.setTotalPage((totalRecordCount) % pageSize == 0 ? pages : (pages + 1));
        return pageModel;
    }
}
