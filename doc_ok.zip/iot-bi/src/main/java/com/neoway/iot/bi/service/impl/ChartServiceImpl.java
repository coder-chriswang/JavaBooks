package com.neoway.iot.bi.service.impl;

import com.neoway.iot.bi.dao.chart.IChartDao;
import com.neoway.iot.bi.domain.BiChart;
import com.neoway.iot.bi.domain.chart.Chart;
import com.neoway.iot.bi.exception.ChartServiceException;
import com.neoway.iot.bi.model.chart.QueryChartListParam;
import com.neoway.iot.bi.service.IChartService;
import com.neoway.iot.bi.util.BiPageModel;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class ChartServiceImpl implements IChartService {
    @Resource
    private IChartDao chartDao;

    @Override
    public BiPageModel<Chart> queryPageList(QueryChartListParam param) throws ChartServiceException {
        if (param == null) {
            throw new ChartServiceException("参数有误");
        }
        Integer count = chartDao.queryCount(param);
        if (count == null || count <= 0) {
            return BiPageModel.build(null, 1, 0, 1);
        }
        List<Chart> chartList = chartDao.queryList(param);
        return BiPageModel.build(chartList, param.getPageNum(), count, param.getPageSize());
    }

    @Override
    public BiChart getChartDetail(String chartId) throws ChartServiceException {
        if (StringUtils.isEmpty(chartId)) {
            throw new ChartServiceException("该chart不存在");
        }
        Chart c = chartDao.queryByKey(chartId);
        if (c == null) {
            throw new ChartServiceException("该chart不存在");
        }
        BiChart biChart = new BiChart();
        biChart.setChartId(c.getChartid());
        biChart.setChartName(c.getName());
        biChart.setChartDesc(c.getDesc());

        // get chart data
        biChart.setChartDs(getDummyData(c));
        return biChart;
    }

    private String getDummyData(Chart c) {
        switch (c.getType()) {
            case "Line":
                return "{\"xAxis\":{\"type\":\"category\",\"data\":[\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\",\"Sun\"]},\"yAxis\":{\"type\":\"value\"},\"series\":[{\"data\":[820,932,901,934,1290,1330,1320],\"type\":\"line\",\"smooth\":true}]}";
            case "Gauge":
                return "{\"tooltip\":{\"formatter\":\"{a} <br/>{b} : {c}%\"},\"toolbox\":{\"feature\":{\"restore\":{},\"saveAsImage\":{}}},\"series\":[{\"name\":\"业务指标\",\"type\":\"gauge\",\"detail\":{\"formatter\":\"{value}%\"},\"data\":[{\"value\":34,\"name\":\"完成率\"}]}]}";
            case "Bar":
                return "{\"xAxis\":{\"type\":\"category\",\"data\":[\"Mon\",\"Tue\",\"Wed\",\"Thu\",\"Fri\",\"Sat\",\"Sun\"]},\"yAxis\":{\"type\":\"value\"},\"series\":[{\"data\":[120,200,150,80,70,110,130],\"type\":\"bar\",\"showBackground\":true,\"backgroundStyle\":{\"color\":\"rgba(220, 220, 220, 0.8)\"}}]}";
            case "Table":
                return "{\"colName\":[\"序号\",\"名称\",\"数量\",\"日期\"],\"rows\":[{\"col1\":\"1\",\"col2\":\"java\",\"col3\":\"22\",\"col4\":\"2020-08-11\"},{\"col1\":\"2\",\"col2\":\"css\",\"col3\":\"13\",\"col4\":\"2020-08-11\"},{\"col1\":\"3\",\"col2\":\"js\",\"col3\":\"78\",\"col4\":\"2020-08-11\"},]}";
            case "Pie":
                return "{\"tooltip\":{\"trigger\":\"item\",\"formatter\":\"{a} <br/>{b}: {c} ({d}%)\"},\"legend\":{\"orient\":\"vertical\",\"left\":10,\"data\":[\"直接访问\",\"邮件营销\",\"联盟广告\",\"视频广告\",\"搜索引擎\"]},\"series\":[{\"name\":\"访问来源\",\"type\":\"pie\",\"radius\":[\"50%\",\"70%\"],\"avoidLabelOverlap\":false,\"label\":{\"show\":false,\"position\":\"center\"},\"emphasis\":{\"label\":{\"show\":true,\"fontSize\":\"30\",\"fontWeight\":\"bold\"}},\"labelLine\":{\"show\":false},\"data\":[{\"value\":335,\"name\":\"直接访问\"},{\"value\":310,\"name\":\"邮件营销\"},{\"value\":234,\"name\":\"联盟广告\"},{\"value\":135,\"name\":\"视频广告\"},{\"value\":1548,\"name\":\"搜索引擎\"}]}]}";
        }
        return "";
    }
}
