package com.neoway.iot.bi.util;

import com.neoway.iot.bi.service.II18nService;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Locale;

@Component
public class MessageUtils {

    private static MessageSource messageSource;
    public MessageUtils(MessageSource messageSource) {
        MessageUtils.messageSource = messageSource;
    }

    private static II18nService ii18nService;
    public static void setI18nService(II18nService ii18nService) {
        MessageUtils.ii18nService = ii18nService;
    }

    /**
     * 获取单个国际化翻译值
     */
    public static String getMessage(String code) {
        Locale locale = LocaleContextHolder.getLocale();
        try {
            return ii18nService.getMessage(code, locale);
        } catch (Exception e) {
            return code;
        }
    }
}
