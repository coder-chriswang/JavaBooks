package com.neoway.iot.dmm;

import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.common.db.DMPool;
import com.neoway.iot.sdk.dmk.data.DMCache;
import org.springframework.core.env.Environment;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: DMMManager
 * @author: 20200312686
 * @date: 2020/7/21 11:49
 */
public class DMMManager {
    private static final String DM_JDBC_HOST="dm.jdbc.host";
    private static final String DM_JDBC_PORT="dm.jdbc.port";
    private static final String DM_JDBC_DB="dm.jdbc.db";
    private static final String DM_JDBC_MAX_CONN="dm.jdbc.max_conn";
    private static final String DM_JDBC_MIN_CONN="dm.jdbc.min_conn";
    private static final String DM_JDBC_USER="dm.jdbc.user";
    private static final String DM_JDBC_PWD="dm.jdbc.pwd";
    private static final String DM_JDBC_CONN_TIMEOUT="dm.jdbc.conn_timeout";
    private static final String DM_JDBC_IDEL_TIMEOUT="dm.jdbc.idel_timeout";
    private static final String DM_DATA_CACHE="dm.data.cache";
    private static DMMManager manager=null;
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private Environment env;
    public void start(Environment env){
        this.env=env;
        if (isStarted.get()) {
            return;
        }
        DMRunner runner = DMRunner.getInstance();
        Map<String,Object> pro=new HashMap<>();
        pro.put(DMPool.JDBC_HOST,env.getProperty(DM_JDBC_HOST));
        pro.put(DMPool.JDBC_PORT,env.getProperty(DM_JDBC_PORT));
        pro.put(DMPool.JDBC_DB,env.getProperty(DM_JDBC_DB));
        pro.put(DMPool.JDBC_MAX_CONN,env.getProperty(DM_JDBC_MAX_CONN));
        pro.put(DMPool.JDBC_MIN_CONN,env.getProperty(DM_JDBC_MIN_CONN));
        pro.put(DMPool.JDBC_USER,env.getProperty(DM_JDBC_USER));
        pro.put(DMPool.JDBC_PWD,env.getProperty(DM_JDBC_PWD));
        pro.put(DMPool.JDBC_CONN_TIMEOUT,env.getProperty(DM_JDBC_CONN_TIMEOUT));
        pro.put(DMPool.JDBC_IDEL_TIMEOUT,env.getProperty(DM_JDBC_IDEL_TIMEOUT));
        pro.put(DMCache.CACHE_KEY,env.getProperty(DM_DATA_CACHE));
        runner.start(pro);
        isStarted.set(true);
    }
    public static DMMManager getInstance() {
        if (manager == null) {
            synchronized (DMMManager.class) {
                if (manager == null) {
                    manager = new DMMManager();
                }
            }
        }
        return manager;
    }
}
