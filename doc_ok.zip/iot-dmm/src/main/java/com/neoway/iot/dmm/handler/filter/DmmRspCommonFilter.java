package com.neoway.iot.dmm.handler.filter;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.MapUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: DmmRspCommonFilter
 * @author: 20200312686
 * @date: 2020/7/28 15:25
 */
public class DmmRspCommonFilter implements DmmRspFilter {
    private DMRunner runner=DMRunner.getInstance();
    @Override
    public void filter(DMMRequest request, DMMResponse response) {
        if(!response.isNeedFilter()){
            return;
        }
        DMMetaCI metaCI=runner.getMetaCI(request.getNs(), DMMetaCI.DEFAULT_TENENT,request.getCi());
        if(null == metaCI){
            throw new RuntimeException("元数据不存在");
        }
        Object data=response.getData();
        if(null == data){
            return;
        }else if(data instanceof List){
            List<Map<String,Object>> datas=(List<Map<String,Object>>) data;
            List<Map<String,Object>> filterArr=new ArrayList<>();
            for(Map<String,Object> dv:datas){
                Map<String,Object> filterMap=filterValue(dv,metaCI,request.getAction());
                if(MapUtils.isEmpty(filterMap)){
                    continue;
                }
                filterArr.add(filterMap);
            }
            response.setData(filterArr);
        }else{
            Map<String,Object> dataMap=(Map<String, Object>) data;
            Map<String,Object> filterMap=filterValue(dataMap,metaCI,request.getAction());
            response.setData(filterMap);
        }
    }

    /**
     * @desc 数据过滤器
     * @param dataMap
     * @param metaCI
     * @param actionId
     * @return
     */
    private Map<String,Object> filterValue(Map<String,Object> dataMap,DMMetaCI metaCI,String actionId){
        Map<String,Object> filterMap=new HashMap<>();
        for(Map.Entry<String,Object> entry:dataMap.entrySet()){
            DMMetaAttr metaAttr=metaCI.buildAssignAttr(entry.getKey());
            if(null == metaAttr){
                continue;
            }else if(metaAttr.getSupportAction().contains(actionId)){
                filterMap.put(entry.getKey(),entry.getValue());
            }else{
                continue;
            }

        }
        return filterMap;
    }
}
