package com.neoway.iot.dmm.api;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.dmm.HttpResult;
import com.neoway.iot.dmm.handler.DataHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @desc: DataController
 * @author: 20200312686
 * @date: 2020/7/21 10:56
 */
@RestController
@RequestMapping("/v1/command")
@Api(tags = "资源")
public class DataController {
    private DataHandler handler=new DataHandler();

    @ApiOperation("资源指令执行")
    @PostMapping("")
    public HttpResult execute(@RequestBody DMMRequest request) {
        DMMResponse response=handler.execute(request);
        if (response.getCode() == DMMResponse.NOK) {
            return HttpResult.returnFail("执行资源指令失败！");
        } else {
            return HttpResult.returnSuccess("执行资源指令成功！", null);
        }
    }
}
