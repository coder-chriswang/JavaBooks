package com.neoway.iot.dmm.handler;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: DataOmExecutor
 * @author: 20200312686
 * @date: 2020/7/27 17:04
 */
public class DataHandlerWithOm {
    private static final String ACTION_ADD="Add";
    private static final String ACTION_UPDATE="Update";
    private static final String ACTION_QUERY="Query";
    private static final String ACTION_GET="Get";
    private static final String ACTION_DELETE="Delete";
    private DMRunner runner;
    private DMMetaCI metaCI;
    private DMMRequest req;
    public DataHandlerWithOm(DMMetaCI metaCI,DMMRequest req){
        runner=DMRunner.getInstance();
        this.metaCI=metaCI;
        this.req=req;
    }
    public DMMResponse execute(){
        DMMResponse response=new DMMResponse();
        if(null == metaCI || null == req){
            response.setCode(DMMResponse.NOK);
            response.setMsg("参数错误");
            return response;
        }
        DMMetaAction action=metaCI.buildAssignAction(req.getAction());
        Object data=req.getData();
        if(data instanceof List && ACTION_ADD.equalsIgnoreCase(action.getId())){
            List<Map<String,Object>> inputs=(List<Map<String,Object>>)data;
            List<DMDataPoint> points=this.convert(inputs);
            runner.write(points);
            return response;
        }
        Map<String,Object> input=(Map<String,Object>)data;
        DMDataPoint point=this.convert(input);
        if(ACTION_UPDATE.equalsIgnoreCase(action.getId())){
            runner.write(point);
        }else if(ACTION_GET.equalsIgnoreCase(action.getId())){
            DMDataPoint result=runner.get(point);
            response.setData(result.buildMapValue());
        }else if(ACTION_QUERY.equalsIgnoreCase(action.getId())){
            List<DMDataPoint> results=runner.list(point);
            List<Map<String,Object>> datas=new ArrayList<>();
            if(CollectionUtils.isNotEmpty(results)){
                for(DMDataPoint pv:results){
                    datas.add(pv.buildMapValue());
                }
                response.setData(datas);
            }

        }else if(ACTION_DELETE.equalsIgnoreCase(action.getId())){
            runner.delete(point);
        }else{
            response=new DataHandlerWithOmSpecial(this.metaCI,this.req).execute();
        }
        return response;
    }

    /**
     * @desc 参数转换
     * @param datas
     * @return
     */
    private DMDataPoint convert(Map<String,Object> datas){
        DMDataPoint point=DMDataPoint.builder(this.metaCI);
        point.buildColumns(datas);
        return point;
    }

    /**
     * @desc 参数转换
     * @param datas
     * @return
     */
    private List<DMDataPoint> convert(List<Map<String,Object>> datas){
        List<DMDataPoint> points=new ArrayList<>();
        for(Map<String,Object> data:datas){
            DMDataPoint point=this.convert(data);
            points.add(point);
        }
        return points;
    }
}
