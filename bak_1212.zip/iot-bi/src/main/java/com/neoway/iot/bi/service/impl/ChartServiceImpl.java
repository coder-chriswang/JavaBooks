package com.neoway.iot.bi.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.neoway.iot.bi.common.domain.BiChart;
import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.dto.GWRequest;
import com.neoway.iot.bi.common.dto.GWResponse;
import com.neoway.iot.bi.common.enums.ExtApiEnum;
import com.neoway.iot.bi.common.exception.ChartServiceException;
import com.neoway.iot.bi.common.param.QueryChartListParam;
import com.neoway.iot.bi.common.param.QueryViewChartListParam;
import com.neoway.iot.bi.common.util.BiPageModel;
import com.neoway.iot.bi.dao.chart.IChartDao;
import com.neoway.iot.bi.service.IChartService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.*;

@Service
@Slf4j
public class ChartServiceImpl implements IChartService {
    @Resource
    private IChartDao chartDao;

    @Resource
    private RestTemplate restTemplate;

    @Value("${iot.service.gw.host}")
    private String gwHost;

    @Override
    public BiPageModel<Chart> queryPageList(QueryChartListParam param) throws ChartServiceException {
        if (param == null) {
            throw new ChartServiceException("参数有误");
        }
        Integer count = chartDao.queryCount(param);
        if (count == null || count <= 0) {
            return BiPageModel.build(null, 1, 0, 1);
        }
        List<Chart> chartList = chartDao.queryList(param);
        return BiPageModel.build(chartList, param.getPageNum(), count, param.getPageSize());
    }

    @Override
    public BiPageModel<Chart> queryViewChartList(QueryViewChartListParam param) {
        String[] chartIds = param.getChart().split(",");
        if(chartIds.length <= 0){
            return BiPageModel.build(null, 1, 0, 1);
        }
        List<Chart> chartList = chartDao.batchQueryById(chartIds);
        return BiPageModel.build(chartList, param.getPageNum(), chartIds.length, param.getPageSize());
    }

    @Override
    public BiChart getChartDetail(String chartId) throws ChartServiceException {
        if (StringUtils.isEmpty(chartId)) {
            throw new ChartServiceException("该chart不存在");
        }
        Chart c = chartDao.queryByKey(chartId);
        if (c == null) {
            throw new ChartServiceException("该chart不存在");
        }
        BiChart biChart = new BiChart();
        biChart.setChartId(c.getChartid());
        biChart.setChartName(c.getName());
        biChart.setChartDesc(c.getDesc());

        // get chart data
        biChart.setChartDs(getDummyData(c));
        return biChart;
    }

    @Override
    public BiChart getGISDetail(String chartId, String doInstanceId) throws ChartServiceException {
        if (StringUtils.isEmpty(chartId)) {
            throw new ChartServiceException("该chart不存在");
        }
        if (StringUtils.isEmpty(doInstanceId)) {
            throw new ChartServiceException("该领域id不存在");
        }
        Chart c = chartDao.queryByKey(chartId);
        if (c == null) {
            throw new ChartServiceException("该chart不存在");
        }
        BiChart biChart = new BiChart();
        biChart.setChartId(c.getChartid());
        biChart.setChartName(c.getName());
        biChart.setChartDesc(c.getDesc());
        biChart.setChartDs(getGISData(c, doInstanceId));
        return biChart;
    }

    private String getGISData(Chart c, String doInstanceId) {
        String url = gwHost + ExtApiEnum.GW_Command_Syn.getUrl();
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
        headers.setContentType(type);
        GWRequest gwRequest = new GWRequest();
        Map<String, Object> requestMap = new HashMap<>(1);
        requestMap.put("doInstanceId", doInstanceId);
        Map<String, Object> headerMap = new HashMap<>();
        headerMap.put("templateid", c.getAlgorithm());
        gwRequest.setHeader(headerMap);
        gwRequest.setBody(requestMap);
        HttpEntity<String> requestEntity = new HttpEntity<>(JSONUtil.toJsonStr(gwRequest), headers);
        ResponseEntity<GWResponse> resEntity = null;
        try {
            resEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, GWResponse.class);
        } catch (Exception e) {
            log.error("request gw service exception is {}", e.getMessage());
            return null;
        }
        log.info("resEntity is {}", resEntity);
        String resultData = null;
        if (HttpStatus.OK.equals(resEntity.getStatusCode())) {
            resultData = JSONUtil.toJsonStr(resEntity.getBody().getData());
            if (resultData != null) {
                return resultData;
            }
        }
        return null;
    }

    private String getDummyData(Chart c) {
        String url = gwHost + ExtApiEnum.GW_Command_Syn.getUrl();
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
        headers.setContentType(type);
        GWRequest gwRequest = new GWRequest();
        Map<String, Object> headerMap = new HashMap<>();
        headerMap.put("templateid", c.getAlgorithm());
        gwRequest.setHeader(headerMap);
        HttpEntity<String> requestEntity = new HttpEntity<>(JSONUtil.toJsonStr(gwRequest), headers);
        ResponseEntity<GWResponse> resEntity = null;
        try {
            resEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, GWResponse.class);
        } catch (Exception e) {
            log.error("request gw service exception is {}", e.getMessage());
            return null;
        }
        log.info("resEntity is {}", resEntity);
        String resultData = null;
        if (HttpStatus.OK.equals(resEntity.getStatusCode())) {
            resultData = JSONUtil.toJsonStr(resEntity.getBody().getData());
            if (resultData != null) {
                return resultData;
            }
        } else {
            switch (c.getType()) {
                case "Line":
                    return "{\"chartType\":\"line\",\"chartTitle\":\"折线图\",\"data\":{\"legend\":{\"nameArr\":[\"图例1\",\"图例2\",\"图例3\"],\"keyArr\":[\"legend1\",\"legend2\",\"legend3\"]},\"xUnit\":\"x单位\",\"yUnit\":\"y单位\",\"xData\":[\"x轴坐标点1\",\"x轴坐标点2\",\"x轴坐标点3\",\"x轴坐标点4\",\"x轴坐标点5\"],\"yData\":{\"legend1\":[80,40,62,45,89],\"legend2\":[89,80,40,62,45],\"legend3\":[45,89,80,40,62]}}}";
                case "Gauge":
                    return "{\"chartType\":\"gauge\",\"chartTitle\":\"仪表盘\",\"data\":[{\"name\":\"仪表1\",\"value\":\"14\",\"unit\":\"km/h\",\"min\":0,\"max\":220,\"splitNumber\":11}]}";
                case "Bar":
                    return "{\"chartType\":\"bar\",\"chartTitle\":\"柱状图\",\"data\":{\"legend\":{\"nameArr\":[\"图例1\",\"图例2\",\"图例3\"],\"keyArr\":[\"legend1\",\"legend2\",\"legend3\"]},\"xUnit\":\"x单位\",\"yUnit\":\"y单位\",\"xData\":[\"x轴坐标点1\",\"x轴坐标点2\",\"x轴坐标点3\",\"x轴坐标点4\",\"x轴坐标点5\"],\"yData\":{\"legend1\":[80,40,62,45,89],\"legend2\":[89,80,40,62,45],\"legend3\":[45,89,80,40,62]}}}";
                case "Table":
                    return "{\"chartType\":\"table\",\"chartTitle\":\"表格\",\"data\":{\"tableHeader\":[{\"name\":\"表头1\",\"id\":\"header1\"},{\"name\":\"表头2\",\"id\":\"header2\"},{\"name\":\"表头3\",\"id\":\"header3\"}],\"tableData\":{\"total\":10,\"pageSize\":10,\"pageNum\":1,\"rows\":[{\"header1\":\"第一列数据\",\"header2\":\"第二列数据\",\"header3\":\"第三列数据\"},{\"header1\":\"第一列数据\",\"header2\":\"第二列数据\",\"header3\":\"第三列数据\"},{\"header1\":\"第一列数据\",\"header2\":\"第二列数据\",\"header3\":\"第三列数据\"},{\"header1\":\"第一列数据1\",\"header2\":\"第二列数据1\",\"header3\":\"第三列数据1\"},{\"header1\":\"第一列数据1\",\"header2\":\"第二列数据1\",\"header3\":\"第三列数据1\"},{\"header1\":\"第一列数据1\",\"header2\":\"第二列数据1\",\"header3\":\"第三列数据1\"},{\"header1\":\"第一列数据2\",\"header2\":\"第二列数据2\",\"header3\":\"第三列数据2\"},{\"header1\":\"第一列数据2\",\"header2\":\"第二列数据2\",\"header3\":\"第三列数据2\"},{\"header1\":\"第一列数据2\",\"header2\":\"第二列数据2\",\"header3\":\"第三列数据2\"},{\"header1\":\"3\",\"header2\":\"3\",\"header3\":\"3\"}]}}}";
                case "Pie":
                    return "{\"chartType\":\"pie\",\"chartTitle\":\"饼图\",\"data\":{\"legend\":[\"图例1\",\"图例2\",\"图例3\",\"图例4\",\"图例5\"],\"series\":{\"name\":\"内圈名称\",\"pieData\":[{\"name\":\"图例1\",\"value\":60},{\"name\":\"图例2\",\"value\":55}]}}}";
                case "LiquidFill":
                    return "{\"chartType\":\"liquidFill\",\"chartTitle\":\"水球图\",\"data\":{\"total\":0,\"names\":[\"在线率\",\"故障率\",\"离线率\"],\"series\":{\"percent\":[\"0.00%\",\"0.00%\",\"0.00%\"],\"pieData\":[\"0.0\",\"0.0\",\"0.0\"]}}}";
                case "ringScreen":
                    return "{\"chartType\":\"ringScreen\",\"chartTitle\":\"环形图\",\"data\":{\"legend\":[\"图例1\",\"图例2\",\"图例3\",\"图例4\"],\"series\":{\"pieData\":[{\"rate\":\"0.00%\",\"name\":\"图例1\"},{\"rate\":\"0.00%\",\"name\":\"图例2\"},{\"rate\":\"0.00%\",\"name\":\"图例3\"},{\"rate\":\"0.00%\",\"name\":\"图例4\"}],\"name\":\"环形图\"}}}";
            }
        }
        return "";
    }

    @Override
    public List<BiChart> getChartListByViewId (String viewId) {
        List<BiChart> list = new ArrayList<>();
        String chart = chartDao.getChartIdByViewId(viewId);
        if (StringUtils.isEmpty(chart)){
            return list;
        }
        String[] charts = chart.split(",");
        List<String> chartIds = Arrays.asList(charts);
        if (CollUtil.isEmpty(chartIds) || chartIds.size() == 0) {
            return list;
        }
        chartIds.forEach(chartId -> {
            try {
                BiChart biChart = getChartDetail(chartId);
                list.add(biChart);
            } catch (ChartServiceException e) {
                log.error("getChartDetailError, ex: {}", e.getMessage());
                return;
            }
        });
        return list;
    }
}
