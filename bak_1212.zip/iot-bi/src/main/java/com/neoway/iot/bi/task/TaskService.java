package com.neoway.iot.bi.task;

public interface TaskService {

	/**
	 * 执行方法
	 * @return
	 */
	boolean process();
}
