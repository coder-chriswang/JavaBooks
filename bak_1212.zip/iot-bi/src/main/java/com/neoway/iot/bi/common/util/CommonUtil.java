package com.neoway.iot.bi.common.util;

import cn.hutool.core.date.DateUtil;
import com.google.common.base.Charsets;
import com.google.common.hash.Hashing;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class CommonUtil {

	public static Integer guavaHash(String data, int partition) {
		int bucket = Hashing.consistentHash(Hashing.md5().hashString(data, Charsets.UTF_8),partition);
		return bucket;
	}


	public static double division(double v1, double v2, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(
					"The scale must be a positive integer or zero");
		}
		BigDecimal b1 = new BigDecimal(Double.valueOf(v1));
		BigDecimal b2 = new BigDecimal(Double.valueOf(v2));
		return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
	}


	public static void main (String[] args) {
//		LocalDateTime localDateTime = LocalDateTimeUtil.
////		System.out.println(DateUtil.offsetHour(new Date(), -1));
//		Date st = Date.from(LocalDateTime.now().withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0).withNano(0).atZone(ZoneId.systemDefault()).toInstant());
//		Date et = Date.from(LocalDateTime.now().withHour(23).withMinute(59).withSecond(59).withNano(0).atZone(ZoneId.systemDefault()).toInstant());
//		System.out.println(DateUtil.offsetHour(st, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetHour(et, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetDay(st, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetDay(et, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetMonth(DateUtil.beginOfMonth(new Date()), -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.endOfMonth(DateUtil.offsetMonth(new Date(), -1)).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetDay(et, -1).toTimestamp().getTime() / 1000);
//		System.out.println(DateUtil.offsetDay(new Date(), -30).toTimestamp().getTime() / 1000);
		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String format = df.format(DateUtil.toLocalDateTime(Instant.ofEpochSecond(1605179752)));
		System.out.println(format);
	}
}
