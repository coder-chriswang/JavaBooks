package com.neoway.iot.bi.common.enums;

public enum OfflineStatTaskCronEnum {

	HOUR("0 0 0/1 * * ?", "h", "每小时"),

	DAY("0 0 0 * * ?", "d","每天"),

	MONTH("0 0 0 1 * ?", "m", "每月"),

	;

	public String cron;
	private String code;
	public String description;

	OfflineStatTaskCronEnum (String cron, String code, String description) {
		this.cron = cron;
		this.code = code;
		this.description = description;
	}

	public String getCode () {
		return code;
	}

	public String getCron () {
		return cron;
	}

	public String getDescription () {
		return description;
	}

	public static OfflineStatTaskCronEnum getEnumByCron(String cron) {
		if (null == cron || "".equals(cron)) {
			return null;
		}
		OfflineStatTaskCronEnum responseCode;
		for (int i = 0; i < OfflineStatTaskCronEnum.values().length; i++) {
			responseCode = OfflineStatTaskCronEnum.values()[i];
			if (responseCode.cron.equals(cron)) {
				return responseCode;
			}
		}
		return null;
	}

	public static OfflineStatTaskCronEnum getEnumByCode(String code) {
		if (null == code || "".equals(code)) {
			return null;
		}
		OfflineStatTaskCronEnum responseCode;
		for (int i = 0; i < OfflineStatTaskCronEnum.values().length; i++) {
			responseCode = OfflineStatTaskCronEnum.values()[i];
			if (responseCode.code.equals(code)) {
				return responseCode;
			}
		}
		return null;
	}

	public static boolean contains(String cron) {
		OfflineStatTaskCronEnum offlineStatTaskCronEnum = OfflineStatTaskCronEnum.getEnumByCode(cron);
		if (offlineStatTaskCronEnum == null) {
			return false;
		} else {
			return true;
		}
	}
}
