package com.neoway.iot.bi.common.transform.table;

import java.util.List;
import java.util.Map;

public class TableDataData {

	private Integer total;

	private Integer pageSize;

	private Integer pageNum;

	private List<Map<String,Object>> rows;

	public Integer getTotal () {
		return total;
	}

	public void setTotal (Integer total) {
		this.total = total;
	}

	public Integer getPageSize () {
		return pageSize;
	}

	public void setPageSize (Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPageNum () {
		return pageNum;
	}

	public void setPageNum (Integer pageNum) {
		this.pageNum = pageNum;
	}

	public List<Map<String, Object>> getRows () {
		return rows;
	}

	public void setRows (List<Map<String, Object>> rows) {
		this.rows = rows;
	}
}
