package com.neoway.iot.bi.api;

import com.neoway.iot.bi.HttpResult;
import com.neoway.iot.bi.client.IotManagerApiClient;
import com.neoway.iot.bi.common.domain.BiChart;
import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.param.QueryChartListParam;
import com.neoway.iot.bi.common.param.QueryViewChartListParam;
import com.neoway.iot.bi.service.IChartService;
import com.neoway.iot.bi.common.util.BiPageModel;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @desc: BIController
 * @author: 20200312686
 * @date: 2020/8/4 13:22
 */
@RestController
@RequestMapping("/v1/chart")
@Api(tags = "bi",description = "数据统计Chart接口")
public class BiChartController {
    private static final Logger LOG = LoggerFactory.getLogger(BiChartController.class);

    @Resource
    private IChartService chartService;

    @Resource
    private IotManagerApiClient iotManagerApiClient;

    @ApiOperation("chart列表查询")
    @PostMapping("list")
    public HttpResult<BiPageModel<Chart>> queryCharts(@RequestBody QueryChartListParam param) {
        try{
            BiPageModel<Chart> r = chartService.queryPageList(param);
            return HttpResult.returnSuccess(r);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.queryFail") + e.getMessage());
        }
    }

    @ApiOperation("获取chart详情和数据")
    @GetMapping("data")
    public HttpResult<BiChart> queryChartData(@RequestParam("chartid") String chartid) {
        try{
            BiChart c = chartService.getChartDetail(chartid);
            return HttpResult.returnSuccess(c);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.queryFail") + e.getMessage());
        }
    }

    @ApiOperation("获取GIS数据")
    @GetMapping("gisData")
    public HttpResult<BiChart> queryGISData(@RequestParam("chartid") String chartid, @RequestParam("doInstanceId") String doInstanceId) {
        try{
            BiChart c = chartService.getGISDetail(chartid, doInstanceId);
            return HttpResult.returnSuccess(c);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.queryFail") + e.getMessage());
        }
    }

    @ApiOperation("根据视图id获取统计类型报表列表数据")
    @GetMapping("/by/{viewId}")
    public HttpResult getChartListByViewId(@PathVariable("viewId") String viewId){
        try {
            List<BiChart> chartList = chartService.getChartListByViewId(viewId);
            return HttpResult.returnSuccess(chartList);
        } catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.queryFail") + e.getMessage());
        }
    }


    @ApiOperation("视图chart列表查询")
    @PostMapping("viewChartList")
    public HttpResult<BiPageModel<Chart>> queryViewChartList(@RequestBody QueryViewChartListParam param) {
        if (param == null || param.getPageNum() == null || param.getPageSize() == null) {
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.paramError"));
        }
        try{
            BiPageModel<Chart> viewChartList = chartService.queryViewChartList(param);
            return HttpResult.returnSuccess(viewChartList);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.queryFail") + e.getMessage());
        }
    }

}
