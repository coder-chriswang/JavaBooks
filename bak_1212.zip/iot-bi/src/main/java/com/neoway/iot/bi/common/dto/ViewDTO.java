package com.neoway.iot.bi.common.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <pre>
 *  描述: 视图实体
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/7 15:34
 */
@Data
@ApiModel("视图实体列表")
public class ViewDTO {

    @ApiModelProperty(value = "视图ID")
    private String viewId;

    @ApiModelProperty(value = "视图名称")
    private String name;
}
