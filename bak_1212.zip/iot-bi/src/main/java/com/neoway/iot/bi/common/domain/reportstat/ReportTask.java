package com.neoway.iot.bi.common.domain.reportstat;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("报表任务")
public class ReportTask {

	private Long id;

	private Long strategyId;

	private String viewid;

	private String viewName;

	private Long nodeid;

	private Integer dcost;

	private Integer dstatus;

	private Integer gcost;

	private Integer gstatus;

	private Integer scost;

	private Integer sstatus;

	private Integer st;

	private Integer lt;
}
