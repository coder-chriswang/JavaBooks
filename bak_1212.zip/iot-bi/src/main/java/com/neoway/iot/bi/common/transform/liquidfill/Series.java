package com.neoway.iot.bi.common.transform.liquidfill;

import java.util.List;

public class Series {

	private List<String> percent;

	private List<String> pieData;

	public List<String> getPercent () {
		return percent;
	}

	public void setPercent (List<String> percent) {
		this.percent = percent;
	}

	public List<String> getPieData () {
		return pieData;
	}

	public void setPieData (List<String> pieData) {
		this.pieData = pieData;
	}
}
