package com.neoway.iot.bi.common.domain.view;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@ApiModel("视图实例")
public class ViewInstance {

	private Long taskId;

	private String viewid;

	private String name;

	private String type;

	private byte[] data;

	private String desc;

	private Integer lt;
}
