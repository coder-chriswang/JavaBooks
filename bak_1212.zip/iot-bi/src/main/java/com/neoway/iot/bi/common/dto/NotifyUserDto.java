package com.neoway.iot.bi.common.dto;

import lombok.Data;

@Data
public class NotifyUserDto {

	private String name;

	private String phone;

	private String email;

}
