package com.neoway.iot.bi.common.transform.table;

import java.util.List;

public class TableData {

	private List<TableHeader> tableHeader;

	private TableDataData tableData;

	public List<TableHeader> getTableHeader () {
		return tableHeader;
	}

	public void setTableHeader (List<TableHeader> tableHeader) {
		this.tableHeader = tableHeader;
	}

	public TableDataData getTableData () {
		return tableData;
	}

	public void setTableData (TableDataData tableData) {
		this.tableData = tableData;
	}
}
