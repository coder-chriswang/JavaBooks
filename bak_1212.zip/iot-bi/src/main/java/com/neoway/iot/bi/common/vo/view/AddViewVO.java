package com.neoway.iot.bi.common.vo.view;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * <pre>
 *  描述: 添加视图配置实体
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/17 20:08
 */
@Data
@ApiModel("添加视图配置实体")
public class AddViewVO {

    @ApiModelProperty(value = "视图名称")
    @NotNull(message = "ies.bi.view.msg.param.nameBlankError")
    private String name;

    @ApiModelProperty(value = "视图描述")
    @NotNull(message = "ies.bi.view.msg.param.descBlankError")
    private String desc;

    @ApiModelProperty(value = "视图id")
    @NotNull(message = "ies.bi.view.msg.param.idBlankError")
    private List<String> chart;

}
