package com.neoway.iot.bi.common.domain.reportstat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <pre>
 *  描述: 周期报表统计策略实体
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/7 16:03
 */
@Data
@ApiModel("周期报表统计策略实体")
public class ReportStrategy {

    @ApiModelProperty(value = "策略id")
    private long id;

    @ApiModelProperty(value = "视图id")
    private String viewId;

    @ApiModelProperty(value = "周期策略")
    private String policy;

    @ApiModelProperty(value = "通知方式")
    private String notifyType;

    @ApiModelProperty(value = "通知组")
    private String notifyGroup;

    @ApiModelProperty(value = "通知组编码")
    private String notifyGroupCode;

    @ApiModelProperty(value = "更新时间")
    private Integer lt;

}
