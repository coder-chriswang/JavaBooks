package com.neoway.iot.bi.common.vo.offlinestrategy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@ApiModel("添加离线统计策略实体")
public class AddOfflineStrategyVO {

	@ApiModelProperty(value = "产品域")
	@NotNull(message = "产品域不得为空")
	private String ns;

	@ApiModelProperty(value = "对象")
	@NotNull(message = "对象不得为空")
	private String type;

	@ApiModelProperty(value = "指标")
	@NotNull(message = "指标不得为空")
	private String metric;

	@ApiModelProperty(value = "统计算法")
	@NotNull(message = "统计算法不得为空")
	private String algorithm;

	@ApiModelProperty(value = "统计策略（h,d,m）")
	@NotNull(message = "统计策略不得为空")
	private String policy;
}
