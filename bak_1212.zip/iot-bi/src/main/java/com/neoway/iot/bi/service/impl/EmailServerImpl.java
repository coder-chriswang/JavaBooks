package com.neoway.iot.bi.service.impl;

import cn.hutool.json.JSONUtil;
import com.google.common.cache.Cache;
import com.google.gson.Gson;
import com.neoway.iot.bi.HttpResult;
import com.neoway.iot.bi.common.Utils;
import com.neoway.iot.bi.common.enums.ExtApiEnum;
import com.neoway.iot.bi.common.param.EmailServerParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;

@Service
@Slf4j
public class EmailServerImpl {

	@Resource
	private RestTemplate restTemplate;

	@Resource
	private Cache guavaCache;

	@Value("${iot.service.mng.host}")
	private String mngHost;

	public Boolean getEmailServerProp() {
		String url = mngHost + ExtApiEnum.MNG_GET_EMAIL_SERVER_PROP.getUrl() + "statistics";
		ResponseEntity<HttpResult> entity = null;
		try {
			entity = restTemplate.getForEntity(url, HttpResult.class);
		if (!HttpStatus.OK.equals(entity.getStatusCode()) || entity.getBody().getCode() != HttpStatus.OK.value()) {
			log.error("http error, status:{}, entity data error, code:{}", entity.getStatusCode().value(), entity.getBody().getCode());
			return false;
		}
		Gson gson = Utils.getJsonUtil();
		String json = gson.toJson(entity.getBody().getData());
		EmailServerParam emailServerParam = gson.fromJson(json, EmailServerParam.class);
		guavaCache.put("statEmailServer", emailServerParam);
		guavaCache.put("sendEmail", emailServerParam.getSendEmail());
		return true;
		} catch (Exception ex) {
			log.error(ex.getMessage());
			return false;
		}
	}

}
