package com.neoway.iot.bi.common.vo.reportstrategy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <pre>
 *  描述: 周期报表统计策略查询条件
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/6 11:06
 */
@Data
@ApiModel("周期报表统计策略列表查询")
public class ListReportStrategyVo {

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页行数")
    private Integer pageSize;

    @ApiModelProperty(value = "视图名称")
    private String name;

}
