package com.neoway.iot.bi.common.vo.view;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.util.List;

/**
 * <pre>
 *  描述: 编辑视图实体
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/18 14:03
 */
@Data
@ApiModel("编辑视图实体")
public class EditViewVO {

    @ApiModelProperty(value = "视图id")
    private String viewId;

    @ApiModelProperty(value = "视图名称")
    private String name;

    @ApiModelProperty(value = "视图描述")
    private String desc;

    @ApiModelProperty(value = "图标")
    private List<String> chart;
}
