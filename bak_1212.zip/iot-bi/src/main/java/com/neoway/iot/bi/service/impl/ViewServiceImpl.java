package com.neoway.iot.bi.service.impl;

import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.domain.view.View;
import com.neoway.iot.bi.common.exception.ChartServiceException;
import com.neoway.iot.bi.common.param.QueryChartListParam;
import com.neoway.iot.bi.common.util.BiPageModel;
import com.neoway.iot.bi.common.util.IDWorker;
import com.neoway.iot.bi.common.vo.view.AddViewVO;
import com.neoway.iot.bi.common.vo.view.EditViewVO;
import com.neoway.iot.bi.dao.view.IViewDao;
import com.neoway.iot.bi.service.IViewService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

/**
 * <pre>
 *  描述: 视图配置service实现
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/17 20:40
 */
@Service
@Slf4j
public class ViewServiceImpl implements IViewService {

    @Resource
    private IViewDao viewDao;

    @Override
    public int addView(AddViewVO addViewVO) {
        View view = new View();
        view.setViewid(String.valueOf(IDWorker.id.nextId()));
        view.setName(addViewVO.getName());
        view.setDesc(addViewVO.getDesc());
        view.setChart(String.join(",",addViewVO.getChart()));
        view.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
        return viewDao.addView(view);
    }

    @Override
    public int del(String viewId) {
        return viewDao.delete(viewId);
    }

    @Override
    public int edit(EditViewVO editViewVO) {
        View view = new View();
        view.setViewid(editViewVO.getViewId());
        view.setName(editViewVO.getName());
        view.setDesc(editViewVO.getDesc());
        view.setChart(String.join(",",editViewVO.getChart()));
        view.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
        return viewDao.updateBySelective(view);
    }

    @Override
    public List<View> queryView() {
        List<View> viewList = viewDao.selectView();
        return viewList;
    }

    @Override
    public BiPageModel<Chart> queryViewChartList(QueryChartListParam param) throws ChartServiceException {
        if (param == null) {
            throw new ChartServiceException("参数有误");
        }
        Integer count = viewDao.queryCount(param);
        if (count == null || count <= 0) {
            return BiPageModel.build(null, 1, 0, 1);
        }
        List<Chart> chartList = viewDao.queryList(param);
        return BiPageModel.build(chartList, param.getPageNum(), count, param.getPageSize());
    }
}
