package com.neoway.iot.bi.common.enums;

public enum ExtApiEnum {

	GW_Command_Asyn("/v1/command/asyn", "指令执行-异步"),
	GW_Command_Syn("/v1/command/syn", "指令执行-同步"),
	MNG_GET_EMAIL_SERVER_PROP("/v1/emailserver/", "获取邮件服务器配置"),
	MNG_GET_NOTIFY_USER("/v1/notifyUser/listByCode", "获取通知组用户信息");
	;

	public String url;
	public String description;

	ExtApiEnum (String url, String description) {
		this.url = url;
		this.description = description;
	}

	public String getDescription () {
		return description;
	}

	public String getUrl () {
		return url;
	}

	public static ExtApiEnum getEnumByCode(String url) {
		if (null == url || "".equals(url)) {
			return null;
		}

		ExtApiEnum responseCode;

		for (int i = 0; i < ExtApiEnum.values().length; i++) {
			responseCode = ExtApiEnum.values()[i];
			if (responseCode.url.equals(url)) {
				return responseCode;
			}
		}
		return null;
	}

	public static boolean contains(String url) {
		ExtApiEnum gwmApiEnum = ExtApiEnum.getEnumByCode(url);
		if (gwmApiEnum == null) {
			return false;
		} else {
			return true;
		}
	}
}
