package com.neoway.iot.bi.common.domain.reportstat;

import cn.hutool.json.JSONObject;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("报表数据实体")
public class ReportData {

	private Long id;

	private Long taskId;

	private String viewid;

	private String viewName;

	private String chartid;

	private String chartName;

	private String chartAlgorthm;

	private String chartType;

	private Long nodeid;

	private JSONObject chartData;

	private Integer lt;


}
