package com.neoway.iot.bi.task.service;

import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.domain.node.Node;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.service.IOfflineTaskService;
import com.neoway.iot.bi.service.IReportTaskService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

@Service
@Slf4j
public class NodeHealthCheckTask implements TaskService {

	@Resource
	private INodeService nodeService;

	@Resource
	private IOfflineTaskService offlineTaskService;

	@Resource
	private IReportTaskService reportTaskService;

	@Resource
	private UpdateNodeStatusTask updateNodeStatusTask;

	@Resource
	private Cache guavaCache;

	@Value("${node.health.timeout}")
	private Integer nodeHealthTimeout;

	@Override
	public boolean process () {
		Long newNid = Long.valueOf(String.valueOf(guavaCache.getIfPresent("nid")));
		Integer currentLt = Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"))));
		List<Node> nodeList = nodeService.getList(null);
		nodeList.forEach(node -> {
			Integer dbLt = node.getLt();
			if (currentLt - dbLt > nodeHealthTimeout) {
				//更新改节点状态
				updateNodeStatusTask.process();
				//节点下的任务转移,目前移至发现节点故障的节点下
				offlineTaskService.offlineTaskTransfer(node.getNid(), newNid);
				//周期报表任务 节点任务转移
				reportTaskService.reportTaskTransfer(node.getNid(), newNid);
			}
		});
		return true;
	}
}
