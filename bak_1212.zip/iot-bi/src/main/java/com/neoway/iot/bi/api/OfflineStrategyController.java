package com.neoway.iot.bi.api;

import com.neoway.iot.bi.HttpResult;
import com.neoway.iot.bi.common.dto.OfflineStrategyDTO;
import com.neoway.iot.bi.common.vo.offlinestrategy.AddOfflineStrategyVO;
import com.neoway.iot.bi.common.vo.offlinestrategy.EditOfflineStrategyVO;
import com.neoway.iot.bi.common.vo.offlinestrategy.ListOfflineStrategyVO;
import com.neoway.iot.bi.service.IOfflineStrategyService;
import com.neoway.iot.bi.common.util.BiPageModel;
import com.neoway.iot.bi.common.util.PageHelper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/v1/offlineStrategy")
@Api(tags = "离线统计策略接口", description = "离线统计策略接口")
@Slf4j
public class OfflineStrategyController {

    @Resource
    private IOfflineStrategyService offlineStatService;

    @ApiOperation(value = "新增离线统计策略")
    @PostMapping("add")
    public HttpResult addOfflineStrategy(@RequestBody @Valid AddOfflineStrategyVO addOfflineStrategyVO){
        int result = offlineStatService.add(addOfflineStrategyVO);
        return HttpResult.returnSuccess(result);
    }

    @ApiOperation(value = "修改离线统计策略")
    @PutMapping("update")
    public HttpResult updateOfflineStrategy(@RequestBody @Valid EditOfflineStrategyVO editOfflineStrategyVO){
        int result = offlineStatService.edit(editOfflineStrategyVO);
        return HttpResult.returnSuccess(result);
    }

    @ApiOperation(value = "删除离线统计策略")
    @DeleteMapping("del/{metric}")
    public HttpResult delOfflineStrategy(@PathVariable("metric") String metric){
        int result = offlineStatService.del(metric);
        return HttpResult.returnSuccess(result);
    }

    @ApiOperation(value = "离线统计策略查询")
    @GetMapping("get/{metric}")
    public HttpResult<OfflineStrategyDTO> getOfflineStrategy(@PathVariable("metric") String metric){
        OfflineStrategyDTO offlineStrategyDTO = offlineStatService.get(metric);
        return HttpResult.returnSuccess(offlineStrategyDTO);
    }

    @ApiOperation(value = "离线统计策略列表查询")
    @PostMapping("list")
    public HttpResult<BiPageModel<OfflineStrategyDTO>> listOfflineStrategy(@RequestBody @Valid ListOfflineStrategyVO listOfflineStrategyVO){
        List<OfflineStrategyDTO> offlineStrategyDTOS = offlineStatService.list(listOfflineStrategyVO);
        BiPageModel<OfflineStrategyDTO> pagination = PageHelper.pagination(offlineStrategyDTOS, listOfflineStrategyVO.getPageSize(), listOfflineStrategyVO.getPageNum());
        return HttpResult.returnSuccess(pagination);
    }


}
