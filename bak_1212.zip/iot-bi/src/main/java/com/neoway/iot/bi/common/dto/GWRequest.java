package com.neoway.iot.bi.common.dto;

import lombok.Data;

import java.util.Map;

@Data
public class GWRequest {

	private Map<String, Object> header;

	private Map<String, Object> body;
}
