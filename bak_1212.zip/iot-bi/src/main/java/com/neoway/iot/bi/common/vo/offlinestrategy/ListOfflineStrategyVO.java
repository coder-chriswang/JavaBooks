package com.neoway.iot.bi.common.vo.offlinestrategy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("离线统计策略列表查询")
public class ListOfflineStrategyVO {

	@ApiModelProperty("当前页")
	private Integer pageNum;

	@ApiModelProperty("页行数")
	private Integer pageSize;

	@ApiModelProperty(value = "指标")
	private String metric;

	@ApiModelProperty(value = "统计策略")
	private String policy;
}
