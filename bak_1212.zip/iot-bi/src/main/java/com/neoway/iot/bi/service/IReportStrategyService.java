package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.domain.reportstat.ReportStrategy;
import com.neoway.iot.bi.common.dto.ReportStrategyDTO;
import com.neoway.iot.bi.common.dto.ViewDTO;
import com.neoway.iot.bi.common.vo.reportstrategy.AddReportStrategyVO;
import com.neoway.iot.bi.common.vo.reportstrategy.EditReportStrategyVO;
import com.neoway.iot.bi.common.vo.reportstrategy.ListReportStrategyVo;

import java.util.List;

/**
 * <pre>
 *  描述:周期报表统计策略相关接口
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/6 9:12
 */
public interface IReportStrategyService {


    /**
     * 周期报表策略列表查询
     * @param listReportStrategyVo
     * @return
     */
    List<ReportStrategyDTO> list(ListReportStrategyVo listReportStrategyVo);

    /**
     * 获取视图下拉框
     * @return
     */
    List<ViewDTO> getViewDropDown();

    /**
     * 添加周期报表统计策略
     * @param addReportStrategyVO
     * @return
     */
    int add(AddReportStrategyVO addReportStrategyVO);

    /**
     * 删除周期报表统计策略
     * @param id
     * @return
     */
    int del(String id);

    /**
     * 修改周期报表统计策略
     * @param editReportStrategyVO
     * @return
     */
    int edit(EditReportStrategyVO editReportStrategyVO);

    /**
     * 获取周期报表策略
     * @param reportStrategy
     * @return
     */
    ReportStrategy getOne(ReportStrategy reportStrategy);

    /**
     * 修改周期报表通知组信息
     * @param code
     * @param name
     * @return
     */
    int editNotifyGroup(String code, String name);

    /**
     * 根据code删除周期报表策略
     * @param code
     * @return
     */
    int delByCode(String code);
}
