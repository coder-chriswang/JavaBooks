package com.neoway.iot.bi.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.domain.reportstat.ReportData;
import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.dto.GWRequest;
import com.neoway.iot.bi.common.dto.GWResponse;
import com.neoway.iot.bi.common.enums.ExtApiEnum;
import com.neoway.iot.bi.common.enums.ReportGenerateStatusEnum;
import com.neoway.iot.bi.common.enums.ReportNotifyStatusEnum;
import com.neoway.iot.bi.common.enums.ReportStatStatusEnum;
import com.neoway.iot.bi.common.util.IDWorker;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.dao.chart.IChartDao;
import com.neoway.iot.bi.dao.reportstat.IReportDataDao;
import com.neoway.iot.bi.dao.reportstat.IReportTaskDao;
import com.neoway.iot.bi.service.IReportTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ReportTaskServiceImpl implements IReportTaskService {

	@Resource
	private IReportTaskDao reportTaskDao;

	@Resource
	private IReportDataDao reportDataDao;

	@Resource
	private IChartDao chartDao;

	@Resource
	private RestTemplate restTemplate;

	@Value("${iot.service.gw.host}")
	private String gwHost;

	@Override
	public List<ReportTask> getReportTaskList (ReportTask reportTask) {
		List<ReportTask> reportTasks = reportTaskDao.selectList(reportTask);
		return reportTasks;
	}

	@Override
	public int add(ReportTask reportTask) {
		return reportTaskDao.insert(reportTask);
	}

    @Override
    public String getChartByViewId(String viewid) {
        return reportTaskDao.getChartByViewId(viewid);
    }

	@Override
	public int updateReportTask(ReportTask reportTask, Long id) {
		return reportTaskDao.update(reportTask,id);
	}

	@Override
	public List<ReportTask> getTimeUpReportTaskList(ReportTask rt) {
		List<ReportTask> reportTasks = reportTaskDao.selectTimeUpReportTaskList(rt);
		return reportTasks;
	}

	@Override
	public List<Integer> getReportTaskDstatus(Long id) {
		return reportTaskDao.getDstatusByStateId(id);
	}

	@Override
	public int del (Long taskId) {
		int result = reportTaskDao.delete(taskId);
		return result;
	}

	@Override
	public int del30DayBeforeData (Del30DayBeforeData del30DayBeforeData) {
		int result = reportTaskDao.del30DayBeforeDay(del30DayBeforeData);
		return result;
	}

	@Override
	public Boolean executeCommandSyn(ReportTask reportTask,String[] chartIds) {
		List<Chart> charts = chartDao.batchQueryById(chartIds);
		HttpHeaders headers = new HttpHeaders();
		MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
		headers.setContentType(type);
		headers.add("Accept", MediaType.APPLICATION_JSON.toString());
		AtomicReference<GWRequest> gwRequest = new AtomicReference<>();
		List<Boolean> booleanList = CollUtil.newArrayList();
		List<ReportData> reportDataList = CollUtil.newArrayList();
		charts.forEach(chart ->{
			gwRequest.set(new GWRequest());
			Map<String, Object> header = new HashMap<>();
			header.put("templateid", chart.getAlgorithm());
			gwRequest.get().setHeader(header);
			HttpEntity<String> formEntity = new HttpEntity<String>(JSONUtil.toJsonStr(gwRequest.get()), headers);
			try {
                ResponseEntity<GWResponse> entity = restTemplate.postForEntity(gwHost + ExtApiEnum.GW_Command_Syn.getUrl(), formEntity, GWResponse.class);
                if (HttpStatus.OK.equals(entity.getStatusCode())) {
                    String code = entity.getBody().getCode();
                    if ("200".equals(code)) {
                        ReportData reportData = new ReportData();
                        reportData.setId(IDWorker.id.nextId());
                        reportData.setTaskId(reportTask.getId());
                        reportData.setViewid(reportTask.getViewid());
                        reportData.setViewName(reportTask.getViewid());
                        reportData.setChartid(chart.getChartid());
                        reportData.setChartName(chart.getName());
                        reportData.setChartAlgorthm(chart.getAlgorithm());
                        reportData.setChartType(chart.getType());
                        reportData.setNodeid(reportTask.getNodeid());
                        reportData.setChartData(JSONUtil.parseObj(entity.getBody().getData()));
                        reportData.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
                        reportDataList.add(reportData);
                        booleanList.add(true);
                    } else {
                        booleanList.add(false);
                    }
                }
            } catch (Exception ex) {
                log.error("GW Restful API:{} exception, request json: {}", ex.getMessage(), JSONUtil.toJsonStr(gwRequest.get()));
                return;
            }
		});
		if (CollUtil.isNotEmpty(reportDataList)){
			try {
				reportDataDao.batchAddReportData(reportDataList);
			} catch (Exception e){
				log.error("批量插入异常={}",e.getMessage());
			}
		}
		if (booleanList.contains(true)){
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int update (ReportTask reportTask) {
		int result = reportTaskDao.updateBySelective(reportTask);
		return result;
	}

	@Override
	public void reportTaskTransfer(Long nid, Long newNid) {
		ReportTask reportTask = new ReportTask();
		reportTask.setNodeid(nid);
		reportTask.setDstatus(ReportStatStatusEnum.WAITTING.getCode());
		List<ReportTask> reportTaskList1 = reportTaskDao.selectList(reportTask);
		ReportTask reportTask2 = new ReportTask();
		reportTask2.setNodeid(nid);
		reportTask2.setGstatus(ReportGenerateStatusEnum.WAITTING.getCode());
		List<ReportTask> reportTaskList2 = reportTaskDao.selectList(reportTask2);
		ReportTask reportTask3 = new ReportTask();
		reportTask3.setNodeid(nid);
		reportTask3.setSstatus(ReportNotifyStatusEnum.WAITTING.getCode());
		List<ReportTask> reportTaskList3 = reportTaskDao.selectList(reportTask3);
		List<ReportTask> reportTaskList = CollUtil.newArrayList();
		reportTaskList.addAll(reportTaskList1);
		reportTaskList.addAll(reportTaskList2);
		reportTaskList.addAll(reportTaskList3);
		List<ReportTask> collect = reportTaskList.stream().distinct().collect(Collectors.toList());
		if (collect.size() > 0){
			collect.forEach(reportTask1 -> {
				reportTask1.setNodeid(newNid);
				reportTaskDao.updateBySelective(reportTask1);
			});
		}

	}
}
