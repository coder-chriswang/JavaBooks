package com.neoway.iot.bi.service;

import org.springframework.core.io.InputStreamSource;

public interface IMailService {

    void sendSimpleMail(String to, String subject, String content);

    void sendHtmlMail(String to, String subject, String content);

    void sendAttachmentsMail(String to, String subject, String content, String filePath);

    void sendInlineResourceMail(String to, String subject, String content, String rscPath, String rscId);

    void sendAttachmentsMailFromSource(String to, String subject, String content, InputStreamSource inputStreamSource);
}
