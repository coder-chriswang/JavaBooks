package com.neoway.iot.bi.common.transform.pie;

import com.neoway.iot.bi.common.transform.BaseData;

public class BasePieData extends BaseData {

	private PieData data;

	public PieData getData () {
		return data;
	}

	public void setData (PieData data) {
		this.data = data;
	}
}
