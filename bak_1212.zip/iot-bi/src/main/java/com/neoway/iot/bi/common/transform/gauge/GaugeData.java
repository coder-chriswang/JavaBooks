package com.neoway.iot.bi.common.transform.gauge;

public class GaugeData {

	private String name;

	private Integer value;

	private String unit;

	private Integer min;

	private Integer max;

	private Integer splitNumber;

	public String getName () {
		return name;
	}

	public void setName (String name) {
		this.name = name;
	}

	public Integer getValue () {
		return value;
	}

	public void setValue (Integer value) {
		this.value = value;
	}

	public String getUnit () {
		return unit;
	}

	public void setUnit (String unit) {
		this.unit = unit;
	}

	public Integer getMin () {
		return min;
	}

	public void setMin (Integer min) {
		this.min = min;
	}

	public Integer getMax () {
		return max;
	}

	public void setMax (Integer max) {
		this.max = max;
	}

	public Integer getSplitNumber () {
		return splitNumber;
	}

	public void setSplitNumber (Integer splitNumber) {
		this.splitNumber = splitNumber;
	}
}
