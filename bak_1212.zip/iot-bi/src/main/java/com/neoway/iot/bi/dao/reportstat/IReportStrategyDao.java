package com.neoway.iot.bi.dao.reportstat;

import com.neoway.iot.bi.common.domain.reportstat.ReportStrategy;
import com.neoway.iot.bi.common.dto.ReportStrategyDTO;
import com.neoway.iot.bi.common.dto.ViewDTO;
import com.neoway.iot.bi.common.vo.reportstrategy.AddReportStrategyVO;
import com.neoway.iot.bi.common.vo.reportstrategy.ListReportStrategyVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述: 周期报表统计策略dao层
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/6 13:49
 */
public interface IReportStrategyDao {

    /**
     * 周期报表统计策略列表查询
     * @param listReportStrategyVo
     * @return
     */
    List<ReportStrategyDTO> selectList(ListReportStrategyVo listReportStrategyVo);

    /**
     * 查询视图下拉框
     * @return
     */
    List<ViewDTO> selectDropDown();

    /**
     * 添加周期报表统计策略
     * @param reportStrategy
     * @return
     */
    int insert(@Param("reportStrategy") ReportStrategy reportStrategy);

    /**
     * 删除周期报表统计策略
     * @param id
     * @return
     */
    int delete(@Param("id") String id);

    /**
     * 更新周期报表统计策略
     * @param reportStrategy
     * @return
     */
    int updateBySelective(@Param("reportStrategy") ReportStrategy reportStrategy);

    /**
     * 查询所有周期报表
     * @return
     */
    List<AddReportStrategyVO> getReportStrategyList();

    /**
     * 获取周期报表策略
     * @param reportStrategy
     * @return
     */
    ReportStrategy selectOne(@Param("reportStrategy") ReportStrategy reportStrategy);

    /**
     * 更改周期报表策略通知组
     * @param code
     * @param name
     * @return
     */
    int updateNotifyGroup(@Param("code") String code, @Param("name") String name);

    /**
     * 根据code删除周期报表策略
     * @param code
     * @return
     */
    int deleteByCode(@Param("code") String code);
}
