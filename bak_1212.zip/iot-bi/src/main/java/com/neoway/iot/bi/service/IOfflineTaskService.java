package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.dto.GWRequest;
import com.neoway.iot.bi.common.dto.OfflineTaskExecuteDTO;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.common.domain.offlinestat.OfflineTask;

import java.util.List;

/**
 * 离线统计任务相关接口
 */
public interface IOfflineTaskService {

	/**
	 * 添加离线统计任务
	 * @param offlineTask
	 * @return
	 */
	int add(OfflineTask offlineTask);

	/**
	 * 修改离线统计任务
	 * @param offlineTask
	 * @return
	 */
	int update(OfflineTask offlineTask);

	/**
	 * 获取离线统计任务
	 * @param offlineTask
	 * @return
	 */
	OfflineTask get(OfflineTask offlineTask);

	/**
	 * RESTFUL调用接入网关sql查询
	 * @param gwRequest
	 */
	Boolean executeCommandAsyn(GWRequest gwRequest);

	/**
	 * 获取最后一条离线统计任务
	 * @param offlineTask
	 * @return
	 */
	OfflineTask getLastOne(OfflineTask offlineTask);

	/**
	 * 查询任务列表
	 * @param offlineTask
	 * @return
	 */
	List<OfflineTask> list(OfflineTask offlineTask);

	/**
	 * 查询状态未待执行并且到点的任务列表
	 * @param offlineTask
	 * @return
	 */
	List<OfflineTaskExecuteDTO> getTimeUpTaskList(OfflineTask offlineTask);

	/**
	 * 删除30天前的所有数据
	 * @param del30DayBeforeData
	 * @return
	 */
	int del30DayBeforeData(Del30DayBeforeData del30DayBeforeData);

	/**
	 * 节点故障离线统计任务转移
	 * @param nid 故障节点id
	 * @param newNid 新节点id
	 * @return
	 */
	int offlineTaskTransfer(Long nid, Long newNid);

}
