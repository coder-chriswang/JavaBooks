package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.param.QueryChartListParam;
import com.neoway.iot.bi.common.domain.BiChart;
import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.exception.ChartServiceException;
import com.neoway.iot.bi.common.param.QueryViewChartListParam;
import com.neoway.iot.bi.common.util.BiPageModel;

import java.util.List;

public interface IChartService {
    BiPageModel<Chart> queryPageList(QueryChartListParam param) throws ChartServiceException;
    BiChart getChartDetail(String chartId) throws ChartServiceException;
    BiChart getGISDetail(String chartId, String doInstanceId) throws ChartServiceException;
    List<BiChart> getChartListByViewId(String viewId);
    BiPageModel<Chart> queryViewChartList(QueryViewChartListParam param);
}
