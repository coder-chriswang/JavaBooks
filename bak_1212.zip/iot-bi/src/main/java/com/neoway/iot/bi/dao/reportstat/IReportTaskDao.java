package com.neoway.iot.bi.dao.reportstat;

import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IReportTaskDao {

	/**
	 * 查询周期报表任务列表
	 * @param reportTask
	 * @return
	 */
	List<ReportTask> selectList(ReportTask reportTask);

	/**
	 * 添加周期报表任务
	 * @param reportTask
	 * @return
	 */
	int insert(@Param("reportTask") ReportTask reportTask);

	/**
	 * 更新周期报表任务
	 * @param reportTask
	 * @return
	 */
	int updateBySelective(@Param("reportTask") ReportTask reportTask);

	/**
	 * 根据viewid获取chart
	 * @param viewid
	 * @return
	 */
    String getChartByViewId(@Param("viewid") String viewid);

	/**
	 * 更新周期报表任务
	 * @param reportTask
	 * @param id
	 * @return
	 */
	int update(@Param("reportTask") ReportTask reportTask, @Param("id") Long id);

	/**
	 * 获取超出任务计划时间周期报表任务
	 * @param reportTask
	 * @return
	 */
	List<ReportTask> selectTimeUpReportTaskList(@Param("reportTask") ReportTask reportTask);

    /**
     * 根据策略id获取统计状态
     * @param id
     * @return
     */
    List<Integer> getDstatusByStateId(@Param("id") Long id);

	/**
	 * 删除任务
	 * @param id
	 * @return
	 */
	int delete(Long id);

	/**
	 * 删除大于30天的任务数据
	 * @param del30DayBeforeData
	 * @return
	 */
	int del30DayBeforeDay(Del30DayBeforeData del30DayBeforeData);
}
