package com.neoway.iot.bi.common.transform.bar;

import com.neoway.iot.bi.common.transform.BaseData;

public class BaseBarData extends BaseData {

	private BarData data;

	public BarData getData () {
		return data;
	}

	public void setData (BarData data) {
		this.data = data;
	}
}
