package com.neoway.iot.bi.task;

import com.neoway.iot.bi.common.enums.TaskCronServiceEnum;
import com.neoway.iot.bi.config.SpringContextHolder;
import com.neoway.iot.bi.service.IMailService;
import com.neoway.iot.bi.service.impl.EmailServerImpl;
import com.neoway.iot.bi.service.impl.MailServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ScheduledFuture;

@Component
@Slf4j
public class TimerTaskService {
	

    @Resource
    private ThreadPoolTaskScheduler threadPoolTaskScheduler;

    @Resource
    private SpringContextHolder springContextHolder;

    @Resource
    private MailServiceImpl mailService;

    private List<ScheduledFuture<?>> robotFutureList=new CopyOnWriteArrayList<>();

	public void startTimerTask() {
	    startTask();
	}

	private void startTask () {

	    for (TaskCronServiceEnum taskCronServiceEnum : TaskCronServiceEnum.values()) {
		    log.info("{}启动", taskCronServiceEnum.getDesc());
		    ScheduledFuture future = threadPoolTaskScheduler.schedule(() -> {
					    try {
					    	TaskService taskService = springContextHolder.getTaskService(taskCronServiceEnum.getTaskBeanName());
					    	taskService.process();
					    } catch (Exception ex) {
						    log.error("start task error :{}", ex.getMessage());
					    }
				    }
				    , triggerContext -> {
					    CronTrigger trigger = new CronTrigger(taskCronServiceEnum.getCron());
					    Date nextExec = trigger.nextExecutionTime(triggerContext);
					    return nextExec;
				    });
		    robotFutureList.add(future);
	    }

    }

    /**
     * 停止定时任务
     */
    public void stopTask() {
	    //不会马上停止任务,会等任务执行完 只是执行了interrupt方法
	    robotFutureList.stream().filter(Objects::nonNull).forEach(future -> future.cancel(true));
        robotFutureList.clear();
        log.info("DynamicTask.stopTask()");
    }
 
}