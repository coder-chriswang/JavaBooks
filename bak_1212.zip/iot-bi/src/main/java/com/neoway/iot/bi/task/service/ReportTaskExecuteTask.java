package com.neoway.iot.bi.task.service;

import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.enums.ReportStatStatusEnum;
import com.neoway.iot.bi.common.util.IDWorker;
import com.neoway.iot.bi.service.IReportTaskService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * <pre>
 *  描述: 周期报表任务执行
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/9 20:20
 */
@Service
@Slf4j
public class ReportTaskExecuteTask implements TaskService {

    @Resource
    private IReportTaskService reportTaskService;

    @Resource
    private ThreadPoolExecutor threadPoolExecutor;

    @Override
    public boolean process() {
        //查询出待执行的任务列表，遍历执行
        ReportTask rt = new ReportTask();
        rt.setDstatus(ReportStatStatusEnum.WAITTING.getCode());
        rt.setSt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
        List<ReportTask> reportTaskList = reportTaskService.getTimeUpReportTaskList(rt);
        reportTaskList.forEach(reportTask -> {
            Long id = reportTask.getId();
            reportTask.setId(IDWorker.id.nextId());
            reportTask.setDstatus(ReportStatStatusEnum.RUNNING.getCode());
            reportTask.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
            try {
                reportTaskService.updateReportTask(reportTask,id);
            }catch (Exception ex){
                log.error("更新报表任务失败,status={}, ex:{}", reportTask.getDstatus(), ex.getMessage());
                return;
            }
            String chartByViewId = reportTaskService.getChartByViewId(reportTask.getViewid());
            String[] chartIds = chartByViewId.split(",");
            Long st = System.currentTimeMillis();
            Boolean result = reportTaskService.executeCommandSyn(reportTask,chartIds);
            Long lt = System.currentTimeMillis();
            Long dcost = lt - st;
            reportTask.setDcost(dcost.intValue());
            if (result){
                reportTask.setDstatus(ReportStatStatusEnum.FINISH.getCode());
            } else {
                reportTask.setDstatus(ReportStatStatusEnum.FAIL.getCode());
            }
            reportTask.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
            try {
                reportTaskService.updateReportTask(reportTask,reportTask.getId());
            }catch (Exception ex){
                log.error("更新报表任务失败,status={}, ex:{}", reportTask.getDstatus(), ex.getMessage());
                return;
            }
          });
        return true;
    }
}
