package com.neoway.iot.bi.common.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

//@Data
//@NoArgsConstructor
//@AllArgsConstructor
@ApiModel("邮件服务器")
public class EmailServerParam implements Serializable {

	private static final long serialVersionUID = -3953793196812106384L;
	@ApiModelProperty("邮箱类别")
	private String type;

	@ApiModelProperty("链接协议")
	private String protocol;

	@ApiModelProperty("邮件服务器")
	private String server;

	@ApiModelProperty("端口")
	private Integer port;

	@ApiModelProperty("发件人邮箱")
	private String sendEmail;

	@ApiModelProperty("发件人账号")
	private String sendAccount;

	@ApiModelProperty("发件人密码")
	private String sendPwd;

	@ApiModelProperty("更新时间")
	private Integer lt;

	public EmailServerParam () {
	}


	public static long getSerialVersionUID () {
		return serialVersionUID;
	}

	public String getType () {
		return type;
	}

	public void setType (String type) {
		this.type = type;
	}

	public String getProtocol () {
		return protocol;
	}

	public void setProtocol (String protocol) {
		this.protocol = protocol;
	}

	public String getServer () {
		return server;
	}

	public void setServer (String server) {
		this.server = server;
	}

	public Integer getPort () {
		return port;
	}

	public void setPort (Integer port) {
		this.port = port;
	}

	public String getSendEmail () {
		return sendEmail;
	}

	public void setSendEmail (String sendEmail) {
		this.sendEmail = sendEmail;
	}

	public String getSendAccount () {
		return sendAccount;
	}

	public void setSendAccount (String sendAccount) {
		this.sendAccount = sendAccount;
	}

	public String getSendPwd () {
		return sendPwd;
	}

	public void setSendPwd (String sendPwd) {
		this.sendPwd = sendPwd;
	}

	public Integer getLt () {
		return lt;
	}

	public void setLt (Integer lt) {
		this.lt = lt;
	}
}
