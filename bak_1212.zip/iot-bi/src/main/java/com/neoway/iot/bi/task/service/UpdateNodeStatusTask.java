package com.neoway.iot.bi.task.service;

import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.domain.node.Node;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;


@Slf4j
@Service
public class UpdateNodeStatusTask implements TaskService {

	@Resource
	private INodeService nodeService;

	@Resource
	private Cache guavaCache;

	@Override
	public boolean process () {
		Long nid = Long.valueOf(String.valueOf(guavaCache.getIfPresent("nid")));
		Node node = new Node();
		node.setNid(nid);
		Node node1 = nodeService.get(node);
		if (node1 == null) {
			nodeService.add();
		} else {
			node.setStatus(NodeStatusEnum.ONLINE.getCode());
			node.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
			int result = nodeService.update(node);
		}
		return true;
	}
}
