package com.neoway.iot.bi.common.enums;

public enum NotifyTypeEnum {
	EMAIL("email", "邮件通知"),
	DINGDING("dingding", "钉钉通知")
	;

	private String code;

	private String desc;

	NotifyTypeEnum (String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static NotifyTypeEnum getEnumByCode(String code) {
		if (null == code || "".equals(code)) {
			return null;
		}
		NotifyTypeEnum responseCode;
		for (int i = 0; i < NotifyTypeEnum.values().length; i++) {
			responseCode = NotifyTypeEnum.values()[i];
			if (responseCode.code.equals(code)) {
				return responseCode;
			}
		}
		return null;
	}

	public String getCode () {
		return code;
	}

	public void setCode (String code) {
		this.code = code;
	}

	public String getDesc () {
		return desc;
	}

	public void setDesc (String desc) {
		this.desc = desc;
	}
}
