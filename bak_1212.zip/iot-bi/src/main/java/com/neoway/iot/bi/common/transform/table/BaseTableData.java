package com.neoway.iot.bi.common.transform.table;

import com.neoway.iot.bi.common.transform.BaseData;

public class BaseTableData extends BaseData {

	private TableData data;

	public TableData getData () {
		return data;
	}

	public void setData (TableData data) {
		this.data = data;
	}
}
