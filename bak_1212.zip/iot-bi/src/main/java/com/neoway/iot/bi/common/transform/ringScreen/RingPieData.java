package com.neoway.iot.bi.common.transform.ringScreen;


public class RingPieData {

    private String name;

    private String rate;

    public String getName () {
        return name;
    }

    public void setName (String name) {
        this.name = name;
    }

    public void setRate(String rate){
        this.rate = rate;
    }

    public String getRate(){
        return rate;
    }
}
