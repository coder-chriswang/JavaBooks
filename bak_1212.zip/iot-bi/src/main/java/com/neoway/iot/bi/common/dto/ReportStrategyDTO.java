package com.neoway.iot.bi.common.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <pre>
 *  描述: 周期报表统计策略实体列表
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/6 11:13
 */
@Data
@ApiModel("周期报表统计策略实体列表")
public class ReportStrategyDTO {

    @ApiModelProperty(value = "策略id")
    private String id;

    @ApiModelProperty(value = "视图ID")
    private String viewId;

    @ApiModelProperty(value = "视图名称")
    private String name;

    @ApiModelProperty(value = "视图描述")
    private String desc;

    @ApiModelProperty(value = "图表")
    private String chart;

    @ApiModelProperty(value = "周期策略")
    private String policy;

    @ApiModelProperty(value = "通知方式")
    private String notifyType;

    @ApiModelProperty(value = "通知组")
    private String notifyGroup;

    @ApiModelProperty(value = "通知组编码")
    private String notifyGroupCode;
}
