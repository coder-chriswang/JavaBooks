package com.neoway.iot.bi.common.vo.offlinestrategy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("删除离线统计策略实体")
public class DelOfflineStrategyVO {

	@ApiModelProperty(value = "指标")
	private String metric;

}
