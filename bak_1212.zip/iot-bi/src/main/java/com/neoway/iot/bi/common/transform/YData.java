package com.neoway.iot.bi.common.transform;

import java.util.Map;

public class YData {

	private Map<String, Object> map;

	public Map<String, Object> getMap () {
		return map;
	}

	public void setMap (Map<String, Object> map) {
		this.map = map;
	}
}
