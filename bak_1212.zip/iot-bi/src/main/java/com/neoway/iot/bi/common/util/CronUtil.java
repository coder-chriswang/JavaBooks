package com.neoway.iot.bi.common.util;

import cn.hutool.cron.pattern.CronPattern;
import cn.hutool.cron.pattern.CronPatternUtil;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

@Slf4j
public class CronUtil {
    private CronUtil () {
    }

    public static Date getCronToDate(String cron) {
        String dateFormat = "ss mm HH dd MM ? yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        Date date = null;
        try {
            date = sdf.parse(cron);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public static void main (String[] args) {
        System.out.println(LocalDateTime.now());
        CronPattern cronPattern = new CronPattern("* */10 * * * ?");
        System.out.println(CronPatternUtil.nextDateAfter(cronPattern, new Date(), true));
    }

}