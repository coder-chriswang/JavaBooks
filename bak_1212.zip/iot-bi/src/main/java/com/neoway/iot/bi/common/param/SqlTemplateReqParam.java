package com.neoway.iot.bi.common.param;

import lombok.Data;

@Data
public class SqlTemplateReqParam {

	private String templateId;

	private String metric;

	private Long st;

	private Long et;
}
