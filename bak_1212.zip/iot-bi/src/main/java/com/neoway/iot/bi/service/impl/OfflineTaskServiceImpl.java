package com.neoway.iot.bi.service.impl;

import cn.hutool.json.JSONUtil;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;
import com.neoway.iot.bi.common.dto.GWRequest;
import com.neoway.iot.bi.common.dto.GWResponse;
import com.neoway.iot.bi.common.dto.OfflineTaskExecuteDTO;
import com.neoway.iot.bi.common.enums.ExtApiEnum;
import com.neoway.iot.bi.common.enums.OfflineStatTaskStatusEnum;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.dao.offlinestat.IOfflineTaskDao;
import com.neoway.iot.bi.common.domain.offlinestat.OfflineTask;
import com.neoway.iot.bi.service.IOfflineTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
public class OfflineTaskServiceImpl implements IOfflineTaskService {

	@Resource
	private IOfflineTaskDao offlineTaskDao;

	@Resource
	private RestTemplate restTemplate;

	@Value("${iot.service.gw.host}")
	private String gwHost;

	private Retryer<Boolean> retryer = RetryerBuilder.<Boolean>newBuilder()
			.retryIfException()
			.retryIfResult(aBoolean -> false)
			.withStopStrategy(StopStrategies.stopAfterAttempt(3))
			//失败后下次尝试之前的等待时间
			.withWaitStrategy(WaitStrategies.fixedWait(2, TimeUnit.SECONDS)).build();

	@Override
	public int add (OfflineTask offlineTask) {
		return offlineTaskDao.insert(offlineTask);
	}

	@Override
	public int update (OfflineTask offlineTask) {
		return offlineTaskDao.updateBySelective(offlineTask);
	}

	@Override
	public OfflineTask get (OfflineTask offlineTask) {
		return offlineTaskDao.selectOne(offlineTask);
	}

	@Override
	public Boolean executeCommandAsyn (GWRequest request) {
		HttpHeaders headers = new HttpHeaders();
		MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
		headers.setContentType(type);
		headers.add("Accept", MediaType.APPLICATION_JSON.toString());
		HttpEntity<String> formEntity = new HttpEntity<String>(JSONUtil.toJsonStr(request), headers);
		AtomicReference<Boolean> result = new AtomicReference<>(false);
		//设置超时
		SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		clientHttpRequestFactory.setConnectTimeout(2000);
		clientHttpRequestFactory.setReadTimeout(5 * 60 * 1000);
		restTemplate.setRequestFactory(clientHttpRequestFactory);
		try {
			retryer.call(() -> {
				ResponseEntity<GWResponse> entity = restTemplate.postForEntity(gwHost + ExtApiEnum.GW_Command_Asyn.getUrl()
						, formEntity, GWResponse.class);
				if (HttpStatus.OK.equals(entity.getStatusCode())) {
					String code = entity.getBody().getCode();
					if ("0".equals(code)) {
						//false则无需重试
						result.set(true);
						return result.get();
					} else {
						return result.get();
					}
				} else {
					return result.get();
				}
			});
		} catch (Exception ex) {
			log.error("GW Restful API:{} exception, request json: {}", ex.getMessage(), JSONUtil.toJsonStr(request));
			return false;
		}
		return result.get();
	}

	@Override
	public OfflineTask getLastOne (OfflineTask offlineTask) {
		OfflineTask offlineTask1 = offlineTaskDao.selectLastOne(offlineTask);
		return offlineTask1;
	}

	@Override
	public List<OfflineTask> list (OfflineTask offlineTask) {
		List<OfflineTask> offlineTaskList = offlineTaskDao.selectList(offlineTask);
		return offlineTaskList;
	}

	@Override
	public List<OfflineTaskExecuteDTO> getTimeUpTaskList (OfflineTask offlineTask) {
		List<OfflineTaskExecuteDTO> offlineTaskList = offlineTaskDao.selectTimeUpTaskList(offlineTask);
		return offlineTaskList;
	}

	@Override
	public int del30DayBeforeData (Del30DayBeforeData del30DayBeforeData) {
		return offlineTaskDao.del30DayBeforeDay(del30DayBeforeData);
	}

	@Override
	public int offlineTaskTransfer (Long nid, Long newNid) {
		OfflineTask offlineTask = new OfflineTask();
		offlineTask.setNodeid(nid);
		//是否考虑Running状态？
		offlineTask.setStatus(OfflineStatTaskStatusEnum.RUNNABLE.getCode());
		List<OfflineTask> offlineTaskList = offlineTaskDao.selectList(offlineTask);
		if (offlineTaskList.size() > 0) {
			offlineTaskList.forEach(offlineTask1 -> {
				offlineTask1.setNodeid(newNid);
				offlineTaskDao.updateBySelective(offlineTask1);
			});
		}
		return 0;
	}
}
