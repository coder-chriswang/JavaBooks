package com.neoway.iot.bi.common.transform.liquidfill;

import com.neoway.iot.bi.common.transform.BaseData;

import java.util.List;

public class BaseLiquidFillData extends BaseData {

	private Integer total;

	private List<String> names;

	private Series series;

	public Integer getTotal () {
		return total;
	}

	public void setTotal (Integer total) {
		this.total = total;
	}

	public List<String> getNames () {
		return names;
	}

	public void setNames (List<String> names) {
		this.names = names;
	}

	public Series getSeries () {
		return series;
	}

	public void setSeries (Series series) {
		this.series = series;
	}
}
