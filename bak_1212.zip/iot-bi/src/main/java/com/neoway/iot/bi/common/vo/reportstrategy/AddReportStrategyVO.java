package com.neoway.iot.bi.common.vo.reportstrategy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import javax.validation.constraints.NotNull;

/**
 * <pre>
 *  描述: 添加周期报表统计策略实体
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/7 15:49
 */
@Data
@ApiModel("添加周期报表统计策略实体")
public class AddReportStrategyVO {

    @ApiModelProperty(value = "视图id")
    @NotNull(message = "ies.bi.report.msg.param.idBlankError")
    private String viewId;

    @ApiModelProperty(value = "周期策略")
    @NotNull(message = "ies.bi.report.msg.param.policydBlankError")
    private String policy;

    @ApiModelProperty(value = "通知方式")
    @NotNull(message = "ies.bi.report.msg.param.notifyTypeBlankError")
    private String notifyType;

    @ApiModelProperty(value = "通知组")
    @NotNull(message = "ies.bi.report.msg.param.notifyGroupBlankError")
    private String notifyGroup;

    @ApiModelProperty(value = "通知组编码")
    @NotNull(message = "ies.bi.report.msg.param.notifyGroupCodeBlankError")
    private String notifyGroupCode;

}
