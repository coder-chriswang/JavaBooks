package com.neoway.iot.bi.common.transform.line;

import com.neoway.iot.bi.common.transform.BaseData;
import com.neoway.iot.bi.common.transform.bar.BarData;

public class BaseLineData extends BaseData {

	private LineData data;

	public LineData getData () {
		return data;
	}

	public void setData (LineData data) {
		this.data = data;
	}
}
