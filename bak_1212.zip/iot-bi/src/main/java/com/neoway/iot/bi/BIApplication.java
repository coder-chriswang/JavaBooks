package com.neoway.iot.bi;

import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.service.impl.EmailServerImpl;
import com.neoway.iot.bi.task.TimerTaskService;
import com.neoway.iot.sdk.mnk.DMI18nInitiator;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import javax.annotation.Resource;

@MapperScan("com.neoway.iot.bi.dao")
@SpringBootApplication(scanBasePackages = {"com.neoway.iot"})
public class BIApplication implements CommandLineRunner {

	@Autowired
	private Environment env;

	@Resource
	private INodeService nodeService;

	@Resource
	private TimerTaskService timerTaskService;

	@Resource
	private EmailServerImpl emailServer;

	public static void main(String[] args) {
		//防止附件名切割
		System.setProperty("mail.mime.splitlongparameters", "false");
		SpringApplication.run(BIApplication.class, args);
	}

	@Override
	public void run(String... strings) {
		//自动注册节点
		nodeService.add();
		//开启定时任务
		timerTaskService.startTimerTask();
		//加载邮件服务器
		emailServer.getEmailServerProp();
		//国际化词条加载
		DMI18nInitiator.getInstance().start(env);
	}

}
