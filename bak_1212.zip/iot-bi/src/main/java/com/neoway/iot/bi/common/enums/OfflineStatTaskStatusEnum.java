package com.neoway.iot.bi.common.enums;

/**
 * 离线统计任务状态
 */
public enum OfflineStatTaskStatusEnum {

    RUNNABLE("Runnable", "待执行"),

    RUNNING("Running", "执行中"),

    SUCCESS("Success", "执行成功"),

    FAIL("Fail", "执行失败"),

    ;

    public String code;
    public String description;

    OfflineStatTaskStatusEnum (String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode () {
        return code;
    }

    public String getDescription () {
        return description;
    }

    public static OfflineStatTaskStatusEnum getEnumByCode(String code) {
        if (null == code || "".equals(code)) {
            return null;
        }

        OfflineStatTaskStatusEnum responseCode;

        for (int i = 0; i < OfflineStatTaskStatusEnum.values().length; i++) {
            responseCode = OfflineStatTaskStatusEnum.values()[i];
            if (responseCode.code.equals(code)) {
                return responseCode;
            }
        }
        return null;
    }

    public static boolean contains(String code) {
        OfflineStatTaskStatusEnum aggType = OfflineStatTaskStatusEnum.getEnumByCode(code);
        if (aggType == null) {
            return false;
        } else {
            return true;
        }
    }
}
