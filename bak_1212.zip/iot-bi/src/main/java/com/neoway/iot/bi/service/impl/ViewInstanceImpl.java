package com.neoway.iot.bi.service.impl;

import com.neoway.iot.bi.common.domain.view.ViewInstance;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.dao.view.IViewInstanceDao;
import com.neoway.iot.bi.service.IViewInstanceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


@Service
@Slf4j
public class ViewInstanceImpl implements IViewInstanceService {

	@Resource
	private IViewInstanceDao viewInstanceDao;

	@Override
	public int add (ViewInstance viewInstance) {
		return viewInstanceDao.insert(viewInstance);
	}

	@Override
	public List<ViewInstance> getList (ViewInstance viewInstance) {
		return null;
	}

	@Override
	public ViewInstance get (ViewInstance viewInstance) {
		return viewInstanceDao.selectOne(viewInstance);
	}

	@Override
	public int del30DayBeforeData (Del30DayBeforeData del30DayBeforeData) {
		int result = viewInstanceDao.del30DayBeforeData(del30DayBeforeData);
		return result;
	}
}
