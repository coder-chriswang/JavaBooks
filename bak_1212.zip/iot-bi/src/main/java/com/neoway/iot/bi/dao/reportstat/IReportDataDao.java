package com.neoway.iot.bi.dao.reportstat;

import com.neoway.iot.bi.common.domain.reportstat.ReportData;

import java.util.List;

import com.neoway.iot.bi.common.domain.reportstat.ReportData;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IReportDataDao {

	List<ReportData> selectList(ReportData reportData);

    /**
     * 添加周期报表统计数据
     * @param list
     * @return
     */
    int batchAddReportData(@Param("list") List<ReportData> list);

	/**
	 * 删除大于30天的任务数据
	 * @param del30DayBeforeData
	 * @return
	 */
	int del30DayBeforeDay(Del30DayBeforeData del30DayBeforeData);
}
