package com.neoway.iot.bi.client;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.neoway.iot.bi.common.exception.ApiClientException;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.Map;

@Component
public class IotManagerApiClient {
//    @Value("${iot.service.mgr.host}")
    private String apiHost;

    @Resource
    private RestTemplate restTemplate;

    public Map<String, String> requestI18nApi(String languageTag) throws ApiClientException {
        String url = apiHost + "/v1/i18n?enable=b";
        HttpHeaders headers = new HttpHeaders();
        headers.add("language", languageTag);
        HttpEntity<String> requestEntity = new HttpEntity<>(null, headers);
        ResponseEntity<String> resEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
        if (resEntity == null || resEntity.getStatusCode() != HttpStatus.OK) {
            throw new ApiClientException("请求错误", resEntity.getStatusCode().value());
        }
        // e.g
        // {"code":"200","message":"success","data":{"iotbi":{"biChart":"图表","biView":"视图"},"iotsystem":{"dgm":"数据网关"}}}
        Gson gson = new Gson();
        Map<String, Object> resMap = gson.fromJson(resEntity.getBody(), Map.class);
        if (!resMap.get("code").equals("200")) {
            throw new ApiClientException((String) resMap.get("message"), Integer.valueOf((String) resMap.get("code")));
        }
        LinkedTreeMap<String, Map<String, String>> linkedTreeMap = (LinkedTreeMap<String, Map<String, String>>) resMap.get("data");
        if (!linkedTreeMap.containsKey("iotbi")) {
            return null;
        }
        return linkedTreeMap.get("iotbi");
    }
}
