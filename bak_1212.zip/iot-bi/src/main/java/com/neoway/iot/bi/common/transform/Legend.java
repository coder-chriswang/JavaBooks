package com.neoway.iot.bi.common.transform;

import java.util.List;

public class Legend {

	private List<String> nameArr;

	private List<String> keyArr;

	public List<String> getNameArr () {
		return nameArr;
	}

	public void setNameArr (List<String> nameArr) {
		this.nameArr = nameArr;
	}

	public List<String> getKeyArr () {
		return keyArr;
	}

	public void setKeyArr (List<String> keyArr) {
		this.keyArr = keyArr;
	}
}
