package com.neoway.iot.bi.api;

import com.neoway.iot.bi.HttpResult;
import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.domain.view.View;
import com.neoway.iot.bi.common.param.QueryChartListParam;
import com.neoway.iot.bi.common.util.BiPageModel;
import com.neoway.iot.bi.common.vo.view.AddViewVO;
import com.neoway.iot.bi.common.vo.view.EditViewVO;
import com.neoway.iot.bi.service.IViewService;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * <pre>
 *  描述: 视图配置接口
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/17 20:29
 */
@RestController
@RequestMapping("/v1/viewConfig/")
@Api(tags = "视图配置接口", description = "视图配置接口")
@Slf4j
public class ViewConfigController {
    @Resource
    private IViewService viewService;

    @ApiOperation(value = "新增视图配置")
    @PostMapping("addView")
    public HttpResult addView(@RequestBody @Valid AddViewVO addViewVO){
        try {
            int result = viewService.addView(addViewVO);
            return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.insertSuccess"),result);
        }catch (Exception e){
            log.error("新增视图配置失败！", e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.insertFail"),e.getMessage());
        }
    }

    @ApiOperation(value = "删除视图配置")
    @DeleteMapping("{viewId}")
    public HttpResult delView(@PathVariable("viewId") String viewId){
        try {
            int result = viewService.del(viewId);
            return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.delSuccess"),result);
        }catch (Exception e){
            log.error("删除视图配置失败！",e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.delFail"),e.getMessage());
        }
    }

    @ApiOperation(value = "编辑视图配置")
    @PostMapping("update")
    public HttpResult updateView(@RequestBody @Valid EditViewVO editViewVO){
        try {
            int result = viewService.edit(editViewVO);
            return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.updateSuccess"),result);
        }catch (Exception e){
            log.error("编辑视图配置失败！",e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.updateFail"),e.getMessage());
        }
    }

    @ApiOperation("视图chart列表查询")
    @PostMapping("queryViewChartList")
    public HttpResult<BiPageModel<Chart>> queryCharts(@RequestBody QueryChartListParam param) {
        try{
            BiPageModel<Chart> chart = viewService.queryViewChartList(param);
            return HttpResult.returnSuccess(chart);
        }catch (Exception e){
            log.error(e.getMessage(),e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.queryFail") + e.getMessage());
        }
    }

    @ApiOperation(value = "查询报表类型")
    @GetMapping("queryView")
    public HttpResult queryView(){
        try {
            List<View> viewList = viewService.queryView();
            return HttpResult.returnSuccess(viewList);
        } catch (Exception e){
            log.error(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.queryFail"), e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.viewConfig.msg.api.queryFail"),e.getMessage());
        }
    }

}
