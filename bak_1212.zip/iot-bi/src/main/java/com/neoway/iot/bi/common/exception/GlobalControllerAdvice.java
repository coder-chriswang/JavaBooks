package com.neoway.iot.bi.common.exception;

import com.neoway.iot.bi.HttpResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理
 */
@Slf4j
@RestControllerAdvice
public class GlobalControllerAdvice {

    @ExceptionHandler(value = Exception.class)
    public HttpResult exceptionHandler(Exception ex) {
        log.info("异常：{}", ex.getMessage());
        return HttpResult.returnFail(ex.getMessage());
    }

    @ExceptionHandler(value = BiException.class)
    public HttpResult biExceptionHandler(BiException ex) {
        return HttpResult.returnFail(ex.getMessage());
    }

    /**
     * 拦截参数校验异常
     */
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public HttpResult validationExceptionHandler(MethodArgumentNotValidException ex) {
        return HttpResult.returnFail(ex.getBindingResult().getFieldError().getDefaultMessage());
    }

    /**
     * 参数类型转换异常
     */
    @ExceptionHandler(value = HttpMessageConversionException.class)
    public HttpResult parameterTypeExceptionHandler(HttpMessageConversionException ex) {
        return HttpResult.returnFail(ex.getCause().getLocalizedMessage());
    }


}
