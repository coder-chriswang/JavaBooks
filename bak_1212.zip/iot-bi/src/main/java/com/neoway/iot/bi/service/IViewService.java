package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.domain.view.View;
import com.neoway.iot.bi.common.exception.ChartServiceException;
import com.neoway.iot.bi.common.param.QueryChartListParam;
import com.neoway.iot.bi.common.util.BiPageModel;
import com.neoway.iot.bi.common.vo.view.AddViewVO;
import com.neoway.iot.bi.common.vo.view.EditViewVO;

import java.util.List;

/**
 * <pre>
 *  描述: 视图配置service接口
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/17 20:36
 */
public interface IViewService {

    /**
     * 新增视图配置
     * @param addViewVO
     * @return
     */
    int addView(AddViewVO addViewVO);

    /**
     * 查询报表类型
     * @return
     */
    List<View> queryView();

    /**
     * 删除视图配置
     * @param viewId
     * @return
     */
    int del(String viewId);

    /**
     * 编辑视图配置
     * @param editViewVO
     * @return
     */
    int edit(EditViewVO editViewVO);

    /**
     * 查询视图列表
     * @param param
     * @return
     */
    BiPageModel<Chart> queryViewChartList(QueryChartListParam param) throws ChartServiceException;
}
