package com.neoway.iot.bi.common.transform.bar;

import com.neoway.iot.bi.common.transform.Legend;

import java.util.List;
import java.util.Map;

public class BarData {

	private Legend legend;

	private String xUnit;

	private String yUnit;

	private List<String> xData;

	private Map<String, Object> yData;

	public Legend getLegend () {
		return legend;
	}

	public void setLegend (Legend legend) {
		this.legend = legend;
	}

	public String getxUnit () {
		return xUnit;
	}

	public void setxUnit (String xUnit) {
		this.xUnit = xUnit;
	}

	public String getyUnit () {
		return yUnit;
	}

	public void setyUnit (String yUnit) {
		this.yUnit = yUnit;
	}

	public List<String> getxData () {
		return xData;
	}

	public void setxData (List<String> xData) {
		this.xData = xData;
	}

	public Map<String, Object> getyData () {
		return yData;
	}

	public void setyData (Map<String, Object> yData) {
		this.yData = yData;
	}
}
