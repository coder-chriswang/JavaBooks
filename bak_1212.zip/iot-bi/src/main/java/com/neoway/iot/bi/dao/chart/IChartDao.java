package com.neoway.iot.bi.dao.chart;

import com.neoway.iot.bi.common.param.QueryChartListParam;
import com.neoway.iot.bi.common.domain.chart.Chart;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IChartDao {
    Chart queryByKey(@Param("chartid") String chartid);
    Integer insertSelective(@Param("chart") Chart chart);
    Integer updateSelective(@Param("chart") Chart chart);
    Integer deleteByKey(@Param("chartid") String chartid);

    List<Chart> queryList(@Param("param") QueryChartListParam param);
    Integer queryCount(@Param("param") QueryChartListParam param);

    /**
     * 通过id批量查询统计算法
     * @param chartIds
     * @return
     */
    List<Chart> batchQueryById(@Param("chartIds") String[] chartIds);

    /**
     * 根据viewId查询chart
     * @param viewId
     * @return
     */
    String getChartIdByViewId(@Param("viewId") String viewId);
}