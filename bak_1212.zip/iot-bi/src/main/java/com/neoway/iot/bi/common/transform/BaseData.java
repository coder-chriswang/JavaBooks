package com.neoway.iot.bi.common.transform;


public class BaseData {

	private String chartType;

	private String chartTitle;


	public String getChartType () {
		return chartType;
	}

	public void setChartType (String chartType) {
		this.chartType = chartType;
	}

	public String getChartTitle () {
		return chartTitle;
	}

	public void setChartTitle (String chartTitle) {
		this.chartTitle = chartTitle;
	}

}
