package com.neoway.iot.bi.config;

import com.neoway.iot.bi.task.TaskService;
import org.springframework.context.support.ApplicationObjectSupport;
import org.springframework.stereotype.Component;

@Component
public class SpringContextHolder extends ApplicationObjectSupport {

    public TaskService getTaskService(String beanName){
        return super.getApplicationContext().getBean(beanName , TaskService.class);
    }
}