package com.neoway.iot.bi.task.service;

import cn.hutool.core.date.DateUtil;
import com.google.common.cache.Cache;
import com.neoway.iot.bi.HttpResult;
import com.neoway.iot.bi.common.domain.reportstat.ReportStrategy;
import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.domain.view.ViewInstance;
import com.neoway.iot.bi.common.enums.ExtApiEnum;
import com.neoway.iot.bi.common.enums.NotifyTypeEnum;
import com.neoway.iot.bi.common.enums.ReportGenerateStatusEnum;
import com.neoway.iot.bi.common.enums.ReportNotifyStatusEnum;
import com.neoway.iot.bi.common.dto.NotifyUserDto;
import com.neoway.iot.bi.service.IMailService;
import com.neoway.iot.bi.service.IReportStrategyService;
import com.neoway.iot.bi.service.IReportTaskService;
import com.neoway.iot.bi.service.IViewInstanceService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Slf4j
@Service
public class ReportNotifyTask implements TaskService {

	@Resource
	private IReportTaskService reportTaskService;

	@Resource
	private IReportStrategyService reportStrategyService;

	@Resource
	private IMailService mailService;

	@Resource
	private IViewInstanceService viewInstanceService;

	@Resource
	private Cache guavaCache;

	@Resource
	private RestTemplate restTemplate;

	@Value("${iot.service.mng.host}")
	private String mngHost;

	@Override
	public boolean process () {
		//获取本节点、生成状态为成功、通知状态为待通知的任务信息
		Long nid = Long.valueOf(String.valueOf(guavaCache.getIfPresent("nid")));
		ReportTask reportTask = new ReportTask();
		reportTask.setNodeid(nid);
		reportTask.setGstatus(ReportGenerateStatusEnum.FINISH.getCode());
		reportTask.setSstatus(ReportNotifyStatusEnum.WAITTING.getCode());
		List<ReportTask> reportTaskList = reportTaskService.getReportTaskList(reportTask);
		if (reportTaskList == null || reportTaskList.size() == 0) {
			return true;
		}
		AtomicReference<ReportStrategy> reportStrategy = new AtomicReference<>();
		AtomicReference<ViewInstance> viewInstance = new AtomicReference<>();
		reportTaskList.forEach(reportTask1 -> {
			//获取strategy_id获取通知组下的用户信息（需调用mng服务）
			reportStrategy.set(new ReportStrategy());
			reportStrategy.get().setId(reportTask1.getStrategyId());
			ReportStrategy reportStrategy1 = reportStrategyService.getOne(reportStrategy.get());
			if (reportStrategy1 == null) {
				log.info("找不到策略id为{}的信息", reportTask1.getStrategyId());
				reportTaskService.del(reportTask1.getId());
				return;
			}
			//根据taskid获取二进制数据表数据s
			viewInstance.set(new ViewInstance());
			viewInstance.get().setTaskId(reportTask1.getId());
			ViewInstance viewInstance1 = viewInstanceService.get(viewInstance.get());
			if (viewInstance1 == null) {
				log.error("找不到任务id为{}的二进制数据信息", reportTask1.getId());
				return;
			}
			//修改任务通知状态为通知中
			reportTask1.setSstatus(ReportNotifyStatusEnum.RUNNING.getCode());
			reportTask1.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
			reportTaskService.update(reportTask1);
			//调用email service发送邮件
			Long costSt = System.currentTimeMillis();
			Boolean handlerResult = handlerPushMessage(reportStrategy1.getNotifyType(), reportStrategy1.getNotifyGroupCode(), viewInstance1);
			Long cost = System.currentTimeMillis() - costSt;
			//修改任务通知状态为通知成功或失败，记录耗时
			if (handlerResult) {
				reportTask1.setSstatus(ReportNotifyStatusEnum.FINISH.getCode());
			} else {
				reportTask1.setSstatus(ReportNotifyStatusEnum.FAIL.getCode());
			}
			reportTask1.setScost(Integer.valueOf(String.valueOf(cost)));
			reportTask1.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
			reportTaskService.update(reportTask1);
			log.info("任务id为{}{}", reportTask1.getId(), ReportNotifyStatusEnum.getEnumByCode(reportTask1.getSstatus()).getDesc());
		});
		return true;
	}

	/**
	 * 处理消息推送逻辑方法
	 * @return
	 */
	private Boolean handlerPushMessage(String notifyType, String notifyGroup, ViewInstance viewInstance) {
		Boolean result = false;
		switch (NotifyTypeEnum.getEnumByCode(notifyType)) {
			case EMAIL:
				result = pushMsgByEmail(notifyGroup, viewInstance);
				break;
			default:
				break;
		}
		return result;
	}

	/**
	 * email方式发送消息
	 * @param notifyGroup
	 * @param viewInstance
	 * @return
	 */
	private Boolean pushMsgByEmail (String notifyGroup, ViewInstance viewInstance) {
		//通过通知组code调用mng服务获取用户信息
		List<NotifyUserDto> notifyUserDtoList = getNotifyUsers(notifyGroup);
		if (notifyUserDtoList == null || notifyUserDtoList.size() == 0) {
			log.error("通知组code为{}找不到所属用户", notifyGroup);
			return false;
		}
		InputStreamSource inputStreamSource = new ByteArrayResource(viewInstance.getData());
		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String date = df.format(DateUtil.toLocalDateTime(Instant.ofEpochSecond(viewInstance.getLt())));
		String subject = "物联感知平台-" + viewInstance.getName() + "-" + date;
		String content = "(●'◡'●)";
		notifyUserDtoList.forEach(notifyUserDto -> {
			try {
				mailService.sendAttachmentsMailFromSource(notifyUserDto.getEmail(), subject, content, inputStreamSource);
			} catch (Exception ex) {
				log.error("发送邮件失败，邮箱为{},subject为{}, 错误消息为{}", notifyUserDto.getEmail(), subject,
						ex.getMessage());
				return;
			}

		});
		return true;
	}

	/**
	 * 调用mng服务
	 * @param notifyGroup
	 * @return
	 */
	private List<NotifyUserDto> getNotifyUsers(String notifyGroup) {
		ResponseEntity<HttpResult<List<NotifyUserDto>>> entity = null;
		String url = mngHost + ExtApiEnum.MNG_GET_NOTIFY_USER.getUrl() + "?code=" + notifyGroup;
		try {
			entity = restTemplate.exchange(url, HttpMethod.GET, null,
					new ParameterizedTypeReference<HttpResult<List<NotifyUserDto>>>() {});
		} catch (Exception ex) {
			log.error("调用接口{}失败:{}", url, ex.getMessage());
		}
		List<NotifyUserDto> list = new ArrayList<>();
		if (!HttpStatus.OK.equals(entity.getStatusCode()) || HttpStatus.OK.value() != entity.getBody().getCode()) {
			log.error("调用接口{}失败，http状态码={}, code={}", url, entity.getStatusCode(), entity.getBody().getCode());
			return list;
		}
		list = entity.getBody().getData();
		return list;
	}
}
