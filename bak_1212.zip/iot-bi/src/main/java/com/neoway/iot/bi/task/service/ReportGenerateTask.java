package com.neoway.iot.bi.task.service;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.net.NetUtil;
import cn.hutool.json.JSONUtil;
import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.domain.reportstat.ReportData;
import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.domain.view.ViewInstance;
import com.neoway.iot.bi.common.enums.ReportGenerateStatusEnum;
import com.neoway.iot.bi.common.enums.ReportStatStatusEnum;
import com.neoway.iot.bi.common.transform.BaseData;
import com.neoway.iot.bi.common.transform.ChartData;
import com.neoway.iot.bi.common.transform.Legend;
import com.neoway.iot.bi.common.transform.bar.BaseBarData;
import com.neoway.iot.bi.common.transform.gauge.BaseGaugeData;
import com.neoway.iot.bi.common.transform.line.BaseLineData;
import com.neoway.iot.bi.common.transform.liquidfill.BaseLiquidFillData;
import com.neoway.iot.bi.common.transform.pie.BasePieData;
import com.neoway.iot.bi.common.transform.ringScreen.BaseRingScreeData;
import com.neoway.iot.bi.common.transform.table.BaseTableData;
import com.neoway.iot.bi.common.util.CommonUtil;
import com.neoway.iot.bi.service.IReportDataService;
import com.neoway.iot.bi.service.IReportTaskService;
import com.neoway.iot.bi.service.IViewInstanceService;
import com.neoway.iot.bi.task.TaskService;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
public class ReportGenerateTask implements TaskService {

	@Resource
	private IReportTaskService reportTaskService;

	@Resource
	private IReportDataService reportDataService;

	@Resource
	private IViewInstanceService viewInstanceService;

	@Resource
	private Cache guavaCache;

	@Value("${path.demo.template}")
	private String demoPath;

	@Override
	public boolean process () {
		//查找本节点、统计状态为成功、生成状态为待生成的报表任务信息
		ReportTask reportTask = new ReportTask();
		Long nid = Long.valueOf(String.valueOf(guavaCache.getIfPresent("nid")));
		reportTask.setNodeid(nid);
		reportTask.setDstatus(ReportStatStatusEnum.FINISH.getCode());
		reportTask.setGstatus(ReportGenerateStatusEnum.WAITTING.getCode());
		List<ReportTask> reportTaskList = reportTaskService.getReportTaskList(reportTask);
		if (reportTaskList == null || reportTaskList.size() == 0) {
			return true;
		}
		//修改生成状态为生成中
		Integer lt = Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"))));
		Integer finalLt = lt;
		reportTaskList.forEach(reportTask1 -> {
			try {
				reportTask1.setGstatus(ReportGenerateStatusEnum.RUNNING.getCode());
				reportTask1.setLt(finalLt);
				reportTaskService.update(reportTask1);
			} catch (Exception ex) {
				log.error("更新离线统计任务失败，ex:{}", ex.getMessage());
				return;
			}
		});
		//根据taskid、viewid获取报表数据表的数据
		AtomicReference<ReportData> reportData = new AtomicReference<>();
		AtomicReference<ViewInstance> viewInstance = new AtomicReference<>();
		reportTaskList.forEach(reportTask1 -> {
			reportData.set(new ReportData());
			reportData.get().setTaskId(reportTask1.getId());
			List<ReportData> reportDataList = reportDataService.getReportDataList(reportData.get());
			if (reportDataList == null || reportDataList.size() == 0) {
				return;
			}
			Long costSt = System.currentTimeMillis();
			//生成html文件数据流
			byte[] bytes = null;
			try {
				bytes = generateHtmlStream(reportTask1.getViewName(), reportDataList);
			} catch (Exception e) {
				log.error("生成html模板数据流失败,ex:{}", e.getMessage());
				return;
			}
			Long gcost = System.currentTimeMillis() - costSt;
			//保存至二进制视图数据表
			viewInstance.set(new ViewInstance());
			viewInstance.get().setTaskId(reportTask1.getId());
			viewInstance.get().setViewid(reportTask1.getViewid());
			viewInstance.get().setName(reportTask1.getViewName());
			viewInstance.get().setType("html");
			viewInstance.get().setData(bytes);
			viewInstance.get().setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
			viewInstanceService.add(viewInstance.get());
			//更新任务状态和耗时
			reportTask1.setGstatus(ReportGenerateStatusEnum.FINISH.getCode());
			reportTask1.setGcost(Integer.valueOf(String.valueOf(gcost)));
			reportTask1.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
			reportTaskService.update(reportTask1);
		});
		return true;
	}

	private byte[] generateHtmlStream (String viewName, List<ReportData> reportDataList) throws IOException {
		Configuration configuration = new Configuration(Configuration.VERSION_2_3_29);
		configuration.setDirectoryForTemplateLoading(new File(demoPath));
		configuration.setDefaultEncoding("utf-8");
		Template template = configuration.getTemplate("demo.html",null,null,null,true,true);
		Map dataModel = new HashMap();
		dataModel.put("title", "物联感知平台-" + viewName);
		String ip = NetUtil.getLocalhostStr();
		if (ip.startsWith("192.168")) {
			dataModel.put("host", "192.168.69.14");
		} else {
			dataModel.put("host", NetUtil.getLocalhostStr());
		}
		List<ChartData> chartDataList = new ArrayList<>();
		AtomicReference<ChartData> chartData = new AtomicReference<>();
		reportDataList.forEach(reportData -> {
			chartData.set(new ChartData());
			//调用相应chart图生成方法转换为option
			try {
				chartData.get().setData(transformOption(reportData.getChartData().toString()));
				chartDataList.add(chartData.get());
			} catch (Exception ex) {
				log.error("chart图标json转换失败,ex:{}", ex.getMessage());
				return;
			}
		});
		dataModel.put("chartList", chartDataList);
		StringWriter out = new StringWriter();
		byte[] bytes = null;
		try {
			template.process(dataModel, out);
			bytes = out.toString().getBytes();
		} catch (TemplateException ex) {
			log.error("freemarker模板赋值错误:{}", ex.getMessage());
		} finally {
			out.close();
		}
		return bytes;
	}

	public static String transformOption(String chartDataStr) {
//		chartDataStr = "{\"chartType\":\"table\",\"chartTitle\":\"表格\",\"data\":{\"tableHeader\":[{\"name\":\"区域\",\"id\":\"header1\"},{\"name\":\"数量\",\"id\":\"header2\"}],\"tableData\":{\"total\":10,\"pageSize\":10,\"pageNum\":1,\"rows\":[{\"header1\":\"西安\",\"header2\":\"55\"},{\"header1\":\"深圳\",\"header2\":\"20\"}]}}}";
		BaseData baseData = JSONUtil.toBean(chartDataStr, BaseData.class);
		String json = null;
		switch (baseData.getChartType()) {
			case "bar" :
				json = parseBar(chartDataStr);
				break;
			case "line":
				json = parseLine(chartDataStr);
				break;
			case "gauge":
				json = parseGauge(chartDataStr);
				break;
			case "pie":
				json = parsePie(chartDataStr);
				break;
			case "table":
				json = parseTable(chartDataStr);
				break;
			case "liquidFill":
				json = parseLiquidFill(chartDataStr);
				break;
			case "ringScreen":
				json = parseRingScreen(chartDataStr);
			default:
				break;
		}
		return json;
	}

	private static String parseLiquidFill (String chartDataStr) {
		String json = null;
		BaseLiquidFillData baseLiquidFillData = JSONUtil.toBean(chartDataStr, BaseLiquidFillData.class);
		List<List<String>> chartColor = new ArrayList<>();
		List<String> color = new ArrayList<>();
		List<String> color1 = new ArrayList<>();
		List<String> color2 = new ArrayList<>();
		color.add("'#4ecd66'");color.add("'#3a9654'");
		chartColor.add(color);
		color1.add("'#602d2d'");color1.add("'#81332d'");
		chartColor.add(color1);
		color2.add("'#4f5963'");color2.add("'#73797f'");
		chartColor.add(color2);
		StringBuffer seriesStr = new StringBuffer("[");
		List<String> percentList = baseLiquidFillData.getSeries().getPercent();
		if (CollectionUtil.isNotEmpty(percentList)) {
			for (int i = 0, len = percentList.size(); i < len; i++) {
				Double data  = Double.valueOf(percentList.get(i).replace("%", ""));
				data = CommonUtil.division(data, BigDecimal.valueOf(100).doubleValue(), 2);
				String seriesArrStr = "{type:'liquidFill',color:[" + chartColor.get(i).get(0) +"],radius:'50%'," +
						"center:[20 + 30 * " + i +" + '%', '50%'],data:['"+ data +"'],backgroundStyle:{" +
						"color:'transparent'},label:{normal:{color:'white',fontSize:13,formatter:'" + percentList.get(i)+ "'" +
						"}},outline:{itemStyle:{borderWidth:2,borderColor:" + chartColor.get(i).get(0)+ "}},amplitude:'4%',waveAnimation:true}";
				seriesStr.append(seriesArrStr);
				if (i < len - 1) {
					seriesStr.append(",");
				}
			}

		}
		seriesStr.append("]");
		StringBuffer titleStr = new StringBuffer("[");
		String title = "{text:'设备总数: " + baseLiquidFillData.getTotal() + "',left:'50%',top:'2%',textAlign:'center',textStyle:{fonWeight:'normal',fontSize:'28',color:'#ffffff',textAlign:'center',rich:{percent:{fonstSize:'16',color:'#3a9654'}}}},";
		titleStr.append(title);
		List<String> nameList = baseLiquidFillData.getNames();
		if (CollectionUtil.isNotEmpty(nameList)) {
			for (int i = 0, len = nameList.size(); i < len; i++) {
				String titleArrStr = "{text:'" + nameList.get(i)+ ":" + percentList.get(i)+ "'," +
						"left:(" + i + " + 1) * 33 -16 + '%',top:'80%',textAlign:'center',textStyle:{fonWeight:'normal'," +
						"fontSize:'16',color:'#7fa4bb',textAlign:'center',rich:{percent:{fonstSize:'16',color:" + chartColor.get(i).get(1)+"}}}}";
				titleStr.append(titleArrStr);
				if (i < len - 1) {
					titleStr.append(",");
				}
			}
		}
		titleStr.append("]");
		json = "{title:" + titleStr.toString() + ",series:" + seriesStr.toString() +"}";
		return json;
	}

	private static String parseRingScreen(String chartDataStr) {
		String json = null;
		BaseRingScreeData baseRingScreeData = JSONUtil.toBean(chartDataStr, BaseRingScreeData.class);
		StringBuffer legendDataStr = new StringBuffer("[");
		for (int i = 0, len = baseRingScreeData.getData().getLegend().size(); i < len; i++) {
			legendDataStr.append("'" + baseRingScreeData.getData().getLegend().get(i) + "'");
			if (i < len - 1) {
				legendDataStr.append(",");
			}
		}
		legendDataStr.append("]");
		StringBuffer seriesDataStr = new StringBuffer("[");
		for (int i = 0, len = baseRingScreeData.getData().getSeries().getPieData().size(); i < len; i++) {
			seriesDataStr.append("{");
			seriesDataStr.append("rate:" + baseRingScreeData.getData().getSeries().getPieData().get(i).getRate());
			seriesDataStr.append(",");
			seriesDataStr.append("name:'" + baseRingScreeData.getData().getSeries().getPieData().get(i).getName() + "'");
			seriesDataStr.append("}");
			if (i < len - 1) {
				seriesDataStr.append(",");
			}
		}
		seriesDataStr.append("]");
		json = "{title:{text:'" + baseRingScreeData.getChartTitle() +"',left:'center',textStyle:{color:'#FFFFFF'}},tooltip:{trigger:'item',formatter:'{a} <br/>{b} : {c} ({d}%)'},toolbox:{show:true,feature:{mark:{show:true},dataView:{show:true,readOnly:false},restore:{show:true},saveAsImage:{show:true}},iconStyle:{borderColor:'rgba(255, 255, 255, 1)'}}," +
				"legend:{orient:'vertical',left:'left',data:" + legendDataStr +",textStyle:{color:'#FFFFFF'}}," +
				"series:[{name:'" + baseRingScreeData.getData().getSeries().getName() +"',type:'pie',radius:'55%',center:['50%','60%']," +
				"data:" + seriesDataStr + ",label:{color:\"rgba(255, 255, 255, 1)\"},emphasis:{itemStyle:{shadowBlur:10,shadowOffsetX:0,shadowColor:'rgba(0, 0, 0, 0.5)'}},}]}";
		return json;
	}

	private static String parseTable (String chartDataStr) {
		String json = null;
		BaseTableData baseTableData = JSONUtil.toBean(chartDataStr, BaseTableData.class);
		int headerLen = baseTableData.getData().getTableHeader().size();
		StringBuffer yAxisData = new StringBuffer();
		List<Map<String, Object>> rows = baseTableData.getData().getTableData().getRows();
		for (int i = 0, len = rows.size(); i < len; i++) {
			yAxisData.append("'" + rows.get(i).get(baseTableData.getData().getTableHeader().get(0).getId())+ "'");
			if (i < len - 1) {
				yAxisData.append(",");
			}
		}
		StringBuffer valueStr = new StringBuffer();
		for (int i = 0, len = rows.size(); i < len; i++) {
			valueStr.append(rows.get(i).get(baseTableData.getData().getTableHeader().get(headerLen - 1).getId()));
			if (i < len - 1) {
				valueStr.append(",");
			}
		}
		json = "{title:{text:'" + baseTableData.getChartTitle() +"',left:'center',top:'2%',textStyle:{color:'#FFFFFF'}},toolbox:{show:true,feature:{dataView:{show:true,readOnly:false},restore:{show:true},saveAsImage:{show:true}},iconStyle:{borderColor:'rgba(255, 255, 255, 1)'}},tooltip:{trigger:'axis',axisPointer:{type:'shadow'}},grid:{left:'3%',right:'4%',bottom:'3%',top:'18%',containLabel:true}," +
				"legend:{data:['" + baseTableData.getData().getTableHeader().get(headerLen - 1).getName() +"'],top:'10%',textStyle:{color:'#FFFFFF'}},xAxis:{type:'value',axisLabel:{textStyle:{color:'#FFFFFF'}}}," +
				"yAxis:{type:'category',data:[" + yAxisData +"],axisLabel:{textStyle:{color:'#FFFFFF'}}}," +
				"series:[{name:'" + baseTableData.getData().getTableHeader().get(headerLen - 1).getName() +"',type:'bar',stack:'总量',label:{show:true,position:'insideRight'}," +
				"data:[" + valueStr +"],color:'#00BFFF'}]}";
		return json;
	}

	private static String parsePie (String chartDataStr) {
		String json = null;
		BasePieData basePieData = JSONUtil.toBean(chartDataStr, BasePieData.class);
		StringBuffer legendDataStr = new StringBuffer("[");
		for (int i = 0, len = basePieData.getData().getLegend().size(); i < len; i++) {
			legendDataStr.append("'" + basePieData.getData().getLegend().get(i) + "'");
			if (i < len - 1) {
				legendDataStr.append(",");
			}
		}
		legendDataStr.append("]");
		StringBuffer seriesDataStr = new StringBuffer("[");
		for (int i = 0, len = basePieData.getData().getSeries().getPieData().size(); i < len; i++) {
			seriesDataStr.append("{");
			seriesDataStr.append("value:" + basePieData.getData().getSeries().getPieData().get(i).getValue());
			seriesDataStr.append(",");
			seriesDataStr.append("name:'" + basePieData.getData().getSeries().getPieData().get(i).getName() + "'");
			seriesDataStr.append("}");
			if (i < len - 1) {
				seriesDataStr.append(",");
			}
		}
		seriesDataStr.append("]");
		json = "{title:{text:'" + basePieData.getChartTitle() +"',left:'center',textStyle:{color:'#FFFFFF'}},tooltip:{trigger:'item',formatter:'{a} <br/>{b} : {c} ({d}%)'},toolbox:{show:true,feature:{mark:{show:true},dataView:{show:true,readOnly:false},restore:{show:true},saveAsImage:{show:true}},iconStyle:{borderColor:'rgba(255, 255, 255, 1)'}}," +
				"legend:{orient:'vertical',left:'left',data:" + legendDataStr +",textStyle:{color:'#FFFFFF'}}," +
				"series:[{name:'" + basePieData.getData().getSeries().getName() +"',type:'pie',radius:'55%',center:['50%','60%']," +
				"data:" + seriesDataStr + ",label:{color:\"rgba(255, 255, 255, 1)\"},emphasis:{itemStyle:{shadowBlur:10,shadowOffsetX:0,shadowColor:'rgba(0, 0, 0, 0.5)'}},}]}";
		return json;
	}

	private static String parseGauge (String chartDataStr) {
		String json = null;
		BaseGaugeData baseGaugeData = JSONUtil.toBean(chartDataStr, BaseGaugeData.class);
		StringBuffer gauges = new StringBuffer();
		String gaugeStr = null;
		for (int i = 0, len = baseGaugeData.getData().size(); i < len; i++) {
			gaugeStr = "{name:'',type:'gauge',center:['50%','60%'],radius:'100%',startAngle:200,endAngle:-20,axisLine:{lineStyle:{color:[[1,'#008ACD']],width:2}},axisTick:{length:5},splitLine:{length:10,lineStyle:{color:'auto'}},pointer:{width:2,shadowColor:'#fff',shadowBlur:5},title:{show:false}" +
					",detail:{formatter:'{value}" + baseGaugeData.getData().get(i).getUnit() +"',color:'#008ACD',fontSize:20}" +
					",max:" + baseGaugeData.getData().get(i).getMax() +",splitNumber:" + baseGaugeData.getData().get(i).getSplitNumber() +"," +
					"data:[{value:" + baseGaugeData.getData().get(i).getValue() +",name:'" + baseGaugeData.getData().get(i).getName() +"'}]}";
			gauges.append(gaugeStr);
			if (i < len - 1) {
				gauges.append(",");
			}
		}
		json = "{title:{text:'" + baseGaugeData.getChartTitle() +"',left:'center',textStyle:{fontWeight:'normal',fontSize:16,color:'#FFFFFF'}},toolbox:{show:true,feature:{dataView:{show:true,readOnly:false},restore:{show:true},saveAsImage:{show:true}},iconStyle:{borderColor:'rgba(255, 255, 255, 1)'}},tooltip:{fontSize:24,formatter:'{a} <br/>{b} : {c}%',transitionDuration:0}" +
				",series:[" + gauges + "]}";
		return json;

	}

	private static String parseLine (String chartDataStr) {
		String json = null;
		BaseLineData baseLineData = JSONUtil.toBean(chartDataStr, BaseLineData.class);
		List<String> xData = baseLineData.getData().getxData();
		Legend legend = baseLineData.getData().getLegend();
		String nameArr = JSONUtil.parseObj(legend).getStr("nameArr");
		Map<String, Object> yData = baseLineData.getData().getyData();
		StringBuffer series = new StringBuffer();
		for (int i = 0, len = legend.getNameArr().size(); i < len; i++) {
			series.append("{");
			series.append("name:'" + legend.getNameArr().get(i) + "',");
			series.append("type: 'line',");
			series.append("data:" + yData.get(legend.getKeyArr().get(i)));
			series.append("}");
			if (i < len - 1) {
				series.append(",");
			}
		}
		StringBuffer xDataStr = new StringBuffer("[");
		for (int i = 0, len = xData.size(); i < len; i++) {
			xDataStr.append("'" + xData.get(i) + "'");
			if (i < len - 1) {
				xDataStr.append(",");
			}
		}
		xDataStr.append("]");
		json = "{title:{text:'" + baseLineData.getChartTitle() + "',left:'center',textStyle:{color:'#FFFFFF'}},animation:false,toolbox:{show:true,feature:{dataView:{show:true,readOnly:false},magicType:{show:true,type:['line','bar']},restore:{show:true},saveAsImage:{show:true}},iconStyle:{borderColor:'rgba(255, 255, 255, 1)'}},tooltip:{trigger:'axis',axisPointer:{type:'shadow'}}," +
				"legend:{data:" + nameArr + ",textStyle:{color:'#FFFFFF'},top:'10%'},grid:{left:'3%',right:'4%',bottom:'3%',top:'20%',containLabel:true}," +
				"xAxis:{type:'category',data:" + xDataStr +",boundaryGap:false,axisLabel:{textStyle:{color:'#FFFFFF'}}},yAxis:{type:'value',axisLabel:{textStyle:{color:'#FFFFFF'}}}," +
				"series:[" + series + "]}";
		return json;
	}

	/**
	 * 柱状图转换
	 * @param chartDataStr
	 * @return
	 */
	public static String parseBar(String chartDataStr) {
		String json = null;
		BaseBarData baseBarData = JSONUtil.toBean(chartDataStr, BaseBarData.class);
		List<String> xData = baseBarData.getData().getxData();
		Legend legend = baseBarData.getData().getLegend();
		String nameArr = JSONUtil.parseObj(legend).getStr("nameArr");
		Map<String, Object> yData = baseBarData.getData().getyData();
		StringBuffer series = new StringBuffer();
		for (int i = 0, len = legend.getNameArr().size(); i < len; i++) {
			series.append("{");
			series.append("name:'" + legend.getNameArr().get(i) + "',");
			series.append("type: 'bar',");
			series.append("data:" + yData.get(legend.getKeyArr().get(i)));
			series.append("}");
			if (i < len - 1) {
				series.append(",");
			}
		}
		StringBuffer xDataStr = new StringBuffer("[");
		for (int i = 0, len = xData.size(); i < len; i++) {
			xDataStr.append("'" + xData.get(i) + "'");
			if (i < len - 1) {
				xDataStr.append(",");
			}
		}
		xDataStr.append("]");
		json = "{title:{text:'" + baseBarData.getChartTitle() + "',left:'center',textStyle:{color:'#FFFFFF'}},toolbox:{show:true,feature:{dataView:{show:true,readOnly:false},magicType:{show:true,type:['line','bar']},restore:{show:true},saveAsImage:{show:true}},iconStyle:{borderColor:'rgba(255, 255, 255, 1)'}},tooltip:{trigger:'axis',axisPointer:{type:'shadow'}}," +
				"legend:{data:" + nameArr + ",textStyle:{color:'#FFFFFF'},top:'10%'},grid:{left:'3%',right:'4%',bottom:'3%',top:'20%',containLabel:true}," +
				"xAxis:[{type:'category',data:" + xDataStr +",axisLabel:{textStyle:{color:'#FFFFFF'}}}],yAxis:[{type:'value',axisLabel:{textStyle:{color:'#FFFFFF'}}}]," +
				"series:[" + series + "]}";
		return json;
	}

	public static void main (String[] args) {
		String str = "{\"total\":555,\"chartType\":\"liquidFill\",\"chartTitle\":\"设备总量\",\"chartSubTitle\":\"设备总数量\",\"names\":[\"在线率\", \"故障率\", \"离线率\"],\"series\":{" +
				"\"percent\":['2.19%','5.00%','97.81%']}}";
		transformOption(str);
		String s = transformOption("{\"chartType\":\"ringScreen\",\"chartTitle\":\"环形图\",\"data\":{\"legend\":[\"图例1\",\"图例2\",\"图例3\",\"图例4\"],\"series\":{\"pieData\":[{\"rate\":\"0.00%\",\"name\":\"图例1\"},{\"rate\":\"0.00%\",\"name\":\"图例2\"},{\"rate\":\"0.00%\",\"name\":\"图例3\"},{\"rate\":\"0.00%\",\"name\":\"图例4\"}],\"name\":\"环形图\"}}}");
		System.out.println(s);
	}
}
