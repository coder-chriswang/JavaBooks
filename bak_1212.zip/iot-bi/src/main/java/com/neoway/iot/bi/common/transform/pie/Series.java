package com.neoway.iot.bi.common.transform.pie;

import java.util.List;

public class Series {

	private String name;

	private List<PieDataData> pieData;

	public String getName () {
		return name;
	}

	public void setName (String name) {
		this.name = name;
	}

	public List<PieDataData> getPieData () {
		return pieData;
	}

	public void setPieData (List<PieDataData> pieData) {
		this.pieData = pieData;
	}
}
