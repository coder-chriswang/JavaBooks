package com.neoway.iot.bi.common.constants;

import com.neoway.iot.sdk.mnk.util.MessageUtils;

public interface ErrorConstant {

	String ADD_FAIL = MessageUtils.getMessage("ies.bi.strategy.msg.service.insertFail");

	String UPDATE_FAIL = MessageUtils.getMessage("ies.bi.strategy.msg.service.updateFail");

	String DEL_FAIL = MessageUtils.getMessage("ies.bi.strategy.msg.service.delFail");

	String QUERY_EMPTY = MessageUtils.getMessage("ies.bi.strategy.msg.service.queryEmpty");

	String DATA_EXIST_ALREADY = MessageUtils.getMessage("ies.bi.strategy.msg.service.exist");

	String OFFLINE_STRATEGY_METRIC_NOT_EXIST = MessageUtils.getMessage("ies.bi.strategy.msg.service.notExist");

}
