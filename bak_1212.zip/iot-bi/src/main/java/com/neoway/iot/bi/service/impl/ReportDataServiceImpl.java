package com.neoway.iot.bi.service.impl;

import com.neoway.iot.bi.common.domain.reportstat.ReportData;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.dao.reportstat.IReportDataDao;
import com.neoway.iot.bi.service.IReportDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
@Slf4j
public class ReportDataServiceImpl implements IReportDataService {

	@Resource
	private IReportDataDao reportDataDao;

	@Override
	public List<ReportData> getReportDataList (ReportData reportData) {
		List<ReportData> reportList = reportDataDao.selectList(reportData);
		return reportList;
	}

	@Override
	public int update (ReportData reportData) {
		return 0;
	}

	@Override
	public int del30DayBeforeData (Del30DayBeforeData del30DayBeforeData) {
		int result = reportDataDao.del30DayBeforeDay(del30DayBeforeData);
		return result;
	}
}
