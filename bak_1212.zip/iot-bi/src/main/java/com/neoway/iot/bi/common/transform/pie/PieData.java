package com.neoway.iot.bi.common.transform.pie;

import java.util.List;

public class PieData {

	private List<String> legend;

	private Series series;

	public List<String> getLegend () {
		return legend;
	}

	public void setLegend (List<String> legend) {
		this.legend = legend;
	}

	public Series getSeries () {
		return series;
	}

	public void setSeries (Series series) {
		this.series = series;
	}
}
