package com.neoway.iot.bi.dao.view;

import com.neoway.iot.bi.common.domain.chart.Chart;
import com.neoway.iot.bi.common.domain.view.View;
import com.neoway.iot.bi.common.param.QueryChartListParam;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IViewDao {

    /**
     * 新增视图配置
     * @param view
     * @return
     */
    int addView(@Param("view") View view);

    /**
     * 查询报表类型
     * @return
     */
    List<View> selectView();

    /**
     * 删除视图配置
     * @param viewId
     * @return
     */
    int delete(@Param("viewId") String viewId);

    /**
     * 更新视图配置
     * @param view
     * @return
     */
    int updateBySelective(@Param("view") View view);

    /**
     * 查询视图图表数量
     * @param param
     * @return
     */
    Integer queryCount(@Param("param") QueryChartListParam param);

    /**
     * 查询视图图表列表
     * @param param
     * @return
     */
    List<Chart> queryList(@Param("param") QueryChartListParam param);
}
