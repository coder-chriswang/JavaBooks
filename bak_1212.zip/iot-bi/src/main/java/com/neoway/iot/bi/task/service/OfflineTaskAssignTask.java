package com.neoway.iot.bi.task.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.cron.pattern.CronPattern;
import cn.hutool.cron.pattern.CronPatternUtil;
import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.domain.node.Node;
import com.neoway.iot.bi.common.domain.offlinestat.OfflineTask;
import com.neoway.iot.bi.common.dto.OfflineStrategyDTO;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.common.enums.OfflineStatTaskCronEnum;
import com.neoway.iot.bi.common.enums.OfflineStatTaskStatusEnum;
import com.neoway.iot.bi.common.util.CommonUtil;
import com.neoway.iot.bi.common.util.IDWorker;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.service.IOfflineStrategyService;
import com.neoway.iot.bi.service.IOfflineTaskService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
public class OfflineTaskAssignTask implements TaskService {

	@Resource
	private INodeService nodeService;

	@Resource
	private IOfflineTaskService offlineTaskService;

	@Resource
	private Cache guavaCache;

	@Resource
	private IOfflineStrategyService offlineStrategyService;

	@Override
	public boolean process () {
		//查询当前离线统计策略是否有未完成任务，有则跳过，无则添加任务和分配节点
		List<OfflineStrategyDTO> list = offlineStrategyService.list(null);
		if (list == null || list.size() == 0) {
			return true;
		}
		Integer lt = Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"))));
		Date now = new Date();
		Node node = new Node();
		node.setStatus(NodeStatusEnum.ONLINE.getCode());
		List<Node> nodeList = nodeService.getList(node);
		Integer nodeIndex = 0;
		Integer nodeSize = nodeList.size();
		//添加任务、分配节点
		if (StringUtils.isEmpty(guavaCache.getIfPresent("ip"))) {
			//有可能数据库中数据被删。。
			nodeService.add();
		}
		String ip = guavaCache.getIfPresent("ip").toString();
		Long nid = null;
		//获取本节点索引
		for (int i = 0; i < nodeSize; i++) {
			if (ip.equals(nodeList.get(i).getIp())) {
				nodeIndex = i;
				nid = nodeList.get(i).getNid();
			}
		}
		Integer finalNodeIndex = nodeIndex;
		List<OfflineStrategyDTO> offlineStrategyDTOS1 = new ArrayList<>();
		list.forEach(offlineStrategyDTO -> {
			//如果hash后与本节点索引相同，则将该策略加入本节点运行
			if (CommonUtil.guavaHash(offlineStrategyDTO.getMetric(), nodeSize).equals(finalNodeIndex)) {
				offlineStrategyDTOS1.add(offlineStrategyDTO);
			}
		});
		Long finalNid = nid;
		AtomicReference<OfflineTask> offlineTask = new AtomicReference<>();
		offlineStrategyDTOS1.forEach(offlineStrategyDTO -> {
			try {
				offlineTask.set(new OfflineTask());
				offlineTask.get().setMetric(offlineStrategyDTO.getMetric());
				OfflineTask offlineTask1 = offlineTaskService.getLastOne(offlineTask.get());
				if (StringUtils.isEmpty(offlineTask1) || OfflineStatTaskStatusEnum.SUCCESS.getCode().equals(offlineTask1.getStatus())
						|| OfflineStatTaskStatusEnum.FAIL.getCode().equals(offlineTask1.getStatus())) {
					//分配任务
					offlineTask.get().setId(IDWorker.id.nextId());
					BeanUtil.copyProperties(offlineStrategyDTO, offlineTask.get());
					offlineTask.get().setStatus(OfflineStatTaskStatusEnum.RUNNABLE.getCode());
					offlineTask.get().setNodeid(finalNid);
					offlineTask.get().setLt(lt);
					CronPattern cronPattern = new CronPattern(OfflineStatTaskCronEnum.getEnumByCode(offlineStrategyDTO.getPolicy()).getCron());
					Integer st = Integer.valueOf(String.valueOf(CronPatternUtil.nextDateAfter(cronPattern, now, true).getTime() / 1000));
					offlineTask.get().setSt(st);
					offlineTaskService.add(offlineTask.get());
				} else {
					//当前已存在未完成任务
					return;
				}
			} catch (Exception ex) {
				log.error("离线统计分配任务执行异常：{}", ex.getMessage());
				return;
			}

		});
		return true;
	}
}
