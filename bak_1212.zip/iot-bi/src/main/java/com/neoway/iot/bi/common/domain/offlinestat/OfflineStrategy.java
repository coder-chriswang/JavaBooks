package com.neoway.iot.bi.common.domain.offlinestat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("离线统计策略实体")
public class OfflineStrategy {

	@ApiModelProperty(value = "产品域")
	private String ns;

	@ApiModelProperty(value = "对象")
	private String type;

	@ApiModelProperty(value = "指标")
	private String metric;

	@ApiModelProperty(value = "统计算法")
	private String algorithm;

	@ApiModelProperty(value = "统计策略（h,d,m）")
	private String policy;

	@ApiModelProperty(value = "更新时间")
	private Integer lt;
}
