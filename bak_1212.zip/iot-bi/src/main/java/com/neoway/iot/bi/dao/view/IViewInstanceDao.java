package com.neoway.iot.bi.dao.view;

import com.neoway.iot.bi.common.domain.view.ViewInstance;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface IViewInstanceDao {

	int insert(@Param("viewInstance") ViewInstance viewInstance);

	ViewInstance selectOne(ViewInstance viewInstance);

	List<ViewInstance> selectList(ViewInstance viewInstance);

	/**
	 * 删除30天前的所有数据
	 * @param del30DayBeforeData
	 * @return
	 */
	int del30DayBeforeData(Del30DayBeforeData del30DayBeforeData);
}
