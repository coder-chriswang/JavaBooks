package com.neoway.iot.bi.common.exception;

public class ChartServiceException extends Exception {
    private int errorCode = -1;

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public ChartServiceException() {
    }

    public ChartServiceException(String message) {
        super(message);
    }

    public ChartServiceException(String message, int errorCode) {
        super(message);
        setErrorCode(errorCode);
    }
}
