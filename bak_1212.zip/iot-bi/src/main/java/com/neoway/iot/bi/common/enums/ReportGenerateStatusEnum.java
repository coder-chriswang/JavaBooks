package com.neoway.iot.bi.common.enums;

/**
 * 报表生成状态
 */
public enum ReportGenerateStatusEnum {
	WAITTING(0, "待生成"),
	RUNNING(1,"生成中"),
	FINISH(2,"生成完成"),
	FAIL(3, "生成失败")
	;

	private int code;

	private String desc;

	ReportGenerateStatusEnum (int code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public int getCode () {
		return code;
	}

	public void setCode (int code) {
		this.code = code;
	}

	public String getDesc () {
		return desc;
	}

	public void setDesc (String desc) {
		this.desc = desc;
	}
}
