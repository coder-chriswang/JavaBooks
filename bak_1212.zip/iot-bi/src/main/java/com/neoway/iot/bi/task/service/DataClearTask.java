package com.neoway.iot.bi.task.service;

import cn.hutool.core.date.DateUtil;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;
import com.neoway.iot.bi.service.IOfflineTaskService;
import com.neoway.iot.bi.service.IReportDataService;
import com.neoway.iot.bi.service.IReportTaskService;
import com.neoway.iot.bi.service.IViewInstanceService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

@Service
@Slf4j
public class DataClearTask implements TaskService {

	@Resource
	private IOfflineTaskService offlineTaskService;

	@Resource
	private IReportTaskService reportTaskService;

	@Resource
	private IReportDataService reportDataService;

	@Resource
	private IViewInstanceService viewInstanceService;

	@Override
	public boolean process () {
		//离线统计任务
		Del30DayBeforeData del30DayBeforeData = new Del30DayBeforeData();
		del30DayBeforeData.setSt(DateUtil.offsetDay(new Date(), -30).toTimestamp().getTime() / 1000);
		offlineTaskService.del30DayBeforeData(del30DayBeforeData);
		log.info("已清除大于30天的离线统计任务");
		//周期报表任务
		reportTaskService.del30DayBeforeData(del30DayBeforeData);
		log.info("已清除大于30天的周期报表任务");
		//统计数据
		reportDataService.del30DayBeforeData(del30DayBeforeData);
		log.info("已清除大于30天的统计数据");
		//二进制数据
		viewInstanceService.del30DayBeforeData(del30DayBeforeData);
		log.info("已清除大于30天的统计数据");
		return true;
	}
}
