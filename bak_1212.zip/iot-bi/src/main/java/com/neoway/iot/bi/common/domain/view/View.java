package com.neoway.iot.bi.common.domain.view;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("视图实体")
public class View {

	private String viewid;

	private String name;

	private String desc;

	private String chart;

	private Integer lt;
}
