package com.neoway.iot.bi.common.param;

import lombok.Data;

@Data
public class Ext {

	private String cmdId;
}
