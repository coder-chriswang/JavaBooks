package com.neoway.iot.bi.common.param;

import lombok.Data;

@Data
public class TaskParam {
	private Long nid;

}
