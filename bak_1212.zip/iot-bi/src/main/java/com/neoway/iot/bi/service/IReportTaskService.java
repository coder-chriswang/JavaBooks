package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;

import java.util.List;

public interface IReportTaskService {

	/**
	 * 查询周期报表任务列表
	 * @param reportTask
	 * @return
	 */
	List<ReportTask> getReportTaskList(ReportTask reportTask);

	/**
	 * 添加周期报表任务
	 * @param reportTask
	 * @return
	 */
	int add(ReportTask reportTask);


	int update(ReportTask reportTask);

	/**
	 * 根据viewid获取chart
	 * @param viewid
	 * @return
	 */
	String getChartByViewId(String viewid);

	/**
	 * 更新周期报表任务
	 * @param reportTask
	 * @param id
	 * @return
	 */
	int updateReportTask(ReportTask reportTask,Long id);

	/**
	 * RESTFUL调用接入网关sql查询
	 * @param reportTask
	 * @param chartIds
	 * @return
	 */
    Boolean executeCommandSyn(ReportTask reportTask,String[] chartIds);

	/**
	 * 获取超出任务计划时间的周期报表任务
	 * @param rt
	 * @return
	 */
	List<ReportTask> getTimeUpReportTaskList(ReportTask rt);

	/**
	 * 根据策略id获取统计状态
	 * @param id
	 * @return
	 */
	List<Integer> getReportTaskDstatus(Long id);

	/**
	 * 删除任务
	 * @param taskId
	 * @return
	 */
	int del(Long taskId);

	/**
	 * 删除30天前的所有数据
	 * @param del30DayBeforeData
	 * @return
	 */
	int del30DayBeforeData(Del30DayBeforeData del30DayBeforeData);

	/**
	 * 节点故障周期报表任务转移
	 * @param nid 故障节点id
	 * @param newNid 新节点id
	 * @return
	 */
    void reportTaskTransfer(Long nid, Long newNid);
}
