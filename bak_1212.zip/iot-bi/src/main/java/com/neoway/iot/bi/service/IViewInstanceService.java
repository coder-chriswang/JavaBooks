package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.domain.view.ViewInstance;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;

import java.util.List;

public interface IViewInstanceService {

	/**
	 * 添加视图实例
	 * @return
	 */
	int add(ViewInstance viewInstance);

	/**
	 * 获取视图实例列表
	 * @param viewInstance
	 * @return
	 */
	List<ViewInstance> getList(ViewInstance viewInstance);

	/**
	 * 获取任务节点信息
	 * @param viewInstance
	 * @return
	 */
	ViewInstance get(ViewInstance viewInstance);

	/**
	 * 删除30天前的所有数据
	 * @param del30DayBeforeData
	 * @return
	 */
	int del30DayBeforeData(Del30DayBeforeData del30DayBeforeData);

}
