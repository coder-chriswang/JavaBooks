package com.neoway.iot.bi.common.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <pre>
 *  描述: 视图Chart图表查询参数
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/18 15:46
 */

@Data
@ApiModel("视图Chart图表查询参数")
public class QueryViewChartListParam {

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页行数")
    private Integer pageSize;

    @ApiModelProperty("chart")
    private String chart;
}
