package com.neoway.iot.bi.common.transform.ringScreen;


import com.neoway.iot.bi.common.transform.pie.PieDataData;

import java.util.List;

public class RingSeries {

    private String name;

    private List<RingPieData> pieData;

    public String getName () {
        return name;
    }

    public void setName (String name) {
        this.name = name;
    }

    public List<RingPieData> getPieData () {
        return pieData;
    }

    public void setPieData (List<RingPieData> pieData) {
        this.pieData = pieData;
    }
}
