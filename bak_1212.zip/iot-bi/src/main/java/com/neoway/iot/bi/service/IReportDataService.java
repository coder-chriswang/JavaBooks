package com.neoway.iot.bi.service;

import com.neoway.iot.bi.common.domain.reportstat.ReportData;
import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.vo.offlinetask.Del30DayBeforeData;

import java.util.List;

public interface IReportDataService {

	List<ReportData> getReportDataList(ReportData reportData);

	int update(ReportData reportData);

	/**
	 * 删除30天前的所有数据
	 * @param del30DayBeforeData
	 * @return
	 */
	int del30DayBeforeData(Del30DayBeforeData del30DayBeforeData);
}
