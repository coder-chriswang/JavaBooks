package com.neoway.iot.bi.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.neoway.iot.bi.common.constants.ErrorConstant;
import com.neoway.iot.bi.common.dto.ReportStrategyDTO;
import com.neoway.iot.bi.common.dto.ViewDTO;
import com.neoway.iot.bi.common.util.IDWorker;
import com.neoway.iot.bi.common.vo.reportstrategy.AddReportStrategyVO;
import com.neoway.iot.bi.common.vo.reportstrategy.EditReportStrategyVO;
import com.neoway.iot.bi.common.vo.reportstrategy.ListReportStrategyVo;
import com.neoway.iot.bi.dao.reportstat.IReportStrategyDao;
import com.neoway.iot.bi.common.domain.reportstat.ReportStrategy;
import com.neoway.iot.bi.common.exception.BiException;
import com.neoway.iot.bi.service.IReportStrategyService;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

/**
 * <pre>
 *  描述: 周期报表统计策略service层实现
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/6 13:45
 */
@Service
@Slf4j
public class ReportStrategyServiceImpl implements IReportStrategyService {

    @Resource
    private IReportStrategyDao reportStrategyDao;

    @Override
    public List<ReportStrategyDTO> list(ListReportStrategyVo listReportStrategyVo) {
        return reportStrategyDao.selectList(listReportStrategyVo);
    }

    @Override
    public List<ViewDTO> getViewDropDown() {
        List<ViewDTO> viewDTOS = reportStrategyDao.selectDropDown();
        if (StrUtil.isEmptyIfStr(viewDTOS)) {
            throw new BiException(MessageUtils.getMessage("ies.bi.strategy.msg.service.queryEmpty"));
        }
        return viewDTOS;
    }

    @Override
    public int add(AddReportStrategyVO addReportStrategyVO) {
        ReportStrategy reportStrategy = new ReportStrategy();
        BeanUtil.copyProperties(addReportStrategyVO, reportStrategy);
        List<AddReportStrategyVO> reportStrategyVOS = reportStrategyDao.getReportStrategyList();
        if (reportStrategyVOS.contains(addReportStrategyVO)){
            return -1;
        }
        reportStrategy.setId(IDWorker.id.nextId());
        reportStrategy.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
        int result = reportStrategyDao.insert(reportStrategy);
        if (result == 0) {
            throw new BiException(ErrorConstant.ADD_FAIL);
        }
        return result;
    }

    @Override
    public int del(String id) {
        int result = reportStrategyDao.delete(id);
        if (result == 0) {
            throw new BiException(ErrorConstant.DEL_FAIL);
        }
        return result;
    }

    @Override
    public int edit(EditReportStrategyVO editReportStrategyVO) {
        ReportStrategy reportStrategy = new ReportStrategy();
        BeanUtil.copyProperties(editReportStrategyVO, reportStrategy);
        reportStrategy.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
        int result = reportStrategyDao.updateBySelective(reportStrategy);
        if (result == 0) {
            throw new BiException(ErrorConstant.UPDATE_FAIL);
        }
        return result;
    }

	@Override
	public ReportStrategy getOne (ReportStrategy reportStrategy) {
        ReportStrategy reportStrategy1 = reportStrategyDao.selectOne(reportStrategy);
        return reportStrategy1;
	}

    @Override
    public int editNotifyGroup(String code, String name) {
        int result = reportStrategyDao.updateNotifyGroup(code,name);
        if (result == 0) {
            throw new BiException(ErrorConstant.UPDATE_FAIL);
        }
        return result;
    }

    @Override
    public int delByCode(String code) {
        int result = reportStrategyDao.deleteByCode(code);
        if (result == 0) {
            throw new BiException(ErrorConstant.DEL_FAIL);
        }
        return result;
    }
}
