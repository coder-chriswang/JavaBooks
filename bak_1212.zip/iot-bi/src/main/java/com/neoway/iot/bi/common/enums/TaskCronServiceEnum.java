package com.neoway.iot.bi.common.enums;

public enum TaskCronServiceEnum {
	/**
	 * taskBeanName 为对应任务beanName
	 */
	NODE_STATUS_UPDATE("nodeStatusUpdate", "0 0/1 * * * ?","节点更新状态任务", "updateNodeStatusTask"),

	NODE_HEALTH_CHECK("nodeHealthCheck","0 0/3 * * * ?","节点健康检测任务", "nodeHealthCheckTask"),

	OFFLINE_TASK_ASSIGN("offlineTaskAssign", "58 * * * * ?","离线统计分配任务", "offlineTaskAssignTask"),

	OFFLINE_TASK_EXECUTE("offlineTaskExecute","0 0/5 * * * ?", "离线统计任务", "offlineTaskExecuteTask"),

	REPORT_TASK_ASSIGN("reportTaskAssign", "0 * * * * ?","周期报表分配任务", "reportTaskAssignTask"),

	REPORT_TASK_EXECUTE("reportTaskExecute", "15 * * * * ?","周期报表统计任务", "reportTaskExecuteTask"),

	DATA_CLEAR("dataClear", "0 0 0 * * ?", "清除大于30天的数据", "dataClearTask"),

	REPORT_GENERATE("reportGenerate", "30 * * * * ?", "报表生成任务", "reportGenerateTask"),

	REPORT_NOTIFY("reportNotify", "45 * * * * ?", "报表通知任务", "reportNotifyTask")
	;

	private String name;

	private String cron;

	private String desc;

	private String taskBeanName;

	TaskCronServiceEnum (String name, String cron, String desc, String taskBeanName) {
		this.name = name;
		this.cron = cron;
		this.desc = desc;
		this.taskBeanName = taskBeanName;
	}

	public String getName () {
		return name;
	}

	public void setName (String name) {
		this.name = name;
	}

	public String getCron () {
		return cron;
	}

	public void setCron (String cron) {
		this.cron = cron;
	}

	public String getDesc () {
		return desc;
	}

	public void setDesc (String desc) {
		this.desc = desc;
	}

	public String getTaskBeanName () {
		return taskBeanName;
	}

	public void setTaskBeanName (String taskBeanName) {
		this.taskBeanName = taskBeanName;
	}
}
