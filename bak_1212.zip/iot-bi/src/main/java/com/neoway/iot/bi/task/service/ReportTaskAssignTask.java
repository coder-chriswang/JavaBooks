package com.neoway.iot.bi.task.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.cron.pattern.CronPattern;
import cn.hutool.cron.pattern.CronPatternUtil;
import com.google.common.cache.Cache;
import com.neoway.iot.bi.common.domain.node.Node;
import com.neoway.iot.bi.common.domain.reportstat.ReportTask;
import com.neoway.iot.bi.common.dto.ReportStrategyDTO;
import com.neoway.iot.bi.common.enums.NodeStatusEnum;
import com.neoway.iot.bi.common.enums.ReportGenerateStatusEnum;
import com.neoway.iot.bi.common.enums.ReportNotifyStatusEnum;
import com.neoway.iot.bi.common.enums.ReportStatStatusEnum;
import com.neoway.iot.bi.common.util.CommonUtil;
import com.neoway.iot.bi.service.INodeService;
import com.neoway.iot.bi.service.IReportStrategyService;
import com.neoway.iot.bi.service.IReportTaskService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * <pre>
 *  描述: 周期报表任务分配
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/5 21:01
 */
@Service
@Slf4j
public class ReportTaskAssignTask implements TaskService {

    @Resource
    private IReportStrategyService reportStrategyService;

    @Resource
    private IReportTaskService reportTaskService;

    @Resource
    private INodeService nodeService;

    @Resource
    private Cache guavaCache;

    @Override
    public boolean process() {
        List<ReportStrategyDTO> list = reportStrategyService.list(null);
        AtomicReference<ReportTask> reportTask = new AtomicReference<>();
        Integer lt = Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8"))));
        Date now = new Date();
        Node node = new Node();
        node.setStatus(NodeStatusEnum.ONLINE.getCode());
        List<Node> nodeList = nodeService.getList(node);
        Integer nodeIndex = 0;
        Integer nodeSize = nodeList.size();
        //添加任务、分配节点
        if (StringUtils.isEmpty(guavaCache.getIfPresent("ip"))) {
            //有可能数据库中数据被删。。
            nodeService.add();
        }
        String ip = guavaCache.getIfPresent("ip").toString();
        Long nid = null;
        //获取本节点索引
        for (int i = 0; i < nodeSize; i++) {
            if (ip.equals(nodeList.get(i).getIp())) {
                nodeIndex = i;
                nid = nodeList.get(i).getNid();
            }
        }
        Integer finalNodeIndex = nodeIndex;
        List<ReportStrategyDTO> reportStrategyDTOS1 = new ArrayList<>();
        list.forEach(reportStrategyDTO -> {
            //如果hash后与本节点索引相同，则将该策略加入本节点运行
            if (CommonUtil.guavaHash(reportStrategyDTO.getViewId(), nodeSize).equals(finalNodeIndex)) {
                reportStrategyDTOS1.add(reportStrategyDTO);
            }
        });
        Long finalNid = nid;
        reportStrategyDTOS1.forEach(reportStrategyDTO -> {
            try {
                reportTask.set(new ReportTask());
                reportTask.get().setId(Long.parseLong(reportStrategyDTO.getId()));
                List<ReportTask> reportTask1 = reportTaskService.getReportTaskList(reportTask.get());
                List<Integer> dstatus  = reportTaskService.getReportTaskDstatus(Long.parseLong(reportStrategyDTO.getId()));
                Boolean bl = CollUtil.isNotEmpty(dstatus) && !(dstatus.contains(0) || dstatus.contains(1));
                if (CollectionUtil.isEmpty(reportTask1) || bl){
                    reportTask.get().setStrategyId(Long.parseLong(reportStrategyDTO.getId()));
                    reportTask.get().setViewid(reportStrategyDTO.getViewId());
                    reportTask.get().setViewName(reportStrategyDTO.getName());
                    reportTask.get().setNodeid(finalNid);
                    reportTask.get().setDstatus(ReportStatStatusEnum.WAITTING.getCode());
                    reportTask.get().setGstatus(ReportGenerateStatusEnum.WAITTING.getCode());
                    reportTask.get().setSstatus(ReportNotifyStatusEnum.WAITTING.getCode());
                    reportTask.get().setLt(lt);
                    CronPattern cronPattern = new CronPattern(reportStrategyDTO.getPolicy());
                    Integer st = Integer.valueOf(String.valueOf(CronPatternUtil.nextDateAfter(cronPattern, now, true).getTime() / 1000));
                    reportTask.get().setSt(st);
                    reportTaskService.add(reportTask.get());
                } else {
                    log.info("当前已存在未完成任务");
                }
            }catch (Exception e){
                log.error("周期报表分配任务执行异常：{}", e.getMessage());
                return;
            }
        });
        return true;
    }
}
