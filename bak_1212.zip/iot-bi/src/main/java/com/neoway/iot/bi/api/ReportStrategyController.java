package com.neoway.iot.bi.api;

import com.neoway.iot.bi.HttpResult;
import com.neoway.iot.bi.common.dto.ReportStrategyDTO;
import com.neoway.iot.bi.common.dto.ViewDTO;
import com.neoway.iot.bi.common.vo.reportstrategy.AddReportStrategyVO;
import com.neoway.iot.bi.common.vo.reportstrategy.EditReportStrategyVO;
import com.neoway.iot.bi.common.vo.reportstrategy.ListReportStrategyVo;
import com.neoway.iot.bi.service.IReportStrategyService;
import com.neoway.iot.bi.common.util.BiPageModel;
import com.neoway.iot.bi.common.util.PageHelper;
import com.neoway.iot.bi.service.impl.EmailServerImpl;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * <pre>
 *  描述: 周期报表统计策略接口
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/11/6 11:26
 */
@RestController
@RequestMapping("/v1/reportStrategy/")
@Api(tags = "周期报表统计策略接口", description = "周期报表统计策略接口")
@Slf4j
public class ReportStrategyController {

    @Resource
    private IReportStrategyService reportStrategyService;

    @Resource
    private EmailServerImpl emailServer;

    @ApiOperation(value = "周期报表统计列表查询")
    @PostMapping("list")
    public HttpResult<BiPageModel<ReportStrategyDTO>> listReportStrategy(@RequestBody @Valid ListReportStrategyVo listReportStrategyVo){
        List<ReportStrategyDTO> reportStrategyDTOS = reportStrategyService.list(listReportStrategyVo);
        BiPageModel<ReportStrategyDTO> pagination = PageHelper.pagination(reportStrategyDTOS, listReportStrategyVo.getPageSize(), listReportStrategyVo.getPageNum());
        return HttpResult.returnSuccess(pagination);
    }

    @ApiOperation(value = "查询视图下拉框")
    @GetMapping("getViewDropDown")
    public HttpResult getViewDropDown(){
        List<ViewDTO> viewDTOS = reportStrategyService.getViewDropDown();
        return HttpResult.returnSuccess(viewDTOS);
    }

    @ApiOperation(value = "新增周期报表统计策略")
    @PostMapping("add")
    public HttpResult addReportStrategy(@RequestBody @Valid AddReportStrategyVO addReportStrategyVO){
        int result = reportStrategyService.add(addReportStrategyVO);
        if (result == -1){
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.strategy.msg.service.againAdd"),false);
        }
        return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.strategy.msg.service.insertSuccess"),result);
    }

    @ApiOperation(value = "删除周期报表统计策略")
    @DeleteMapping("{id}")
    public HttpResult delReportStrategy(@PathVariable("id") String id){
        int result = reportStrategyService.del(id);
        return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.strategy.msg.service.delSuccess"),result);
    }

    @ApiOperation(value = "修改周期报表统计策略")
    @PostMapping("update")
    public HttpResult updateReportStrategy(@RequestBody @Valid EditReportStrategyVO editReportStrategyVO){
        int result = reportStrategyService.edit(editReportStrategyVO);
        return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.strategy.msg.service.updateSuccess"),result);
    }

    @ApiOperation(value = "修改周期报表策略通知组信息")
    @GetMapping("updateNotifyGroup")
    public HttpResult updateNotifyGroup(@RequestParam("code") String code, @RequestParam("name") String name){
        if (StringUtils.isEmpty(code) || StringUtils.isEmpty(name)){
            return HttpResult.returnFail(MessageUtils.getMessage("ies.bi.biChart.msg.api.paramError"));
        }
        int result = reportStrategyService.editNotifyGroup(code,name);
        return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.strategy.msg.service.updateSuccess"),result);
    }

    @ApiOperation(value = "根据code删除周期报表统计策略")
    @DeleteMapping("delReportByCode/{code}")
    public HttpResult delReportStrategyByCode(@PathVariable("code") String code){
        int result = reportStrategyService.delByCode(code);
        return HttpResult.returnSuccess(MessageUtils.getMessage("ies.bi.strategy.msg.service.delSuccess"),result);
    }
    @ApiOperation(value = "更新email server配置缓存")
    @GetMapping("updateEmailServerProp")
    public void updateEmailServerProp(){
        emailServer.getEmailServerProp();
    }


}
