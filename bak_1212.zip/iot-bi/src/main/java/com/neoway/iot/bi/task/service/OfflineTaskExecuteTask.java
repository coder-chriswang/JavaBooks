package com.neoway.iot.bi.task.service;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import com.neoway.iot.bi.common.domain.offlinestat.OfflineTask;
import com.neoway.iot.bi.common.dto.GWRequest;
import com.neoway.iot.bi.common.dto.OfflineTaskExecuteDTO;
import com.neoway.iot.bi.common.enums.OfflineStatTaskStatusEnum;
import com.neoway.iot.bi.service.IOfflineTaskService;
import com.neoway.iot.bi.task.TaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@Service
@Slf4j
public class OfflineTaskExecuteTask implements TaskService {

	@Resource
	private IOfflineTaskService offlineTaskService;
	@Resource
	private ThreadPoolExecutor threadPoolExecutor;

	@Override
	public boolean process () {
		//查询出待执行的任务列表，遍历执行
		OfflineTask offlineTask = new OfflineTask();
		offlineTask.setStatus(OfflineStatTaskStatusEnum.RUNNABLE.getCode());
		offlineTask.setSt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
		List<OfflineTaskExecuteDTO> list = offlineTaskService.getTimeUpTaskList(offlineTask);
		if (list == null || list.size() == 0) {
			//当前无可执行的离线统计任务，结束任务
			return true;
		}
		AtomicReference<GWRequest> gwRequest = new AtomicReference<>();
		list.forEach(offlineTaskExecuteDTO -> {
			threadPoolExecutor.submit(() -> {
				offlineTaskExecuteDTO.getPolicy();
				offlineTaskExecuteDTO.setStatus(OfflineStatTaskStatusEnum.RUNNING.getCode());
				offlineTaskExecuteDTO.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
				OfflineTask offlineTask2 = new OfflineTask();
				BeanUtil.copyProperties(offlineTaskExecuteDTO, offlineTask2);
				try {
					offlineTaskService.update(offlineTask2);
				} catch (Exception ex) {
					log.error("更新离线统计任务失败,status={}, ex:{}", offlineTask2.getStatus(), ex.getMessage());
					return;
				}
				gwRequest.set(new GWRequest());
				Map<String, Object> body = buildBody(offlineTaskExecuteDTO.getPolicy());
				Map<String, Object> header = new HashMap<>();
				header.put("templateid", offlineTaskExecuteDTO.getAlgorithm());
				gwRequest.get().setBody(body);
				gwRequest.get().setHeader(header);
				Boolean result = offlineTaskService.executeCommandAsyn(gwRequest.get());
				if (result) {
					offlineTaskExecuteDTO.setStatus(OfflineStatTaskStatusEnum.SUCCESS.getCode());
				} else {
					offlineTaskExecuteDTO.setStatus(OfflineStatTaskStatusEnum.FAIL.getCode());
				}
				offlineTaskExecuteDTO.setLt(Integer.valueOf(String.valueOf(LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")))));
				BeanUtil.copyProperties(offlineTaskExecuteDTO, offlineTask2);
				try {
					offlineTaskService.update(offlineTask2);
				} catch (Exception ex) {
					log.error("更新离线统计任务失败,status={}, ex:{}", offlineTask2.getStatus(), ex.getMessage());
					return;
				}
			});
		});
		return true;
	}

	/**
	 * 构建body
	 * @param policy
	 * @return
	 */
	private Map<String, Object> buildBody(String policy) {
		Map<String, Object> body = new HashMap<>();
		long st = 0;
		long et = 0;
		switch (policy) {
			case "h":
				st = DateUtil.offsetHour(Date.from(LocalDateTime.now().withMinute(0).withSecond(0).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				et = DateUtil.offsetHour(Date.from(LocalDateTime.now().withMinute(59).withSecond(59).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				break;
			case "d":
				st = DateUtil.offsetDay(Date.from(LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				et = DateUtil.offsetDay(Date.from(LocalDateTime.now().withHour(23).withMinute(59).withSecond(59).withNano(0).atZone(
						ZoneId.systemDefault()).toInstant()), -1).toTimestamp().getTime() / 1000;
				break;
			case "m":
				Date date = new Date();
				st = DateUtil.offsetMonth(DateUtil.beginOfMonth(date), -1).toTimestamp().getTime() / 1000;
				et = DateUtil.endOfMonth(DateUtil.offsetMonth(new Date(), -1)).toTimestamp().getTime() / 1000;
				break;
			default:
				break;
		}
		body.put("st", st + "");
		body.put("et", et + "");
		return body;
	}
}
