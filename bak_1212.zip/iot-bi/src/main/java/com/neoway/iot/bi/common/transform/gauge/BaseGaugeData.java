package com.neoway.iot.bi.common.transform.gauge;

import com.neoway.iot.bi.common.transform.BaseData;

import java.util.List;

public class BaseGaugeData extends BaseData {

	private List<GaugeData> data;

	public List<GaugeData> getData () {
		return data;
	}

	public void setData (List<GaugeData> data) {
		this.data = data;
	}
}
