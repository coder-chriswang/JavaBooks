package com.neoway.iot.bi.common.enums;

/**
 * 报表通知状态
 */
public enum ReportNotifyStatusEnum {
	WAITTING(0, "待通知"),
	RUNNING(1,"通知中"),
	FINISH(2,"通知完成"),
	FAIL(3, "通知失败")
	;

	private int code;

	private String desc;

	ReportNotifyStatusEnum (int code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public static ReportNotifyStatusEnum getEnumByCode(int code) {
		ReportNotifyStatusEnum responseCode;
		for (int i = 0; i < ReportNotifyStatusEnum.values().length; i++) {
			responseCode = ReportNotifyStatusEnum.values()[i];
			if (responseCode.code == code) {
				return responseCode;
			}
		}
		return null;
	}

	public int getCode () {
		return code;
	}

	public void setCode (int code) {
		this.code = code;
	}

	public String getDesc () {
		return desc;
	}

	public void setDesc (String desc) {
		this.desc = desc;
	}
}
