package com.neoway.iot.bi.common.enums;

/**
 * 报表统计状态
 */
public enum ReportStatStatusEnum {
	WAITTING(0, "待统计"),
	RUNNING(1,"统计中"),
	FINISH(2,"统计完成"),
	FAIL(3, "统计失败")
	;

	private int code;

	private String desc;

	ReportStatStatusEnum (int code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public int getCode () {
		return code;
	}

	public void setCode (int code) {
		this.code = code;
	}

	public String getDesc () {
		return desc;
	}

	public void setDesc (String desc) {
		this.desc = desc;
	}
}
