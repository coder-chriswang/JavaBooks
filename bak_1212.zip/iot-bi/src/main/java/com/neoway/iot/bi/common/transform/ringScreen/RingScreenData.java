package com.neoway.iot.bi.common.transform.ringScreen;


import com.neoway.iot.bi.common.transform.pie.Series;

import java.util.List;

public class RingScreenData {

    private List<String> legend;

    private RingSeries series;

    public List<String> getLegend () {
        return legend;
    }

    public void setLegend (List<String> legend) {
        this.legend = legend;
    }

    public RingSeries getSeries () {
        return series;
    }

    public void setSeries (RingSeries series) {
        this.series = series;
    }
}
