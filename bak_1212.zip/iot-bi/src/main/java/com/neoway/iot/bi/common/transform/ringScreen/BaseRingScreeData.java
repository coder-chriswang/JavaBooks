package com.neoway.iot.bi.common.transform.ringScreen;

import com.neoway.iot.bi.common.transform.BaseData;

public class BaseRingScreeData extends BaseData {

    private RingScreenData data;

    public void setData(RingScreenData data){
        this.data = data;
    }
    public RingScreenData getData(){
        return data;
    }

}
