package com.neoway.iot.dmm.api;

import com.neoway.iot.dmm.HttpResult;
import com.neoway.iot.dmm.common.Utils;
import com.neoway.iot.dmm.handler.MetaHandler;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.dmk.meta.DMMetaI18n;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @desc: MetaController
 * @author: 20200312686
 * @date: 2020/7/21 10:56
 */
@RestController
@RequestMapping("/v1/meta")
@Api(tags = "元数据")
public class MetaController {
    private static final Logger LOG = LoggerFactory.getLogger(MetaController.class);
    private MetaHandler handler=new MetaHandler();

    @ApiOperation("查询系统中CI元数据")
    @GetMapping("/ci")
    public HttpResult<List<DMMetaCI>> queryCI(@RequestParam("type") String type, HttpServletRequest request) {
        try {
            String lang = request.getHeader("lang");
            DMMetaCI condition=new DMMetaCI(Utils.R_PRODUCT, Utils.R_CATEGORY,"");
            condition.setType(type);
            List<DMMetaCI> metaCIs = handler.queryMetaCI(condition);
            return HttpResult.returnSuccess(MessageUtils.getMessage("ies.cm.dmm.msg.api.querySuccess"), handler.resultUrmI18n(metaCIs, lang));
        } catch (Exception e) {
            LOG.error("查询失败！", e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.cm.dmm.msg.api.queryFail"));
        }

    }


    @ApiOperation("查询CI元数据")
    @GetMapping("/{category}/{ci}")
    public HttpResult<DMMetaCI> getMeta(@PathVariable("category") String category, @PathVariable("ci") String ci, HttpServletRequest request) {
        try {
            String lang = request.getHeader("lang");
            DMMetaCI metaCI = handler.getMetaCIBySort(Utils.R_PRODUCT, category, ci);
            List<DMMetaI18n> i18ns = handler.getMetaI18n("ies", category, ci);
            DMMetaCI result = handler.resultI18n(metaCI, i18ns, lang);
            return HttpResult.returnSuccess(MessageUtils.getMessage("ies.cm.dmm.msg.api.querySuccess"), result);
        } catch (Exception e) {
            LOG.error("查询失败！", e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.cm.dmm.msg.api.queryFail"));
        }
    }
}
