package com.neoway.iot.dmm.handler.filter;

import cn.hutool.core.date.DateTime;
import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.PageInfo;
import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @desc: DmmRspCommonFilter
 * @author: 20200312686
 * @date: 2020/7/28 15:25
 */
public class DmmRspCommonFilter implements DmmRspFilter {
    private static final String ACTION_GET="Get";
    private DMRunner runner=DMRunner.getInstance();
    @Override
    public void filter(DMMRequest request, DMMResponse response) {
        if(!response.isNeedFilter()){
            return;
        }
        DMMetaCI metaCI=runner.getMetaCI(request.getNs(), request.getCategory(),request.getCi());
        if(null == metaCI){
            throw new RuntimeException(MessageUtils.getMessage("ies.cm.dmm.msg.handler.notExistMetaData"));
        }
        Object data=response.getData();
        if(null == data){
            return;
        }else if(data instanceof List){
            List<Map<String,Object>> datas=(List<Map<String,Object>>) data;
            List<Map<String,Object>> filterArr=new ArrayList<>();
            for(Map<String,Object> dv:datas){
                Map<String,Object> filterMap=filterValue(dv,metaCI,request.getAction());
                if(MapUtils.isEmpty(filterMap)){
                    continue;
                }
                filterArr.add(filterMap);
            }
            response.setData(filterArr);
        } else if (data instanceof PageInfo){
            response.setData(data);
        } else{
            Map<String,Object> dataMap=(Map<String, Object>) data;
            if (ACTION_GET.equalsIgnoreCase(request.getAction())) {
                List<Map<String,Object>> filterMap=filterAttr(dataMap,metaCI,request.getAction());
                response.setData(filterMap);
            } else {
                Map<String,Object> filterMap=filterValue(dataMap,metaCI,request.getAction());
                response.setData(filterMap);
            }
        }
    }

    /**
     * @desc 数据过滤器
     * @param dataMap
     * @param metaCI
     * @param actionId
     * @return
     */
    private Map<String,Object> filterValue(Map<String,Object> dataMap,DMMetaCI metaCI,String actionId){
        Map<String,Object> filterMap=new HashMap<>();
        for(Map.Entry<String,Object> entry:dataMap.entrySet()){
            DMMetaAttr metaAttr=metaCI.buildAssignAttr(entry.getKey());
            if(null == metaAttr){
                continue;
            }else if(metaAttr.getSupportAction().contains(actionId)){
                filterMap.put(entry.getKey(),String.valueOf(entry.getValue()));
            }else{
                continue;
            }
        }
        return filterMap;
    }

    /**
     * @desc 数据过滤器
     * @param dataMap
     * @param metaCI
     * @param actionId
     * @return
     */
    private List<Map<String,Object>> filterAttr(Map<String,Object> dataMap,DMMetaCI metaCI,String actionId){
        List<Map<String,Object>> list = new ArrayList<>();
        for(Map.Entry<String,Object> entry:dataMap.entrySet()){
            DMMetaAttr metaAttr=metaCI.buildAssignAttr(entry.getKey());
            if(null == metaAttr){
                continue;
            }else if(metaAttr.getSupportAction().contains(actionId)){
                Map<String,Object> map=new HashMap<>(2);
                map.put("label", metaAttr.getName());
                map.put("value",String.valueOf(entry.getValue()));
                convertTimeForm(entry, map);
                if (entry.getValue() == null) {
                    map.put("value", "");
                }
                list.add(map);
            }else{
                continue;
            }
        }
        return list;
    }

    private void convertTimeForm(Map.Entry<String, Object> entry, Map<String, Object> map) {
        if ("lt".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
        if ("productiondate".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
        if ("production_date".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
        if ("install_date".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
        if ("create_time".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
        if ("event_time".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
        if ("rt".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
        if ("at".equals(entry.getKey()) && (entry.getValue() != null)) {
            String time = DateTime.of(Long.valueOf(String.valueOf(entry.getValue())) * 1000).toString("yyyy-MM-dd HH:mm:ss");
            map.put("value", time);
        }
    }
}
