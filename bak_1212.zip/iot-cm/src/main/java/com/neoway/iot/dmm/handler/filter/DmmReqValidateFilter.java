package com.neoway.iot.dmm.handler.filter;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaAttr;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

/**
 * @desc: ValidateFilter
 * @author: 20200312686
 * @date: 2020/7/27 16:16
 */
public class DmmReqValidateFilter implements DmmReqFilter {
    private DMRunner runner=DMRunner.getInstance();
    @Override
    public void filter(DMMRequest request) {
        //获取元数据进行参数校验
        if(StringUtils.isEmpty(request.getNs())
                || StringUtils.isEmpty(request.getCi())){
            throw new RuntimeException(MessageUtils.getMessage("ies.cm.dmm.msg.handler.paramNotNull"));
        }
        DMMetaCI metaCI=runner.getMetaCI(request.getNs(), request.getCategory(), request.getCi());
        if(null == metaCI){
            throw new RuntimeException(MessageUtils.getMessage("ies.cm.dmm.msg.handler.notExistMetaData"));
        }
        DMMetaAction action=metaCI.buildAssignAction(request.getAction());
        if(null == action){
            throw new RuntimeException(MessageUtils.getMessage("ies.cm.dmm.msg.handler.actionNotExist"));
        }
        Map<String,Object> attrValue=(Map<String, Object>) request.getData();
        if(MapUtils.isNotEmpty(attrValue)){
            for(Map.Entry<String,Object> entry:attrValue.entrySet()){
                DMMetaAttr metaAttr=metaCI.buildAssignAttr(entry.getKey());
                if(null == metaAttr){
                    throw new RuntimeException(MessageUtils.getMessage("ies.cm.dmm.msg.handler.notExistAttr") + ":" + entry.getKey());
                }else if(!metaAttr.getSupportAction().contains(request.getAction())){
                    throw new RuntimeException(MessageUtils.getMessage("ies.cm.dmm.msg.handler.attrNotSupportAction") + ":"+entry.getKey());
                }
            }
        }
    }
}
