package com.neoway.iot.dmm.api;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONUtil;
import com.google.gson.JsonArray;
import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.HttpResult;
import com.neoway.iot.dmm.common.Utils;
import com.neoway.iot.dmm.model.OmCapabilityModel;
import com.neoway.iot.dmm.model.ResourceStatus;
import com.neoway.iot.dmm.service.ResourceService;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：获取om能力
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/9/22 15:17
 */
@RestController
@RequestMapping("/v1/resource")
@Api(tags = "资源查询")
public class ResourceController {
    private static final Logger LOG = LoggerFactory.getLogger(ResourceController.class);

    @Autowired
    ResourceService resourceService;

    @ApiOperation("查询业务能力")
    @GetMapping("/om/{ns}/{ci}")
    public HttpResult<List<OmCapabilityModel>> queryCapability(@PathVariable("ns") String ns, @PathVariable("ci") String ci) {
        try {
            return HttpResult.returnSuccess(resourceService.queryCapability(ns,ci));
        } catch (Exception e) {
            LOG.error("查询om能力失败！", e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.cm.dmm.msg.api.queryOmFail"));
        }
    }

    @ApiOperation("查询设备状态")
    @GetMapping("/status/{instanceId}")
    public HttpResult<List<ResourceStatus>> queryStatus(@PathVariable("instanceId") String instanceId) {
        try {
            return HttpResult.returnSuccess(resourceService.queryStatus(instanceId));
        } catch (Exception e) {
            LOG.error("查询设备状态失败！", e);
            return HttpResult.returnFail(MessageUtils.getMessage("ies.cm.dmm.msg.api.queryStatusFail"));
        }
    }

    @ApiOperation("查询Tag标签")
    @GetMapping("/tag")
    public HttpResult<List<Map<String, Object>>> queryCmTag(String targetId, HttpServletRequest request) {
        try {
            String lang = request.getHeader("lang");
            if (StringUtils.isEmpty(targetId)) {
                List<Map<String,Object>> result = resourceService.queryTag(Utils.R_PRODUCT, Utils.R_CM);
                return HttpResult.returnSuccess(resourceService.resultUrmI18n(result, lang));
            } else {
                List<Map<String,Object>> resultLeaf = resourceService.queryTagLeave(targetId);
                return HttpResult.returnSuccess(resourceService.resultI18n(resultLeaf, lang));

            }
        } catch (Exception e) {
            return HttpResult.returnFail(MessageUtils.getMessage("ies.cm.dmm.msg.api.queryTagFail"));
        }
    }

    @ApiOperation("关联查询实例数据")
    @PostMapping("/instance")
    public HttpResult<List<Map<String, Object>>> queryInstanceInfo(@RequestBody DMMRequest request) {
        try {
            return HttpResult.returnSuccess(resourceService.queryInstance(request));
        } catch (Exception e) {
            return HttpResult.returnFail(MessageUtils.getMessage("ies.cm.dmm.msg.api.queryInstanceFail"));
        }
    }
}
