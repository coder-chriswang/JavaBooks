package com.neoway.iot.dmm.handler;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.dmm.handler.filter.DmmReqFilter;
import com.neoway.iot.dmm.handler.filter.DmmReqValidateFilter;
import com.neoway.iot.dmm.handler.filter.DmmRspCommonFilter;
import com.neoway.iot.dmm.handler.filter.DmmRspFilter;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @desc: 资源操作
 * @author: 20200312686
 * @date: 2020/7/21 11:00
 */
public class DataHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DataHandler.class);
    private DMRunner runner;
    private List<DmmReqFilter> reqFilters=new ArrayList<>();
    private List<DmmRspFilter> rspFilters=new ArrayList<>();
    public DataHandler(){
        this.runner=DMRunner.getInstance();
        reqFilters.add(new DmmReqValidateFilter());
        rspFilters.add(new DmmRspCommonFilter());
    }

    /**
     * 资源指令执行
     * @param request
     * @return
     */
    public DMMResponse execute(DMMRequest request){
        DMMResponse response=new DMMResponse();
        try{
            for(DmmReqFilter filter:reqFilters){
                filter.filter(request);
            }
            DMMetaCI metaci=runner.getMetaCI(request.getNs(), request.getCategory(),request.getCi());
            if (request.getPageNum() != null && request.getPageSize() != null) {
                metaci.setPageNum(request.getPageNum());
                metaci.setPageSize(request.getPageSize());
            }
            DMMetaAction action=metaci.buildAssignAction(request.getAction());
            if(action.getType().equals(DMMetaAction.TYPE_DEVICE)){
                response=new DataHandlerWithDevice(metaci,request).execute();
            }else{
                response=new DataHandlerWithOm(metaci,request).execute();
            }
            for(DmmRspFilter filter:this.rspFilters){
                filter.filter(request,response);
            }
        }catch (RuntimeException e){
            response.setCode(DMMResponse.NOK);
            response.setMsg(e.getMessage());
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DMMResponse.NOK);
            response.setMsg(MessageUtils.getMessage("ies.cm.dmm.msg.handler.operationException"));
        }
        return response;
    }
}
