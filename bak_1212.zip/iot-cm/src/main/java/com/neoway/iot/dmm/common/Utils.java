package com.neoway.iot.dmm.common;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.LongSerializationPolicy;

/**
 * @desc: Utils
 * @author: 20200312686
 * @date: 2020/7/21 17:00
 */
public class Utils {
    public static final String R_PRODUCT="ies";
    public static final String R_CATEGORY="urm";
    public static final String R_CM="cm";
    public static final String Meta_CI_KEY = "ies.urm.%.metaCI";
    public static Gson getJsonUtil(){
        Gson gson=new GsonBuilder()
                .setDateFormat("yyyy-MM-dd HH:mm:ss")
                .setLongSerializationPolicy(LongSerializationPolicy.STRING)
                .create();
        return gson;

    }
}
