package com.neoway.iot.dmm.handler;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.dmm.common.Utils;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * @desc: 特殊处理类
 * @author: 20200312686
 * @date: 2020/7/28 16:39
 */
public class DataHandlerWithOmSpecial {
    private static final Logger LOG = LoggerFactory.getLogger(DataHandlerWithOmSpecial.class);
    private DMRunner runner;
    private DMMetaCI metaCI;
    private DMMRequest req;
    public DataHandlerWithOmSpecial(DMMetaCI metaCI,DMMRequest req){
        runner=DMRunner.getInstance();
        this.metaCI=metaCI;
        this.req=req;
    }
    public DMMResponse execute(){
        DMMResponse response=new DMMResponse();
        DMMetaAction action=metaCI.buildAssignAction(req.getAction());
        //资源分组的search操作是需要执行分组的sql进行数据查询
        if(metaCI.getNs().equalsIgnoreCase(Utils.R_PRODUCT)
                && metaCI.getCategory().equalsIgnoreCase(Utils.R_CM)
                && metaCI.getCi().equalsIgnoreCase("Tag")
                && action.getId().equalsIgnoreCase("Search")){
            Map<String,Object> dc=(Map<String,Object>)req.getData();
            DMDataPoint point=DMDataPoint.builder(this.metaCI);
            point.buildColumns(dc);
            DMDataPoint dpoint=runner.get(point);
            if(null == dpoint){
                return response;
            }
            String sql=String.valueOf(dpoint.getDataColumn("el").value);
            if ("null" .equals(sql)) {
                response.setMsg(MessageUtils.getMessage("ies.cm.dmm.msg.handler.notExistSql"));
                return response;
            }
            LOG.info("SQL={}",sql);
            List<Map<String,Object>> results=runner.executeSQL(sql);
            response.setData(results);
            response.setNeedFilter(false);
        }else{
            response.setCode(DMMResponse.NOK);
            response.setMsg(MessageUtils.getMessage("ies.cm.dmm.msg.handler.notSupportAction"));
        }
        return response;
    }
}
