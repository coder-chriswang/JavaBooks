package com.neoway.iot.dmm.handler;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.dmm.common.Utils;
import com.neoway.iot.sdk.dmk.meta.DMMetaAction;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import com.neoway.iot.sdk.mnk.util.MessageUtils;
import com.neoway.iot.sdk.roa.ROAClient;
import com.neoway.iot.sdk.roa.ROAResult;
import org.aspectj.bridge.MessageUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: DataHandlerWithDevice
 * @author: 20200312686
 * @date: 2020/7/27 17:05
 */
public class DataHandlerWithDevice {
    private static final Logger LOG = LoggerFactory.getLogger(DataHandlerWithDevice.class);
    private DMMetaCI metaCI;
    private DMMRequest req;

    public DataHandlerWithDevice(DMMetaCI metaCI,DMMRequest req){
        this.metaCI=metaCI;
        this.req=req;
    }

    /**
     * @desc 设备操作指令下发
     * @return
     */
    public DMMResponse execute(){
        String paramJson=buildParam(this.req);
        DMMResponse response=new DMMResponse();
        try{
            ROAResult result=ROAClient.sendPostJson("/dgw/v1/command",paramJson);
            if(result.getStatusCode() != 200){
                response.setCode(result.getStatusCode());
                response.setMsg(MessageUtils.getMessage("ies.cm.dmm.msg.handler.accessGwErro"));
            }else{
                String respnseBody=result.getStringContent();
                response=Utils.getJsonUtil().fromJson(respnseBody,DMMResponse.class);
            }
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DMMResponse.NOK);
            response.setMsg(e.getMessage());
        }
        return response;
    }

    /**
     * @desc 构建请求参数
     * @param req
     * @return
     */
    private String buildParam(DMMRequest req){
        DMMetaAction action=this.metaCI.buildAssignAction(req.getAction());
        Map<String,Object> paramMap=new HashMap<>();
        paramMap.put("product",this.metaCI.getNs());
        paramMap.put("templateid",action.getTemplateid());
        paramMap.put("data",req.getData());
        return Utils.getJsonUtil().toJson(paramMap);
    }
}
