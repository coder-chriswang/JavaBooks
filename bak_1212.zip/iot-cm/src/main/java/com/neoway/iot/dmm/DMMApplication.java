package com.neoway.iot.dmm;

import com.neoway.iot.sdk.mnk.DMI18nInitiator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;


@SpringBootApplication(scanBasePackages = {"com.neoway.iot"})
public class DMMApplication implements CommandLineRunner {
	private static final Logger LOG = LoggerFactory.getLogger(DMMApplication.class);
	@Autowired
	private Environment env;

	public static void main(String[] args) {
		SpringApplication.run(DMMApplication.class, args);
	}
	@Override
	public void run(String... strings) throws Exception {
		LOG.info("国际化词条开始加载");
		DMI18nInitiator.getInstance().start(env);
		LOG.info("国际化词条加载成功");
		LOG.info("DMM开始启动");
		DMMManager.getInstance().start(env);
		LOG.info("DMM启动成功");
	}
}
