package com.neoway;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * 
 * 文件配置中心服务
 * @author guojy
 * @version V1.0.0-RELEASE 日期：2017年12月25日
 * @since 1.0.0-RELEASE
 */
@EnableConfigServer
@SpringBootApplication
public class ApplicationConfig {

	public static void main(String[] args) {
		new SpringApplicationBuilder(ApplicationConfig.class).web(true).run(args);
	}

}
