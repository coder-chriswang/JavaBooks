/**
 * @company 有方物联
 * @file EquRedisDaoImpl.java
 * @author guojy
 * @date 2018年4月12日 
 */
package com.neoway.car.logic.redis.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.neoway.car.logic.redis.ICarRedisDao;

/**
 * @description :终端设备redis缓存操作默认实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月12日
 */
@Component
public class CarRedisDaoImpl implements ICarRedisDao {
	@Resource
	private StringRedisTemplate template;

	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.ICarRedisDao#updateCarState(java.lang.String, java.util.Map)
	 */
	@Override
	public void updateCarState(String carId, Map<String, String> value) {
		this.template.boundHashOps("etiot:car:state:" + carId).putAll(value);
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.ICarRedisDao#getCarInfoByCarId(java.lang.String)
	 */
	@Override
	public Map<String, String> getCarInfoByCarId(String carId) {
		Map<String, String> carInfo =  this.template.<String, String>boundHashOps("etiot:car:info:" + carId).entries();
		if(carInfo == null){
			//查询数据库 缓存redis
			//this.updateCarState(carId, value);
		}
		return carInfo;
	}
}
