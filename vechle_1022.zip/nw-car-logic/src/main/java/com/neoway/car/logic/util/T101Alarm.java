package com.neoway.car.logic.util;

/**
 * <pre>
 *  描述: T101报警类型
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/04 15:34
 */
public class T101Alarm extends AbstractBitTool {

    /**
     * 震动报警
     * @param alarm
     * @return
     */
    public static byte alarm3(long alarm) {
        return convert(alarm, 3, 1);
    }

    /**
     * 温度报警
     * @param alarm
     * @return
     */
    public static byte alarm4(long alarm) {
        return convert(alarm, 4, 1);
    }

    /**
     * 拆机报警
     * @param alarm
     * @return
     */
    public static byte alarm5(long alarm) {
        return convert(alarm, 5, 1);
    }

    /**
     * 低电量报警
     * @param alarm
     * @return
     */
    public static byte alarm6(long alarm) {
        return convert(alarm, 6, 1);
    }
}
