/**
 * @company 有方物联
 * @file OfflineTaskListener.java
 * @author guojy
 * @date 2018年4月28日 
 */
package com.neoway.car.logic.listener;

import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neoway.car.logic.dao.IDeviceOrderDao;
import com.neoway.car.logic.dao.IRailDao;
import com.neoway.car.logic.dao.IRuleDao;
import com.neoway.car.logic.util.JsonTools;
import com.neoway.util.ObjectUtils;
import com.neoway.util.gps.Gps;
import com.neoway.util.gps.GpsCoordinateUtil;

/**
 * @description :设备离线任务指令处理
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月28日
 */
@Component
public class OfflineTaskListener {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IRailDao railDao;
	@Autowired
	private IRuleDao ruleDao;
	@Autowired
	private IDeviceOrderDao orderDao;
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	@RabbitListener(bindings={@org.springframework.amqp.rabbit.annotation.QueueBinding(value=@org.springframework.amqp.rabbit.annotation.Queue(value="carOfflineTaskQueue", durable="true"), exchange=@org.springframework.amqp.rabbit.annotation.Exchange(value="carOfflineTask", type="fanout", durable="true"))})
	public void task(String message){
		logger.info("设备离线指令处理 ：{}", message);
		Map<String, String> taskIn = JsonTools.toMap(message);
		
		if(taskIn == null || ObjectUtils.isNullOrEmptyString(taskIn.get("equId"))){
			return;
		}
		
		String equId = taskIn.get("equId");
		//1.查询设备离线围栏设置指令
		List<Map<String,Object>> taskList = railDao.findTodoRailTasks(equId);
		railCmdDown(taskList, equId);
		
		//2.查询规则下发表
		List<Map<String, Object>> ruleTaskList = ruleDao.findTodoRuleTasks(equId);
		ruleCmdDown(ruleTaskList,equId);
		
		//3.查询操作指令记录，并下发
		deviceOrderCmdDown(equId);
		
	}
	
	/**
	 * 规则下发任务
	 * @param ruleTaskList
	 * @param equId
	 */
	private void ruleCmdDown(List<Map<String, Object>> ruleTaskList, String equId) {
		if(ruleTaskList == null || ruleTaskList.size() < 1){
			return;
		}
		Map<String,Object> headMap = Maps.newHashMap();
		headMap.put("equId", equId);
		headMap.put("cmd", "setParam");
		headMap.put("phone",  ruleTaskList.get(0).get("phone").toString());
		
		Map<String, String> paramMap = new HashMap<String, String>();
		
		String fatigueMsgId = "";//疲劳驾驶消息ID
		String speedMsgId = "";//超速消息ID
		for(Map<String,Object> task : ruleTaskList){
			if(task.get("paramCode").toString().equals("drivingDuration")){
				fatigueMsgId = task.get("id").toString();
			}
			if(task.get("paramCode").toString().equals("speedLimit")){
				speedMsgId = task.get("id").toString();
			}
			paramMap.put(task.get("paramCode").toString(), task.get("paramVal").toString());
		}
		
		if(paramMap.containsKey("drivingDuration") && paramMap.containsKey("restDuration")){
			headMap.put("msgId", fatigueMsgId);
			Map<String,String> bodyFatigueMap = Maps.newHashMap();
			bodyFatigueMap.put("paramType", "fatigue");//疲劳驾驶
			bodyFatigueMap.put("drivingDuration", paramMap.get("drivingDuration"));
			bodyFatigueMap.put("restDuration", paramMap.get("restDuration"));
			
			byte[] bodyFatigue = JsonTools.toJsonStr(bodyFatigueMap).getBytes(Charset.forName("utf-8"));
			rabbitTemplate.send("carDownCommand", "jt808", MessageBuilder.withBody(bodyFatigue).copyHeaders(headMap).setContentType(MessageProperties.CONTENT_TYPE_TEXT_PLAIN).build());
		}
		if(paramMap.containsKey("speedLimit") && paramMap.containsKey("speedDuration")){
			headMap.put("msgId", speedMsgId);
			Map<String,String> bodySpeedMap = Maps.newHashMap();
			bodySpeedMap.put("paramType", "speed");//超速
			bodySpeedMap.put("speedLimit", paramMap.get("speedLimit"));
			bodySpeedMap.put("speedDuration", paramMap.get("speedDuration"));
			
			byte[] bodySpeed = JsonTools.toJsonStr(bodySpeedMap).getBytes(Charset.forName("utf-8"));
			rabbitTemplate.send("carDownCommand", "jt808", MessageBuilder.withBody(bodySpeed).copyHeaders(headMap).setContentType(MessageProperties.CONTENT_TYPE_TEXT_PLAIN).build());
		}
	}

	/**
	 * 围栏任务
	 * @param taskList
	 * @param equId
	 */
	private void railCmdDown(List<Map<String,Object>> taskList,String equId){
		if(taskList == null || taskList.size() <1){
			return;
		}
		try {
			for(Map<String,Object> task:taskList){
				String uuid = task.get("id").toString();
				String phone = task.get("phone").toString();
				String operType = task.getOrDefault("operType", "").toString();
				String railShape = task.get("railShape").toString();
				
				Map<String,Object> headMap = Maps.newHashMap();
				headMap.put("msgId", uuid);
				headMap.put("equId", equId);
				headMap.put("phone", phone);
				
				Map<String,String> bodyMap = Maps.newHashMap();
				bodyMap.put("railType", railShape);
				if(operType.equals("ADD") || operType.equals("MODIFY")){
					headMap.put("cmd", "setElecFence");
					bodyMap.put("attr", operType.equals("ADD")?"1":operType.equals("MODIFY")?"2":"");
					List<Map<String,String>> data = Lists.newArrayList();
					
					String railVal = task.get("railVal").toString();//围栏值
					JSONObject val = JSONObject.parseObject(railVal);
					DecimalFormat df = new DecimalFormat("#");
					if(railShape.equals("circle")){//圆
						Map<String,String> childMap = Maps.newHashMap();
						childMap.put("areaId", task.get("areaId").toString());//区域ID
						childMap.put("timerFlag", task.get("timerFlag").toString());//时间开关  0.关   1.启用
						childMap.put("speedFlag", task.get("speedFlag").toString());//限速开关  0.关   1.启用
						childMap.put("inAlarmDriver", task.get("inAlarmDriver").toString());//进入提醒开关  0.关   1.启用
						childMap.put("inAlarmPlantform", task.get("inAlarmPlantform").toString());//进入报警开关  0.关   1.启用
						childMap.put("outAlarmDriver", task.get("outAlarmDriver").toString());//出区提醒开关  0.关   1.启用
						childMap.put("outAlarmPlantform", task.get("outAlarmPlantform").toString());//出区报警开关  0.关   1.启用
						if(task.get("timerFlag").toString().equals("1")){
							childMap.put("startTime", task.getOrDefault("startTime", "").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
							childMap.put("endTime", task.getOrDefault("endTime","").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
						}
						if(task.get("speedFlag").toString().equals("1")){
							childMap.put("speed", df.format(task.getOrDefault("speed","0")));
							childMap.put("duration", df.format(task.getOrDefault("duration","0")));
						}
						if(val.getString("type").equals("bd09")){
							Gps gps = GpsCoordinateUtil.bd09_To_Gps84(Double.parseDouble(val.getString("centerLat")), Double.parseDouble(val.getString("centerLng")));
							childMap.put("radius", val.getString("radius"));
							childMap.put("lat", df.format(Math.round(gps.getWgLat() * Math.pow(10, 6)) ));
							childMap.put("lng", df.format(Math.round(gps.getWgLon() * Math.pow(10, 6)) ));

							data.add(childMap);
						}
					}else if(railShape.equals("rectangle")){//矩形
						Map<String,String> childMap = Maps.newHashMap();
						childMap.put("areaId", task.get("areaId").toString());//区域ID
						childMap.put("timerFlag", task.get("timerFlag").toString());//时间开关  0.关   1.启用
						childMap.put("speedFlag", task.get("speedFlag").toString());//限速开关  0.关   1.启用
						childMap.put("inAlarmDriver", task.get("inAlarmDriver").toString());//进入提醒开关  0.关   1.启用
						childMap.put("inAlarmPlantform", task.get("inAlarmPlantform").toString());//进入报警开关  0.关   1.启用
						childMap.put("outAlarmDriver", task.get("outAlarmDriver").toString());//出区提醒开关  0.关   1.启用
						childMap.put("outAlarmPlantform", task.get("outAlarmPlantform").toString());//出区报警开关  0.关   1.启用
						if(task.get("timerFlag").toString().equals("1")){
							childMap.put("startTime", task.getOrDefault("startTime", "").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
							childMap.put("endTime", task.getOrDefault("endTime","").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
						}
						if(task.get("speedFlag").toString().equals("1")){
							childMap.put("speed", df.format(task.getOrDefault("speed","0")));
							childMap.put("duration", df.format(task.getOrDefault("duration","0")));
						}
						
						String points=val.getString("points");
						childMap.put("areaId", task.get("areaId").toString());//区域ID
						childMap.put("timerFlag", task.get("timerFlag").toString());//时间开关  0.关   1.启用
						childMap.put("speedFlag", task.get("speedFlag").toString());//限速开关  0.关   1.启用
						childMap.put("inAlarmDriver", task.get("inAlarmDriver").toString());//进入提醒开关  0.关   1.启用
						childMap.put("inAlarmPlantform", task.get("inAlarmPlantform").toString());//进入报警开关  0.关   1.启用
						childMap.put("outAlarmDriver", task.get("outAlarmDriver").toString());//出区提醒开关  0.关   1.启用
						childMap.put("outAlarmPlantform", task.get("outAlarmPlantform").toString());//出区报警开关  0.关   1.启用
						if(task.get("timerFlag").toString().equals("1")){
							childMap.put("startTime", task.getOrDefault("startTime", "").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
							childMap.put("endTime", task.getOrDefault("endTime","").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
						}
						if(task.get("speedFlag").toString().equals("1")){
							childMap.put("speed", df.format(task.getOrDefault("speed","0")));
							childMap.put("duration", df.format(task.getOrDefault("duration","0")));
						}
						ObjectMapper mapper = new ObjectMapper();
						List<Map<String,String>> resultList = mapper.readValue(points, new TypeReference<List<Map<String,String>>>() {});
						if(StringUtils.isNotBlank(resultList.get(0).get("lat"))&&StringUtils.isNotBlank(resultList.get(0).get("lng"))){
							if(val.getString("type").equals("bd09")){
								Gps gps1=GpsCoordinateUtil.bd09_To_Gps84(Double.valueOf(resultList.get(0).get("lat")), Double.valueOf(resultList.get(0).get("lng")));
								childMap.put("upperLeftLat", df.format(gps1.getWgLat() * Math.pow(10, 6)));
								childMap.put("upperLeftLng", df.format(gps1.getWgLon() * Math.pow(10, 6)));
								Gps gps2=GpsCoordinateUtil.bd09_To_Gps84(Double.valueOf(resultList.get(2).get("lat")), Double.valueOf(resultList.get(2).get("lng")));
								childMap.put("downRightLat", df.format(gps2.getWgLat() * Math.pow(10, 6)));
								childMap.put("downRightLng", df.format(gps2.getWgLon() * Math.pow(10, 6)));

								data.add(childMap);
							}
						}
					}else if(railShape.equals("polygon")){//多边形
						bodyMap.put("areaId", task.get("areaId").toString());//区域ID
						bodyMap.put("timerFlag", task.get("timerFlag").toString());//时间开关  0.关   1.启用
						bodyMap.put("speedFlag", task.get("speedFlag").toString());//限速开关  0.关   1.启用
						bodyMap.put("inAlarmDriver", task.get("inAlarmDriver").toString());//进入提醒开关  0.关   1.启用
						bodyMap.put("inAlarmPlantform", task.get("inAlarmPlantform").toString());//进入报警开关  0.关   1.启用
						bodyMap.put("outAlarmDriver", task.get("outAlarmDriver").toString());//出区提醒开关  0.关   1.启用
						bodyMap.put("outAlarmPlantform", task.get("outAlarmPlantform").toString());//出区报警开关  0.关   1.启用
						if(task.get("timerFlag").toString().equals("1")){
							bodyMap.put("startTime", task.getOrDefault("startTime", "").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
							bodyMap.put("endTime", task.getOrDefault("endTime","").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
						}
						if(task.get("speedFlag").toString().equals("1")){
							bodyMap.put("speed", df.format(task.getOrDefault("speed","0")));
							bodyMap.put("duration", df.format(task.getOrDefault("duration","0")));
						}
						String points=val.getString("points");
						ObjectMapper mapper = new ObjectMapper();
						List<Map<String,String>> resultList = mapper.readValue(points, new TypeReference<List<Map<String,String>>>() {});
						for (Map<String, String> map2 : resultList) {
							if(StringUtils.isNotBlank(map2.get("lat"))&&StringUtils.isNotBlank(map2.get("lng"))){
								if(val.getString("type").equals("bd09")){
									Map<String,String> gpsMap=new HashMap<>();
									Gps gps1=GpsCoordinateUtil.bd09_To_Gps84(Double.valueOf(map2.get("lat")), Double.valueOf(map2.get("lng")));
									gpsMap.put("lat", df.format(gps1.getWgLat() * Math.pow(10, 6)));
									gpsMap.put("lng", df.format(gps1.getWgLon() * Math.pow(10, 6)));
									
									data.add(gpsMap);
								}
							}
						}
					}else if(railShape.equals("polyline")){//线路
						bodyMap.put("lineId", task.get("areaId").toString());//线路ID
						bodyMap.put("timerFlag", task.get("timerFlag").toString());//时间开关  0.关   1.启用
						bodyMap.put("speedFlag", task.get("speedFlag").toString());//限速开关  0.关   1.启用
						bodyMap.put("inAlarmDriver", task.get("inAlarmDriver").toString());//进入提醒开关  0.关   1.启用
						bodyMap.put("inAlarmPlantform", task.get("inAlarmPlantform").toString());//进入报警开关  0.关   1.启用
						bodyMap.put("outAlarmDriver", task.get("outAlarmDriver").toString());//出区提醒开关  0.关   1.启用
						bodyMap.put("outAlarmPlantform", task.get("outAlarmPlantform").toString());//出区报警开关  0.关   1.启用
						if(task.get("timerFlag").toString().equals("1")){
							bodyMap.put("startTime", task.getOrDefault("startTime", "").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
							bodyMap.put("endTime", task.getOrDefault("endTime","").toString().replaceAll(" ", "").replaceAll("-", "").replaceAll(":", ""));
						}
						String points=val.getString("points");
						ObjectMapper mapper = new ObjectMapper();
						List<Map<String,String>> resultList = mapper.readValue(points, new TypeReference<List<Map<String,String>>>() {});
						if(val.getString("type").equals("bd09")){
							for (Map<String, String> map2 : resultList) {
								if(StringUtils.isNotBlank(map2.get("lat"))&&StringUtils.isNotBlank(map2.get("lng"))){
									Map<String,String> dataMap=new HashMap<>();
										Gps gps1=GpsCoordinateUtil.bd09_To_Gps84(Double.valueOf(map2.get("lat")), Double.valueOf(map2.get("lng")));
										dataMap.put("lat", df.format(gps1.getWgLat()*1000000));
										dataMap.put("lng", df.format(gps1.getWgLon()*1000000));
										dataMap.put("inflexId", createRandomId());
										dataMap.put("roadId", createRandomId());
										if(task.get("speedFlag").toString().equals("1")){
											dataMap.put("speed", df.format(task.getOrDefault("speed","0")));
											dataMap.put("duration", df.format(task.getOrDefault("duration","0")));
										}
										dataMap.put("roadWide", "20");//TODO:线路宽度,暂时给默认值20
										if(task.get("timerFlag").toString().equals("1")){
											dataMap.put("tooLong", "60");
											dataMap.put("tooShort", "30");
										}
										
										data.add(dataMap);
								}
							}
						}
					}else{
						return;
					}
					bodyMap.put("data", JSON.toJSONString(data));
				}else{
					headMap.put("cmd", "unbindElecFence");
					bodyMap.put("railType", railShape);
					bodyMap.put("size", "1");
					bodyMap.put("areaIds", task.get("areaId").toString());
				}
				byte[] body = JsonTools.toJsonStr(bodyMap).getBytes(Charset.forName("utf-8"));
				rabbitTemplate.send("carDownCommand", "jt808", MessageBuilder.withBody(body).copyHeaders(headMap).setContentType(MessageProperties.CONTENT_TYPE_TEXT_PLAIN).build());
			}
		} catch (Exception e) {
			logger.error("电子围栏下发离线任务执行异常：{}",e);
		}
		
	}
	
	/**
	 * 设备指令参数下发
	 * @author bailu
	 */
	private void deviceOrderCmdDown(String equId){
		//部标服务器设置 lbsServerCfg 车辆信息配置 carInfoCfg 上报策略配置 reportStrategy sbh固件升级sbhDeviceUpdate
		List<Map<String, Object>> orderList = orderDao.findToDoOrderList(equId);
		if(orderList == null || orderList.size() < 1 || orderList.get(0).get("phone") == null){
			return;
		}
		
		Map<String,Object> headMap = Maps.newHashMap();
		headMap.put("equId", equId);
		headMap.put("cmd", "setParam");
		headMap.put("phone",  orderList.get(0).get("phone").toString());
		
		List<Map<String, Object>> sbhList = Lists.newArrayList();
		for (Map<String, Object> orderMap : orderList) {
			if("sbhDeviceUpdate".equals(orderMap.get("order_type"))){
				sbhList.add(orderMap);
				continue;
			}
			List<Map<String, Object>> paramList = orderDao.findParamsByOrderId(orderMap.get("order_id").toString());
			if (paramList == null || paramList.size() < 1) {
				continue;
			}
			headMap.put("msgId", orderMap.get("order_id").toString());
			List<Map<String, String>> paramMqList = new ArrayList<Map<String, String>>();
			for (Map<String, Object> param : paramList) {
				Map<String,String> paramMap = new HashMap<String,String>();
				paramMap.put("key", param.get("param_code").toString());
				paramMap.put("val", param.get("param_value").toString());
				paramMqList.add(paramMap);
			}
			Map<String,String> bodyMap = Maps.newHashMap();
			bodyMap.put("params",  JSONArray.toJSONString(paramMqList));
			bodyMap.put("paramType", "");
			byte[] bodySpeed = JsonTools.toJsonStr(bodyMap).getBytes(Charset.forName("utf-8"));
			rabbitTemplate.send("carDownCommand", "jt808", MessageBuilder.withBody(bodySpeed).copyHeaders(headMap).setContentType(MessageProperties.CONTENT_TYPE_TEXT_PLAIN).build());
		}
		
		//思博慧固件升级
		headMap.put("cmd", "sbhDeviceUpdate");
		for (Map<String, Object> orderMap : sbhList) {
			List<Map<String, Object>> paramList = orderDao.findParamsByOrderId(orderMap.get("order_id").toString());
			if (paramList == null || paramList.size() < 1) {
				continue;
			}
			headMap.put("msgId", orderMap.get("order_id").toString());
			Map<String,String> bodyMap = Maps.newHashMap();
			Object url = paramList.get(0).get("param_value");
			bodyMap.put("url", String.valueOf(url));
			byte[] body = JsonTools.toJsonStr(bodyMap).getBytes(Charset.forName("utf-8"));
			rabbitTemplate.send("carDownCommand", "jt808", MessageBuilder.withBody(body).copyHeaders(headMap).setContentType(MessageProperties.CONTENT_TYPE_TEXT_PLAIN).build());
		}
		
	}
	
	/**
	 * 根据指定长度生成纯数字的随机数
	 * @return String
	 */
	private String createRandomId() {
		StringBuilder sb=new StringBuilder();
		Random rand=new Random();
		for(int i=0;i<9;i++) {
			sb.append(rand.nextInt(10));
		}
		String data=sb.toString();
		        
		return data;
	}
}
