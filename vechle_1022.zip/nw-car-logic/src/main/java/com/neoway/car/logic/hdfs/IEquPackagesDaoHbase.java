/**
 * @company 有方物联
 * @file IEquPackagesHbase.java
 * @author guojy
 * @date 2018年7月24日 
 */
package com.neoway.car.logic.hdfs;

import java.io.IOException;
import java.util.Map;

/**
 * @description :设备报文数据Hbase存储接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月24日
 */
public interface IEquPackagesDaoHbase {
	/**
	 * 设备报文数据存储hbase
	 * @param equId 设备ID  作为hbase的rowkey
	 * @param paramMap 数据
	 * @throws IOException
	 */
	public void insert(String equId, Map<String, String> paramMap);
}
