package com.neoway.car.logic.util;

/**
 * <pre>
 *  描述: OBD扩展状态位
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/04 14:44
 */
public class ObdState extends AbstractBitTool {

    /**
     * 3D传感器正常0
     * @param state
     * @return
     */
    public static byte state0(long state) {
        return convert(state, 0, 1);
    }

    /**
     * RTC模块正常0
     * @param state
     * @return
     */
    public static byte state1(long state) {
        return convert(state, 1, 1);
    }

    /**
     * FLASH正常0
     * @param state
     * @return
     */
    public static byte state2(long state) {
        return convert(state , 2, 1);
    }

    /**
     * GPS模块正常0
     * @param state
     * @return
     */
    public static byte state3(long state) {
        return convert(state, 3, 1);
    }

    /**
     * CAN模块正常0
     * @param state
     * @return
     */
    public static byte state4(long state) {
        return convert(state, 4, 1);
    }

    /**
     * OBD适配0
     * @param state
     * @return
     */
    public static byte state5(long state) {
        return convert(state, 5, 1);
    }

    /**
     * 总线睡眠正常0
     * @param state
     * @return
     */
    public static byte state6(long state) {
        return convert(state, 6, 1);
    }
}
