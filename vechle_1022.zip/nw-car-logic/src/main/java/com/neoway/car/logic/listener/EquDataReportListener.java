/**
 * @company 有方物联
 * @file EquLocaltionReportListener.java
 * @author guojy
 * @date 2018年4月11日
 */
package com.neoway.car.logic.listener;

import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.neoway.car.logic.dao.IAlarmDao;
import com.neoway.car.logic.dao.IEquDao;
import com.neoway.car.logic.entity.AlarmStartEntity;
import com.neoway.car.logic.hdfs.IPositionDaoHBase;
import com.neoway.car.logic.redis.IAccountRedisDao;
import com.neoway.car.logic.redis.IEquAlarmRedisDao;
import com.neoway.car.logic.redis.IEquRedisDao;
import com.neoway.car.logic.util.*;
import com.neoway.util.DateUtil;
import com.neoway.util.StringUtil;
import com.neoway.util.gps.MapMath;
import com.neoway.util.hex.HexStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.*;

/**
 * @description :设备数据上报
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
@Component
public class EquDataReportListener {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    // 告警字符串前缀
    private final static String ALARMTYPE_PREFIX = "at_";

    @Autowired
    private IEquRedisDao equRedisDao;
    @Autowired
    private IEquDao equDao;
    @Autowired
    private IAlarmDao alarmDao;
    @Autowired
    private IPositionDaoHBase positionDaoHBase;
    @Autowired
    private IEquAlarmRedisDao equAlarmRedisDao;
    @Autowired
    private IAccountRedisDao accountRedisDao;
    @Autowired
    private BaiduMapTools baiduMapTools;
    /**
     * JT808设备注册（消费端）RPC消息
     * @param message
     * @return
     */
    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_registerQueue_jt808", durable = "true"), exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_register", type = "direct", durable = "true"), key = "jt808") })
    public String register(String message){
        logger.info("设备注册接收消息={}", message);
        Map<String, String> regIn = JsonTools.toMap(message);
        Map<String, String> regOut = Maps.newHashMap();
        //数据库中设备信息
        Map<String, Object> equMap = equDao.queryEquByPhone(regIn.get("phone"));
        if(equMap == null){
            regOut.put("result", "4");
        }else{
            Object authCodeObj = equMap.get("authCode");//数据库中的鉴权码
            String authCode = null;
            if(authCodeObj == null){
                authCode = String.valueOf(System.nanoTime());//系统生成鉴权码
                equDao.updateAuthCode(String.valueOf(equMap.get("equId")), authCode);
            }else{
                authCode = String.valueOf(authCodeObj);
            }
            regOut.put("result", "0");
            regOut.put("authCode", authCode);
        }
        String result = JSON.toJSONString(regOut);
        logger.info("设备号：{}的注册结果：{}", regIn.get("phone"),result);
        return result;
    }

    /**
     * 终端鉴权RPC消息消费
     * @param message
     * @return
     */
    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_authQueue_jt808", durable = "true"), exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_auth", type = "direct", durable = "true"), key = "jt808") })
    public String auth(String message){
        logger.info("设备鉴权接收消息={}", message);
        Map<String, String> authIn = JsonTools.toMap(message);
        String phone = authIn.get("phone");
        Map<String,String> authOut = Maps.newHashMap();
        // 车辆设备信息
        Map<String, Object> carEquMap = equDao.queryCarEquByPhone(phone);
        if(carEquMap == null){
            authOut.put("result", "1");
            logger.error("设备鉴权-平台不存在此终端，phone={}", phone);
//            authOut.put("result", "0");
//            authOut.put("equId", "123456789");
        }else{
            String carId = String.valueOf(carEquMap.getOrDefault("carId", ""));
            String equId = String.valueOf(carEquMap.get("equId"));
            Object authCodeObj = carEquMap.get("authCode");//数据库中的鉴权码
            String deptId = String.valueOf(carEquMap.get("deptId"));
            Map<String, String> equStatus = equRedisDao.findEquStatusByID(equId);
            String online = equStatus.getOrDefault("online", "0");
            if("1".equals(online)){
                authOut.put("result", "1");
                String linkTime = equStatus.getOrDefault("linkTime", "");
                long sec = DateUtil.getDistanceSec(linkTime, DateUtil.TIME_HAVINTERVAL);
                if(sec >= 60 * 3){
                    Map<String, String> equState = Maps.newHashMap();
                    equState.put("online", "0");
                    equRedisDao.updateEquState(equId, equState);
                    logger.info("强制更新设备状态为离线 设备ID：{}", equId);
                }
            }else if("0".equals(online) && authIn.get("authCode").equals(authCodeObj)){
                authOut.put("result", "0");
                authOut.put("equId", equId);
                authOut.put("deptId", deptId);
                authOut.put("carId", carId);
                authOut.put("carNum", String.valueOf(carEquMap.getOrDefault("carNum", "")));
                Map<String, String> equState = Maps.newHashMap();//设备状态更新
                equState.put("online", "1");
                equState.put("linkTime", DateUtil.getSysStrCurrentDate(DateUtil.TIME_HAVINTERVAL));
                equRedisDao.updateEquState(equId, equState);//更新设备redis状态
            }else{
                authOut.put("result", "1");
                logger.info("鉴权码不一致！终端手机号：{}，平台鉴权码：{}，设备鉴权码：{}", phone,String.valueOf(authCodeObj),authIn.get("authCode"));
            }
        }
        String result = JSON.toJSONString(authOut);
        logger.info("设备号：{}的鉴权结果：{}", authIn.get("phone"),result);
        return result;
    }

    /**
     * 终端设备数据上报
     * @param message
     */
    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_dataReportQueue_jt808", durable = "true"), exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_dataReport", type = "direct", durable = "true"), key = "jt808") })
    public void dataReport(String message){
        logger.info("设备位置上报接收消息={}", message);
        Map<String, String> dataReportIn = JsonTools.toMap(message);
        Map<String,String> positionMap = Maps.newHashMap();
        String equId = dataReportIn.get("equId");
        String phone = dataReportIn.get("phone");
        Map<String,Object> equMap = equDao.queryEquByPhone(phone);
        if (equMap == null) {
            logger.error("位置信息上报-通过手机号查找不到对应的设备，phone={}",phone);
            return;
        }
        positionMap.put("phone", dataReportIn.get("phone"));
        positionMap.put("deptId", dataReportIn.get("deptId"));
        positionMap.put("carId", dataReportIn.get("carId"));
        positionMap.put("carNum", dataReportIn.get("carNum"));
        long alarm = Long.parseLong(dataReportIn.get("alarm"));
        logger.info("alarm:{}", HexStringUtils.toHexString(alarm, 4));
        // 状态
        long state = Long.parseLong(dataReportIn.get("state"));
        String alarmFlag = processAlarmFlag(alarm);
        String lbsFlag = processLbsFlag(state);
        positionMap.put("alarm", alarmFlag);
        positionMap.put("acc", String.valueOf(State.State0(state)));
        positionMap.put("lbsFlag", lbsFlag);
        // 南纬北纬
        String latitude_flag = State.State2(state) == 0?"+":"-";
        // 东经西经
        String longitude_flag = State.State3(state) == 0?"+":"-";
        // 计算经纬度  除10的6次方
        BigDecimal latitude = new BigDecimal(latitude_flag+dataReportIn.get("latitude"));
        latitude = latitude.divide(BigDecimal.valueOf(1000000L));
        BigDecimal longitude = new BigDecimal(longitude_flag+dataReportIn.get("longitude"));
        longitude = longitude.divide(BigDecimal.valueOf(1000000L));
        positionMap.put("latitude", latitude.toString());
        positionMap.put("longitude", longitude.toString());
        positionMap.put("altitude", dataReportIn.get("altitude"));
        positionMap.put("speed", dataReportIn.get("speed"));
        positionMap.put("direation", dataReportIn.get("direation"));
        positionMap.put("gpsTime", dataReportIn.get("gpsTime"));
        positionMap.put("linkTime", dataReportIn.get("gpsTime"));
        processAdditionalGps(dataReportIn, positionMap);
        try {
            equRedisDao.updateEquState(equId, positionMap);
        } catch (NullPointerException e) {
            logger.error("redis中不存在此设备id！equId={}", equId);
        } catch (Exception e) {
            logger.error("redis更新异常！", e);
        }
        if(State.State1(state) == 1){
            positionDaoHBase.insert(equId, positionMap);
        }
        Map<String, String> equAlarm = equAlarmRedisDao.getEquAlarmByEquId(equId);
        for (int j = 0; j < 32; j++) {
            if(j == 15 || j == 16 || j == 17){
                continue;
            }
            statusAlarm(equId,j, alarm, positionMap,equAlarm);
        }

        try {
            if(State.State1(state) == 1){
                trip(equId, positionMap);
            }
        } catch (Exception e) {
            logger.error("行程统计异常", e);
        }
    }

    /**
     *
     * @param equId 设备ID
     * @param alarmTypeIndex 告警状态索引位
     * @param alarm 告警状态
     * @param positionMap 位置数据
     * @param equAlarm 告警缓存数据（作用：对比处理告警是否结束）
     */
    private void statusAlarm(String equId,int alarmTypeIndex,long alarm,Map<String,String> positionMap,Map<String, String> equAlarm){
        //反射查找具体告警
        String methodName = "Alarm"+alarmTypeIndex;
        Method method = ReflectionUtils.findMethod(Alarm.class, methodName, long.class);
        Object rev = ReflectionUtils.invokeMethod(method, null, alarm);
        byte alarmType = Byte.parseByte(rev.toString());
        String alarmTypeOld = (String) equAlarm.getOrDefault(ALARMTYPE_PREFIX+alarmTypeIndex, "0");
        if ("0".equalsIgnoreCase(alarmTypeOld)) {
            if (1 == alarmType) {
                alarmBegin(positionMap, equId, alarmTypeIndex);
            }
        }else if(0 == alarmType){
            alarmEnd(positionMap, equAlarm, equId, alarmTypeIndex);
        }
    }

    /**
     * OBD扩展位置告警
     * @param equId
     * @param alarmTypeIndex
     * @param alarm
     * @param positionMap
     * @param equAlarm
     */
    private void statusObdAlarm(String equId,int alarmTypeIndex,long alarm,Map<String,String> positionMap,Map<String, String> equAlarm) {
        String methodName = "obdAlarm" + alarmTypeIndex;
        Method method = ReflectionUtils.findMethod(ObdAlarm.class, methodName, long.class);
        Object resultValue = ReflectionUtils.invokeMethod(method, null, alarm);
        byte alarmType = Byte.parseByte(resultValue.toString());
        // 转化为OBD告警数字
        alarmTypeIndex = Integer.valueOf("4" + alarmTypeIndex);
        String alarmTypeOld = equAlarm.getOrDefault(ALARMTYPE_PREFIX + alarmTypeIndex, "0");
        if ("0".equalsIgnoreCase(alarmTypeOld)) {
            if (1 == alarmType) {
                alarmBegin(positionMap, equId, alarmTypeIndex);
            }
        } else if(0 == alarmType){
            alarmEnd(positionMap, equAlarm, equId, alarmTypeIndex);
        }
    }

    /**
     * 开始告警
     * @param positionMap 定位数据
     * @param equId 设备ID
     * @param alarmTypeIndex 告警类型索引位
     */
    private void alarmBegin(Map<String,String> positionMap,String equId,int alarmTypeIndex){
        String alarmId = StringUtil.getUUID();
        Date startTime = DateUtil.formatStrToDate(positionMap.get("gpsTime"), DateUtil.TIME_HAVINTERVAL);
        String address = gpsToAddress(positionMap.get("longitude"), positionMap.get("latitude"));
        AlarmStartEntity alarmStartEntity = new AlarmStartEntity(alarmId, positionMap.get("carId"),equId,
                positionMap.get("deptId"), ALARMTYPE_PREFIX+alarmTypeIndex, startTime, positionMap.get("longitude"),
                positionMap.get("latitude"), address, "0", "", positionMap.get("acc"),
                positionMap.get("direation"), positionMap.get("gpsTime"), positionMap.get("speed"), positionMap.get("lbsFlag"),
                positionMap.get("mileage"), Constant.EQU_ONLINE, positionMap.get("simSignal"),
                null, positionMap.get("linkTime"), positionMap.get("satelliteNum"));
        HashMap<String, String> equAlarmMap = Maps.newHashMap();
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex, "1");
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_id", alarmId);
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_start_time", positionMap.get("gpsTime"));
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_start_longitude", positionMap.get("longitude"));
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_start_latitude", positionMap.get("latitude"));
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_speed", positionMap.get("speed"));
        equAlarmRedisDao.pushEquAlarm(equId, equAlarmMap);

        alarmDao.insertAlarmStart(alarmStartEntity);

        alarmRedisCacheAndNotice(alarmId, positionMap.get("deptId"), ALARMTYPE_PREFIX+alarmTypeIndex, positionMap.get("carId"), positionMap.get("carNum"), address, positionMap.get("gpsTime"));
    }

    /**
     * 结束告警
     * @param positionMap 位置数据
     * @param equAlarm 告警redis缓存
     * @param equId 设备ID
     * @param alarmTypeIndex 告警类型索引
     */
    private void alarmEnd(Map<String,String> positionMap,Map<String, String> equAlarm,String equId,int alarmTypeIndex){
        String address = "";
        Map<String,Object> alarmEndMap = Maps.newHashMap();
        String alarmId = equAlarm.get(ALARMTYPE_PREFIX+alarmTypeIndex + "_id");
        alarmEndMap.put("alarmId", alarmId);
        alarmEndMap.put("endTime", DateUtil.getDate());
        alarmEndMap.put("endAddress", address);
        alarmEndMap.put("longitude", positionMap.get("longitude"));
        alarmEndMap.put("latitude", positionMap.get("latitude"));
        alarmDao.insertAlarmEnd(alarmEndMap);

        Map<String, String> equAlarmMap = Maps.newHashMap();
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex, "0");
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_id", "");
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_start_time", "");
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_start_longitude", "");
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_start_latitude", "");
        equAlarmMap.put(ALARMTYPE_PREFIX+alarmTypeIndex + "_speed", "");
        equAlarmRedisDao.pushEquAlarm(equId, equAlarmMap);
    }

    /**
     * 设备离线
     * @param message
     * @throws Exception
     */
    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_offlineQueue", durable = "true"), exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_offline", type = "fanout", durable = "true")) })
    public void offline(String message) throws Exception{
        logger.info("设备离线接收消息={}", message);
        Map<String, String> offlineIn = JsonTools.toMap(message);
        String equId = offlineIn.get("equId");
        Map<String, String> equState = Maps.newHashMap();//设备状态更新
        equState.put("online", "0");
        equRedisDao.updateEquState(equId, equState);//更新设备redis状态
        //查询设备最新状态数据
        Map<String, String> equStatus = equRedisDao.findEquStatusByID(equId);
        Date now = DateUtil.getDate();
        String address = gpsToAddress(equStatus.get("longitude"), equStatus.get("latitude"));
        String alarmId = StringUtil.getUUID();
        AlarmStartEntity alarmStartEntity = new AlarmStartEntity(alarmId, equStatus.get("carId"),equId,
                offlineIn.get("deptId"), Constant.ALARM_TYPE_102, now, equStatus.get("longitude"),
                equStatus.get("latitude"), address, "0", "", equStatus.get("acc"),
                equStatus.get("direation"), equStatus.get("gpsTime"), equStatus.get("speed"), equStatus.get("lbsFlag"),
                equStatus.get("mileage"), equStatus.get("online"), equStatus.get("simSignal"),
                equStatus.get("idlingDuration"), equStatus.get("linkTime"),"0");
        //开始告警
        alarmDao.insertAlarmStart(alarmStartEntity);
        Map<String,Object> alarmEndMap = Maps.newHashMap();
        alarmEndMap.put("alarmId", alarmId);
        alarmEndMap.put("endTime", now);
        alarmEndMap.put("endAddress", address);
        alarmEndMap.put("longitude", equStatus.get("longitude"));
        alarmEndMap.put("latitude", equStatus.get("latitude"));
        //结束告警
        alarmDao.insertAlarmEnd(alarmEndMap);
        try {
            alarmRedisCacheAndNotice(alarmId, offlineIn.get("deptId"), Constant.ALARM_TYPE_102, offlineIn.get("carId"), offlineIn.get("carNum"), address, equStatus.getOrDefault("gpsTime", ""));
        } catch (NullPointerException e) {
            logger.error("告警信息存入redis报空指针异常！alarmId={}", alarmId);
        } catch (Exception e) {
            logger.error("告警信息存入redis存在异常！", e);
        }
        String endTimeStr = equStatus.getOrDefault("gpsTime", DateUtil.formatDateToStr(new Date(), DateUtil.TIME_HAVINTERVAL));
        Date endTime = DateUtil.formatStrToDate(endTimeStr, DateUtil.TIME_HAVINTERVAL);
        closeTrip(equId, equStatus.get("latitude"), equStatus.get("longitude"),endTime);
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_passThroughMessage_jt808", durable = "true"), exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_passThroughMessage", type = "direct", durable = "true"), key = "jt808") })
    public void handlePassThroughMessage(String message) {
        Map<String, String> dataMap = JsonTools.toMap(message);
        String phone = dataMap.get("phone");
        String equId = dataMap.get("equId");
        String carNum = dataMap.get("carNum");
        logger.info("数据上行透传消息！phone={}, equId={}, carNum={}", phone, equId, carNum);
        Map<String, Object> resultMap = Maps.newHashMap();
        resultMap.put("phone", phone);
        resultMap.put("equId", equId);
        resultMap.put("carNum", carNum);
        if (dataMap.containsKey("startMarch")) {
            String startMarch = dataMap.get("startMarch");
            Map<String, String> startMarchMap = JsonTools.toMap(startMarch);
            String time = startMarchMap.get("time");
            long state = Long.parseLong(startMarchMap.get("state"));
            String longitudeFlag = State.State1(state) == 0 ? "+":"-";
            String latitudeFlag = State.State0(state) == 0 ? "+":"-";
            // 计算经纬度  除10的6次方
            String latitude = new BigDecimal(latitudeFlag + startMarchMap.get("latitude")).divide(BigDecimal.valueOf(1000000L)).toString();
            String longitude = new BigDecimal(longitudeFlag + startMarchMap.get("longitude")).divide(BigDecimal.valueOf(1000000L)).toString();
            logger.info("行程开始数据：时间={}, 纬度={}{}, 经度={}{}", time, latitudeFlag, latitude, longitudeFlag, longitude);
            // 封装数据
            resultMap.put("startTime", cn.hutool.core.date.DateUtil.parse(time));
            resultMap.put("latitude", latitude);
            resultMap.put("longitude", longitude);
            // 存储行程开始数据
            equDao.insertStartTrip(resultMap);
        } else if (dataMap.containsKey("endMarch")) {
            String endMarch = dataMap.get("endMarch");
            Map<String, String> endMarchMap = JsonTools.toMap(endMarch);
            String time = endMarchMap.get("time");
            long state = Long.parseLong(endMarchMap.get("state"));
            String latitudeFlag = State.State0(state) == 0 ? "+":"-";
            String longitudeFlag = State.State1(state) == 0 ? "+":"-";
            // 计算经纬度  除10的6次方
            String longitude = new BigDecimal(longitudeFlag + endMarchMap.get("longitude")).divide(BigDecimal.valueOf(1000000L)).toString();
            String latitude = new BigDecimal(latitudeFlag + endMarchMap.get("latitude")).divide(BigDecimal.valueOf(1000000L)).toString();
            logger.info("行程结束数据：时间={}, 纬度={}{}, 经度={}{}", time, latitudeFlag, latitude, longitudeFlag, longitude);
            // 封装数据
            resultMap.put("endTime", cn.hutool.core.date.DateUtil.parse(time));
            resultMap.put("longitude", longitude);
            resultMap.put("latitude", latitude);
            // 存储行程结束数据
            equDao.insertEndTrip(resultMap);
        } else if (dataMap.containsKey("marchReport")) {
            String marchReport = dataMap.get("marchReport");
            Map<String, String> marchReportMap = JsonTools.toMap(marchReport);
            String startTime = marchReportMap.get("startTime");
            String endTime = marchReportMap.get("endTime");
            int distance = Integer.parseInt(marchReportMap.get("distance"));
            int oil = Integer.parseInt(marchReportMap.get("oil"));
            int idleSpeedSeconds = Integer.parseInt(marchReportMap.get("idleSpeedSeconds"));
            int idleOil = Integer.parseInt(marchReportMap.get("idleOil"));
            short maxSpeed = Short.parseShort(marchReportMap.get("maxSpeed"));
            int maxRpm = Integer.parseInt(marchReportMap.get("maxRpm"));
            logger.info("行程报告数据：开始时间={}, 结束时间={}, 行程距离={}Km, 行程燃油量={}mL", startTime, endTime, distance, oil);
            logger.info("行程报告数据：行程怠速时长={}s, 怠速累计油量={}mL, 最大速度={}km/h, 最大RPM={}", idleSpeedSeconds, idleOil, maxSpeed, maxRpm);
            // 封装数据
            resultMap.put("startTime", cn.hutool.core.date.DateUtil.parse(startTime));
            resultMap.put("endTime", cn.hutool.core.date.DateUtil.parse(endTime));
            resultMap.put("distance", String.valueOf(distance));
            resultMap.put("oil", String.valueOf(oil));
            resultMap.put("idleSpeedSeconds", String.valueOf(idleSpeedSeconds));
            resultMap.put("idleOil", String.valueOf(idleOil));
            resultMap.put("maxSpeed", String.valueOf(maxSpeed));
            resultMap.put("maxRpm", String.valueOf(maxRpm));
            // 存储总行程数据
            equDao.insertWholeTrip(resultMap);
        } else if (dataMap.containsKey("troubleCode")) {
            StringBuilder stringBuilder = new StringBuilder();
            String troubleCode = dataMap.get("troubleCode");
            Map<String, String> troubleCodeMap = JsonTools.toMap(troubleCode);
            String time = troubleCodeMap.get("time");
            short troubleCodeCount = Short.parseShort(troubleCodeMap.get("troubleCodeCount"));
            List<Integer> troubleCodeList = JSON.parseObject(troubleCodeMap.get("troubleCodeList"), new TypeReference<List<Integer>>(){});
            List<String> hexTroubleCodeList = new ArrayList<>();
            // 转成16进制码
            for (Integer a : troubleCodeList) {
                hexTroubleCodeList.add(Integer.toHexString(a).toUpperCase());
                stringBuilder.append(Integer.toHexString(a).toUpperCase()).append(",");
            }
            logger.info("故障包数据：时间={}, 故障码个数={}", time, troubleCodeCount);
            logger.info("故障包数据：故障码List={}", hexTroubleCodeList);
            // 封装数据
            resultMap.put("errorCodeNum", troubleCodeCount);
            if (troubleCodeCount == 0) {
                resultMap.put("errorCode", "");
            } else {
                resultMap.put("errorCode", stringBuilder.toString().substring(0, stringBuilder.lastIndexOf(",")));
            }
            // 存储故障码数据
            equDao.insertErrorCode(resultMap);
        } else if (dataMap.containsKey("terminalParams")) {
            String terminalParams = dataMap.get("terminalParams");
            Map<String, String> terminalParamsMap = JsonTools.toMap(terminalParams);
            String cmVerison = terminalParamsMap.get("communicationModuleVersion");
            String tswVersion = terminalParamsMap.get("terminalSoftwareVersion");
            String busType = terminalParamsMap.get("busProtocolType");
            String vin = terminalParamsMap.get("vin");
            String iccId = terminalParamsMap.get("iccId");
            String imsi = terminalParamsMap.get("imsi");
            String gsmImei = terminalParamsMap.get("gsmImei");
            logger.info("扩展终端属性数据：通讯模块版本号={}, 终端软件版本号={}, 总线类型={}", cmVerison, tswVersion, busType);
            logger.info("扩展终端属性数据：VIN码={}, ICCID={}, IMSI={}, GSM IMEI={}", vin, iccId, imsi, gsmImei);
            // 封装数据
            resultMap.put("communicationModuleVersion", cmVerison);
            resultMap.put("terminalSoftwareVersion", tswVersion);
            resultMap.put("busProtocolType", busType);
            resultMap.put("vin", vin);
            resultMap.put("iccId", iccId);
            resultMap.put("imsi", imsi);
            resultMap.put("gsmImei", gsmImei);
            // 存储终端扩展属性数据
            equDao.insertTerminalExtendProperty(resultMap);
        }

    }

    /**
     * notify admin
     * @param alarmId
     * @param deptId
     * @param alarmType
     * @param carId
     * @param carNum
     * @param address
     * @param gpsTime
     */
    private void alarmRedisCacheAndNotice(String alarmId,String deptId,String alarmType,String carId,String carNum,String address,String gpsTime){
        Map<String, String> alarmMap = Maps.newHashMap();
        alarmMap.put("alarmType", alarmType);
        alarmMap.put("carId", carId);
        alarmMap.put("carNum", carNum);
        alarmMap.put("startAddress", address);
        alarmMap.put("startTime", gpsTime);
        equAlarmRedisDao.insertAlarm(alarmId, alarmMap);
        Set<String> accountList = accountRedisDao.queryAccountsByDeptId(deptId);
        if(accountList != null){
            accountList.forEach(account ->{
                equAlarmRedisDao.insertAdminAlarmMsg(account, alarmId);
            });
        }
    }
    /**
     * 定位方式处理
     * @param state 设备上报状态位
     * @return
     */
    private String processLbsFlag(long state){
        String lbsFlag = String.valueOf(State.State1(state));
        logger.info("状态位={}",Long.toBinaryString(state));
        logger.info("定位状态={}",lbsFlag);
        logger.info("GPS卫星状态位={}",State.State18(state));
        if("1".equals(lbsFlag)){
            StringBuilder sbf = new StringBuilder();
            if(State.State18(state) == 1){
                sbf.append("1,");
            }
            if(State.State19(state) == 1){
                sbf.append("2,");
            }
            if(State.State20(state) == 1){
                sbf.append("3,");
            }
            if(State.State21(state) == 1){
                sbf.append("4,");
            }
            lbsFlag = sbf.toString();
        }
        return lbsFlag;
    }

    /**
     * 告警字符串处理
     * @param alarm
     * @return
     */
    public String processAlarmFlag(long alarm){
        //多个告警用逗号分隔
        StringBuilder sbuilder = new StringBuilder();
        for(int i=0;i<32;i++){
            if(i==15 || i==16 || i==17){
                continue;
            }
            byte tmpAlarm = Alarm.selectAlarm(alarm, i);
            if(tmpAlarm == 1){
                sbuilder.append(ALARMTYPE_PREFIX+i).append(",");
            }
        }
        return sbuilder.toString();
    }

    /**
     * 处理附加定位数据
     * @param dataReportIn 上报原始数据
     * @param positionMap 清洗后的数据
     */
    private void processAdditionalGps(Map<String, String> dataReportIn,Map<String,String> positionMap) {
        String equId = dataReportIn.get("equId");
        DecimalFormat df = new DecimalFormat("#.00");
        Map<String, Object> dataMap = Maps.newHashMap();
        dataMap.put("equId", equId);
        dataMap.put("carNum", positionMap.get("carNum"));
        dataMap.put("phone", positionMap.get("phone"));
        if(dataReportIn.containsKey("simSignal_additional")){
            String simSignal_additional = dataReportIn.get("simSignal_additional");
            Map<String, String> simSignalMap = JsonTools.toMap(simSignal_additional);
            positionMap.put("simSignal", simSignalMap.get("simSignal"));
        }
        if(dataReportIn.containsKey("satelliteNum_additional")){
            String satelliteNum_additional = dataReportIn.get("satelliteNum_additional");
            Map<String, String> satelliteNumMap = JsonTools.toMap(satelliteNum_additional);
            positionMap.put("satelliteNum", satelliteNumMap.get("satelliteNum"));
        }
        if(dataReportIn.containsKey("mileage_additional")){
            String satelliteNum_additional = dataReportIn.get("mileage_additional");
            Map<String, String> mileageMap = JsonTools.toMap(satelliteNum_additional);
            String mileage = String.valueOf(Double.parseDouble(mileageMap.get("mileage")) * 0.1);
            int index = mileage.indexOf(".");
            positionMap.put("mileage", mileage.substring(0, index + 2 ));
        }
        // 处理OBD五种附加数据
        if (dataReportIn.containsKey("extendAlarmState_additional")) {
            // 扩展告警位
            String extendAlarmStateAdditional = dataReportIn.get("extendAlarmState_additional");
            Map<String, String> extendAlarmStateDataMap = JsonTools.toMap(extendAlarmStateAdditional);
            long obdAlarm = Long.parseLong(extendAlarmStateDataMap.get("extendAlarmState"));
            Map<String, String> equAlarm = equAlarmRedisDao.getEquAlarmByEquId(equId);
            logger.info("OBD告警位信息={}", Long.toBinaryString(obdAlarm));
            // 处理OBD自定义告警位
            logger.info("处理OBD自定义告警位！equId={}", equId);
            for (int i = 0; i < 12; i++) {
                statusObdAlarm(equId, i, obdAlarm, positionMap, equAlarm);
            }
        }
        if (dataReportIn.containsKey("extendState_additional")) {
            // 扩展状态位
            String extendStateAdditional = dataReportIn.get("extendState_additional");
            Map<String, String> extendStateDataMap = JsonTools.toMap(extendStateAdditional);
            long obdState = Long.parseLong(extendStateDataMap.get("extendState"));
            logger.info("OBD状态位信息={}", Long.toBinaryString(obdState));
            // 处理OBD自定义状态位
            logger.info("处理OBD自定义状态位！equId={}", equId);
            processObdState(obdState, positionMap, dataMap);
        }
        if (dataReportIn.containsKey("carVoltage_additional")) {
            // 车辆电压
            String carVoltageAdditional = dataReportIn.get("carVoltage_additional");
            Map<String, String> carVoltageDataMap = JsonTools.toMap(carVoltageAdditional);
            double obdCarVoltage = Short.parseShort(carVoltageDataMap.get("carVoltage")) * 0.1;
            positionMap.put("carVoltage", obdCarVoltage == 0 ? "0.00" : df.format(obdCarVoltage));
            dataMap.put("carVoltage", obdCarVoltage == 0 ? "0.00" : df.format(obdCarVoltage));
            logger.info("OBD车辆电压={}V", obdCarVoltage == 0 ? 0.00 : df.format(obdCarVoltage));
        }
        if (dataReportIn.containsKey("terminalBatteryVoltage_additional")) {
            // 终端内置电池电压
            String terminalBatteryVoltageAdditional = dataReportIn.get("terminalBatteryVoltage_additional");
            Map<String, String> terminalBatteryVoltageDataMap = JsonTools.toMap(terminalBatteryVoltageAdditional);
            double terminalBatteryVoltage = Short.parseShort(terminalBatteryVoltageDataMap.get("terminalBatteryVoltage")) * 0.1;
            positionMap.put("terminalBatteryVoltage", terminalBatteryVoltage == 0 ? "0.00" : df.format(terminalBatteryVoltage));
            dataMap.put("terminalBatteryVoltage", terminalBatteryVoltage == 0 ? "0.00" : df.format(terminalBatteryVoltage));
            logger.info("终端内置电池电压={}V", terminalBatteryVoltage == 0 ? 0.00 : df.format(terminalBatteryVoltage));
        }
        if (dataReportIn.containsKey("obdData_additional")) {
            // OBD自定义数据
            String obdDataAdditional = dataReportIn.get("obdData_additional");
            try {
                Map<String, String> obdDataMaps = JsonTools.toMap(obdDataAdditional);
                List<Map<String, String>> obdDataMap = JSON.parseObject(obdDataMaps.get("paramList"), new TypeReference<List<Map<String, String>>>(){});
                for (Map<String, String> obdData : obdDataMap) {
                    short obdDataId = Short.parseShort(obdData.get("paramId"));
                    short data = Short.parseShort(obdData.get("paramVal"));
                    logger.info("处理OBD自定义数据id={}，data={}", obdDataId, data);
                    processObdData(obdDataId, data, positionMap, dataMap);
                }
            } catch (Exception e) {
                logger.error("解析失败！", e);
            }
        }
        // 存储OBD自定义数据至数据库
        insertObdData(dataMap);
    }

    /**
     * 处理OBD附件位置信息的状态位信息
     * @param obdState 状态位
     * @param positionMap 位置信息map
     * @param stateMap 状态map
     */
    private void processObdState(long obdState, Map<String, String> positionMap, Map<String, Object> stateMap) {
        // 3D传感器 0正常，1异常
        byte sensorOf3D = ObdState.state0(obdState);
        positionMap.put("sensorOf3D", String.valueOf(sensorOf3D));
        stateMap.put("sesorOf3D", sensorOf3D);
        // RTC模块 0正常，1异常
        byte rtc = ObdState.state1(obdState);
        positionMap.put("rtc", String.valueOf(rtc));
        stateMap.put("rtc", rtc);
        // FLASH模块 0正常，1异常
        byte flash = ObdState.state2(obdState);
        positionMap.put("flash", String.valueOf(flash));
        stateMap.put("flash", flash);
        // GPS模块 0正常，1异常
        byte gpsModule = ObdState.state3(obdState);
        positionMap.put("gpsModule", String.valueOf(gpsModule));
        stateMap.put("gpsModule", gpsModule);
        // CAN模块 0正常，1异常
        byte can = ObdState.state4(obdState);
        positionMap.put("can", String.valueOf(can));
        stateMap.put("can", can);
        // OBD适配 0适配，1不适配
        byte obd = ObdState.state5(obdState);
        positionMap.put("obd", String.valueOf(obd));
        stateMap.put("obd", obd);
        // 总线睡眠 0正常，1不睡眠
        byte bus = ObdState.state6(obdState);
        positionMap.put("bus", String.valueOf(bus));
        stateMap.put("bus", bus);
    }

    /**
     * 处理OBD自定义数据
     * @param obdDataId 数据id
     * @param data 数据值
     * @param positionMap 位置信息map
     * @param dataMap OBD数据map
     */
    private void processObdData(short obdDataId, short data, Map<String,String> positionMap, Map<String, Object> dataMap) {
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        if (obdDataId == Constant.OBD_ID_105) {
            // 冷却液温度，上传值减去40
            positionMap.put("ect", String.valueOf(data-40));
            dataMap.put("ect", String.valueOf(data-40));
        }
        if (obdDataId == Constant.OBD_ID_10B) {
            // 进气压力
            positionMap.put("intakePressure", String.valueOf(data));
            dataMap.put("intakePressure", String.valueOf(data));
        }
        if (obdDataId == Constant.OBD_ID_10C) {
            // 转速
            positionMap.put("rotationRate", String.valueOf(data));
            dataMap.put("rotationRate", String.valueOf(data));
        }
        if (obdDataId == Constant.OBD_ID_10D) {
            // 车速
            positionMap.put("carSpeed", String.valueOf(data));
            dataMap.put("carSpeed", String.valueOf(data));
        }
        if (obdDataId == Constant.OBD_ID_10F) {
            // 进气口温度
            positionMap.put("inletTemperature", String.valueOf(data-40));
            dataMap.put("inletTemperature", String.valueOf(data-40));
        }
        if (obdDataId == Constant.OBD_ID_110) {
            // 空气流量
            positionMap.put("airDischarge", decimalFormat.format(new BigDecimal(String.valueOf(data * 0.1))));
            dataMap.put("airDischarge", decimalFormat.format(new BigDecimal(String.valueOf(data * 0.1))));
        }
        if (obdDataId == Constant.OBD_ID_111) {
            // 绝对节气门位置
            positionMap.put("absoluteThrottlePosition", decimalFormat.format(new BigDecimal(String.valueOf(data * 0.1))));
            dataMap.put("absoluteThrottlePosition", decimalFormat.format(new BigDecimal(String.valueOf(data * 0.1))));
        }
        if (obdDataId == Constant.OBD_ID_12F) {
            // 剩余油量
            positionMap.put("remainingOil", decimalFormat.format(new BigDecimal(String.valueOf(data * 0.1))));
            dataMap.put("remainingOil", decimalFormat.format(new BigDecimal(String.valueOf(data * 0.1))));
        }
    }

    /**
     * 存储OBD自定义附加位置信息
     * @param dataMap OBD自定义附加位置信息map
     */
    private void insertObdData(Map<String, Object> dataMap) {
        logger.info("存储OBD自定义附加位置信息！");
        equDao.insertObdData(dataMap);
    }
    /**
     * 行程处理
     * @param equId
     * @param positionMap
     * @throws Exception
     */
    private void trip(String equId,Map<String,String> positionMap) throws Exception{
        String acc = positionMap.get("acc");
        Map<String, String> lastStatus = equRedisDao.findEquStatusByID(equId);
        String tripId = lastStatus.getOrDefault("tripId", "");
        if("0".equals(acc) && !Strings.isNullOrEmpty(tripId)){
            String endTimeStr = positionMap.getOrDefault("gpsTime", DateUtil.formatDateToStr(new Date(), DateUtil.TIME_HAVINTERVAL));
            Date endTime = DateUtil.formatStrToDate(endTimeStr, DateUtil.TIME_HAVINTERVAL);
            closeTrip(equId, positionMap.get("latitude"), positionMap.get("longitude"),endTime);
        }else if("1".equals(acc)){
            if(Strings.isNullOrEmpty(tripId)){
                tripId = StringUtil.getUUID();
                Map<String,String> tripStatusMap = Maps.newHashMap();
                tripStatusMap.put("tripId", tripId);
                equRedisDao.updateEquState(equId, tripStatusMap);

                Map<String,String> tripMap = Maps.newHashMap();
                tripMap.put("tripId", tripId);
                tripMap.put("carId", positionMap.get("carId"));
                tripMap.put("deptId", positionMap.get("deptId"));
                tripMap.put("startTime", positionMap.get("gpsTime"));
                tripMap.put("startLat", positionMap.get("latitude"));
                tripMap.put("startLng", positionMap.get("longitude"));
                tripMap.put("lat", positionMap.get("latitude"));
                tripMap.put("lng", positionMap.get("longitude"));
                tripMap.put("mileage", "0");
                equRedisDao.updateEquTrip(equId, tripMap);
            }else{
                Map<String,String> lastTripMap = equRedisDao.findEquTripByID(equId);
                double mileage = Double.parseDouble(lastTripMap.getOrDefault("mileage", "0"));
                double distance = MapMath.distance(Double.parseDouble(lastTripMap.get("lng")), Double.parseDouble(lastTripMap.get("lat")), Double.parseDouble(positionMap.get("longitude")), Double.parseDouble(positionMap.get("latitude")));
                mileage += distance;
                Map<String,String> tripMap = Maps.newHashMap();
                tripMap.put("mileage", String.valueOf(mileage));
                tripMap.put("lng", positionMap.get("longitude"));
                tripMap.put("lat", positionMap.get("latitude"));
                equRedisDao.updateEquTrip(equId, tripMap);
            }
        }
    }

    /**
     * 结束行程
     * @param equId
     * @param latitude
     * @param longitude
     * @param endTime    行程结束时间
     * @throws Exception
     */
    private void closeTrip(String equId,String latitude,String longitude,Date endTime) throws Exception{
        Map<String,String> lastTripMap = equRedisDao.findEquTripByID(equId);
        if(lastTripMap != null && !lastTripMap.isEmpty()){
            long start = DateUtil.formatStrToDate(lastTripMap.get("startTime"), DateUtil.TIME_HAVINTERVAL).getTime();
            long end = endTime.getTime();
            long totalSec = (end-start) / 1000;
            double mileage = Double.parseDouble(lastTripMap.getOrDefault("mileage", "0"))/1000.0;
            double speedAvg = mileage/totalSec * 60 * 60;
            if(totalSec == 0){
                speedAvg = 0;
            }

            DecimalFormat df = new DecimalFormat("#.##");
            DecimalFormat df2 = new DecimalFormat("#");
            Map<String,String> tripMap = Maps.newHashMap();
            String endTimeStr = DateUtil.formatDateToStr(endTime, DateUtil.TIME_HAVINTERVAL);
            tripMap.put("endTime", endTimeStr);
            tripMap.put("endLat", latitude);
            tripMap.put("endLng", longitude);
            tripMap.put("timer", df2.format(totalSec));
            tripMap.put("avgSpeed", df.format(speedAvg));
            lastTripMap.putAll(tripMap);
            lastTripMap.put("mileage", df.format(mileage));
            equRedisDao.dropTrip(equId);
            positionDaoHBase.insertTrip(equId, lastTripMap);
        }
        Map<String,String> equStatus = Maps.newHashMap();
        equStatus.put("tripId", "");
        equRedisDao.updateEquState(equId, equStatus);
    }
    /**
     * 坐标转地理位置
     * @param longitude
     * @param latitude
     * @return
     */
    private String gpsToAddress(String longitude,String latitude){
        //经纬度地址转化
        String address = null;
        Map<String,String> bdMap =  baiduMapTools.gpsToBd09(longitude, latitude);
        if("0".equals(bdMap.get("status"))){
            String lng = bdMap.get("longitude");
            String lat = bdMap.get("latitude");
            Map<String,String> addressMap = baiduMapTools.mapToAddress(lng, lat);
            if("0".equals(addressMap.get("status"))){
                address = addressMap.get("address");
            }
        }
        if(address == null){
            address = "";
        }
        return address;
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_lowPowerLBSExtendQueue_jt808", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_lowPowerLBSExtend", type = "direct", durable = "true"),
                    key = "jt808") })
    public void handleLBSExtend(String message) {
        Map<String, String> dataMap = JsonTools.toMap(message);
        if (dataMap == null || dataMap.size() == 0) {
            logger.error("消息体为空！");
            return;
        }
        // 存储相关LBS扩展消息
        logger.info("存储相关LBS扩展消息");
        equDao.insertLBSExtendData(dataMap);
    }


    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_lowPowerLocationReportQueue_jt808", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_lowPowerLocationReport", type = "direct", durable = "true"),
                    key = "jt808") })
    public String handleGpsLocationReport(String message) {
        logger.info("低功耗设备GPS信息上报");
        Map<String, String> dataMap = JsonTools.toMap(message);
        Map<String, String> resultMap = Maps.newHashMap();
        Map<String,String> gpsMap = Maps.newHashMap();
        String phone = dataMap.get("phone");
        String equId = dataMap.get("equId");
        int phoneLength = phone.length();
        if (phoneLength == 11) {
            phone = "0" + phone;
        }
        // 车辆设备信息
        Map<String, Object> equMap = equDao.queryEquByPhone(phone);
        if (equMap == null) {
            logger.error("低功耗设备GPS信息上报-通过手机号查找不到对应的设备，phone={}", phone);
            return null;
        }
        // 查询低功耗配置信息中的开关
        Map<String, Object> configMap = equDao.queryConfigById(equId);
        if (configMap == null || configMap.size() == 0) {
            // 无配置也当做未开启追踪模式
            resultMap.put("result", "false");
        } else {
            int flowSwitch = Integer.valueOf(String.valueOf(configMap.get("flowSwitch")));
            // 未开启追踪模式
            if (flowSwitch == 0) {
                resultMap.put("result", "false");
            } else {
                Integer flowInterval = Integer.valueOf(String.valueOf(configMap.get("flowInterval")));
                resultMap.put("result", "true");
                resultMap.put("flowInterval",String.valueOf(flowInterval));
            }
        }
        // 基本设备信息
        gpsMap.put("deptId", dataMap.get("deptId"));
        gpsMap.put("phone", phone);
        gpsMap.put("carNum", dataMap.get("carNum"));
        gpsMap.put("carId", dataMap.get("carId"));
        // 状态位
        long state = Long.valueOf(dataMap.get("state"));
        // 定位模式
        byte locationMode = State.State4_7(state);
        // 上报模式位
        long reportModeValue = Long.valueOf(dataMap.get("reportMode"));
        // 上报模式值
        byte reportMode = State.State4_7(reportModeValue);
        // 南纬北纬
        String latitudeFlag = State.State3(state) == 0 ? "+" : "-";
        // 东经西经
        String longitudeFlag = State.State2(state) == 0 ? "+" : "-";
        // 计算经纬度  除10的6次方
        BigDecimal longitude = new BigDecimal(longitudeFlag + dataMap.get("longitude"));
        longitude = longitude.divide(BigDecimal.valueOf(1000000L));
        BigDecimal latitude = new BigDecimal(latitudeFlag + dataMap.get("latitude"));
        latitude = latitude.divide(BigDecimal.valueOf(1000000L));
        String gpsTimeUtc = dataMap.get("gpsTime");
        logger.info("低功耗上报UTC-GPS时间={}", gpsTimeUtc);
        Date gpsDate;
        DateTime gpsDateTime;
        try {
            gpsDate = cn.hutool.core.date.DateUtil.parse(gpsTimeUtc);
            gpsDateTime = cn.hutool.core.date.DateUtil.offsetHour(gpsDate, 8);
            gpsMap.put("longitude", longitude.toString());
            gpsMap.put("latitude", latitude.toString());
            gpsMap.put("speed", dataMap.get("speed"));
            gpsMap.put("altitude", dataMap.get("altitude"));
            gpsMap.put("direation", dataMap.get("direation"));
            gpsMap.put("acc", "1");
            gpsMap.put("gpsTime", gpsDateTime.toString());
            gpsMap.put("linkTime", gpsDateTime.toString());
            // 其他上报信息
            gpsMap.put("locationMode", String.valueOf(locationMode));
            gpsMap.put("reportMode", dataMap.get("reportMode"));
            gpsMap.put("voltage", dataMap.get("voltage"));
            gpsMap.put("gpsNum", dataMap.get("gpsNum"));
            gpsMap.put("currentGpsNum", dataMap.get("currentGpsNum"));
            gpsMap.put("csqSignal", dataMap.get("csqSignal"));
            gpsMap.put("temperature", dataMap.get("temperature"));
            gpsMap.put("lbsFlag", "1,");
            gpsMap.put("type", "101");
        } catch (Exception e) {
            logger.error("时间格式存在问题-{}", gpsTimeUtc);
        }
        // 上报模式包含告警信息，处理告警信息
        handleAlarm(equId, gpsMap, reportMode, reportModeValue);
        // 存储相关GPS数据
        logger.info("低功耗设备{}，GPS数据={}", dataMap.get("carNum"), gpsMap);
        positionDaoHBase.insert(equId, gpsMap);
        try {
            // 更新Redis
            equRedisDao.updateEquState(equId, gpsMap);
            // 行程统计
            trip(equId, gpsMap);
        } catch (NullPointerException e) {
            logger.error("redis中不存在此设备id！equId={}", equId);
        } catch (Exception e) {
            logger.error("redis更新异常或行程更新异常！", e);
        }
        return JsonTools.toJsonStr(resultMap);
    }

    /**
     * 处理低功耗4种告警
     * @param equId 设备id
     * @param gpsMap 位置map
     * @param mode 上报模式
     * @param value 上报模式值
     */
    private void handleAlarm(String equId, Map<String,String> gpsMap, int mode, long value) {
        logger.info("低功耗mode={}", mode);
        StringBuilder stringBuilder = new StringBuilder();
        try {
            Map<String, String> equAlarm = equAlarmRedisDao.getEquAlarmByEquId(equId);
            // 如果mode等于3，则存储震动报警的信息
            String shakeAlarmOld = equAlarm.getOrDefault(ALARMTYPE_PREFIX + 53, "0");
            if ("0".equalsIgnoreCase(shakeAlarmOld)) {
                if (3 == mode) {
                    stringBuilder.append(ALARMTYPE_PREFIX + 53).append(",");
                    alarmBegin(gpsMap, equId, 53);
                }
            } else if (3 != mode) {
                alarmEnd(gpsMap, equAlarm, equId, 53);
            }
            // 如果mode等于4，则存储拆机报警的信息
            String tearDownAlarmOld = equAlarm.getOrDefault(ALARMTYPE_PREFIX + 55, "0");
            if ("0".equalsIgnoreCase(tearDownAlarmOld)) {
                if (4 == mode) {
                    stringBuilder.append(ALARMTYPE_PREFIX + 55).append(",");
                    alarmBegin(gpsMap, equId, 55);
                }
            } else if (4 != mode) {
                alarmEnd(gpsMap, equAlarm, equId, 55);
            }
            // 其他状态位报警信息
            byte lowBatteryAlarm = State.State2(value);
            byte temperatureAlarm = State.State3(value);
            // 老的告警信息
            String temperatureAlarmOld = equAlarm.getOrDefault(ALARMTYPE_PREFIX + 54, "0");
            String lowBatteryAlarmOld = equAlarm.getOrDefault(ALARMTYPE_PREFIX + 56, "0");
            // 温度告警
            if ("0".equalsIgnoreCase(temperatureAlarmOld)) {
                if (1 == temperatureAlarm) {
                    stringBuilder.append(ALARMTYPE_PREFIX + 54).append(",");
                    alarmBegin(gpsMap, equId, 54);
                }
            } else if(0 == temperatureAlarm){
                alarmEnd(gpsMap, equAlarm, equId, 54);
            }
            // 低电量告警
            if ("0".equalsIgnoreCase(lowBatteryAlarmOld)) {
                if (1 == lowBatteryAlarm) {
                    stringBuilder.append(ALARMTYPE_PREFIX + 56).append(",");
                    alarmBegin(gpsMap, equId, 56);
                }
            } else if(0 == lowBatteryAlarm){
                alarmEnd(gpsMap, equAlarm, equId, 56);
            }
            gpsMap.put("alarm", stringBuilder.toString());
        } catch (Exception e) {
            logger.error("处理低功耗设备告警失败！", e);
        }
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_lowPower_loginQueue_jt808", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_lowPower_login", type = "direct", durable = "true"),
                    key = "jt808") })
    public String handleLowPowerLogin(String message) {
        try {
            Map<String,String> loginMap = Maps.newHashMap();
            Map<String,String> dataMap = JsonTools.toMap(message);
            String phone = dataMap.get("phone");
            // 升级标志
            String update = dataMap.get("update");
            // 车辆设备信息
            int phoneLength = phone.length();
            if (phoneLength == 11) {
                phone = "0" + phone;
            }
            Map<String, Object> carEquMap = equDao.queryCarEquByPhone(phone);
            if(carEquMap == null){
                loginMap.put("loginResult", "3");
                logger.error("低功耗设备登录-平台不存在此终端，phone={}", message);
            } else {
                String equId = String.valueOf(carEquMap.get("equId"));
                String carId = String.valueOf(carEquMap.getOrDefault("carId", ""));
                String deptId = String.valueOf(carEquMap.get("deptId"));
                // 处理升级标志
                if ("100".equals(update)) {
                    // MCU升级成功
                    equDao.updateMcuSwitch(equId);
                }
                Map<String, String> equStatus = equRedisDao.findEquStatusByID(equId);
                String online = equStatus.getOrDefault("online", "0");
                if("1".equals(online)){
                    loginMap.put("loginResult", "1");
                    String linkTime = equStatus.getOrDefault("linkTime", "");
                    long sec = DateUtil.getDistanceSec(linkTime, DateUtil.TIME_HAVINTERVAL);
                    if(sec >= 60 * 3){
                        Map<String, String> equState = Maps.newHashMap();
                        equState.put("online", "0");
                        equRedisDao.updateEquState(equId, equState);
                        logger.info("低功耗设备登录-强制更新状态为离线 设备id={}", equId);
                    }
                } else if("0".equals(online)) {
                    loginMap.put("loginResult", "0");
                    loginMap.put("equId", equId);
                    loginMap.put("carId", carId);
                    loginMap.put("carNum", String.valueOf(carEquMap.getOrDefault("carNum", "")));
                    loginMap.put("deptId", deptId);
                    // 查询低功耗设备的配置信息
                    Map<String, Object> config = equDao.queryConfigById(equId);
                    if (config == null || config.size() == 0) {
                        loginMap.put("config", "");
                    } else {
                        loginMap.put("config",JSON.toJSONString(config));
                        // 设备状态更新
                        Map<String, String> equState = Maps.newHashMap();
                        equState.put("linkTime", DateUtil.getSysStrCurrentDate(DateUtil.TIME_HAVINTERVAL));
                        equState.put("online", "1");
                        equRedisDao.updateEquState(equId, equState);
                    }
                } else {
                    loginMap.put("loginResult", "1");
                    logger.info("低功耗设备登录-登录验证失败！");
                }
            }
            String result = JSON.toJSONString(loginMap);
            logger.info("低功耗设备唯一标识={}的登录结果={}", message,result);
            return result;
        } catch (Exception e) {
            logger.error("处理失败！e", e);
            return null;
        }
    }
}
