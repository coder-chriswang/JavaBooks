/**
 * @company 有方物联
 * @file Alarm.java
 * @author guojy
 * @date 2018年4月16日 
 */
package com.neoway.car.logic.util;

/**
 * @description :JT808告警位操作
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class Alarm extends AbstractBitTool {
	/**
	 * 1：紧急报警，触动报警开关后触发
	 * @param alarm
	 * @return
	 */
	public static byte Alarm0(long alarm) {
		return convert(alarm, 0, 1);
	}

	/**
	 * 1：超速报警
	 * @param alarm
	 * @return
	 */
	public static byte Alarm1(long alarm) {
		return convert(alarm, 1, 1);
	}

	/**
	 * 1：疲劳驾驶
	 * @param alarm
	 * @return
	 */
	public static byte Alarm2(long alarm) {
		return convert(alarm, 2, 1);
	}

	/**
	 * 1：危险预警
	 * @param alarm
	 * @return
	 */
	public static byte Alarm3(long alarm) {
		return convert(alarm, 3, 1);
	}

	/**
	 * 1：GNSS 模块发生故障
	 * @param alarm
	 * @return
	 */
	public static byte Alarm4(long alarm) {
		return convert(alarm, 4, 1);
	}

	/**
	 * 1：GNSS 天线未接或被剪断
	 * @param alarm
	 * @return
	 */
	public static byte Alarm5(long alarm) {
		return convert(alarm, 5, 1);
	}

	/**
	 * 1：GNSS 天线短路
	 * @param alarm
	 * @return
	 */
	public static byte Alarm6(long alarm) {
		return convert(alarm, 6, 1);
	}

	/**
	 * 1：终端主电源欠压
	 * @param alarm
	 * @return
	 */
	public static byte Alarm7(long alarm) {
		return convert(alarm, 7, 1);
	}

	/**
	 * 1：终端主电源掉电
	 * @param alarm
	 * @return
	 */
	public static byte Alarm8(long alarm) {
		return convert(alarm, 8, 1);
	}

	/**
	 * 1：终端LCD 或显示器故障
	 * @param alarm
	 * @return
	 */
	public static byte Alarm9(long alarm) {
		return convert(alarm, 9, 1);
	}

	/**
	 * 1：TTS 模块故障
	 * @param alarm
	 * @return
	 */
	public static byte Alarm10(long alarm) {
		return convert(alarm, 10, 1);
	}

	/**
	 * 1：摄像头故障
	 * @param alarm
	 * @return
	 */
	public static byte Alarm11(long alarm) {
		return convert(alarm, 11, 1);
	}

	/**
	 * 1：道路运输证IC 卡模块故障
	 * @param alarm
	 * @return
	 */
	public static byte Alarm12(long alarm) {
		return convert(alarm, 12, 1);
	}

	/**
	 * 1：超速预警
	 * @param alarm
	 * @return
	 */
	public static byte Alarm13(long alarm) {
		return convert(alarm, 13, 1);
	}

	/**
	 * 1：疲劳驾驶预警
	 * @param alarm
	 * @return
	 */
	public static byte Alarm14(long alarm) {
		return convert(alarm, 14, 1);
	}

	/**
	 * 1：当天累计驾驶超时
	 * @param alarm
	 * @return
	 */
	public static byte Alarm18(long alarm) {
		return convert(alarm, 18, 1);
	}

	/**
	 * 1：超时停车
	 * @param alarm
	 * @return
	 */
	public static byte Alarm19(long alarm) {
		return convert(alarm, 19, 1);
	}

	/**
	 * 1：进出区域
	 * @param alarm
	 * @return
	 */
	public static byte Alarm20(long alarm) {
		return convert(alarm, 20, 1);
	}

	/**
	 * 1：进出路线
	 * @param alarm
	 * @return
	 */
	public static byte Alarm21(long alarm) {
		return convert(alarm, 21, 1);
	}

	/**
	 * 1：路段行驶时间不足/过长
	 * @param alarm
	 * @return
	 */
	public static byte Alarm22(long alarm) {
		return convert(alarm, 22, 1);
	}

	/**
	 * 1：路线偏离报警
	 * @param alarm
	 * @return
	 */
	public static byte Alarm23(long alarm) {
		return convert(alarm, 23, 1);
	}

	/**
	 * 1：车辆VSS 故障
	 * @param alarm
	 * @return
	 */
	public static byte Alarm24(long alarm) {
		return convert(alarm, 24, 1);
	}

	/**
	 * 1：车辆油量异常
	 * @param alarm
	 * @return
	 */
	public static byte Alarm25(long alarm) {
		return convert(alarm, 25, 1);
	}

	/**
	 * 1：车辆被盗(通过车辆防盗器)
	 * @param alarm
	 * @return
	 */
	public static byte Alarm26(long alarm) {
		return convert(alarm, 26, 1);
	}

	/**
	 * 1：车辆非法点火
	 * @param alarm
	 * @return
	 */
	public static byte Alarm27(long alarm) {
		return convert(alarm, 27, 1);
	}

	/**
	 * 1：车辆非法位移
	 * @param alarm
	 * @return
	 */
	public static byte Alarm28(long alarm) {
		return convert(alarm, 28, 1);
	}

	/**
	 * 1：碰撞预警
	 * @param alarm
	 * @return
	 */
	public static byte Alarm29(long alarm) {
		return convert(alarm, 29, 1);
	}

	/**
	 * 1：侧翻预警
	 * @param alarm
	 * @return
	 */
	public static byte Alarm30(long alarm) {
		return convert(alarm, 30, 1);
	}

	/**
	 * 1：非法开门报警（终端未设置区域时，不判断非法开门）
	 * @param alarm
	 * @return
	 */
	public static byte Alarm31(long alarm) {
		return convert(alarm, 31, 1);
	}
	
	/**
	 * 通过pos索引位置计算告警位
	 * @param alarm
	 * @param pos
	 * @return
	 */
	public static byte selectAlarm(long alarm,int pos){
		return convert(alarm, pos, 1);
	}
	
	public static String test(String a){
		return a;
	}
	
}
