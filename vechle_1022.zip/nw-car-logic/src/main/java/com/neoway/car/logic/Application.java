/**
 * @company 有方物联
 * @file Application.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.logic;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.client.RestTemplate;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
@ImportResource("classpath*:application-*.xml")
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class,HibernateJpaAutoConfiguration.class},scanBasePackages={"com.neoway"})
public class Application {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new SpringApplicationBuilder(Application.class).beanNameGenerator((def,reg)-> def.getBeanClassName()).web(true).run(args);
	}
	
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
}
