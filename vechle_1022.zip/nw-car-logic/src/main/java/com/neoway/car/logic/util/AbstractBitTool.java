/**
 * @company 有方物联
 * @file AbstractBitTool.java
 * @author guojy
 * @date 2018年4月16日 
 */
package com.neoway.car.logic.util;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public abstract class AbstractBitTool {
	/**
	 * @param state JT808状态位
	 * @param pos 位索引  从0开始
	 * @param len 长度
	 * @return
	 */
	protected static byte convert(long state, int pos, int len)
	  {
	    return (byte)(state >> pos & (len == 1 ? 1 : 3));
	  }
}
