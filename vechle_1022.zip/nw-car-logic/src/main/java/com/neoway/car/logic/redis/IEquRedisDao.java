/**
 * @company 有方物联
 * @file IEquRedisDao.java
 * @author guojy
 * @date 2018年4月15日 
 */
package com.neoway.car.logic.redis;

import java.util.Map;

/**
 * @description :设备redis缓存
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
public interface IEquRedisDao {
	/**
	 * 更新设备redis缓存数据
	 * @param equId
	 * @param value
	 */
	public void updateEquState(String equId,Map<String, String> value);
	/**
	 * 查询设备redis状态数据
	 * @param equId
	 * @return
	 */
	public Map<String, String> findEquStatusByID(String equId);
	
	/**
	 * 更新设备行程数据
	 * @param equId
	 * @param value
	 */
	public void updateEquTrip(String equId,Map<String, String> value);
	
	/**
	 * 查询设备redis行程数据
	 * @param equId
	 * @return
	 */
	public Map<String, String> findEquTripByID(String equId);
	
	/**
	 * 删除行程缓存数据
	 * @param equId
	 */
	public void dropTrip(String equId);
	
	/**
	 * 更新设备信息redis
	 * @param phone
	 * @param value
	 */
	public void updateEquInfo(String phone,Map<String, String> value);
	/**
	 * 查询设备信息
	 * @param phone
	 * @return
	 */
	public Map<String, String> findEquInfoByID(String phone);
}
