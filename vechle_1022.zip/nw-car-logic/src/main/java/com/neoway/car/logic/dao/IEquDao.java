/**
 * @company 有方物联
 * @file IEquDao.java
 * @author guojy
 * @date 2018年4月12日
 */
package com.neoway.car.logic.dao;

import org.apache.ibatis.annotations.Param;

import java.util.Map;

/**
 * @description :设备DAO接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月12日
 */
public interface IEquDao {
    /**
     * 通过设备手机号查询设备
     * @param phone 设备手机号
     * @return
     */
    public Map<String,Object> queryEquByPhone(String phone);

    /**
     * 更新设备鉴权码
     * @param equId 设备ID
     * @param authCode 鉴权码
     */
    public void updateAuthCode(@Param("equId") String equId,@Param("authCode") String authCode);

    /**
     * 通过设备手机号查询车辆设备关系信息
     * @param phone 设备手机号
     * @return
     */
    public Map<String,Object> queryCarEquByPhone(String phone);

    /**
     * 存储OBD自定义附加位置信息
     * @param dataMap 数据map
     */
    void insertObdData(Map<String, Object> dataMap);

    /**
     * 存储行程开始数据
     * @param dataMap 数据map
     */
    void insertStartTrip(Map<String, Object> dataMap);

    /**
     * 存储行程结束数据
     * @param dataMap 数据map
     */
    void insertEndTrip(Map<String, Object> dataMap);

    /**
     * 存储行程报告数据
     * @param dataMap 数据map
     */
    void insertWholeTrip(Map<String, Object> dataMap);

    /**
     * 存储故障码数据
     * @param dataMap 数据map
     */
    void insertErrorCode(Map<String, Object> dataMap);

    /**
     * 存储扩展终端属性数据
     * @param dataMap 数据map
     */
    void insertTerminalExtendProperty(Map<String, Object> dataMap);

    /**
     * 存储LBS扩展信息数据
     * @param dataMap 数据map
     */
    void insertLBSExtendData(Map<String, String> dataMap);

    /**
     * 根据id查询低功耗设备配置信息
     * @param equId 设备id
     * @return Map
     */
    Map<String, Object> queryConfigById(@Param("equId") String equId);

    /**
     * 更新Mcu版本更新标志
     * @param equId 设备id
     */
    void updateMcuSwitch(@Param("equId") String equId);
}
