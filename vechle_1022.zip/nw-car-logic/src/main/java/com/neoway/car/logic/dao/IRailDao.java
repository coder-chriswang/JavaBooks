/**
 * @company 有方物联
 * @file IRailDao.java
 * @author guojy
 * @date 2018年4月28日 
 */
package com.neoway.car.logic.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * @description :电子围栏离线下发DAO接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月28日
 */
public interface IRailDao {
	/**
	 * 查询待执行的电子围栏下发任务
	 * @param equId 设备ID
	 * @return
	 */
	public List<Map<String,Object>> findTodoRailTasks(String equId);
	/**
	 * 更新围栏操作结果
	 * @param id
	 * @param result 结果  1:成功 -1 失败
	 */
	public void updateResultById(@Param("id") String id,@Param("result") String result);
	/**
	 * 删除操作类型为DELETE 并且状态为1的记录 operType execStatus
	 */
	public void deleteValidRecord();
}
