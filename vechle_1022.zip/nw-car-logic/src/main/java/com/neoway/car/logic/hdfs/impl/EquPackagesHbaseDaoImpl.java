/**
 * @company 有方物联
 * @file EquPackagesHbaseImpl.java
 * @author guojy
 * @date 2018年7月24日 
 */
package com.neoway.car.logic.hdfs.impl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.neoway.car.logic.hdfs.IEquPackagesDaoHbase;

/**
 * @description :设备报文存储实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月24日
 */
@Component
public class EquPackagesHbaseDaoImpl implements IEquPackagesDaoHbase {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private DateTimeFormatter f1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS");
	private DateTimeFormatter f2 = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
	@Autowired
	private Connection conn;
	/* (non-Javadoc)
	 * @see com.etiot.car.logic.hdfs.IEquPackagesHbase#insert(java.lang.String, java.util.Map)
	 */
	@Override
	public void insert(String equId, Map<String, String> paramMap) {
		try {
			HTable hTable = (HTable)this.conn.getTable(TableName.valueOf("EQU_PACKETS"));
			LocalDateTime dtl = LocalDateTime.parse(paramMap.get("collectTime"), this.f1);
			String collectTime = dtl.format(this.f2);
			String rowKey = equId + ":" + collectTime;
			Put put = new Put(rowKey.getBytes());
			put.addColumn("c".getBytes(), "equId".getBytes(),Bytes.toBytes(equId));
			put.addColumn("c".getBytes(), "phone".getBytes(),Bytes.toBytes(paramMap.get("phone")));
			put.addColumn("c".getBytes(), "direct".getBytes(),Bytes.toBytes(paramMap.get("direct")));
			put.addColumn("c".getBytes(), "content".getBytes(),Bytes.toBytes(paramMap.get("content")));
			put.addColumn("c".getBytes(), "collectTime".getBytes(),Bytes.toBytes(paramMap.get("collectTime")));
			hTable.put(put);
		    hTable.close();
		} catch (IOException e) {
			logger.error("hbase存储发生异常！",e);
		}
	}

}
