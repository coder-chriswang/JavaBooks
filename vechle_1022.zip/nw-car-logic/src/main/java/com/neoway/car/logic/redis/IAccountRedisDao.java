/**
 * @company 有方物联
 * @file IAccountRedisDao.java
 * @author guojy
 * @date 2018年4月20日 
 */
package com.neoway.car.logic.redis;

import java.util.Set;

/**
 * @description :用户账号相关redis缓存数据
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月20日
 */
public interface IAccountRedisDao {
	public Set<String> queryAccountsByDeptId(String deptId);
}
