/**
 * @company 有方物联
 * @file Constant.java
 * @author guojy
 * @date 2018年4月15日
 */
package com.neoway.car.logic.util;

/**
 * @description :常量类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
public class Constant {
    //1：超速告警 2：疲劳驾驶 8：亏电告警  20 进出区域告警 29碰撞预警 30 侧翻预警19 超时停车  101 怠速告警 102 离线告警
    public static final String ALARM_TYPE_101 = "at_101";
    public static final String ALARM_TYPE_102 = "at_102";
    //设备在线状态  1：在线  0：离线
    public static final String EQU_ONLINE = "1";
    //redis告警缓存天数
    public static final long REDIS_ALARM_CACHE_DAYS = 5;

    public static final int OBD_ID_105 = 261;

    public static final int OBD_ID_10B = 267;

    public static final int OBD_ID_10C = 268;

    public static final int OBD_ID_10D = 269;

    public static final int OBD_ID_10F = 271;

    public static final int OBD_ID_110 = 272;

    public static final int OBD_ID_111 = 273;

    public static final int OBD_ID_12F = 303;
}
