/**
 * @company 有方物联
 * @file RuleRedisDaoImpl.java
 * @author guojy
 * @date 2018年7月4日 
 */
package com.neoway.car.logic.redis.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.neoway.car.logic.redis.IRuleRedisDao;

/**
 * @description :规则redis缓存
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月4日
 */
@Component
public class RuleRedisDaoImpl implements IRuleRedisDao {
	@Resource
	private StringRedisTemplate template;
	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.IRuleRedisDao#findEquRulesByID(java.lang.String)
	 */
	@Override
	public Map<String, String> findEquRulesByID(String equId) {
		Map<String, String> rulesMap =  this.template.<String, String>boundHashOps("etiot:equrule:map:" + equId).entries();
		return rulesMap;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.IRuleRedisDao#findRuleByID(java.lang.String)
	 */
	@Override
	public Map<String, String> findRuleByID(String ruleId) {
		Map<String, String> ruleInfo =  this.template.<String, String>boundHashOps("etiot:equ:rule:" + ruleId).entries();
		return ruleInfo;
	}

}
