/**
 * @company 有方物联
 * @file IEquAlarmRedisDao.java
 * @author guojy
 * @date 2018年4月19日 
 */
package com.neoway.car.logic.redis;

import java.util.Map;

/**
 * @description :设备告警redis缓存
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月19日
 */
public interface IEquAlarmRedisDao {
	/**
	 * 
	 * @param equId 设备ID
	 * @return
	 */
	public Map<String, String> getEquAlarmByEquId(String equId);
	
	/**
	 * 缓存告警数据 
	 * @param equId 设备ID
	 * @param equAlarmMap 告警数据
	 */
	public void pushEquAlarm(String equId, Map<String, String> equAlarmMap);
	
	/**
	 * add alarm 
	 * @param alarmId 告警ID
	 * @param alarmMap 告警详情
	 */
	public void insertAlarm(String alarmId, Map<String, String> alarmMap);
	
	/**
	 * add alarm msg
	 * @param accountId 用户账号
	 * @param alarmId 告警ID
	 */
	public void insertAdminAlarmMsg(String accountId, String alarmId);
	
}
