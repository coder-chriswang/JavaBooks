/**
 * @company 有方物联
 * @file IDeviceOrder.java
 * @author guojy
 * @date 2018年4月25日 
 */
package com.neoway.car.logic.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * @description :设备操作指令DAO层接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月25日
 */
public interface IDeviceOrderDao {
	/**
	 * 更新操作指令流水号
	 * @param orderId 操作记录ID
	 * @param serialNum 流水号
	 */
	public void updateSerialNum(@Param("orderId") String orderId,@Param("serialNum") int serialNum);
	/**
	 * 更新指令操作结果(根据流水号和设备ID)
	 * @param serialNum 流水号
	 * @param equId 设备ID
	 * @param result 结果
	 */
	public void updateResult(@Param("serialNum") int serialNum,@Param("equId") String equId,@Param("result") String result);
	
	/**
	 * 更新指令操作结果
	 * @param orderId
	 * @param result 结果
	 */
	public void updateResultById(@Param("orderId") String orderId,@Param("result") String result);
	
	/**
	 * 查询待执行的OrderId列表
	 * @param equId 设备ID
	 * @return
	 */
	public List<Map<String,Object>> findToDoOrderList(@Param("equId") String equId);

	/**
	 * 查询待执行的参数信息
	 * @param orderId 指令ID
	 * @return
	 */
	public List<Map<String,Object>> findParamsByOrderId(@Param("orderId") String orderId);
}
