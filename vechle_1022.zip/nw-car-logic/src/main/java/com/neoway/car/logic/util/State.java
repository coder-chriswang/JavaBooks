/**
 * @company 有方物联
 * @file State.java
 * @author guojy
 * @date 2018年4月16日
 */
package com.neoway.car.logic.util;

/**
 * @description :JT808状态位操作
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class State extends AbstractBitTool {

    public static byte State0(long state) {
        return convert(state, 0, 1);
    }

    public static byte State1(long state) {
        return convert(state, 1, 1);
    }

    public static byte State2(long state) {
        return convert(state, 2, 1);
    }

    public static byte State3(long state) {
        return convert(state, 3, 1);
    }

    public static byte State4(long state) {
        return convert(state, 4, 1);
    }

    public static byte State5(long state) {
        return convert(state, 5, 1);
    }

    public static byte State7(long state) {
        return convert(state, 7, 1);
    }

    public static byte State8(long state) {
        return convert(state, 8, 2);
    }

    public static byte State10(long state) {
        return convert(state, 10, 1);
    }

    public static byte State11(long state) {
        return convert(state, 11, 1);
    }

    public static byte State12(long state) {
        return convert(state, 12, 1);
    }

    public static byte State13(long state) {
        return convert(state, 13, 1);
    }

    public static byte State14(long state) {
        return convert(state, 14, 1);
    }

    public static byte State15(long state) {
        return convert(state, 15, 1);
    }

    public static byte State16(long state) {
        return convert(state, 16, 1);
    }

    public static byte State17(long state) {
        return convert(state, 17, 1);
    }

    public static byte State18(long state) {
        return convert(state, 18, 1);
    }

    public static byte State19(long state) {
        return convert(state, 19, 1);
    }

    public static byte State20(long state) {
        return convert(state, 20, 1);
    }

    public static byte State21(long state) {
        return convert(state, 21, 1);
    }

    public static byte StateExt0(long state) {
        return convert(state, 0, 1);
    }

    public static byte StateExt1(long state) {
        return convert(state, 1, 1);
    }

    public static byte StateExt2(long state) {
        return convert(state, 2, 1);
    }

    public static byte StateExt3(long state) {
        return convert(state, 3, 1);
    }

    public static byte StateExt4(long state) {
        return convert(state, 4, 1);
    }

    public static byte StateExt5(long state) {
        return convert(state, 5, 1);
    }

    public static byte StateExt6(long state) {
        return convert(state, 6, 1);
    }

    public static byte StateExt7(long state) {
        return convert(state, 7, 1);
    }

    public static byte StateExt8(long state) {
        return convert(state, 8, 1);
    }

    public static byte StateExt9(long state) {
        return convert(state, 9, 1);
    }

    public static byte StateExt10(long state) {
        return convert(state, 10, 1);
    }

    public static byte StateExt11(long state) {
        return convert(state, 11, 1);
    }

    public static byte StateExt12(long state) {
        return convert(state, 12, 1);
    }

    public static byte StateExt13(long state) {
        return convert(state, 13, 1);
    }

    public static byte StateExt14(long state) {
        return convert(state, 14, 1);
    }

    public static byte State4_7(long state) {
        return (byte)(state >> 4 & 15);
    }
}
