/**
 * @company 有方物联
 * @file AccountRedisDaoImpl.java
 * @author guojy
 * @date 2018年4月20日 
 */
package com.neoway.car.logic.redis.impl;

import java.util.Set;

import javax.annotation.Resource;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.neoway.car.logic.redis.IAccountRedisDao;

/**
 * @description :用户信息缓存默认实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月20日
 */
@Component
public class AccountRedisDaoImpl implements IAccountRedisDao {
	@Resource
	private StringRedisTemplate template;
	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.impl.IAccountRedisDao#queryAccountsByDeptId(java.lang.String)
	 */
	@Override
	public Set<String> queryAccountsByDeptId(String deptId) {
		return this.template.boundSetOps("etiot:dept:admin:" + deptId).members();
	}

}
