/**
 * @company 有方物联
 * @file BaiduMapTools.java
 * @author guojy
 * @date 2018年5月9日 
 */
package com.neoway.car.logic.util;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;

/**
 * @description :百度地址工具类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年5月9日
 */
@Component
public class BaiduMapTools {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private RestTemplate template = new RestTemplate();
	@Value("${map.baidu.ak}")
	private String ak;
	
	/**
	 * gps84坐标系转百度坐标系纠偏
	 * @param lat
	 * @param lng
	 * @return
	 */
	public  Map<String, String> gpsToBd09(String longitude, String latitude){
		Map<String, String> urlVariables = Maps.newHashMap();
	    urlVariables.put("coords", longitude + "," + latitude);
	    urlVariables.put("ak", this.ak);
	    
	    String ret = this.template.getForObject("http://api.map.baidu.com/geoconv/v1/?coords={coords}&from=1&to=5&ak={ak}", String.class, urlVariables);
	    logger.debug("gpsToMap ret = {}", ret);
	    JSONObject retJson = JSON.parseObject(ret);
	    Map<String, String> returnMap = Maps.newHashMap();
	    if(0 == retJson.getInteger("status")){
	    	JSONArray dataArrayJson = retJson.getJSONArray("result");
	    	JSONObject dataJson = dataArrayJson.getJSONObject(0);
	    	returnMap.put("status", "0");
	    	returnMap.put("longitude", dataJson.getBigDecimal("x").toString());
	    	returnMap.put("latitude", dataJson.getBigDecimal("y").toString());
	    }else{
	    	returnMap.put("status", "-1");
	    	logger.error("经纬度转化异常！坐标:{},{} result:{}",longitude,latitude,ret);
	    }
		return returnMap;
	}
	
	/**
	 * 经纬度转地址
	 * @param longitude
	 * @param latitude
	 * @return
	 */
	public  Map<String, String> mapToAddress(String longitude, String latitude){
		Map<String, String> urlVariables = Maps.newHashMap();
	    urlVariables.put("location", latitude + "," + longitude);
	    urlVariables.put("ak", this.ak);
	    String ret = (String)this.template.getForObject("http://api.map.baidu.com/geocoder/v2/?ak={ak}&location={location}&output=json", String.class, urlVariables);
	    logger.debug("mapToAddress ret = {}", ret);
	    Map<String, String> retMap = JsonTools.toMap(ret);
	    Map<String, String> returnMap = Maps.newHashMap();
	    if("0".equals(retMap.get("status"))){
	    	Map<String, String> dataMap = JsonTools.toMap(retMap.get("result"));
	    	returnMap.put("status", "0");
	    	returnMap.put("address", dataMap.get("formatted_address"));
	    }else{
	    	returnMap.put("status", "-1");
	    	logger.error("地址转化转化异常！");
	    }
		return returnMap;
	}
}
