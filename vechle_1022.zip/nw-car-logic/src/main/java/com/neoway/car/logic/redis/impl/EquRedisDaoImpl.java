/**
 * @company 有方物联
 * @file EquRedisDaoImpl.java
 * @author guojy
 * @date 2018年4月15日 
 */
package com.neoway.car.logic.redis.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.neoway.car.logic.redis.IEquRedisDao;

/**
 * @description :设备redis缓存默认实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
@Component
public class EquRedisDaoImpl implements IEquRedisDao {
	@Resource
	private StringRedisTemplate template;
	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.IEquRedisDao#updateEquState(java.lang.String, java.util.Map)
	 */
	@Override
	public void updateEquState(String equId, Map<String, String> value) {
		this.template.boundHashOps("etiot:equ:state:" + equId).putAll(value);
	}
	@Override
	public Map<String, String> findEquStatusByID(String equId) {
		Map<String, String> equInfo =  this.template.<String, String>boundHashOps("etiot:equ:state:" + equId).entries();
		return equInfo;
	}
	@Override
	public void updateEquTrip(String equId, Map<String, String> value) {
		this.template.boundHashOps("etiot:equ:trip:" + equId).putAll(value);
	}
	@Override
	public Map<String, String> findEquTripByID(String equId) {
		Map<String, String> tripMap =  this.template.<String, String>boundHashOps("etiot:equ:trip:" + equId).entries();
		return tripMap;
	}
	
	@Override
	public void dropTrip(String equId) {
		this.template.delete("etiot:equ:trip:" + equId);
	}
	
	@Override
	public void updateEquInfo(String phone, Map<String, String> value) {
		this.template.boundHashOps("etiot:equ:info:" + phone).putAll(value);
	}
	
	@Override
	public Map<String, String> findEquInfoByID(String phone) {
		Map<String, String> equMap =  this.template.<String, String>boundHashOps("etiot:equ:info:" + phone).entries();
		return equMap;
	}

}
