/**
 * @company 有方物联
 * @file IEquPacketsDao.java
 * @author guojy
 * @date 2018年4月15日 
 */
package com.neoway.car.logic.dao;

import java.util.Map;

/**
 * @description :设备报文DAO接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
public interface IEquPacketsDao {
	/**
	 * 保存报文
	 * @param equPacket
	 * @return
	 */
	public int insertEquPackets(Map<String,Object> equPacket);
}
