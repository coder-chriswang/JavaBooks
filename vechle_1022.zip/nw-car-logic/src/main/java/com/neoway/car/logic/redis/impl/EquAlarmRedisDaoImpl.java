/**
 * @company 有方物联
 * @file EquAlarmRedisDaoImpl.java
 * @author guojy
 * @date 2018年4月19日 
 */
package com.neoway.car.logic.redis.impl;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.neoway.car.logic.redis.IEquAlarmRedisDao;
import com.neoway.car.logic.util.Constant;

/**
 * @description :设备告警缓存
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月19日
 */
@Component
public class EquAlarmRedisDaoImpl implements IEquAlarmRedisDao {
	@Resource
	private StringRedisTemplate template;
	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.IEquAlarmRedisDao#getEquAlarmByEquId(java.lang.String)
	 */
	@Override
	public Map<String, String> getEquAlarmByEquId(String equId) {
		Map<String, String> equAlarm =  this.template.<String, String>boundHashOps("etiot:equ:alarm:" + equId).entries();
		return equAlarm;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.logic.redis.IEquAlarmRedisDao#pushEquAlarm(java.lang.String, java.util.Map)
	 */
	@Override
	public void pushEquAlarm(String equId, Map<String, String> equAlarmMap) {
		this.template.boundHashOps("etiot:equ:alarm:" + equId).putAll(equAlarmMap);
	}

	@Override
	public void insertAlarm(String alarmId, Map<String, String> alarmMap) {
		this.template.boundHashOps("etiot:alarm:message:" + alarmId).putAll(alarmMap);
		this.template.boundHashOps("etiot:alarm:message:" + alarmId).expire(Constant.REDIS_ALARM_CACHE_DAYS, TimeUnit.DAYS);
	}

	@Override
	public void insertAdminAlarmMsg(String accountId, String alarmId) {
		this.template.boundListOps("etiot:admin:message:" + accountId).leftPush(alarmId);
	    this.template.boundListOps("etiot:admin:message:" + accountId).trim(0L, 99L);
	}

}
