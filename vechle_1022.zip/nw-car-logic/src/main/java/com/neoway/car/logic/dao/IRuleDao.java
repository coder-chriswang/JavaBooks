/**
 * @company 有方物联
 * @file IRuleDao.java
 * @author guojy
 * @date 2018年5月2日 
 */
package com.neoway.car.logic.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * @description :规则参数下发DAO接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年5月2日
 */
public interface IRuleDao {
	/**
	 * 更新围栏操作结果
	 * @param id
	 * @param result 结果  1:成功 -1 失败
	 */
	public void updateResultById(@Param("id") String id,@Param("result") String result);
	
	/**
	 * 查询待执行的规则下发任务
	 * @param equId 设备ID
	 * @return
	 */
	public List<Map<String,Object>> findTodoRuleTasks(String equId);
}
