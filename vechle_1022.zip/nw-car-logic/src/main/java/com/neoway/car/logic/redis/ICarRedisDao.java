/**
 * @company 有方物联
 * @file IEquRedisDao.java
 * @author guojy
 * @date 2018年4月12日 
 */
package com.neoway.car.logic.redis;

import java.util.Map;

/**
 * @description :车辆redis缓存接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月12日
 */
public interface ICarRedisDao {
	/**
	 * 更新车辆redis状态
	 * @param carId
	 * @param value
	 */
	public void updateCarState(String carId,Map<String, String> value);
	/**
	 * @param carId
	 * @return
	 */
	public Map<String, String> getCarInfoByCarId(String carId);
}
