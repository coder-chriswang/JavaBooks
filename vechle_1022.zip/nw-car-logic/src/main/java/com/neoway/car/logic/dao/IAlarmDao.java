/**
 * @company 有方物联
 * @file IAlarmStartDao.java
 * @author guojy
 * @date 2018年4月15日 
 */
package com.neoway.car.logic.dao;

import java.util.Map;

import com.neoway.car.logic.entity.AlarmStartEntity;

/**
 * @description :告警接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
public interface IAlarmDao {
	/**
	 * 新增告警开始
	 * @param alarmStartEntity
	 * @return
	 */
	public int insertAlarmStart(AlarmStartEntity alarmStartEntity);
	
	/**
	 * 新增告警结束
	 * @param alarmEndMap
	 * @return
	 */
	public int insertAlarmEnd(Map<String,Object> alarmEndMap);
}
