/**
 * @company 有方物联
 * @file IPositionDaoHBase.java
 * @author guojy
 * @date 2018年4月16日 
 */
package com.neoway.car.logic.hdfs;

import java.io.IOException;
import java.util.Map;

/**
 * @description :GPS定位数据hbase存储接口定义
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public interface IPositionDaoHBase {
	/**
	 * GPS数据存储hbase
	 * @param equId 设备ID  作为hbase的rowkey
	 * @param paramMap 数据
	 * @throws IOException
	 */
	public void insert(String equId, Map<String, String> paramMap);
	
	/**
	 * 记录行程数据
	 * @param equId
	 * @param tripMap
	 */
	public void insertTrip(String equId,Map<String, String> tripMap);
}
