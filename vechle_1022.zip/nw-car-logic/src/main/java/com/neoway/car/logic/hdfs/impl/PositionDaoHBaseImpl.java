/**
 * @company 有方物联
 * @file PositionDaoHBaseImpl.java
 * @author guojy
 * @date 2018年4月16日
 */
package com.neoway.car.logic.hdfs.impl;

import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.base.Strings;
import com.neoway.car.logic.hdfs.IPositionDaoHBase;

/**
 * @description :GPS定位数据hbase存储
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
@Component
public class PositionDaoHBaseImpl implements IPositionDaoHBase {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private DateTimeFormatter f1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private DateTimeFormatter f2 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    @Autowired
    private Connection conn;
    /* (non-Javadoc)
     * @see com.etiot.car.logic.hdfs.IPositionDaoHBase#insert(java.lang.String, java.util.Map)
     */
    @Override
    public void insert(String equId, Map<String, String> paramMap) {
        try {
            if("0".equals(paramMap.get("lbsFlag"))){
                logger.warn("设备未定位数据不入Hbase库={}",paramMap);
            }
            HTable hTable = (HTable)this.conn.getTable(TableName.valueOf("GPS_HIS"));
            LocalDateTime dtl = LocalDateTime.parse(paramMap.get("gpsTime"), this.f1);
            String gpsTime = dtl.format(this.f2);
            String rowKey = equId + ":" + gpsTime;
            Put put = new Put(rowKey.getBytes());
            put.addColumn("c".getBytes(), "equId".getBytes(),Bytes.toBytes(equId));
            put.addColumn("c".getBytes(), "phone".getBytes(),Bytes.toBytes(paramMap.get("phone")));
            put.addColumn("c".getBytes(), "carId".getBytes(),Bytes.toBytes(paramMap.get("carId")));
            put.addColumn("c".getBytes(), "carNum".getBytes(),Bytes.toBytes(paramMap.get("carNum")));
            put.addColumn("c".getBytes(), "alarm".getBytes(),Bytes.toBytes(paramMap.get("alarm")));
            put.addColumn("c".getBytes(), "acc".getBytes(),Bytes.toBytes(paramMap.get("acc")));
            put.addColumn("c".getBytes(), "lbsFlag".getBytes(),Bytes.toBytes(paramMap.get("lbsFlag")));
            put.addColumn("c".getBytes(), "latitude".getBytes(),Bytes.toBytes(paramMap.get("latitude")));
            put.addColumn("c".getBytes(), "longitude".getBytes(),Bytes.toBytes(paramMap.get("longitude")));
            put.addColumn("c".getBytes(), "altitude".getBytes(),Bytes.toBytes(paramMap.get("altitude")));
            put.addColumn("c".getBytes(), "speed".getBytes(),Bytes.toBytes(paramMap.get("speed")));
            put.addColumn("c".getBytes(), "direation".getBytes(),Bytes.toBytes(paramMap.get("direation")));
            put.addColumn("c".getBytes(), "gpsTime".getBytes(),Bytes.toBytes(paramMap.get("gpsTime")));
            put.addColumn("c".getBytes(), "linkTime".getBytes(),Bytes.toBytes(paramMap.get("linkTime")));
            put.addColumn("c".getBytes(), "insertTime".getBytes(),Bytes.toBytes(LocalDateTime.now().format(this.f2)));
            String simSignal = paramMap.get("simSignal");
            if(!Strings.isNullOrEmpty(simSignal)){
                put.addColumn("c".getBytes(), "simSignal".getBytes(),Bytes.toBytes(simSignal));
            }
            String satelliteNum = paramMap.get("satelliteNum");
            if(!Strings.isNullOrEmpty(satelliteNum)){
                put.addColumn("c".getBytes(), "satelliteNum".getBytes(),Bytes.toBytes(satelliteNum));
            }
            String mileage = paramMap.get("mileage");
            if(!Strings.isNullOrEmpty(mileage)){
                put.addColumn("c".getBytes(), "mileage".getBytes(),Bytes.toBytes(mileage));
            }

            hTable.put(put);
            hTable.close();
        } catch (DateTimeException e) {
            logger.error("GPS时间转化异常!",e);
        } catch (IOException e) {
            logger.error("hbase存储发生异常！",e);
        } catch (Exception e) {
            logger.error("插入GPS数据异常！", e);
        }
    }
    @Override
    public void insertTrip(String equId, Map<String, String> tripMap) {
        try {
            HTable hTable = (HTable)this.conn.getTable(TableName.valueOf("GPS_TRIP"));
            LocalDateTime dtl = LocalDateTime.parse(tripMap.get("startTime"), this.f1);
            String startTime = dtl.format(this.f2);
            String rowKey = equId + ":" + startTime;
            Put put = new Put(rowKey.getBytes());
            put.addColumn("c".getBytes(), "tripId".getBytes(),Bytes.toBytes(tripMap.get("tripId")));
            put.addColumn("c".getBytes(), "equId".getBytes(),Bytes.toBytes(equId));
            put.addColumn("c".getBytes(), "carId".getBytes(),Bytes.toBytes(tripMap.getOrDefault("carId", "")));
            put.addColumn("c".getBytes(), "deptId".getBytes(),Bytes.toBytes(tripMap.get("deptId")));
            put.addColumn("c".getBytes(), "startTime".getBytes(),Bytes.toBytes(tripMap.get("startTime")));
            put.addColumn("c".getBytes(), "startLat".getBytes(),Bytes.toBytes(tripMap.get("startLat")));
            put.addColumn("c".getBytes(), "startLng".getBytes(),Bytes.toBytes(tripMap.get("startLng")));
            put.addColumn("c".getBytes(), "endTime".getBytes(),Bytes.toBytes(tripMap.get("endTime")));
            put.addColumn("c".getBytes(), "endLat".getBytes(),Bytes.toBytes(tripMap.get("endLat")));
            put.addColumn("c".getBytes(), "endLng".getBytes(),Bytes.toBytes(tripMap.get("endLng")));
            put.addColumn("c".getBytes(), "timer".getBytes(),Bytes.toBytes(tripMap.get("timer")));
            put.addColumn("c".getBytes(), "avgSpeed".getBytes(),Bytes.toBytes(tripMap.get("avgSpeed")));
            put.addColumn("c".getBytes(), "mileage".getBytes(),Bytes.toBytes(tripMap.get("mileage")));
            hTable.put(put);
            hTable.close();
        }catch (IOException e) {
            logger.error("hbase存储发生异常！",e);
        }
    }

}
