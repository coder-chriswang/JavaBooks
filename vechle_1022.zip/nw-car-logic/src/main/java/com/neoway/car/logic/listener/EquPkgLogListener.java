/**
 * @company 有方物联
 * @file EquPkgLogListener.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.logic.listener;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Maps;
import com.neoway.car.logic.dao.IEquDao;
import com.neoway.car.logic.hdfs.IEquPackagesDaoHbase;
import com.neoway.car.logic.redis.IEquRedisDao;
import com.neoway.car.logic.util.JsonTools;

/**
 * @description :设备报文MQ消息消费
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
@Component
public class EquPkgLogListener {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IEquPackagesDaoHbase equPackagesDaoHbase;
	@Autowired
	private IEquDao equDao;
	@Autowired
	private IEquRedisDao equRedisDao;
	
	@RabbitListener(bindings={@org.springframework.amqp.rabbit.annotation.QueueBinding(value=@org.springframework.amqp.rabbit.annotation.Queue(value="carEquPkgLogQueue", durable="true"), exchange=@org.springframework.amqp.rabbit.annotation.Exchange(value="carEquPkgLog", type="fanout", durable="true"))})
	public void log(String message){
		logger.debug("报文日志：{}", message);
		Map<String, String> logIn = JsonTools.toMap(message);
		String phone = logIn.get("phone");
		Map<String, String> equInfo = equRedisDao.findEquInfoByID(phone);
		if(equInfo == null || equInfo.isEmpty()) {
			Map<String,Object> equMap = equDao.queryEquByPhone(phone);
			if(equMap != null){
				equInfo = Maps.newHashMap();
				equInfo.put("equId", String.valueOf(equMap.get("equId")));
				equInfo.put("authCode", String.valueOf(equMap.get("authCode")));
				equInfo.put("entId", String.valueOf(equMap.get("entId")));
				equInfo.put("deptId", String.valueOf(equMap.get("deptId")));
				equInfo.put("superVideo", String.valueOf(equMap.get("superVideo")));
				equInfo.put("modelId", String.valueOf(equMap.get("modelId")));
				equInfo.put("phone", phone);
				equRedisDao.updateEquInfo(phone, equInfo);
			} else {
				Map<String, Object> equInfoBak = equDao.queryEquByPhone("0" + phone);
				if (equInfoBak != null) {
					equInfo = Maps.newHashMap();
					equInfo.put("equId", String.valueOf(equInfoBak.get("equId")));
					equInfo.put("authCode", String.valueOf(equInfoBak.get("authCode")));
					equInfo.put("entId", String.valueOf(equInfoBak.get("entId")));
					equInfo.put("deptId", String.valueOf(equInfoBak.get("deptId")));
					equInfo.put("superVideo", String.valueOf(equInfoBak.get("superVideo")));
					equInfo.put("modelId", String.valueOf(equInfoBak.get("modelId")));
					equInfo.put("phone", "0" + phone);
					logIn.put("phone", "0" + phone);
					equRedisDao.updateEquInfo("0" + phone, equInfo);
				} else {
					logger.warn("通过手机号查找不到对应的设备：{}", logIn.get("phone"));
					return;
				}
			}
		}
		logIn.put("equId", equInfo.get("equId"));
		equPackagesDaoHbase.insert(logIn.get("equId"), logIn);
	}
}
