/**
 * @company 有方物联
 * @file BizAlarmEntity.java
 * @author hedong
 * @date 2018年3月22日 
 */
package com.neoway.car.logic.entity;

import java.util.Date;


/**
 * @description :告警实体类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
public class AlarmStartEntity {
	/**
	 * 告警ID
	 */
	private String alarmId;
    /**
     * 车辆ID
     */
    private String carId;
    /**
     * 设备ID
     */
    private String equId;
    /**
     * 部门ID
     */
    private String deptId;
    /**
     * 告警类型
     * 1：超速告警 2：疲劳驾驶 8：亏电告警  20 进出区域告警 29碰撞预警 30 侧翻预警19 超时停车  101 怠速告警 102 离线告警 
     */
    private String alarmType;
    /**
     * 告警开始时间
     */
    private Date startTime;
    /**
     * 告警开始经度
     */
    private String startLng;
    /**
     * 告警开始维度
     */
    private String startLat;
    /**
     * 告警地址
     */
    private String address;
    /**
     * 1已读  0未读
     */
    private String isread;
    /**
     * 告警描述
     */
    private String description;
    /**
     * acc状态 
     * 0：关闭 1：开启
     */
    private String acc;
    /**
     * 方向角
     */
    private String direation;
    /**
     * 定位时间
     */
    private String gpsTime;
    /**
     * 速度
     */
    private String speed;
    /**
     * 定位状态
     * 1：gps 2：基站定位 3：未定位
     */
    private String lbsFlag;
    /**
     * 里程
     */
    private String mileage;
    /**
     * 0：离线 1：在线 2：怠速（怠速时需要返回怠速时间）
     */
    private String online;
    /**
     * 基站信号
     */
    private String simSignal;
    /**
     * 怠速时间
     */
    private String idlingDuration;
    /**
     * 通讯时间
     */
    private String linkTime;
    
    /**
     * 卫星数
     */
    private String satelliteNum;
    /**
	 * 
	 */
	public AlarmStartEntity() {
		super();
	}

	/**
	 * @param alarmId
	 * @param carId
	 * @param deptId
	 * @param alarmType
	 * @param startTime
	 * @param startLng
	 * @param startLat
	 * @param address
	 * @param isread
	 * @param description
	 * @param acc
	 * @param direation
	 * @param gpsTime
	 * @param speed
	 * @param lbsFlag
	 * @param mileage
	 * @param online
	 * @param simSignal
	 * @param idlingDuration
	 * @param linkTime
	 */
	public AlarmStartEntity(String alarmId, String carId, String equId, String deptId, String alarmType, Date startTime,
			String startLng, String startLat, String address, String isread, String description, String acc,
			String direation, String gpsTime, String speed, String lbsFlag, String mileage, String online,
			String simSignal, String idlingDuration, String linkTime,String satelliteNum) {
		super();
		this.alarmId = alarmId;
		this.carId = carId;
		this.equId = equId;
		this.deptId = deptId;
		this.alarmType = alarmType;
		this.startTime = startTime;
		this.startLng = startLng;
		this.startLat = startLat;
		this.address = address;
		this.isread = isread;
		this.description = description;
		this.acc = acc;
		this.direation = direation;
		this.gpsTime = gpsTime;
		this.speed = speed;
		this.lbsFlag = lbsFlag;
		this.mileage = mileage;
		this.online = online;
		this.simSignal = simSignal;
		this.idlingDuration = idlingDuration;
		this.linkTime = linkTime;
		this.satelliteNum = satelliteNum;
	}

	public String getAlarmId() {
        return alarmId;
    }

    public void setAlarmId(String alarmId) {
        this.alarmId = alarmId;
    }

    public String getCarId() {
        return carId;
    }

    public void setCarId(String carId) {
        this.carId = carId;
    }

    /**
	 * @return the equId
	 */
	public String getEquId() {
		return equId;
	}

	/**
	 * @param equId the equId to set
	 */
	public void setEquId(String equId) {
		this.equId = equId;
	}

	public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getAlarmType() {
        return alarmType;
    }

    public void setAlarmType(String alarmType) {
        this.alarmType = alarmType;
    }


    public String getStartLng() {
        return startLng;
    }

    public void setStartLng(String startLng) {
        this.startLng = startLng;
    }

    public String getStartLat() {
        return startLat;
    }

    public void setStartLat(String startLat) {
        this.startLat = startLat;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

  

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAcc() {
        return acc;
    }

    public void setAcc(String acc) {
        this.acc = acc;
    }

    public String getDireation() {
        return direation;
    }

    public void setDireation(String direation) {
        this.direation = direation;
    }

    public String getGpsTime() {
        return gpsTime;
    }

    public void setGpsTime(String gpsTime) {
        this.gpsTime = gpsTime;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getLbsFlag() {
        return lbsFlag;
    }

    public void setLbsFlag(String lbsFlag) {
        this.lbsFlag = lbsFlag;
    }

    public String getMileage() {
        return mileage;
    }

    public void setMileage(String mileage) {
        this.mileage = mileage;
    }

    public String getOnline() {
        return online;
    }

    public void setOnline(String online) {
        this.online = online;
    }

    public String getSimSignal() {
        return simSignal;
    }

    public void setSimSignal(String simSignal) {
        this.simSignal = simSignal;
    }

	public String getIsread() {
		return isread;
	}

	public void setIsread(String isread) {
		this.isread = isread;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public String getLinkTime() {
		return linkTime;
	}

	public void setLinkTime(String linkTime) {
		this.linkTime = linkTime;
	}

	public String getIdlingDuration() {
		return idlingDuration;
	}

	public void setIdlingDuration(String idlingDuration) {
		this.idlingDuration = idlingDuration;
	}

	/**
	 * @return the satelliteNum
	 */
	public String getSatelliteNum() {
		return satelliteNum;
	}

	/**
	 * @param satelliteNum the satelliteNum to set
	 */
	public void setSatelliteNum(String satelliteNum) {
		this.satelliteNum = satelliteNum;
	}

}
