package com.neoway.car.logic.util;

/**
 * <pre>
 *  描述: OBD自定义扩展标志位
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/04 14:23
 */
public class ObdAlarm extends AbstractBitTool {

    /**
     * 急加速报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm0(long obdAlarm) {
        return convert(obdAlarm, 0, 1);
    }

    /**
     * 急减速报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm1(long obdAlarm) {
        return convert(obdAlarm, 1, 1);
    }

    /**
     * 急拐弯报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm2(long obdAlarm) {
        return convert(obdAlarm, 2, 1);
    }


    /**
     * 急变道报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm3(long obdAlarm) {
        return convert(obdAlarm, 3, 1);
    }

    /**
     * ECT低温报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm4(long obdAlarm) {
        return convert(obdAlarm, 4, 1);
    }

    /**
     * ECT高温报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm5(long obdAlarm) {
        return convert(obdAlarm, 5, 1);
    }

    /**
     * RPM报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm6(long obdAlarm) {
        return convert(obdAlarm, 6, 1);
    }

    /**
     * 怠速报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm7(long obdAlarm) {
        return convert(obdAlarm, 7, 1);
    }

    /**
     * 插入报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm8(long obdAlarm) {
        return convert(obdAlarm, 8, 1);
    }

    /**
     * 拔出报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm9(long obdAlarm) {
        return convert(obdAlarm, 9, 1);
    }

    /**
     * 点火报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm10(long obdAlarm) {
        return convert(obdAlarm, 10, 1);
    }

    /**
     * 熄火报警
     * @param obdAlarm
     * @return
     */
    public static byte obdAlarm11(long obdAlarm) {
        return convert(obdAlarm, 11, 1);
    }

    /**
     * 通过pos索引位置计算告警位
     * @param alarm
     * @param pos
     * @return
     */
    public static byte selectAlarm(long alarm,int pos){
        return convert(alarm, pos, 1);
    }
}
