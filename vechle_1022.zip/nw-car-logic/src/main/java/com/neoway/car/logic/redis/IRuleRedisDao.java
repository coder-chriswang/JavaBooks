/**
 * @company 有方物联
 * @file IRuleRedisDao.java
 * @author guojy
 * @date 2018年7月4日 
 */
package com.neoway.car.logic.redis;

import java.util.Map;

/**
 * @description :规则redis缓存  
 * <br>超速、疲劳驾驶、围栏、怠速对应的规则：tts消息联动、拍照联动、摄像联动
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月4日
 */
public interface IRuleRedisDao {
	/**
	 * 查询设备规则redis缓存
	 * @param equId 设备ID
	 * @return
	 */
	public Map<String, String> findEquRulesByID(String equId);
	/**
	 * 查询规则信息
	 * @param ruleId 规则ID
	 * @return
	 */
	public Map<String, String> findRuleByID(String ruleId);
}
