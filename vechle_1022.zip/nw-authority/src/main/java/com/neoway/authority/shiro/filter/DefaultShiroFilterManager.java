/**
 * @company neoway
 * @file DefaultShiroFilterManager.java
 * @author guojy
 * @date 2019年2月21日
 */
package com.neoway.authority.shiro.filter;

import java.util.Map;

import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.filter.mgt.DefaultFilterChainManager;
import org.apache.shiro.web.filter.mgt.PathMatchingFilterChainResolver;
import org.apache.shiro.web.servlet.AbstractShiroFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @description shiro filter
 * @author guojy
 * @version V1.0.0
 * @date 2019年02月21日 14:58:25
 */
public class DefaultShiroFilterManager implements ShiroFilterManager {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private ShiroFilterFactoryBean shiroFilterFactoryBean;
	private ShiroManager shiroManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.neoway.authority.shiro.filter.ShiroFilterManager#reCreateFilterChains
	 * ()
	 */
	// 此方法加同步锁
	@Override
	public synchronized void reCreateFilterChains() {
		AbstractShiroFilter shiroFilter = null;
		try {
			shiroFilter = (AbstractShiroFilter) shiroFilterFactoryBean.getObject();
		} catch (Exception e) {
			logger.error("getShiroFilter from shiroFilterFactoryBean error!", e);
			throw new RuntimeException("get ShiroFilter from shiroFilterFactoryBean error!");
		}

		PathMatchingFilterChainResolver filterChainResolver = (PathMatchingFilterChainResolver) shiroFilter
				.getFilterChainResolver();
		DefaultFilterChainManager manager = (DefaultFilterChainManager) filterChainResolver.getFilterChainManager();

		// 清空老的权限控制
		manager.getFilterChains().clear();

		shiroFilterFactoryBean.getFilterChainDefinitionMap().clear();
		shiroFilterFactoryBean.setFilterChainDefinitionMap(shiroManager.loadFilterChainDefinitions());
		// 重新构建生成
		Map<String, String> chains = shiroFilterFactoryBean.getFilterChainDefinitionMap();
		for (Map.Entry<String, String> entry : chains.entrySet()) {
			String url = entry.getKey();
			String chainDefinition = entry.getValue().trim().replace(" ", "");
			manager.createChain(url, chainDefinition);
		}

	}

	public void setShiroFilterFactoryBean(ShiroFilterFactoryBean shiroFilterFactoryBean) {
		this.shiroFilterFactoryBean = shiroFilterFactoryBean;
	}


	public void setShiroManager(ShiroManager shiroManager) {
		this.shiroManager = shiroManager;
	}

}
