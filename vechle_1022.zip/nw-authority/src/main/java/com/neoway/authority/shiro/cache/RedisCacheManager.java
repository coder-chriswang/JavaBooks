/**
 * @company 有方物联
 * @file RedisCacheManager.java
 * @author guojy
 * @date 2017年7月11日 
 */
package com.neoway.authority.shiro.cache;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.apache.shiro.cache.CacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.neoway.core.extend.redis.RedisManager;

/**
 * @description :CacheManager的redis实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年7月11日
 */
@Component
public class RedisCacheManager implements CacheManager {

	private static final Logger logger = LoggerFactory
			.getLogger(RedisCacheManager.class);

	@SuppressWarnings("rawtypes")
	private final ConcurrentMap<String, Cache> caches = new ConcurrentHashMap<String, Cache>();

	/**
	 * Jedis 客户端
	 */
	@Autowired
	private RedisManager redisManager;

	/**
	 * Redis缓存前缀
	 */
	private String keyPrefix = "shiro_redis_cache:";
	
	/**
	 * @return
	 */
	public String getKeyPrefix() {
		return keyPrefix;
	}

	/**
	 * @param keyPrefix
	 */
	public void setKeyPrefix(String keyPrefix) {
		this.keyPrefix = keyPrefix;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public <K, V> Cache<K, V> getCache(String name) throws CacheException {
		logger.debug("获取名称为: " + name + " 的RedisCache实例");
		Cache c = caches.get(name);
		if (c == null) {
			// create a new cache instance
			c = new RedisCache<K, V>(redisManager, keyPrefix);
			// add it to the cache collection
			caches.put(name, c);
		}
		return c;
	}

}
