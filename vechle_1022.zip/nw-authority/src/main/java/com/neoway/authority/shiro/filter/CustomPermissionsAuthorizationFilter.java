/**
 * @company 有方物联
 * @file CustomPermissionsAuthorizationFilter.java
 * @author guojy
 * @date 2017年7月13日 
 */
package com.neoway.authority.shiro.filter;

import java.io.IOException;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authz.AuthorizationFilter;

/**
 * @description :自定义权限过滤器,处理superadmin授权
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年7月13日
 */
public class CustomPermissionsAuthorizationFilter extends AuthorizationFilter {
	@Override
	public boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue)
			throws IOException {
		
		Subject subject = getSubject(request, response);
        String[] perms = (String[]) mappedValue;

        boolean isPermitted = true;
        if (perms != null && perms.length > 0) {
            if (perms.length == 1) {
                if (!subject.isPermitted(perms[0])) {
                    isPermitted = false;
                }
            } else {
                if (!subject.isPermittedAll(perms)) {
                    isPermitted = false;
                }
            }
        }

        return isPermitted;
	}
}
