/**
 * @company 有方物联
 * @file ShiroManager.java
 * @author guojy
 * @date 2018年3月13日 
 */
package com.neoway.authority.shiro.filter;

import java.util.Map;

/**
 * @description :shiro过滤规则管理：动态加载过滤规则、规则重建
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月13日
 */
public interface ShiroManager {
	/**
	 * 加载过滤配置信息
	 * @return
	 */
	public Map<String, String> loadFilterChainDefinitions();
}
