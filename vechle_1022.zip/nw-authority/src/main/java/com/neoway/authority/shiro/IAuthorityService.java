/**
 * @company 有方物联
 * @file IAuthorityService.java
 * @author guojy
 * @date 2018年3月6日 
 */
package com.neoway.authority.shiro;

import java.util.List;
import java.util.Map;

import com.neoway.core.bean.User;
import com.neoway.core.exception.CustomRuntimeException;

/**
 * @description :权限管理服务接口定义
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月6日
 */
public interface IAuthorityService {
	/**
	 * 通过用户名 密码查找用户信息
	 * @param account 账号
	 * @param password 密码
	 * @param entCode 企业标识
	 * @return
	 */
	public User findLoginUser(String entCode,String account,String password) throws CustomRuntimeException;
	
	/**
	 * 通过账号获取用户权限字符串
	 * <p>超级管理员则查询企业最大权限  普通账号则查询对应的分配权限<p>
	 * @param entCode 企业标识
	 * @param account 企业账号
	 * @param superadmin 是否超级管理员
	 * @return
	 */
	public List<String> findUserAuthorities(String entCode,String account,boolean superadmin);
	
	/**
	 * 获取系统全部资源权限信息
	 * @return
	 */
	public Map<String, String> findAllResource();
	
	/**
	 * 获取系统白名单资源权限
	 * @return
	 */
	public Map<String, String> findAuthWhite();
}
