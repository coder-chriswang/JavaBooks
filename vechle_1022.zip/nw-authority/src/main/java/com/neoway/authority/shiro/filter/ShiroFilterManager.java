/**
 * @company neoway
 * @file IShiroFilterManager.java
 * @author guojy
 * @date 2019年2月21日
 */
package com.neoway.authority.shiro.filter;

/**
 * @description TODO
 * @author 20181114503
 * @version V1.0.0
 * @date 2019年02月21日 14:57:28
 */
public interface ShiroFilterManager {
	/**
	 * 重新构建权限过滤器
	 * <p>一般在修改了用户角色、用户等信息时，需要再次调用该方法
	 */
	public void reCreateFilterChains();
}
