/**
 * @company 有方物联
 * @file CustomToken.java
 * @author guojy
 * @date 2018年6月5日 
 */
package com.neoway.authority.shiro.realm;

import org.apache.shiro.authc.UsernamePasswordToken;

/**
 * @description :扩展shiro 登录token
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年6月5日
 */
public class CustomToken extends UsernamePasswordToken {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String entCode;
	/**
	 * @return the entCode
	 */
	public String getEntCode() {
		return entCode;
	}
	/**
	 * @param entCode the entCode to set
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}
	/**
	 * @param entCode
	 */
	public CustomToken(String entCode,String username, String password) {
		this.entCode = entCode;
		this.setUsername(username);
		this.setPassword(password.toCharArray());
	}
	/**
	 * 
	 */
	public CustomToken() {
		super();
	}
	

}
