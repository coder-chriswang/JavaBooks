/**
 * @company 有方物联
 * @file LoginFilter.java
 * @author guojy
 * @date 2017年12月5日 
 */
package com.neoway.authority.shiro.filter;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.shiro.config.Ini;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.AccessControlFilter;
import org.apache.shiro.web.util.WebUtils;
import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;

/**
 * @description :shiro登录过滤器  处理ajax请求方式
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年12月5日
 */
public class LoginFilter extends AccessControlFilter {
	private final Logger logger = Logger.getLogger(LoginFilter.class);
	
	private String configPath;
	private Ini.Section section;

	/* (non-Javadoc)
	 * @see org.apache.shiro.web.filter.AccessControlFilter#isAccessAllowed(javax.servlet.ServletRequest, javax.servlet.ServletResponse, java.lang.Object)
	 */
	@Override
	protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue)
			throws Exception {
		Subject subject = getSubject(request, response);
		Object principal = subject.getPrincipal();
		HttpServletRequest httpRequest = WebUtils.toHttp(request);
		
		if(principal != null || isUrlBlank(httpRequest)){
			return Boolean.TRUE;
		}
		if(isAjax(httpRequest)){
			Map<String,String> result = Maps.newHashMap();
			result.put("status", "401");
			result.put("msg", "需要登录");
			out(response, result);
			return Boolean.FALSE;
		}else{
			Map<String,String> result = Maps.newHashMap();
			result.put("status", "401");
			result.put("msg", "需要登录");
			out(response, result);
		}
		return Boolean.FALSE;
	}
	
	/**
	 * 请求是否白名单
	 * @param request
	 * @return
	 */
	private boolean isUrlBlank(HttpServletRequest request){
		Iterator<String> iterator = section.keySet().iterator();
		while(iterator.hasNext()){
			String blank_url = iterator.next();
			if(pathsMatch(blank_url, request)){
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see org.apache.shiro.web.filter.AccessControlFilter#onAccessDenied(javax.servlet.ServletRequest, javax.servlet.ServletResponse)
	 */
	@Override
	protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
		//saveRequestAndRedirectToLogin(request, response);
		return Boolean.FALSE;
	}

	/**
     * 判断ajax请求
     * @param request
     * @return
     */
    boolean isAjax(HttpServletRequest request){
        return  (request.getHeader("X-Requested-With") != null  && "XMLHttpRequest".equals( request.getHeader("X-Requested-With").toString())   ) ;
    }
    
    /**
     * json输出
     * @param response
     * @param resultMap
     */
    public void out(ServletResponse response, Map<String, String> resultMap){
    	PrintWriter out = null;
    	try {
    		response.setCharacterEncoding("UTF-8");//设置编码
    		response.setContentType("application/json");//设置返回类型
    		out = response.getWriter();
    		ObjectMapper objectMapper = new ObjectMapper();
			String content = objectMapper.writeValueAsString(resultMap);
    		out.println(content);//输出
    	} catch (Exception e) {
    		logger.error("JSON格式输出出错");
    	}finally{
    		if(null != out){
    			out.flush();
    			out.close();
    		}
    	}
    }

	/**
	 * @param configPath the configPath to set
	 */
	public void setConfigPath(String configPath) {
		this.configPath = configPath;
		Ini ini = new Ini();
		org.springframework.core.io.Resource iniResource = new ClassPathResource(this.configPath);
		try {
			ini.load(iniResource.getInputStream());
			this.section = ini.getSection("urls");
		} catch (Exception e) {
			logger.error("加载默认ini配置异常", e);
		} 
	}
    
    
}
