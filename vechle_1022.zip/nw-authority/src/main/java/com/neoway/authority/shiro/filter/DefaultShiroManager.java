/**
 * @company 有方物联
 * @file DefaultShiroManager.java
 * @author guojy
 * @date 2017年7月11日 
 */
package com.neoway.authority.shiro.filter;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.shiro.config.ConfigurationException;
import org.apache.shiro.config.Ini;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.neoway.authority.shiro.IAuthorityService;

/**
 * @description :shiro过滤规则默认实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年7月11日
 */
public class DefaultShiroManager implements ShiroManager {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	// ini配置文件
    private String configPath;
    private IAuthorityService authorityService;
    
	@Override
	public Map<String, String> loadFilterChainDefinitions() {
		Ini ini = new Ini();
        org.springframework.core.io.Resource iniResource = new ClassPathResource(configPath);
        // 从INI配置文件中加载URL验证规则
        if (null != iniResource && iniResource.exists()) {
            try {
                ini.load(iniResource.getInputStream());
            } catch (ConfigurationException e) {
            	logger.debug(e.getMessage());
            } catch (IOException e) {
            	logger.debug(e.getMessage());
            }
        }
        Ini.Section section = ini.getSection("urls");
        if (section == null) {
            section = ini.addSection("urls");
        }
        Map<String,String> urlStategysMap  = authorityService.findAllResource();
        logger.info("allprivileges list:{}",urlStategysMap.toString());
        //白名单url
        Map<String,String> whiteMap  = authorityService.findAuthWhite();
        logger.info("white list:{}", whiteMap.toString());
        if(urlStategysMap!=null){
        	Iterator<Entry<String, String>> iterator = urlStategysMap.entrySet().iterator();
        	while(iterator.hasNext()){
        		Entry<String, String> entity = iterator.next();
        		section.put(entity.getKey()+"*", "loginFilter,perms[\""+entity.getValue()+"\"]");
        	}
        }
        
        if(whiteMap!=null){
        	Iterator<Entry<String, String>> iterator = whiteMap.entrySet().iterator();
        	while(iterator.hasNext()){
        		Entry<String, String> entity = iterator.next();
        		section.put(entity.getKey()+"*", "loginFilter,authc,perms[\""+entity.getValue()+"\"]");
        	}
        }
        section.put("/**", "loginFilter,authc");
        logger.info("load all system url perms:{}",section.entrySet().toString());
        return section;
	}

	/**
	 * @param configPath the configPath to set
	 */
	public void setConfigPath(String configPath) {
		this.configPath = configPath;
	}

	public void setAuthorityService(IAuthorityService authorityService) {
		this.authorityService = authorityService;
	}

}
