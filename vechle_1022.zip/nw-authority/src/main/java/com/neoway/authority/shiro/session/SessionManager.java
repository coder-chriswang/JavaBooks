/**
 * @company 有方物联
 * @file SessionManager.java
 * @author guojy
 * @date 2018年3月6日 
 */
package com.neoway.authority.shiro.session;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.shiro.session.Session;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.neoway.core.bean.User;

/**
 * @description :shiro session管理
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月6日
 */
@Component
public class SessionManager {
	@Autowired
	private RedisSessionDAO redisSessionDAO;
	
	/**
	 * 根据ID查询 SimplePrincipalCollection
	 * @param account	用户ID
	 * @return
	 */
	public List<SimplePrincipalCollection> getSimplePrincipalCollectionByUserId(String account){
		//获取所有session
		Collection<Session> sessions = redisSessionDAO.getActiveSessions();
		//定义返回
		List<SimplePrincipalCollection> list = new ArrayList<SimplePrincipalCollection>();
		for (Session session : sessions) {
			//获取SimplePrincipalCollection
			Object obj = session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY);
			if(null != obj && obj instanceof SimplePrincipalCollection){
				//强转
				SimplePrincipalCollection spc = (SimplePrincipalCollection)obj;
				//判断用户，匹配用户ID。
				obj = spc.getPrimaryPrincipal();
				if(null != obj && obj instanceof User){
					User user = (User)obj;
					//比较用户ID，符合即加入集合
					if(null != user && user.getAccount().equals(account)){
						list.add(spc);
					}
				}
			}
		}
		return list;
	}
	
	/**
	 * 清空用户ID对应的session
	 * @param accountId
	 */
	public void clearSession(String accountId){
		//获取所有session
		Collection<Session> sessions = redisSessionDAO.getActiveSessions();
		for (Session session : sessions) {
			//获取SimplePrincipalCollection
			Object obj = session.getAttribute(DefaultSubjectContext.PRINCIPALS_SESSION_KEY);
			if(null != obj && obj instanceof SimplePrincipalCollection){
				//强转
				SimplePrincipalCollection spc = (SimplePrincipalCollection)obj;
				//判断用户，匹配用户ID。
				obj = spc.getPrimaryPrincipal();
				if(null != obj && obj instanceof User){
					User user = (User)obj;
					//比较用户ID，符合即加入集合
					if(null != user && user.getAccountId().equals(accountId)){
						redisSessionDAO.delete(session);
						//session.stop();
						return;
					}
				}
			}
		}
	}
}
