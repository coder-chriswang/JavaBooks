/**
 * @company 有方物联
 * @file RedisSessionDAO.java
 * @author guojy
 * @date 2018年3月6日 
 */
package com.neoway.authority.shiro.session;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.UnknownSessionException;
import org.apache.shiro.session.mgt.eis.AbstractSessionDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.neoway.authority.utils.Constants;
import com.neoway.authority.utils.SerializeUtils;
import com.neoway.core.extend.redis.RedisManager;

/**
 * @description :AbstractSessionDAO的redis存储实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月6日
 */
@Component
public class RedisSessionDAO extends AbstractSessionDAO {
	private static Logger logger = LoggerFactory.getLogger(RedisSessionDAO.class);
	/**
	 * redis客户端管理
	 */
	@Autowired
	private RedisManager redisManager;
	

	/* (non-Javadoc)
	 * @see org.apache.shiro.session.mgt.eis.SessionDAO#update(org.apache.shiro.session.Session)
	 */
	@Override
	public void update(Session session) throws UnknownSessionException {
		this.saveSession(session);
	}

	/* (non-Javadoc)
	 * @see org.apache.shiro.session.mgt.eis.SessionDAO#delete(org.apache.shiro.session.Session)
	 */
	@Override
	public void delete(Session session) {
		if(session == null || session.getId() == null){
			logger.error("session or session id is null");
			return;
		}
		redisManager.del(this.getByteKey(session.getId()));
	}

	/* (non-Javadoc)
	 * @see org.apache.shiro.session.mgt.eis.SessionDAO#getActiveSessions()
	 */
	@Override
	public Collection<Session> getActiveSessions() {
		Set<Session> sessions = new HashSet<Session>();
		Set<String> keys = redisManager.keys(Constants.SESSION_DEFAULT_PREFIX + "*");
		if(keys != null && keys.size()>0){
			for(String key:keys){
				Session s = (Session)SerializeUtils.deserialize(redisManager.get(key.getBytes()));
				sessions.add(s);
			}
		}
		return sessions;
	}

	/* (non-Javadoc)
	 * @see org.apache.shiro.session.mgt.eis.AbstractSessionDAO#doCreate(org.apache.shiro.session.Session)
	 */
	@Override
	protected Serializable doCreate(Session session) {
		Serializable sessionId = this.generateSessionId(session);  
        this.assignSessionId(session, sessionId);
        this.saveSession(session);
		return sessionId;
	}

	/* (non-Javadoc)
	 * @see org.apache.shiro.session.mgt.eis.AbstractSessionDAO#doReadSession(java.io.Serializable)
	 */
	@Override
	protected Session doReadSession(Serializable sessionId) {
		if(sessionId == null){
			logger.error("session id is null");
			return null;
		}
		Session s = (Session)SerializeUtils.deserialize(redisManager.get(this.getByteKey(sessionId)));
		return s;
	}

	/**
	 * save session
	 * @param session
	 * @throws UnknownSessionException
	 */
	private void saveSession(Session session) throws UnknownSessionException{
		if(session == null || session.getId() == null){
			logger.error("session or session id is null");
			return;
		}
		session.setTimeout(Constants.EXPIRE_SECOND_TIME * 1000);		
		byte[] key = getByteKey(session.getId());
		byte[] value = SerializeUtils.serialize(session);
		this.redisManager.set(key, value, Constants.EXPIRE_SECOND_TIME);
	}
	
	/**
	 * 获得byte[]型的key
	 * @param key
	 * @return
	 */
	private byte[] getByteKey(Serializable sessionId){
		String preKey = Constants.SESSION_DEFAULT_PREFIX + sessionId;
		return preKey.getBytes();
	}
}
