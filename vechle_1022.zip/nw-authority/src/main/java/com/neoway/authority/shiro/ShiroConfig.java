/**
 * @company 有方物联
 * @file ShiroConfig.java
 * @author guojy
 * @date 2018年3月16日 
 */
package com.neoway.authority.shiro;

import java.util.Map;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;

import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.mgt.SessionManager;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.DelegatingFilterProxy;

import com.google.common.collect.Maps;
import com.neoway.authority.shiro.cache.RedisCacheManager;
import com.neoway.authority.shiro.filter.CustomPermissionsAuthorizationFilter;
import com.neoway.authority.shiro.filter.DefaultShiroFilterManager;
import com.neoway.authority.shiro.filter.DefaultShiroManager;
import com.neoway.authority.shiro.filter.LoginFilter;
import com.neoway.authority.shiro.filter.ShiroFilterManager;
import com.neoway.authority.shiro.filter.ShiroManager;
import com.neoway.authority.shiro.realm.CustomerRealm;
import com.neoway.authority.shiro.session.RedisSessionDAO;

/**
 * @description :shiro配置信息
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月16日
 */
@Configuration
public class ShiroConfig {
	@Autowired
	private RedisCacheManager cacheManager;
	@Autowired
	private RedisSessionDAO sessionDAO;
	@Value("${web.sessionid}")
	private String sessionid;
	@Autowired
	private IAuthorityService authorityService;
	
	@Bean  
    public FilterRegistrationBean filterRegistrationBean() {  
        FilterRegistrationBean filterRegistration = new FilterRegistrationBean();  
        filterRegistration.setFilter(new DelegatingFilterProxy("shiroFilter"));   
        filterRegistration.setEnabled(true);  
        filterRegistration.addUrlPatterns("/*");   
        filterRegistration.setDispatcherTypes(DispatcherType.REQUEST);  
        return filterRegistration;  
    }
	
	@Bean
	public org.apache.shiro.mgt.SecurityManager securityManager(){
		DefaultWebSecurityManager smg = new DefaultWebSecurityManager();
		smg.setRealm(realm());
		smg.setSessionManager(sessionManager());
		smg.setCacheManager(cacheManager);
		return smg;
	}
	
	@Bean
	public SessionManager sessionManager(){
		DefaultWebSessionManager sessionManager = new DefaultWebSessionManager();
		sessionManager.setSessionDAO(sessionDAO);
		SimpleCookie sessionIdCookie = new SimpleCookie();
		sessionIdCookie.setName(sessionid);
		sessionManager.setSessionIdCookie(sessionIdCookie);
		return sessionManager;
	}
	
	@Bean
	public AuthorizingRealm realm(){
		CustomerRealm realm = new CustomerRealm();
		HashedCredentialsMatcher credentialsMatcher = new HashedCredentialsMatcher();
		credentialsMatcher.setHashAlgorithmName("MD5");
		realm.setCredentialsMatcher(credentialsMatcher);
		realm.setAuthorityService(authorityService);
		return realm;
	}
	
	@Bean("shiroFilter")
	public ShiroFilterFactoryBean shiroFilterFactoryBean(){
		ShiroFilterFactoryBean shiroFilterBean = new ShiroFilterFactoryBean();
		shiroFilterBean.setSecurityManager(securityManager());
		shiroFilterBean.setLoginUrl("/");
		shiroFilterBean.setUnauthorizedUrl("/unauthorized");
		shiroFilterBean.setFilterChainDefinitionMap(shiroManager().loadFilterChainDefinitions());
		Map<String, Filter> filters = Maps.newLinkedHashMap();
		filters.put("loginFilter", loginFilter());
		filters.put("perms", permsFilter());
		shiroFilterBean.setFilters(filters);
		return shiroFilterBean;
	}
	
	@Bean
	public CustomPermissionsAuthorizationFilter permsFilter(){
		CustomPermissionsAuthorizationFilter perms = new CustomPermissionsAuthorizationFilter();
		return perms;
	}
	
	@Bean
	public LoginFilter loginFilter(){
		LoginFilter loginFilter = new LoginFilter();
		loginFilter.setConfigPath("shiro-url-rules.ini");
		return loginFilter;
	}
	
	@Bean
	public ShiroManager shiroManager(){
		DefaultShiroManager shiroManager = new DefaultShiroManager();
		shiroManager.setConfigPath("shiro-url-rules.ini");
		shiroManager.setAuthorityService(authorityService);
		return shiroManager;
	}
	
	@Bean
	public ShiroFilterManager shiroFilterManager(){
		DefaultShiroFilterManager shiroFilter = new DefaultShiroFilterManager();
		shiroFilter.setShiroFilterFactoryBean(shiroFilterFactoryBean());
		shiroFilter.setShiroManager(shiroManager());
		return shiroFilter;
	}
	
	@Bean
	public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(){
		AuthorizationAttributeSourceAdvisor authorizationAdvisor = new AuthorizationAttributeSourceAdvisor();
		authorizationAdvisor.setSecurityManager(securityManager());
		return authorizationAdvisor;
	}
	
}
