/**
 * @company 有方物联
 * @file Constants.java
 * @author guojy
 * @date 2018年3月6日 
 */
package com.neoway.authority.utils;

/**
 * @description :常量定义
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月6日
 */
public class Constants {
	/**
	 * redis中session的key的默认前缀
	 */
	public static String SESSION_DEFAULT_PREFIX="shiro_redis_session:";
	
	public static int EXPIRE_SECOND_TIME = 30 * 60;
	
	/**
	 * 用户权限信息redis缓存前缀
	 */
	public static String AUTHORIZATION_CACHE_PREFIX = "shiro_redis_cache:";
	
}
