/**
 * @company 有方物联
 * @file CustomerRealm.java
 * @author guojy
 * @date 2018年3月6日 
 */
package com.neoway.authority.shiro.realm;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import com.google.common.collect.Lists;
import com.neoway.authority.shiro.IAuthorityService;
import com.neoway.core.bean.User;
import com.neoway.core.exception.CustomRuntimeException;

/**
 * @description :shiro realm对象:登录认证、用户授权
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月6日
 */
public class CustomerRealm extends AuthorizingRealm {
	private static Logger logger = LoggerFactory.getLogger(CustomerRealm.class);
	private IAuthorityService authorityService;

	/* (non-Javadoc)
	 * @see org.apache.shiro.realm.AuthorizingRealm#doGetAuthorizationInfo(org.apache.shiro.subject.PrincipalCollection)
	 * 授权
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		User user = new User();
		Object userObj = principals.fromRealm(getName()).iterator().next();
		BeanUtils.copyProperties(userObj,user);
		List<String> permissionList = authorityService.findUserAuthorities(user.getEntCode(), user.getAccount(), user.isSuperadmin());
		Map<String,String> 	whiteMap  = authorityService.findAuthWhite();
		if(permissionList==null){
			permissionList = Lists.newArrayList();
		}
		if(whiteMap!=null){
			permissionList.addAll(whiteMap.values());
		}
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		if(permissionList!=null && !permissionList.isEmpty()){
			info.addStringPermissions(permissionList);
		}
		logger.info("加载用户{}授权信息：{}", user.getAccount(),permissionList);
		return info;
	}

	/* (non-Javadoc)
	 * @see org.apache.shiro.realm.AuthenticatingRealm#doGetAuthenticationInfo(org.apache.shiro.authc.AuthenticationToken)
	 * 登录
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken) throws AuthenticationException {
		CustomToken token = (CustomToken) authcToken;
		User user = new User(token.getUsername(),new String(token.getPassword()));
		try {
			user = authorityService.findLoginUser(token.getEntCode(),user.getAccount(), user.getPassword());
		} catch (CustomRuntimeException e) {
			throw new AuthenticationException(e.getMessage());
		} catch(Exception e1){
			throw new AuthenticationException("系统异常！",e1);
		}
		if(user == null){
			throw new UnknownAccountException("帐号或密码不正确！");
		}
		ByteSource credentialsSalt = ByteSource.Util.bytes(user.getAccount());
		return new SimpleAuthenticationInfo(user,new Md5Hash(user.getPassword(),user.getAccount()).toHex(),credentialsSalt, getName());
	}
	
	/* (non-Javadoc)
	 * @see org.apache.shiro.realm.AuthorizingRealm#getAuthorizationCacheKey(org.apache.shiro.subject.PrincipalCollection)
	 * 缓存对应的账号key
	 */
	@Override
	protected Object getAuthorizationCacheKey(PrincipalCollection principals) {
		if(principals==null)
    		return null;
		User user = (User) principals.getPrimaryPrincipal();
		return user.getAccountId();
	}
	
	
	/* (non-Javadoc)
	 * @see org.apache.shiro.realm.AuthorizingRealm#clearCachedAuthorizationInfo(org.apache.shiro.subject.PrincipalCollection)
	 * 清空用户缓存
	 */
	@Override
	public void clearCachedAuthorizationInfo(PrincipalCollection principals) {
		super.clearCachedAuthorizationInfo(principals);
	}

	/**
	 * 获取当前用户权限字符串
	 * @return
	 */
	public Collection<String>  getStringPermissions(){
		PrincipalCollection principals = SecurityUtils.getSubject().getPrincipals();
    	AuthorizationInfo authorizationInfo = this.getAuthorizationInfo(principals);
    	return authorizationInfo.getStringPermissions();
	}

	public void setAuthorityService(IAuthorityService authorityService) {
		this.authorityService = authorityService;
	}

	
}
