package com.neoway.util.gps;

/**
 * @description :
 * @author : caoxuwei
 * @version : V1.0.0
 * @date : 2018年7月31日
 */
public class Gps {

	//上报纬度
	private double wgLat;
	//上报经度
	private double wgLon;
	//GPS上报车辆速度
	private double speed ;
	//GPS上报时间
	private String time ;
	//方向角
	private int direction;
	
	public Gps(){
		
	}
	public Gps(double wgLat, double wgLon) {
		setWgLat(wgLat);
		setWgLon(wgLon);
	}
	public Gps(double wgLat, double wgLon,int speed) {
		setWgLat(wgLat);
		setWgLon(wgLon);
		setSpeed(speed);
	}
	
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
	public int getDirection() {
		return direction;
	}
	public void setDirection(int direction) {
		this.direction = direction;
	}
	
	
	
	public double getWgLat() {
		return wgLat;
	}

	public void setWgLat(double wgLat) {
		this.wgLat = wgLat;
	}

	public double getWgLon() {
		return wgLon;
	}

	public void setWgLon(double wgLon) {
		this.wgLon = wgLon;
	}

	@Override
	public String toString() {
		return wgLat + "," + wgLon;
	}
}

