/**
 * @company 有方科技
 * @file MapMath.java
 * @author guojy
 * @date 2018年5月15日 
 */
package com.neoway.util.gps;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年5月15日
 */
public class MapMath {
	
	/**
	 * 计算两个经纬度之间的距离
	 * @param lng1
	 * @param lat1
	 * @param lng2
	 * @param lat2
	 * @return
	 */
	public static double distance(double lng1, double lat1, double lng2, double lat2){
		double radLat1 = rad(lat1);
	    double radLat2 = rad(lat2);
	    double a = radLat1 - radLat2;
	    double b = rad(lng1) - rad(lng2);
	    double s = 2.0D * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2.0D), 2.0D) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(b / 2.0D, 2.0D)));
	    s *= 6372797.0D;
	    return s;
	}
	
	public static double rad(double d){
	    return d * 3.141592653589793D / 180.0D;
	}
}
