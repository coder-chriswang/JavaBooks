/**
 * @company 有方物联
 * @file ConstantUtil.java
 * @author guojy
 * @date 2017年9月21日 
 */
package com.neoway.util;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月21日
 */
public class ConstantUtil {
	
	/**
	 * @description :常用业务状态
	 * @author : guojy
	 * @version : V1.0.0
	 * @date : 2017年9月21日
	 */
	public static class Status{
		public static final short SUCCESS = 1;
		public static final short ERROR = -1;
	}
}
