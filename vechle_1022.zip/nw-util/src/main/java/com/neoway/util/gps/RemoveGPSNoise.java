/**
 * @company 有方物联
 * @file RemoveGPSNoise.java
 * @author caoxuwei
 * @date 2018年12月6日 
 */
package com.neoway.util.gps;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 
 * @description :GPS坐标去燥
 * @author : caoxuwei
 * @version : V1.0.0
 * @date : 2018年12月6日
 */
public class RemoveGPSNoise {

	/**
	 * 1经纬度变化对应的长度 单位：米
	 */
	private static final double ONE_DU_LENGTH = 111700;

	/**
	 * 两经纬度之间的最大上报间间隔 单位：分钟
	 */
	private static final double MAX_TIME_SLEEP = 5;

	/**
	 * 判断是否在中国
	 */
	public static boolean outOfChina(double lat, double lon) {
		if (lon < 72.004 || lon > 137.8347)
			return true;
		if (lat < 0.8293 || lat > 55.8271)
			return true;
		return false;
	}

	/**
	 * 求中间点到前后两个点的垂直距离
	 * 
	 * @param one
	 * @param mid
	 * @param last
	 * @return
	 */
	private static double getHeight(Gps one, Gps mid, Gps last) {

		if ((one.getWgLat() == mid.getWgLat() && mid.getWgLat() == last.getWgLat())
				|| (one.getWgLon() == mid.getWgLon() && mid.getWgLon() == last.getWgLon())) {
			// 判断是否能组成一个三角形
			return 0;
		}
		// 判断是否在国内
		/*if (outOfChina(one.getWgLat(), one.getWgLon()) || outOfChina(one.getWgLat(), one.getWgLon())
				|| outOfChina(mid.getWgLat(), mid.getWgLon()) || outOfChina(mid.getWgLat(), mid.getWgLon())) {
			return -1;
		}*/
		// 过滤掉相邻GPS相同 但是中间GPS不相同的漂移点
		if (one.getWgLat() == last.getWgLat() && one.getWgLon() == last.getWgLon()) {
			one.setWgLat(one.getWgLat() + 0.000001);
		}
		double b1 = Distance(one.getWgLon(), one.getWgLat(), mid.getWgLon(), mid.getWgLat());
		double b2 = Distance(one.getWgLon(), one.getWgLat(), last.getWgLon(), last.getWgLat());
		double b3 = Distance(mid.getWgLon(), mid.getWgLat(), last.getWgLon(), last.getWgLat());
		if (((b1 + b2) > b3) || ((b1 + b3) > b2) || ((b2 + b3) > b1)) {
			// 判断是否能组成一个三角形
			double c = (b1 + b2 + b3) / 2;
			// 海伦公式计算三角形面试
			double s = Math.sqrt(c * (c - b1) * (c - b2) * (c - b3));
			if (b2 <= 0) {
				return 0;
			} else {
				return (2 * s) / b2;
			}
		} else {
			return 0;
		}

	}

	/**
	 * 计算两个GPS点之间的距离
	 * 
	 * @param long1
	 * @param lat1
	 * @param long2
	 * @param lat2
	 * @return
	 */
	private static double Distance(double long1, double lat1, double long2, double lat2) {
		double a, b, R;
		R = 6378137; // 地球半径
		lat1 = lat1 * Math.PI / 180.0;
		lat2 = lat2 * Math.PI / 180.0;
		a = lat1 - lat2;
		b = (long1 - long2) * Math.PI / 180.0;
		double d;
		double sa2, sb2;
		sa2 = Math.sin(a / 2.0);
		sb2 = Math.sin(b / 2.0);
		d = 2 * R * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1) * Math.cos(lat2) * sb2 * sb2));
		return d;
	}

	/**
	 * 获取原始GPS数据并去噪 key为data取数据 key为totalMileage取总里程
	 * 
	 * @return
	 */
	public static Map<String, Object> getGps(List<Map<String, Object>> gpsList) {
		Map<String, Object> resultData = new HashMap<>();
		if (gpsList == null || gpsList.isEmpty()) {
			resultData.put("data", gpsList);
			resultData.put("totalMileage", 0);
			return resultData;
		}
		try {
			List<Gps> list = new ArrayList<>();
			//int tempLast = 0;
			//int indexLast = gpsList.size() - 1;
			//boolean findFlag = true;
			for (int k = 0; k < gpsList.size(); k++) {
				Map<String, Object> map = gpsList.get(k);
				/*if (findFlag) {
					Map<String, Object> mapLast = gpsList.get(indexLast);
					if (mapLast != null && outOfChina(
							Double.parseDouble(String.valueOf(mapLast.getOrDefault("latitude", "0")).replace(" ", "")),
							Double.parseDouble(
									String.valueOf(mapLast.getOrDefault("longitude", "0")).replace(" ", "")))) {
						indexLast--;
					} else {
						tempLast = indexLast;
						findFlag = false;
					}
				}*/
				Gps gps = new Gps();
				gps.setDirection(Integer.parseInt(String.valueOf(map.getOrDefault("direation", "0")).replace(" ", "")));
				gps.setSpeed(Double.parseDouble(
						String.valueOf(map.getOrDefault("speed", "0")).replace("km/h", "").replace("Km/h", "")));
				gps.setTime(String.valueOf(map.getOrDefault("gpsTime", "")));
				gps.setWgLat(Double.parseDouble(String.valueOf(map.getOrDefault("latitude", "0")).replace(" ", "")));
				gps.setWgLon(Double.parseDouble(String.valueOf(map.getOrDefault("longitude", "0")).replace(" ", "")));
				if (gps.getWgLat() >= 0 && gps.getWgLon() >= 0) {
					list.add(gps);
					/*if (!outOfChina(gps.getWgLat(), gps.getWgLon())) {
						list.add(gps);
					} else if (list.size() >= 1 && k <= tempLast) {
						list.add(gps);
					}*/
				}

			}
			// 存放连续速度为0的GPS对象
			Map<Integer, Gps> tempMap = new HashMap<>();
			int tempStep = 0;
			for (int i = 0; i < list.size(); i++) {
				Gps one = list.get(i);
				Gps mid = null;
				Gps last = null;
				if ((i + 1) >= list.size()) {
					mid = list.get(i);
				} else {
					mid = list.get(i + 1);
				}
				if ((i + 2) >= list.size()) {
					last = list.get(i);
				} else {
					last = list.get(i + 2);
				}
				if (one.getSpeed() == 0) {
					tempStep++;
					tempMap.put(i, one);
					// 连续点速度为0 则取经纬度平均值
					if (tempStep % 5 == 0 || tempStep > 50) {
						getLatLonAvg(tempMap, list);
					}
				} else {
					tempMap = new HashMap<>();
					tempStep = 0;
				}
				// 根据三个点的GPS坐标计算出中间点到前后两个点的垂直距离
				double d = getHeight(one, mid, last);
				// 根据三个点的速度计算出最大的可能垂直距离（30S）
				double yuzhi = getYuzhi(one, mid, last);
				double timeSleep = getMinuteTime(one.getTime(), mid.getTime());
				if ((d > yuzhi && timeSleep < MAX_TIME_SLEEP) || d == -1) {
					if(mid.getDirection()<=0){
						mid.setDirection((one.getDirection()+last.getDirection())/2);
					}
					if(one.getSpeed()>0 && last.getSpeed()>0){
						mid.setSpeed((one.getSpeed()+last.getSpeed())/2);
					}
					Gps newGps = getNewGps(one,
							getTime(one.getTime(), mid.getTime()) * ((one.getSpeed() + mid.getSpeed()) / 2) * 1000,
							mid.getDirection());
					newGps.setSpeed(mid.getSpeed());
					list.set(i + 1,newGps);
				}
			}
			double mileage = 0;
			for (int i = 0; i < list.size(); i++) {
				Gps g = list.get(i);
				if (i == 0) {
					mileage = 0;
				} else {
					double timeSleep = getMinuteTime(list.get(i - 1).getTime(), list.get(i).getTime());
					if (timeSleep < MAX_TIME_SLEEP) {
						double distance = Distance(list.get(i - 1).getWgLon(), list.get(i - 1).getWgLat(),
								list.get(i).getWgLon(), list.get(i).getWgLat()) / 1000;
						mileage = parseDouble(mileage + distance);
					}

				}
				gpsList.get(i).put("latitude", g.getWgLat());
				gpsList.get(i).put("longitude", g.getWgLon());
			}
			resultData.put("data", gpsList);
			resultData.put("totalMileage", parseDoubleThreePont(mileage));

		} catch (Exception e) {
			e.printStackTrace();
			resultData.put("data", null);
			resultData.put("totalMileage", 0);
		}
		return resultData;
	}

	/**
	 * 速度为0连续点经纬度求平均值
	 * 
	 * @param tempMap
	 * @param list
	 */
	private static void getLatLonAvg(Map<Integer, Gps> tempMap, List<Gps> list) {
		Iterator<Integer> it = tempMap.keySet().iterator();
		double lat = 0;
		double lon = 0;
		while (it.hasNext()) {
			Integer key = it.next();
			Gps g = tempMap.get(key);
			lat = lat + g.getWgLat();
			lon = lon + g.getWgLon();
		}
		lat = parseDouble(lat / tempMap.size());
		lon = parseDouble(lon / tempMap.size());
		Iterator<Integer> its = tempMap.keySet().iterator();
		while (its.hasNext()) {
			Integer key = its.next();
			Gps g = list.get(key);
			g.setWgLat(lat);
			g.setWgLon(lon);
			list.set(key, g);
		}
	}

	/**
	 * 计算可能的最大值
	 * 
	 * @param one
	 * @param last
	 * @return
	 */
	private static double getYuzhi(Gps one, Gps mid, Gps last) {
		double b1 = one.getSpeed() * 1000 * 0.00834;
		double b2 = last.getSpeed() * 1000 * 0.00834;
		double b3 = mid.getSpeed() * 1000 * 0.00834;
		if (b1 == 0 && b2 == 0 && b3 == 0) {
			return 10;
		}
		if (b3 > b2) {
			b2 = b3;
		}
		return b1 > b2 ? b1 : b2;
	}

	/**
	 * 根据该GPS点的上一个GPS点计算下一个GSP点坐标
	 * 
	 * @param pGps
	 * @param distance
	 * @param direction
	 * @return
	 */
	private static Gps getNewGps(Gps pGps, double distance, int direction) {
		Gps newGps = new Gps();
		if (direction == 0 || direction == 360) {
			//经度不变 纬度变（变大）
			newGps.setWgLat(parseDouble(pGps.getWgLat() + (distance / ONE_DU_LENGTH)));
			newGps.setWgLon(pGps.getWgLon());
		}else if(direction==180){
			//经度不变 纬度变（变小）
			newGps.setWgLat(parseDouble(pGps.getWgLat() - (distance / ONE_DU_LENGTH)));
			newGps.setWgLon(pGps.getWgLon());
		} else if (direction == 90) {
			//纬度不变 经度变（变大）
			newGps.setWgLat(pGps.getWgLat());
			newGps.setWgLon(parseDouble(pGps.getWgLon() + (distance / getLongLength(pGps))));
		} else if ((direction > 0 && direction < 90)) {
			//纬度变大 经度变大
			newGps.setWgLat(parseDouble(
					pGps.getWgLat() + Math.abs((Math.cos(Math.PI / (180d / direction))) * distance / ONE_DU_LENGTH)));
			newGps.setWgLon(parseDouble(
					pGps.getWgLon() + Math.abs((Math.sin(Math.PI / (180d / direction))) * distance / getLongLength(pGps))));
		}else if((direction > 270 && direction < 360)){
			//纬度变大 经度变小
			newGps.setWgLat(parseDouble(
					pGps.getWgLat() + Math.abs((Math.cos(Math.PI / (180d / direction))) * distance / ONE_DU_LENGTH)));
			newGps.setWgLon(parseDouble(
					pGps.getWgLon() - Math.abs(Math.sin(Math.PI / (180d / direction))) * distance / getLongLength(pGps)));
		} else if (direction == 270) {
			//纬度不变 经度变（变小）
			newGps.setWgLat(pGps.getWgLat());
			newGps.setWgLon(parseDouble(pGps.getWgLon() - (distance / getLongLength(pGps))));
		} else if ((direction > 90 && direction < 180)) {
			//纬度变小 经度变大
			newGps.setWgLat(parseDouble(pGps.getWgLat()
					- Math.abs(parseDouble((Math.cos(Math.PI / (180d / direction))) * distance / ONE_DU_LENGTH))));
			newGps.setWgLon(parseDouble(pGps.getWgLon()
					+ Math.abs(parseDouble((Math.sin(Math.PI / (180d / direction))) * distance / getLongLength(pGps)))));
		}else if((direction > 180 && direction < 270)){
			//纬度变小 经度变小
			newGps.setWgLat(parseDouble(pGps.getWgLat()
					- Math.abs(parseDouble((Math.cos(Math.PI / (180d / direction))) * distance / ONE_DU_LENGTH))));
			newGps.setWgLon(parseDouble(pGps.getWgLon()
					- Math.abs(parseDouble((Math.sin(Math.PI / (180d / direction))) * distance / getLongLength(pGps)))));
		}
		newGps.setTime(pGps.getTime());
		newGps.setDirection(direction);
		return newGps;
	}
	
	private static double getLongLength(Gps pGps) {
		return Math.abs(Math.cos(Math.PI / (180 / pGps.getWgLat())) * ONE_DU_LENGTH);
	}

	/**
	 * 保留六位小数
	 * 
	 * @param f
	 * @return
	 */
	private static double parseDouble(double f) {
		try {
			DecimalFormat df = new DecimalFormat("#.000000");
			return Double.parseDouble(df.format(f));
		} catch (Exception e) {
		}
		return 0;
	}

	/**
	 * 保留三位小数
	 * 
	 * @param f
	 * @return
	 */
	private static double parseDoubleThreePont(double f) {
		try {
			DecimalFormat df = new DecimalFormat("#.000");
			return Double.parseDouble(df.format(f));
		} catch (Exception e) {
			System.out.println("转换异常:" + f);
		}
		return 0;
	}

	/**
	 * 根据时间转换对应的小时差
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings("unused")
	private static double getTime(String startDate, String endDate) {
		double resultTime = 0;
		try {
			SimpleDateFormat start = null;
			if (startDate != null && startDate.indexOf("-") > 0 && startDate.indexOf(":") > 0) {
				start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			} else {
				start = new SimpleDateFormat("yyyyMMddHHmmss");
			}
			if (start == null) {
				resultTime = 0;
			} else {
				resultTime = parseDouble(
						(start.parse(endDate).getTime() - start.parse(startDate).getTime()) / 3600000d);
			}
		} catch (Exception e) {
			resultTime = 0;
		}
		return resultTime;
	}

	/**
	 * 返回两个时间的分钟差
	 * 
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@SuppressWarnings("unused")
	private static double getMinuteTime(String startDate, String endDate) {
		double resultTime = 0;
		try {
			SimpleDateFormat start = null;
			if (startDate != null && startDate.indexOf("-") > 0 && startDate.indexOf(":") > 0) {
				start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			} else {
				start = new SimpleDateFormat("yyyyMMddHHmmss");
			}
			if (start == null) {
				resultTime = 0;
			} else {
				resultTime = parseDouble((start.parse(endDate).getTime() - start.parse(startDate).getTime()) / 60000d);
			}
		} catch (Exception e) {
			resultTime = 0;
		}
		return resultTime;
	}
}
