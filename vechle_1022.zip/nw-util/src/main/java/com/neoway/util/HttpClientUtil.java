/**
 * @company 有方物联
 * @file HttpClientUtil.java
 * @author bailu
 * @date 2017年11月10日 
 */
package com.neoway.util;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * @description : http请求工具类
 * @author : bailu
 * @version : V1.0.0
 * @date : 2017年11月10日
 */
public class HttpClientUtil {
	
	/**
	 * post请求
	 * @param url 请求url
	 * @param xml 请求参数
	 * @return
	 */
	public static String doPost(String url, String xml) {
		String result = "";
		try {
			CloseableHttpClient httpClient = HttpClients.createDefault();
			HttpPost httppost = new HttpPost(url);

			StringEntity s = new StringEntity(xml);
			s.setContentEncoding("UTF-8");
			s.setContentType("application/json");
			httppost.setEntity(s);

			CloseableHttpResponse response = httpClient.execute(httppost);
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 200) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, "utf-8");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
