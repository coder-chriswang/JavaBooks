/**
 * 有方科技
 */
package com.neoway.util.hex;

import java.io.UnsupportedEncodingException;

import com.neoway.util.ObjectUtils;

/**
 * @author guojy
 * 16进制工具类
 * ASCII 码 8位二进制表示字母数字符号等
 * 0xF0      0x0F
 * 11110000  00001111
 */
public class HexStringUtils {

	/**
	 * 16进制字符列表
	 */
	private static final char[] DIGITS_HEX = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

	/**
	 * @param data
	 * (0xF0 & data[i]) >>> 4  取高4位转为16进制对应的数
	 * 0x0F & data[i] 取低4位转16进制对应的数
	 * 解释：一个byte分8位分高低4位    4bit最大的二进制是1111即十进制的15 最小的二进制是0000即十进制0，所以能表示16进制的数
	 * @return
	 */
	protected static char[] encodeHex(byte[] data) {
		int l = data.length;
		char[] out = new char[l << 1];
		for (int i = 0, j = 0; i < l; i++) {
			out[j++] = DIGITS_HEX[(0xF0 & data[i]) >>> 4];
			out[j++] = DIGITS_HEX[0x0F & data[i]];
		}
		return out;
	}

	public static byte[] decodeHex(char[] data) {
		int len = data.length;
		if ((len & 0x01) != 0) {
			throw new RuntimeException("字符个数应该为偶数");
		}
		byte[] out = new byte[len >> 1];
		for (int i = 0, j = 0; j < len; i++) {
			int f = toDigit(data[j], j) << 4;
			j++;
			f |= toDigit(data[j], j);
			j++;
			out[i] = (byte) (f & 0xFF);
		}
		return out;
	}

	protected static int toDigit(char ch, int index) {
		int digit = Character.digit(ch, 16);
		if (digit == -1) {
			throw new RuntimeException("Illegal hexadecimal character " + ch + " at index " + index);
		}
		return digit;
	}

	public static String toHexString(byte[] bs) {
		return new String(encodeHex(bs));
	}

	public static String hexString2Bytes(String hex) {
		return new String(decodeHex(hex.toCharArray()));
	}

	public static byte[] chars2Bytes(char[] bs) {
		return decodeHex(bs);
	}
	
	/**  
	 * Convert hex string to byte[]  
	 * @param hexString the hex string  
	 * @return byte[]  
	 */  
	public static byte[] toBytes(String hexString) {   
	    if (hexString == null || hexString.equals("")) {   
	        return null;   
	    }   
	    hexString = hexString.toUpperCase();   
	    int length = hexString.length() / 2;   
	    char[] hexChars = hexString.toCharArray();   
	    byte[] d = new byte[length];   
	    for (int i = 0; i < length; i++) {   
	        int pos = i * 2;   
	        d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));   
	    }   
	    return d;   
	} 
	
	/**
	 * 16进制字符串转10进制
	 * @param hexStr
	 * @return
	 */
	public static int hexString2Decimal(String hexStr){
		String s = "0x"+hexStr.replace(" ", "");
		return Integer.parseInt(s.replaceAll("^0[x|X]", ""), 16);
	}
	
	/**
	 * 16进制字符串转2进制字符串
	 * @param hexString
	 * @return String
	 */
	public static String hexString2binaryString(String hexString) {
		if (hexString == null || hexString.length() % 2 != 0)
			return null;
		String bString = "", tmp;
		for (int i = 0; i < hexString.length(); i++) {
			tmp = "0000"
					+ Integer.toBinaryString(Integer.parseInt(
							hexString.substring(i, i + 1), 16));
			bString += tmp.substring(tmp.length() - 4);
		}
		return bString;
	}

	/**
	 * 2进制字符串转16进制字符串
	 * @param hexString
	 * @return String
	 */
	public static String binaryString2hexString(String bString) {
		if (bString == null || bString.equals("") || bString.length() % 8 != 0)
			return null;
		StringBuffer tmp = new StringBuffer();
		int iTmp = 0;
		for (int i = 0; i < bString.length(); i += 4) {
			iTmp = 0;
			for (int j = 0; j < 4; j++) {
				iTmp += Integer.parseInt(bString.substring(i + j, i + j + 1)) << (4 - j - 1);
			}
			tmp.append(Integer.toHexString(iTmp));
		}
		return tmp.toString();
	}
	
	/**
	 * 整形转16进制
	 * @param data
	 * @param byteNum
	 * @return
	 */
	public static String toHexString(long data, int byteNum) {

		StringBuilder sb = new StringBuilder("");
		for (int m = 0; m < byteNum; m++) {
			sb.append("00");
		}
		int totalLen = byteNum * 2;
		String tmp = Long.toHexString(data);
		sb.replace(totalLen - tmp.length(), totalLen, tmp);
		return sb.toString();
	}
	
	/**  
	 * Convert char to byte  
	 * @param c char  
	 * @return byte  
	 */  
	 private static byte charToByte(char c) {   
	    return (byte) "0123456789ABCDEF".indexOf(c);   
	}  
	 
	 
		/**
		 * 字符串转ASCII
		 * @param str
		 * @param length 0 忽略
		 * @return
		 */
		 public static String parseAscii(String str,int length){
			if (ObjectUtils.isNullOrEmptyString(str)) {
				return "";
			}
		 	StringBuilder sb=new StringBuilder();
		        
		 	byte[] bs=str.getBytes();
		 	sb.append(HexStringUtils.toHexString(bs));
			if(length > 0 && str.length() < length){
			 	for(int i=0;i<length-str.length();i++){
			    	sb.append("00");
				}
		    }
		    return sb.toString();
		 }
		 
		 /**
		  * ASCII转字符串
		  * @param value
		  * @return
		  */
		 public static String asciiToString(String value)  
		 {  
			 if (ObjectUtils.isNullOrEmptyString(value)) {
				return "";
			 }
		     StringBuffer sbu = new StringBuffer();  
		     String[] chars = value.split(",");  
		     for (int i = 0; i < chars.length; i++) {  
		         sbu.append((char) Integer.parseInt(chars[i]));  
		     }  
		     return sbu.toString();  
		 }  
		 
		 /**
		  * 高低位翻转（大小端模式转换）
		  * @param hexParam 需要转换的16进制字符串
		  * @return
		  */
		public static String reversePosition(String hexParam) {
			if(ObjectUtils.isNullOrEmptyString(hexParam) || hexParam.length()%2 != 0){
				return "";
			}

			//01000618  18060001
			int forCount = hexParam.length()/2; //for循环次数
			StringBuffer sb = new StringBuffer();
			for (int i = forCount; i > 0; i--) {
				String str = hexParam.substring((i-1)*2, i*2);
				sb.append(str);
			}
			
			return sb.toString();
		}
		
		/**
		 * ip地址转16进制
		 * @param ip
		 * @return
		 */
		public static String ipToHexString(String ip) {
			if(ObjectUtils.isNullOrEmptyString(ip) || ip.split("\\.").length != 4){
				return "";
			}
			
			String[] ipArr = ip.split("\\.");
			StringBuffer sBuffer = new StringBuffer();
			for (String string : ipArr) {
				sBuffer.append(toHexString(Long.parseLong(string), 1));
			}
			return sBuffer.toString();
		}
		
		/**
		 * 日期时间转16进制
		 * @param date  171125
		 * @return
		 */
		public static String dateToHexString(String date) {
			if(ObjectUtils.isNullOrEmptyString(date) || date.length() != 6){
				return "";
			}
			
			StringBuffer sBuffer = new StringBuffer();
			
			for(int i = 0; i < date.length()/2; i++){
				sBuffer.append(toHexString(Long.parseLong(date.substring(i*2, (i+1)*2)), 1));
			}
			return sBuffer.toString();
		}

	
	public static void main(String[] args) {
		try {
			System.out.println(toHexString("313830333136303031".getBytes("GBK")));
			//new String(msgBodyBytes,Constant.string_charset)
			System.out.println(new String("313830333136303031".getBytes(),"GBK"));
			byte[] resp = new byte[]{126, -127, 0, 0, 17, 2, 1, -128, 49, 96, 1, 0, 0, 8, -60, 0, 51, 50, 50, 52, 51, 57, 48, 49, 48, 51, 55, 48, 53, 57, -117, 126};
			System.out.println(toHexString(resp));
			System.out.println(new String(new byte[]{51, 50, 50, 52, 51, 57, 48, 49, 48, 51, 55, 48, 53, 57}));
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}