package com.neoway.util;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neoway.util.hex.HexStringUtils;

/**
 * 字符串工具类
 * @author bailu
 * 
 */
public class StringUtil {

	protected static Random random = new Random();

	/**
     * 获取32位UUID
     * @return
     */
    public static String getUUID() {
    	return UUID.randomUUID().toString().replace("-", "");
    }
    
    /**
	 * 获取随机数
	 * @return int
	 */
	public static int getRandom() {
    	return random.nextInt(999999)%900000+100000;
    }
    
    /**
	 * SHA256加密
	 * @param str
	 * @return String
	 */
	public static String strToSHA256(String str) {
		String result = "";
		try {
			 MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
		
	        byte[] inputByteArray = str.getBytes();
	        messageDigest.update(inputByteArray);
	        byte[] resultByteArray = messageDigest.digest();
	        result = HexStringUtils.toHexString(resultByteArray);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return result.toUpperCase();
    }
	
	/**
	 * 替换指定位置字符串
	 * @param index 要替换的位置
	 * @param res 原字符串
	 * @param str 替换字符
	 * @return
	 */
	public static String replaceIndex(int index,String res,String str){
		return res.substring(0, index)+str+res.substring(index+1);
	}
	
	/**
	 * 字符串转对象 List或者Map
	 * @param str
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public static Object stringToJson(String str) throws JsonParseException, JsonMappingException, IOException{
		ObjectMapper objectMapper = new ObjectMapper();
		if(isJsonObject(str)){
			Map<String,Object> mapResult = new HashMap<String,Object>();
			Map<String,String> map = objectMapper.readValue (str,new TypeReference<Map<String,String>>() {});
			Iterator<Entry<String, String>> iterator = map.entrySet().iterator();
			while(iterator.hasNext()){
				Entry<String, String> entry = iterator.next();
				Object val = stringToJson(entry.getValue());
				mapResult.put(entry.getKey(), val);
			}
			return map;
		}else if(isJsonArray(str)){
			List<Object> list = new ArrayList<Object>();
			List<Map<String,String>> listTmp = objectMapper.readValue (str,new TypeReference<List<Map<String,String>>>() {});
			for(Map<String,String> tmpMap:listTmp){
				Object val = jsonToBean(tmpMap);
				list.add(val);
			}
			return list;
		}else{
			return str;
		}
	}
	
	private static Object jsonToBean(Map<String,String> jsonMap) throws JsonParseException, JsonMappingException, IOException{
		Map<String,Object> mapResult = new HashMap<String,Object>();
		Iterator<Entry<String, String>> iterator = jsonMap.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<String, String> entry = iterator.next();
			Object val = stringToJson(entry.getValue());
			mapResult.put(entry.getKey(), val);
		}
		return mapResult;
	}
	
	private static boolean isJsonObject(String json){
		if(json==null || json.trim().equals(""))
			return false;
		char begin = json.trim().charAt(0);
		if(begin == '{'){
			return true;
		}else{
			return false;
		}
	}
	
	private static boolean isJsonArray(String json){
		if(json==null || json.trim().equals(""))
			return false;
		char begin = json.trim().charAt(0);
		if(begin == '['){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 字符串转long型
	 * @param value
	 * @return
	 */
	public static long parseLong(String value){
		long result = 0;
		if(ObjectUtils.isNullOrEmptyString(value)){
			return result;
		}
		try {
			result = Long.parseLong(value);
		} catch (NumberFormatException e) {
			return result;
		}
		return result;
	}
	
	public static void main(String[] args) {
		System.out.println(StringUtil.getUUID());
		String string = HexStringUtils.hexString2binaryString("00000000");
		System.out.println(replaceIndex(8, string, "1"));
		
		String hexString = HexStringUtils.hexString2binaryString("00000000");
		String clkBinaryStr = StringUtil.replaceIndex(Integer.parseInt("0"), hexString, "1");
		String clkFlagHex = HexStringUtils.binaryString2hexString(clkBinaryStr);
		
		System.out.println(clkFlagHex);
		System.out.println(HexStringUtils.hexString2binaryString(clkFlagHex));
	}
}
