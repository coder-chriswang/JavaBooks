/**
 * @company 有方物联
 * @file IExportService.java
 * @author guojy
 * @date 2018年3月23日 
 */
package com.neoway.exports.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.neoway.exports.bean.ExportBean;

/**
 * @description :导出数据服务接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月23日
 */
public interface IExportService {
	/**
	 * 通过数据源导出数据
	 * @param source
	 * @param exportBean
	 * @param response
	 */
	public void exportData(List<?> source,ExportBean exportBean,HttpServletResponse response);
	/**
	 * 通过sql导出数据
	 * @param sql
	 * @param exportBean
	 * @param response
	 */
	public void exportData(String sql,ExportBean exportBean,HttpServletResponse response);
}
