/**
 * @company 有方物联
 * @file ExportServiceImpl.java
 * @author guojy
 * @date 2018年3月23日 
 */
package com.neoway.exports.service.impl;

import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import com.alibaba.fastjson.annotation.JSONField;
import com.neoway.exports.bean.ExportBean;
import com.neoway.exports.dao.IExportDao;
import com.neoway.exports.service.IExportService;
import com.neoway.util.DateUtil;

/**
 * @description :导出数据接口默认实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月23日
 */
@Service
public class ExportServiceImpl implements IExportService {
	private static Logger logger = LoggerFactory.getLogger(ExportServiceImpl.class);
	
	@Autowired
	private IExportDao exportDao;
	/* (non-Javadoc)
	 * @see com.etiot.exports.service.IExportService#exportData(java.util.List, com.etiot.exports.bean.ExportBean, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void exportData(List<?> source, ExportBean exportBean, HttpServletResponse response) {
		logger.debug("导出Excel数据");
		// 第一步，创建一个webbook，对应一个Excel文件
		HSSFWorkbook workbook = new HSSFWorkbook();
		int sheetCount = 1;
		if (source != null) {
			sheetCount = (source.size() / 5000)+source.size() % 5000==0?0:1;
		}
		for (int s = 0; s < sheetCount; s++) {
			// 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
			HSSFSheet sheet = workbook.createSheet(exportBean.getFileName() + "-" + s + 1);
			// 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
			HSSFRow row = sheet.createRow((int) 0);
			// 第四步，创建单元格，并设置值表头 设置表头居中
			HSSFCellStyle style = workbook.createCellStyle();
			// 第五步 设置表头
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			if (exportBean.getHead() != null && exportBean.getHead().length > 0) {
				int index = 0;
				for (String head : exportBean.getHead()) {
					HSSFCell cell = row.createCell(index);
					cell.setCellValue(head);
					cell.setCellStyle(style);
					index++;
				}
			}
			// 第六步 填充数据
			if (source != null) {
				int start = s * 5000;
				int end = ((source.size() - ((s + 1) * 5000))) <= 0 ? source.size() : (s + 1) * 5000;
				for (int index = start; index < end; index++) {
					Object obj = source.get(index);
					row = sheet.createRow(index + 1);
					int idx = 0;
					for (String field : exportBean.getField()) {
						Object fieldVal = invokeVal(field, obj);
						String cellVal = fieldVal == null ? null : String.valueOf(fieldVal);
						row.createCell(idx).setCellValue(cellVal);
						idx++;
					}
				}
			}
		}

		// 第七部 导出
		try {
			logger.info("开始导出数据");
			String fileName=java.net.URLEncoder.encode(exportBean.getFileName(), "UTF8");
			OutputStream output = response.getOutputStream();
			response.reset();
			response.setContentType("application/octet-stream;charset=utf-8");
			/*response.setHeader("Content-disposition",
					"attachment; filename=" + fileName + ".xls");*/
			response.setHeader("Content-Disposition", "attachment;filename*=utf-8'zh_cn'" + fileName  + ".xls");
			response.setContentType("application/msexcel");
			workbook.write(output);
			output.close();
		} catch (Exception e) {
			logger.error("发生数据导出异常"+e.getMessage());
		}
	}
	
	/**
	 * 查找对象中对应field的值
	 * @param field
	 * @param obj
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Object invokeVal(String field,Object obj){
		if(obj instanceof Map){
			Map<String,Object> mapData = (Map<String, Object>) obj;
			Object fieldVal =  mapData.get(field);
			if(fieldVal != null && fieldVal instanceof Date){
				return DateUtil.formatDate((Date)fieldVal, DateUtil.TIME_HAVINTERVAL);
			}else{
				return fieldVal;
			}
		}else{
			Method method = ReflectionUtils.findMethod(obj.getClass(), "get"+field.substring(0, 1).toUpperCase()+field.substring(1));
			Object fieldVal =  ReflectionUtils.invokeMethod(method, obj);
			Field proField = ReflectionUtils.findField(obj.getClass(), field);
			if(fieldVal != null && proField.getType().isAssignableFrom(Date.class)){
				JSONField annotation = proField.getAnnotation(JSONField.class);
				String dateFormat = annotation.format();
				return DateUtil.formatDate((Date)fieldVal, dateFormat);
			}else{
				return fieldVal;
			}
		}
	}
	/* (non-Javadoc)
	 * @see com.etiot.exports.service.IExportService#exportData(java.lang.String, com.etiot.exports.bean.ExportBean, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void exportData(String sql, ExportBean exportBean, HttpServletResponse response) {
		List<Map<String, Object>> sourceData = exportDao.find(sql);
		this.exportData(sourceData, exportBean, response);
	}

}
