/**
 * @company 有方物联
 * @file IExportDao.java
 * @author guojy
 * @date 2018年3月23日 
 */
package com.neoway.exports.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

/**
 * @description :sql导出
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月23日
 */
public interface IExportDao {
	/**
	 * 通过sql查询
	 * @param sql
	 * @return
	 */
	List<Map<String, Object>> find(@Param("exportSql") String exportSql);
}
