/**
 * @company 有方物联
 * @file ImportEntity.java
 * @author caoxuwei
 * @date 2017年10月6日 
 */
package com.neoway.imports.entity;

import java.util.List;
import java.util.Map;

/**
 * 
 * @description :数据导入实体类
 * @author : caoxuwei
 * @version : V1.0.0
 * @date : 2017年10月6日
 */
public class ImportEntity {
	/**
	 * 导入表名字
	 */
	private String tableName;
	/**
	 * 对应列
	 */
	private String[] filedsArray;
	/**
	 * 对应数据
	 */
	private List<String[]> valusList;

	/**
	 * 导入方式 默认xls
	 */
	private String importType;

	/**
	 * 目标源类型 默认RDB
	 */
	private String sourceType;

	/**
	 * 根据对应的汉子获取对应的编码
	 */
	private Map<String, FiledCondition> conditionMap;

	/**
	 * 字段唯一性验证
	 */
	private Map<String, String> uniquenessMap;

	/**
	 * 是否验证表头和列相同 默认验证
	 */
	private Boolean isValidateRank;

	public Boolean getIsValidateRank() {
		return isValidateRank;
	}

	public void setIsValidateRank(Boolean isValidateRank) {
		this.isValidateRank = isValidateRank;
	}

	public Map<String, String> getUniquenessMap() {
		return uniquenessMap;
	}

	public void setUniquenessMap(Map<String, String> uniquenessMap) {
		this.uniquenessMap = uniquenessMap;
	}

	public Map<String, FiledCondition> getConditionMap() {
		return conditionMap;
	}

	public void setConditionMap(Map<String, FiledCondition> conditionMap) {
		this.conditionMap = conditionMap;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getImportType() {
		return importType;
	}

	public void setImportType(String importType) {
		this.importType = importType;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String[] getFiledsArray() {
		return filedsArray;
	}

	public void setFiledsArray(String[] filedsArray) {
		this.filedsArray = filedsArray;
	}

	public List<String[]> getValusList() {
		return valusList;
	}

	public void setValusList(List<String[]> valusList) {
		this.valusList = valusList;
	}

}
