/**
 * @company 有方物联
 * @file IImportDao.java
 * @author caoxuwei
 * @date 2017年10月6日 
 */
package com.neoway.imports.dao;

import java.util.List;
import java.util.Map;

import com.neoway.imports.entity.FiledCondition;
import com.neoway.imports.entity.ImportEntity;

/**
 * 
 * @description :数据导入dao层接口
 * @author : caoxuwei
 * @version : V1.0.0
 * @date : 2017年10月6日
 */
public interface IImportDao {
	int insert(ImportEntity entity);
	
	List<Map<String, Object>> find(FiledCondition entity);
}
