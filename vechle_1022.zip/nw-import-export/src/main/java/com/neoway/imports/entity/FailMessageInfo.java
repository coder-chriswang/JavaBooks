/**
 * @company 有方物联
 * @file FailMessageInfo.java
 * @author caoxuwei
 * @date 2018年6月13日 
 */
package com.neoway.imports.entity;

/**
 * @description :数据导入失败记录其失败信息
 * @author : caoxuwei
 * @version : V1.0.0
 * @date : 2018年6月13日
 */
public class FailMessageInfo {

	// 失败的行号
	public int rowNum;
	// 失败的列号
	public int columNum;
	// 失败原因
	public String message;
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public int getColumNum() {
		return columNum;
	}
	public void setColumNum(int columNum) {
		this.columNum = columNum;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
