/**
 * @company 有方物联
 * @file ExcelImportServiceImpl.java
 * @author caoxuwei
 * @date 2017年10月6日 
 */
package com.neoway.imports.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.neoway.core.ICommonManager;
import com.neoway.core.extend.redis.RedisManager;
import com.neoway.imports.dao.IImportDao;
import com.neoway.imports.entity.FailMessageInfo;
import com.neoway.imports.entity.FiledCondition;
import com.neoway.imports.entity.ImportEntity;
import com.neoway.imports.service.IImportService;
import com.neoway.util.StringUtil;

/**
 * 
 * @description :excel数据导入 service实现层
 * @author : caoxuwei
 * @version : V1.0.0
 * @date : 2017年10月6日
 */
@Service
public class ExcelImportServiceImpl implements IImportService {

	private final Logger logger = Logger.getLogger(getClass());
	@Autowired
	private IImportDao importDao;
	@Autowired
	private RedisManager redisManager;
	// 导入失败的条数
	private int failCount = 0;
	// 存储验证失败信息
	List<FailMessageInfo> messageInfoList = null;
	//缓存唯一性验证数据的二维数组
    private String[][] catchUniqueness = null ;
	/**
	 * Excel数据导入 入口
	 */
	@Override
	public Map<String, Object> importData(InputStreamSource object, ImportEntity entity, ICommonManager userManager)
			throws IOException {
		messageInfoList = new ArrayList<>();
		MultipartFile file = (MultipartFile) object;
		failCount = 0;
		Map<String, Object> resultMap = new HashMap<>();
		if (checkFile(file)) {
			int result = 0;
			List<String[]> valueList = readExcel(file, entity,userManager);
			if (entity.getIsValidateRank()) {
				// 去掉必填项没填的数据
				if (valueList != null && valueList.size() > 0) {
					for (int i = 0; i < valueList.size(); i++) {
						if (valueList.get(i) == null || valueList.get(i).length != entity.getFiledsArray().length) {
							valueList.remove(i);
						}
					}
				}
			}
			resultMap.put("should", failCount);
			// 数据随机验证
			if (randomValidateData(valueList, entity)) {
				// 导入关系型数据库
				if ("rdb".equals(entity.getSourceType())) {
					result = insertRdb(valueList, entity);
				}
			}
			resultMap.put("success", result);
			resultMap.put("fail", failCount - result);
			resultMap.put("failReason", messageInfoList);
			if (result > 0) {
				logger.debug("excel数据导入成功");
				return resultMap;
			}
		}
		logger.debug("excel数据导入失败");
		return resultMap;
	}

	/**
	 * 数据导入到关系数据库中
	 * 
	 * @param valueList
	 * @param entity
	 * @return
	 */
	public int insertRdb(List<String[]> valueList, ImportEntity entity) {
		logger.debug("数据导入关系数据库开始");
		int result = 0;
		if (entity.getTableName() != null && !"".equals(entity.getTableName())) {
			List<String[]> tempList = null;
			// 分页导入 每次导入1000条记录
			for (int i = 0; i < valueList.size(); i = i + 1000) {
				if (valueList.size() > (i + 1000)) {
					tempList = valueList.subList(i, i + 1000);
				} else {
					tempList = valueList.subList(i, valueList.size());
				}
				entity.setValusList(tempList);
				result += importDao.insert(entity);
			}
		}
		logger.debug("数据导入关系数据库结束");
		return result;
	}

	/**
	 * 随机验证导入的数据
	 * 
	 * @return
	 */
	public boolean randomValidateData(List<String[]> dataList, ImportEntity entity) {
		logger.debug("导入数据随机验证 开始");
		boolean flag = true;
		if (entity.getFiledsArray() != null && entity.getFiledsArray().length > 0) {
			int columnCount = entity.getFiledsArray().length;
			int randomCount = dataList.size() > 100 ? dataList.size() / 2 : dataList.size();
			int max = dataList.size();
			int min = 0;
			if (randomCount > 500) {
				randomCount = 500;
			}
			for (int i = 0; i < randomCount; i++) {
				Random random = new Random();
				int tempIndex = random.nextInt(max) % (max - min + 1) + min;
				String[] tempData = dataList.get(tempIndex);
				if (tempData.length != columnCount) {
					flag = false;
					break;
				}
			}
		} else {
			flag = false;
		}
		logger.debug("导入数据随机验证 结束");
		return flag;
	}

	/**
	 * 读取excel数据
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public List<String[]> readExcel(MultipartFile file, ImportEntity entity,ICommonManager userManager) throws IOException {
		logger.debug("读取excel文件开始");
		// 检查文件
		// 获得Workbook工作薄对象
		Workbook workbook = getWorkBook(file);
		// 创建返回对象，把每行中的值作为一个数组，所有行作为一个集合返回
		List<String[]> list = new ArrayList<String[]>();
		if (workbook != null) {
			for (int sheetNum = 0; sheetNum < workbook.getNumberOfSheets(); sheetNum++) {
				// 获得当前sheet工作表
				Sheet sheet = workbook.getSheetAt(sheetNum);
				if (sheet == null) {
					continue;
				}
				// 获得当前sheet的开始行
				int firstRowNum = sheet.getFirstRowNum();
				// 获得当前sheet的结束行
				int lastRowNum = sheet.getLastRowNum();
				catchUniqueness = new String[lastRowNum+1][entity.getFiledsArray().length-1];
				// 循环除了第一行的所有行
				for (int rowNum = firstRowNum + 1; rowNum <= lastRowNum; rowNum++) {
					// 获得当前行
					Row row = sheet.getRow(rowNum);
					if (row == null) {
						continue;
					}
					// 获得当前行的开始列
					int firstCellNum = row.getFirstCellNum();
					if (firstCellNum == 0) {
						failCount = failCount + 1;
					}
					String[] cells = new String[entity.getFiledsArray().length];
					boolean flag = false;
					// 循环当前行
					for (int cellNum = firstCellNum; cellNum < entity.getFiledsArray().length - 1; cellNum++) {
						Cell cell = row.getCell(cellNum);
						if (cell == null) {
							cell = row.createCell(cellNum);
							cell.setCellValue("");
						}
						Cell pCell = null;
						if ((cellNum - 1) >= firstCellNum) {
							pCell = row.getCell(cellNum - 1);
						}
						String resultV = getCellValue(cell, pCell, entity, cellNum,userManager);
						if (resultV == null) {
							flag = true;
							break;
						}
						// 如果返回的值是此值 默认值为null
						if ("-10".equals(resultV)) {
							cells[cellNum] = null;
						} else {
							cells[cellNum] = resultV == null ? resultV : resultV.trim();
						}
					}
					cells[entity.getFiledsArray().length - 1] = StringUtil.getUUID();
					if (flag) {
						continue;
					}
					list.add(cells);
				}
			}
		}
		logger.debug("读取excel文件结束");
		return list;
	}

	/**
	 * 获取单元格数据
	 * 
	 * @param cell
	 * @return
	 */
	public String getCellValue(Cell cell, Cell pCell, ImportEntity entity, int cellNum,ICommonManager userManager) {
		FiledCondition condition = entity.getConditionMap().get(entity.getFiledsArray()[cellNum]);
		String cellValue = "";
		if (cell == null) {
			return cellValue;
		}
		if (condition.getType() != null && "int".equals(condition.getType())) {
			//cell.setCellType(0);
		} else if (condition.getType() != null && "date".equals(condition.getType())) {
			cell.setCellType(0);
		} else {
			cell.setCellType(1);
		}
		// 判断数据的类型
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_NUMERIC: // 数字
			// cellValue = String.valueOf(cell.getNumericCellValue());
			if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell)) {
				Date theDate = cell.getDateCellValue();
				SimpleDateFormat dff = new SimpleDateFormat("yyyy-MM-dd");
				cellValue = dff.format(theDate);
			} else {
				DecimalFormat df = new DecimalFormat("0");
				cellValue = df.format(cell.getNumericCellValue());
			}
			break;
		case Cell.CELL_TYPE_STRING: // 字符串
			cellValue = String.valueOf(cell.getStringCellValue());
			break;
		case Cell.CELL_TYPE_BOOLEAN: // Boolean
			cellValue = String.valueOf(cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_FORMULA: // 公式
			cellValue = String.valueOf(cell.getCellFormula());
			break;
		case Cell.CELL_TYPE_BLANK: // 空值
			cellValue = "";
			break;
		case Cell.CELL_TYPE_ERROR: // 故障
			cellValue = "非法字符";
			break;
		default:
			cellValue = "未知类型";
			break;
		}
		if (cellValue != null) {
			cellValue = cellValue.trim();
		}
		FailMessageInfo messageInfo = new FailMessageInfo();
		if (condition.getRequired() != null && "true".equals(condition.getRequired())
				&& (cellValue == null || "".equals(cellValue))) {
			messageInfo.setColumNum(cell.getColumnIndex() + 1);
			messageInfo.setRowNum(cell.getRowIndex());
			messageInfo.setMessage("必填项");
			messageInfoList.add(messageInfo);
			return null;
		}
		//验证对应数据的长度
		if(condition.getMaxLength() != null && condition.getMaxLength()>0 ){
			if(cellValue.length()>condition.getMaxLength()){
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("长度过长");
				messageInfoList.add(messageInfo);
				return null;
			}
		}
		//是否读xml文件中配置的常量
		if(condition.getConstantSource() !=null && "true".equals(condition.getConstantSource()) && condition.getConstantValue() !=null){
			String[] tempV = condition.getConstantValue().split(",");
			for(String v:tempV){
				String[] tempA = v.split(":") ;
				if(cellValue.equals(tempA[0])){
					return tempA[1] ;
				}
			}
		}
		
		// 判断数据是否来自redis 并且取对应的code
		if (condition.getReadRedis() != null && condition.getRedisKey() != null
				&& "true".equals(condition.getReadRedis())) {
			Map<String, String> map = redisManager.getMapByKey(condition.getRedisKey());
			if (map == null ||  map.size()<=0) {
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("关联表对应的数据不存在");
				messageInfoList.add(messageInfo);
				return null;
			}
			Iterator<String> it = map.keySet().iterator();
			String retKey = null ;
			while (it.hasNext()) {
				String key = it.next();
				if (map.get(key).equals(cellValue)) {
					retKey = key;
					return retKey;
				}
			}
			if(retKey==null){
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("关联表对应的数据不存在");
				messageInfoList.add(messageInfo);
				return null;
			
			}
		}
		// 判断数据类型
		if ("date".equals(condition.getType())) {
			if (cellValue == null || "".equals(cellValue)) {
				return "0";
			}
			// 时间类型
			if (!isValidDate(cellValue)) {
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("时间格式不正确");
				messageInfoList.add(messageInfo);
				return null;
			}
		}
		if ("float".equals(condition.getType())) {
			if (cellValue == null || "".equals(cellValue)) {
				return "0";
			}
			// float类型
			try {
				Float.parseFloat(cellValue);
			} catch (Exception e) {
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("数字格式不正确(应为浮点型)");
				messageInfoList.add(messageInfo);
				return null;
			}
		}
		if ("int".equals(condition.getType())) {
			if (cellValue == null || "".equals(cellValue)) {
				return "0";
			}
			// int类型
			try {
				Integer.parseInt(cellValue);
			} catch (Exception e) {
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("数字格式不正确(应为整形)");
				messageInfoList.add(messageInfo);
				return null;
			}
		}
		if ("email".equals(condition.getType())) {
			// 邮箱验证
			if (cellValue == null || "".equals(cellValue)) {
				return "-10";
			}
			if (!emailFormat(cellValue)) {
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("邮箱格式不正确");
				messageInfoList.add(messageInfo);
				return null;
			}
		}
		if ("phone".equals(condition.getType())) {
			// 手机号验证
			if (cellValue == null || "".equals(cellValue)) {
				return "-10";
			}
			if (!isMobileNO(cellValue)) {
				messageInfo.setColumNum(cell.getColumnIndex() + 1);
				messageInfo.setRowNum(cell.getRowIndex());
				messageInfo.setMessage("手机格式不正确");
				messageInfoList.add(messageInfo);
				return null;
			}
		}

		
		// 验证字段唯一性
		if (entity.getUniquenessMap() != null && entity.getUniquenessMap().size() > 0
				&& entity.getUniquenessMap().get(String.valueOf(entity.getFiledsArray()[cellNum])) != null) {
			if (cellValue == null || "".equals(cellValue)) {
				return null;
			}
			String filed = entity.getFiledsArray()[cellNum];
			String uniqueness = entity.getUniquenessMap().get(filed);
			if (uniqueness != null && !"".equals(uniqueness)) {
				// 需要验证唯一性
				StringBuffer sb = new StringBuffer();
				sb.append("select ");
				sb.append(filed);
				sb.append(" from ");
				sb.append(entity.getTableName());
				sb.append(" where  ");
				sb.append(filed + " = '" + cellValue + "'");
				FiledCondition uniqu = new FiledCondition();
				uniqu.setFindSql(sb.toString());
				List<Map<String, Object>> resultList = importDao.find(uniqu);
				if (resultList != null && resultList.size() > 0) {
					// 验证不通过
					messageInfo.setColumNum(cell.getColumnIndex() + 1);
					messageInfo.setRowNum(cell.getRowIndex());
					messageInfo.setMessage("该数据已存在");
					messageInfoList.add(messageInfo);
					return null;
				} else {
					//缓存唯一性验证
					if(cell.getRowIndex()==1){
						catchUniqueness[cell.getRowIndex()][cell.getColumnIndex()]=cellValue;
					}else{
						boolean validateFlag = true ;
						for(int k=0;k<cell.getRowIndex();k++){
							if(cellValue.equals(catchUniqueness[k][cell.getColumnIndex()])){
								validateFlag = false ;
								break ;
							}
						}
						if(validateFlag){
							catchUniqueness[cell.getRowIndex()][cell.getColumnIndex()]=cellValue;
						}else{
							messageInfo.setColumNum(cell.getColumnIndex() + 1);
							messageInfo.setRowNum(cell.getRowIndex());
							messageInfo.setMessage("该数据已存在");
							messageInfoList.add(messageInfo);
							return null;
						}
					}
					return String.valueOf(cell.getStringCellValue());
				}
			}
		}
		// 验证字段关联关系是否存在 比如陕西省 在省表中是否存在
		if (entity.getConditionMap() != null && entity.getConditionMap().size() > 0
				&& entity.getConditionMap().get(String.valueOf(entity.getFiledsArray()[cellNum])) != null) {
			if (condition != null) {
				// 判断是否有次字段和上个字段有级联关系
				StringBuffer sb = null;
				if (condition.getResultname() != null && condition.getTablename() != null
						&& condition.getConditionname() != null && !"".equals(condition.getResultname())
						&& !"".equals(condition.getTablename()) && !"".equals(condition.getConditionname())
						&& condition.getRelevanceTable() != null && condition.getRelevanceField() != null
						&& condition.getRelevanceFieldName() != null && !"".equals(condition.getRelevanceTable())
						&& !"".equals(condition.getRelevanceField()) && !"".equals(condition.getRelevanceFieldName())) {
					if (cellValue == null || "".equals(cellValue) || pCell == null) {
						return null;
					}
					sb = new StringBuffer();
					sb.append("select c.");
					sb.append(condition.getResultname());
					sb.append(" from ");
					sb.append(condition.getTablename() + " c");
					sb.append(" LEFT JOIN ");
					sb.append(condition.getRelevanceTable() + " p");
					if (condition.getIsPrecise() != null && "true".equals(condition.getIsPrecise())) {
						sb.append(" on c." + condition.getRelevanceField() + "= p." + condition.getRelevancePreField());
						sb.append(" where c." + condition.getConditionname() + " = '" + cellValue + "'");
						sb.append(" and p." + condition.getRelevanceFieldName() + " = '"
								+ String.valueOf(pCell.getStringCellValue()) + "'");
					} else {
						sb.append(" on c." + condition.getRelevanceField() + "= p." + condition.getRelevancePreField());
						sb.append(" where c." + condition.getConditionname() + " like '%" + cellValue + "%'");
						sb.append(" and p." + condition.getRelevanceFieldName() + " like '%"
								+ String.valueOf(pCell.getStringCellValue()) + "%'");
					}
					if (condition.getIsDeleted() != null && "true".equals(condition.getIsDeleted())) {
						sb.append(" and c.deleted=0 and p.deleted=0 ");
					}
					condition.setFindSql(sb.toString());
					List<Map<String, Object>> resultList = importDao.find(condition);
					if (resultList == null || resultList.size() <= 0) {
						// 级联验证未通过
						messageInfo.setColumNum(cell.getColumnIndex() + 1);
						messageInfo.setRowNum(cell.getRowIndex());
						messageInfo.setMessage("级联关系不存在");
						messageInfoList.add(messageInfo);
						return null;
					}
					Map<String, Object> map = resultList.get(0);
					return String.valueOf(map.get(condition.getResultname()));
				}

				if (condition.getResultname() != null && condition.getTablename() != null
						&& condition.getConditionname() != null && !"".equals(condition.getResultname())
						&& !"".equals(condition.getTablename()) && !"".equals(condition.getConditionname())) {

					if (condition.getDefaultDept() == null) {
						if (cellValue == null || "".equals(cellValue)) {
							return null;
						}
						sb = new StringBuffer();
						sb.append("select ");
						sb.append(condition.getResultname());
						sb.append(" from ");
						sb.append(condition.getTablename());
						sb.append(" where ");
						sb.append(condition.getConditionname());
						if (condition.getIsPrecise() != null && "true".equals(condition.getIsPrecise())) {
							sb.append(" = '");
							sb.append(cellValue);
							sb.append("'");
						} else {
							sb.append(" like '%");
							sb.append(cellValue);
							sb.append("%'");
						}
						//sb.append("  and ent_id='").append(userManager.getUser().getEntId()).append("' ") ;
						if (condition.getIsDeleted() != null && "true".equals(condition.getIsDeleted())) {
							sb.append(" and deleted=0 ");
						}
						sb.append(" limit 0,1");
						condition.setFindSql(sb.toString());
						List<Map<String, Object>> resultList = importDao.find(condition);
						if (resultList != null && resultList.size() > 0) {
							Map<String, Object> map = resultList.get(0);
							return String.valueOf(map.get(condition.getResultname()));
						}
						messageInfo.setColumNum(cell.getColumnIndex() + 1);
						messageInfo.setRowNum(cell.getRowIndex());
						messageInfo.setMessage("关联表对应的数据不存在");
						messageInfoList.add(messageInfo);
						return null;
					} else {
						// 取默认组织机构ID
						if (cellValue == null || "".equals(cellValue)) {
							sb = new StringBuffer();
							sb.append("select "+condition.getResultname()+" from biz_account where account ='" +condition.getDefaultDept() 
									+ "' and ent_id=(select ent_id from eoms_enterprise_account where ent_name='"
									+ pCell.getStringCellValue() + "') ");
						} else {
							// 取对应的输入的组织机构ID
							//过滤当前用户的企业ID
							sb = new StringBuffer();
							if(condition.getFilterUserEnt() !=null && "true".equals(condition.getFilterUserEnt())){
								sb.append("select "+condition.getResultname()+" from "+condition.getTablename()+" where ent_id='"+userManager.getUser().getEntId()+"' and "+condition.getConditionname()+"='" + cellValue + "'");
							}else{
								sb.append("select "+condition.getResultname()+" from "+condition.getTablename()+" where ent_id=(select ent_id from eoms_enterprise_account where ent_name='"
										+ pCell.getStringCellValue() + "') and dept_name='" + cellValue + "'");
							}
						}
						condition.setFindSql(sb.toString());
						List<Map<String, Object>> resultList = importDao.find(condition);
						if (resultList != null && resultList.size() > 0) {
							Map<String, Object> map = resultList.get(0);
							return String.valueOf(map.get(condition.getResultname()));
						}
						messageInfo.setColumNum(cell.getColumnIndex() + 1);
						messageInfo.setRowNum(cell.getRowIndex());
						messageInfo.setMessage("关联表对应的数据不存在");
						messageInfoList.add(messageInfo);
					}
				}
			}
		}
		return cellValue;
	}

	/**
	 * 邮箱验证
	 * 
	 * @param email
	 * @return
	 */
	public boolean emailFormat(String email) {
		boolean tag = true;
		final String pattern1 = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
		final Pattern pattern = Pattern.compile(pattern1);
		final Matcher mat = pattern.matcher(email);
		if (!mat.find()) {
			tag = false;
		}
		return tag;
	}

	/**
	 * 手机号验证
	 * 
	 * @param mobiles
	 * @return
	 */
	public boolean isMobileNO(String mobiles) {
		Pattern p = Pattern.compile("^((13[0-9])||(17[0-9])||(15[^4,\\D])|(18[0,5-9]))\\d{8}$");
		Matcher m = p.matcher(mobiles);
		return m.matches();
	}

	public boolean isValidDate(String str) {
		boolean convertSuccess = true;
		// 验证年月日时分秒
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			format.setLenient(false);
			format.parse(str);
			convertSuccess = true;
		} catch (ParseException e) {
			convertSuccess = false;
		}
		// 验证年月日
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			format1.setLenient(false);
			format1.parse(str);
			convertSuccess = true;
		} catch (ParseException e) {
			convertSuccess = false;
		}
		return convertSuccess;
	}

	/**
	 * 验证文件是否为空 格式是否正确
	 * 
	 * @param file
	 * @return
	 */
	public boolean checkFile(MultipartFile file) {
		logger.debug("验证文件格式开始");
		// 判断文件是否存在
		if (null == file) {
			return false;
		}
		// 获得文件名
		String fileName = file.getOriginalFilename();
		// 判断文件是否是excel文件
		if (!fileName.endsWith("xls") && !fileName.endsWith("xlsx")) {
			return false;
		}
		logger.debug("验证文件格式结束");
		return true;
	}

	/**
	 * 获取excel Workbook对象
	 * 
	 * @param file
	 * @return
	 */
	public Workbook getWorkBook(MultipartFile file) {
		logger.debug("获取excel Workbook对象 开始");
		// 获得文件名
		String fileName = file.getOriginalFilename();
		// 创建Workbook工作薄对象，表示整个excel
		Workbook workbook = null;
		try {
			// 获取excel文件的io流
			InputStream is = file.getInputStream();
			if (fileName.endsWith("xls")) {
				// 2003
				workbook = new HSSFWorkbook(is);
			} else if (fileName.endsWith("xlsx")) {
				// 2007
				workbook = new XSSFWorkbook(is);
			}
			logger.debug("获取excel Workbook对象 成功");
		} catch (IOException e) {
			logger.debug("获取excel Workbook对象 失败");
		}
		return workbook;
	}
}
