package com.neoway.imports.entity;

public class FiledCondition {

	// 此字段名称需要关联的表名
	private String tablename;
	// 查询条件的字段
	private String conditionname;
	// 关联的结果
	private String resultname;
	// 关联表
	private String relevanceTable;
	// 级联的子级字段
	private String relevanceField;
	//级联的父级字段
	private String relevancePreField;
	// 级联父级对应的子对名
	private String relevanceFieldName;
	//级联的两张表是否存在逻辑删除deleted标识 true存在false不存在
	private String isDeleted ;
	// 查询SQL
	private String findSql;
    //字段数据类型
	private String type ;
	//是否必填 true必填 false非必填
	private String required;
	//是否精确查找
	private String isPrecise ;
	
	//数据源是否读redis
	private String readRedis ;
	//对应的key
	private String redisKey ;
	//存放级联默认下的组织机构
	private String defaultDept ;
	
	//对应的值取常量 标识
	private String constantSource ;
	//对应的值取常量 对应的值
	private String constantValue ;
	//是否过滤当前用户的企业ID
	private String filterUserEnt ;
	//对应字段最大长度
	private Integer maxLength ;
	
	
	public String getRelevancePreField() {
		return relevancePreField;
	}

	public void setRelevancePreField(String relevancePreField) {
		this.relevancePreField = relevancePreField;
	}

	public Integer getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(Integer maxLength) {
		this.maxLength = maxLength;
	}

	public String getFilterUserEnt() {
		return filterUserEnt;
	}

	public void setFilterUserEnt(String filterUserEnt) {
		this.filterUserEnt = filterUserEnt;
	}

	public String getConstantSource() {
		return constantSource;
	}

	public void setConstantSource(String constantSource) {
		this.constantSource = constantSource;
	}

	public String getConstantValue() {
		return constantValue;
	}

	public void setConstantValue(String constantValue) {
		this.constantValue = constantValue;
	}

	public String getDefaultDept() {
		return defaultDept;
	}

	public void setDefaultDept(String defaultDept) {
		this.defaultDept = defaultDept;
	}

	public String getReadRedis() {
		return readRedis;
	}

	public void setReadRedis(String readRedis) {
		this.readRedis = readRedis;
	}

	public String getRedisKey() {
		return redisKey;
	}

	public void setRedisKey(String redisKey) {
		this.redisKey = redisKey;
	}

	public String getIsPrecise() {
		return isPrecise;
	}

	public void setIsPrecise(String isPrecise) {
		this.isPrecise = isPrecise;
	}

	public String getRequired() {
		return required;
	}

	public void setRequired(String required) {
		this.required = required;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getRelevanceFieldName() {
		return relevanceFieldName;
	}

	public void setRelevanceFieldName(String relevanceFieldName) {
		this.relevanceFieldName = relevanceFieldName;
	}

	public String getRelevanceField() {
		return relevanceField;
	}

	public void setRelevanceField(String relevanceField) {
		this.relevanceField = relevanceField;
	}

	public String getRelevanceTable() {
		return relevanceTable;
	}

	public void setRelevanceTable(String relevanceTable) {
		this.relevanceTable = relevanceTable;
	}

	public String getFindSql() {
		return findSql;
	}

	public void setFindSql(String findSql) {
		this.findSql = findSql;
	}

	public String getResultname() {
		return resultname;
	}

	public void setResultname(String resultname) {
		this.resultname = resultname;
	}

	public String getTablename() {
		return tablename;
	}

	public void setTablename(String tablename) {
		this.tablename = tablename;
	}

	public String getConditionname() {
		return conditionname;
	}

	public void setConditionname(String conditionname) {
		this.conditionname = conditionname;
	}

}
