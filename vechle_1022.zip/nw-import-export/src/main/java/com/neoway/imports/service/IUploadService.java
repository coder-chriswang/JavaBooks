/**
 * @company 有方物联
 * @file IUploadService.java
 * @author bailu
 * @date 2017年11月6日 
 */
package com.neoway.imports.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

/**
 * @description : 文件上传服务接口
 * @author : bailu
 * @version : V1.0.0
 * @date : 2017年11月6日
 */
public interface IUploadService {

	/**
	 * 批量上传图片
	 * @param  multipartFile
	 * @return 文件-新名字
	 * @author bailu
	 * @date：     2017年11月6日
	 */
	List<String> uploadImages(MultipartFile multipartFile[]);
	
	/**
	 * 批量上传文件
	 * @param  multipartFile
	 * @param  fileType:1.图片   2.音频  3.文档    4.固件更新包
	 * @return 文件-新名字
	 * @author bailu
	 * @date：     2017年11月16日
	 */
	List<String> uploadFiles(MultipartFile multipartFile[], int fileType);
}
