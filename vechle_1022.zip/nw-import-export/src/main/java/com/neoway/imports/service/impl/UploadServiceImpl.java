/**
 * @company 有方物联
 * @file UploadServiceImpl.java
 * @author bailu
 * @date 2017年11月6日 
 */
package com.neoway.imports.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.neoway.imports.service.IUploadService;
import com.neoway.util.DateUtil;
import com.neoway.util.StringUtil;

/**
 * @description :
 * @author : bailu
 * @version : V1.0.0
 * @date : 2017年11月6日
 */
@Service
public class UploadServiceImpl implements IUploadService {

	/* (non-Javadoc)
	 * @see com.etiot.imports.service.IUploadService#uploadImages(org.springframework.web.multipart.MultipartFile[])
	 */
	@Override
	public List<String> uploadImages(MultipartFile[] multipartFiles) {
		List<String> newFileNames = new ArrayList<>();
		
		try {
			for (MultipartFile multipartFile : multipartFiles) {
		    	//文件的原始名称
				String originalFilename = multipartFile.getOriginalFilename();
				String newFileName = null;
				if (multipartFile != null && originalFilename !=null && originalFilename.length() > 0){
					//新文件名称
					
					newFileName = DateUtil.getSysCurrentTimestamp().getTime()+ String.valueOf(StringUtil.getRandom()) + originalFilename.substring(originalFilename.lastIndexOf("."), originalFilename.length());
		            //存储图片的物理路径
		            String pic_path = (new File("")).getAbsolutePath()+"/upload/";
		            //新图片路径
		            File targetFile = new File(pic_path, newFileName);
		            if(!targetFile.getParentFile().exists()){
		            	targetFile.getParentFile().mkdirs();
		            }
		            //内存数据读入磁盘
		            multipartFile.transferTo(targetFile);

		            newFileNames.add("upload/" + newFileName);
		        }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return newFileNames;
	}

	@Override
	public List<String> uploadFiles(MultipartFile[] multipartFiles, int fileType) {
		List<String> newFileNames = new ArrayList<>();
		
		try {
			for (MultipartFile multipartFile : multipartFiles) {
		    	//文件的原始名称
				String originalFilename = multipartFile.getOriginalFilename();
				String newFileName = null;
				if (multipartFile != null && originalFilename !=null && originalFilename.length() > 0){
					//新文件名称
					newFileName = DateUtil.getSysCurrentTimestamp().getTime()+ String.valueOf(StringUtil.getRandom()) + originalFilename.substring(originalFilename.lastIndexOf("."), originalFilename.length());
		            
					String sub_path = ""; //上传文件子目录
					switch (fileType) {
						case 1:
							sub_path = "image";
							break;
						case 2:
							sub_path = "audio";
							break;
						case 3:
							sub_path = "doc";
							break;
						case 4:
							sub_path = "package";
							break;
						default:
							break;
					}
					
					//存储文件的物理路径
		            String file_path = (new File("")).getAbsolutePath() + "/upload/" + sub_path;
		            //新图片路径
		            File targetFile = new File(file_path, newFileName);
		            if(!targetFile.getParentFile().exists()){
		            	targetFile.getParentFile().mkdirs();
		            }
		            //内存数据读入磁盘
		            multipartFile.transferTo(targetFile);

		            newFileNames.add("upload/" + sub_path + "/" + newFileName);
		        }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return newFileNames;
	}

}
