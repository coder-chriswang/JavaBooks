/**
 * @company 有方物联
 * @file ExportFactory.java
 * @author guojy
 * @date 2018年3月23日 
 */
package com.neoway;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neoway.core.SpringContextHolder;
import com.neoway.exports.bean.ExportBean;
import com.neoway.exports.service.IExportService;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月23日
 */
public class ExportFactory {
	private static Logger logger = LoggerFactory.getLogger(ExportFactory.class);
	
	/**
	 * 导出已有的数据源
	 * @param source
	 * @param exportBean
	 * @param responses
	 */
	public static void ExportData(List<?> source,ExportBean exportBean,HttpServletResponse response){
		logger.info("导出数据");
		IExportService exportService = SpringContextHolder.getBean(IExportService.class);
		if(exportService != null){
			exportService.exportData(source, exportBean, response);
		}
	}
	
	/**
	 * 导出SQL数据源
	 * @param sql
	 * @param exportBean
	 * @param responses
	 */
	public static void ExportData(String sql,ExportBean exportBean,HttpServletResponse response){
		logger.info("导出数据");
		IExportService exportService = SpringContextHolder.getBean("exportService");
		if(exportService != null){
			exportService.exportData(sql, exportBean, response);
		}
	}
}
