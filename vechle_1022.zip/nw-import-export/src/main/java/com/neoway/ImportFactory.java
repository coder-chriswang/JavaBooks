/**
 * @company 有方物联
 * @file ImportFactory.java
 * @author guojy
 * @date 2018年3月23日 
 */
package com.neoway;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.core.io.InputStreamSource;

import com.neoway.core.ICommonManager;
import com.neoway.core.SpringContextHolder;
import com.neoway.imports.entity.ImportEntity;
import com.neoway.imports.service.IImportService;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月23日
 */
public class ImportFactory {


	private static final Logger logger = Logger.getLogger(ImportFactory.class);

	/**
	 * 数据导入方法入口
	 * 
	 * @param entity
	 * @param object
	 * @return
	 * @throws Exception
	 */
	public static Map<String, Object> improtData(ImportEntity entity, InputStreamSource object,ICommonManager userManager) throws Exception {
		IImportService importService = null;
		Map<String, Object> result = new HashMap<>();
		if (entity != null) {
			if (entity.getImportType() == null || "".equals(entity.getImportType())) {
				logger.debug("excel导入");
				entity.setImportType("xls");
			}
			if (entity.getSourceType() == null || "".equals(entity.getSourceType())) {
				logger.debug("数据导入关系数据库");
				entity.setSourceType("rdb");
			}
			importService = getServiceByImportType(entity.getImportType());
		}
		if (importService != null) {
			logger.debug("数据导入开始");
			result = importService.importData(object, entity,userManager);
			logger.debug("数据导入结束");
		}
		return result;
	}

	/**
	 * 根据导入文件格式实例化对应的实现类
	 * 
	 * @param type
	 * @return
	 */
	private static IImportService getServiceByImportType(String type) {
		type = type.toUpperCase();
		logger.debug("根据导入类型获取相应的实现对象 开始");
		IImportService service = null;
		if ("XLS".equals(type)) {
			service = SpringContextHolder.getBean(IImportService.class);
		} else {
			service = null;
		}
		logger.debug("根据导入类型获取相应的实现对象 结束");
		return service;
	}

}
