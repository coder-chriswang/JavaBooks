/**
 * @company 有方物联
 * @file JT_0801.java
 * @author guojy
 * @date 2018年7月3日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :JT808-多媒体数据上传
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月3日
 */
public class JT_0801 implements IReadMessageBody {
	/**
	 * 多媒体ID DWORD
	 */
	private long mediaId;
	
	/**
	 * 多媒体类型 BYTE
	 * 0.图像 1.音频 2.视频
	 */
	private short mediaType;

	/**
	 * 多媒体格式编码 BYTE
	 * 0.JPEG  1.TIF  2.MP3  3.WAV  4.WMV
	 */
	private short formatCode;
	
	/**
	 * 事件项编码 BYTE
	 *  0.平台下发   1.定时动作  2.抢劫报警触发   3.碰撞侧翻报警触发
	 */
	private short itemCode;

	/**
	 * 通道ID BYTE
	 */
	private short channel;

	/**
	 * 位置信息 BYTE[28]
	 */
	private byte[] position;
	
	/**
	 * 多媒体数据包
	 */
	private byte[] dataPackage;
	
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IReadMessageBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);

		this.setMediaId(in.readUnsignedInt());
		this.setMediaType(in.readByte());
		this.setFormatCode(in.readByte());
		this.setItemCode(in.readByte());
		this.setChannel(in.readByte());
		byte[] positionPkg = new byte[28];
		in.readBytes(positionPkg, 0, 28);
		this.setPosition(positionPkg);
		int dataLen = messageBodyBytes.length-36;
		byte[] dataPkg = new byte[dataLen];
		in.readBytes(dataPkg, 0, dataLen);
		this.setDataPackage(dataPkg);
	}
	/**
	 * @return the mediaId
	 */
	public long getMediaId() {
		return mediaId;
	}
	/**
	 * @param mediaId the mediaId to set
	 */
	public void setMediaId(long mediaId) {
		this.mediaId = mediaId;
	}
	/**
	 * @return the mediaType
	 */
	public short getMediaType() {
		return mediaType;
	}
	/**
	 * @param mediaType the mediaType to set
	 */
	public void setMediaType(short mediaType) {
		this.mediaType = mediaType;
	}
	/**
	 * @return the formatCode
	 */
	public short getFormatCode() {
		return formatCode;
	}
	/**
	 * @param formatCode the formatCode to set
	 */
	public void setFormatCode(short formatCode) {
		this.formatCode = formatCode;
	}
	/**
	 * @return the itemCode
	 */
	public short getItemCode() {
		return itemCode;
	}
	/**
	 * @param itemCode the itemCode to set
	 */
	public void setItemCode(short itemCode) {
		this.itemCode = itemCode;
	}
	/**
	 * @return the channel
	 */
	public short getChannel() {
		return channel;
	}
	/**
	 * @param channel the channel to set
	 */
	public void setChannel(short channel) {
		this.channel = channel;
	}
	/**
	 * @return the position
	 */
	public byte[] getPosition() {
		return position;
	}
	/**
	 * @param position the position to set
	 */
	public void setPosition(byte[] position) {
		this.position = position;
	}
	/**
	 * @return the dataPackage
	 */
	public byte[] getDataPackage() {
		return dataPackage;
	}
	/**
	 * @param dataPackage the dataPackage to set
	 */
	public void setDataPackage(byte[] dataPackage) {
		this.dataPackage = dataPackage;
	}

	
}
