/**
 * @company 有方物联
 * @file JT808Consts.java
 * @author guojy
 * @date 2018年4月11日
 */
package com.neoway.car.device.util;

import java.util.Hashtable;

/**
 * @description :JT808部标协议相关变量
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class JT808Consts {
    /*******************终端消息ID****************************************/
    public static final int msgid_terminal_register = 0x0100;
    public static final int msgid_terminal_auth = 0x0102;
    public static final int msgid_terminal_commresp = 0x0001;
    public static final int msgid_terminal_heart = 0x0002;
    public static final int msgid_terminal_localtionreport = 0x0200;
    public static final int msgid_terminal_paramsresp = 0x0104;
    public static final int msgid_terminal_propsresp = 0x0107;
    public static final int msgid_terminal_updateresp = 0x0108;
    public static final int msgid_terminal_localtionresp = 0x0201;
    public static final int msgid_terminal_controlresp = 0x0500;
    public static final int MSGID_TERMINAL_BATCH_REPORT = 0x0704;
    public static final int MSGID_TERMINAL_PASSTHROUGH_REPORT = 0x0900;
    public static final int MSGID_TERMINAL_LOW_POWER_LOGIN = 0x0101;
    public static final int MSGID_TERMINAL_LOW_POWER_LOCATION_REPORT = 0x0211;
    public static final int MSGID_TERMINAL_LOW_POWER_LBS_EXTEND = 0x0212;

    /*******************平台消息ID****************************************/
    public static final int msgid_plantform_commresp = 0x8001;
    public static final int MSGID_LOW_POWER_PLANTFORM_COMMRESP = 0x8150;
    public static final int msgid_plantform_registerresp = 0x8100;
    public static final int msgid_plantform_setparams = 0x8103;
    public static final int msgid_plantform_searchparams = 0x8104;
    public static final int msgid_plantform_control = 0x8105;
    public static final int msgid_plantform_searchparam = 0x8106;
    public static final int msgid_plantform_searchprop = 0x8107;
    public static final int MSGID_PLANTFORM_LOGIN_REPLY = 0x8101;

    /**
     * 位置信息查询
     */
    public static final int msgid_plantform_searchlocaltion = 0x8201;
    /**
     * 临时位置跟踪控制
     */
    public static final int msgid_plantform_track = 0x8202;
    /**
     * 文本下发
     */
    public static final int msgid_plantform_textdown = 0x8300;
    /**
     * 设置圆形区域
     */
    public static final int msgid_plantform_setcircular = 0x8600;
    /**
     * 删除圆形区域
     */
    public static final int msgid_plantform_delcircular = 0x8601;
    /**
     * 设置矩形区域
     */
    public static final int msgid_plantform_setrectangle = 0x8602;
    /**
     * 删除矩形区域
     */
    public static final int msgid_plantform_delrectangle = 0x8603;
    /**
     * 设置多边形区域
     */
    public static final int msgid_plantform_setpolygon = 0x8604;
    /**
     * 删除多边形区域
     */
    public static final int msgid_plantform_delpolygon = 0x8605;
    /**
     * 设置线路
     */
    public static final int msgid_plantform_setpolyline = 0x8606;
    /**
     * 删除线路
     */
    public static final int msgid_plantform_delpolyline = 0x8607;
    /*******************位置附加消息ID****************************************/
    /**
     * 里程附加ID
     */
    public static final int msgid_positionAdditional_mileage = 0x01;
    /**
     * 油量附加ID
     */
    public static final int msgid_positionAdditional_oilmass = 0x02;
    /**
     * 超速报警附加信息ID
     */
    public static final int msgid_positionAdditional_speed = 0x11;
    /**
     * 进出区域、线路报警附加信息ID
     */
    public static final int msgid_positionAdditional_inoutarea = 0x12;
    /**
     * 路段行驶时间不足/过长报警附加信息ID
     */
    public static final int msgid_positionAdditional_driving = 0x13;
    /**
     * 无线通信网络信号强度附加信息ID
     */
    public static final int msgid_positionAdditional_simSignal = 0x30;
    /**
     * GNSS 定位卫星数附加信息ID
     */
    public static final int msgid_positionAdditional_satellitenum = 0x31;

    /**
     * OBD扩展告警ID
     */
    public static final int MSGID_PISITIONADDITIONAL_EXTENDALARMSTATE = 0xF0;

    /**
     * OBD拓展状态ID
     */
    public static final int MSGID_PISITIONADDITIONAL_EXTENDSTATE = 0xF1;

    /**
     * OBD车辆电压ID
     */
    public static final int MSGID_PISITIONADDITIONAL_CARVOLTAGE = 0xF2;

    /**
     * OBD终端电池电压ID
     */
    public static final int MSGID_PISITIONADDITIONAL_TERMINALBATTERYVOLTAGE = 0xF3;

    /**
     * OBD自定义数据体ID
     */
    public static final int MSGID_PISITIONADDITIONAL_CUSTOMDATA = 0xF4;

    /**
     * 参数设置指令ID
     */
    public static java.util.Hashtable<Integer,String> FieldTypeMap = null;

    /**
     * 低功耗登录回复参数指令ID MAP
     */
    public static java.util.Hashtable<Integer,String> LOW_POWER_FIELD_TYPE_MAP = null;

    /**
     * obd F4 obd数据
     */
    public static java.util.Hashtable<Integer,String> OBD_F4_FIELD_TYPE_MAP = null;

    static{
        FieldTypeMap = new java.util.Hashtable<Integer,String>();
        FieldTypeMap.put(0x0001, "DWORD");
        FieldTypeMap.put(0x0002, "DWORD");
        FieldTypeMap.put(0x0003, "DWORD");
        FieldTypeMap.put(0x0004, "DWORD");
        FieldTypeMap.put(0x0005, "DWORD");
        FieldTypeMap.put(0x0006, "DWORD");
        FieldTypeMap.put(0x0007, "DWORD");
        FieldTypeMap.put(0x0010, "STRING");
        FieldTypeMap.put(0x0011, "STRING");
        FieldTypeMap.put(0x0012, "STRING");
        FieldTypeMap.put(0x0013, "STRING");
        FieldTypeMap.put(0x0014, "STRING");
        FieldTypeMap.put(0x0015, "STRING");
        FieldTypeMap.put(0x0016, "STRING");
        FieldTypeMap.put(0x0017, "STRING");
        FieldTypeMap.put(0x0018, "DWORD");
        FieldTypeMap.put(0x0019, "DWORD");
        FieldTypeMap.put(0x001A, "STRING");
        FieldTypeMap.put(0x001B, "DWORD");
        FieldTypeMap.put(0x001C, "DWORD");
        FieldTypeMap.put(0x001D, "STRING");
        FieldTypeMap.put(0x0020, "DWORD");
        FieldTypeMap.put(0x0021, "DWORD");
        FieldTypeMap.put(0x0022, "DWORD");
        FieldTypeMap.put(0x0027, "DWORD");
        FieldTypeMap.put(0x0028, "DWORD");
        FieldTypeMap.put(0x0029, "DWORD");
        FieldTypeMap.put(0x002C, "DWORD");
        FieldTypeMap.put(0x002D, "DWORD");
        FieldTypeMap.put(0x002E, "DWORD");
        FieldTypeMap.put(0x002F, "DWORD");
        FieldTypeMap.put(0x0030, "DWORD");
        FieldTypeMap.put(0x0031, "WORD");
        FieldTypeMap.put(0x0040, "STRING");
        FieldTypeMap.put(0x0041, "STRING");
        FieldTypeMap.put(0x0042, "STRING");
        FieldTypeMap.put(0x0043, "STRING");
        FieldTypeMap.put(0x0044, "STRING");
        FieldTypeMap.put(0x0045, "DWORD");
        FieldTypeMap.put(0x0046, "DWORD");
        FieldTypeMap.put(0x0047, "DWORD");
        FieldTypeMap.put(0x0048, "STRING");
        FieldTypeMap.put(0x0049, "STRING");
        FieldTypeMap.put(0x0050, "DWORD");
        FieldTypeMap.put(0x0051, "DWORD");
        FieldTypeMap.put(0x0052, "DWORD");
        FieldTypeMap.put(0x0053, "DWORD");
        FieldTypeMap.put(0x0054, "DWORD");
        FieldTypeMap.put(0x0055, "DWORD");
        FieldTypeMap.put(0x0056, "DWORD");
        FieldTypeMap.put(0x0057, "DWORD");
        FieldTypeMap.put(0x0058, "DWORD");
        FieldTypeMap.put(0x0059, "DWORD");
        FieldTypeMap.put(0x005A, "DWORD");
        FieldTypeMap.put(0x005B, "WORD");
        FieldTypeMap.put(0x005C, "WORD");
        FieldTypeMap.put(0x005D, "WORD");
        FieldTypeMap.put(0x005E, "WORD");
        FieldTypeMap.put(0x0064, "DWORD");
        FieldTypeMap.put(0x0065, "DWORD");
        FieldTypeMap.put(0x0070, "DWORD");
        FieldTypeMap.put(0x0071, "DWORD");
        FieldTypeMap.put(0x0072, "DWORD");
        FieldTypeMap.put(0x0073, "DWORD");
        FieldTypeMap.put(0x0074, "DWORD");
        FieldTypeMap.put(0x0080, "DWORD");
        FieldTypeMap.put(0x0081, "WORD");
        FieldTypeMap.put(0x0082, "WORD");
        FieldTypeMap.put(0x0083, "STRING");
        FieldTypeMap.put(0x0084, "BYTE");
        FieldTypeMap.put(0x0090, "BYTE");
        FieldTypeMap.put(0x0091, "BYTE");
        FieldTypeMap.put(0x0092, "BYTE");
        FieldTypeMap.put(0x0093, "DWORD");
        FieldTypeMap.put(0x0094, "BYTE");
        FieldTypeMap.put(0x0095, "DWORD");
        FieldTypeMap.put(0x0100, "DWORD");
        FieldTypeMap.put(0x0101, "DWORD");
        FieldTypeMap.put(0x0102, "DWORD");
        FieldTypeMap.put(0x0103, "BYTE");
        FieldTypeMap.put(0xF001, "BYTE");
        FieldTypeMap.put(0xF002, "BYTE");
        FieldTypeMap.put(0xF003, "BYTE");
        FieldTypeMap.put(0xF004, "BYTE");
        FieldTypeMap.put(0xF005, "WORD");
        FieldTypeMap.put(0xF006, "WORD");
        FieldTypeMap.put(0xF007, "WORD");
        FieldTypeMap.put(0xF008, "WORD");
        FieldTypeMap.put(0xF009, "STRING");
        FieldTypeMap.put(0xF010, "WORD");
        FieldTypeMap.put(0xF011, "WORD");
        FieldTypeMap.put(0xF012, "WORD");
        FieldTypeMap.put(0xF013, "WORD");
        FieldTypeMap.put(0xF014, "STRING");
        FieldTypeMap.put(0xF015, "BYTE");

        LOW_POWER_FIELD_TYPE_MAP = new Hashtable<>();
        LOW_POWER_FIELD_TYPE_MAP.put(0x01, "WORD");
        LOW_POWER_FIELD_TYPE_MAP.put(0x02, "BCD");
        LOW_POWER_FIELD_TYPE_MAP.put(0x03, "BYTE");
        LOW_POWER_FIELD_TYPE_MAP.put(0x04, "BYTE");
        LOW_POWER_FIELD_TYPE_MAP.put(0x05, "WORD");
        LOW_POWER_FIELD_TYPE_MAP.put(0x06, "BYTE");
        LOW_POWER_FIELD_TYPE_MAP.put(0x07, "BYTE");
        LOW_POWER_FIELD_TYPE_MAP.put(0x08, "STRING");
        LOW_POWER_FIELD_TYPE_MAP.put(0x09, "WORD");

        OBD_F4_FIELD_TYPE_MAP = new Hashtable<>();
        OBD_F4_FIELD_TYPE_MAP.put(0x0105, "BYTE");
        OBD_F4_FIELD_TYPE_MAP.put(0x010B, "BYTE");
        OBD_F4_FIELD_TYPE_MAP.put(0x010C, "WORD");
        OBD_F4_FIELD_TYPE_MAP.put(0x010D, "BYTE");
        OBD_F4_FIELD_TYPE_MAP.put(0x010F, "BYTE");
        OBD_F4_FIELD_TYPE_MAP.put(0x0110, "WORD");
        OBD_F4_FIELD_TYPE_MAP.put(0x0111, "WORD");
        OBD_F4_FIELD_TYPE_MAP.put(0x012F, "WORD");
    }
}
