/**
 * @company 有方物联
 * @file PostitionAdditional_25.java
 * @author guojy
 * @date 2018年4月24日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月24日
 */
public class PostitionAdditional_25 implements IPositionAdditionalItem {

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x25;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x4;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {

	}

}
