/**
 * @company 有方物联
 * @file JsonTools.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.device.util;

import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

/**
 * @description :alibaba JSON转发工具
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class JsonTools {
	
	private static TypeReference<Map<String,String>> typeReference = new TypeReference<Map<String,String>>(){};

	public static Map<String, String> toMap(String value){
		return JSON.parseObject(value, typeReference);
	}
	
	public static String toJsonStr(Map<String, String> value){
        return JSON.toJSONString(value);
    }
	

}
