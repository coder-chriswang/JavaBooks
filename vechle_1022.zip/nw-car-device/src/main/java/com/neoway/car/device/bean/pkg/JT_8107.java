/**
 * @company 有方物联
 * @file JT_8107.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;

/**
 * @description : 查询终端属性（消息体为空）
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8107 implements IWriteMessageBody {

	@Override
	public byte[] writeToBytes() {
		return null;
	}

}
