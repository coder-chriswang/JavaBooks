/**
 * @company 有方物联
 * @file JT808PositionAdditionalFactory.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.device.bean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neoway.util.hex.HexStringUtils;

/**
 * @description :JT808位置附加信息工厂类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class JT808PositionAdditionalFactory {
	private static Logger logger = LoggerFactory.getLogger(JT808PositionAdditionalFactory.class);
	
	/**
	 * 实例化附加消息对象
	 * @param msgId 附加消息ID
	 * @param itemBytes 附加消息
	 * @return
	 */
	public static IPositionAdditionalItem getPositionAdditional(int additionalId,byte[] additionalBytes){
		String nameSpace = JT808MessageFactory.class.getPackage().getName()+".pkg";
		String name = ".PostitionAdditional_"+HexStringUtils.toHexString(additionalId, 1).toUpperCase();
		String className = nameSpace+name;
		try {
			Class<?> cl = Class.forName(className);
			IPositionAdditionalItem additionalItem = (IPositionAdditionalItem) cl.newInstance();
			additionalItem.readFromBytes(additionalBytes);
			return additionalItem;
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			logger.warn("不支持的通讯消息");
		}
		return null;
	}
}
