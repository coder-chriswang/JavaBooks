/**
 * @company 有方物联
 * @file IMessageBody.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.bean;

/**
 * @description :报文解码接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
public interface IReadMessageBody {
	/**
	 * 读入字节数组
	 * @param messageBodyBytes
	 */
	void readFromBytes(byte[] messageBodyBytes);
}
