package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: 低功耗设备上报GPS信息
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/30 10:03
 */
public class JT_0211 implements IReadMessageBody {

    private static final int BCD_STRING_LENGTH = 6;
    /**
     * 纬度,DWord(32bit)
     * 以度为单位的纬度值乘以10的6次方，精确到百万分之一度
     */
    private long latitude;

    /**
     * 经度,DWord(32bit)
     * 以度为单位的经度值乘以10的6次方，精确到百万 分之一度
     */
    private long longitude;

    /**
     * 海拔高度，单位为米（m）Word(16bit)
     */
    private int altitude;

    /**
     * 速度,1/10km/h  Word(16bit)
     */
    private int speed;

    /**
     * 方向,0～359，正北为0，顺时针 Word(16bit)
     */
    private int course;

    /**
     * 卫星数，BYTE
     */
    private short gpsNum;

    /**
     * 当前卫星数 BYTE
     */
    private short currentGpsNum;

    /**
     * 状态位
     */
    private short state;

    /**
     * 上报模式
     */
    private short reportMode;

    /**
     * 电压值，单位0.1V
     */
    private short voltage;

    /**
     * 温度，单位0.01摄氏度
     */
    private int temperature;

    /**
     * CSQ信号强度，（0-3199）
     */
    private short csqSignal;

    /**
     * 时间, BCD[6]
     * YY-MM-DD-hh-mm-ss（本标准中之后涉及的时间均采用此时区）
     */
    private String time;

    @Override
    public void readFromBytes(byte[] messageBodyBytes) {
        ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
        setLatitude(in.readUnsignedInt());
        setLongitude(in.readUnsignedInt());
        setAltitude(in.readUnsignedShort());
        setSpeed(in.readUnsignedShort());
        setCourse(in.readUnsignedShort());
        setGpsNum(in.readUnsignedByte());
        setCurrentGpsNum(in.readUnsignedByte());
        setState(in.readUnsignedByte());
        setReportMode(in.readUnsignedByte());
        setVoltage(in.readUnsignedByte());
        setTemperature(in.readUnsignedShort());
        setCsqSignal(in.readUnsignedByte());
        // 上报时间6字节 BCD[6]
        if(in.readableBytes() >= BCD_STRING_LENGTH){
            StringBuilder timeBuilder = new StringBuilder();
            byte[] timeBytes = new byte[6];
            in.readBytes(timeBytes, 0, 6);
            timeBuilder.append("20")
                    .append(String.format("%02X", timeBytes[0]))
                    .append("-")
                    .append(String.format("%02X", timeBytes[1]))
                    .append("-")
                    .append(String.format("%02X", timeBytes[2]))
                    .append(" ")
                    .append(String.format("%02X", timeBytes[3]))
                    .append(":")
                    .append(String.format("%02X", timeBytes[4]))
                    .append(":")
                    .append(String.format("%02X", timeBytes[5]));
            setTime(timeBuilder.toString());
        }
    }

    public long getLatitude() {
        return latitude;
    }

    public void setLatitude(long latitude) {
        this.latitude = latitude;
    }

    public long getLongitude() {
        return longitude;
    }

    public void setLongitude(long longitude) {
        this.longitude = longitude;
    }

    public int getAltitude() {
        return altitude;
    }

    public void setAltitude(int altitude) {
        this.altitude = altitude;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getCourse() {
        return course;
    }

    public void setCourse(int course) {
        this.course = course;
    }

    public short getGpsNum() {
        return gpsNum;
    }

    public void setGpsNum(short gpsNum) {
        this.gpsNum = gpsNum;
    }

    public short getCurrentGpsNum() {
        return currentGpsNum;
    }

    public void setCurrentGpsNum(short currentGpsNum) {
        this.currentGpsNum = currentGpsNum;
    }

    public short getState() {
        return state;
    }

    public void setState(short state) {
        this.state = state;
    }

    public short getReportMode() {
        return reportMode;
    }

    public void setReportMode(short reportMode) {
        this.reportMode = reportMode;
    }

    public short getVoltage() {
        return voltage;
    }

    public void setVoltage(short voltage) {
        this.voltage = voltage;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public short getCsqSignal() {
        return csqSignal;
    }

    public void setCsqSignal(short csqSignal) {
        this.csqSignal = csqSignal;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
