package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPassThroughMessage;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: 行程报告（行程结束时发送）
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/16 16:56
 */
public class PassThroughMessage_F3 implements IPassThroughMessage {
    /**
     * 行程开始时间
     */
    private String startTime;

    /**
     * 行程结束时间
     */
    private String endTime;

    /**
     * 行程距离（单位km）
     */
    private int distance;

    /**
     * 行程燃油量（单位ml）
     */
    private int oil;

    /**
     * 行程怠速时长（单位s）
     */
    private int idleSpeedSeconds;

    /**
     * 怠速累计燃油量（单位ml）
     */
    private int idleOil;

    /**
     * 行程最大速度
     */
    private short maxSpeed;

    /**
     * 行程最大RPM
     */
    private int maxRpm;

    @Override
    public int getMessageId() {
        return 0xF3;
    }

    @Override
    public byte getMessageLength() {
        return 23;
    }

    @Override
    public byte[] writeToBytes() {
        return null;
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        // 开始时间
        StringBuilder startTimeBuilder = new StringBuilder();
        byte[] startTimeBytes = new byte[6];
        in.readBytes(startTimeBytes, 0, 6);
        startTimeBuilder.append("20")
                .append(String.format("%02X", startTimeBytes[0]))
                .append("-")
                .append(String.format("%02X", startTimeBytes[1]))
                .append("-")
                .append(String.format("%02X", startTimeBytes[2]))
                .append(" ")
                .append(String.format("%02X", startTimeBytes[3]))
                .append(":")
                .append(String.format("%02X", startTimeBytes[4]))
                .append(":")
                .append(String.format("%02X", startTimeBytes[5]));
        setStartTime(startTimeBuilder.toString());
        // 行程结束时间
        StringBuilder endTimeBuilder = new StringBuilder();
        byte[] endTimeBytes = new byte[6];
        in.readBytes(endTimeBytes, 0, 6);
        endTimeBuilder.append("20")
                .append(String.format("%02X", endTimeBytes[0]))
                .append("-")
                .append(String.format("%02X", endTimeBytes[1]))
                .append("-")
                .append(String.format("%02X", endTimeBytes[2]))
                .append(" ")
                .append(String.format("%02X", endTimeBytes[3]))
                .append(":")
                .append(String.format("%02X", endTimeBytes[4]))
                .append(":")
                .append(String.format("%02X", endTimeBytes[5]));
        setEndTime(endTimeBuilder.toString());
        // 行程距离
        setDistance(in.readUnsignedShort());
        // 行程燃油量
        setOil(in.readUnsignedShort());
        // 行程怠速时长
        setIdleSpeedSeconds(in.readUnsignedShort());
        // 行程怠速累计燃油量
        setIdleOil(in.readUnsignedShort());
        // 行程最大速度
        setMaxSpeed(in.readUnsignedByte());
        // 行程最大RPM
        setMaxRpm(in.readUnsignedShort());
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getOil() {
        return oil;
    }

    public void setOil(int oil) {
        this.oil = oil;
    }

    public int getIdleSpeedSeconds() {
        return idleSpeedSeconds;
    }

    public void setIdleSpeedSeconds(int idleSpeedSeconds) {
        this.idleSpeedSeconds = idleSpeedSeconds;
    }

    public int getIdleOil() {
        return idleOil;
    }

    public void setIdleOil(int idleOil) {
        this.idleOil = idleOil;
    }

    public short getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(short maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public int getMaxRpm() {
        return maxRpm;
    }

    public void setMaxRpm(int maxRpm) {
        this.maxRpm = maxRpm;
    }
}
