/**
 * @company 有方物联
 * @file ShutdownHook.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.boot;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ConfigurableApplicationContext;

import com.neoway.car.device.service.ICarDeviceService;
import com.neoway.car.device.util.Constant;
import com.neoway.car.device.util.DeviceManager;

import io.netty.channel.ChannelHandlerContext;

/**
 * @description :销毁容器Hook
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
public class ShutdownHook implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(ShutdownHook.class);

	private ConfigurableApplicationContext beanfactory;  
    
    public ShutdownHook(ConfigurableApplicationContext beanfactory){  
        this.beanfactory = beanfactory;  
    }  
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		//车辆离线处理
		logger.info("服务关闭！  车辆强制离线");
		ICarDeviceService carDeviceService = beanfactory.getBean(ICarDeviceService.class);
		DeviceManager deviceManager = DeviceManager.getInstance();
		Map<String, ChannelHandlerContext> deviceMap = deviceManager.findAllDevices();
		Iterator<Entry<String, ChannelHandlerContext>> iterator = deviceMap.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<String, ChannelHandlerContext> entry = iterator.next();
			String equId = entry.getKey();
			String deptId = "",carId = "",carNum = "";
			ChannelHandlerContext ctx = entry.getValue();
			if(ctx != null){
				carId = ctx.channel().attr(Constant.carId).get();
				carNum = ctx.channel().attr(Constant.carNum).get();
				deptId = ctx.channel().attr(Constant.deptId).get();
			}
			carDeviceService.equOffline(equId, deptId, carId, carNum);
		}
		beanfactory.close();
	}

}
