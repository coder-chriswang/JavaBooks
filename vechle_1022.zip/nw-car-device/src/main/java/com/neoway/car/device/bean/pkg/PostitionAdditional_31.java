/**
 * @company 有方物联
 * @file PostitionAdditional_31.java
 * @author guojy
 * @date 2018年4月24日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :GNSS 定位卫星数
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月24日
 */
public class PostitionAdditional_31 implements IPositionAdditionalItem {
	/**
	 * 定位卫星数
	 */
	private short satelliteNum;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x31;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x1;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(1);
		in.writeByte(this.getSatelliteNum());
		return in.array();
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		this.setSatelliteNum(in.readUnsignedByte());
	}

	/**
	 * @return the satelliteNum
	 */
	public short getSatelliteNum() {
		return satelliteNum;
	}

	/**
	 * @param satelliteNum the satelliteNum to set
	 */
	public void setSatelliteNum(short satelliteNum) {
		this.satelliteNum = satelliteNum;
	}

}
