/**
 * @company 有方物联
 * @file JT808MessageFactory.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.bean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neoway.util.hex.HexStringUtils;

/**
 * @description :部标协议数据体字节码转化
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
public class JT808MessageFactory {
	private static Logger logger = LoggerFactory.getLogger(JT808MessageFactory.class);
	
	public static IReadMessageBody getMsgBody(int msgId,byte[] msgBodyBytes){
		String nameSpace = JT808MessageFactory.class.getPackage().getName()+".pkg";
		String name = ".JT_"+HexStringUtils.toHexString(msgId, 2).toUpperCase();
		String className = nameSpace+name;
		try {
			Class<?> cl = Class.forName(className);
			IReadMessageBody msgBody = (IReadMessageBody) cl.newInstance();
			msgBody.readFromBytes(msgBodyBytes);
			logger.info("消息体：{}", msgBody);
			return msgBody;
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			logger.warn("不支持的通讯消息");
		}
		return null;
	}
}
