/**
 * @company 有方物联
 * @file JT_1003.java
 * @author guojy
 * @date 2018年7月6日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :上传终端音视频属性
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月6日
 */
public class JT_1003 implements IReadMessageBody {
	/**
	 * BYTE音频编码
	 */
	private short audioType;
	/**
	 * BYTE音频声道数
	 */
	private short audioNum;
	/**
	 * BYTE音频采样率
	 */
	private short audioSampRates;
	/**
	 * BYTE音频采样位数
	 */
	private short audioSampBit;
	/**
	 * BYTE音频帧长度
	 */
	private int audioFrameLen;
	/**
	 * BYTE是否允许音频输出
	 */
	private short allowAudio;
	/**
	 * BYTE视频编码
	 */
	private short videoType;
	/**
	 * BYTE支持最大物理音频通道数
	 */
	private short maxAudioNum;
	/**
	 * BYTE支持最大物理视频通道数
	 */
	private short maxVideoNum;
	
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IReadMessageBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
		this.setAudioType(in.readUnsignedByte());
		this.setAudioNum(in.readUnsignedByte());
		this.setAudioSampRates(in.readUnsignedByte());
		this.setAudioSampBit(in.readUnsignedByte());
		this.setAudioFrameLen(in.readUnsignedShort());
		this.setAllowAudio(in.readUnsignedByte());
		this.setVideoType(in.readUnsignedByte());
		this.setMaxAudioNum(in.readUnsignedByte());
		this.setMaxVideoNum(in.readUnsignedByte());
	}

	/**
	 * @return the audioType
	 */
	public short getAudioType() {
		return audioType;
	}

	/**
	 * @param audioType the audioType to set
	 */
	public void setAudioType(short audioType) {
		this.audioType = audioType;
	}

	/**
	 * @return the audioNum
	 */
	public short getAudioNum() {
		return audioNum;
	}

	/**
	 * @param audioNum the audioNum to set
	 */
	public void setAudioNum(short audioNum) {
		this.audioNum = audioNum;
	}

	/**
	 * @return the audioSampRates
	 */
	public short getAudioSampRates() {
		return audioSampRates;
	}

	/**
	 * @param audioSampRates the audioSampRates to set
	 */
	public void setAudioSampRates(short audioSampRates) {
		this.audioSampRates = audioSampRates;
	}

	/**
	 * @return the audioSampBit
	 */
	public short getAudioSampBit() {
		return audioSampBit;
	}

	/**
	 * @param audioSampBit the audioSampBit to set
	 */
	public void setAudioSampBit(short audioSampBit) {
		this.audioSampBit = audioSampBit;
	}

	/**
	 * @return the audioFrameLen
	 */
	public int getAudioFrameLen() {
		return audioFrameLen;
	}

	/**
	 * @param audioFrameLen the audioFrameLen to set
	 */
	public void setAudioFrameLen(int audioFrameLen) {
		this.audioFrameLen = audioFrameLen;
	}

	/**
	 * @return the allowAudio
	 */
	public short getAllowAudio() {
		return allowAudio;
	}

	/**
	 * @param allowAudio the allowAudio to set
	 */
	public void setAllowAudio(short allowAudio) {
		this.allowAudio = allowAudio;
	}

	/**
	 * @return the videoType
	 */
	public short getVideoType() {
		return videoType;
	}

	/**
	 * @param videoType the videoType to set
	 */
	public void setVideoType(short videoType) {
		this.videoType = videoType;
	}

	/**
	 * @return the maxAudioNum
	 */
	public short getMaxAudioNum() {
		return maxAudioNum;
	}

	/**
	 * @param maxAudioNum the maxAudioNum to set
	 */
	public void setMaxAudioNum(short maxAudioNum) {
		this.maxAudioNum = maxAudioNum;
	}

	/**
	 * @return the maxVideoNum
	 */
	public short getMaxVideoNum() {
		return maxVideoNum;
	}

	/**
	 * @param maxVideoNum the maxVideoNum to set
	 */
	public void setMaxVideoNum(short maxVideoNum) {
		this.maxVideoNum = maxVideoNum;
	}


	
}
