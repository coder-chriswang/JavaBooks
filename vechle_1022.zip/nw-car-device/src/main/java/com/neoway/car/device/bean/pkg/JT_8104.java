/**
 * @company 有方物联
 * @file JT_8104.java
 * @author bailu
 * @date 2018年4月16日
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;

/**
 * @description : 查询终端参数（应答0104）
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8104 implements IWriteMessageBody {

    @Override
    public byte[] writeToBytes() {
        return null;
    }

}
