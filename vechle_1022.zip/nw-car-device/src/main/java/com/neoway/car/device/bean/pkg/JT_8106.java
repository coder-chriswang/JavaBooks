/**
 * @company 有方物联
 * @file JT_8106.java
 * @author bailu
 * @date 2018年4月16日
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;
import com.neoway.car.device.util.Constant;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 查询指定终端参数（应答0104）
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8106 implements IWriteMessageBody {

    /**
     * id总数
     */
    private short idNum;

    /**
     * id列表
     */
    private String ids;

    @Override
    public byte[] writeToBytes() {
        int len = 1;
        len += 4 * getIdNum();
        ByteBuf in = Unpooled.buffer(len);
        in.writeByte(getIdNum());
        in.writeBytes(getIds().getBytes(Constant.string_charset));
        return in.array();
    }

    public short getIdNum() {
        return idNum;
    }

    public void setIdNum(short idNum) {
        this.idNum = idNum;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }
}
