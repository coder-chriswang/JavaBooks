/**
 * @company 有方物联
 * @file Constant.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.device.util;

import java.nio.charset.Charset;

import io.netty.util.AttributeKey;

/**
 * @description :共用常量类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class Constant {
	/**
	 * 报文上报流向
	 */
	public static final String pkg_direct_up = "UP";
	/**
	 * 报文下发流向
	 */
	public static final String pkg_direct_down = "DOWN";
	/**
	 * 协议编码
	 */
	public static final String string_encoding = "GBK";

	/**
	 * 字符和字节之间的命名映射
	 */
	public static final Charset string_charset = Charset.forName(string_encoding);
	
	/**
	 *  标识位
	 */
	public static final int pkg_delimiter = 0x7e;
	public static AttributeKey<String> equId = AttributeKey.valueOf("equId"); //设备ID
	public static AttributeKey<String> carId = AttributeKey.valueOf("carId"); //车辆ID
	public static AttributeKey<String> carNum = AttributeKey.valueOf("carNum"); //车牌
	public static AttributeKey<String> deptId = AttributeKey.valueOf("deptId"); //部门ID
	
	public static AttributeKey<String> downCmdCahce = AttributeKey.valueOf("downCmdCahce"); //指令下发数据缓存  终端响应时消息处理
	
	/**
	 * 0x8107的应答消息不带平台流水号  因此指定默认流水号为0
	 */
	public static final int JT8107_DEFAULT_FLOWID = 0;
	/**
	 * 0x9003的应答消息不带平台流水号  因此指定默认流水号为1
	 */
	public static final int JT9003_DEFAULT_FLOWID = 1;
}
