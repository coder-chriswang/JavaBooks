/**
 * @company 有方物联
 * @file JT_0201.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 位置信息查询应答
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_0201 implements IReadMessageBody {

	/**
	 * 应答流水号 word(16bit)  
	 * 对应的平台消息的流水号
	 */
	private int respFlowId;
	
	/**
	 * 位置信息汇报
	 */
	private JT_0200 positionInfo;
	
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
		this.setRespFlowId(in.readUnsignedShort());
		JT_0200 jt_0200 = new JT_0200();
		byte[] jt0200byte = new byte[messageBodyBytes.length-2];
		System.arraycopy(messageBodyBytes, 2, jt0200byte, 0, jt0200byte.length);
		jt_0200.readFromBytes(jt0200byte);
		this.setPositionInfo(jt_0200);
	}

	/**
	 * @return the respFlowId
	 */
	public int getRespFlowId() {
		return respFlowId;
	}

	/**
	 * @param respFlowId the respFlowId to set
	 */
	public void setRespFlowId(int respFlowId) {
		this.respFlowId = respFlowId;
	}

	/**
	 * @return the positionInfo
	 */
	public JT_0200 getPositionInfo() {
		return positionInfo;
	}

	/**
	 * @param positionInfo the positionInfo to set
	 */
	public void setPositionInfo(JT_0200 positionInfo) {
		this.positionInfo = positionInfo;
	}

}
