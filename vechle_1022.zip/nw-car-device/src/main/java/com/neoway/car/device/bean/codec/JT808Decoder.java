/**
 * @company 有方物联
 * @file JT808Decoder.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.bean.codec;

import java.util.List;
import java.util.concurrent.ConcurrentMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Maps;
import com.neoway.car.device.bean.IReadMessageBody;
import com.neoway.car.device.bean.JT808MessageFactory;
import com.neoway.car.device.bean.MsgHeader;
import com.neoway.car.device.bean.PackageData;
import com.neoway.car.device.service.ICarDeviceService;
import com.neoway.car.device.util.Constant;
import com.neoway.util.hex.BCD8421Operater;
import com.neoway.util.hex.BitOperator;
import com.neoway.util.hex.HexStringUtils;
import com.neoway.util.hex.JT808ProtocolUtils;

/**
 * @description :JT808部标协议解码
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
@Component
public class JT808Decoder {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private ICarDeviceService carDeviceService;
	/**
	 * 数据分包时临时存储 key为终端手机号+消息ID
	 */
	public static ConcurrentMap<String, List<byte[]>> subPkgMap = Maps.newConcurrentMap();
	/**
	 * 设备报文数据解码
	 * @param data
	 * @return
	 */
	public PackageData bytes2PackageData(byte[] data) {
		PackageData packageData = new PackageData();
		try {
			data = JT808ProtocolUtils.doEscape4Receive(data, 0, data.length);
			MsgHeader msgHeader = this.parseMsgHeaderFromBytes(data);
			packageData.setMsgHeader(msgHeader);
			int msgBodyByteStartIndex = 12;
			if(msgHeader.isHasSubPackage()){
				msgBodyByteStartIndex = 16;
			}
			byte[] msgBodyBytes = null;
			if(msgHeader.getMsgBodyLength() != 0){
				msgBodyBytes = new byte[msgHeader.getMsgBodyLength()];
				System.arraycopy(data, msgBodyByteStartIndex, msgBodyBytes, 0, msgBodyBytes.length);
				logger.info("msgBodyBytes: {}", msgBodyBytes);
			}
			if(packageData.getMsgHeader().isHasSubPackage()){
				//getWholePacket(packageData, msgBodyBytes);
			}else{
				IReadMessageBody messageBody = JT808MessageFactory.getMsgBody(msgHeader.getMsgId(), msgBodyBytes);
				packageData.setMessageBody(messageBody);
				packageData.setFullPkg(true);//标记数据包完整
			}
			//校验码
			int checkSumInPkg = data[data.length - 1];
			int calculatedCheckSum = BitOperator.getCheckSum4JT808(data, 0, data.length - 1);
			packageData.setCheckSum(checkSumInPkg);
			//验证校验码
	 		if(checkSumInPkg != calculatedCheckSum){
				logger.warn("检验码不一致,msgid:"+msgHeader.getMsgId()+" checkSumInPkg:"+checkSumInPkg+" calculatedCheckSum:"+calculatedCheckSum);
			}
	 		//记录设备报文
			carDeviceService.recordEquPkgLog(packageData.getMsgHeader().getTerminalPhone(), Constant.pkg_direct_up, "7e"+HexStringUtils.toHexString(data)+"7e");
		} catch (Exception e) {
			logger.error("协议包解码异常：", e);
		}
		return packageData;
	}
	
	
	/**
	 * 从报文解析消息头
	 * @param data
	 * @return
	 */
	private MsgHeader parseMsgHeaderFromBytes(byte[] data) {
		MsgHeader msgHeader = new MsgHeader();
		//1. 消息ID word(16)
		msgHeader.setMsgId(this.parseIntFromBytes(data, 0, 2));
		//2. 消息体属性 word(16)
		int msgBodyProps = this.parseIntFromBytes(data, 2, 2);
		msgHeader.setMsgBodyProps(msgBodyProps);
		//[ 0-9 ]bit  0000,0011,1111,1111(3FF)(消息体长度)
		msgHeader.setMsgBodyLength(msgBodyProps & 0x3ff);
		//[10-12]bit 0001,1100,0000,0000(1C00)(加密类型)
		msgHeader.setEncryptionType((msgBodyProps & 0x1C00) >> 10);
		//[ 13 ]bit 0010,0000,0000,0000(2000)(是否有子包)
		msgHeader.setHasSubPackage(((msgBodyProps & 0x2000) >> 13) == 1);
		//[14-15]bit 1100,0000,0000,0000(C000)(保留位)
		msgHeader.setReservedBit(((msgBodyProps & 0xc000) >> 14));
		//3. 终端手机号 bcd[6]
		msgHeader.setTerminalPhone(this.parseBcdStringFromBytes(data, 4, 6));
		//4. 消息流水号 word(16) 按发送顺序从 0 开始循环累加
		msgHeader.setFlowId(this.parseIntFromBytes(data, 10, 2));
		// 5. 消息包封装项
		if(msgHeader.isHasSubPackage()){
			//消息包封装项
			//byte[0-1] 消息包总数(word(16))
			msgHeader.setTotalSubPackage(this.parseIntFromBytes(data, 12, 2));
			//byte[2-3] 包序号(word(16)) 从 1 开始
			msgHeader.setSubPackageSeq(this.parseIntFromBytes(data, 14, 2));
		}
		return msgHeader;
	}
	
	/**
	 * 字节数组中截取对应的内容
	 * @param data 字节数组
	 * @param startIndex 开始索引
	 * @param length 截取字节长度
	 * @return
	 */
	private int parseIntFromBytes(byte[] data, int startIndex, int length) {
		return this.parseIntFromBytes(data, startIndex, length, 0);
	}

	private int parseIntFromBytes(byte[] data, int startIndex, int length, int defaultVal) {
		try {
			// 字节数大于4,从起始索引开始向后处理4个字节,其余超出部分丢弃
			final int len = length > 4 ? 4 : length;
			byte[] tmp = new byte[len];
			System.arraycopy(data, startIndex, tmp, 0, len);
			return BitOperator.byteToInteger(tmp);
		} catch (Exception e) {
			logger.error("解析整数出错:", e);
			return defaultVal;
		}
	}
	
	/**
	 * BCD 8421码
	 * @param data
	 * @param startIndex
	 * @param lenth
	 * @return
	 */
	private String parseBcdStringFromBytes(byte[] data, int startIndex, int lenth) {
		return this.parseBcdStringFromBytes(data, startIndex, lenth, null);
	}

	private String parseBcdStringFromBytes(byte[] data, int startIndex, int lenth, String defaultVal) {
		try {
			byte[] tmp = new byte[lenth];
			System.arraycopy(data, startIndex, tmp, 0, lenth);
			return BCD8421Operater.bcd2String(tmp);
		} catch (Exception e) {
			logger.error("解析BCD(8421码)出错:", e);
			return defaultVal;
		}
	}
	
}
