package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPassThroughMessage;
import com.neoway.car.device.bean.IReadMessageBody;
import com.neoway.car.device.bean.PassThroughMessageFactory;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: OBD数据上行透传
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/16 15:48
 */
public class JT_0900 implements IReadMessageBody {

    /**
     * 数据上行透传消息数据体
     */
    IPassThroughMessage passThroughMessage;

    @Override
    public void readFromBytes(byte[] messageBodyBytes) {
        ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
        int messageId = in.readUnsignedByte();
        // 拷贝除消息id之外的字节
        int len = messageBodyBytes.length - 1;
        byte[] temp = new byte[len];
        System.arraycopy(messageBodyBytes, 1, temp, 0, len);
        IPassThroughMessage passThroughMessage = PassThroughMessageFactory.getPassThroughMessage(messageId, temp);
        setPassThroughMessage(passThroughMessage);
    }

    public IPassThroughMessage getPassThroughMessage() {
        return passThroughMessage;
    }

    public void setPassThroughMessage(IPassThroughMessage passThroughMessage) {
        this.passThroughMessage = passThroughMessage;
    }
}
