package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPassThroughMessage;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: 行程结束（熄火/休眠前发送）
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/16 16:54
 */
public class PassThroughMessage_F2 implements IPassThroughMessage {
    /**
     * 时间, BCD[6]  (48bit)
     * YY-MM-DD-hh-mm-ss（GMT+8时间，本标准中之后涉及的时间均采用此时区）
     */
    private String time;

    /**
     * 状态位（bit0:0北纬，1南纬；bit1:0东经，1西经）
     */
    private short state;

    /**
     * 纬度,DWord(32bit)
     * 以度为单位的纬度值乘以10的6次方，精确到百万分之一度
     */
    private long latitude;

    /**
     * 经度,DWord(32bit)
     * 以度为单位的经度值乘以10的6次方，精确到百万 分之一度
     */
    private long longitude;

    @Override
    public int getMessageId() {
        return 0xF2;
    }

    @Override
    public byte getMessageLength() {
        return 15;
    }

    @Override
    public byte[] writeToBytes() {
        return null;
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        StringBuilder timeBuilder = new StringBuilder();
        byte[] timeBytes = new byte[6];
        in.readBytes(timeBytes, 0, 6);
        timeBuilder.append("20")
                .append(String.format("%02X", timeBytes[0]))
                .append("-")
                .append(String.format("%02X", timeBytes[1]))
                .append("-")
                .append(String.format("%02X", timeBytes[2]))
                .append(" ")
                .append(String.format("%02X", timeBytes[3]))
                .append(":")
                .append(String.format("%02X", timeBytes[4]))
                .append(":")
                .append(String.format("%02X", timeBytes[5]));
        setTime(timeBuilder.toString());
        setState(in.readUnsignedByte());
        setLatitude(in.readUnsignedInt());
        setLongitude(in.readUnsignedInt());
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public long getLatitude() {
        return latitude;
    }

    public void setLatitude(long latitude) {
        this.latitude = latitude;
    }

    public long getLongitude() {
        return longitude;
    }

    public void setLongitude(long longitude) {
        this.longitude = longitude;
    }

    public short getState() {
        return state;
    }

    public void setState(short state) {
        this.state = state;
    }
}
