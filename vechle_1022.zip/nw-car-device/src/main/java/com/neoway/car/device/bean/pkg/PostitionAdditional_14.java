/**
 * @company 有方物联
 * @file PostitionAdditional_14.java
 * @author guojy
 * @date 2018年7月2日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :视频相关报警
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月2日
 */
public class PostitionAdditional_14 implements IPositionAdditionalItem {
	/**
	 * 视频信号丢失报警 0位
	 */
	private byte loss;
	/**
	 * 视频信号遮挡报警 1位
	 */
	private byte cover;
	/**
	 * 存储单元故障报警 2位
	 */
	private byte storeFault;
	/**
	 * 其他视频设备故障报警 3位
	 */
	private byte otherFault;
	/**
	 * 客车超员报警 4位
	 */
	private byte overman;
	/**
	 * 异常驾驶行为报警 5位
	 */
	private byte abnormalDriving;
	/**
	 * 特殊报警录像达到阈值报警 6位
	 */
	private byte videoThreshold;
	
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x14;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x4;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		long state = in.readUnsignedInt();
		
		this.setLoss(convert(state, 0));
		this.setCover(convert(state, 1));
		this.setStoreFault(convert(state, 2));
		this.setOtherFault(convert(state, 3));
		this.setOverman(convert(state, 4));
		this.setAbnormalDriving(convert(state, 5));
		this.setVideoThreshold(convert(state, 6));
	}
	
	protected static byte convert(long state, int pos){
	    return (byte)(state >> pos & 1);
	}

	/**
	 * @return the loss
	 */
	public byte getLoss() {
		return loss;
	}

	/**
	 * @param loss the loss to set
	 */
	public void setLoss(byte loss) {
		this.loss = loss;
	}

	/**
	 * @return the cover
	 */
	public byte getCover() {
		return cover;
	}

	/**
	 * @param cover the cover to set
	 */
	public void setCover(byte cover) {
		this.cover = cover;
	}

	/**
	 * @return the storeFault
	 */
	public byte getStoreFault() {
		return storeFault;
	}

	/**
	 * @param storeFault the storeFault to set
	 */
	public void setStoreFault(byte storeFault) {
		this.storeFault = storeFault;
	}

	/**
	 * @return the otherFault
	 */
	public byte getOtherFault() {
		return otherFault;
	}

	/**
	 * @param otherFault the otherFault to set
	 */
	public void setOtherFault(byte otherFault) {
		this.otherFault = otherFault;
	}

	/**
	 * @return the overman
	 */
	public byte getOverman() {
		return overman;
	}

	/**
	 * @param overman the overman to set
	 */
	public void setOverman(byte overman) {
		this.overman = overman;
	}

	/**
	 * @return the abnormalDriving
	 */
	public byte getAbnormalDriving() {
		return abnormalDriving;
	}

	/**
	 * @param abnormalDriving the abnormalDriving to set
	 */
	public void setAbnormalDriving(byte abnormalDriving) {
		this.abnormalDriving = abnormalDriving;
	}

	/**
	 * @return the videoThreshold
	 */
	public byte getVideoThreshold() {
		return videoThreshold;
	}

	/**
	 * @param videoThreshold the videoThreshold to set
	 */
	public void setVideoThreshold(byte videoThreshold) {
		this.videoThreshold = videoThreshold;
	}

	
}
