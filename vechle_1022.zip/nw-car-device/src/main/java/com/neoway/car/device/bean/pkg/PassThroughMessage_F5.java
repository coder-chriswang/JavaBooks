package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPassThroughMessage;
import com.neoway.util.hex.BCD8421Operater;
import com.neoway.util.hex.BitOperator;
import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 *  描述: 扩展终端属性消息
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/17 13:56
 */
@Slf4j
public class PassThroughMessage_F5 implements IPassThroughMessage {

    /**
     * 通信模块版本号长度
     */
    private short communicationModuleVersionLength;

    /**
     * 通信模块版本号
     */
    private String communicationModuleVersion;

    /**
     * 终端软件版本号长度
     */
    private short terminalSoftwareVersionLength;

    /**
     * 终端软件版本号
     */
    private String terminalSoftwareVersion;

    /**
     * 总线协议类型长度
     */
    private short busProtocolTypeLength;

    /**
     * 总线协议类型
     */
    private String busProtocolType;

    /**
     * VIN码 17个字节
     */
    private String vin;

    /**
     * ICCID 20个字节
     */
    private String iccId;

    /**
     * IMSI 15个字节
     */
    private String imsi;

    /**
     * GSM IMEI 15个字节
     */
    private String gsmImei;


    @Override
    public int getMessageId() {
        return 0xF5;
    }

    @Override
    public byte getMessageLength() {
        return (byte) (70 + getCommunicationModuleVersionLength() + getTerminalSoftwareVersionLength() + getBusProtocolTypeLength());
    }

    @Override
    public byte[] writeToBytes() {
        return null;
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        short cmLength = (short) parseIntFromBytes(bytes, 0, 1);
        log.info("通讯模块长度={}", cmLength);
        setCommunicationModuleVersionLength(cmLength);
        setCommunicationModuleVersion(parseBcdStringFromBytes(bytes, 1, cmLength));
        short tsvlength = (short) parseIntFromBytes(bytes,1 + cmLength, 1);
        log.info("终端软件版本长度={}", tsvlength);
        setTerminalSoftwareVersionLength(tsvlength);
        setTerminalSoftwareVersion(parseBcdStringFromBytes(bytes, 2 + cmLength, tsvlength));
        short busLength = (short) parseIntFromBytes(bytes, 2 + cmLength + tsvlength, 1);
        log.info("总线协议类型长度={}", busLength);
        setBusProtocolTypeLength(busLength);
        setBusProtocolType(parseBcdStringFromBytes(bytes, 3 + cmLength + tsvlength, busLength));
        setVin(parseBcdStringFromBytes(bytes, 3 + cmLength + tsvlength + busLength, 17));
        setIccId(parseBcdStringFromBytes(bytes, 20 + cmLength + tsvlength + busLength, 20));
        setImsi(parseBcdStringFromBytes(bytes, 40 + cmLength + tsvlength + busLength, 15));
        setGsmImei(parseBcdStringFromBytes(bytes, 55 + cmLength + tsvlength + busLength, 15));
    }

    private String parseBcdStringFromBytes(byte[] data, int startIndex, int length) {
        try {
            byte[] tmp = new byte[length];
            System.arraycopy(data, startIndex, tmp, 0, length);
            return new String(tmp);
        } catch (Exception e) {
            log.error("解析BCD(8421码)出错:", e);
            return null;
        }
    }

    private int parseIntFromBytes(byte[] data, int startIndex, int length) {
        try {
            // 字节数大于4,从起始索引开始向后处理4个字节,其余超出部分丢弃
            int len = length > 4 ? 4 : length;
            byte[] tmp = new byte[len];
            System.arraycopy(data, startIndex, tmp, 0, len);
            return BitOperator.byteToInteger(tmp);
        } catch (Exception e) {
            log.error("解析整数出错:", e);
            return 0;
        }
    }

    public short getCommunicationModuleVersionLength() {
        return communicationModuleVersionLength;
    }

    public void setCommunicationModuleVersionLength(short communicationModuleVersionLength) {
        this.communicationModuleVersionLength = communicationModuleVersionLength;
    }

    public String getCommunicationModuleVersion() {
        return communicationModuleVersion;
    }

    public void setCommunicationModuleVersion(String communicationModuleVersion) {
        this.communicationModuleVersion = communicationModuleVersion;
    }

    public short getTerminalSoftwareVersionLength() {
        return terminalSoftwareVersionLength;
    }

    public void setTerminalSoftwareVersionLength(short terminalSoftwareVersionLength) {
        this.terminalSoftwareVersionLength = terminalSoftwareVersionLength;
    }

    public String getTerminalSoftwareVersion() {
        return terminalSoftwareVersion;
    }

    public void setTerminalSoftwareVersion(String terminalSoftwareVersion) {
        this.terminalSoftwareVersion = terminalSoftwareVersion;
    }

    public short getBusProtocolTypeLength() {
        return busProtocolTypeLength;
    }

    public void setBusProtocolTypeLength(short busProtocolTypeLength) {
        this.busProtocolTypeLength = busProtocolTypeLength;
    }

    public String getBusProtocolType() {
        return busProtocolType;
    }

    public void setBusProtocolType(String busProtocolType) {
        this.busProtocolType = busProtocolType;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getIccId() {
        return iccId;
    }

    public void setIccId(String iccId) {
        this.iccId = iccId;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getGsmImei() {
        return gsmImei;
    }

    public void setGsmImei(String gsmImei) {
        this.gsmImei = gsmImei;
    }
}
