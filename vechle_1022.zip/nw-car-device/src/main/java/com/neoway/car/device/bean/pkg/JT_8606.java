/**
 * @company 有方物联
 * @file JT_8606.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 设置路线
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8606 implements IWriteMessageBody {
	/**
	 * 路线ID DWORD
	 */
	private long lineId;

	/**
	 * 路线属性 WORD 808协议表67
	 */
	private int lineAttr;

	/**
	 * 起始时间 BCD[6] 区域属性0位为0则没有该字段
	 */
	private String startTime;

	/**
	 * 结束时间 BCD[6] 区域属性0位为0则没有该字段
	 */
	private String endTime;

	/**
	 * 路线总拐点数 WORD
	 */
	private int pointNum;

	/**
	 * 拐点项 808协议表68
	 */
	private List<Item> itemList;

	@Override
	public byte[] writeToBytes() {
		int size = 8;
		int timeFlag = lineAttr & 0x1;//0000 0000 0000 0001
		if(timeFlag ==1){
			size += 12;
		}
		//TODO优化性能
		int itemSize = 18;
		if(this.getPointNum() > 0){
			for(Item item:itemList){
				int roadAttr = item.getRoadAttr();
				int timeFlag_ = roadAttr & 0x1;//0000 0000 0000 0001
				if(timeFlag_ == 1){
					itemSize += 4;
				}
				int speedFlag_ = roadAttr >> 1 & 0x1;//0000 0000 0000 0010
				if(speedFlag_ == 1){
					itemSize += 3;
				}
			}
		}
		
		ByteBuf in = Unpooled.buffer(size+itemSize);
		in.writeInt(Long.valueOf(this.getLineId()).intValue());
		in.writeShort(this.getLineAttr());
		if(timeFlag ==1){
			//0位为1
			in.writeByte(Byte.parseByte(this.getStartTime().substring(0, 2),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(2, 4),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(4, 6),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(6, 8),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(8, 10),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(10, 12),16));
			
			in.writeByte(Byte.parseByte(this.getEndTime().substring(0, 2),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(2, 4),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(4, 6),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(6, 8),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(8, 10),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(10, 12),16));
		}
		in.writeShort(this.getPointNum());
		if(this.getPointNum() > 0){
			for(Item item:itemList){
				in.writeInt(Long.valueOf(item.getInflexId()).intValue());
				in.writeInt(Long.valueOf(item.getRoadId()).intValue());
				in.writeInt(Long.valueOf(item.getLat()).intValue());
				in.writeInt(Long.valueOf(item.getLng()).intValue());
				in.writeByte(item.getRoadWide());
				in.writeByte(item.getRoadAttr());
				int roadAttr = item.getRoadAttr();
				int timeFlag_ = roadAttr & 0x1;//0000 0000 0000 0001
				if(timeFlag_ == 1){
					in.writeShort(item.getTooLong());
					in.writeShort(item.getTooShort());
				}
				int speedFlag_ = roadAttr >> 1 & 0x1;//0000 0000 0000 0010
				if(speedFlag_ == 1){
					in.writeShort(item.getSpeed());
					in.writeByte(item.getDuration());
				}
			}
		}
		return null;
	}

	/**
	 * @description :拐点项
	 * @author : guojy
	 * @version : V1.0.0
	 * @date : 2018年5月7日
	 */
	public class Item {

		/**
		 * 拐点ID DWORD
		 */
		private long inflexId;

		/**
		 * 路段ID DWORD
		 */
		private long roadId;

		/**
		 * 拐点纬度 DWORD
		 */
		private long lat;

		/**
		 * 拐点经度 DWORD
		 */
		private long lng;

		/**
		 * 路段宽度 BYTE
		 */
		private short roadWide;

		/**
		 * 路段属性 BYTE 说明见808协议 表-69 0：1.行驶时间 1：1.限速 2：0.北纬 1.南纬 3：0.东经 1.西经
		 * 4-7：保留
		 */
		private short roadAttr;

		/**
		 * 路段行驶过长阈值（s） WORD 路段属性0位为0则没有该字段
		 */
		private int tooLong;

		/**
		 * 路段行驶不足阈值（s） WORD 路段属性0位为0则没有该字段
		 */
		private int tooShort;

		/**
		 * 路段最高速度 WORD 路段属性1位为0则没有该字段
		 */
		private int speed;

		/**
		 * 路段超速持续时间 BYTE 路段属性1位为0则没有该字段
		 */
		private short duration;

		/**
		 * @return the inflexId
		 */
		public long getInflexId() {
			return inflexId;
		}

		/**
		 * @param inflexId the inflexId to set
		 */
		public void setInflexId(long inflexId) {
			this.inflexId = inflexId;
		}

		/**
		 * @return the roadId
		 */
		public long getRoadId() {
			return roadId;
		}

		/**
		 * @param roadId the roadId to set
		 */
		public void setRoadId(long roadId) {
			this.roadId = roadId;
		}

		/**
		 * @return the lat
		 */
		public long getLat() {
			return lat;
		}

		/**
		 * @param lat the lat to set
		 */
		public void setLat(long lat) {
			this.lat = lat;
		}

		/**
		 * @return the lng
		 */
		public long getLng() {
			return lng;
		}

		/**
		 * @param lng the lng to set
		 */
		public void setLng(long lng) {
			this.lng = lng;
		}

		/**
		 * @return the roadWide
		 */
		public short getRoadWide() {
			return roadWide;
		}

		/**
		 * @param roadWide the roadWide to set
		 */
		public void setRoadWide(short roadWide) {
			this.roadWide = roadWide;
		}

		/**
		 * @return the roadAttr
		 */
		public short getRoadAttr() {
			return roadAttr;
		}

		/**
		 * @param roadAttr the roadAttr to set
		 */
		public void setRoadAttr(short roadAttr) {
			this.roadAttr = roadAttr;
		}

		/**
		 * @return the tooLong
		 */
		public int getTooLong() {
			return tooLong;
		}

		/**
		 * @param tooLong the tooLong to set
		 */
		public void setTooLong(int tooLong) {
			this.tooLong = tooLong;
		}

		/**
		 * @return the tooShort
		 */
		public int getTooShort() {
			return tooShort;
		}

		/**
		 * @param tooShort the tooShort to set
		 */
		public void setTooShort(int tooShort) {
			this.tooShort = tooShort;
		}

		/**
		 * @return the speed
		 */
		public int getSpeed() {
			return speed;
		}

		/**
		 * @param speed the speed to set
		 */
		public void setSpeed(int speed) {
			this.speed = speed;
		}

		/**
		 * @return the duration
		 */
		public short getDuration() {
			return duration;
		}

		/**
		 * @param duration the duration to set
		 */
		public void setDuration(short duration) {
			this.duration = duration;
		}
	}

	/**
	 * @return the lineId
	 */
	public long getLineId() {
		return lineId;
	}

	/**
	 * @param lineId the lineId to set
	 */
	public void setLineId(long lineId) {
		this.lineId = lineId;
	}

	/**
	 * @return the lineAttr
	 */
	public int getLineAttr() {
		return lineAttr;
	}

	/**
	 * @param lineAttr the lineAttr to set
	 */
	public void setLineAttr(int lineAttr) {
		this.lineAttr = lineAttr;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the pointNum
	 */
	public int getPointNum() {
		return pointNum;
	}

	/**
	 * @param pointNum the pointNum to set
	 */
	public void setPointNum(int pointNum) {
		this.pointNum = pointNum;
	}

	/**
	 * @return the itemList
	 */
	public List<Item> getItemList() {
		return itemList;
	}

	/**
	 * @param itemList the itemList to set
	 */
	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}
	
	
}
