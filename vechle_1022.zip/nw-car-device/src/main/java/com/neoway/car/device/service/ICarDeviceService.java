/**
 * @company 有方物联
 * @file ICarDeviceService.java
 * @author guojy
 * @date 2018年4月11日
 */
package com.neoway.car.device.service;

import com.neoway.car.device.bean.PackageData;
import io.netty.channel.ChannelHandlerContext;

/**
 * @description :设备接入业务接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public interface ICarDeviceService {
    /**
     *
     * @param equId 设备ID
     * @param deptId 部门ID
     * @param carId 车辆ID
     * @param carNum 车牌号
     */
    void equOffline(String equId,String deptId,String carId,String carNum);
    /**
     *
     * @param ctx
     * @param packageData
     */
    void register(ChannelHandlerContext ctx,PackageData packageData);
    /**
     *
     * @param ctx
     * @param packageData
     */
    void auth(ChannelHandlerContext ctx,PackageData packageData);
    /**
     * 终端心跳
     * @param ctx
     * @param packageData
     */
    void heart(ChannelHandlerContext ctx,PackageData packageData);
    /**
     *
     * @param ctx
     * @param packageData
     */
    void terminalCommResp(ChannelHandlerContext ctx,PackageData packageData);
    /**
     *
     * @param ctx
     * @param packageData
     */
    void localtionReport(ChannelHandlerContext ctx,PackageData packageData);

    /**
     *
     * @param ctx
     * @param packageData
     */
    void lastLocaltion(ChannelHandlerContext ctx,PackageData packageData);
    /**
     *
     * @param ctx
     * @param packageData
     */
    void termParamResp(ChannelHandlerContext ctx,PackageData packageData);
    /**
     *
     * @param ctx
     * @param packageData
     */
    void termPropResp(ChannelHandlerContext ctx,PackageData packageData);
    /**
     *
     * @param phone 终端手机号
     * @param direct 日志报文流向UP DOWN
     * @param content 报文内容
     */
    void recordEquPkgLog(String phone,String direct,String content);

    /**
     * 位置批量上传
     * @param ctx
     * @param packageData
     */
    void batchLocationReport(ChannelHandlerContext ctx, PackageData packageData);

    /**
     * 数据上行透传
     * @param ctx
     * @param packageData
     */
    void passThroughMessage(ChannelHandlerContext ctx, PackageData packageData);

    /**
     * 低功耗设备登录
     * @param ctx
     * @param packageData
     */
    void lowPowerLogin(ChannelHandlerContext ctx, PackageData packageData);

    /**
     * 低功耗设备上报位置信息
     * @param ctx
     * @param packageData
     */
    void lowPowerLocationReport(ChannelHandlerContext ctx, PackageData packageData);

    /**
     * 低功耗设备上报LBS扩展信息
     * @param ctx
     * @param packageData
     */
    void lowPowerLBSExtend(ChannelHandlerContext ctx, PackageData packageData);
}
