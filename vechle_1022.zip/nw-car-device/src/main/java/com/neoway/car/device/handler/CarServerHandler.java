/**
 * @company 有方物联
 * @file CarServerHandler.java
 * @author guojy
 * @date 2018年4月10日
 */
package com.neoway.car.device.handler;

import com.neoway.car.device.bean.PackageData;
import com.neoway.car.device.service.ICarDeviceService;
import com.neoway.car.device.util.Constant;
import com.neoway.car.device.util.DeviceManager;
import com.neoway.car.device.util.JT808Consts;
import com.neoway.car.device.util.SerialNumManager;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.ReferenceCountUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @description :JT808部标设备handler
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
@Sharable
@Component
public class CarServerHandler extends ChannelInboundHandlerAdapter {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    /**
     * 设备管理单例
     */
    private DeviceManager deviceManager;
    @Autowired
    private ICarDeviceService carDeviceService;
    /**
     *
     */
    public CarServerHandler() {
        this.deviceManager = DeviceManager.getInstance();
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        logger.info("设备连接:{}",ctx.channel().remoteAddress());
        super.channelActive(ctx);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        String equId = ctx.channel().attr(Constant.equId).get();
        String deptId = ctx.channel().attr(Constant.deptId).get();
        String carId = ctx.channel().attr(Constant.carId).get();
        String carNum = ctx.channel().attr(Constant.carNum).get();
        if(equId != null) {
            logger.info("设备断开，与平台离线,设备id={}",equId);
            deviceManager.removeByDeviceId(equId);
            ctx.channel().attr(Constant.equId).set(null);
            ctx.channel().attr(Constant.deptId).set(null);
            ctx.channel().attr(Constant.carId).set(null);
            ctx.channel().attr(Constant.carNum).set(null);
            // 设备离线状态更新
            carDeviceService.equOffline(equId,deptId,carId,carNum);
        } else{
            logger.info("非鉴权渠道连接的设备断开");
        }
        // 清除session
        SerialNumManager.getInstance().clearCtx(ctx);
        super.channelInactive(ctx);
        ctx.close();
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        PackageData packageData = (PackageData) msg;
        try{
            switch (packageData.getMsgHeader().getMsgId()) {
                case JT808Consts.msgid_terminal_commresp:
                    carDeviceService.terminalCommResp(ctx, packageData);
                    break;
                case JT808Consts.msgid_terminal_heart:
                    carDeviceService.heart(ctx, packageData);
                    break;
                case JT808Consts.msgid_terminal_register:
                    carDeviceService.register(ctx, packageData);
                    break;
                case JT808Consts.msgid_terminal_auth:
                    carDeviceService.auth(ctx, packageData);
                    break;
                case JT808Consts.msgid_terminal_localtionreport:
                    carDeviceService.localtionReport(ctx, packageData);
                    break;
                case JT808Consts.msgid_terminal_localtionresp:
                    carDeviceService.lastLocaltion(ctx, packageData);
                    break;
                case JT808Consts.msgid_terminal_paramsresp:
                    carDeviceService.termParamResp(ctx, packageData);
                    break;
                case JT808Consts.msgid_terminal_propsresp:
                    carDeviceService.termPropResp(ctx, packageData);
                    break;
                case JT808Consts.MSGID_TERMINAL_BATCH_REPORT:
                    carDeviceService.batchLocationReport(ctx, packageData);
                    break;
                case JT808Consts.MSGID_TERMINAL_PASSTHROUGH_REPORT:
                    carDeviceService.passThroughMessage(ctx, packageData);
                    break;
                case JT808Consts.MSGID_TERMINAL_LOW_POWER_LBS_EXTEND:
                    carDeviceService.lowPowerLBSExtend(ctx, packageData);
                    break;
                case JT808Consts.MSGID_TERMINAL_LOW_POWER_LOCATION_REPORT:
                    carDeviceService.lowPowerLocationReport(ctx, packageData);
                    break;
                case JT808Consts.MSGID_TERMINAL_LOW_POWER_LOGIN:
                    carDeviceService.lowPowerLogin(ctx, packageData);
                    break;
                default:
                    logger.error("消息非法:消息ID={},来源设备IP={}",packageData.getMsgHeader().getMsgId(),ctx.channel().remoteAddress());
                    break;
            }
        }finally {
            ReferenceCountUtil.release(msg);
        }

    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent event = (IdleStateEvent) evt;
            if (event.state() == IdleState.READER_IDLE) {
                String equId = ctx.channel().attr(Constant.equId).get();
                if (equId == null) {
                    logger.info("未鉴权的设备与平台之间长时间无通讯，主动离线！");
                } else {
                    logger.info("设备长时间无通讯，平台主动离线，设备id={}", equId);
                }
                SerialNumManager.getInstance().clearCtx(ctx);
                ctx.close();
            }
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("数据传输发生异常,来源设备IP={}", ctx.channel().remoteAddress());
        logger.error("数据传输发生异常！", cause);
        if(ctx != null){
            SerialNumManager.getInstance().clearCtx(ctx);
            ctx.close();
        }
    }
}
