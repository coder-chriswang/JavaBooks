package com.neoway.car.device.bean;

import com.neoway.util.hex.HexStringUtils;
import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 *  描述: OBD数据上行透传工厂类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/16 16:38
 */
@Slf4j
public class PassThroughMessageFactory {

    /**
     * 找寻透传信息类
     * @param messageId 透传消息id
     * @param messageBytes 消息体
     * @return
     */
    public static IPassThroughMessage getPassThroughMessage(int messageId,byte[] messageBytes){
        String nameSpace = JT808MessageFactory.class.getPackage().getName()+".pkg";
        String name = ".PassThroughMessage_"+ HexStringUtils.toHexString(messageId, 1).toUpperCase();
        String className = nameSpace + name;
        try {
            Class<?> cl = Class.forName(className);
            IPassThroughMessage passThroughMessage = (IPassThroughMessage) cl.newInstance();
            passThroughMessage.readFromBytes(messageBytes);
            return passThroughMessage;
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            log.error("不支持的OBD自定义数据上行透传消息");
        }
        return null;
    }
}
