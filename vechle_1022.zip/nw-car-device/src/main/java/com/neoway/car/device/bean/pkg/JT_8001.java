/**
 * @company 有方物联
 * @file JT_8001.java
 * @author guojy
 * @date 2018年4月12日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :平台通用应答
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月12日
 */
public class JT_8001 implements IWriteMessageBody {
	/**
	 * 应答流水号 word(16bit)  
	 * 对应的平台消息的流水号
	 */
	private int respFlowId;
	
	/**
	 * 应答消息ID word(16bit) 
	 * 对应的平台消息的ID
	 */
	private int respMsgId;
	
	/**
	 * 结果  byte(8bit)
	 * 0：成功/确认；1：失败；2：消息有误；3：不支持
	 */
	private short respResult;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IMessageBody#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		//5字节
		ByteBuf in = Unpooled.buffer(5);
		in.writeShort(this.getRespFlowId());
		in.writeShort(this.getRespMsgId());
		in.writeByte(this.getRespResult());
		return in.array();
	}

	/**
	 * @return the respFlowId
	 */
	public int getRespFlowId() {
		return respFlowId;
	}

	/**
	 * @param respFlowId the respFlowId to set
	 */
	public void setRespFlowId(int respFlowId) {
		this.respFlowId = respFlowId;
	}

	/**
	 * @return the respMsgId
	 */
	public int getRespMsgId() {
		return respMsgId;
	}

	/**
	 * @param respMsgId the respMsgId to set
	 */
	public void setRespMsgId(int respMsgId) {
		this.respMsgId = respMsgId;
	}

	/**
	 * @return the respResult
	 */
	public short getRespResult() {
		return respResult;
	}

	/**
	 * @param respResult the respResult to set
	 */
	public void setRespResult(short respResult) {
		this.respResult = respResult;
	}

	
}
