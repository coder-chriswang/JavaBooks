package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.nio.Buffer;

/**
 * <pre>
 *  描述: OBD扩展状态位
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/03 20:04
 */
public class PostitionAdditional_F1 implements IPositionAdditionalItem {

    /**
     * 扩展状态位
     */
    private long extendState;

    @Override
    public int getAdditionalId() {
        return 0xF1;
    }

    @Override
    public byte getAdditionalLength() {
        return 0x4;
    }

    @Override
    public byte[] writeToBytes() {
        ByteBuf in = Unpooled.buffer(4);
        in.writeInt(Long.valueOf(getExtendState()).intValue());
        return in.array();
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        setExtendState(in.readUnsignedInt());
    }

    public long getExtendState() {
        return extendState;
    }

    public void setExtendState(long extendState) {
        this.extendState = extendState;
    }
}
