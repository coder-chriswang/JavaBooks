package com.neoway.car.device.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Maps;
import com.neoway.car.device.bean.IPassThroughMessage;
import com.neoway.car.device.bean.IPositionAdditionalItem;
import com.neoway.car.device.bean.PackageData;
import com.neoway.car.device.bean.codec.JT808Encoder;
import com.neoway.car.device.bean.pkg.*;
import com.neoway.car.device.service.ICarDeviceService;
import com.neoway.car.device.util.*;
import com.neoway.util.DateUtil;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @description :设备接入业务服务默认实现
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
@Service
@Slf4j
public class CarDeviceServiceImpl implements ICarDeviceService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private JT808Encoder jT808Encoder;
    /**
     * 设备管理单例
     */
    private DeviceManager deviceManager = DeviceManager.getInstance();

    @Override
    public void register(ChannelHandlerContext ctx, PackageData packageData) {
        String phone = packageData.getMsgHeader().getTerminalPhone();
        JT_0100 jt0101 = (JT_0100) packageData.getMessageBody();
        Map<String,String> regMap = Maps.newHashMap();
        regMap.put("phone", phone);
        regMap.put("madeId", jt0101.getManufactureId());
        regMap.put("deviceType", jt0101.getTerminalModelNo());
        regMap.put("deviceId", jt0101.getTerminalId());
        regMap.put("cpys", String.valueOf(jt0101.getPlateColor()));
        regMap.put("clbs", jt0101.getLicenseNo());
        Object resultObj = rabbitTemplate.convertSendAndReceive("car_register", "jt808", JsonTools.toJsonStr(regMap));
        Map<String,String> resultMap = JsonTools.toMap(String.valueOf(resultObj));
        JT_8100 jT_8100 = new JT_8100();
        short result = Short.parseShort(resultMap.get("result"));
        jT_8100.setRespResult(result);
        jT_8100.setRespFlowId(packageData.getMsgHeader().getFlowId());
        if(result == 0){
            jT_8100.setAuthCode(resultMap.get("authCode"));
        }
        int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
        try {
            byte[] respBytes = jT808Encoder.encodePackage(phone, jT_8100, flowId, JT808Consts.msgid_plantform_registerresp);
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
            logger.info("终端（手机号={} 注册结果={}）", phone,resultObj.toString());
        } catch (Exception e) {
            logger.error("终端（手机号={}）注册应答消息编码异常！ 异常信息={}", phone,e.getMessage());
        }
    }


    @Override
    public void auth(ChannelHandlerContext ctx, PackageData packageData) {
        String phone = packageData.getMsgHeader().getTerminalPhone();
        JT_0102 jt0102 = (JT_0102) packageData.getMessageBody();
        Map<String,String> authMap = Maps.newHashMap();
        authMap.put("authCode", jt0102.getAuthCode());
        authMap.put("phone", phone);
        Object result = rabbitTemplate.convertSendAndReceive("car_auth", "jt808", JsonTools.toJsonStr(authMap));
        if(result != null){
            Map<String,String> resultMap = JsonTools.toMap(result.toString());
            plantformCommResp(ctx, packageData, Short.parseShort(resultMap.get("result")),"鉴权");
            if("0".equals(resultMap.get("result"))){
                ctx.channel().attr(Constant.carId).set(resultMap.get("carId"));
                ctx.channel().attr(Constant.equId).set(resultMap.get("equId"));
                ctx.channel().attr(Constant.carNum).set(resultMap.get("carNum"));
                ctx.channel().attr(Constant.deptId).set(resultMap.get("deptId"));
                deviceManager.put(resultMap.get("equId"), ctx);
                Map<String,String> taskMap = Maps.newHashMap();
                taskMap.put("equId", resultMap.get("equId"));
                logger.info("=========================================================================================================================================");
                logger.info("equId={},carId={}",resultMap.get("equId"),resultMap.get("carId"));
                logger.info("carNum={},deptId={}",resultMap.get("carNum"),resultMap.get("deptId"));
                logger.info("=========================================================================================================================================");
                rabbitTemplate.convertAndSend("carOfflineTask", null, JsonTools.toJsonStr(taskMap));
            }
            logger.info("终端（手机号={} 鉴权结果={}）", phone,result.toString());
        }
    }


    @Override
    public void heart(ChannelHandlerContext ctx, PackageData packageData) {
        String equId = ctx.channel().attr(Constant.equId).get();
        if(equId == null || "".equals(equId)){
            logger.info("设备已离线,设备id={}", equId);
            SerialNumManager.getInstance().clearCtx(ctx);
            ctx.close();
            return;
        }
        log.info("设备发送心跳包，设备id={}", equId);
        // 下发平台通用应答
        plantformCommResp(ctx, packageData, Short.valueOf("0"),"心跳");
    }

    /**
     *
     * @param ctx 通道上下文
     * @param packageData 包
     * @param result 应答结果
     * @param errDesc 异常描述
     */
    private void plantformCommResp(ChannelHandlerContext ctx,PackageData packageData,short result,String errDesc){
        String phone = packageData.getMsgHeader().getTerminalPhone();
        JT_8001 jT_8001 = new JT_8001();
        jT_8001.setRespFlowId(packageData.getMsgHeader().getFlowId());
        jT_8001.setRespMsgId(packageData.getMsgHeader().getMsgId());
        jT_8001.setRespResult(result);
        int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
        try {
            byte[] respBytes = jT808Encoder.encodePackage(phone, jT_8001, flowId, JT808Consts.msgid_plantform_commresp);
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
        } catch (Exception e) {
            errDesc = errDesc==null?"平台通用":errDesc;
            logger.error("终端（手机号={}）{}应答消息编码异常！ 异常信息={}", phone,errDesc,e.getMessage());
        }
    }

    private void lowPowerPlatformCommonResp(ChannelHandlerContext ctx, PackageData packageData, Map<String, String> resultMap, String errDesc) {
        String phone = packageData.getMsgHeader().getTerminalPhone();
        String resultStr = resultMap.get("result");
        int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
        JT_8150 jt8150 = new JT_8150();
        jt8150.setRespFlowId(packageData.getMsgHeader().getFlowId());
        jt8150.setRespMsgId(packageData.getMsgHeader().getMsgId());
        // 未开启追踪模式
        if ("false".equals(resultStr)) {
            jt8150.setParamCnt(Short.valueOf("1"));
            jt8150.setRespResult(Short.valueOf("0"));
            List<JT_8150.ParamItem> list = new ArrayList<>(1);
            JT_8150.ParamItem paramItem09 = jt8150.new ParamItem();
            paramItem09.setParamId(0x09);
            paramItem09.setParamVal(0);
            list.add(paramItem09);
            jt8150.setParamList(list);
        }
        // 开启追踪模式，返回追踪间隔（0s表示停止）
        else {
            jt8150.setRespResult(Short.valueOf("0"));
            jt8150.setParamCnt(Short.valueOf("1"));
            int flowInterval = Integer.valueOf(resultMap.get("flowInterval"));
            List<JT_8150.ParamItem> list = new ArrayList<>(1);
            JT_8150.ParamItem paramItem09 = jt8150.new ParamItem();
            paramItem09.setParamId(0x09);
            paramItem09.setParamVal(flowInterval);
            list.add(paramItem09);
            jt8150.setParamList(list);
        }
        try {
            byte[] respBytes = jT808Encoder.encodePackage(phone, jt8150, flowId, JT808Consts.MSGID_LOW_POWER_PLANTFORM_COMMRESP);
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
        } catch (Exception e) {
            errDesc = errDesc==null?"平台通用":errDesc;
            logger.error("终端（手机号={}）{}应答消息编码异常！ 异常信息={}", phone, errDesc,e.getMessage());
        }
    }

    /**
     * 增加低功耗LBS应答
     * @param ctx
     * @param packageData
     * @param errDesc
     */
    private void lowPowerLBSResp(ChannelHandlerContext ctx, PackageData packageData, String errDesc) {
        String phone = packageData.getMsgHeader().getTerminalPhone();
        int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
        JT_8150 jt8150 = new JT_8150();
        jt8150.setRespFlowId(packageData.getMsgHeader().getFlowId());
        jt8150.setRespMsgId(packageData.getMsgHeader().getMsgId());
        jt8150.setRespResult(Short.valueOf("0"));
        jt8150.setParamCnt(Short.valueOf("1"));
        List<JT_8150.ParamItem> list = new ArrayList<>(1);
        JT_8150.ParamItem paramItem09 = jt8150.new ParamItem();
        paramItem09.setParamId(0x09);
        paramItem09.setParamVal(0);
        list.add(paramItem09);
        jt8150.setParamList(list);
        try {
            byte[] respBytes = jT808Encoder.encodePackage(phone, jt8150, flowId, JT808Consts.MSGID_LOW_POWER_PLANTFORM_COMMRESP);
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
        } catch (Exception e) {
            logger.error("终端（手机号={}）{}应答消息编码异常！ 异常信息={}", phone, errDesc,e.getMessage());
        }
    }

    @Override
    public void terminalCommResp(ChannelHandlerContext ctx, PackageData packageData) {
        String equId = ctx.channel().attr(Constant.equId).get();
        if(equId == null || "".equals(equId)){
            logger.info("设备通用应答——设备已离线,设备id={}", equId);
            SerialNumManager.getInstance().clearCtx(ctx);
            ctx.close();
            return;
        }
        String phone = packageData.getMsgHeader().getTerminalPhone();
        JT_0001 jT0001 = (JT_0001) packageData.getMessageBody();
        Map<String,String> respMap = Maps.newHashMap();
        respMap.put("phone", phone);
        respMap.put("carId", ctx.channel().attr(Constant.carId).get());
        respMap.put("equId", ctx.channel().attr(Constant.equId).get());
        respMap.put("serialNum", String.valueOf(jT0001.getRespFlowId()));
        respMap.put("msgId", String.valueOf(jT0001.getRespMsgId()));
        respMap.put("result", String.valueOf(jT0001.getRespResult()));
        rabbitTemplate.convertAndSend("carDownCommandResp", null, JsonTools.toJsonStr(respMap));
    }


    @Override
    public void localtionReport(ChannelHandlerContext ctx, PackageData packageData) {
        String phone = packageData.getMsgHeader().getTerminalPhone();
        String equId = ctx.channel().attr(Constant.equId).get();
        if(equId == null || "".equals(equId)){
            logger.error("设备未鉴权或已离线,phone={},equId={}", phone, equId);
            SerialNumManager.getInstance().clearCtx(ctx);
            ctx.close();
            return;
        }
        logger.info("位置上报，phone={}, equId={}", phone, equId);
        JT_0200 jT0200= (JT_0200) packageData.getMessageBody();
        Map<String,String> reportMap = Maps.newHashMap();
        reportMap.put("phone", phone);
        reportMap.put("carId", ctx.channel().attr(Constant.carId).get());
        reportMap.put("carNum", ctx.channel().attr(Constant.carNum).get());
        reportMap.put("equId", ctx.channel().attr(Constant.equId).get());
        reportMap.put("deptId", ctx.channel().attr(Constant.deptId).get());
        reportMap.put("alarm", String.valueOf(jT0200.getAlarmFlag()));
        reportMap.put("state", String.valueOf(jT0200.getStatus()));
        reportMap.put("longitude", String.valueOf(jT0200.getLongitude()));
        reportMap.put("latitude", String.valueOf(jT0200.getLatitude()));
        reportMap.put("altitude", String.valueOf(jT0200.getAltitude()));
        reportMap.put("speed", String.valueOf(jT0200.getSpeed()/10.0));
        reportMap.put("direation", String.valueOf(jT0200.getCourse()));
        reportMap.put("gpsTime", String.valueOf(jT0200.getTime()));
        List<IPositionAdditionalItem> additionalList = jT0200.getAdditionals();
        for(IPositionAdditionalItem item : additionalList){
            switch (item.getAdditionalId()) {
                case JT808Consts.msgid_positionAdditional_mileage:
                    PostitionAdditional_01 mileage = (PostitionAdditional_01) item;
                    reportMap.put("mileage_additional", JSON.toJSONString(mileage));
                    break;
                case JT808Consts.msgid_positionAdditional_oilmass:
                    PostitionAdditional_02 oilmass = (PostitionAdditional_02) item;
                    reportMap.put("oilmass_additional", JSON.toJSONString(oilmass));
                    break;
                case JT808Consts.msgid_positionAdditional_speed:
                    PostitionAdditional_11 speed = (PostitionAdditional_11) item;
                    reportMap.put("speed_additional", JSON.toJSONString(speed));
                    break;
                case JT808Consts.msgid_positionAdditional_inoutarea:
                    PostitionAdditional_12 inoutArea = (PostitionAdditional_12) item;
                    reportMap.put("inoutarea_additional", JSON.toJSONString(inoutArea));
                    break;
                case JT808Consts.msgid_positionAdditional_driving:
                    PostitionAdditional_13 driving = (PostitionAdditional_13) item;
                    reportMap.put("driving_additional", JSON.toJSONString(driving));
                    break;
                case JT808Consts.msgid_positionAdditional_simSignal:
                    PostitionAdditional_30 simSignal = (PostitionAdditional_30) item;
                    reportMap.put("simSignal_additional", JSON.toJSONString(simSignal));
                    break;
                case JT808Consts.msgid_positionAdditional_satellitenum:
                    PostitionAdditional_31 satelliteNum = (PostitionAdditional_31) item;
                    reportMap.put("satelliteNum_additional", JSON.toJSONString(satelliteNum));
                    break;
                case JT808Consts.MSGID_PISITIONADDITIONAL_EXTENDALARMSTATE:
                    PostitionAdditional_F0 extendAlarmState = (PostitionAdditional_F0) item;
                    reportMap.put("extendAlarmState_additional", JSON.toJSONString(extendAlarmState));
                    break;
                case JT808Consts.MSGID_PISITIONADDITIONAL_EXTENDSTATE:
                    PostitionAdditional_F1 extendState = (PostitionAdditional_F1) item;
                    reportMap.put("extendState_additional", JSON.toJSONString(extendState));
                    break;
                case JT808Consts.MSGID_PISITIONADDITIONAL_CARVOLTAGE:
                    PostitionAdditional_F2 carVoltage = (PostitionAdditional_F2) item;
                    reportMap.put("carVoltage_additional", JSON.toJSONString(carVoltage));
                    break;
                case JT808Consts.MSGID_PISITIONADDITIONAL_TERMINALBATTERYVOLTAGE:
                    PostitionAdditional_F3 terminalBatteryVoltage = (PostitionAdditional_F3) item;
                    reportMap.put("terminalBatteryVoltage_additional", JSON.toJSONString(terminalBatteryVoltage));
                    break;
                case JT808Consts.MSGID_PISITIONADDITIONAL_CUSTOMDATA:
                    PostitionAdditional_F4 obdData = (PostitionAdditional_F4) item;
                    reportMap.put("obdData_additional", JSON.toJSONString(obdData));
                    break;
                default:
                    break;
            }
        }
        rabbitTemplate.convertAndSend("car_dataReport", "jt808", JsonTools.toJsonStr(reportMap));
        plantformCommResp(ctx, packageData, Short.valueOf("0"), "位置上报");
    }


    @Override
    public void equOffline(String equId,String deptId,String carId,String carNum) {
        Map<String,String> offlineMap = Maps.newHashMap();
        offlineMap.put("equId", equId);
        offlineMap.put("deptId", deptId);
        offlineMap.put("carId", carId);
        offlineMap.put("carNum", carNum);
        rabbitTemplate.convertAndSend("car_offline",null, JsonTools.toJsonStr(offlineMap));
    }


    @Override
    public void recordEquPkgLog(String phone, String direct, String content) {
        try {
            Map<String,String> pkgMap = Maps.newHashMap();
            pkgMap.put("phone", phone);
            pkgMap.put("direct", direct);
            pkgMap.put("content", content);
            pkgMap.put("collectTime", DateUtil.getSysStrCurrentDate(DateUtil.TIME_HAVINTERVAL_MILLIS));
            rabbitTemplate.convertAndSend("carEquPkgLog", null, JsonTools.toJsonStr(pkgMap));
        } catch (Exception e) {
            logger.error("记录设备上下行报文异常！",e);
        }
    }

    @Override
    public void batchLocationReport(ChannelHandlerContext ctx, PackageData packageData) {
        log.info("批量位置信息上报！");
        JT_0704 jt0704 = (JT_0704) packageData.getMessageBody();
        List<JT_0200> jt0200List = jt0704.getPositionList();
        for (JT_0200 jt0200 : jt0200List) {
            packageData.setMessageBody(jt0200);
            localtionReport(ctx, packageData);
        }
    }

    @Override
    public void passThroughMessage(ChannelHandlerContext ctx, PackageData packageData) {
        log.info("数据上行透传！");
        Map<String,String> messageMap = Maps.newHashMap();
        String carNum = ctx.channel().attr(Constant.carNum).get();
        String equId = ctx.channel().attr(Constant.equId).get();
        String phone = packageData.getMsgHeader().getTerminalPhone();
        if(equId == null || "".equals(equId)){
            logger.error("设备未鉴权或已离线,phone={},equId={}, carNum={}", phone, equId, carNum);
            SerialNumManager.getInstance().clearCtx(ctx);
            ctx.close();
            return;
        }
        messageMap.put("phone", phone);
        messageMap.put("equId", equId);
        messageMap.put("carNum", carNum);
        JT_0900 jt0900 = (JT_0900) packageData.getMessageBody();
        IPassThroughMessage passThroughMessage = jt0900.getPassThroughMessage();
        if (passThroughMessage == null) {
            logger.error("透传消息类型与协议不相符！phone={}, equId={}, carNum={}", phone, equId, carNum);
            return;
        }
        switch (passThroughMessage.getMessageId()) {
            case 0xF1 :
                PassThroughMessage_F1 passThroughMessageF1 = (PassThroughMessage_F1) passThroughMessage;
                log.info("行程开始数据");
                log.info("时间={},纬度={},经度={}", passThroughMessageF1.getTime(), passThroughMessageF1.getLatitude(), passThroughMessageF1.getLongitude());
                messageMap.put("startMarch", JSON.toJSONString(passThroughMessageF1));
                break;
            case 0xF2 :
                PassThroughMessage_F2 passThroughMessageF2 = (PassThroughMessage_F2) passThroughMessage;
                log.info("行程结束数据");
                log.info("时间={},纬度={},经度={}", passThroughMessageF2.getTime(), passThroughMessageF2.getLatitude(), passThroughMessageF2.getLongitude());
                messageMap.put("endMarch", JSON.toJSONString(passThroughMessageF2));
                break;
            case 0xF3 :
                PassThroughMessage_F3 passThroughMessageF3 = (PassThroughMessage_F3) passThroughMessage;
                log.info("行程报告");
                log.info("行程数据={}", passThroughMessageF3);
                messageMap.put("marchReport", JSON.toJSONString(passThroughMessageF3));
                break;
            case 0xF4 :
                PassThroughMessage_F4 passThroughMessageF4 = (PassThroughMessage_F4) passThroughMessage;
                log.info("故障码数据");
                log.info("故障码数据包={}", passThroughMessageF4);
                messageMap.put("troubleCode", JSON.toJSONString(passThroughMessageF4));
                break;
            case 0xF5 :
                PassThroughMessage_F5 passThroughMessageF5 = (PassThroughMessage_F5) passThroughMessage;
                log.info("扩展终端属性数据");
                log.info("扩展终端属性信息={}", passThroughMessageF5);
                messageMap.put("terminalParams", JSON.toJSONString(passThroughMessageF5));
                break;
            default:
                break;
        }
        log.info("数据上行透传消息至消息队列处理！");
        rabbitTemplate.convertAndSend("car_passThroughMessage", "jt808", JsonTools.toJsonStr(messageMap));
        // 增加通用应答
        plantformCommResp(ctx, packageData, Short.valueOf("0"), "数据上行透传消息");
    }

    @Override
    public void lowPowerLogin(ChannelHandlerContext ctx, PackageData packageData) {
        Map<String, String> dataMap = Maps.newHashMap();
        String phone = packageData.getMsgHeader().getTerminalPhone();
        JT_0101 jt0101 = (JT_0101) packageData.getMessageBody();
        String versionInfo = jt0101.getVersionInfo();
        logger.info("低功耗设备的版本信息为={}", versionInfo);
        String[] versions = versionInfo.split(";");
        dataMap.put("phone", phone);
        dataMap.put("update", versions[3]);
        // 发送消息队列返回登录结果
        Object result = rabbitTemplate.convertSendAndReceive("car_lowPower_login", "jt808", JsonTools.toJsonStr(dataMap));
        if (result != null) {
            Map<String, String> resultMap = JsonTools.toMap(result.toString());
            String loginResult = resultMap.get("loginResult");
            // 数据库存在此设备
            if("0".equals(loginResult)) {
                // 获取配置
                String config = resultMap.get("config");
                // 该低功耗设备配置信息不存在
                if (StringUtils.isBlank(config)) {
                    loginFailResponse(ctx, packageData, Short.valueOf("1"));
                    return;
                }
                // 处理配置信息下发
                handleConfig(config, ctx, packageData);
                ctx.channel().attr(Constant.equId).set(resultMap.get("equId"));
                ctx.channel().attr(Constant.carId).set(resultMap.get("carId"));
                ctx.channel().attr(Constant.deptId).set(resultMap.get("deptId"));
                ctx.channel().attr(Constant.carNum).set(resultMap.get("carNum"));
                deviceManager.put(resultMap.get("equId"), ctx);
                Map<String,String> taskMap = Maps.newHashMap();
                taskMap.put("equId", resultMap.get("equId"));
                rabbitTemplate.convertAndSend("carOfflineTask", null, JsonTools.toJsonStr(taskMap));
            } else {
                // 登录失败，平台回复响应
                logger.info("登录失败！设备唯一标识={}", phone);
                loginFailResponse(ctx, packageData, Short.valueOf("3"));
            }
        }
    }

    /**
     * 处理登录回复响应
     * @param config
     * @param ctx
     * @param packageData
     */
    private void handleConfig(String config, ChannelHandlerContext ctx, PackageData packageData) {
        Map<String, Object> configMap = JSON.parseObject(config, new TypeReference<Map<String, Object>>(){});
        short paramCount = 0;
        int teardownAlarmValue = 0;
        int lowBatteryAlarmValue = 0;
        int temperatureAlarmValue = 0;
        int shakeAlarmValue = 0;
        Integer fixedReportTime = null;
        String knockedReportTime = "";
        Integer shakeThreshold = null;
        Integer temperatureDetectCycle = null;
        Integer temperatureThreshold = null;
        Integer lowBatteryThreshold = null;
        String lowBatteryThresholdUnit = "";
        String updateInfo = "";
        Integer flowInterval = null;
        int alarm = 0;
        // MCU升级标志位
        int mcuSwitch = Integer.valueOf(String.valueOf(configMap.get("mcuSwitch")));
        // 追踪模式标志位
        int flowSwitch = Integer.valueOf(String.valueOf(configMap.get("flowSwitch")));
        // 基本数据信息
        if (configMap.get("fixedReportTime") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("fixedReportTime")))) {
            paramCount++;
            fixedReportTime = Integer.valueOf(String.valueOf(configMap.get("fixedReportTime")));
        }
        if (configMap.get("knockedReportTime") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("knockedReportTime")))) {
            paramCount++;
            knockedReportTime = String.valueOf(configMap.get("knockedReportTime"));
        }
        if (configMap.get("shakeThreshold") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("shakeThreshold")))) {
            paramCount++;
            shakeThreshold = Integer.valueOf(String.valueOf(configMap.get("shakeThreshold")));
        }
        if (configMap.get("temperatureDetectCycle") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("temperatureDetectCycle")))) {
            paramCount++;
            temperatureDetectCycle = Integer.valueOf(String.valueOf(configMap.get("temperatureDetectCycle")));
        }
        if (configMap.get("temperatureThreshold") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("temperatureThreshold")))) {
            paramCount++;
            temperatureThreshold = Integer.valueOf(String.valueOf(configMap.get("temperatureThreshold")));
        }
        if (configMap.get("lowBatteryThreshold") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("lowBatteryThreshold")))) {
            paramCount++;
            lowBatteryThreshold = Integer.valueOf(String.valueOf(configMap.get("lowBatteryThreshold")));
            // 低电压单位
            lowBatteryThresholdUnit = String.valueOf(configMap.get("lowBatteryThresholdUnit"));
        }
        if (configMap.get("updateInfo") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("updateInfo"))) && mcuSwitch == 1) {
            paramCount++;
            updateInfo = String.valueOf(configMap.get("updateInfo"));
        }
        if (configMap.get("flowInterval") != null && StringUtils.isNotBlank(String.valueOf(configMap.get("flowInterval"))) && flowSwitch == 1) {
            paramCount++;
            flowInterval = Integer.valueOf(String.valueOf(configMap.get("flowInterval")));
        }
        int teardownAlarm = Integer.valueOf(String.valueOf(configMap.get("teardownAlarm")));
        int lowBatteryAlarm = Integer.valueOf(String.valueOf(configMap.get("lowBatteryAlarm")));
        int temperatureAlarm = Integer.valueOf(String.valueOf(configMap.get("temperatureAlarm")));
        int shakeAlarm = Integer.valueOf(String.valueOf(configMap.get("shakeAlarm")));
        if (teardownAlarm != 0 || lowBatteryAlarm != 0 || temperatureAlarm != 0 || shakeAlarm != 0) {
            paramCount++;
        }
        if (teardownAlarm == 1) {
            teardownAlarmValue = 8;
        }
        if (lowBatteryAlarm == 1) {
            lowBatteryAlarmValue = 4;
        }
        if (temperatureAlarm == 1) {
            temperatureAlarmValue = 2;
        }
        if (shakeAlarm == 1) {
            shakeAlarmValue = 1;
        }
        alarm = teardownAlarmValue | lowBatteryAlarmValue | temperatureAlarmValue  | shakeAlarmValue;
        // 处理返回响应
        JT_8101 jt8101 = new JT_8101();
        jt8101.setParamCnt(paramCount);
        List<JT_8101.ParamItem> paramItemList = new ArrayList<>();
        if (fixedReportTime != null) {
            JT_8101.ParamItem paramItem01 = jt8101.new ParamItem();
            paramItem01.setParamId(0x01);
            paramItem01.setParamVal(fixedReportTime);
            paramItemList.add(paramItem01);
        }
        if (StringUtils.isNotBlank(knockedReportTime)) {
            JT_8101.ParamItem paramItem02 = jt8101.new ParamItem();
            paramItem02.setParamId(0x02);
            paramItem02.setParamVal(knockedReportTime);
            paramItemList.add(paramItem02);
        }
        if (shakeThreshold != null) {
            JT_8101.ParamItem paramItem03 = jt8101.new ParamItem();
            paramItem03.setParamId(0x03);
            paramItem03.setParamVal(shakeThreshold);
            paramItemList.add(paramItem03);
        }
        if (temperatureDetectCycle != null) {
            JT_8101.ParamItem paramItem04 = jt8101.new ParamItem();
            paramItem04.setParamId(0x04);
            paramItem04.setParamVal(temperatureDetectCycle);
            paramItemList.add(paramItem04);
        }
        if (temperatureThreshold != null) {
            JT_8101.ParamItem paramItem05 = jt8101.new ParamItem();
            paramItem05.setParamId(0x05);
            if (temperatureThreshold < 0) {
                paramItem05.setParamVal(Math.abs(temperatureThreshold) | 32768);
            } else {
                paramItem05.setParamVal(temperatureThreshold);
            }
            paramItemList.add(paramItem05);
        }
        if (lowBatteryThreshold != null) {
            JT_8101.ParamItem paramItem06 = jt8101.new ParamItem();
            paramItem06.setParamId(0x06);
            if ("V".equals(lowBatteryThresholdUnit)) {
                paramItem06.setParamVal(lowBatteryThreshold | 128);
            } else {
                paramItem06.setParamVal(lowBatteryThreshold);
            }
            paramItemList.add(paramItem06);
        }
        if (teardownAlarm != 0 || lowBatteryAlarm != 0 || temperatureAlarm != 0 || shakeAlarm != 0) {
            JT_8101.ParamItem paramItem07 = jt8101.new ParamItem();
            paramItem07.setParamId(0x07);
            paramItem07.setParamVal(alarm);
            paramItemList.add(paramItem07);
        }
        if (StringUtils.isNotBlank(updateInfo)) {
            JT_8101.ParamItem paramItem08 = jt8101.new ParamItem();
            paramItem08.setParamId(0x08);
            paramItem08.setParamVal(updateInfo);
            paramItemList.add(paramItem08);
        }
        if (flowInterval != null) {
            JT_8101.ParamItem paramItem09 = jt8101.new ParamItem();
            paramItem09.setParamId(0x09);
            paramItem09.setParamVal(flowInterval);
            paramItemList.add(paramItem09);
        }
        jt8101.setParamList(paramItemList);
        jt8101.setRespResult(Short.valueOf("0"));
        // 登录平台成功回复
        loginSuccessResponse(ctx, packageData,jt8101);
    }

    /**
     * 低功耗设备登录成功返回参数响应
     * @param ctx
     * @param packageData
     * @param jt8101
     */
    private void loginSuccessResponse(ChannelHandlerContext ctx, PackageData packageData, JT_8101 jt8101) {
        jt8101.setRespFlowId(packageData.getMsgHeader().getFlowId());
        String phone = packageData.getMsgHeader().getTerminalPhone();
        int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
        try {
            byte[] respBytes = jT808Encoder.encodePackage(phone, jt8101, flowId, JT808Consts.MSGID_PLANTFORM_LOGIN_REPLY);
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
            log.info("低功耗登录成功应答！终端唯一标识={}",phone);
        } catch (Exception e) {
            logger.error("终端登录应答消息编码异常！终端标识={}", packageData.getMsgHeader().getTerminalPhone(), e);
        }
    }

    /**
     * 低功耗设备登录失败响应
     * @param ctx
     * @param packageData
     * @param result
     */
    private void loginFailResponse(ChannelHandlerContext ctx, PackageData packageData, short result) {
        JT_8101 jt8101 = new JT_8101();
        jt8101.setRespFlowId(packageData.getMsgHeader().getFlowId());
        jt8101.setRespResult(result);
        jt8101.setParamCnt(Short.valueOf("0"));
        jt8101.setParamList(new ArrayList<>());
        int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
        try {
            byte[] respBytes = jT808Encoder.encodePackage(packageData.getMsgHeader().getTerminalPhone(), jt8101, flowId, JT808Consts.MSGID_PLANTFORM_LOGIN_REPLY);
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
            log.info("低功耗登录失败应答！终端唯一标识={}",packageData.getMsgHeader().getTerminalPhone());
        } catch (Exception e) {
            logger.error("终端登录应答消息编码异常！终端标识={}，异常信息={}", packageData.getMsgHeader().getTerminalPhone(), e.getMessage(), e);
        }
    }

    @Override
    public void lowPowerLocationReport(ChannelHandlerContext ctx, PackageData packageData) {
        String equId = ctx.channel().attr(Constant.equId).get();
        String carId = ctx.channel().attr(Constant.carId).get();
        String carNum = ctx.channel().attr(Constant.carNum).get();
        String deptId = ctx.channel().attr(Constant.deptId).get();
        String phone = packageData.getMsgHeader().getTerminalPhone();
        if (StringUtils.isBlank(equId)) {
            log.error("低功耗设备没有登录！equId={},phone={}", equId, phone);
            ctx.channel().close();
            return;
        }
        logger.info("低功耗设备终端唯一标识={}，设备id={}", phone, equId);
        JT_0211 jt0211 = (JT_0211) packageData.getMessageBody();
        Map<String, String> dataMap = Maps.newHashMap();
        dataMap.put("phone", phone);
        dataMap.put("equId", equId);
        dataMap.put("carId", carId);
        dataMap.put("carNum", carNum);
        dataMap.put("deptId", deptId);
        dataMap.put("state", String.valueOf(jt0211.getState()));
        dataMap.put("latitude", String.valueOf(jt0211.getLatitude()));
        dataMap.put("longitude", String.valueOf(jt0211.getLongitude()));
        dataMap.put("altitude", String.valueOf(jt0211.getAltitude()));
        dataMap.put("direation", String.valueOf(jt0211.getCourse()));
        dataMap.put("speed", String.valueOf(jt0211.getSpeed()/10.0));
        dataMap.put("reportMode", String.valueOf(jt0211.getReportMode()));
        dataMap.put("voltage", String.valueOf(jt0211.getVoltage() * 0.1));
        dataMap.put("gpsNum", String.valueOf(jt0211.getGpsNum()));
        dataMap.put("currentGpsNum", String.valueOf(jt0211.getCurrentGpsNum()));
        dataMap.put("csqSignal", String.valueOf(jt0211.getCsqSignal()));
        dataMap.put("temperature", String.valueOf(jt0211.getTemperature() * 0.01));
        dataMap.put("gpsTime", String.valueOf(jt0211.getTime()));
        logger.info("数据上行-低功耗设备GPS信息上报至消息队列！");
        Object result = rabbitTemplate.convertSendAndReceive("car_lowPowerLocationReport", "jt808", JsonTools.toJsonStr(dataMap));
        if (result == null) {
            log.info("低功耗设备上报GPS-数据库无此设备！phone={}", phone);
            return;
        }
        Map<String, String> resultMap = JsonTools.toMap(String.valueOf(result));
        // 增加低功耗平台应答
        lowPowerPlatformCommonResp(ctx, packageData, resultMap, "低功耗设备GPS信息");
    }

    @Override
    public void lowPowerLBSExtend(ChannelHandlerContext ctx, PackageData packageData) {
        String phone = packageData.getMsgHeader().getTerminalPhone();
        String equId = ctx.channel().attr(Constant.equId).get();
        if (StringUtils.isBlank(equId)) {
            log.error("低功耗设备没有登录！equId={},phone={}", equId, phone);
            ctx.channel().close();
            return;
        }
        JT_0212 jt0212 = (JT_0212) packageData.getMessageBody();
        logger.info("低功耗设备终端唯一标识={}，设备id={}", phone, equId);
        Map<String, String> dataMap = Maps.newHashMap();
        dataMap.put("equId", equId);
        dataMap.put("phone", phone);
        dataMap.put("mcc", String.valueOf(jt0212.getMcc()));
        dataMap.put("mnc", String.valueOf(jt0212.getMnc()));
        dataMap.put("serverLac", String.valueOf(jt0212.getServerLac()));
        dataMap.put("serverCellId", String.valueOf(jt0212.getServerCellId()));
        dataMap.put("n1Lac", String.valueOf(jt0212.getN1Lac()));
        dataMap.put("n1CellId", String.valueOf(jt0212.getN1CellId()));
        dataMap.put("n2Lac", String.valueOf(jt0212.getN2Lac()));
        dataMap.put("n2CellId", String.valueOf(jt0212.getN2CellId()));
        dataMap.put("n3Lac", String.valueOf(jt0212.getN3Lac()));
        dataMap.put("n3CellId", String.valueOf(jt0212.getN3CellId()));
        dataMap.put("n4Lac", String.valueOf(jt0212.getN4Lac()));
        dataMap.put("n4CellId", String.valueOf(jt0212.getN4CellId()));
        dataMap.put("n5Lac", String.valueOf(jt0212.getN5Lac()));
        dataMap.put("n5CellId", String.valueOf(jt0212.getN5CellId()));
        dataMap.put("n6Lac", String.valueOf(jt0212.getN6Lac()));
        dataMap.put("n6CellId", String.valueOf(jt0212.getN6CellId()));
        log.info("数据上行-LBS扩展信息至消息队列处理！");
        rabbitTemplate.convertAndSend("car_lowPowerLBSExtend", "jt808", JsonTools.toJsonStr(dataMap));
        // 增加低功耗平台应答
        lowPowerLBSResp(ctx, packageData, "LBS扩展信息");
    }


    @Override
    public void lastLocaltion(ChannelHandlerContext ctx, PackageData packageData) {
        JT_0201 jT0201 = (JT_0201) packageData.getMessageBody();
        JT_0200 jT0200 = jT0201.getPositionInfo();
        packageData.setMessageBody(jT0200);
        this.localtionReport(ctx, packageData);

        Map<String,String> respMap = Maps.newHashMap();
        respMap.put("phone", packageData.getMsgHeader().getTerminalPhone());
        respMap.put("equId", ctx.channel().attr(Constant.equId).get());
        respMap.put("serialNum", String.valueOf(jT0201.getRespFlowId()));
        respMap.put("result", "0");
        respMap.put("msgId", String.valueOf(JT808Consts.msgid_plantform_searchlocaltion));
        rabbitTemplate.convertAndSend("carDownCommandResp", null, JsonTools.toJsonStr(respMap));
    }



    @Override
    public void termParamResp(ChannelHandlerContext ctx, PackageData packageData) {
        JT_0104 jT_0104 = (JT_0104) packageData.getMessageBody();
        Map<String,String> respMap = Maps.newHashMap();
        respMap.put("phone", packageData.getMsgHeader().getTerminalPhone());
        respMap.put("equId", ctx.channel().attr(Constant.equId).get());
        respMap.put("serialNum", String.valueOf(jT_0104.getRespSerialNo()));
        respMap.put("result", "0");
        respMap.put("msgId", String.valueOf(JT808Consts.msgid_plantform_searchparams));
        respMap.put("data", JSON.toJSONString(jT_0104));
        rabbitTemplate.convertAndSend("carDownCommandResp", null, JsonTools.toJsonStr(respMap));
    }


    @Override
    public void termPropResp(ChannelHandlerContext ctx, PackageData packageData) {
        JT_0107 jT_0107 = (JT_0107) packageData.getMessageBody();
        Map<String,String> respMap = Maps.newHashMap();
        respMap.put("phone", packageData.getMsgHeader().getTerminalPhone());
        respMap.put("equId", ctx.channel().attr(Constant.equId).get());
        // 0107无平台流水号  因此默认指定
        respMap.put("serialNum", String.valueOf(Constant.JT8107_DEFAULT_FLOWID));
        respMap.put("result", "0");
        respMap.put("msgId", String.valueOf(JT808Consts.msgid_plantform_searchprop));
        respMap.put("data", JSON.toJSONString(jT_0107));
        rabbitTemplate.convertAndSend("carDownCommandResp", null, JsonTools.toJsonStr(respMap));
    }
}
