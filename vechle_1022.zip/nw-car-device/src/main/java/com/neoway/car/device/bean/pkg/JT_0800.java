/**
 * @company 有方物联
 * @file JT_0800.java
 * @author guojy
 * @date 2018年7月3日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :JT808-多媒体事件信息上传
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月3日
 */
public class JT_0800 implements IReadMessageBody {
	/**
	 * 多媒体ID DWORD
	 */
	private long mediaId;
	
	/**
	 * 多媒体类型 BYTE
	 * 0.图像 1.音频 2.视频
	 */
	private short mediaType;

	/**
	 * 多媒体格式编码 BYTE
	 * 0.JPEG  1.TIF  2.MP3  3.WAV  4.WMV
	 */
	private short formatCode;
	/**
	 * 事件项编码 BYTE
	 *  0：平台下发指令；1：定时动作；2：抢劫报警触发；3：碰撞侧翻报警触发；4：门开拍照；5：门关拍照；6：车门由开变关，时速从＜20 公里到超过20 公里；7：定距拍照
	 */
	private short itemCode;

	/**
	 * 通道ID BYTE
	 */
	private short channel;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IReadMessageBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
		this.setMediaId(in.readUnsignedInt());
		this.setMediaType(in.readByte());
		this.setFormatCode(in.readByte());
		this.setItemCode(in.readByte());
		this.setChannel(in.readByte());
	}
	/**
	 * @return the mediaId
	 */
	public long getMediaId() {
		return mediaId;
	}
	/**
	 * @param mediaId the mediaId to set
	 */
	public void setMediaId(long mediaId) {
		this.mediaId = mediaId;
	}
	/**
	 * @return the mediaType
	 */
	public short getMediaType() {
		return mediaType;
	}
	/**
	 * @param mediaType the mediaType to set
	 */
	public void setMediaType(short mediaType) {
		this.mediaType = mediaType;
	}
	/**
	 * @return the formatCode
	 */
	public short getFormatCode() {
		return formatCode;
	}
	/**
	 * @param formatCode the formatCode to set
	 */
	public void setFormatCode(short formatCode) {
		this.formatCode = formatCode;
	}
	/**
	 * @return the itemCode
	 */
	public short getItemCode() {
		return itemCode;
	}
	/**
	 * @param itemCode the itemCode to set
	 */
	public void setItemCode(short itemCode) {
		this.itemCode = itemCode;
	}
	/**
	 * @return the channel
	 */
	public short getChannel() {
		return channel;
	}
	/**
	 * @param channel the channel to set
	 */
	public void setChannel(short channel) {
		this.channel = channel;
	}

	
}
