/**
 * @company 有方物联
 * @file PostitionAdditional_01.java
 * @author guojy
 * @date 2018年4月24日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :里程附加信息  1/10km，对应车上里程表读数
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月24日
 */
public class PostitionAdditional_01 implements IPositionAdditionalItem {
	/**
	 * 里程
	 */
	private long mileage;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x01;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x4;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(4);
		in.writeInt(Long.valueOf(this.getMileage()).intValue());
		return in.array();
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		this.setMileage(in.readUnsignedInt());
	}

	/**
	 * @return the mileage
	 */
	public long getMileage() {
		return mileage;
	}

	/**
	 * @param mileage the mileage to set
	 */
	public void setMileage(long mileage) {
		this.mileage = mileage;
	}

}
