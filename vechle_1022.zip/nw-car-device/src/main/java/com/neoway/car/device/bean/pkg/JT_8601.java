/**
 * @company 有方物联
 * @file JT_8601.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 删除圆形区域
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8601 implements IWriteMessageBody {
	/**
	 * 区域数 不超过125   0表示删除所有圆形区域
	 */
	private short num;
	
	/**
	 * 区域ID列表
	 */
	private List<Long> areaIds;
	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(1 + 4*num);
		in.writeByte(this.getNum());
		for (Long areaId : this.getAreaIds()) {
			in.writeInt(areaId.intValue());
		}
		return in.array();
	}
	/**
	 * @return the num
	 */
	public short getNum() {
		return num;
	}
	/**
	 * @param num the num to set
	 */
	public void setNum(short num) {
		this.num = num;
	}
	/**
	 * @return the areaIds
	 */
	public List<Long> getAreaIds() {
		return areaIds;
	}
	/**
	 * @param areaIds the areaIds to set
	 */
	public void setAreaIds(List<Long> areaIds) {
		this.areaIds = areaIds;
	}
	
	

}
