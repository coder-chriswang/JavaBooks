/**
 * @company 有方物联
 * @file JT_0104.java
 * @author bailu
 * @date 2018年4月16日
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.google.common.collect.Lists;
import com.neoway.car.device.bean.IReadMessageBody;
import com.neoway.car.device.util.Constant;
import com.neoway.car.device.util.JT808Consts;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 查询终端参数应答
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_0104 implements IReadMessageBody {
    /**
     * WORD 应答流水号
     */
    private int respSerialNo;
    /**
     * BYTE 应答参数个数
     */
    private short paramCnt;

    /**
     * 参数项列表
     */
    private List<ParamItem> paramItemList;

    @Override
    public void readFromBytes(byte[] messageBodyBytes) {
        ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
        this.setRespSerialNo(in.readUnsignedShort());
        this.setParamCnt(in.readUnsignedByte());
        this.setParamItemList(Lists.newArrayList());
        while(in.isReadable()){
            ParamItem item = new ParamItem();
            item.setParamId(in.readUnsignedInt());
            item.setParamLen(in.readUnsignedByte());
            String fileType = JT808Consts.FieldTypeMap.get(Long.valueOf(item.getParamId()).intValue());
            if(fileType == null){
                break;
            }
            if("BYTE".equals(fileType)){
                item.setParamVal(in.readByte());
            }else if("WORD".equals(fileType)){
                item.setParamVal(in.readUnsignedShort());
            }else if("DWORD".equals(fileType)){
                item.setParamVal(in.readUnsignedInt());
            }else if("STRING".equals(fileType)){
                byte[] val = new byte[item.getParamLen()];
                in.readBytes(val);
                item.setParamVal(new String(val,Constant.string_charset));
            }else{
                in.readBytes(item.getParamLen());
            }
            this.getParamItemList().add(item);
        }
    }


    /**
     * @return the respSerialNo
     */
    public int getRespSerialNo() {
        return respSerialNo;
    }


    /**
     * @param respSerialNo the respSerialNo to set
     */
    public void setRespSerialNo(int respSerialNo) {
        this.respSerialNo = respSerialNo;
    }


    /**
     * @return the paramCnt
     */
    public short getParamCnt() {
        return paramCnt;
    }


    /**
     * @param paramCnt the paramCnt to set
     */
    public void setParamCnt(short paramCnt) {
        this.paramCnt = paramCnt;
    }


    /**
     * @return the paramItemList
     */
    public List<ParamItem> getParamItemList() {
        return paramItemList;
    }


    /**
     * @param paramItemList the paramItemList to set
     */
    public void setParamItemList(List<ParamItem> paramItemList) {
        this.paramItemList = paramItemList;
    }


    /**
     * @description :终端参数项
     * @author : guojy
     * @version : V1.0.0
     * @date : 2018年5月2日
     */
    public class ParamItem{
        /**
         * DWORD
         */
        private long paramId;
        /**
         * BYTE
         */
        private short paramLen;
        /**
         * 参数值
         */
        private Object paramVal;
        /**
         * @return the paramId
         */
        public long getParamId() {
            return paramId;
        }
        /**
         * @param paramId the paramId to set
         */
        public void setParamId(long paramId) {
            this.paramId = paramId;
        }
        /**
         * @return the paramLen
         */
        public short getParamLen() {
//			byte[] val = getParamVal().toString().getBytes(Constant.string_charset);
//			String fileType = JT808Consts.FieldTypeMap.get(Long.valueOf(getParamId()).intValue());
//			if("BYTE".equals(fileType)){
//				return (short)1;
//			}else if("WORD".equals(fileType)){
//				return (short)2;
//			}else if("DWORD".equals(fileType)){
//				return (short)4;
//			}else if("STRING".equals(fileType)){
//				return (short)val.length;
//			}
            return paramLen;
        }
        /**
         * @return the paramVal
         */
        public Object getParamVal() {
            return paramVal;
        }
        /**
         * @param paramVal the paramVal to set
         */
        public void setParamVal(Object paramVal) {
            this.paramVal = paramVal;
        }
        /**
         * @param paramLen the paramLen to set
         */
        public void setParamLen(short paramLen) {
            this.paramLen = paramLen;
        }


    }

}
