package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;
import com.neoway.car.device.util.Constant;

/**
 * <pre>
 *  描述: 低功耗设备登录消息体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/30 8:56
 */
public class JT_0101 implements IReadMessageBody {


    /**
     * 登录上报版本信息——“MCU版本号;模块版本号;蓝牙版本号”
     */
    private String versionInfo;

    @Override
    public void readFromBytes(byte[] messageBodyBytes) {
        setVersionInfo(new String(messageBodyBytes, Constant.string_charset));
    }


    public String getVersionInfo() {
        return versionInfo;
    }

    public void setVersionInfo(String versionInfo) {
        this.versionInfo = versionInfo;
    }
}
