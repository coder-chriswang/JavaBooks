package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: 低功耗终端LBS扩展信息上报
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/30 10:52
 */
public class JT_0212 implements IReadMessageBody {

    /**
     * 国家代号
     */
    private int mcc;

    /**
     * 移动网号码
     */
    private short mnc;

    /**
     * 服务位置区码
     */
    private int serverLac;

    /**
     * 服务移动基站
     */
    private int serverCellId;

    private int n1Lac;

    private int n1CellId;

    private int n2Lac;

    private int n2CellId;

    private int n3Lac;

    private int n3CellId;

    private int n4Lac;

    private int n4CellId;

    private int n5Lac;

    private int n5CellId;

    private int n6Lac;

    private int n6CellId;

    @Override
    public void readFromBytes(byte[] messageBodyBytes) {
        ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
        setMcc(in.readUnsignedShort());
        setMnc(in.readUnsignedByte());
        setServerLac(in.readUnsignedShort());
        setServerCellId(in.readUnsignedShort());
        setN1Lac(in.readUnsignedShort());
        setN1CellId(in.readUnsignedShort());
        setN2Lac(in.readUnsignedShort());
        setN2CellId(in.readUnsignedShort());
        setN3Lac(in.readUnsignedShort());
        setN3CellId(in.readUnsignedShort());
        setN4Lac(in.readUnsignedShort());
        setN4CellId(in.readUnsignedShort());
        setN5Lac(in.readUnsignedShort());
        setN5CellId(in.readUnsignedShort());
        setN6Lac(in.readUnsignedShort());
        setN6CellId(in.readUnsignedShort());
    }

    public int getMcc() {
        return mcc;
    }

    public void setMcc(int mcc) {
        this.mcc = mcc;
    }

    public short getMnc() {
        return mnc;
    }

    public void setMnc(short mnc) {
        this.mnc = mnc;
    }

    public int getServerLac() {
        return serverLac;
    }

    public void setServerLac(int serverLac) {
        this.serverLac = serverLac;
    }

    public int getServerCellId() {
        return serverCellId;
    }

    public void setServerCellId(int serverCellId) {
        this.serverCellId = serverCellId;
    }

    public int getN1Lac() {
        return n1Lac;
    }

    public void setN1Lac(int n1Lac) {
        this.n1Lac = n1Lac;
    }

    public int getN1CellId() {
        return n1CellId;
    }

    public void setN1CellId(int n1CellId) {
        this.n1CellId = n1CellId;
    }

    public int getN2Lac() {
        return n2Lac;
    }

    public void setN2Lac(int n2Lac) {
        this.n2Lac = n2Lac;
    }

    public int getN2CellId() {
        return n2CellId;
    }

    public void setN2CellId(int n2CellId) {
        this.n2CellId = n2CellId;
    }

    public int getN3Lac() {
        return n3Lac;
    }

    public void setN3Lac(int n3Lac) {
        this.n3Lac = n3Lac;
    }

    public int getN3CellId() {
        return n3CellId;
    }

    public void setN3CellId(int n3CellId) {
        this.n3CellId = n3CellId;
    }

    public int getN4Lac() {
        return n4Lac;
    }

    public void setN4Lac(int n4Lac) {
        this.n4Lac = n4Lac;
    }

    public int getN4CellId() {
        return n4CellId;
    }

    public void setN4CellId(int n4CellId) {
        this.n4CellId = n4CellId;
    }

    public int getN5Lac() {
        return n5Lac;
    }

    public void setN5Lac(int n5Lac) {
        this.n5Lac = n5Lac;
    }

    public int getN5CellId() {
        return n5CellId;
    }

    public void setN5CellId(int n5CellId) {
        this.n5CellId = n5CellId;
    }

    public int getN6Lac() {
        return n6Lac;
    }

    public void setN6Lac(int n6Lac) {
        this.n6Lac = n6Lac;
    }

    public int getN6CellId() {
        return n6CellId;
    }

    public void setN6CellId(int n6CellId) {
        this.n6CellId = n6CellId;
    }
}
