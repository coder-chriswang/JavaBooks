/**
 * @company 有方物联
 * @file JT_8103.java
 * @author bailu
 * @date 2018年4月16日
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.neoway.car.device.bean.IWriteMessageBody;
import com.neoway.car.device.util.Constant;
import com.neoway.car.device.util.JT808Consts;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 设置终端参数
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8103 implements IWriteMessageBody {
    /**
     * 参数总数  BYTE
     */
    private short paramCnt;
    /**
     * 参数列表
     */
    private List<ParamItem> paramList;

    @Override
    public byte[] writeToBytes() {
        int len = 1;
        if(paramList != null){
            for(ParamItem item : paramList){
                len += (5 + item.getParamLen());
            }
        }
        ByteBuf in = Unpooled.buffer(len);
        in.writeByte(this.getParamCnt());
        for(ParamItem item : paramList) {
            in.writeInt(Long.valueOf(item.getParamId()).intValue());
            short paramLen = item.getParamLen();
            in.writeByte(paramLen);
            String fileType = JT808Consts.FieldTypeMap.get(Long.valueOf(item.getParamId()).intValue());
            if("BYTE".equals(fileType)) {
                in.writeByte(Byte.parseByte(item.getParamVal().toString()));
            } else if("WORD".equals(fileType)) {
                in.writeShort(Short.parseShort(item.getParamVal().toString()));
            } else if("DWORD".equals(fileType)) {
                in.writeInt(Integer.parseInt(item.getParamVal().toString()));
            } else if("STRING".equals(fileType)) {
                byte[] val = item.getParamVal().toString().getBytes(Constant.string_charset);
                in.writeBytes(val, 0, val.length);
            }
        }
        return in.array();
    }

    /**
     * @description :终端参数项
     * @author : guojy
     * @version : V1.0.0
     * @date : 2018年5月2日
     */
    public class ParamItem{
        /**
         * DWORD
         */
        private long paramId;
        /**
         * BYTE
         */
//		private short paramLen;
        /**
         * 参数值
         */
        private Object paramVal;
        /**
         * @return the paramId
         */
        public long getParamId() {
            return paramId;
        }
        /**
         * @param paramId the paramId to set
         */
        public void setParamId(long paramId) {
            this.paramId = paramId;
        }
        /**
         * @return the paramLen
         */
        public short getParamLen() {
            byte[] val = getParamVal().toString().getBytes(Constant.string_charset);
            String fileType = JT808Consts.FieldTypeMap.get(Long.valueOf(getParamId()).intValue());
            if("BYTE".equals(fileType)){
                return (short)1;
            }else if("WORD".equals(fileType)){
                return (short)2;
            }else if("DWORD".equals(fileType)){
                return (short)4;
            }else if("STRING".equals(fileType)){
                return (short)val.length;
            }
            return 0;
        }
        /**
         * @return the paramVal
         */
        public Object getParamVal() {
            return paramVal;
        }
        /**
         * @param paramVal the paramVal to set
         */
        public void setParamVal(Object paramVal) {
            this.paramVal = paramVal;
        }


    }
    /**
     * @return the paramCnt
     */
    public short getParamCnt() {
        return paramCnt;
    }
    /**
     * @param paramCnt the paramCnt to set
     */
    public void setParamCnt(short paramCnt) {
        this.paramCnt = paramCnt;
    }
    /**
     * @return the paramList
     */
    public List<ParamItem> getParamList() {
        return paramList;
    }
    /**
     * @param paramList the paramList to set
     */
    public void setParamList(List<ParamItem> paramList) {
        this.paramList = paramList;
    }


}
