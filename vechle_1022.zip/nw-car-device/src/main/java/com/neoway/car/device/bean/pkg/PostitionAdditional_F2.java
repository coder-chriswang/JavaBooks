package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: OBD扩展车辆电压 WORD 单位：0.1V
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/03 20:14
 */
public class PostitionAdditional_F2 implements IPositionAdditionalItem {

    private int carVoltage;

    @Override
    public int getAdditionalId() {
        return 0xF2;
    }

    @Override
    public byte getAdditionalLength() {
        return 0x2;
    }

    @Override
    public byte[] writeToBytes() {
        ByteBuf in = Unpooled.buffer(2);
        in.writeShort(getCarVoltage());
        return in.array();
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        setCarVoltage(in.readUnsignedShort());
    }

    public int getCarVoltage() {
        return carVoltage;
    }

    public void setCarVoltage(int carVoltage) {
        this.carVoltage = carVoltage;
    }
}
