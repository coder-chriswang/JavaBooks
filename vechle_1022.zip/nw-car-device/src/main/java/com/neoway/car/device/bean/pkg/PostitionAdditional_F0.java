package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: OBD拓展报警标志位
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/03 19:54
 */
public class PostitionAdditional_F0 implements IPositionAdditionalItem {

    /**
     * OBD扩展告警字段
     */
    private long extendAlarmState;

    @Override
    public int getAdditionalId() {
        return 0xF0;
    }

    @Override
    public byte getAdditionalLength() {
        return 0x4;
    }

    @Override
    public byte[] writeToBytes() {
        ByteBuf in = Unpooled.buffer(4);
        in.writeInt(Long.valueOf(getExtendAlarmState()).intValue());
        return in.array();
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        setExtendAlarmState(in.readUnsignedInt());
    }

    public long getExtendAlarmState() {
        return extendAlarmState;
    }

    public void setExtendAlarmState(long extendAlarmState) {
        this.extendAlarmState = extendAlarmState;
    }
}
