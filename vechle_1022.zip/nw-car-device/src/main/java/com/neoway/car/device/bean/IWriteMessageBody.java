/**
 * @company 有方物联
 * @file IMessageBody.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.bean;

/**
 * @description :报文编码接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
public interface IWriteMessageBody {
	/**
	 * 对象转为字节数组
	 * @return
	 */
	byte[] writeToBytes();
}
