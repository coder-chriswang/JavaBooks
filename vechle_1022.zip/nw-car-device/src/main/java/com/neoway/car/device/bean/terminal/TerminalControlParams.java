package com.neoway.car.device.bean.terminal;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 终端控制参数实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/02 19:16
 */
@Data
public class TerminalControlParams implements Serializable {
    private static final long serialVersionUID = 5305611946485393108L;

    /**
     * 设备号
     */
    private String equId;

    /**
     * 终端电话
     */
    private String phone;

    /**
     * 命令字
     */
    private byte commandWord;

    /**
     * 命令参数
     */
    private String commandParams;
}
