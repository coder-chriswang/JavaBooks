/**
 * @company 有方物联
 * @file JT_8801.java
 * @author guojy
 * @date 2018年7月3日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :JT808-摄像头立即拍摄命令
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月3日
 */
public class JT_8801 implements IWriteMessageBody {
	/**
	 * 通道ID
	 */
	private short channel;
	
	/**
	 * 拍照指令
	 * 0.停止拍摄     0xFFFF.录像   其他表示拍照张数
	 */
	private int shotOrder;
	
	/**
	 * 拍照间隔（秒） 0.最小拍照间隔
	 */
	private int shotSpace;
	
	/**
	 * 保存标志 1.保存  2.实时上传
	 */
	private short saveFlag;
	
	/**
	 * 分辨率
	 * 0x01：320*240 0x02：640*480 0x03：800*600 0x04：1024*768 
	 * 0x05：176*144 0x06：352*288 0x07：704*288 0x08：704*576 
	 */
	private short resolution;

	/**
	 * 图像质量 1-10  1.代表图像质量损失最小   10.代表压缩比最大
	 */
	private short imageQuality;
	
	/**
	 * 亮度 0-255
	 */
	private short brightness;
	
	/**
	 * 对比度0-127
	 */
	private short contrast;
	
	/**
	 * 饱和度0-127
	 */
	private short saturation;
	
	/**
	 * 色度 0-255
	 */
	private short chroma;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IWriteMessageBody#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(12);
		in.writeByte(this.getChannel());
		in.writeShort(this.getShotOrder());
		in.writeShort(this.getShotSpace());
		in.writeByte(this.getSaveFlag());
		in.writeByte(this.getResolution());
		in.writeByte(this.getImageQuality());
		in.writeByte(this.getBrightness());
		in.writeByte(this.getContrast());
		in.writeByte(this.getSaturation());
		in.writeByte(this.getChroma());
		return in.array();
	}
	/**
	 * @return the channel
	 */
	public short getChannel() {
		return channel;
	}
	/**
	 * @param channel the channel to set
	 */
	public void setChannel(short channel) {
		this.channel = channel;
	}
	/**
	 * @return the shotOrder
	 */
	public int getShotOrder() {
		return shotOrder;
	}
	/**
	 * @param shotOrder the shotOrder to set
	 */
	public void setShotOrder(int shotOrder) {
		this.shotOrder = shotOrder;
	}
	/**
	 * @return the shotSpace
	 */
	public int getShotSpace() {
		return shotSpace;
	}
	/**
	 * @param shotSpace the shotSpace to set
	 */
	public void setShotSpace(int shotSpace) {
		this.shotSpace = shotSpace;
	}
	/**
	 * @return the saveFlag
	 */
	public short getSaveFlag() {
		return saveFlag;
	}
	/**
	 * @param saveFlag the saveFlag to set
	 */
	public void setSaveFlag(short saveFlag) {
		this.saveFlag = saveFlag;
	}
	/**
	 * @return the resolution
	 */
	public short getResolution() {
		return resolution;
	}
	/**
	 * @param resolution the resolution to set
	 */
	public void setResolution(short resolution) {
		this.resolution = resolution;
	}
	/**
	 * @return the imageQuality
	 */
	public short getImageQuality() {
		return imageQuality;
	}
	/**
	 * @param imageQuality the imageQuality to set
	 */
	public void setImageQuality(short imageQuality) {
		this.imageQuality = imageQuality;
	}
	/**
	 * @return the brightness
	 */
	public short getBrightness() {
		return brightness;
	}
	/**
	 * @param brightness the brightness to set
	 */
	public void setBrightness(short brightness) {
		this.brightness = brightness;
	}
	/**
	 * @return the contrast
	 */
	public short getContrast() {
		return contrast;
	}
	/**
	 * @param contrast the contrast to set
	 */
	public void setContrast(short contrast) {
		this.contrast = contrast;
	}
	/**
	 * @return the saturation
	 */
	public short getSaturation() {
		return saturation;
	}
	/**
	 * @param saturation the saturation to set
	 */
	public void setSaturation(short saturation) {
		this.saturation = saturation;
	}
	/**
	 * @return the chroma
	 */
	public short getChroma() {
		return chroma;
	}
	/**
	 * @param chroma the chroma to set
	 */
	public void setChroma(short chroma) {
		this.chroma = chroma;
	}

	
}
