package com.neoway.car.device.bean.pkg;

import com.google.common.collect.Lists;
import com.neoway.car.device.bean.IPositionAdditionalItem;
import com.neoway.car.device.util.Constant;
import com.neoway.car.device.util.JT808Consts;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * <pre>
 *  描述: OBD数据自定义数据
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/03 20:34
 */
public class PostitionAdditional_F4 implements IPositionAdditionalItem {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 参数列表
     */
    private List<ParamItem> paramList;

    @Override
    public int getAdditionalId() {
        return 0xF4;
    }

    @Override
    public byte getAdditionalLength() {
        return 0;
    }

    @Override
    public byte[] writeToBytes() {
        return null;
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        setParamList(Lists.newArrayList());
        while(in.isReadable()) {
            // 附加消息
            ParamItem paramItem = new ParamItem();
            // F4消息ID
            int obdId = in.readUnsignedShort();
            logger.info("obdId={}", Long.valueOf(obdId).intValue());
            String fileType = JT808Consts.OBD_F4_FIELD_TYPE_MAP.get(Long.valueOf(obdId).intValue());
            logger.info("F4 消息类型={}", fileType);
            paramItem.setParamId(obdId);
            // F4消息长度
            int obdDataLength = in.readUnsignedByte();
            if("BYTE".equals(fileType)) {
               paramItem.setParamVal(in.readUnsignedByte());
            } else if("WORD".equals(fileType)) {
                paramItem.setParamVal(in.readUnsignedShort());
            }
            logger.info("F4 消息ID={},消息长度={}", Integer.toHexString(obdId), obdDataLength);
            this.getParamList().add(paramItem);
        }
    }


    public class ParamItem {
        /**
         * WORD
         */
        private int paramId;

        /**
         * 参数值
         */
        private Object paramVal;

        public int getParamId() {
            return paramId;
        }

        public void setParamId(int paramId) {
            this.paramId = paramId;
        }

        public short getParamLen() {
            byte[] val = getParamVal().toString().getBytes(Constant.string_charset);
            String fileType = JT808Consts.OBD_F4_FIELD_TYPE_MAP.get(Long.valueOf(getParamId()).intValue());
            if("BYTE".equals(fileType)){
                return (short)1;
            } else if("WORD".equals(fileType)){
                return (short)2;
            }
            return 0;
        }

        public Object getParamVal() {
            return paramVal;
        }

        public void setParamVal(Object paramVal) {
            this.paramVal = paramVal;
        }

    }

    public List<ParamItem> getParamList() {
        return paramList;
    }

    public void setParamList(List<ParamItem> paramList) {
        this.paramList = paramList;
    }
}
