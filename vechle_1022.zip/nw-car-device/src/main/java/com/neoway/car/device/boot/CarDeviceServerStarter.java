/**
 * @company 有方物联
 * @file CarDeviceServerStarter.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.boot;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @description :车载设备接入服务启动BOOT
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
@Deprecated
public class CarDeviceServerStarter {
	private static Logger logger = LoggerFactory.getLogger(CarDeviceServerStarter.class);
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ConfigurableApplicationContext applicaton = new ClassPathXmlApplicationContext("classpath*:application-*.xml");
		logger.info("服务启动:{}",applicaton.toString());
		//处理程序退出时车辆离线、关闭容器
		Runtime.getRuntime().addShutdownHook(new Thread(new ShutdownHook(applicaton)));
	}
	
}
