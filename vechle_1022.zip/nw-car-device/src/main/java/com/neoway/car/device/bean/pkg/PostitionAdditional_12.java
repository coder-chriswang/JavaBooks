/**
 * @company 有方物联
 * @file PostitionAdditional_12.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :进出区域、线路附加告警信息
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class PostitionAdditional_12 implements IPositionAdditionalItem {
	/**
	 * BYTE
	 * 位置类型 1：圆型区域；2：矩形区域；3：多边形区域；4：路线
	 */
	private short positionType;
	/**
	 * DWORD
	 * 区域或线路ID
	 */
	private long areaId;
	/**
	 * 
	 * BYTE
	 * 方向 0出 1进
	 */
	private short direction;
	
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x12;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x6;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(6);
		in.writeByte(this.getPositionType());
		in.writeInt(Long.valueOf(this.getAreaId()).intValue());
		in.writeByte(this.getDirection());
		return in.array();
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		this.setPositionType(in.readUnsignedByte());
		this.setAreaId(in.readUnsignedInt());
		this.setDirection(in.readUnsignedByte());
	}

	/**
	 * @return the direction
	 */
	public short getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(short direction) {
		this.direction = direction;
	}

	/**
	 * @return the positionType
	 */
	public short getPositionType() {
		return positionType;
	}

	/**
	 * @param positionType the positionType to set
	 */
	public void setPositionType(short positionType) {
		this.positionType = positionType;
	}

	/**
	 * @return the areaId
	 */
	public long getAreaId() {
		return areaId;
	}

	/**
	 * @param areaId the areaId to set
	 */
	public void setAreaId(long areaId) {
		this.areaId = areaId;
	}

	
	
}
