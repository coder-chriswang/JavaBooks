/**
 * @company 有方物联
 * @file DeviceManager.java
 * @author guojy
 * @date 2018年4月15日 
 */
package com.neoway.car.device.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import io.netty.channel.ChannelHandlerContext;

/**
 * @description :设备连接管理
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
public class DeviceManager {
	private static volatile DeviceManager instance = null;
	/**
	 * device和channel的映射关系
	 */
	private Map<String, ChannelHandlerContext> deviceMap;
	
	public static DeviceManager getInstance() {
		if (instance == null) {
			synchronized (DeviceManager.class) {
				if (instance == null) {
					instance = new DeviceManager();
				}
			}
		}
		return instance;
	}
	
	public DeviceManager() {
		this.deviceMap = new ConcurrentHashMap<String, ChannelHandlerContext>();
	}
	

	/**
	 * 通过deviceId查找Channel
	 * @param deviceId
	 * @return
	 */
	public ChannelHandlerContext findByDeviceId(String deviceId) {
		return deviceMap.get(deviceId);
	}
	
	/**
	 * 保存设备连接上下文
	 * @param deviceId
	 * @param value
	 * @return
	 */
	public synchronized ChannelHandlerContext put(String deviceId, ChannelHandlerContext value) {
		return deviceMap.put(deviceId, value);
	}
	
	/**
	 * 移除设备连接上下文
	 * @param deviceId
	 * @return
	 */
	public synchronized ChannelHandlerContext removeByDeviceId(String deviceId) {
		if(deviceId == null){
			return null;
		}
		return deviceMap.remove(deviceId);
	}
	
	/**
	 * 返回所有在线设备列表
	 * @return
	 */
	public Map<String, ChannelHandlerContext> findAllDevices(){
		return deviceMap;
	}
}
