package com.neoway.car.device.lowpower;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 低功耗设备参数设置
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/30 19:19
 */
@Data
public class LowPowerConfig implements Serializable {
    private static final long serialVersionUID = -5594394929331088403L;

    /**
     * 参数总数
     */
    private int paramCount;

    /**
     * 定时上报时间
     */
    private int fixedReportTime;

    /**
     * 闹钟定位上报
     */
    private String knockedReportTime;

    /**
     * 震动阈值
     */
    private int shakeThreshold;

    /**
     * 温度检测周期
     */
    private int temperatureDetectCycle;

    /**
     * 温度阈值
     */
    private int temperatureThreshold;

    /**
     * 低电量阈值
     */
    private int lowBatteryThreshold;

    /**
     * 报警开关
     */
    private int alarm;

    /**
     * 更新升级
     */
    private String updateInfo;
}
