/**
 * @company 有方物联
 * @file PostitionAdditional_17.java
 * @author guojy
 * @date 2018年7月2日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.google.common.collect.Lists;
import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :存储器故障报警
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月2日
 */
public class PostitionAdditional_17 implements IPositionAdditionalItem {
	/**
	 * 主存储器故障列表
	 */
	private List<Integer> masterStore = Lists.newArrayList();
	/**
	 * 备份存储器故障列表
	 */
	private List<Integer> slaveStore = Lists.newArrayList();
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x17;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x2;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		int state = in.readUnsignedShort();
		for(int i=0;i<12;i++){
			byte flag = convert(state, i);
			if(flag == 1){
				masterStore.add(i+1);
			}
		}
		for(int i=12;i<16;i++){
			byte flag = convert(state, i);
			if(flag == 1){
				slaveStore.add(i+1);
			}
		}
	}
	
	protected static byte convert(long state, int pos){
	    return (byte)(state >> pos & 1);
	}

	/**
	 * @return the masterStore
	 */
	public List<Integer> getMasterStore() {
		return masterStore;
	}

	/**
	 * @return the slaveStore
	 */
	public List<Integer> getSlaveStore() {
		return slaveStore;
	}

	
}
