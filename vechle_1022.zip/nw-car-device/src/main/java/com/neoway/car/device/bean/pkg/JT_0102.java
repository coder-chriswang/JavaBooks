/**
 * @company 有方物联
 * @file Mirror_0005.java
 * @author guojy
 * @date 2017年12月18日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;
import com.neoway.car.device.util.Constant;

/**
 * @description :终端鉴权 0x0102
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class JT_0102 implements IReadMessageBody {
	/**
	 * 鉴权码
	 */
	private String authCode;

	/* (non-Javadoc)
	 * @see com.etide.device.drivmirror.IMsgBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] msgBodyBytes) {
		this.setAuthCode(new String(msgBodyBytes,Constant.string_charset));
	}

	/**
	 * @return the authCode
	 */
	public String getAuthCode() {
		return authCode;
	}

	/**
	 * @param authCode the authCode to set
	 */
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	
}
