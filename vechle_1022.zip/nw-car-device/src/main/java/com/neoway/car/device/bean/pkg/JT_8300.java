/**
 * @company 有方物联
 * @file JT_8300.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import java.nio.charset.Charset;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 文本信息下发
 * @author : bailu 
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8300 implements IWriteMessageBody {

	/**
	 * 标志 BYTE
	 * =================================
	 * 位           标志
	 * =================================
	 * 0    1：紧急
	 * 1            保留
	 * 2    1：终端显示器显示
	 * 3    1：终端TTS播读
	 * 4    1：广告屏显示
	 * 5    0：中心导航信息   1：CAN故障码信息
	 * 6-7     保留
	 */
	private short flag;
	
	/**
	 * 文本信息 STRING
	 * 最长为1024字节，经GBK编码
	 */
	private String content;
	
	@Override
	public byte[] writeToBytes() {
		byte[] contentBytes = this.getContent().getBytes(Charset.forName("GBK"));
		ByteBuf in = Unpooled.buffer(1+contentBytes.length);
		in.writeByte(this.getFlag());
		in.writeBytes(contentBytes);
		return in.array();
	}

	/**
	 * @return the flag
	 */
	public short getFlag() {
		return flag;
	}

	/**
	 * @param flag the flag to set
	 */
	public void setFlag(short flag) {
		this.flag = flag;
	}

	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

}
