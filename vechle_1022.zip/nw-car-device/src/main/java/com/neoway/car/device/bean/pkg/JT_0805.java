/**
 * @company 有方物联
 * @file JT_0805.java
 * @author guojy
 * @date 2018年7月3日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.google.common.collect.Lists;
import com.neoway.car.device.bean.IReadMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :JT808-摄像头立即拍摄命令应答
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月3日
 */
public class JT_0805 implements IReadMessageBody {
	/**
	 * 应答流水号WORD
	 */
	private int serialNo;
	
	/**
	 * 结果 BYTE  0.成功  1.失败  2.通道不支持 
	 * 下面的参数在0时才有效
	 */
	private short result;
	
	/**
	 * 拍摄成功的多媒体个数 WORD  n
	 */
	private int mediaNum;
	
	/**
	 * 多媒体ID列表  BYTE[4*n]
	 */
	private List<String> mediaList;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IReadMessageBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
		this.setSerialNo(in.readUnsignedShort());
		this.setResult(in.readUnsignedByte());
		this.setMediaNum(in.readUnsignedShort());
		List<String> mediaList = Lists.newArrayList();
		for(int i = 0;i < this.getMediaNum(); i++){
			if(in.isReadable()){
				long resId = in.readUnsignedInt();
				mediaList.add(String.valueOf(resId));
			}
		}
		this.setMediaList(mediaList);
	}
	/**
	 * @return the serialNo
	 */
	public int getSerialNo() {
		return serialNo;
	}
	/**
	 * @param serialNo the serialNo to set
	 */
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	/**
	 * @return the result
	 */
	public short getResult() {
		return result;
	}
	/**
	 * @param result the result to set
	 */
	public void setResult(short result) {
		this.result = result;
	}
	/**
	 * @return the mediaNum
	 */
	public int getMediaNum() {
		return mediaNum;
	}
	/**
	 * @param mediaNum the mediaNum to set
	 */
	public void setMediaNum(int mediaNum) {
		this.mediaNum = mediaNum;
	}
	/**
	 * @return the mediaList
	 */
	public List<String> getMediaList() {
		return mediaList;
	}
	/**
	 * @param mediaList the mediaList to set
	 */
	public void setMediaList(List<String> mediaList) {
		this.mediaList = mediaList;
	}
	
}
