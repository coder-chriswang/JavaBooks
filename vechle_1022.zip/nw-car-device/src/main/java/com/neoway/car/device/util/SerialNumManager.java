/**
 * @company 有方物联
 * @file SerialNumManager.java
 * @author guojy
 * @date 2017年12月19日 
 */
package com.neoway.car.device.util;

import java.util.Map;

import com.google.common.collect.Maps;

import io.netty.channel.ChannelHandlerContext;

/**
 * @description :流水号管理
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年12月19日
 */
public class SerialNumManager {
	private static volatile SerialNumManager instance = null;
	
	private Map<String, Session> sessionIdMap;
	/**
	 * 单例类
	 * @return
	 */
	public static SerialNumManager getInstance() {
		if (instance == null) {
			synchronized (SerialNumManager.class) {
				if (instance == null) {
					instance = new SerialNumManager();
				}
			}
		}
		return instance;
	}
	
	/**
	 * @param sessionIdMap
	 */
	public SerialNumManager() {
		this.sessionIdMap = Maps.newConcurrentMap();
	}
	
	private class Session{
		//消息流水号 word(16) 按发送顺序从 0 开始循环累加
		private int currentFlowId = 0;
		
		public int currentFlowId() {
			if (currentFlowId >= 0xffff)
				currentFlowId = 0;
			return currentFlowId++;
		}
	}
	
	/**
	 * 获取流水号
	 * @param ctx
	 * @return
	 */
	public synchronized int currentFlowId(ChannelHandlerContext ctx){
		String key = ctx.channel().remoteAddress().toString();
		if(!sessionIdMap.containsKey(key)){
			sessionIdMap.put(key, new Session());
		}
		return sessionIdMap.get(key).currentFlowId();
	}
	
	/**
	 * 清除ctx
	 * @param ctx
	 */
	public void clearCtx(ChannelHandlerContext ctx){
		String key = ctx.channel().remoteAddress().toString();
		sessionIdMap.remove(key);
	}
}
