/**
 * @company 有方物联
 * @file JT_8100.java
 * @author guojy
 * @date 2018年4月12日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;
import com.neoway.car.device.util.Constant;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :终端注册应答
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月12日
 */
public class JT_8100 implements IWriteMessageBody {
	/**
	 * 应答流水号 word(16bit)  
	 */
	private int respFlowId;
	/**
	 * 结果 byte (8bit) 
	 * 0：成功；1：车辆已被注册；2：数据库中无该车辆；3：终端已被注册；4：数据库中无该终端
	 */
	private short respResult;
	
	/**
	 * 鉴权码
	 */
	private String authCode;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IMessageBody#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		int authLength = 0;
		if(this.getRespResult() == 0 && getAuthCode() != null){
			authLength = getAuthCode().getBytes(Constant.string_charset).length;
		}
		ByteBuf in = Unpooled.buffer(3+authLength);
		in.writeShort(getRespFlowId());
		in.writeByte(getRespResult());
		if(this.getRespResult() == 0 && getAuthCode() != null){
			in.writeBytes(getAuthCode().getBytes(Constant.string_charset));
		}
		return in.array();
	}

	/**
	 * @return the respFlowId
	 */
	public int getRespFlowId() {
		return respFlowId;
	}

	/**
	 * @param respFlowId the respFlowId to set
	 */
	public void setRespFlowId(int respFlowId) {
		this.respFlowId = respFlowId;
	}

	/**
	 * @return the respResult
	 */
	public short getRespResult() {
		return respResult;
	}

	/**
	 * @param respResult the respResult to set
	 */
	public void setRespResult(short respResult) {
		this.respResult = respResult;
	}

	/**
	 * @return the authCode
	 */
	public String getAuthCode() {
		return authCode;
	}

	/**
	 * @param authCode the authCode to set
	 */
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	
}
