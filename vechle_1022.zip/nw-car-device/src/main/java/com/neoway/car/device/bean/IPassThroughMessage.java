package com.neoway.car.device.bean;

/**
 * <pre>
 *  描述: 数据上行透传消息接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/16 16:21
 */
public interface IPassThroughMessage {

    /**
     * 透传消息ID
     * @return
     */
    int getMessageId();

    /**
     * 附加消息长度
     * @return
     */
    byte getMessageLength();

    /**
     * 附加消息转为字节
     * @return
     */
    byte[] writeToBytes();

    /**
     * 读取附加消息
     * @param bytes
     */
    void readFromBytes(byte[] bytes);
}
