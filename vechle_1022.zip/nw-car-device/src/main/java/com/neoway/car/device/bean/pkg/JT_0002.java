/**
 * @company 有方物联
 * @file JT_0002.java
 * @author guojy
 * @date 2018年4月12日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

/**
 * @description :终端心跳
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月12日
 */
public class JT_0002 implements IReadMessageBody {

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IMessageBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {

	}

}
