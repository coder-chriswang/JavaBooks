/**
 * @company 有方物联
 * @file JT_0001.java
 * @author guojy
 * @date 2018年4月15日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :终端通用应答
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月15日
 */
public class JT_0001 implements IReadMessageBody {
	/**
	 * 应答流水号 word(16bit)  
	 * 对应的平台消息的流水号
	 */
	private int respFlowId;
	
	/**
	 * 应答消息ID word(16bit) 
	 * 对应的平台消息的ID
	 */
	private int respMsgId;
	
	/**
	 * 结果  byte(8bit)
	 * 0：成功/确认；1：失败；2：消息有误；3：不支持
	 */
	private short respResult;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IReadMessageBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
		this.setRespFlowId(in.readUnsignedShort());
		this.setRespMsgId(in.readUnsignedShort());
		this.setRespResult(in.readUnsignedByte());
	}
	/**
	 * @return the respFlowId
	 */
	public int getRespFlowId() {
		return respFlowId;
	}
	/**
	 * @param respFlowId the respFlowId to set
	 */
	public void setRespFlowId(int respFlowId) {
		this.respFlowId = respFlowId;
	}
	/**
	 * @return the respMsgId
	 */
	public int getRespMsgId() {
		return respMsgId;
	}
	/**
	 * @param respMsgId the respMsgId to set
	 */
	public void setRespMsgId(int respMsgId) {
		this.respMsgId = respMsgId;
	}
	/**
	 * @return the respResult
	 */
	public short getRespResult() {
		return respResult;
	}
	/**
	 * @param respResult the respResult to set
	 */
	public void setRespResult(short respResult) {
		this.respResult = respResult;
	}

	
}
