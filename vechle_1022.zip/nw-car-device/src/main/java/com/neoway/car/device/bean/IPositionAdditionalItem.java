/**
 * @company 有方物联
 * @file IPositionAdditionalItem.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.device.bean;

/**
 * @description :JT808位置附加信息接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public interface IPositionAdditionalItem {
	/**
	 * 附加消息ID
	 * @return
	 */
	int getAdditionalId();
	/**
	 * 附加消息长度
	 * @return
	 */
	byte getAdditionalLength();
	/**
	 * 附加消息转为字节
	 * @return
	 */
	byte[] writeToBytes();
	/**
	 * 读取附加消息
	 * @param bytes
	 */
	void readFromBytes(byte[] bytes);
}
