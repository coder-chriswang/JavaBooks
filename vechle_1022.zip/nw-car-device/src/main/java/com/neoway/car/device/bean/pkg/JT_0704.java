package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.util.ArrayList;
import java.util.List;

/**
 * <pre>
 *  描述: 定位数据批量上传
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/04 10:44
 */
public class JT_0704 implements IReadMessageBody {

    /**
     * 数据项个数，WORD
     */
    private int positionPackageCount;

    /**
     * 上报类型，BYTE，0：正常位置批量汇报，1：盲区补报
     */
    private short reportType;

    /**
     * 位置数据上报项
     */
    private List<JT_0200> positionList;

    @Override
    public void readFromBytes(byte[] messageBodyBytes) {
        ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
        setPositionPackageCount(in.readUnsignedShort());
        setReportType(in.readUnsignedByte());
        List<JT_0200> positionList = new ArrayList<>();
        for (int i = 0; i < getPositionPackageCount(); i++) {
            JT_0200 jt0200 = new JT_0200();
            int dataLength = in.readUnsignedShort();
            byte[] jt0200byte = new byte[dataLength];
            in.readBytes(jt0200byte, 0, dataLength);
            jt0200.readFromBytes(jt0200byte);
            positionList.add(jt0200);
        }
        setPositionList(positionList);
    }

    public int getPositionPackageCount() {
        return positionPackageCount;
    }

    public void setPositionPackageCount(int positionPackageCount) {
        this.positionPackageCount = positionPackageCount;
    }

    public short getReportType() {
        return reportType;
    }

    public void setReportType(short reportType) {
        this.reportType = reportType;
    }

    public List<JT_0200> getPositionList() {
        return positionList;
    }

    public void setPositionList(List<JT_0200> positionList) {
        this.positionList = positionList;
    }
}
