package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;
import com.neoway.car.device.util.Constant;
import com.neoway.car.device.util.JT808Consts;
import com.neoway.util.hex.BCD8421Operater;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.util.List;

/**
 * <pre>
 *  描述: 低功耗终端登录应答
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/30 9:46
 */
public class JT_8101 implements IWriteMessageBody {
    /**
     * 应答流水号 WORD
     */
    private int respFlowId;

    /**
     * 结果 BYTE
     * 0：成功；1：失败-参数错误；2：失败-指令不支持；3：失败-数据库中无该终端
     */
    private short respResult;

    /**
     * 参数总数 BYTE
     */
    private short paramCnt;

    /**
     * 参数列表
     */
    private List<ParamItem> paramList;

    @Override
    public byte[] writeToBytes() {
        int len = 4;
        if(paramList != null){
            for(ParamItem item : paramList){
                len += (3 + item.getParamLen());
            }
        }
        ByteBuf in = Unpooled.buffer(len);
        in.writeShort(getRespFlowId());
        in.writeByte(getRespResult());
        in.writeByte(getParamCnt());
        for(ParamItem item : paramList) {
            in.writeByte(Long.valueOf(item.getParamId()).intValue());
            short paramLen = item.getParamLen();
            in.writeShort(paramLen);
            String fileType = JT808Consts.LOW_POWER_FIELD_TYPE_MAP.get(Long.valueOf(item.getParamId()).intValue());
            if("BYTE".equals(fileType)) {
                in.writeByte(Short.parseShort(item.getParamVal().toString()));
            } else if("WORD".equals(fileType)) {
                in.writeShort(Short.parseShort(item.getParamVal().toString()));
            } else if("DWORD".equals(fileType)) {
                in.writeInt(Integer.parseInt(item.getParamVal().toString()));
            } else if("BCD".equals(fileType)) {
                byte[] val = BCD8421Operater.string2Bcd(item.getParamVal().toString());
                in.writeBytes(val, 0, val.length);
            } else if("STRING".equals(fileType)) {
                byte[] val = item.getParamVal().toString().getBytes(Constant.string_charset);
                in.writeBytes(val, 0, val.length);
            }
        }
        return in.array();
    }

    /**
     * 低功耗参数设置
     */
    public class ParamItem{
        /**
         * BYTE
         */
        private int paramId;

        /**
         * 参数值
         */
        private Object paramVal;

        public int getParamId() {
            return paramId;
        }

        public void setParamId(int paramId) {
            this.paramId = paramId;
        }

        public short getParamLen() {
            byte[] val = getParamVal().toString().getBytes(Constant.string_charset);
            String fileType = JT808Consts.LOW_POWER_FIELD_TYPE_MAP.get(Long.valueOf(getParamId()).intValue());
            if("BYTE".equals(fileType)){
                return (short)1;
            } else if("WORD".equals(fileType)){
                return (short)2;
            } else if("DWORD".equals(fileType)){
                return (short)4;
            } else if("STRING".equals(fileType)){
                return (short)val.length;
            } else if ("BCD".equals(fileType)) {
                return (short)8;
            }
            return 0;
        }

        public Object getParamVal() {
            return paramVal;
        }

        public void setParamVal(Object paramVal) {
            this.paramVal = paramVal;
        }

    }

    public int getRespFlowId() {
        return respFlowId;
    }

    public void setRespFlowId(int respFlowId) {
        this.respFlowId = respFlowId;
    }

    public short getRespResult() {
        return respResult;
    }

    public void setRespResult(short respResult) {
        this.respResult = respResult;
    }

    public short getParamCnt() {
        return paramCnt;
    }

    public void setParamCnt(short paramCnt) {
        this.paramCnt = paramCnt;
    }

    public List<ParamItem> getParamList() {
        return paramList;
    }

    public void setParamList(List<ParamItem> paramList) {
        this.paramList = paramList;
    }
}
