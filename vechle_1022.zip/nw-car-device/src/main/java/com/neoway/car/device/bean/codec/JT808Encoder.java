/**
 * @company 有方物联
 * @file JT808Encoder.java
 * @author guojy
 * @date 2018年4月12日
 */
package com.neoway.car.device.bean.codec;

import java.util.Arrays;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.neoway.car.device.bean.IWriteMessageBody;
import com.neoway.car.device.bean.MsgHeader;
import com.neoway.car.device.service.ICarDeviceService;
import com.neoway.car.device.util.Constant;
import com.neoway.util.hex.BitOperator;
import com.neoway.util.hex.HexStringUtils;
import com.neoway.util.hex.JT808ProtocolUtils;

/**
 * @description :平台下发消息时的编码器
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月12日
 */
@Component
@Slf4j
public class JT808Encoder {
    @Autowired
    private ICarDeviceService carDeviceService;

    /**
     * 平台下发指令时的编码逻辑
     * @param phone 终端手机号
     * @param msgBody 消息体
     * @param flowId 消息流水号
     * @param msgId 消息ID
     * @return byte[]
     */
    public byte[] encodePackage(String phone,IWriteMessageBody msgBody,int flowId,int msgId) {
        byte[] msgBodys = msgBody.writeToBytes();

        MsgHeader msgHeader = new MsgHeader();
        msgHeader.setMsgId(msgId);
        if(msgBodys == null) {
            msgHeader.setMsgBodyLength(0);
        } else{
            msgHeader.setMsgBodyLength(msgBodys.length);
        }
        msgHeader.setEncryptionType(0);
        msgHeader.setHasSubPackage(false);
        msgHeader.setReservedBit(0);
        int msgBodyProps = (msgHeader.getMsgBodyLength() & 0x3FF) | ((msgHeader.getEncryptionType() << 10) & 0x1C00) | ((msgHeader.isHasSubPackage()?1:0 << 13) & 0x2000)
                | ((msgHeader.getReservedBit() << 14) & 0xC000);
        msgHeader.setMsgBodyProps(msgBodyProps);
        msgHeader.setTerminalPhone(phone);
        msgHeader.setFlowId(flowId);
        byte[] msgHeaders = msgHeader.write2Bytes();

        byte[] headerAndBody = BitOperator.concatAll(msgHeaders, msgBodys);

        int checkSum = BitOperator.getCheckSum4JT808(headerAndBody, 0, headerAndBody.length);
        return doEncode(headerAndBody, checkSum,phone);
    }

    private byte[] doEncode(byte[] headerAndBody, int checkSum,String phone) {
        try {
            byte[] noEscapedBytes = BitOperator.concatAll(Arrays.asList(
                    new byte[] { Constant.pkg_delimiter }, // 0x7e
                    headerAndBody, // 消息头+ 消息体
                    BitOperator.integerTo1Bytes(checkSum), // 校验码
                    new byte[] { Constant.pkg_delimiter }// 0x7e
            ));
            //记录报文日志
            Thread.sleep(1);
            carDeviceService.recordEquPkgLog(phone, Constant.pkg_direct_down, HexStringUtils.toHexString(noEscapedBytes));
            // 转义
            return JT808ProtocolUtils.doEscape4Send(noEscapedBytes, 1, noEscapedBytes.length - 2);
        } catch (Exception e) {
            log.error("编码发生错误！", e);
            return null;
        }
    }
}
