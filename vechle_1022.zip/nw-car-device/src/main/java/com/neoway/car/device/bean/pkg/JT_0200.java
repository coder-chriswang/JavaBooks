/**
 * @company 有方物联
 * @file JT_0200.java
 * @author guojy
 * @date 2018年4月11日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.neoway.car.device.bean.IPositionAdditionalItem;
import com.neoway.car.device.bean.IReadMessageBody;
import com.neoway.car.device.bean.JT808PositionAdditionalFactory;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :终端位置上报
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class JT_0200 implements IReadMessageBody {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	/**
	 * 报警标志 DWord(32bit)
	 */
	private long alarmFlag;
	
	/**
	 * 状态 DWord(32bit)
	 */
	private long status;
	
	/**
	 * 纬度,DWord(32bit) 
	 * 以度为单位的纬度值乘以10的6次方，精确到百万分之一度
	 */
	private long latitude;
	
	/**
	 * 经度,DWord(32bit) 
	 * 以度为单位的经度值乘以10的6次方，精确到百万 分之一度
	 */
	private long longitude;

	/**
	 * 海拔高度，单位为米（m）Word(16bit) 
	 */
	private int altitude;
	
	/**
	 * 速度,1/10km/h  Word(16bit) 
	 */
	private int speed;
	
	/**
	 * 方向,0～359，正北为0，顺时针 Word(16bit) 
	 */
	private int course;
	
	/**
	 * 时间, BCD[6]  (48bit)
	 * YY-MM-DD-hh-mm-ss（GMT+8时间，本标准中之后涉及的时间均采用此时区）
	 */
	private String time;
	
	/**
	 * 附加位置信息
	 */
	private List<IPositionAdditionalItem> additionals;
	
	/* (non-Javadoc)
	 * @see com.etide.device.drivmirror.IMsgBody#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] msgBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(msgBodyBytes);
		this.setAlarmFlag(in.readUnsignedInt());
		this.setStatus(in.readUnsignedInt());
		this.setLatitude(in.readUnsignedInt());
		this.setLongitude(in.readUnsignedInt());
		this.setAltitude(in.readUnsignedShort());
		this.setSpeed(in.readUnsignedShort());
		this.setCourse(in.readUnsignedShort());
		//上报时间6字节 BCD[6]
		if(in.readableBytes() >= 6){
			StringBuilder timeBuilder = new StringBuilder();
			byte[] timeBytes = new byte[6];
			in.readBytes(timeBytes, 0, 6);
			timeBuilder.append("20")
			.append(String.format("%02X", timeBytes[0]))
			.append("-")
			.append(String.format("%02X", timeBytes[1]))
			.append("-")
			.append(String.format("%02X", timeBytes[2]))
			.append(" ")
			.append(String.format("%02X", timeBytes[3]))
			.append(":")
			.append(String.format("%02X", timeBytes[4]))
			.append(":")
			.append(String.format("%02X", timeBytes[5]));
			this.setTime(timeBuilder.toString());
			//附加位置信息
			this.setAdditionals(Lists.newArrayList());
			while(in.isReadable()){
				int additionalId = in.readUnsignedByte();//附加消息ID
				int additionalLength = in.readUnsignedByte();//附加消息长度
				byte[] additionalBytes = new byte[additionalLength];//附加消息
				in.readBytes(additionalBytes, 0, additionalLength);
				IPositionAdditionalItem item = JT808PositionAdditionalFactory.getPositionAdditional(additionalId, additionalBytes);
				if(item != null){
					this.getAdditionals().add(item);
				}else{
					logger.warn("未知的附加协议 协议ID：{} 协议长度：{}", Integer.toHexString(additionalId),additionalLength);
				}
			}
		}
	}


	public long getAlarmFlag() {
		return alarmFlag;
	}



	public void setAlarmFlag(long alarmFlag) {
		this.alarmFlag = alarmFlag;
	}



	public long getStatus() {
		return status;
	}



	public void setStatus(long status) {
		this.status = status;
	}



	public long getLatitude() {
		return latitude;
	}



	public void setLatitude(long latitude) {
		this.latitude = latitude;
	}



	public long getLongitude() {
		return longitude;
	}



	public void setLongitude(long longitude) {
		this.longitude = longitude;
	}



	public int getAltitude() {
		return altitude;
	}



	public void setAltitude(int altitude) {
		this.altitude = altitude;
	}



	public int getSpeed() {
		return speed;
	}



	public void setSpeed(int speed) {
		this.speed = speed;
	}



	public int getCourse() {
		return course;
	}



	public void setCourse(int course) {
		this.course = course;
	}



	public String getTime() {
		return time;
	}



	public void setTime(String time) {
		this.time = time;
	}



	/**
	 * @return the additionals
	 */
	public List<IPositionAdditionalItem> getAdditionals() {
		return additionals;
	}

	/**
	 * @param additionals the additionals to set
	 */
	public void setAdditionals(List<IPositionAdditionalItem> additionals) {
		this.additionals = additionals;
	}
	
	

}
