/**
 * @company 有方物联
 * @file JT_1206.java
 * @author bailu
 * @date 2018年8月13日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 文件上传完成通知
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年8月13日
 */
public class JT_1206 implements IReadMessageBody {
	/**
	 * 应答流水号 word(16bit)  
	 * 对应平台文件上传消息的流水号
	 */
	private int respFlowId;
	
	/**
	 * 结果  byte(8bit)
	 * 0：成功；1：失败；
	 */
	private short respResult;
	
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
		this.setRespFlowId(in.readUnsignedShort());
		this.setRespResult(in.readUnsignedByte());
	}

	/**
	 * @return the respFlowId
	 */
	public int getRespFlowId() {
		return respFlowId;
	}

	/**
	 * @param respFlowId the respFlowId to set
	 */
	public void setRespFlowId(int respFlowId) {
		this.respFlowId = respFlowId;
	}

	/**
	 * @return the respResult
	 */
	public short getRespResult() {
		return respResult;
	}

	/**
	 * @param respResult the respResult to set
	 */
	public void setRespResult(short respResult) {
		this.respResult = respResult;
	}

}
