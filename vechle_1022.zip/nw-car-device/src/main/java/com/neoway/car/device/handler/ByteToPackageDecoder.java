/**
 * @company 有方物联
 * @file ByteToPackageDecoder.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.handler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neoway.car.device.bean.PackageData;
import com.neoway.car.device.bean.codec.JT808Decoder;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

/**
 * @description :终端接入字节数据解码为java对象Bean：PackageData
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
public class ByteToPackageDecoder extends ByteToMessageDecoder {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private JT808Decoder jT808Decoder;
	/**
	 * 
	 */
	public ByteToPackageDecoder(JT808Decoder jT808Decoder) {
		this.jT808Decoder = jT808Decoder;
	}


	/* (non-Javadoc)
	 * @see io.netty.handler.codec.ByteToMessageDecoder#decode(io.netty.channel.ChannelHandlerContext, io.netty.buffer.ByteBuf, java.util.List)
	 */
	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
		if(in.readableBytes()<PackageData.PACKAGE_MIN_LEN){
			logger.warn("报文缺失！");
			return;
		}
		byte[] req = new byte[in.readableBytes()];
		in.readBytes(req);
		//解码
		PackageData packageData = jT808Decoder.bytes2PackageData(req);
		if(packageData != null && packageData.isFullPkg()){
			out.add(packageData);
		}
	}

}
