/**
 * @company 有方物联
 * @file JT_8604.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 设置多边形区域
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8604 implements IWriteMessageBody {
	/**
	 * 区域ID DWORD
	 */
	private long areaId;
	
	/**
	 * 区域属性 WORD   808协议表58
	 */
	private int areaAttr;
	
	/**
	 * 起始时间 BCD[6]
	 * 区域属性0位为0则没有该字段
	 */
	private String startTime;

	/**
	 * 结束时间 BCD[6]
	 * 区域属性0位为0则没有该字段
	 */
	private String endTime;
	
	/**
	 * 最高速度 WORD
	 * 区域属性1位为0则没有该字段
	 */
	private int speed;
	
	/**
	 * 超速持续时间 BYTE
	 * 区域属性1位为0则没有该字段
	 */
	private short duration;
	
	/**
	 * 区域总顶点数
	 */
	private int pointNum;
	/**
	 * 顶点项
	 */
	private List<Item> itemList;
	
	@Override
	public byte[] writeToBytes() {
		int size = 8;
		int timeFlag = areaAttr & 0x1;//0000 0000 0000 0001
		if(timeFlag ==1){
			size += 12;
		}
		int speedFlag = areaAttr >> 1 & 0x1;//0000 0000 0000 0010
		if(speedFlag == 1){
			size += 3;
		}
		ByteBuf in = Unpooled.buffer(size+itemList.size()*8);
		in.writeInt(Long.valueOf(this.getAreaId()).intValue());
		in.writeShort(this.getAreaAttr());
		if(timeFlag == 1){
			//0位为1
			in.writeByte(Byte.parseByte(this.getStartTime().substring(0, 2),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(2, 4),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(4, 6),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(6, 8),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(8, 10),16));
			in.writeByte(Byte.parseByte(this.getStartTime().substring(10, 12),16));
			
			in.writeByte(Byte.parseByte(this.getEndTime().substring(0, 2),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(2, 4),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(4, 6),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(6, 8),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(8, 10),16));
			in.writeByte(Byte.parseByte(this.getEndTime().substring(10, 12),16));
		}
		if(speedFlag == 1){
			in.writeShort(this.getSpeed());
			in.writeByte(this.getDuration());
		}
		in.writeShort(this.getPointNum());
		if(this.getPointNum() > 0){
			for(Item item:itemList){
				in.writeInt(Long.valueOf(item.getLat()).intValue());
				in.writeInt(Long.valueOf(item.getLng()).intValue());
			}
		}
		return in.array();
	}
	
	/**
	 * @description :顶点项
	 * @author : guojy
	 * @version : V1.0.0
	 * @date : 2018年5月3日
	 */
	public class Item{
		/**
		 * 顶点纬度 DWORD
		 */
		private long lat;
		
		/**
		 * 顶点经度 DWORD
		 */
		private long lng;
		

		/**
		 * @param lat
		 * @param lng
		 */
		public Item(long lat, long lng) {
			this.lat = lat;
			this.lng = lng;
		}

		/**
		 * @return the lat
		 */
		public long getLat() {
			return lat;
		}

		/**
		 * @param lat the lat to set
		 */
		public void setLat(long lat) {
			this.lat = lat;
		}

		/**
		 * @return the lng
		 */
		public long getLng() {
			return lng;
		}

		/**
		 * @param lng the lng to set
		 */
		public void setLng(long lng) {
			this.lng = lng;
		}
		
	}

	/**
	 * @return the areaId
	 */
	public long getAreaId() {
		return areaId;
	}

	/**
	 * @param areaId the areaId to set
	 */
	public void setAreaId(long areaId) {
		this.areaId = areaId;
	}

	/**
	 * @return the areaAttr
	 */
	public int getAreaAttr() {
		return areaAttr;
	}

	/**
	 * @param areaAttr the areaAttr to set
	 */
	public void setAreaAttr(int areaAttr) {
		this.areaAttr = areaAttr;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the speed
	 */
	public int getSpeed() {
		return speed;
	}

	/**
	 * @param speed the speed to set
	 */
	public void setSpeed(int speed) {
		this.speed = speed;
	}

	/**
	 * @return the duration
	 */
	public short getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(short duration) {
		this.duration = duration;
	}

	/**
	 * @return the pointNum
	 */
	public int getPointNum() {
		return pointNum;
	}

	/**
	 * @param pointNum the pointNum to set
	 */
	public void setPointNum(int pointNum) {
		this.pointNum = pointNum;
	}

	/**
	 * @return the itemList
	 */
	public List<Item> getItemList() {
		return itemList;
	}

	/**
	 * @param itemList the itemList to set
	 */
	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}
	
	

}
