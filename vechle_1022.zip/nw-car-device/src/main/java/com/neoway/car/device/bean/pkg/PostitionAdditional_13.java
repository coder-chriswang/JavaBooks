/**
 * @company 有方物联
 * @file PostitionAdditional_13.java
 * @author guojy
 * @date 2018年4月24日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :路段行驶时间不足/过长报警附加信息
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月24日
 */
public class PostitionAdditional_13 implements IPositionAdditionalItem {
	/**
	 * 路段ID
	 */
	private long roadId;
	/**
	 * 路段行驶时间
	 */
	private int drivingTime;
	/**
	 * 结果
	 */
	private short result;
	@Override
	public int getAdditionalId() {
		return 0x13;
	}

	@Override
	public byte getAdditionalLength() {
		return 0x7;
	}

	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(7);
		in.writeInt(Long.valueOf(this.getRoadId()).intValue());
		in.writeShort(this.getDrivingTime());
		in.writeByte(this.getResult());
		return in.array();
	}

	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		this.setRoadId(in.readUnsignedInt());
		this.setDrivingTime(in.readUnsignedShort());
		this.setResult(in.readUnsignedByte());
	}

	/**
	 * @return the roadId
	 */
	public long getRoadId() {
		return roadId;
	}

	/**
	 * @param roadId the roadId to set
	 */
	public void setRoadId(long roadId) {
		this.roadId = roadId;
	}

	/**
	 * @return the drivingTime
	 */
	public int getDrivingTime() {
		return drivingTime;
	}

	/**
	 * @param drivingTime the drivingTime to set
	 */
	public void setDrivingTime(int drivingTime) {
		this.drivingTime = drivingTime;
	}

	/**
	 * @return the result
	 */
	public short getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(short result) {
		this.result = result;
	}

	
	
}
