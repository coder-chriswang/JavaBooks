/**
 * @company 有方物联
 * @file DeviceServer.java
 * @author guojy
 * @date 2017年9月26日 
 */
package com.neoway.car.device.boot;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.socket.nio.NioDatagramChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.neoway.car.device.handler.CarChannelInitializer;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.util.concurrent.Future;

/**
 * @description :服务启动包装
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月26日
 */
@Component
public class DeviceServer {
	private Logger logger = LoggerFactory.getLogger(getClass());
	private volatile boolean isRunning = false;
	private EventLoopGroup bossGroup = null;
	private EventLoopGroup workerGroup = null;
	/**
	 * 服务端口
	 */
	@Value("${device.protocol.port}")
	private int port;
	/**
	 * 服务名
	 */
	private String serverName = "车联网服务";

	/**
	 * Channel初始化实现
	 */
	@Autowired
	private CarChannelInitializer carChannelInitializer;

	/**
	 * 启动服务
	 */
	@PostConstruct
	public synchronized void startServer() {
		if (this.isRunning) {
			throw new IllegalStateException(this.getName() + " is already started .");
		}
		this.isRunning = true;

		new Thread(() -> {
			try {
				this.bind();
			} catch (Exception e) {
				logger.info("{}服务启动出错:{}", this.getName(),e.getMessage());
				e.printStackTrace();
			}
		}, this.getName()).start();
		new Thread(() -> {
			try {
				this.bindUdp();
			} catch (Exception e) {
				logger.error("{}服务启动出错:{}", this.getName(),e.getMessage());
			}

		}, this.getName()).start();
	}

	/**
	 * 关闭服务
	 */
	@PreDestroy
	public synchronized void stopServer() {
		if (!this.isRunning) {
			throw new IllegalStateException(this.getName() + " is not yet started .");
		}
		this.isRunning = false;

		try {
			Future<?> future = this.workerGroup.shutdownGracefully().await();
			if (!future.isSuccess()) {
				logger.error("workerGroup 无法正常停止:{}", future.cause());
			}

			future = this.bossGroup.shutdownGracefully().await();
			if (!future.isSuccess()) {
				logger.error("bossGroup 无法正常停止:{}", future.cause());
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		logger.info("{}服务已经停止...",this.getName());
	}

	private void bind() throws InterruptedException {
		this.bossGroup = new NioEventLoopGroup();
		this.workerGroup = new NioEventLoopGroup();
		ServerBootstrap serverBootstrap = new ServerBootstrap();
		serverBootstrap.group(bossGroup, workerGroup)//
				.channel(NioServerSocketChannel.class)
				.childHandler(carChannelInitializer)
				.option(ChannelOption.SO_BACKLOG, 128)
				.childOption(ChannelOption.SO_KEEPALIVE, true);

		logger.info("{}服务启动完毕,port={}", this.getName(),this.port);
		ChannelFuture channelFuture = serverBootstrap.bind(port).sync();

		channelFuture.channel().closeFuture().sync();
	}

	private void bindUdp() throws InterruptedException {
		try {
			EventLoopGroup workGroup = new NioEventLoopGroup();
			Bootstrap bootstrap = new Bootstrap();
			bootstrap.group(workGroup)
					.channel(NioDatagramChannel.class)
					// 支持广播
					.option(ChannelOption.SO_BROADCAST, true)
					.option(ChannelOption.SO_BACKLOG, 128)
					// 设置UDP读缓冲区为1M
					.option(ChannelOption.SO_RCVBUF, 1024 * 1024)
					// 设置UDP写缓冲区为1M
					.option(ChannelOption.SO_SNDBUF, 1024 * 1024)
					.handler(carChannelInitializer);

			logger.info("{}服务启动UDP完毕,port={}", this.getName(),9091);
			bootstrap.bind(9091).sync().channel().closeFuture().await();
		} finally {
			workerGroup.shutdownGracefully();
			System.out.println("UDP 关闭了");
		}
	}

	public String getName() {
		return this.serverName;
	}
	
}
