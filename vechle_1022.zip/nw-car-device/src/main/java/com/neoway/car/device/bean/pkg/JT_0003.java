/**
 * @company 有方物联
 * @file JT_0003.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

/**
 * @description : 终端注销
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_0003 implements IReadMessageBody {

	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		
	}

}
