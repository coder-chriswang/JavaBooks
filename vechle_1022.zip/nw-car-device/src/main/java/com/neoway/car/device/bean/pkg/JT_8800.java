/**
 * @company 有方物联
 * @file JT_8800.java
 * @author guojy
 * @date 2018年7月3日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :JT-多媒体数据上传应答
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月3日
 */
public class JT_8800 implements IWriteMessageBody {
	/**
	 * 多媒体ID DWORD
	 */
	private long mediaId;
	/**
	 * BYTE 重传包总数
	 */
	private short reuploadPkgNum;
	/**
	 * BYTE[2*n] 重传包列表
	 */
	private List<Integer> pkgSeqs;
	
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IWriteMessageBody#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		int len = 4 + reuploadPkgNum * 2 + (reuploadPkgNum == 0?0:1);
		ByteBuf in = Unpooled.buffer(len);
		in.writeInt(Long.valueOf(this.getMediaId()).intValue());
		if(reuploadPkgNum > 0){
			in.writeByte(this.getReuploadPkgNum());
			for(int i = 0;i < reuploadPkgNum;i++){
				int pkgSeq  = pkgSeqs.get(i);
				in.writeShort(pkgSeq);
			}
		}
		return in.array();
	}
	/**
	 * @return the mediaId
	 */
	public long getMediaId() {
		return mediaId;
	}
	/**
	 * @param mediaId the mediaId to set
	 */
	public void setMediaId(long mediaId) {
		this.mediaId = mediaId;
	}
	/**
	 * @return the reuploadPkgNum
	 */
	public short getReuploadPkgNum() {
		return reuploadPkgNum;
	}
	/**
	 * @param reuploadPkgNum the reuploadPkgNum to set
	 */
	public void setReuploadPkgNum(short reuploadPkgNum) {
		this.reuploadPkgNum = reuploadPkgNum;
	}
	/**
	 * @return the pkgSeqs
	 */
	public List<Integer> getPkgSeqs() {
		return pkgSeqs;
	}
	/**
	 * @param pkgSeqs the pkgSeqs to set
	 */
	public void setPkgSeqs(List<Integer> pkgSeqs) {
		this.pkgSeqs = pkgSeqs;
	}

	
}
