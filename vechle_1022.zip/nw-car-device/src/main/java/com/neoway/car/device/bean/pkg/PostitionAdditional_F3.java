package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * <pre>
 *  描述: OBD扩展终端内置电池电压 BYTE 单位：0.1V
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/03 20:21
 */
public class PostitionAdditional_F3 implements IPositionAdditionalItem {

    private short terminalBatteryVoltage;

    @Override
    public int getAdditionalId() {
        return 0xF3;
    }

    @Override
    public byte getAdditionalLength() {
        return 0x1;
    }

    @Override
    public byte[] writeToBytes() {
        ByteBuf in = Unpooled.buffer(1);
        in.writeByte(getTerminalBatteryVoltage());
        return in.array();
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        setTerminalBatteryVoltage(in.readUnsignedByte());
    }

    public short getTerminalBatteryVoltage() {
        return terminalBatteryVoltage;
    }

    public void setTerminalBatteryVoltage(short terminalBatteryVoltage) {
        this.terminalBatteryVoltage = terminalBatteryVoltage;
    }
}
