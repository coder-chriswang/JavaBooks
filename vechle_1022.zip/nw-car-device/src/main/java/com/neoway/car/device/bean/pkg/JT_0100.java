package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;

/**
 * @description :终端注册
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月11日
 */
public class JT_0100 implements IReadMessageBody {

	/**
	 * 省域ID
	 */
	private short provinceId;
	/**
	 * 市、县域ID
	 */
	private short cityId;
	/**
	 * 制造商ID
	 */
	private String manufactureId;
	
	/**
	 * 终端型号
	 */
	private String terminalModelNo;
	
	/**
	 * 终端ID
	 */
	private String terminalId;
	
	/**
	 * 车牌颜色
	 */
	private byte plateColor = 0;
	
	/**
	 * 车牌号码
	 */
	private String licenseNo;

	public final short getProvinceId() {
		return provinceId;
	}

	public final void setProvinceId(short value) {
		provinceId = value;
	}


	public final short getCityId() {
		return cityId;
	}

	public final void setCityId(short value) {
		cityId = value;
	}


	public final String getManufactureId() {
		return manufactureId;
	}

	public final void setManufactureId(String value) {
		manufactureId = value;
	}


	public final String getTerminalModelNo() {
		return terminalModelNo;
	}

	public final void setTerminalModelNo(String value) {
		terminalModelNo = value;
	}


	public final String getTerminalId() {
		return terminalId;
	}

	public final void setTerminalId(String value) {
		terminalId = value;
	}

	public final byte getPlateColor() {
		return plateColor;
	}

	public final void setPlateColor(byte value) {
		plateColor = value;
	}


	public final String getLicenseNo() {
		return licenseNo;
	}

	public final void setLicenseNo(String value) {
		licenseNo = value;
	}

	@Override
	public String toString() {
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append(String.format(
				"省:%1$s,市:%2$s,制造商:%3$s,型号:%4$s,终端:%5$s,车牌颜色:%6$s,车牌号:%7$s",
				getProvinceId(), getCityId(), getManufactureId(),
				getTerminalModelNo(), getTerminalId(), getPlateColor(),
				getLicenseNo()));
		return sBuilder.toString();
	}

	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		
	}
}
