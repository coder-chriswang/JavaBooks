/**
 * @company 有方物联
 * @file PackageData.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.bean;

/**
 * @description :JT808 部标协议报
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
public class PackageData {
	public static int PACKAGE_MIN_LEN = 13;
	/**
	 * 是否完整报文
	 */
	protected boolean isFullPkg;
	/**
	 * 12/16 byte 消息头
	 */
	protected MsgHeader msgHeader;
	/**
	 * 消息体
	 */
	protected IReadMessageBody messageBody;
	/**
	 * 校验码 1byte
	 */
	protected int checkSum;
	/**
	 * @return the msgHeader
	 */
	public MsgHeader getMsgHeader() {
		return msgHeader;
	}
	/**
	 * @param msgHeader the msgHeader to set
	 */
	public void setMsgHeader(MsgHeader msgHeader) {
		this.msgHeader = msgHeader;
	}
	/**
	 * @return the messageBody
	 */
	public IReadMessageBody getMessageBody() {
		return messageBody;
	}
	/**
	 * @param messageBody the messageBody to set
	 */
	public void setMessageBody(IReadMessageBody messageBody) {
		this.messageBody = messageBody;
	}
	/**
	 * @return the checkSum
	 */
	public int getCheckSum() {
		return checkSum;
	}
	/**
	 * @param checkSum the checkSum to set
	 */
	public void setCheckSum(int checkSum) {
		this.checkSum = checkSum;
	}
	/**
	 * @return the isFullPkg
	 */
	public boolean isFullPkg() {
		return isFullPkg;
	}
	/**
	 * @param isFullPkg the isFullPkg to set
	 */
	public void setFullPkg(boolean isFullPkg) {
		this.isFullPkg = isFullPkg;
	}
	
	
}
