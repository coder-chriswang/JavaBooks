package com.neoway.car.device.bean.terminal;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 查询指定终端参数实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/02 17:56
 */
@Data
public class TerminalParamsById implements Serializable {
    private static final long serialVersionUID = -5057103205897485880L;

    /**
     * id数量
     */
    private int idNum;

    /**
     * id字符组
     */
    private String ids;

    /**
     * 设备号
     */
    private String equId;

    /**
     * 终端电话
     */
    private String phone;
}
