/**
 * @company 有方物联
 * @file JT_0107.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IReadMessageBody;
import com.neoway.car.device.util.Constant;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 查询终端属性应答
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_0107 implements IReadMessageBody {
	/**
	 * WORD 终端类型
	 */
	private int terminalType;
	/**
	 * BYTE[5] 制造商ID
	 */
	private String manufactureId;
	/**
	 * BYTE[20] 终端型号
	 */
	private String terminalModelNo;
	/**
	 * BYTE[7] 终端ID
	 */
	private String terminalId;
	/**
	 * BCD[10] 终端SIM卡ICCID
	 */
	private String terminalSimCard;
	/**
	 * BYTE 终端版本号长度
	 */
	private short terminalVersionLength;
	/**
	 * STRING 终端硬件版本号
	 */
	private String terminalVersion;
	/**
	 * BYTE 终端固件版本号长度
	 */
	private short terminalFirmwareVersionLength;
	/**
	 * STRING 终端固件版本号
	 */
	private String terminalFirmwareVersion;
	/**
	 * BYTE GNSS模块属性
	 */
	private short gnssProperty;
	/**
	 * BYTE 通讯模块属性
	 */
	private short communicatingModule;
	@Override
	public void readFromBytes(byte[] messageBodyBytes) {
		ByteBuf in = Unpooled.copiedBuffer(messageBodyBytes);
		this.setTerminalType(in.readUnsignedShort());
		
		byte[] manufactureId = new byte[5];
		in.readBytes(manufactureId);
		this.setManufactureId(new String(manufactureId,Constant.string_charset));
		
		byte[] terminalModelNo = new byte[20];
		in.readBytes(terminalModelNo);
		this.setTerminalModelNo(new String(terminalModelNo,Constant.string_charset));
		
		byte[] terminalId = new byte[7];
		in.readBytes(terminalId);
		this.setTerminalId(new String(terminalId,Constant.string_charset));
		
		byte[] terminalSimCard = new byte[10];
		in.readBytes(terminalSimCard);
		this.setTerminalSimCard(String.format("%02X", terminalSimCard[0])
							   +String.format("%02X", terminalSimCard[1])
							   +String.format("%02X", terminalSimCard[2])
							   +String.format("%02X", terminalSimCard[3])
							   +String.format("%02X", terminalSimCard[4])
							   +String.format("%02X", terminalSimCard[5])
							   +String.format("%02X", terminalSimCard[6])
							   +String.format("%02X", terminalSimCard[7])
							   +String.format("%02X", terminalSimCard[8])
							   +String.format("%02X", terminalSimCard[9]));
		
		this.setTerminalVersionLength(in.readUnsignedByte());
		
		byte[] terminalVersion = new byte[this.getTerminalVersionLength()];
		in.readBytes(terminalVersion);
		this.setTerminalVersion(new String(terminalVersion,Constant.string_charset));
		
		this.setTerminalFirmwareVersionLength(in.readUnsignedByte());
		
		byte[] terminalFirmwareVersion = new byte[this.getTerminalFirmwareVersionLength()];
		in.readBytes(terminalFirmwareVersion);
		this.setTerminalFirmwareVersion(new String(terminalFirmwareVersion,Constant.string_charset));
		
		this.setGnssProperty(in.readUnsignedByte());
		this.setCommunicatingModule(in.readUnsignedByte());
		
	}
	/**
	 * @return the terminalType
	 */
	public int getTerminalType() {
		return terminalType;
	}
	/**
	 * @param terminalType the terminalType to set
	 */
	public void setTerminalType(int terminalType) {
		this.terminalType = terminalType;
	}
	/**
	 * @return the manufactureId
	 */
	public String getManufactureId() {
		return manufactureId;
	}
	/**
	 * @param manufactureId the manufactureId to set
	 */
	public void setManufactureId(String manufactureId) {
		this.manufactureId = manufactureId;
	}
	/**
	 * @return the terminalModelNo
	 */
	public String getTerminalModelNo() {
		return terminalModelNo;
	}
	/**
	 * @param terminalModelNo the terminalModelNo to set
	 */
	public void setTerminalModelNo(String terminalModelNo) {
		this.terminalModelNo = terminalModelNo;
	}
	/**
	 * @return the terminalId
	 */
	public String getTerminalId() {
		return terminalId;
	}
	/**
	 * @param terminalId the terminalId to set
	 */
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}
	/**
	 * @return the terminalSimCard
	 */
	public String getTerminalSimCard() {
		return terminalSimCard;
	}
	/**
	 * @param terminalSimCard the terminalSimCard to set
	 */
	public void setTerminalSimCard(String terminalSimCard) {
		this.terminalSimCard = terminalSimCard;
	}
	/**
	 * @return the terminalVersionLength
	 */
	public short getTerminalVersionLength() {
		return terminalVersionLength;
	}
	/**
	 * @param terminalVersionLength the terminalVersionLength to set
	 */
	public void setTerminalVersionLength(short terminalVersionLength) {
		this.terminalVersionLength = terminalVersionLength;
	}
	/**
	 * @return the terminalVersion
	 */
	public String getTerminalVersion() {
		return terminalVersion;
	}
	/**
	 * @param terminalVersion the terminalVersion to set
	 */
	public void setTerminalVersion(String terminalVersion) {
		this.terminalVersion = terminalVersion;
	}
	/**
	 * @return the terminalFirmwareVersionLength
	 */
	public short getTerminalFirmwareVersionLength() {
		return terminalFirmwareVersionLength;
	}
	/**
	 * @param terminalFirmwareVersionLength the terminalFirmwareVersionLength to set
	 */
	public void setTerminalFirmwareVersionLength(short terminalFirmwareVersionLength) {
		this.terminalFirmwareVersionLength = terminalFirmwareVersionLength;
	}
	/**
	 * @return the terminalFirmwareVersion
	 */
	public String getTerminalFirmwareVersion() {
		return terminalFirmwareVersion;
	}
	/**
	 * @param terminalFirmwareVersion the terminalFirmwareVersion to set
	 */
	public void setTerminalFirmwareVersion(String terminalFirmwareVersion) {
		this.terminalFirmwareVersion = terminalFirmwareVersion;
	}
	/**
	 * @return the gnssProperty
	 */
	public short getGnssProperty() {
		return gnssProperty;
	}
	/**
	 * @param gnssProperty the gnssProperty to set
	 */
	public void setGnssProperty(short gnssProperty) {
		this.gnssProperty = gnssProperty;
	}
	/**
	 * @return the communicatingModule
	 */
	public short getCommunicatingModule() {
		return communicatingModule;
	}
	/**
	 * @param communicatingModule the communicatingModule to set
	 */
	public void setCommunicatingModule(short communicatingModule) {
		this.communicatingModule = communicatingModule;
	}

	
}
