package com.neoway.car.device.bean.pkg;

import com.google.common.collect.Lists;
import com.neoway.car.device.bean.IPassThroughMessage;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.util.List;

/**
 * <pre>
 *  描述: 故障码数据包消息结构体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/16 17:18
 */
public class PassThroughMessage_F4 implements IPassThroughMessage {

    /**
     * 时间
     */
    private String time;

    /**
     * 故障码个数
     */
    private short troubleCodeCount;

    /**
     * 故障码
     */
    List<Integer> troubleCodeList;

    @Override
    public int getMessageId() {
        return 0xF4;
    }

    @Override
    public byte getMessageLength() {

        return (byte)(6 + getTroubleCodeCount() + 2 * getTroubleCodeCount());
    }

    @Override
    public byte[] writeToBytes() {
        return null;
    }

    @Override
    public void readFromBytes(byte[] bytes) {
        ByteBuf in = Unpooled.copiedBuffer(bytes);
        StringBuilder timeBuilder = new StringBuilder();
        byte[] timeBytes = new byte[6];
        in.readBytes(timeBytes, 0, 6);
        timeBuilder.append("20")
                .append(String.format("%02X", timeBytes[0]))
                .append("-")
                .append(String.format("%02X", timeBytes[1]))
                .append("-")
                .append(String.format("%02X", timeBytes[2]))
                .append(" ")
                .append(String.format("%02X", timeBytes[3]))
                .append(":")
                .append(String.format("%02X", timeBytes[4]))
                .append(":")
                .append(String.format("%02X", timeBytes[5]));
        setTime(timeBuilder.toString());
        setTroubleCodeCount(in.readUnsignedByte());
        setTroubleCodeList(Lists.newArrayList());
        for (int i = 0; i < getTroubleCodeCount(); i++) {
            int troubleCode = in.readUnsignedShort();
            getTroubleCodeList().add(troubleCode);
        }
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public short getTroubleCodeCount() {
        return troubleCodeCount;
    }

    public void setTroubleCodeCount(short troubleCodeCount) {
        this.troubleCodeCount = troubleCodeCount;
    }

    public List<Integer> getTroubleCodeList() {
        return troubleCodeList;
    }

    public void setTroubleCodeList(List<Integer> troubleCodeList) {
        this.troubleCodeList = troubleCodeList;
    }
}
