/**
 * @company 有方物联
 * @file CarChannelInitializer.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.handler;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.neoway.car.device.bean.codec.JT808Decoder;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.timeout.IdleStateHandler;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
@Component
public class CarChannelInitializer extends ChannelInitializer<Channel> {
	@Autowired
	private CarServerHandler carServerHandler;
	@Autowired
	private JT808Decoder jT808Decoder;
	/* (non-Javadoc)
	 * @see io.netty.channel.ChannelInitializer#initChannel(io.netty.channel.Channel)
	 */
	@Override
	protected void initChannel(Channel ch) throws Exception {
		final byte[] delimit = new byte[]{0x7e};
		ByteBuf delimiter = Unpooled.copiedBuffer(delimit);
		ch.pipeline().addLast("idleStateHandler",
				new IdleStateHandler(3, 0, 0, TimeUnit.MINUTES));
		ch.pipeline().addLast(new DelimiterBasedFrameDecoder(2048, delimiter));
		ch.pipeline().addLast(new ByteToPackageDecoder(jT808Decoder));
		ch.pipeline().addLast(carServerHandler);
	}

}
