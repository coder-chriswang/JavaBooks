/**
 * @company 有方物联
 * @file PostitionAdditional_16.java
 * @author guojy
 * @date 2018年7月2日 
 */
package com.neoway.car.device.bean.pkg;

/**
 * @description :视频信号遮挡状态
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月2日
 */
public class PostitionAdditional_16 extends PostitionAdditional_15 {
	
	@Override
	public int getAdditionalId() {
		return 0x16;
	}

}
