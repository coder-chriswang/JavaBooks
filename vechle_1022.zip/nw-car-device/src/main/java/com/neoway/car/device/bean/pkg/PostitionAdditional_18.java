/**
 * @company 有方物联
 * @file PostitionAdditional_18.java
 * @author guojy
 * @date 2018年7月2日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

/**
 * @description :异常驾驶行为报警
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月2日
 */
public class PostitionAdditional_18 implements IPositionAdditionalItem {

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x18;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x2;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
	}

}
