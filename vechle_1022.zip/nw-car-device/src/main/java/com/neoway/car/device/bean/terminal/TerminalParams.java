package com.neoway.car.device.bean.terminal;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 终端参数设置实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/02 10:00
 */
@Data
public class TerminalParams implements Serializable {

    private static final long serialVersionUID = 55609618383292021L;

    /**
     * 设备id
     */
    private String equId;

    /**
     * 终端电话
     */
    private String phone;

    /**
     * 参数长度
     */
    private Integer paramCount;

    /**
     * 心跳间隔（s）
     */
    private Long heartBeat;

    /**
     * 拨号地址
     */
    private String dialAddress;

    /**
     * 服务器地址
     */
    private String serverAddress;

    /**
     * TCP端口
     */
    private Long tcpPort;

    /**
     * 位置上报策略（0：定时汇报；1：定居汇报；2：定时定距汇报）
     */
    private Long locationReportStrategy;

    /**
     * 休眠汇报时间间隔（s）
     */
    private Long sleepTimeReport;

    /**
     * 缺省时间汇报间隔
     */
    private Long defaultTimeReport;

    /**
     * 缺省距离汇报间隔
     */
    private Long defaultDistanceReport;

    /**
     * 最高速度（km/h）
     */
    private Long maxSpeed;

    /**
     * 超速持续时间（s）
     */
    private Long overSpeedLastTime;

    /**
     * 连续驾驶时间（s）
     */
    private Long driverLastTime;

    /**
     * 最小休息时间（s）
     */
    private Long minBreakTime;

    /**
     * 碰撞报警参数设置
     */
    private Integer knockAlarmParam;

    /**
     * 侧翻报警参数设置
     */
    private Integer rolloverAlarmParam;

    /**
     * 里程表读数（1/10 km）
     */
    private Long odometerNum;

    /**
     * 省域id
     */
    private Integer provinceId;

    /**
     * 市域id
     */
    private Integer cityId;

    /**
     * 机动车车牌号
     */
    private String carNum;

    /**
     * 机动车颜色
     */
    private Short carColor;

    /**
     * GNSS定位模式
     */
    private Short gnssModel;

    /**
     * 急加速参数
     */
    private Short acceleration;

    /**
     * 急减速参数
     */
    private Short deAcceleration;

    /**
     * 急转弯
     */
    private Short sharpTurn;

    /**
     * 急变道参数
     */
    private Short suddenChangePath;

    /**
     * ETC低温告警阈值
     */
    private Integer etcLowTemperatureAlarm;

    /**
     * ETC高温告警阈值
     */
    private Integer etcHighTemperatureAlarm;

    /**
     * RPM告警阈值
     */
    private Integer rpmAlarm;

    /**
     * 低电压报警参数（0.1V）
     */
    private Integer lowVoltageAlarm;

    /**
     * 怠速报警参数
     */
    private String idlingAlarm;

    /**
     * 里程计算系数（默认100，设置值/100）
     */
    private Integer mileageCalculatingCoefficient;

    /**
     * 油耗计算系数（默认100，设置值/100）
     */
    private Integer oilCalculatingCoefficient;

    /**
     * 排量（默认16，设置值/10）
     */
    private Integer displacement;

    /**
     * 油品类型
     */
    private Integer oilType;

    /**
     * WIFI参数
     */
    private String wifi;

}
