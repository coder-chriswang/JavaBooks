/**
 * @company neoway
 * @file Application.java
 * @author guojy
 * @date 2019年3月26日
 */
package com.neoway.car.device;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ImportResource;

import com.neoway.car.device.boot.ShutdownHook;

/**
 * @description JT808接入服务boot
 * @author guojy
 * @version V1.0.0
 * @date 2019年03月26日 10:24:09
 */
@ImportResource("classpath*:application-*.xml")
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class,HibernateJpaAutoConfiguration.class},scanBasePackages={"com.neoway"})
public class Application {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ConfigurableApplicationContext application = new SpringApplicationBuilder(Application.class).web(true).run(args);
		//处理程序退出时设备离线、关闭容器
		Runtime.getRuntime().addShutdownHook(new Thread(new ShutdownHook(application)));
	}

}
