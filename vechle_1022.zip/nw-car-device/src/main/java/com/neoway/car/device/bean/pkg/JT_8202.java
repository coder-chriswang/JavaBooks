/**
 * @company 有方物联
 * @file JT_8202.java
 * @author guojy
 * @date 2018年4月24日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :临时位置跟踪控制
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月24日
 */
public class JT_8202 implements IWriteMessageBody {
	/**
	 * 时间间隔
	 * 单位为秒（s），0 则停止跟踪。停止跟踪无需带后继字段
	 */
	private int timeInterval;
	/**
	 * 位置跟踪有效期
	 * 单位为秒（s），终端在接收到位置跟踪控制消息后，在有效期截止时间之前，依据消息中的时间间隔发送位置汇报
	 */
	private long validDate;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IWriteMessageBody#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(timeInterval == 0?2:6);
		in.writeShort(this.getTimeInterval());
		if(timeInterval > 0){
			in.writeInt(Long.valueOf(this.getValidDate()).intValue());
		}
		return in.array();
	}
	/**
	 * @return the timeInterval
	 */
	public int getTimeInterval() {
		return timeInterval;
	}
	/**
	 * @param timeInterval the timeInterval to set
	 */
	public void setTimeInterval(int timeInterval) {
		this.timeInterval = timeInterval;
	}
	/**
	 * @return the validDate
	 */
	public long getValidDate() {
		return validDate;
	}
	/**
	 * @param validDate the validDate to set
	 */
	public void setValidDate(long validDate) {
		this.validDate = validDate;
	}

	
}
