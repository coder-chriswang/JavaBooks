/**
 * @company 有方物联
 * @file PostitionAdditional_15.java
 * @author guojy
 * @date 2018年7月2日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.google.common.collect.Lists;
import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :视频信号丢失状态
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年7月2日
 */
public class PostitionAdditional_15 implements IPositionAdditionalItem {
	private List<Integer> alarmChannels = Lists.newArrayList();
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x15;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		return 0x4;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		long state = in.readUnsignedInt();
		for(int i=0;i<32;i++){
			byte flag = convert(state, i);
			if(flag == 1){
				alarmChannels.add(i+1);
			}
		}
	}

	protected static byte convert(long state, int pos){
	    return (byte)(state >> pos & 1);
	}

	/**
	 * @return the alarmChannels
	 */
	public List<Integer> getAlarmChannels() {
		return alarmChannels;
	}

	
}
