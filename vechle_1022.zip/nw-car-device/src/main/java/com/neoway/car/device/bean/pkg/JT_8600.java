/**
 * @company 有方物联
 * @file JT_8600.java
 * @author bailu
 * @date 2018年4月16日 
 */
package com.neoway.car.device.bean.pkg;

import java.util.List;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 设置圆形区域
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8600 implements IWriteMessageBody {
	/**
	 * byte 设置属性
	 */
	private short attr;
	/**
	 * byte 区域总数
	 */
	private short areaCnt;
	
	/**
	 * 区域项
	 */
	private List<Item> itemList;
	@Override
	public byte[] writeToBytes() {
		int size = 2;//包长
		if(this.getAreaCnt() > 0){
			for(Item item:itemList){
				size += 18;
				int areaAttr = item.getAreaAttr();
				int timeFlag = areaAttr & 0x1;//0000 0000 0000 0001
				if(timeFlag == 1){
					//0位为1
					size += 12;
				}
				int speedFlag = areaAttr >> 1 & 0x1;//0000 0000 0000 0010
				if(speedFlag == 1){
					//1位为1
					size += 3;
				}
			}
		}
		ByteBuf in = Unpooled.buffer(2+size);
		in.writeByte(this.getAttr());
		in.writeByte(this.getAreaCnt());
		if(this.getAreaCnt() > 0){
			for(Item item:itemList){
				in.writeInt(Long.valueOf(item.getAreaId()).intValue());
				in.writeShort(item.getAreaAttr());
				in.writeInt(Long.valueOf(item.getCenterLat()).intValue());
				in.writeInt(Long.valueOf(item.getCenterLng()).intValue());
				in.writeInt(Long.valueOf(item.getRadius()).intValue());
				int timeFlag = item.getAreaAttr() & 0x1;
				if(timeFlag == 1){
					//0位为1
					in.writeByte(Byte.parseByte(item.getStartTime().substring(0, 2),16));
					in.writeByte(Byte.parseByte(item.getStartTime().substring(2, 4),16));
					in.writeByte(Byte.parseByte(item.getStartTime().substring(4, 6),16));
					in.writeByte(Byte.parseByte(item.getStartTime().substring(6, 8),16));
					in.writeByte(Byte.parseByte(item.getStartTime().substring(8, 10),16));
					in.writeByte(Byte.parseByte(item.getStartTime().substring(10, 12),16));
					
					in.writeByte(Byte.parseByte(item.getEndTime().substring(0, 2),16));
					in.writeByte(Byte.parseByte(item.getEndTime().substring(2, 4),16));
					in.writeByte(Byte.parseByte(item.getEndTime().substring(4, 6),16));
					in.writeByte(Byte.parseByte(item.getEndTime().substring(6, 8),16));
					in.writeByte(Byte.parseByte(item.getEndTime().substring(8, 10),16));
					in.writeByte(Byte.parseByte(item.getEndTime().substring(10, 12),16));
				}
				int speedFlag = item.getAreaAttr() >> 1 & 0x1;//0000 0000 0000 0010
				if(speedFlag == 1){
					//1位为1
					in.writeShort(item.getSpeed());
					in.writeByte(item.getDuration());
				}
			}
		}
		return in.array();
	}

	public class Item{
		/**
		 * 区域ID DWORD
		 */
		private long areaId;
		
		/**
		 * 区域属性 WORD
		 */
		private int areaAttr;

		/**
		 * 中心点纬度 DWORD
		 */
		private long centerLat;
		
		/**
		 * 中心点经度 DWORD
		 */
		private long centerLng;
		
		/**
		 * 半径 DWORD
		 */
		private long radius;
		
		/**
		 * 起始时间 BCD[6]
		 * 区域属性0位为0则没有该字段
		 */
		private String startTime;

		/**
		 * 结束时间 BCD[6]
		 * 区域属性0位为0则没有该字段
		 */
		private String endTime;
		
		/**
		 * 最高速度 WORD
		 * 区域属性1位为0则没有该字段
		 */
		private int speed;
		
		/**
		 * 超速持续时间 BYTE
		 * 区域属性1位为0则没有该字段
		 */
		private short duration;

		/**
		 * @return the areaId
		 */
		public long getAreaId() {
			return areaId;
		}

		/**
		 * @param areaId the areaId to set
		 */
		public void setAreaId(long areaId) {
			this.areaId = areaId;
		}

		/**
		 * @return the areaAttr
		 */
		public int getAreaAttr() {
			return areaAttr;
		}

		/**
		 * @param areaAttr the areaAttr to set
		 */
		public void setAreaAttr(int areaAttr) {
			this.areaAttr = areaAttr;
		}

		/**
		 * @return the centerLat
		 */
		public long getCenterLat() {
			return centerLat;
		}

		/**
		 * @param centerLat the centerLat to set
		 */
		public void setCenterLat(long centerLat) {
			this.centerLat = centerLat;
		}

		/**
		 * @return the centerLng
		 */
		public long getCenterLng() {
			return centerLng;
		}

		/**
		 * @param centerLng the centerLng to set
		 */
		public void setCenterLng(long centerLng) {
			this.centerLng = centerLng;
		}

		/**
		 * @return the radius
		 */
		public long getRadius() {
			return radius;
		}

		/**
		 * @param radius the radius to set
		 */
		public void setRadius(long radius) {
			this.radius = radius;
		}

		/**
		 * @return the startTime
		 */
		public String getStartTime() {
			return startTime;
		}

		/**
		 * @param startTime the startTime to set
		 */
		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}

		/**
		 * @return the endTime
		 */
		public String getEndTime() {
			return endTime;
		}

		/**
		 * @param endTime the endTime to set
		 */
		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}

		/**
		 * @return the speed
		 */
		public int getSpeed() {
			return speed;
		}

		/**
		 * @param speed the speed to set
		 */
		public void setSpeed(int speed) {
			this.speed = speed;
		}

		/**
		 * @return the duration
		 */
		public short getDuration() {
			return duration;
		}

		/**
		 * @param duration the duration to set
		 */
		public void setDuration(short duration) {
			this.duration = duration;
		}
		
		
	}

	/**
	 * @return the attr
	 */
	public short getAttr() {
		return attr;
	}

	/**
	 * @param attr the attr to set
	 */
	public void setAttr(short attr) {
		this.attr = attr;
	}

	/**
	 * @return the areaCnt
	 */
	public short getAreaCnt() {
		return areaCnt;
	}

	/**
	 * @param areaCnt the areaCnt to set
	 */
	public void setAreaCnt(short areaCnt) {
		this.areaCnt = areaCnt;
	}

	/**
	 * @return the itemList
	 */
	public List<Item> getItemList() {
		return itemList;
	}

	/**
	 * @param itemList the itemList to set
	 */
	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}
	
	
}
