package com.neoway.car.device.listener;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Maps;
import com.neoway.car.device.bean.codec.JT808Encoder;
import com.neoway.car.device.bean.pkg.JT_8103;
import com.neoway.car.device.bean.pkg.JT_8103.ParamItem;
import com.neoway.car.device.bean.pkg.JT_8104;
import com.neoway.car.device.bean.pkg.JT_8105;
import com.neoway.car.device.bean.pkg.JT_8106;
import com.neoway.car.device.bean.terminal.TerminalControlParams;
import com.neoway.car.device.bean.terminal.TerminalParams;
import com.neoway.car.device.bean.terminal.TerminalParamsById;
import com.neoway.car.device.util.DeviceManager;
import com.neoway.car.device.util.JT808Consts;
import com.neoway.car.device.util.JsonTools;
import com.neoway.car.device.util.SerialNumManager;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * <pre>
 *  描述: 平台下发终端下行指令监听
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/09/03 9:07
 */
@Component
@Slf4j
public class TerminalDownListener {

    @Autowired
    private JT808Encoder jT808Encoder;

    @Autowired
    private StringRedisTemplate redisTemplate;

    /**
     * 设备管理单例
     */
    private DeviceManager deviceManager = DeviceManager.getInstance();

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_terminal_settingQueue_jt808", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_terminal_setting", type = "direct", durable = "true"),
                    key = "jt808")
    })
    public String sendParamSettings(String message) {
        log.info("平台下发终端设置指令，消息={}", message);
        TerminalParams terminalParams = JSON.parseObject(message, new TypeReference<TerminalParams>(){});
        String deviceId = terminalParams.getEquId();
        String phone = terminalParams.getPhone();
        ChannelHandlerContext ctx = deviceManager.findByDeviceId(deviceId);
        Map<String, String> resultMap = Maps.newHashMap();
        if (ctx == null) {
            log.error("设备当前不在线，deviceId={}", deviceId);
            resultMap.put("result", "1");
            resultMap.put("message", "设备已跟平台失去TCP连接，请更新页面在线状态并在设备上线后重试！！");
            return JsonTools.toJsonStr(resultMap);
        }
        // 流水号
        int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
        byte[] respBytes = null;
        JT_8103 jt8103 = new JT_8103();
        try {
            jt8103.setParamCnt(Short.parseShort(String.valueOf(terminalParams.getParamCount())));
            List<ParamItem> paramItemList = new ArrayList<>();
            if (terminalParams.getHeartBeat() != null) {
                ParamItem paramItem01 = jt8103.new ParamItem();
                paramItem01.setParamId(0x0001);
                paramItem01.setParamVal(terminalParams.getHeartBeat());
                paramItemList.add(paramItem01);
            }
            if (!StringUtils.isBlank(terminalParams.getDialAddress())) {
                ParamItem paramItem10 = jt8103.new ParamItem();
                paramItem10.setParamId(0x0010);
                paramItem10.setParamVal(terminalParams.getDialAddress());
                paramItemList.add(paramItem10);
            }
            if (!StringUtils.isBlank(terminalParams.getServerAddress())) {
                ParamItem paramItem13 = jt8103.new ParamItem();
                paramItem13.setParamId(0x0013);
                paramItem13.setParamVal(terminalParams.getServerAddress());
                paramItemList.add(paramItem13);
            }
            if (terminalParams.getTcpPort() != null) {
                ParamItem paramItem18 = jt8103.new ParamItem();
                paramItem18.setParamId(0x0018);
                paramItemList.add(paramItem18);
            }
            if (terminalParams.getLocationReportStrategy() != null) {
                ParamItem paramItem20 = jt8103.new ParamItem();
                paramItem20.setParamId(0x0020);
                paramItem20.setParamVal(terminalParams.getLocationReportStrategy());
                paramItemList.add(paramItem20);
            }
            if (terminalParams.getSleepTimeReport() != null) {
                ParamItem paramItem27 = jt8103.new ParamItem();
                paramItem27.setParamId(0x0027);
                paramItem27.setParamVal(terminalParams.getSleepTimeReport());
                paramItemList.add(paramItem27);
            }
            if (terminalParams.getDefaultTimeReport() != null) {
                ParamItem paramItem29 = jt8103.new ParamItem();
                paramItem29.setParamId(0x0029);
                paramItem29.setParamVal(terminalParams.getDefaultTimeReport());
                paramItemList.add(paramItem29);
            }
            if (terminalParams.getDefaultDistanceReport() != null) {
                ParamItem paramItem2C = jt8103.new ParamItem();
                paramItem2C.setParamId(0x002C);
                paramItem2C.setParamVal(terminalParams.getDefaultDistanceReport());
                paramItemList.add(paramItem2C);
            }
            if (terminalParams.getMaxSpeed() != null) {
                ParamItem paramItem55 = jt8103.new ParamItem();
                paramItem55.setParamId(0x0055);
                paramItem55.setParamVal(terminalParams.getMaxSpeed());
                paramItemList.add(paramItem55);
            }
            if (terminalParams.getOverSpeedLastTime() != null) {
                ParamItem paramItem56 = jt8103.new ParamItem();
                paramItem56.setParamId(0x0056);
                paramItem56.setParamVal(terminalParams.getOverSpeedLastTime());
                paramItemList.add(paramItem56);
            }
            if (terminalParams.getDriverLastTime() != null) {
                ParamItem paramItem57 = jt8103.new ParamItem();
                paramItem57.setParamId(0x0057);
                paramItem57.setParamVal(terminalParams.getDriverLastTime());
                paramItemList.add(paramItem57);
            }
            if (terminalParams.getMinBreakTime() != null) {
                ParamItem paramItem59 = jt8103.new ParamItem();
                paramItem59.setParamId(0x0059);
                paramItem59.setParamVal(terminalParams.getMinBreakTime());
                paramItemList.add(paramItem59);
            }
            if (terminalParams.getKnockAlarmParam() != null) {
                ParamItem paramItem5D = jt8103.new ParamItem();
                paramItem5D.setParamId(0x005D);
                paramItem5D.setParamVal(terminalParams.getKnockAlarmParam());
                paramItemList.add(paramItem5D);
            }
            if (terminalParams.getRolloverAlarmParam() != null) {
                ParamItem paramItem5E = jt8103.new ParamItem();
                paramItem5E.setParamId(0x005E);
                paramItem5E.setParamVal(terminalParams.getRolloverAlarmParam());
                paramItemList.add(paramItem5E);
            }
            if (terminalParams.getOdometerNum() != null) {
                ParamItem paramItem80 = jt8103.new ParamItem();
                paramItem80.setParamId(0x0080);
                paramItem80.setParamVal(terminalParams.getOdometerNum());
                paramItemList.add(paramItem80);
            }
            if (terminalParams.getProvinceId() != null) {
                ParamItem paramItem81 = jt8103.new ParamItem();
                paramItem81.setParamId(0x0081);
                paramItem81.setParamVal(terminalParams.getProvinceId());
                paramItemList.add(paramItem81);
            }
            if (terminalParams.getCityId() != null) {
                ParamItem paramItem82 = jt8103.new ParamItem();
                paramItem82.setParamId(0x0082);
                paramItem82.setParamVal(terminalParams.getCityId());
                paramItemList.add(paramItem82);
            }
            if (!StringUtils.isBlank(terminalParams.getCarNum())) {
                ParamItem paramItem83 = jt8103.new ParamItem();
                paramItem83.setParamId(0x0083);
                paramItem83.setParamVal(terminalParams.getCityId());
                paramItemList.add(paramItem83);
            }
            if (terminalParams.getCarColor() != null) {
                ParamItem paramItem84 = jt8103.new ParamItem();
                paramItem84.setParamId(0x0084);
                paramItem84.setParamVal(terminalParams.getCarColor());
                paramItemList.add(paramItem84);
            }
            if (terminalParams.getGnssModel() != null) {
                ParamItem paramItem90 = jt8103.new ParamItem();
                paramItem90.setParamId(0x0090);
                paramItem90.setParamVal(terminalParams.getGnssModel());
                paramItemList.add(paramItem90);
            }
            if (terminalParams.getAcceleration() != null) {
                ParamItem paramItemF01 = jt8103.new ParamItem();
                paramItemF01.setParamId(0xF001);
                paramItemF01.setParamVal(terminalParams.getAcceleration());
                paramItemList.add(paramItemF01);
            }
            if (terminalParams.getDeAcceleration() != null) {
                ParamItem paramItemF02 = jt8103.new ParamItem();
                paramItemF02.setParamId(0xF002);
                paramItemF02.setParamVal(terminalParams.getDeAcceleration());
                paramItemList.add(paramItemF02);
            }
            if (terminalParams.getSharpTurn() != null) {
                ParamItem paramItemF03 = jt8103.new ParamItem();
                paramItemF03.setParamId(0xF003);
                paramItemF03.setParamVal(terminalParams.getSharpTurn());
                paramItemList.add(paramItemF03);
            }
            if (terminalParams.getSuddenChangePath() != null) {
               ParamItem paramItemF04 = jt8103.new ParamItem();
               paramItemF04.setParamId(0xF004);
               paramItemF04.setParamVal(terminalParams.getSuddenChangePath());
               paramItemList.add(paramItemF04);
            }
            if (terminalParams.getEtcLowTemperatureAlarm() != null) {
                ParamItem paramItemF05 = jt8103.new ParamItem();
                paramItemF05.setParamId(0xF005);
                paramItemF05.setParamVal(terminalParams.getEtcLowTemperatureAlarm());
                paramItemList.add(paramItemF05);
            }
            if (terminalParams.getEtcHighTemperatureAlarm() != null) {
                ParamItem paramItemF06 = jt8103.new ParamItem();
                paramItemF06.setParamId(0xF006);
                paramItemF06.setParamVal(terminalParams.getEtcHighTemperatureAlarm());
                paramItemList.add(paramItemF06);
            }
            if (terminalParams.getRpmAlarm() != null) {
                ParamItem paramItemF07 = jt8103.new ParamItem();
                paramItemF07.setParamId(0xF007);
                paramItemF07.setParamVal(terminalParams.getRpmAlarm());
                paramItemList.add(paramItemF07);
            }
            if (terminalParams.getLowVoltageAlarm() != null) {
                ParamItem paramItemF08 = jt8103.new ParamItem();
                paramItemF08.setParamId(0xF008);
                paramItemF08.setParamVal(terminalParams.getLowVoltageAlarm());
                paramItemList.add(paramItemF08);
            }
            if (terminalParams.getIdlingAlarm() != null && StringUtils.isNotBlank(terminalParams.getIdlingAlarm())) {
                ParamItem paramItemF09 = jt8103.new ParamItem();
                paramItemF09.setParamId(0xF009);
                paramItemF09.setParamVal(terminalParams.getIdlingAlarm());
                paramItemList.add(paramItemF09);
            }
            if (terminalParams.getMileageCalculatingCoefficient() != null) {
                ParamItem paramItemF10 = jt8103.new ParamItem();
                paramItemF10.setParamId(0xF010);
                paramItemF10.setParamVal(terminalParams.getMileageCalculatingCoefficient());
                paramItemList.add(paramItemF10);
            }
            if (terminalParams.getOilCalculatingCoefficient() != null) {
                ParamItem paramItemF11 = jt8103.new ParamItem();
                paramItemF11.setParamId(0xF011);
                paramItemF11.setParamVal(terminalParams.getOilCalculatingCoefficient());
                paramItemList.add(paramItemF11);
            }
            if (terminalParams.getDisplacement() != null) {
                ParamItem paramItemF12 = jt8103.new ParamItem();
                paramItemF12.setParamId(0xF012);
                paramItemF12.setParamVal(terminalParams.getDisplacement());
                paramItemList.add(paramItemF12);
            }
            if (terminalParams.getOilType() != null) {
                ParamItem paramItemF13 = jt8103.new ParamItem();
                paramItemF13.setParamId(0xF013);
                paramItemF13.setParamVal(terminalParams.getOilType());
                paramItemList.add(paramItemF13);
            }
            if (terminalParams.getWifi() != null && StringUtils.isNotBlank(terminalParams.getWifi())) {
                ParamItem paramItemF14 = jt8103.new ParamItem();
                paramItemF14.setParamId(0xF014);
                paramItemF14.setParamVal(terminalParams.getWifi());
                paramItemList.add(paramItemF14);
            }
            jt8103.setParamList(paramItemList);
            // 下发指令字节封装
            respBytes = jT808Encoder.encodePackage(phone, jt8103, flowId, JT808Consts.msgid_plantform_setparams);
            recordFlowId(flowId, deviceId, JT808Consts.msgid_plantform_setparams, "car_terminal_setting");
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
            resultMap.put("result", "0");
            resultMap.put("message", "下发终端参数设置指令成功！");
        } catch (Exception e) {
            log.error("平台下发终端设置指令发生错误！", e);
            resultMap.put("result", "1");
            resultMap.put("message", "下发参数解析存在问题！");
        }
        return JsonTools.toJsonStr(resultMap);
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_terminal_findParamQueue_jt808", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_terminal_findParam", type = "direct", durable = "true"),
                    key = "jt808")
    })
    public void findTerminalParams(String message) {
        log.info("平台下发查询终端参数指令！消息={}", message);
        try {
            Map<String, String> msgMap = JSON.parseObject(message, new TypeReference<Map<String, String>>(){});
            String deviceId = msgMap.get("equId");
            String phone = msgMap.get("phone");
            ChannelHandlerContext ctx = deviceManager.findByDeviceId(deviceId);
            byte[] respBytes = null;
            if (ctx == null) {
                log.error("设备当前不在线，deviceId={}", deviceId);
                return;
            }
            int flowId = SerialNumManager.getInstance().currentFlowId(ctx);
            JT_8104 jt8104 = new JT_8104();
            // 下发指令字节
            respBytes = jT808Encoder.encodePackage(phone, jt8104, flowId, JT808Consts.msgid_plantform_searchparams);
            recordFlowId(flowId, deviceId, JT808Consts.msgid_plantform_searchparams, "car_terminal_findParam");
            ctx.writeAndFlush(Unpooled.copiedBuffer(respBytes));
        } catch (Exception e) {
            log.error("平台下发查询终端参数指令发生错误！", e);
        }
    }


    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_terminal_findParamByIdQueue_jt808", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_terminal_findParamById", type = "direct", durable = "true"),
                    key = "jt808")
    })
    public void findTerminalParamsById(String message) {
        log.info("平台下发查询指定终端参数指令！消息={}", message);
        try {
            TerminalParamsById terminalParamsById = JSON.parseObject(message, new TypeReference<TerminalParamsById>(){});
            int paramCount = terminalParamsById.getIdNum();
            String deviceId = terminalParamsById.getEquId();
            String phone = terminalParamsById.getPhone();
            String ids = terminalParamsById.getIds();
            byte[] respBytes = null;
            ChannelHandlerContext cxt = deviceManager.findByDeviceId(deviceId);
            if (cxt == null) {
                log.error("设备当前不在线！deviceId={}", deviceId);
                return;
            }
            int flowId = SerialNumManager.getInstance().currentFlowId(cxt);
            JT_8106 jt8106 = new JT_8106();
            jt8106.setIdNum(Short.parseShort(String.valueOf(paramCount)));
            if (!StringUtils.isBlank(ids)) {
                jt8106.setIds(ids);
            }
            // 下发指令字节
            respBytes = jT808Encoder.encodePackage(phone, jt8106, flowId, JT808Consts.msgid_plantform_searchparam);
            recordFlowId(flowId, deviceId, JT808Consts.msgid_plantform_searchparam, "car_terminal_findParamById");
            cxt.writeAndFlush(Unpooled.copiedBuffer(respBytes));
        } catch (Exception e) {
            log.error("平台下发查询指定终端参数指令发生错误！", e);
        }

    }


    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "car_terminal_controlQueue_jt808", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "car_terminal_control", type = "direct", durable = "true"),
                    key = "jt808")
    })
    public void terminalControl(String message) {
        log.info("平台下发终端控制指令！消息={}", message);
        try {
            TerminalControlParams terminalControlParams = JSON.parseObject(message, new TypeReference<TerminalControlParams>(){});
            String deviceId = terminalControlParams.getEquId();
            String phone = terminalControlParams.getPhone();
            ChannelHandlerContext cxt = deviceManager.findByDeviceId(deviceId);
            if (cxt == null) {
                log.error("设备当前不在线！deviceId={}", deviceId);
                return;
            }
            byte[] respBytes = null;
            int flowId = SerialNumManager.getInstance().currentFlowId(cxt);
            JT_8105 jt8105 = new JT_8105();
            jt8105.setCommandWord(terminalControlParams.getCommandWord());
            jt8105.setCommandParameters(terminalControlParams.getCommandParams());
            // 下发指令字节
            respBytes = jT808Encoder.encodePackage(phone, jt8105, flowId, JT808Consts.msgid_plantform_control);
            recordFlowId(flowId, deviceId, JT808Consts.msgid_plantform_control, "car_terminal_control");
            cxt.writeAndFlush(Unpooled.copiedBuffer(respBytes));
        } catch (Exception e) {
            log.error("平台下发终端控制指令发生错误！", e);
        }
    }

    /**
     * 将流水号存至redis
     * @param flowId 流水号
     * @param deviceId 设备id
     * @param msgId 消息id
     * @param type 消息类型
     */
    private void recordFlowId(int flowId, String deviceId, int msgId, String type) {
        Map<String, String> cmdMap = Maps.newHashMap();
        cmdMap.put("type", type);
        cmdMap.put("msgId", String.valueOf(msgId));
        redisTemplate.boundHashOps("nw:equId:"+deviceId+":flowId:"+flowId).putAll(cmdMap);
        redisTemplate.boundHashOps("nw:equId:"+deviceId+":flowId:"+flowId).expire(2, TimeUnit.MINUTES);
    }
}
