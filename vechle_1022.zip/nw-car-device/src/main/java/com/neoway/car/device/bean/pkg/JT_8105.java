/**
 * @company 有方物联
 * @file JT_8105.java
 * @author bailu
 * @date 2018年4月16日
 */
package com.neoway.car.device.bean.pkg;

import java.io.UnsupportedEncodingException;

import com.neoway.car.device.bean.IWriteMessageBody;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description : 终端控制
 * @author : bailu
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
public class JT_8105 implements IWriteMessageBody {

    /**
     * 命令字  BYTE
     */
    private byte commandWord;

    public final byte getCommandWord() {
        return commandWord;
    }

    public final void setCommandWord(byte value) {
        commandWord = value;
    }

    /**
     * 命令参数项  STRING
     */
    private String commandParameters;

    public final String getCommandParameters() {
        return commandParameters;
    }

    public final void setCommandParameters(String value) {
        commandParameters = value;
    }

    @Override
    public byte[] writeToBytes() {
        ByteBuf in = Unpooled.buffer(1 + this.getCommandParameters().getBytes().length);

        in.writeByte(getCommandWord());
        try {
            if(this.commandParameters != null && this.commandParameters.length() > 0){
                in.writeBytes(getCommandParameters().getBytes("GBK"));
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return in.array();
    }

}
