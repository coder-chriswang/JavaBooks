/**
 * @company 有方物联
 * @file PostitionAdditional_11.java
 * @author guojy
 * @date 2018年4月24日 
 */
package com.neoway.car.device.bean.pkg;

import com.neoway.car.device.bean.IPositionAdditionalItem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :超速报警附加信息
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月24日
 */
public class PostitionAdditional_11 implements IPositionAdditionalItem {
	/**
	 * 位置类型
	 * 0：无特定位置；1：圆形区域；2：矩形区域；3：多边形区域；4：路段
	 */
	private short localtionType;
	/**
	 * 区域或路段ID
	 * 若位置类型为0，无该字段
	 */
	private long areaId;
	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalId()
	 */
	@Override
	public int getAdditionalId() {
		return 0x11;
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#getAdditionalLength()
	 */
	@Override
	public byte getAdditionalLength() {
		if(localtionType == 0){
			return 0x1;
		}else{
			return 0x5;
		}
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#writeToBytes()
	 */
	@Override
	public byte[] writeToBytes() {
		ByteBuf in = Unpooled.buffer(localtionType == 0?1:5);
		in.writeByte(this.getLocaltionType());
		if(localtionType != 0){
			in.writeInt(Long.valueOf(this.getAreaId()).intValue());
		}
		return in.array();
	}

	/* (non-Javadoc)
	 * @see com.etiot.car.device.bean.IPositionAdditionalItem#readFromBytes(byte[])
	 */
	@Override
	public void readFromBytes(byte[] bytes) {
		ByteBuf in = Unpooled.copiedBuffer(bytes);
		this.setLocaltionType(in.readUnsignedByte());
		if(bytes.length ==5){
			this.setAreaId(in.readUnsignedInt());
		}
	}

	/**
	 * @return the localtionType
	 */
	public short getLocaltionType() {
		return localtionType;
	}

	/**
	 * @param localtionType the localtionType to set
	 */
	public void setLocaltionType(short localtionType) {
		this.localtionType = localtionType;
	}

	/**
	 * @return the areaId
	 */
	public long getAreaId() {
		return areaId;
	}

	/**
	 * @param areaId the areaId to set
	 */
	public void setAreaId(long areaId) {
		this.areaId = areaId;
	}

}
