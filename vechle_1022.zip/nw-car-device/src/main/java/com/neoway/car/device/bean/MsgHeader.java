/**
 * @company 有方物联
 * @file MsgHeader.java
 * @author guojy
 * @date 2018年4月10日 
 */
package com.neoway.car.device.bean;

import com.neoway.util.hex.BCD8421Operater;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @description :JT808 部标协议消息头
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月10日
 */
public class MsgHeader {
	/**
	 * byte[0-1] 消息ID word(16bit)
	 */
	protected int msgId;
	
	/**
	 * byte[2-3] 消息体属性 word(16bit)
	 * <br>消息体长度
	 * <br>数据加密方式
	 * <br>是否分包
	 * <br>保留位
	 */
	protected int msgBodyProps;
	
	/**
	 * bit[0-9] 消息体长度
	 */
	protected int msgBodyLength;
	
	/**
	 * bit[10-12] 数据加密方式
	 */
	protected int encryptionType;
	
	/**
	 * bit[13] 是否分包,true==>有消息包封装项
	 */
	protected boolean hasSubPackage;
	
	/**
	 * bit[14-15]保留位
	 */
	protected int reservedBit;
	
	/**
	 * byte[4-9] 终端手机号 bcd[6]  (48bit)
	 */
	protected String terminalPhone;
	
	/**
	 * byte[10-11] 流水号word(16bit)
	 */
	protected int flowId;
		
	/**
	 * byte[12-13] 消息包总数(word(16bit))
	 */
	protected int totalSubPackage;
	
	/**
	 * byte[14-15]  包序号(word(16bit)) 从 1 开始
	 */
	protected int subPackageSeq;

	/**
	 * @return the msgId
	 */
	public int getMsgId() {
		return msgId;
	}

	/**
	 * @param msgId the msgId to set
	 */
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}

	/**
	 * @return the msgBodyProps
	 */
	public int getMsgBodyProps() {
		return msgBodyProps;
	}

	/**
	 * @param msgBodyProps the msgBodyProps to set
	 */
	public void setMsgBodyProps(int msgBodyProps) {
		this.msgBodyProps = msgBodyProps;
	}

	/**
	 * @return the msgBodyLength
	 */
	public int getMsgBodyLength() {
		return msgBodyLength;
	}

	/**
	 * @param msgBodyLength the msgBodyLength to set
	 */
	public void setMsgBodyLength(int msgBodyLength) {
		this.msgBodyLength = msgBodyLength;
	}

	/**
	 * @return the encryptionType
	 */
	public int getEncryptionType() {
		return encryptionType;
	}

	/**
	 * @param encryptionType the encryptionType to set
	 */
	public void setEncryptionType(int encryptionType) {
		this.encryptionType = encryptionType;
	}

	/**
	 * @return the hasSubPackage
	 */
	public boolean isHasSubPackage() {
		return hasSubPackage;
	}

	/**
	 * @param hasSubPackage the hasSubPackage to set
	 */
	public void setHasSubPackage(boolean hasSubPackage) {
		this.hasSubPackage = hasSubPackage;
	}

	/**
	 * @return the reservedBit
	 */
	public int getReservedBit() {
		return reservedBit;
	}

	/**
	 * @param reservedBit the reservedBit to set
	 */
	public void setReservedBit(int reservedBit) {
		this.reservedBit = reservedBit;
	}

	/**
	 * @return the terminalPhone
	 */
	public String getTerminalPhone() {
		return terminalPhone;
	}

	/**
	 * @param terminalPhone the terminalPhone to set
	 */
	public void setTerminalPhone(String terminalPhone) {
		this.terminalPhone = terminalPhone;
	}

	/**
	 * @return the flowId
	 */
	public int getFlowId() {
		return flowId;
	}

	/**
	 * @param flowId the flowId to set
	 */
	public void setFlowId(int flowId) {
		this.flowId = flowId;
	}

	/**
	 * @return the totalSubPackage
	 */
	public int getTotalSubPackage() {
		return totalSubPackage;
	}

	/**
	 * @param totalSubPackage the totalSubPackage to set
	 */
	public void setTotalSubPackage(int totalSubPackage) {
		this.totalSubPackage = totalSubPackage;
	}

	/**
	 * @return the subPackageSeq
	 */
	public int getSubPackageSeq() {
		return subPackageSeq;
	}

	/**
	 * @param subPackageSeq the subPackageSeq to set
	 */
	public void setSubPackageSeq(int subPackageSeq) {
		this.subPackageSeq = subPackageSeq;
	}
	
	/**
	 * 消息体转字节码
	 * @return
	 */
	public byte[] write2Bytes(){
		int initialCapacity = this.isHasSubPackage()?16:12;
		ByteBuf in = Unpooled.buffer(initialCapacity);
		in.writeShort(getMsgId());
		in.writeShort(getMsgBodyProps());
		//不足12位补0
		String phone = String.format("%012d", Long.parseLong(getTerminalPhone()));
		in.writeBytes(BCD8421Operater.string2Bcd(phone));
		
		in.writeShort(getFlowId());
		//分包
		if(this.isHasSubPackage()){
			in.writeShort(getTotalSubPackage());
			in.writeShort(getSubPackageSeq());
		}
		return in.array();
	}
}
