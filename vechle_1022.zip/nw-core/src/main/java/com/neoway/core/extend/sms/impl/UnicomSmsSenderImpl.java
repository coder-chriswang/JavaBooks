/**
 * @company 有方物联
 * @file IUnicomSmsSender.java
 * @author guojy
 * @date 2017年9月29日 
 */
package com.neoway.core.extend.sms.impl;

import com.neoway.core.extend.sms.ISmsSender;

/**
 * @description :联通短信发送服务
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月29日
 */
public class UnicomSmsSenderImpl implements ISmsSender {

	/* (non-Javadoc)
	 * @see com.etiot.core.extend.sms.ISmsSender#send(java.lang.String, java.lang.String)
	 */
	@Override
	public void send(String phoneNo, String content) {
		
	}

	@Override
	public void send(String phoneNo, String templateCode, String signName, String jsonParam) {
		
	}

	@Override
	public void send(String phoneNo, String templateCode, String jsonParam) {
		this.send(phoneNo, templateCode, null, jsonParam);
	}

}
