/**
 * @company 有方物联
 * @file CustomRuntimeException.java
 * @author guojy
 * @date 2017年9月22日 
 */
package com.neoway.core.exception;

/**
 * @description :系统自定义异常类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月22日
 */
public class CustomRuntimeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6960404033481894631L;

	/**
	 * 
	 */
	public CustomRuntimeException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public CustomRuntimeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CustomRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public CustomRuntimeException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public CustomRuntimeException(Throwable cause) {
		super(cause);
	}

	
}
