/**
 * @company 有方物联
 * @file JsonFilterUtils.java
 * @author guojy
 * @date 2018年2月5日 
 */
package com.neoway.core.extend.json;

import java.util.Arrays;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializeFilter;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.neoway.core.datasource.pagination.bean.PageList;


/**
 * @description :json过滤字段
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年2月5日
 */
public class JsonFilterUtils {
	/**
	 * 对象转json串（包含字段）
	 * @param object 目标对象
	 * @param clazz 需要过滤的字段对应的类   为空则全目标对象中过滤字段
	 * @param properties 包含字段
	 * @return
	 */
	public static String toJSONInclude(Object object,Class<?> clazz,String... properties){
		SimplePropertyPreFilter filter = new SimplePropertyPreFilter(clazz, properties);
		return parsePageList(object, filter);
	}
	
	/**
	 * 对象转json串 （排除字段）
	 * @param object 目标对象
	 * @param clazz 需要过滤的字段对应的类   为空则全目标对象中过滤字段
	 * @param properties 排除字段
	 * @return
	 */
	public static String toJSONExclude(Object object,Class<?> clazz,String... properties){
		SimplePropertyPreFilter filter = new SimplePropertyPreFilter(clazz);
		if(properties != null){
			for (String prop:properties) {
				filter.getExcludes().add(prop);
			}		
		}
		return parsePageList(object, filter);
	}
	
	/**
	 * 分页对象处理逻辑
	 * @param object
	 * @param filter
	 * @return
	 */
	private static String parsePageList(Object object,SerializeFilter... filter){
		if(object instanceof PageList){
			PageList<?> pageList = (PageList<?>) object;
			int total = pageList.getPaginator().getTotalCount();
			PageListBean pageListBean = new PageListBean(total,pageList);
			return JSON.toJSONString(pageListBean,filter,SerializerFeature.WriteMapNullValue);
		}else{
			return JSON.toJSONString(object,filter,SerializerFeature.WriteMapNullValue);
		}
	}
	
	/**
	 * 对象转json串（包含字段）
	 * @param object 目标对象
	 * @param fastJsonFilters 多个类型过滤属性的过滤器 通过属性Include判断排除还是包含
	 * @return
	 */
	public static String toJSON(Object object,JsonFilter... fastJsonFilters){
		if(fastJsonFilters != null){
			SerializeFilter[] filters = new SerializeFilter[fastJsonFilters.length];
			for(int i=0;i<fastJsonFilters.length;i++){
				boolean isInclude = fastJsonFilters[i].isInclude();
				String[] properties = fastJsonFilters[i].getProperties();
				if(isInclude){
					SimplePropertyPreFilter filter = new SimplePropertyPreFilter(fastJsonFilters[i].getClazz(), properties);
					filters[i] = filter;
				}else{
					SimplePropertyPreFilter filter = new SimplePropertyPreFilter(fastJsonFilters[i].getClazz());
					if(properties != null){
						filter.getExcludes().addAll(Arrays.asList(properties));
					}
					filters[i] = filter;
				}
			}
			return parsePageList(object, filters);
		}else{
			return parsePageList(object);
		}
	}
	
}
