/**
 * @company 有方物联
 * @file WebMvcConfigurerExtend.java
 * @author guojy
 * @date 2017年9月20日 
 */
package com.neoway.core.web;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @description :WebMvcConfigurerAdapter扩展
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月20日
 * 
 */
@Configuration
public class WebMvcConfigurerExtend {
	
	@Bean
	public JsonMessageConverterExtend customConverters(){
		return new JsonMessageConverterExtend();
	}
	
}
