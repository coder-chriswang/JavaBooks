/**
 * @company 有方物联
 * @file IAppPushSender.java
 * @author guojy
 * @date 2017年9月29日 
 */
package com.neoway.core.extend.push;

/**
 * @description :app信息推送接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月29日
 */
public interface IAppPushSender {
	/**
	 * 安卓app消息推送
	 * @param address
	 * @param conteng
	 * @param messageType
	 */
	public void androidPush(String address, String conteng, String messageType);
	/**
	 * ios app消息推送
	 * @param address
	 * @param conteng
	 * @param messageType
	 */
	public void iosPush(String address, String conteng, String messageType);
}
