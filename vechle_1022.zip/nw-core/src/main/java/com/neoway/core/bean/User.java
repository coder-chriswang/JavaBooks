/**
 * @company 有方物联
 * @file User.java
 * @author guojy
 * @date 2018年3月13日 
 */
package com.neoway.core.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月13日
 */
public class User implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String accountId;
	protected String account;
	protected String nick;
	protected String password;
	protected String email;
	protected String phone;
	protected boolean valid;
	protected boolean superadmin;
	protected String entCode;
	protected String entId;
	protected String contacts;
	/**
	 * 用户所属组织ID
	 */
	protected String deptId;
	/**
	 * 是否允许app登录
	 */
	protected boolean allowMobile;
	/**
	 * 用户角色列表
	 */
	protected List<String> roles;
	/**
	 * 企业状态
	 */
	protected boolean entStatus;
	/**
	 * 企业账号有效期
	 */
	protected Date entExpiryDate;
	/**
	 * 企业logo
	 */
	protected String entLogo;
	/**
	 * 
	 */
	public User() {
		super();
	}
	


	/**
	 * @param account
	 * @param password
	 */
	public User(String account, String password) {
		super();
		this.account = account;
		this.password = password;
	}




	/**
	 * @param userId
	 * @param account
	 * @param nick
	 * @param password
	 * @param email
	 * @param phone
	 * @param valid
	 * @param superadmin
	 * @param entCode
	 */
	public User(String accountId, String account, String nick, String password, String email, String phone, boolean valid,
			boolean superadmin, String entCode) {
		super();
		this.accountId = accountId;
		this.account = account;
		this.nick = nick;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.valid = valid;
		this.superadmin = superadmin;
		this.entCode = entCode;
	}


	/**
	 * @param accountId
	 * @param account
	 * @param nick
	 * @param password
	 * @param email
	 * @param phone
	 * @param valid
	 * @param superadmin
	 * @param entCode
	 * @param entId
	 * @param contacts
	 * @param deptId
	 * @param allowMobile
	 * @param roles
	 * @param entStatus
	 * @param entExpiryDate
	 */
	public User(String accountId, String account, String nick, String password, String email, String phone,
			boolean valid, boolean superadmin, String entCode, String entId, String contacts, String deptId,
			boolean allowMobile, List<String> roles, boolean entStatus, Date entExpiryDate) {
		super();
		this.accountId = accountId;
		this.account = account;
		this.nick = nick;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.valid = valid;
		this.superadmin = superadmin;
		this.entCode = entCode;
		this.entId = entId;
		this.contacts = contacts;
		this.deptId = deptId;
		this.allowMobile = allowMobile;
		this.roles = roles;
		this.entStatus = entStatus;
		this.entExpiryDate = entExpiryDate;
	}



	/**
	 * @return the account
	 */
	public String getAccount() {
		return account;
	}



	/**
	 * @param account the account to set
	 */
	public void setAccount(String account) {
		this.account = account;
	}



	/**
	 * @return the nick
	 */
	public String getNick() {
		return nick;
	}



	/**
	 * @param nick the nick to set
	 */
	public void setNick(String nick) {
		this.nick = nick;
	}



	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}



	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}



	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}



	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}



	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}



	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}



	/**
	 * @return the valid
	 */
	public boolean isValid() {
		return valid;
	}



	/**
	 * @param valid the valid to set
	 */
	public void setValid(boolean valid) {
		this.valid = valid;
	}



	/**
	 * @return the superadmin
	 */
	public boolean isSuperadmin() {
		return superadmin;
	}



	/**
	 * @param superadmin the superadmin to set
	 */
	public void setSuperadmin(boolean superadmin) {
		this.superadmin = superadmin;
	}



	/**
	 * @return the entCode
	 */
	public String getEntCode() {
		return entCode;
	}



	/**
	 * @param entCode the entCode to set
	 */
	public void setEntCode(String entCode) {
		this.entCode = entCode;
	}



	/**
	 * @return the entId
	 */
	public String getEntId() {
		return entId;
	}



	/**
	 * @param entId the entId to set
	 */
	public void setEntId(String entId) {
		this.entId = entId;
	}



	/**
	 * @return the roles
	 */
	public List<String> getRoles() {
		return roles;
	}



	/**
	 * @param roles the roles to set
	 */
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}



	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}



	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}



	/**
	 * @return the contacts
	 */
	public String getContacts() {
		return contacts;
	}



	/**
	 * @param contacts the contacts to set
	 */
	public void setContacts(String contacts) {
		this.contacts = contacts;
	}



	/**
	 * @return the allowMobile
	 */
	public boolean isAllowMobile() {
		return allowMobile;
	}



	/**
	 * @param allowMobile the allowMobile to set
	 */
	public void setAllowMobile(boolean allowMobile) {
		this.allowMobile = allowMobile;
	}



	/**
	 * @return the deptId
	 */
	public String getDeptId() {
		return deptId;
	}



	/**
	 * @param deptId the deptId to set
	 */
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}



	/**
	 * @return the entStatus
	 */
	public boolean isEntStatus() {
		return entStatus;
	}



	/**
	 * @param entStatus the entStatus to set
	 */
	public void setEntStatus(boolean entStatus) {
		this.entStatus = entStatus;
	}



	/**
	 * @return the entExpiryDate
	 */
	public Date getEntExpiryDate() {
		return entExpiryDate;
	}



	/**
	 * @param entExpiryDate the entExpiryDate to set
	 */
	public void setEntExpiryDate(Date entExpiryDate) {
		this.entExpiryDate = entExpiryDate;
	}



	/**
	 * @return the entLogo
	 */
	public String getEntLogo() {
		return entLogo;
	}



	/**
	 * @param entLogo the entLogo to set
	 */
	public void setEntLogo(String entLogo) {
		this.entLogo = entLogo;
	}
	
	
}
