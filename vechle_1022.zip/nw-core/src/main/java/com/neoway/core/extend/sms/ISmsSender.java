/**
 * @company 有方物联
 * @file ISmsSender.java
 * @author guojy
 * @date 2017年9月29日 
 */
package com.neoway.core.extend.sms;

/**
 * @description :短信发送接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月29日
 */
public interface ISmsSender {
	/**
	 * 短信发送接口
	 * @param phoneNo 手机号
	 * @param content 发送内容
	 */
	public void send(String phoneNo,String content);
	/**
	 * @param phoneNo 手机号
	 * @param templateCode 短信模板ID（根据各个运营商不同，模板需要在运营商平台预先定义）
	 * @param signName 短信签名，空则使用默认签名
	 * @param jsonParam 短信模板变量参数（json格式、参数可选）
	 */
	public void send(String phoneNo,String templateCode,String signName,String jsonParam);
	/**
	 * @param phoneNo 手机号
	 * @param templateCode 短信模板ID（根据各个运营商不同，模板需要在运营商平台预先定义）
	 * @param jsonParam 短信模板变量参数（json格式、参数可选）
	 */
	public void send(String phoneNo,String templateCode,String jsonParam);
}
