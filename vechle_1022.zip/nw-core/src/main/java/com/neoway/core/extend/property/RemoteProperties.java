/**
 * @company 有方物联
 * @file RemoteProperties.java
 * @author guojy
 * @date 2017年9月26日 
 */
package com.neoway.core.extend.property;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.cloud.config.environment.Environment;
import org.springframework.cloud.config.environment.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


/**
 * @description :加载远程properties文件,实现非spring-boot项目整合spring cloud config
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月26日
 */
public class RemoteProperties implements InitializingBean, FactoryBean<Properties> {
	private Logger logger = LoggerFactory.getLogger(RemoteProperties.class);
	private Properties properties = new Properties();
	/**
	 * 文件模式
	 */
	private String profile;
	/**
	 * 远程配置uri
	 */
	private String uri;
	/**
	 * 配置文件名
	 */
	private String propertyName;
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void afterPropertiesSet() throws Exception {
		logger.debug("loading remote properties:" + uri);
		RestTemplate restTemplate = new RestTemplate();
		Object[] args = new String[] { propertyName, profile };
		HttpHeaders headers = new HttpHeaders();
		final HttpEntity<Void> entity = new HttpEntity<>((Void) null, headers);
		ResponseEntity<Environment> response = restTemplate.exchange(uri+"/{name}/{profile}", HttpMethod.GET,
				entity, Environment.class, args);
		if (response == null || response.getStatusCode() != HttpStatus.OK) {
			return;
		}
		Environment result = response.getBody();
		List<PropertySource> list = result.getPropertySources();
		for(PropertySource property:list){
			Map map = property.getSource();
			Iterator<Entry> iterator = map.entrySet().iterator();
			while(iterator.hasNext()){
				Entry entry = iterator.next();
				properties.put(entry.getKey(), entry.getValue());
			}
		}
		logger.info("加载远程配置信息：{}",properties);
	}

	@Override
	public Properties getObject() throws Exception {
		return properties;
	}

	@Override
	public Class<?> getObjectType() {
		return properties.getClass();
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	/**
	 * @param profile the profile to set
	 */
	public void setProfile(String profile) {
		this.profile = profile;
	}

	/**
	 * @param uri the uri to set
	 */
	public void setUri(String uri) {
		this.uri = uri;
	}

	/**
	 * @param propertyName the propertyName to set
	 */
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	
}
