/**
 * @company 有方物联
 * @file LoggingBean.java
 * @author guojy
 * @date 2017年9月21日 
 */
package com.neoway.core.logging.bean;

import java.util.Date;

/**
 * @description :操作日志bean
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月21日
 */
public class LoggingBean {
	/**
	 * 记录id
	 */
	private String logId;
	/**
	 * 操作内容
	 */
	private String detail;
	/**
	 * 操作类型：  新增/修改/删除/导入/导出
	 */
	private String type;
	/**
	 * 操作状态  成功/失败
	 */
	private Short state;
	/**
	 * 操作时间
	 */
	private Date createTime;
	/**
	 * 操作人
	 */
	private String createUser;
	/**
	 * @return the logId
	 */
	public String getLogId() {
		return logId;
	}
	/**
	 * @param logId the logId to set
	 */
	public void setLogId(String logId) {
		this.logId = logId;
	}
	/**
	 * @return the detail
	 */
	public String getDetail() {
		return detail;
	}
	/**
	 * @param detail the detail to set
	 */
	public void setDetail(String detail) {
		this.detail = detail;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the state
	 */
	public Short getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(Short state) {
		this.state = state;
	}
	/**
	 * @return the createTime
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * @param createTime the createTime to set
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * @return the createUser
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * @param createUser the createUser to set
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * @param logId
	 * @param detail
	 * @param type
	 * @param state
	 * @param createTime
	 * @param createUser
	 */
	public LoggingBean(String logId, String detail, String type, Short state, Date createTime, String createUser) {
		super();
		this.logId = logId;
		this.detail = detail;
		this.type = type;
		this.state = state;
		this.createTime = createTime;
		this.createUser = createUser;
	}
	/**
	 * 
	 */
	public LoggingBean() {
		super();
	}
	
	
}
