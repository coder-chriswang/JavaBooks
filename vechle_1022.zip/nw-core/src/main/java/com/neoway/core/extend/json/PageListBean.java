/**
 * @company 有方物联
 * @file PageListBean.java
 * @author guojy
 * @date 2018年3月23日 
 */
package com.neoway.core.extend.json;

import com.neoway.core.datasource.pagination.bean.PageList;

/**
 * @description :PageList包装类  解决json转化分页显示
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年3月23日
 */
public class PageListBean {
	private int contTotal;
	private PageList<?> data;
	/**
	 * @return the contTotal
	 */
	public int getContTotal() {
		return contTotal;
	}
	/**
	 * @param contTotal the contTotal to set
	 */
	public void setContTotal(int contTotal) {
		this.contTotal = contTotal;
	}
	/**
	 * @return the data
	 */
	public PageList<?> getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(PageList<?> data) {
		this.data = data;
	}
	/**
	 * @param contTotal
	 * @param data
	 */
	public PageListBean(int contTotal, PageList<?> data) {
		this.contTotal = contTotal;
		this.data = data;
	}

	
}
