/**
 * @company neoway
 * @file RedisConfig.java
 * @author guojy
 * @date 2019年4月19日
 */
package com.neoway.core.extend.redis;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * @description redis config
 * @author guojy
 * @version V1.0.0
 * @date 2019年04月19日 14:32:00
 */
@Configuration
public class RedisConfig {
	@Bean
	public RedisTemplate<?,?> getRedisTemplate(RedisConnectionFactory redisConnectionFactory){
		RedisTemplate<?,?> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(redisConnectionFactory);

        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}
}
