/**
 * @company 有方物联
 * @file ILoggingService.java
 * @author guojy
 * @date 2017年9月21日 
 */
package com.neoway.core.logging;

import com.neoway.core.logging.bean.LoggingBean;

/**
 * @description :操作日志基础服务接口
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月21日
 */
public interface ILoggingService {
	/**
	 * 记录操作日志
	 * @param loggingBean
	 */
	public void recordLog(LoggingBean loggingBean);
}
