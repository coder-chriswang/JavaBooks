/**
 * @company neoway
 * @file MybatisConfig.java
 * @author guojy
 * @date 2019年2月19日
 */
package com.neoway.core.extend.mybatis;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

/**
 * @description mybatis配置
 * @author guojy
 * @version V1.0.0
 * @date 2019年02月19日 11:25:18
 */
//@Configuration
public class MybatisConfig {
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private DataSource dataSource;
	
	@Bean
	public SqlSessionFactory sqlSessionFactory() throws Exception{
		logger.info("初始化SqlSessionFactory");
		PathMatchingResourcePatternResolver resolover = new PathMatchingResourcePatternResolver();
		
		TypeAliasesPackagePropExtend typeAliasesPackage = new TypeAliasesPackagePropExtend();
		typeAliasesPackage.setRootPackage("com/");
		typeAliasesPackage.setTypeAliasesPackages(new String[]{"com.**.entity"});
		
		SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
		sqlSessionFactory.setDataSource(dataSource);
		sqlSessionFactory.setConfigLocation(resolover.getResource("classpath:mybatis-config.xml"));
		sqlSessionFactory.setTypeAliasesPackage(typeAliasesPackage.getObject());
		sqlSessionFactory.setMapperLocations(resolover.getResources("classpath*:mapper/**/*Mapper.xml"));
		sqlSessionFactory.setVfs(SpringBootVFS.class);
		return sqlSessionFactory.getObject();
	}
}
