/**
 * @company 有方物联
 * @file WebInterceptor.java
 * @author guojy
 * @date 2017年9月21日 
 */
package com.neoway.core.intercept;

import java.lang.reflect.Method;
import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neoway.core.ICommonManager;
import com.neoway.core.annotation.LogRecord;
import com.neoway.core.exception.CustomRuntimeException;
import com.neoway.core.logging.ILoggingService;
import com.neoway.core.logging.bean.LoggingBean;
import com.neoway.util.ConstantUtil;
import com.neoway.util.DateUtil;
import com.neoway.util.StringUtil;

/**
 * @description :拦截器：处理Controller对外提供的接口是否有异常，异常全局处理
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月21日
 */
@Aspect
@Component
public class WebInterceptor {
	private static final Logger logger = LoggerFactory.getLogger(WebInterceptor.class);
	@Autowired(required=false)
	private ILoggingService loggingService;
	
	@Autowired(required=false)
	private ICommonManager commonManager;
	/**
	 * 拦截规则：
	 */
	@Pointcut("execution(* com.neoway..controller..*(..)) and @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	public void methodPointcut(){	
	}
	
	/**
	 * 拦截器方法过程
	 * @param pjp
	 * @return
	 */
	@Around("methodPointcut()")
	public Object interceptor(ProceedingJoinPoint pjp){
		MethodSignature signature = (MethodSignature) pjp.getSignature();  
        Method method = signature.getMethod(); 
        String methodName = method.getName();
        logger.debug("请求开始，方法：{}()", method.getDeclaringClass().getName()+"."+methodName);
        Object result = null;
        LoggingBean loggingBean = new LoggingBean();
        try {
        	result =  pjp.proceed();
        	loggingBean.setState(ConstantUtil.Status.SUCCESS);
        	recordLog(method, loggingBean);
		} catch (Throwable e) {
			loggingBean.setState(ConstantUtil.Status.ERROR);
			recordLog(method, loggingBean);
			throw new CustomRuntimeException("系统调用异常",e);
		}
        return result;
	}
	
	/**
	 * 操作日志记录
	 * @param method
	 * @param loggingBean
	 */
	private void recordLog(Method method,LoggingBean loggingBean){
		if(method.isAnnotationPresent(LogRecord.class) && loggingService != null){
        	ServletRequestAttributes attributes  = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        	Map<String, String[]> params = attributes.getRequest().getParameterMap();
        	LogRecord logRecordAnnotation = method.getAnnotation(LogRecord.class);
        	try {
        		ObjectMapper objectMapper = new ObjectMapper();
				String content = objectMapper.writeValueAsString(params);
				loggingBean.setDetail(logRecordAnnotation.logPrefixDesc()+":"+content);
			} catch (JsonProcessingException e) {
				logger.error("参数转化异常：{}", e.getMessage());
				loggingBean.setDetail(logRecordAnnotation.logPrefixDesc()+":"+"参数转化异常："+e.getMessage());
			}
        	loggingBean.setCreateTime(DateUtil.getDate());
        	loggingBean.setCreateUser(commonManager!=null?commonManager.getCurrentAccount():"");
        	loggingBean.setLogId(StringUtil.getUUID());
        	loggingBean.setType(logRecordAnnotation.operateType().getName());
        	loggingService.recordLog(loggingBean);
        }
	}
}
