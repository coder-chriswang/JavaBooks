/**
 * @company 有方物联
 * @file LogRecord.java
 * @author guojy
 * @date 2017年9月21日 
 */
package com.neoway.core.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.neoway.core.enums.LogOperatorType;

/**
 * @description :操作日志记录注解
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月21日
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface LogRecord {
	/**
	 * 日志操作类型
	 * @return
	 */
	LogOperatorType operateType();
	
	/**
	 * 操作日志前缀说明
	 * @return
	 */
	String logPrefixDesc() default ":";
}
