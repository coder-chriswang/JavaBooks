/**
 * @company 有方物联
 * @file JsonFilter.java
 * @author guojy
 * @date 2018年2月5日 
 */
package com.neoway.core.extend.json;

/**
 * @description :json过滤器包装实体类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年2月5日
 */
public class JsonFilter {
	/**
	 * 过滤目标对象class  为空则全对象过滤
	 */
	private Class<?> clazz;
	/**
	 * 过滤的字段列表
	 */
	private String[] properties;
	/**
	 * true则包含过滤字段   false则排除过滤字段
	 */
	private boolean isInclude;
	/**
	 * @return the clazz
	 */
	public Class<?> getClazz() {
		return clazz;
	}
	/**
	 * @return the properties
	 */
	public String[] getProperties() {
		return properties;
	}
	/**
	 * @return the isInclude
	 */
	public boolean isInclude() {
		return isInclude;
	}
	/**
	 * @param clazz
	 * @param properties
	 * @param isInclude
	 */
	public JsonFilter(Class<?> clazz, String[] properties, boolean isInclude) {
		this.clazz = clazz;
		this.properties = properties;
		this.isInclude = isInclude;
	}
	
	
}
