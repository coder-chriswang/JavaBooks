/**
 * @company 有方物联
 * @file IUserManager.java
 * @author guojy
 * @date 2017年9月21日 
 */
package com.neoway.core;

import com.neoway.core.bean.User;

/**
 * @description :基础管理接口  用户信息/
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月21日
 */
public interface ICommonManager {
	/**
	 * 获取当前登录用户账号
	 * @return
	 */
	public String getCurrentAccount();
	
	/**
	 * 获取用户全量信息
	 * @return
	 */
	public User getUser();
	
	/**
	 * 重新加载用户权限
	 * @param accounts
	 */
	public void reloadUserAuthorization(String... accounts);
}
