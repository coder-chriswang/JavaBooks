/**
 * @company 有方物联
 * @file HBaseConfig.java
 * @author guojy
 * @date 2018年4月16日 
 */
package com.neoway.core.extend.hadoop;

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.hadoop.hbase.HbaseTemplate;

/**
 * @description :
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年4月16日
 */
@Configuration
@ConditionalOnProperty(value = "hbase.switch", havingValue = "true" ,matchIfMissing = false)
public class HBaseConfig {
	/**
	 * 创建hbase连接
	 * @param quorum hbase集群地址  多个ip用逗号分隔
	 * @param port zookeeper端口
	 * @return
	 * @throws IOException
	 */
	@Bean
	public Connection getHbaseConn(@Value("${hbase.zookeeper.quorum}") String quorum,@Value("${hbase.zookeeper.port}") String port) throws IOException{
		org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();  
        conf.set("hbase.zookeeper.quorum", quorum);  
        conf.set("hbase.zookeeper.port", port); 
        return ConnectionFactory.createConnection(conf);
	}
	
	@Bean
	public HbaseTemplate getHbaseTemplate(@Value("${hbase.zookeeper.quorum}") String quorum,@Value("${hbase.zookeeper.port}") String port) throws IOException{
		HbaseTemplate hbaseTemplate = new HbaseTemplate();
		org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();  
        conf.set("hbase.zookeeper.quorum", quorum);  
        conf.set("hbase.zookeeper.port", port); 
		hbaseTemplate.setConfiguration(conf);
		hbaseTemplate.setAutoFlush(true);
		return hbaseTemplate;
	}
}
