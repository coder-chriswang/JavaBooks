/**
 * @company 有方物联
 * @file JsonMessageConverterExtend.java
 * @author guojy
 * @date 2017年9月20日 
 */
package com.neoway.core.web;

import java.io.IOException;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.neoway.core.datasource.pagination.bean.PageList;

/**
 * @description :自定义对象转化处理逻辑
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月20日
 */
public class JsonMessageConverterExtend extends AbstractHttpMessageConverter<PageList<?>> {
	private static Logger logger = LoggerFactory.getLogger(JsonMessageConverterExtend.class);
	@Value("${spring.jackson.date-format}")
	private String pattern;
	@Value("${spring.jackson.time-zone}")
	private String timeZoneId;
	@Override
	protected boolean supports(Class<?> clazz) {
		return PageList.class.isAssignableFrom(clazz);
	}

	public JsonMessageConverterExtend() {
		super(Charset.forName("UTF-8"),new MediaType("application", "json", Charset.forName("UTF-8")));
	}

	@Override
	protected PageList<?> readInternal(Class<? extends PageList<?>> clazz, HttpInputMessage inputMessage)
			throws IOException, HttpMessageNotReadableException {
		logger.info("目前不支持读取前端参数转化为PageList对象");
		return null;
	}

	@Override
	protected void writeInternal(PageList<?> pageList, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {
		ObjectMapper objectMapper = Jackson2ObjectMapperBuilder.json().build();
		objectMapper.setDateFormat(new SimpleDateFormat(pattern));
		objectMapper.setTimeZone(TimeZone.getTimeZone(timeZoneId));
		JsonEncoding encoding = getJsonEncoding(outputMessage.getHeaders().getContentType());
		JsonGenerator jsonGenerator = objectMapper.getFactory().createGenerator(outputMessage.getBody(), encoding);
		if(objectMapper.isEnabled(SerializationFeature.INDENT_OUTPUT)){
			jsonGenerator.useDefaultPrettyPrinter();
		}
		ObjectNode objNode = objectMapper.createObjectNode();
		if(pageList!=null){
			objNode.put("contTotal", pageList.getPaginator().getTotalCount());
		}else{
			objNode.put("contTotal", 0);
		}
		objNode.putPOJO("data", pageList);
		objectMapper.writeValue(jsonGenerator, objNode);
	}
	
	protected JsonEncoding getJsonEncoding(MediaType contentType) {
		if (contentType != null && contentType.getCharset() != null) {
			Charset charset = contentType.getCharset();
			for (JsonEncoding encoding : JsonEncoding.values()) {
				if (charset.name().equals(encoding.getJavaName())) {
					return encoding;
				}
			}
		}
		return JsonEncoding.UTF8;
	}
}
