/**
 * @company 有方物联
 * @file StringToArray.java
 * @author guojy
 * @date 2017年9月22日 
 */
package com.neoway.core.extend.format;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * @description :字符串序列化为Json
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月22日
 */
public class StringToJsonSerializer extends JsonSerializer<String> {

	@Override
	public void serialize(String value, JsonGenerator gen, SerializerProvider serializers)
			throws IOException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		Object val = jsonToBean(value,objectMapper);
		gen.writeObject(val);
	}

	private Object jsonToBean(String json,ObjectMapper objectMapper) throws JsonParseException, JsonMappingException, IOException{
		if(isJsonObject(json)){
			Map<String,Object> mapResult = new HashMap<String,Object>();
			Map<String,String> map = objectMapper.readValue (json,new TypeReference<Map<String,String>>() {});
			Iterator<Entry<String, String>> iterator = map.entrySet().iterator();
			while(iterator.hasNext()){
				Entry<String, String> entry = iterator.next();
				Object val = jsonToBean(entry.getValue(),objectMapper);
				mapResult.put(entry.getKey(), val);
			}
			return map;
		}else if(isJsonArray(json)){
			List<Object> list = new ArrayList<Object>();
			List<Map<String,String>> listTmp = objectMapper.readValue (json,new TypeReference<List<Map<String,String>>>() {});
			for(Map<String,String> tmpMap:listTmp){
				Object val = jsonToBean(tmpMap,objectMapper);
				list.add(val);
			}
			return list;
		}else{
			return json;
		}
	}
	
	private Object jsonToBean(Map<String,String> jsonMap,ObjectMapper objectMapper) throws JsonParseException, JsonMappingException, IOException{
		Map<String,Object> mapResult = new HashMap<String,Object>();
		Iterator<Entry<String, String>> iterator = jsonMap.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<String, String> entry = iterator.next();
			Object val = jsonToBean(entry.getValue(),objectMapper);
			mapResult.put(entry.getKey(), val);
		}
		return mapResult;
	}
	
	private boolean isJsonObject(String json){
		if(json==null || json.trim().equals(""))
			return false;
		char begin = json.trim().charAt(0);
		if(begin == '{'){
			return true;
		}else{
			return false;
		}
	}
	private boolean isJsonArray(String json){
		if(json==null || json.trim().equals(""))
			return false;
		char begin = json.trim().charAt(0);
		if(begin == '['){
			return true;
		}else{
			return false;
		}
	}
}
