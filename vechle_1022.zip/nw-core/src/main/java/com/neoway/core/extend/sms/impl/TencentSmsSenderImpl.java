/**
 * @company 有方物联
 * @file ITencentSmsSender.java
 * @author bailu
 * @date 2017年9月29日 
 */
package com.neoway.core.extend.sms.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.neoway.core.extend.sms.ISmsSender;
import com.neoway.util.StringUtil;

/**
 * @description : 腾讯云短信
 * @author : bailu
 * @version : V1.0.0
 * @date : 2017年9月29日
 */
public class TencentSmsSenderImpl implements ISmsSender {
	
	/**
	 * post发送短信请求地址
	 */
//	@Value("${tencent.sms.url}")
	private String url;
	
	/**
	 * APPID
	 */
//	@Value("${tencent.sms.appid}")
	private int appid;
	
	/**
	 * APPKEY
	 */
//	@Value("${tencent.sms.appkey}")
	private String appkey;
	
	/**
	 * 国家编码
	 */
//	@Value("${tencent.sms.nationcode}")
	private String nationcode;

	
	/* (non-Javadoc)
	 * @see com.etiot.core.extend.sms.ISmsSender#send(java.lang.String, java.lang.String)
	 */
	@Override
	public void send(String phoneNo, String content) {
		// 按照协议组织 post 请求包体
        long random = StringUtil.getRandom();
        long curTime = System.currentTimeMillis()/1000;
        
        ObjectMapper mapper = new ObjectMapper(); 
        ObjectNode tel = mapper.createObjectNode();
        tel.put("nationcode", nationcode);
        tel.put("mobile", phoneNo);
        
        ObjectNode data = mapper.createObjectNode();         
        data.put("type", 0);
    	data.put("msg", content);
        data.put("sig", StringUtil.strToSHA256(String.format("appkey=%s&random=%d&time=%d&mobile=%s", appkey, random, curTime, phoneNo)));
        data.putPOJO("tel", tel);
        data.put("time", curTime);
        data.put("extend", "");
        data.put("ext", "");
        
        // 与上面的 random 必须一致
		String wholeUrl = String.format("%s?sdkappid=%d&random=%d", url, appid, random);

        doPost(wholeUrl,data.toString());
	}

	/**
	 * 执行post请求
	 * @param url 请求url
	 * @param json 参数
	 * @return 响应结果
	 */
	private String doPost(String url, String json) {
		String result = "";
		try {
			URL object = new URL(url);
			HttpURLConnection conn;
		    conn = (HttpURLConnection) object.openConnection();
		    conn.setDoOutput(true);
		    conn.setDoInput(true);
		    conn.setRequestProperty("Content-Type", "application/json");
		    conn.setRequestProperty("Accept", "application/json");
		    conn.setRequestMethod("POST");
		       
		    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream(), "utf-8");
		    wr.write(json.toString());
		    wr.flush();

		   // 显示 POST 请求返回的内容
		   StringBuilder sb = new StringBuilder();
		   int httpRspCode = conn.getResponseCode();
		   if (httpRspCode == HttpURLConnection.HTTP_OK) {
			   BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
		   	   String line = null;
		       while ((line = br.readLine()) != null) {
		          sb.append(line);
		       }
		       br.close();
		       result = sb.toString();
		    } 
		} catch (Exception e) {
			e.printStackTrace();
		}
	   
		return result;
	}

	@Override
	public void send(String phoneNo, String templateCode, String signName, String jsonParam) {
		
	}

	@Override
	public void send(String phoneNo, String templateCode, String jsonParam) {
		this.send(phoneNo, templateCode, null, jsonParam);
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setAppid(int appid) {
		this.appid = appid;
	}

	public void setAppkey(String appkey) {
		this.appkey = appkey;
	}

	public void setNationcode(String nationcode) {
		this.nationcode = nationcode;
	}

	
}
