/**
 * @company 有方物联
 * @file RedisManager.java
 * @author guojy
 * @date 2018年1月23日 
 */
package com.neoway.core.extend.redis;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

/**
 * @description :Jedis 客户端包装管理类
 * @author : guojy
 * @version : V1.0.0
 * @date : 2018年1月23日
 */
@Component
public class RedisManager {
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	@Autowired
	private RedisTemplate<String, byte[]> redisTemplate;
		
	/**
	 * 通过字节数组key获取redis的值
	 * @param key
	 * @return
	 */
	public byte[] get(byte[] key){
		return redisTemplate.boundValueOps(new String(key)).get();
	}
	
	/**
	 * 通过字节数组key设置redis的值value
	 * @param key
	 * @param value
	 * @return
	 */
	public void set(byte[] key,byte[] value){
		redisTemplate.boundValueOps(new String(key)).set(value);
	}
	
	/**
	 * 通过字节数组key设置redis的值value
	 * @param key
	 * @param value
	 * @param expire 数据存活时间
	 * @return
	 */
	public void set(byte[] key,byte[] value,int expire){
		redisTemplate.boundValueOps(new String(key)).set(value, expire, TimeUnit.SECONDS);
	}
	
	/**
	 * 通过字节数组key删除redis值
	 * @param key
	 */
	public void del(byte[] key){
		redisTemplate.delete(new String(key));
	}
	
	/**
	 * 通过字符串key获取redis的值
	 * @param key
	 * @return
	 */
	public String get(String key){
		return stringRedisTemplate.boundValueOps(key).get();
	}
	
	
	/**
	 * 通过字符串key设置redis的值value
	 * @param key
	 * @param value
	 * @return
	 */
	public void set(String key,String value){
		stringRedisTemplate.boundValueOps(key).set(value);
	}
	/**
	 * 通过字符串key设置redis的值value
	 * @param key
	 * @param value
	 * @param expire SECONDS数据存活时间
	 * @return
	 */
	public void set(String key,String value,int expire){
		stringRedisTemplate.boundValueOps(key).set(value, expire, TimeUnit.SECONDS);
	}
	
	
	/**
	 * 通过字符key删除redis值
	 * @param key
	 */
	public void del(String... key){
		List<String> keys = Lists.newArrayList(key);
		stringRedisTemplate.delete(keys);
	}
	
	/**
	 * redis存储map
	 * @param key
	 * @param map
	 */
	public void putMap(String key,Map<String,String> map){
		stringRedisTemplate.boundHashOps(key).putAll(map);
	}
	
	/**
	 * redis存储hash
	 * @param key
	 * @param field
	 * @param value
	 */
	public void putMap(String key,String field,String value){
		stringRedisTemplate.boundHashOps(key).put(field, value);
	}
	
	/**
	 * redis存储map
	 * @param key
	 * @param map
	 * @param expire SECONDS
	 */
	public void putMap(String key,Map<String,String> map,int expire){
		stringRedisTemplate.boundHashOps(key).putAll(map);
		stringRedisTemplate.boundHashOps(key).expire(expire, TimeUnit.SECONDS);
	}
	
	/**
	 * 删除Map中对应field的记录
	 * @param key
	 * @param field
	 * @param value
	 */
	public void delMapFiled(String key,String field,String value){
		stringRedisTemplate.boundHashOps(key).delete(field);
	}
	
	/**
	 * 通过key获取map对象
	 * @param key
	 * @return
	 */
	public Map<String,String> getMapByKey(String key){
		return stringRedisTemplate.<String,String>boundHashOps(key).entries();
	}
	
	/**
	 * redis存储list对象
	 * @param key
	 * @param list
	 */
	public void putList(String key,List<String> list){
		String[] strings = new String[list.size()];
		stringRedisTemplate.boundListOps(key).leftPushAll(list.toArray(strings));
	}
	
	/**
	 * 更新list中对应索引的值
	 * @param key
	 * @param index
	 * @param value
	 */
	public void updateListVal(String key,int index,String value){
		stringRedisTemplate.boundListOps(key).set(index, value);
	}
	
	/**
	 * redis存储list对象
	 * @param key
	 * @param list
	 * @param expire
	 */
	public void putList(String key,List<String> list,int expire){
		String[] strings = new String[list.size()];
		stringRedisTemplate.boundListOps(key).leftPushAll(list.toArray(strings));
		stringRedisTemplate.boundListOps(key).expire(expire, TimeUnit.SECONDS);
	}
	
	/**
	 * 删除list中对应的元素
	 * @param key
	 * @param value
	 */
	public void delListMember(String key,String value){
		stringRedisTemplate.boundListOps(key).remove(0, value);
	}
	
	/**
	 * 获取list中最新记录
	 * @param key redis中的key
	 * @param start list起始索引位置
	 * @param end list中结束索引位置
	 * @return
	 */
	public List<String> getListLeft(String key,long start,long end){
		return stringRedisTemplate.boundListOps(key).range(start, end);
	}
	
	/**
	 * redis存储set对象
	 * @param key
	 * @param vals set中的元素
	 */
	public void putSet(String key,String... vals){
		stringRedisTemplate.boundSetOps(key).add(vals);
	}
	
	/**
	 * 移除set中的元素
	 * @param key
	 * @param members set中的元素
	 */
	public void delSetMembers(String key,String... members){
		if(members == null || members.length == 0){
			return;
		}
		Object[] mem = new Object[members.length];
		System.arraycopy(members, 0, mem, 0, members.length);
		stringRedisTemplate.boundSetOps(key).remove(mem);
	}
	
	/**
	 * 获取set中的元素
	 * @param key
	 */
	public Set<String> getSetMembers(String key){
		return stringRedisTemplate.boundSetOps(key).members();
	}
	
	/**
	 * 获取set中的元素
	 * @param keys
	 */
	public Set<String> getSetMembers(String... keys){
		Set<String> retSet = Sets.newHashSet();
		for(String key:keys){
			retSet.addAll(getSetMembers(key));
		}
		return retSet;
	}
	
	/**
	 * 删除当前database的所有key
	 */
	public void flushDB(){
		stringRedisTemplate.getConnectionFactory().getConnection().flushDb();
	}
	
	/**
	 * 获取当前database的key个数
	 * @return
	 */
	public Long dbSize(){
		return stringRedisTemplate.getConnectionFactory().getConnection().dbSize();
	}
	
	/**
	 * 通过表达式获取key的列表
	 * @param pattern
	 * @return
	 */
	public Set<String> keys(String pattern){
		return stringRedisTemplate.keys(pattern);
	}
	
	/**
	 * 通过表达式获取key的列表
	 * @param pattern
	 * @return
	 */
	public Set<String> keys(byte[] pattern){
		return redisTemplate.keys(new String(pattern));
	}

}
