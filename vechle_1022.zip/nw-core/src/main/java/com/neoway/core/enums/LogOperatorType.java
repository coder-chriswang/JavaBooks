/**
 * @company 有方物联
 * @file LogOperateType.java
 * @author guojy
 * @date 2017年9月21日 
 */
package com.neoway.core.enums;

/**
 * @description :日志操作类型枚举
 * @author : guojy
 * @version : V1.0.0
 * @date : 2017年9月21日
 */
public enum LogOperatorType {
	ADD("新增"),
	MODIFY("修改"),
	DELETE("删除"),
	EXPORT("导出"),
	IMPORT("导入");
	
	private String name;
	
	/**
	 * @param name
	 */
	private LogOperatorType(String name) {
		this.name = name;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
}
