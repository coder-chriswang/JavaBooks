package com.neoway.mqtt.analyse.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import com.neoway.mqtt.analyse.mapper.TopoShowDataMapper;
import com.neoway.mqtt.analyse.model.TopoModel;
import com.neoway.mqtt.analyse.service.TopoShowDataService;
import com.neoway.mqtt.analyse.util.NetInfoUtil;
import com.neoway.mqtt.analyse.vo.TopoCapabilityVo;
import com.neoway.mqtt.analyse.vo.TopoNodeDataVo;
import com.neoway.mqtt.analyse.vo.TopoNodeVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * <pre>
 * 描述：拓扑数据展示service实现层
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 11:04
 */
@Service
@Slf4j
public class TopoShowDataServiceImpl implements TopoShowDataService {

    @Autowired
    TopoShowDataMapper topoShowDataMapper;

    @Override
    public List<TopoNodeVo> findTopoInfo() {
        List<TopoModel> topoModelList = topoShowDataMapper.findTopoInfo(DateUtil.today());
        if (CollectionUtil.isEmpty(topoModelList)) {
            log.error("未查询到设备节点信息");
            return null;
        }
        List<String> currentCellIdList = CollectionUtil.newArrayList();
        List<TopoNodeVo> topoNodeVoList = CollectionUtil.newArrayList();
        for (TopoModel topoModel : topoModelList) {
            if (!currentCellIdList.contains(topoModel.getCurrentCellId())){
                currentCellIdList.add(topoModel.getCurrentCellId());
            }
        }

        for (String currentCellId : currentCellIdList) {
            TopoNodeVo topoNodeVo = new TopoNodeVo();
            List<String> imeiList = CollectionUtil.newArrayList();
            for (TopoModel topoModel : topoModelList) {
                if (currentCellId.equals(topoModel.getCurrentCellId())){
                    imeiList.add(topoModel.getImei());
                }
            }
            topoNodeVo.setCurrentCellId(currentCellId);
            topoNodeVo.setImeis(imeiList);
            topoNodeVoList.add(topoNodeVo);
        }
        return topoNodeVoList;
    }

    @Override
    public TopoNodeDataVo findBaseStationDataOfDay(String currentCellId) {
        // 查询基站网络信号
        List<TopoCapabilityVo> topoCapabilityVoList = topoShowDataMapper.findBaseStationSingnal(currentCellId, DateUtil.today());
        // 返回基站信息实体,查询基站基础信息
        TopoNodeDataVo topoNodeDataVo = topoShowDataMapper.findBaseStationData(currentCellId, DateUtil.today());
        if (topoNodeDataVo != null){
            if (StringUtils.isNotBlank(topoNodeDataVo.getOperator())) {
                String operator = NetInfoUtil.getNetOperator(topoNodeDataVo.getOperator());
                topoNodeDataVo.setOperator(operator);
            }
            // 判断网络质量
            TopoNodeDataVo topoNodeDataVo1 = topoShowDataMapper.findBaseStationAver(currentCellId, DateUtil.today());
            if (topoNodeDataVo1 != null){
                if (topoNodeDataVo1.getRsrpValue() != null && topoNodeDataVo1.getSinrValue() != null){
                    String signalLevel = NetInfoUtil.getNetStatus(topoNodeDataVo1.getRsrpValue(), topoNodeDataVo1.getSinrValue());
                    topoNodeDataVo.setSignalLevel(signalLevel);
                } else {
                    topoNodeDataVo.setSignalLevel("未知");
                }
            } else {
                topoNodeDataVo.setSignalLevel("未知");
            }
            // 加入网络信号集合
            topoNodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            return topoNodeDataVo;
        } else {
            topoNodeDataVo = new TopoNodeDataVo();
            topoNodeDataVo.setSignalLevel("未知");
            topoNodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            return topoNodeDataVo;
        }
    }


    @Override
    public TopoNodeDataVo findDeviceNodeDataOfDay(String imei) {
        // 查询设备网络信号
        List<TopoCapabilityVo> topoCapabilityVoList = topoShowDataMapper.findDeviceNodeSingnal(imei, DateUtil.today());
        // 返回设备信息实体,查询设备基础信息
        TopoNodeDataVo nodeDataVo = topoShowDataMapper.findDeviceNodeData(imei, DateUtil.today());
        if (nodeDataVo != null) {
            if (StringUtils.isNotBlank(nodeDataVo.getOperator())) {
                String operator = NetInfoUtil.getNetOperator(nodeDataVo.getOperator());
                nodeDataVo.setOperator(operator);
            }
            // 加入网络信号集合
            nodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            // 判断网络质量
            if (nodeDataVo.getLateRsrpValue() != null && nodeDataVo.getLateSinrValue() != null){
                String signalLevel = NetInfoUtil.getNetStatus(nodeDataVo.getLateRsrpValue(), nodeDataVo.getLateSinrValue());
                nodeDataVo.setSignalLevel(signalLevel);
            } else {
                nodeDataVo.setSignalLevel("未知");
            }
            return nodeDataVo;
        } else {
            nodeDataVo = new TopoNodeDataVo();
            nodeDataVo.setSignalLevel("未知");
            nodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            return nodeDataVo;
        }
    }

    @Override
    public TopoNodeDataVo findBaseStationDataOfDays(String currentCellId, int dayNum) {
        Date toDate = DateUtil.parse(DateUtil.today());
        Date fromDate = DateUtil.parse(DateUtil.offsetDay(toDate, dayNum + 1).toString());
        Date endOfNowDate = DateUtil.endOfDay(toDate);
        // 查询基站网络信号
        List<TopoCapabilityVo> topoCapabilityVoList = topoShowDataMapper.findBaseStationSingnalOfDays(currentCellId, fromDate, endOfNowDate);
        // 返回基站信息实体,查询基站基础信息
        TopoNodeDataVo topoNodeDataVo = topoShowDataMapper.findBaseStationDataOfDays(currentCellId, fromDate, endOfNowDate);
        if (topoNodeDataVo != null){
            if (StringUtils.isNotBlank(topoNodeDataVo.getOperator())) {
                String operator = NetInfoUtil.getNetOperator(topoNodeDataVo.getOperator());
                topoNodeDataVo.setOperator(operator);
            }
            // 判断网络质量
            TopoNodeDataVo topoNodeDataVo1 = topoShowDataMapper.findBaseStationAverOfDays(currentCellId, fromDate, endOfNowDate);
            if (topoNodeDataVo1 != null){
                if (topoNodeDataVo1.getRsrpValue() != null && topoNodeDataVo1.getSinrValue() != null){
                    String signalLevel = NetInfoUtil.getNetStatus(topoNodeDataVo1.getRsrpValue(), topoNodeDataVo1.getSinrValue());
                    topoNodeDataVo.setSignalLevel(signalLevel);
                } else {
                    topoNodeDataVo.setSignalLevel("未知");
                }
            } else {
                topoNodeDataVo.setSignalLevel("未知");
            }
            // 加入网络信号集合
            topoNodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            return topoNodeDataVo;
        } else {
            topoNodeDataVo = new TopoNodeDataVo();
            topoNodeDataVo.setSignalLevel("未知");
            topoNodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            return topoNodeDataVo;
        }
    }

    @Override
    public TopoNodeDataVo findDeviceNodeDataOfDays(String imei, int dayNum) {
        Date toDate = DateUtil.parse(DateUtil.today());
        Date fromDate = DateUtil.parse(DateUtil.offsetDay(toDate, dayNum + 1).toString());
        Date endOfNowDate = DateUtil.endOfDay(toDate);
        // 查询设备网络信号
        List<TopoCapabilityVo> topoCapabilityVoList = topoShowDataMapper.findDeviceNodeSingnalOfDays(imei, fromDate, endOfNowDate);
        // 返回设备信息实体,查询设备基础信息
        TopoNodeDataVo nodeDataVo = topoShowDataMapper.findDeviceNodeDataOfDays(imei, fromDate, endOfNowDate);
        if (nodeDataVo != null) {
            if (StringUtils.isNotBlank(nodeDataVo.getOperator())) {
                String operator = NetInfoUtil.getNetOperator(nodeDataVo.getOperator());
                nodeDataVo.setOperator(operator);
            }
            // 加入网络信号集合
            nodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            // 判断网络质量
            if (nodeDataVo.getLateRsrpValue() != null && nodeDataVo.getLateSinrValue() != null){
                String signalLevel = NetInfoUtil.getNetStatus(nodeDataVo.getLateRsrpValue(), nodeDataVo.getLateSinrValue());
                nodeDataVo.setSignalLevel(signalLevel);
            } else {
                nodeDataVo.setSignalLevel("未知");
            }
            return nodeDataVo;
        } else {
            nodeDataVo = new TopoNodeDataVo();
            nodeDataVo.setSignalLevel("未知");
            nodeDataVo.setCapabilityVoList(topoCapabilityVoList);
            return nodeDataVo;
        }
    }
}
