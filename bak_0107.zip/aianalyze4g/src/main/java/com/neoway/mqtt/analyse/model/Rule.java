package com.neoway.mqtt.analyse.model;


import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 规则类实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/10 13:43
 */
@ApiModel("规则类实体")
@Data
public class Rule implements Serializable {

    private static final long serialVersionUID = 1204511074865987534L;

    @ApiModelProperty("规则编号")
    private Integer id;

    @ApiModelProperty("规则名称")
    private String name;

    @ApiModelProperty("规则具体内容")
    private String rule;

    @ApiModelProperty("所属工程")
    private String projectName;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("规则创建时间")
    private Date createTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("规则更新时间")
    private Date updateTime;

    @ApiModelProperty("规则可见情况，0表示不可见，1表示可见")
    private Integer visible;

    @ApiModelProperty("规则启用状态，0表示停用，1表示启用")
    private Integer status;

    @ApiModelProperty("规则类型，0表示系统规则，1表示用户规则")
    private Integer type;

    @ApiModelProperty("规则描述")
    private String description;
}
