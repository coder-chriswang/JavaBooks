package com.neoway.mqtt.analyse.service;


import com.neoway.mqtt.analyse.model.AlarmInfo;
import com.neoway.mqtt.analyse.model.AlarmInfoSearchCondition;
import com.neoway.mqtt.analyse.model.DeviceNodeInfo;

import java.util.List;

/**
 * 设备节点信息业务接口
 * @author tuo.yang
 */
public interface DeviceNodeDataService {

    /**
     * 根据节点imei号查询设备节点具体信息
     * @return
     */
    List<DeviceNodeInfo> getDeviceNodeInfo();


    /**
     * 更新设备处理告警信息状态（支持单个操作和批量操作）
     * @param imeis
     * @param userId
     */
    void updateAlarmStatus(String userId, List<Integer> imeis);

    /**
     * 告警派单，支持单个派单和批量派单
     * @param imeis
     * @param userId
     */
    void manualDispatch(String userId, List<String> imeis);

    /**
     * 查询历史告警信息
     * @return list
     */
    List<AlarmInfo> getHistoryInfo(AlarmInfoSearchCondition alarmInfoSearchCondition);


    /**
     * 查询当前告警信息
     * @return list
     */
    List<AlarmInfo> getAlarmInfo(AlarmInfoSearchCondition alarmInfoSearchCondition);

    /**
     * 通过id查询设备详情
     * @param id
     * @return
     */
    AlarmInfo findAlarmInfoById(Integer id);
}
