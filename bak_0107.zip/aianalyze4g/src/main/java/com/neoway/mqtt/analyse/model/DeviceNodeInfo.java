package com.neoway.mqtt.analyse.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 设备节点信息封装类
 * @author tuo.yang
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceNodeInfo implements Serializable {

    private static final long serialVersionUID = 8359718004206739300L;
    private String imei;

    private String currentCellId;

    private String operator;

    private String nodeName;

    private String netMode;

    private String nodeNameEn;

    private String nodeTypeEn;

    private String cellId;

    private String nodeType;

    private String modeType;

    private String simType;

    private String cellPci;

    private String networkStatus;
    private int severeAlarmNo = 0;

    private Double lteRsrq;

    private Double lteSnr;

    private Double wcdRsrp;

    private Double wcdSnr;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date upTime;
}
