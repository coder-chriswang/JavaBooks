package com.neoway.mqtt.analyse.config.oauth2;

import com.neoway.kernel.model.response.HttpResult;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * <pre>
 *  描述: 自定义用户无访问权限时异常处理
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/19 15:12
 */
public class AuthExceptionEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                         AuthenticationException e) throws IOException, ServletException {
        //解析全局异常
        HttpResult httpResult = GlobalControllerAdvice.resolveException(e);
        //设置响应类型
        httpServletResponse.setContentType("application/json");
        //设置浏览器状态码
        httpServletResponse.setStatus(HttpServletResponse.SC_OK);
        //设置响应体
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.writeValue(httpServletResponse.getOutputStream(),httpResult);
    }
}
