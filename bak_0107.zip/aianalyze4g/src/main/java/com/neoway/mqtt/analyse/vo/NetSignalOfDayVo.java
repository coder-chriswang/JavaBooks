package com.neoway.mqtt.analyse.vo;

import com.neoway.mqtt.analyse.model.NetSignalOfDay;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 * 描述：运营商网络信号对比趋势返回实体
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/15 11:36
 */
@Data
@ApiModel(value = "运营商网络信号对比趋势返回实体")
public class NetSignalOfDayVo implements Serializable {
    private static final long serialVersionUID = -555119035767713483L;

    @ApiModelProperty("移动网络")
    List<NetSignalOfDay> cmccList;

    @ApiModelProperty("联通网络")
    List<NetSignalOfDay> cuccList;

    @ApiModelProperty("电信网络")
    List<NetSignalOfDay> ctccList;
}
