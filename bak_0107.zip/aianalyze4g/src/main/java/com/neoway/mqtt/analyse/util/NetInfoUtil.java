package com.neoway.mqtt.analyse.util;

import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 *  描述: 统一处理设备相关信息工具类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/14 9:21
 */
@Slf4j
public class NetInfoUtil {

    /**
     * 获取网络状态
     * @param rsrp
     * @param snr
     * @return
     */
    public static String getNetStatus(double rsrp, double snr) {
        String status = "";
        try {
            if (snr <= 5) {
                if (rsrp <= -105) {
                    status = "差";
                } else {
                    status = "优";
                }
            } else if (snr <= 15) {
                if (rsrp <= -95) {
                    status = "优";
                } else {
                    status = "中";
                }
            } else if (snr <= 25) {
                if (rsrp > -95 && rsrp <= -85) {
                    status = "中";
                } else {
                    status = "优";
                }
            } else {
                status = "优";
            }
        } catch (Exception e) {
            log.error("获取网络状态有误");
        }
        return status;
    }

    /**
     * 获取网络运营商
     * @param plmn
     * @return
     */
    public static String getNetOperator(String plmn){
        String operator = "";
        try {
            if (OperatorEnum.CMCC.getPlmn().contains(plmn)){
                operator = OperatorEnum.CMCC.getChinaOperator();
            } else if (OperatorEnum.CUCC.getPlmn().contains(plmn)) {
                operator = OperatorEnum.CUCC.getChinaOperator();
            } else if (OperatorEnum.CTCC.getPlmn().contains(plmn)){
                operator = OperatorEnum.CTCC.getChinaOperator();
            } else {
                operator = OperatorEnum.UNKNOWN.getChinaOperator();
            }
        } catch (Exception e) {
            log.error("获取网络运营商有误");
        }
        return operator;
    }

}
