package com.neoway.mqtt.analyse.service;

import com.neoway.mqtt.analyse.vo.TopoNodeDataVo;
import com.neoway.mqtt.analyse.vo.TopoNodeVo;

import java.util.List;

/**
 * <pre>
 * 描述：拓扑数据展示service层
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 11:01
 */
public interface TopoShowDataService {

    /**
     * 查找基站与设备拓扑关系
     * @return
     */
    List<TopoNodeVo> findTopoInfo();

    /**
     * 查询当天基站节点的基础数据
     * @param currentCellId
     * @return
     */
    TopoNodeDataVo findBaseStationDataOfDay(String currentCellId);


    /**
     * 查询当天设备节点的基础数据
     * @param imei
     * @return
     */
    TopoNodeDataVo findDeviceNodeDataOfDay(String imei);

    /**
     * 查询周月基站节点的基础数据
     * @param currentCellId
     * @param dayNum
     * @return
     */
    TopoNodeDataVo findBaseStationDataOfDays(String currentCellId, int dayNum);

    /**
     * 查询周月设备节点的基础数据
     * @param imei
     * @param dayNum
     * @return
     */
    TopoNodeDataVo findDeviceNodeDataOfDays(String imei, int dayNum);
}
