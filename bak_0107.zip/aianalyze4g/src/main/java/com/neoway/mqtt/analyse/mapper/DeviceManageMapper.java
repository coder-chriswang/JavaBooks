package com.neoway.mqtt.analyse.mapper;

import com.neoway.mqtt.analyse.model.DeviceInfo;
import com.neoway.mqtt.analyse.model.DeviceSearchCondition;
import com.neoway.mqtt.analyse.vo.CellIdInfoVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 * 描述：设备管理mapper层
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/6 11:28
 */
@Mapper
public interface DeviceManageMapper {

    /**
     *  查询设备详情
     *  @param imei
     *  @return DeviceInfo
     */
    DeviceInfo findDetailInfoByImei(@Param("imei") String imei);

    /**
     *  更新设备信息
     *  @param deviceInfo
     */
    void updateDeviceInfo(@Param("deviceInfo") DeviceInfo deviceInfo);

    /**
     * 查询小区id
     * @param cellAddress
     * @param cellName
     * @return
     */
    String findCellIdByAddressName(@Param("cellAddress") String cellAddress, @Param("cellName") String cellName);

    /**
     * 删除设备信息
     * @param imei
     * @return
     */
    int deleteDeviceInfo(@Param("imei") String imei);

    /**
     * 查询设备是否在线
     * @param imei
     * @return
     */
    Boolean isOnline(@Param("imei") String imei);

    /**
     * 查询设备信息列表
     * @param searchCondition
     * @return
     */
    List<DeviceInfo> findDeviceInfo(@Param("searchCondition") DeviceSearchCondition searchCondition);

    /**
     * 批量存入设备信息
     * @param list
     */
    void batchInsertDeviceInfo(@Param("list") List<DeviceInfo> list);

    /**
     * 查询所有imei号
     * @return
     */
    List<String> findAllImei();

    /**
     * 查询小区地址和小区名称对应cellId
     * @return
     */
    List<CellIdInfoVo> findCellIdInfo();


    /**
     * 查询所有在线设备
     * @param imei
     * @return
     */
    List<String> findOnlineDevice(@Param("imei") String imei);
}
