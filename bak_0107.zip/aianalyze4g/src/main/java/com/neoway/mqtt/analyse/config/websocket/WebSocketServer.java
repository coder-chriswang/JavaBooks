package com.neoway.mqtt.analyse.config.websocket;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.neoway.mqtt.analyse.model.ModuleConfigParam;
import com.neoway.mqtt.analyse.model.ModuleDiagnoseParam;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.service.CommandSendService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * <pre>
 * 描述：核心类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/8/4 10:39
 */
@ServerEndpoint("/websocket/{sid}")
@Slf4j
@Component
public class WebSocketServer {

    private static CommandSendService commandSendServiceImpl;

    private static EmqRedisDao emqRedisDaoImpl;

    @Autowired
    CommandSendService commandSendService;

    @Autowired
    EmqRedisDao emqRedisDao;

    @PostConstruct
    public void beforeInit() {
        commandSendServiceImpl = commandSendService;
        emqRedisDaoImpl = emqRedisDao;
    }

    /**
     * 静态变量，用来记录当前在线连接数。应该把它设计成线程安全的
     */
    private static AtomicInteger onlineNum = new AtomicInteger();

    /**
     * concurrent包的线程安全Set，用来存放每个客户端对应的WebSocketServer对象
     */
    private static CopyOnWriteArraySet<WebSocketServer> sessionPools = new CopyOnWriteArraySet<>();

    /**
     * 与某个客户端的连接会话
     */
    private Session session;

    /**
     * 接收sid
     */
    private String sid="";

    /**
     * 发送消息
     * @param message
     * @throws IOException
     */
    public void sendMessage(String message) throws IOException {
        this.session.getBasicRemote().sendText(message);
        log.info("发送命令:{}到客户端:{}成功", message, sid);
    }

    /**
     * 给指定用户发送信息
     * @param sid
     * @param message
     */
    public static void sendInfo(@PathParam("sid") String sid, String message){
        log.info("推送消息到窗口：{}，推送内容：{}\n", sid,message);
        for (WebSocketServer item : sessionPools) {
            try {
                if (sid == null) {
                    log.error("找不到客户端");
                    return;
                } else if (item.sid.equals(sid)){
                    item.sendMessage(message);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    /**
     * 建立连接成功调用
     * @param session
     * @param sid
     */
    @OnOpen
    public void onOpen(Session session, @PathParam(value = "sid") String sid){
        this.session = session;
        sessionPools.add(this);
        addOnlineCount();
        this.sid = sid;
    }

    /**
     * 关闭连接时调用
     */
    @OnClose
    public void onClose(){
        sessionPools.remove(this);
        subOnlineCount();
    }

    /**
     * 收到客户端信息
     * @param message
     * @throws IOException
     */
    @OnMessage
    public void onMessage(String message) {
        log.info("已收到客户端消息", message);
        for (WebSocketServer item: sessionPools) {
            try {
                if (sid == null) {
                    item.sendMessage("请传入客户端id");
                    return;
                } else if (item.sid.equals(sid)){
                    log.info("message= {}", message);
                    Integer type = JSONObject.parseObject(message).getInteger("type");
                    if (type == 1){
                        ModuleDiagnoseParam moduleDiagnoseParam = JSON.parseObject(message,new TypeReference<ModuleDiagnoseParam>(){});
                        log.info(moduleDiagnoseParam.toString());
                        if (StringUtils.isBlank(moduleDiagnoseParam.getImei())) {
                            item.sendMessage("请传入imei");
                            return;
                        }
                        if (CollectionUtil.isEmpty(moduleDiagnoseParam.getDataModelList())) {
                            item.sendMessage("下发命令内容不能为空 ");
                            return;
                        } else {
                            long ts = System.currentTimeMillis();
                            moduleDiagnoseParam.setTime(String.valueOf(ts));
                            commandSendServiceImpl.moduleDiagnoseSend(moduleDiagnoseParam);
                            emqRedisDaoImpl.updateUniqueFlag(String.valueOf(ts));
                            String clientKey = moduleDiagnoseParam.getImei() + "#" + ts;
                            emqRedisDaoImpl.setClientId(clientKey,sid);
                        }
                    } else if (type == 2){
                        ModuleConfigParam moduleConfigParam = JSON.parseObject(message, new TypeReference<ModuleConfigParam>() {});
                        log.info(moduleConfigParam.toString());
                        if (StringUtils.isBlank(moduleConfigParam.getImei())){
                            item.sendMessage("请传入imei");
                            return;
                        }
                        if (moduleConfigParam.getReportTime() == null){
                            item.sendMessage("下发命令内容不能为空");
                        } else {
                            long ts = System.currentTimeMillis();
                            moduleConfigParam.getReportTime().setTime(ts);
                            commandSendServiceImpl.moduleConfigSend(moduleConfigParam);
                            String clientKey = moduleConfigParam.getImei() + "$" + ts;
                            emqRedisDaoImpl.setClientId(clientKey,sid);
                            emqRedisDaoImpl.setMoudleConfig(moduleConfigParam.getImei(),moduleConfigParam.getReportTime().getValue());
                        }
                    } else {
                        item.sendMessage("下发命令类型错误！");
                    }
                }
            } catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    /**
     * 错误时调用
     * @param session
     * @param throwable
     */
    @OnError
    public void onError(Session session, Throwable throwable){
        log.error("发生错误");
        throwable.printStackTrace();
    }

    public static void addOnlineCount(){
        onlineNum.incrementAndGet();
    }

    public static void subOnlineCount() {
        onlineNum.decrementAndGet();
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
