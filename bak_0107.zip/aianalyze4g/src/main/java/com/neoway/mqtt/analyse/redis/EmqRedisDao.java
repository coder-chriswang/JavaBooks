package com.neoway.mqtt.analyse.redis;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * 描述：redis
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 19:58
 */
public interface EmqRedisDao {

    /**
     * 存储更新配置信息
     * @param value
     */
    void updateConfig(Map<String, String> value);

    /**
     * 查询唯一配置
     * @return
     */
    Map<String, String> findConfig();

    /**
     * 删除配置信息
     */
    void deleteConfig();

    /**
     * 查询观测性能周期数
     * @return
     */
    Map<String,String> findObservationTimeConfig();

    /**
     * 删除观测性能周期数
     */
    void deleteObservationTime();

    /**
     * 更新观测性能周期数信息
     * @param observationTimeMap
     */
    void updateObservationTime(Map<String, String> observationTimeMap);

    /**
     * 查询cellId
     * @return
     */
    Map<String, String> findCellIdInfo();

    /**
     * 存储更新cellId信息
     * @param refreshMap
     */
    void updateCellIdInfo(Map<String, String> refreshMap);

    /**
     * 存储更新IMEI号
     * @param imei
     */
    void updateImei(String[] imei);

    /**
     * 查询所有的imei
     * @return
     */
    List<String> findAllImei();

    /**
     *  状态位设置
     * @param id
     * @param statusBit
     */
    void updateStatusBit(String id, Map<String, String> statusBit);

    /**
     * 查询状态位
     * @param id
     * @return
     */
    Map<String, String> findStatusBit(String id);

    /**
     *  存储excel导入信息
     * @param id
     * @param map
     */
    void updateErrorInfo(String id, Map<String, String> map);

    /**
     * 获取excel导入信息
     * @param id
     * @return
     */

    Map<String,String> getExcelErrorInfo(String id);

    /**
     * 删除缓存中的imei号
     * @param imei
     */
    void deleteRedisImei(String imei);

    /**
     * 删除状态位
     * @param id
     */
    void deleteStatusBit(String id);

    /**
     * 删除规则
     * @param id
     */
    void deleteRuleByKey(Integer id);

    /**
     * 更新内置规则
     * @param id
     * @param ruleMap
     */
    void updateInternalRule(Integer id, Map<String, String> ruleMap);

    /**
     * 存储客户端id
     * @param key
     * @param client
     */
    void setClientId(String key, String client);

    /**
     * 查询
     * @param key
     * @return
     */
    String getClientId(String key);

    /**
     * 删除客户端id
     * @param key
     */
    void deleteClientId(String key);

    /**
     * 根据imei批量删除redis键
     * @param imei
     */
    void deleteClientIdByImei(String imei);


    /**
     * 根据imei模糊匹配搜索键值
     * @param imei
     * @return
     */
    Set<String> getClientIdKeys(String imei);

    /**
     * 根据IMEI删除cellId和imei的映射关系
     * @param imei
     */
    void deleteCellIdAndImeiByImei(String imei);

    /**
     * 根据imei模糊匹配搜索远程配置键值
     * @param imei
     * @return
     */
    Set<String> getClientKeys(String imei);

    /**
     * 更新保存远程配置上报时间间隔设置
     * @param imei
     */
    void updateReportTimeShow(String imei, String reportTime);

    /**
     * 设置具体设备的上报时间间隔
     * @param imei
     * @param value
     */
    void setMoudleConfig(String imei, int value);

    /**
     * 获取远程诊断配置时间
     * @param imei
     * @return
     */
    String getReportTime(String imei);

    /**
     * 远程诊断唯一标志位（时间戳）
     * @param time
     */
    void updateUniqueFlag(String time);

    /**
     * 获取远程诊断唯一标志位（时间戳）
     * @return
     */
    Set<String> getUniqueFlag();

    /**
     * 删除远程诊断历史唯一标识
     * @param oldTime
     */
    void deleteTimeStamp(String oldTime);
}
