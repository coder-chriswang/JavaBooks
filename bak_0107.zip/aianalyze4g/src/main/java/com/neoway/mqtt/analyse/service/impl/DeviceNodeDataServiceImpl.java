package com.neoway.mqtt.analyse.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.github.pagehelper.PageHelper;
import com.neoway.mqtt.analyse.mapper.DeviceNodeDataMapper;
import com.neoway.mqtt.analyse.model.*;
import com.neoway.mqtt.analyse.service.DeviceNodeDataService;
import com.neoway.mqtt.analyse.util.NetInfoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 设备节点信息业务实现
 * @author tuo.yang
 */
@Service
@Slf4j
public class DeviceNodeDataServiceImpl implements DeviceNodeDataService {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private DeviceNodeDataMapper deviceNodeDataMapper;

    @Override
    public List<DeviceNodeInfo> getDeviceNodeInfo() {
        List<DeviceNodeInfo> deviceNodeInfos = deviceNodeDataMapper.findDeviceNodeInfo(null, null, null);
        deviceNodeInfos.forEach(deviceNodeInfo -> {
            if (StringUtils.equals(deviceNodeInfo.getNetMode(), NetMode.LTE.getMode())) {
                String netStatus = NetInfoUtil.getNetStatus(deviceNodeInfo.getLteRsrq(), deviceNodeInfo.getLteSnr());
                deviceNodeInfo.setNetworkStatus(netStatus);
            } else if (StringUtils.equals(deviceNodeInfo.getNetMode(),NetMode.WCDMA.getMode())) {
                String netStatus = NetInfoUtil.getNetStatus(deviceNodeInfo.getWcdRsrp(), deviceNodeInfo.getWcdSnr());
                deviceNodeInfo.setNetworkStatus(netStatus);
            }
        });
        return deviceNodeInfos;
    }

    @Override
    public void updateAlarmStatus(String userId,List<Integer> ids) {
        deviceNodeDataMapper.updateAlarmStatus(ids);
    }

    @Override
    public void manualDispatch(String userId,List<String> imeis) {
        try {
            Map<String,String> entries = redisTemplate.<String, String>boundHashOps("nw:4g:alarmInfos:" + userId).entries();
            String alarmInfo = entries.get("alarmInfo");
            List<AlarmInfo> results = JSON.parseObject(alarmInfo, new TypeReference<List<AlarmInfo>>() {
            });
            List<PatchInfo> patchInfos = new ArrayList<>();
            for (AlarmInfo info : results) {
                if (imeis.contains(info.getImei())) {
                    PatchInfo patchInfo = new PatchInfo();
                    BeanUtil.copyProperties(info,patchInfo);
                    patchInfo.setId(UUID.randomUUID().toString());
                    patchInfo.setDispatchTime(DateUtil.now());
                    patchInfos.add(patchInfo);
                }
            }
            deviceNodeDataMapper.insertAlarmDisPatch(patchInfos);
            redisTemplate.boundHashOps("nw:4g:alarmInfos:" + userId).delete("alarmInfo");
            patchInfos.forEach(patchInfo -> entries.remove(patchInfo.getImei()));
            redisTemplate.boundHashOps("nw:4g:alarmInfos:" + userId).putAll(entries);
        } catch (Exception e) {
            log.error("告警派单发生异常");
        }
    }

    @Override
    public List<AlarmInfo> getHistoryInfo(AlarmInfoSearchCondition alarmInfoSearchCondition) {
        PageHelper.startPage(alarmInfoSearchCondition.getPageNum(), alarmInfoSearchCondition.getPageSize());
        return deviceNodeDataMapper.findHistoryDeviceAlarmInfo(alarmInfoSearchCondition);
    }

    @Override
    public List<AlarmInfo> getAlarmInfo(AlarmInfoSearchCondition alarmInfoSearchCondition) {
        PageHelper.startPage(alarmInfoSearchCondition.getPageNum(), alarmInfoSearchCondition.getPageSize());
        return deviceNodeDataMapper.findDeviceAlarmInfo(alarmInfoSearchCondition);
    }

    @Override
    public AlarmInfo findAlarmInfoById(Integer id) {
        return deviceNodeDataMapper.findAlarmInfoById(id);
    }
}
