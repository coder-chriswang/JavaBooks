package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述:基站与节点关系条件实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/12 9:41
 */
@Data
@ApiModel("拓扑查询条件")
public class TopoSearchCondition implements Serializable {

    private static final long serialVersionUID = 7406049768990564201L;
    @ApiModelProperty("设备imei号")
    private String imei;

    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("基站id")
    private String currentCellId;
}
