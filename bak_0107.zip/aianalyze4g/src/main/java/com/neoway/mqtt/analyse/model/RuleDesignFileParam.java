package com.neoway.mqtt.analyse.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 规则设计文件实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/21 11:23
 */
@Data
@ApiModel("规则设计文件参数")
public class RuleDesignFileParam implements Serializable {
    private static final long serialVersionUID = -3934526285720956541L;
    @ApiModelProperty(value = "id")
    private String id;

    private String pid;

    @ApiModelProperty(value = "父文件夹路径", example = "D:/test")
    private String parentPath;

    @ApiModelProperty(value = "文件名称", example = "告警规则")
    private String fileName;

    @ApiModelProperty(value = "文件后缀", example = ".drl")
    private String fileSuffix;

    @ApiModelProperty(value = "规则文件绝对路径", example = "C:/rule_design_test/告警规则.drl")
    private String path;

    @ApiModelProperty(value = "文件内容")
    private String content;

    @ApiModelProperty(value = "规则描述")
    private String description;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
}
