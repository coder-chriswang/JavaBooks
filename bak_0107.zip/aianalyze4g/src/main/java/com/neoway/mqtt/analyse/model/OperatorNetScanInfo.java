package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：运营商网络质量
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/15 15:10
 */
@Data
@ApiModel("运营商网络质量")
public class OperatorNetScanInfo implements Serializable {
    private static final long serialVersionUID = -2769186216782070932L;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("运营商1")
    private String operator1;

    @ApiModelProperty("运营商1接收信号")
    private double rsrpValue1;

    @ApiModelProperty("运营商1信噪比")
    private double snrValue1;

    @ApiModelProperty("运营商1信号等级")
    private String signalLevel1;

    @ApiModelProperty("运营商2")
    private String operator2;

    @ApiModelProperty("运营商2接收信号")
    private double rsrpValue2;

    @ApiModelProperty("运营商2信噪比")
    private double snrValue2;

    @ApiModelProperty("运营商2信号等级")
    private String signalLevel2;

    @ApiModelProperty("上报时间")
    private Date upTime;
}
