package com.neoway.mqtt.analyse.util;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import com.neoway.mqtt.analyse.mapper.DataAnalyseMapper;
import com.neoway.mqtt.analyse.model.DataPacket;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 功能分析工具
 * @author 20190712158
 */
@Slf4j
@Component
public class FeatureAnalysisUtil {

    /**
     * 周期时长
     */
    private static final long PERIOD = 15 * 60;

    //采样周期（暂定1）单位:D
    private static final int samplingPeriod = 1;
    //采样周期内理想状态下的接收数据量（暂定每个周期为20）
    private static final int idealDataVolume = 6000;
    //采样周期内理想状态下的发送数据量（暂定每个周期为20）
    private static final int idealDataSend = 10000;

    private static DataAnalyseMapper dataAnalyse;

    @Autowired
    private DataAnalyseMapper dataAnalyses;

    @PostConstruct
    public void beforeInit() {
        dataAnalyse = dataAnalyses;
    }

    /**
     * 延时指数
     * @param pgNumbers 包数量
     * @return double
     */
    public static double delayIndex(List<Integer> pgNumbers){

        if (pgNumbers.isEmpty()){
            return -1;
        }

        //周期时间
        List<Double> avgTimeInT = CollectionUtil.newArrayList();
        for (int pgNum : pgNumbers){
            //每个周期每个包传输平均时间
            try {
                double avgTime = BigDecimal.valueOf(PERIOD).divide(BigDecimal.valueOf(pgNum), 4, BigDecimal.ROUND_HALF_UP).doubleValue();
                avgTimeInT.add(avgTime);
            } catch (ArithmeticException e){
                log.error("数据包数量为零", e);
            }
        }
        List<Double> difs = CollectionUtil.newArrayList();
        for (int i = 0; i < avgTimeInT.size() - 1; i++){
            //每个周期之间每个包传输平均数延时差
            double dif = avgTimeInT.get(i) - avgTimeInT.get(i + 1);
            difs.add(Math.abs(dif));
        }
        double sum = difs.stream().mapToDouble(dif -> dif).sum();
        double delayIndex = 0;
        try {
            delayIndex = BigDecimal.valueOf(sum).divide(BigDecimal.valueOf(avgTimeInT.size()), 4, BigDecimal.ROUND_HALF_UP).doubleValue();
        } catch (ArithmeticException e){
            log.error("数据包集合为零", e);
        }
        return delayIndex;
    }

    public static double getDataReceivingRate(int observationTime, List<DataPacket> rxPacketsCounters) {

        //观测时长 （暂定必须为采样周期的倍数）
        //观测时间内第i个周期中接收到的数据量,先行初始化写死
        //List<Integer> dataVolumes = Arrays.asList(20, 15, 16);

        List<Long> dataVolumes = rxPacketsCounters.stream().map(DataPacket::getDataPacketSum).collect(Collectors.toList());

        //观测占比
        int observationRate = (int) Math.ceil(observationTime / samplingPeriod);
        //接收数据量累加和
        int dataVolumeSum = dataVolumes.stream().mapToInt(dataVolume -> Math.toIntExact(dataVolume)).sum();
        //接收率计算结果
        double result = new BigDecimal(dataVolumeSum).divide(new BigDecimal(observationRate),4, BigDecimal.ROUND_HALF_UP).divide(new BigDecimal(idealDataVolume),4, BigDecimal.ROUND_HALF_UP).doubleValue();
        double dataReceivingRate = new BigDecimal(result)
                .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        return dataReceivingRate;
    }

    public static double getDataSendingRate(int observationTime, List<DataPacket> rxPacketsCounters) {
        //观测时长 （暂定必须为采样周期的倍数）
        //观测时间内第i个周期中发送的数据量,先行初始化写死
        // List<Integer> dataSends = Arrays.asList(10, 2, 6);

        List<Long> dataSends = rxPacketsCounters.stream().map(DataPacket::getDataPacketSum).collect(Collectors.toList());

        //观测占比
        int observationRate = (int) Math.ceil(observationTime / samplingPeriod);
        //发送数据量累加和
        int dataSendSum = dataSends.stream().mapToInt(dataVolume -> Math.toIntExact(dataVolume)).sum();
        //发送率计算结果
        double result = new BigDecimal(dataSendSum).divide(new BigDecimal(observationRate), 4, BigDecimal.ROUND_HALF_UP).divide(new BigDecimal(idealDataSend), 4, BigDecimal.ROUND_HALF_UP).doubleValue();
        double dataSendingRate = new BigDecimal(result)
                .setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        return dataSendingRate;
    }

    /**
     * 统计当前数据包
     * @param imei 设备imei
     * @return
     */
    public static List<DataPacket> statisticCurrentDataPacket(String imei) {
        List<DataPacket> dataPackets = null;
        try {
            dataPackets = dataAnalyse.findCurrentDataPacket(DateUtil.today(), imei);
        } catch (Exception e) {
            log.error("统计当前数据包有误");
        }
        return dataPackets;
    }

    /**
     * 统计历史周期数据包（7天为一周期）
     * @param endDate
     * @param imei 设备imei
     * @return
     */
    public static List<DataPacket> statisticHostoryDataPacket(String endDate, String imei){
        Date toDate = DateUtil.parse(DateUtil.parse(endDate).toString("yyyy-MM-dd"));
        Date fromDate = DateUtil.parse(DateUtil.offsetDay(toDate, -7).toString());
        Date endOfNowDate = DateUtil.endOfDay(toDate);
        List<DataPacket> dataPacketList = null;
        try {
            dataPacketList = dataAnalyse.findHistoryDataPacket(fromDate, endOfNowDate, imei);
        } catch (Exception e) {
            log.error("统计历史数据包有误");
        }
        return dataPacketList;
    }
}
