package com.neoway.mqtt.analyse.controller;

import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.model.PerformManageParam;
import com.neoway.mqtt.analyse.service.PerformManageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <pre>
 * 描述：性能管理controller
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 14:43
 */
@RestController
@Slf4j
@RequestMapping("/data/config")
@Api(tags = "4G管道云性能管理" , description = "4G管道云性能管理")
public class PerformManageController {

    @Autowired
    PerformManageService performManageService;

    @ApiOperation("新增配置")
    @PostMapping("/add")
    public HttpResult add(@RequestBody PerformManageParam performManageParam) {
        if (performManageParam == null ) {
            return HttpResult.returnFail("参数实体为空！");
        }
        try {
            performManageService.addPerformConfig(performManageParam);
            return HttpResult.returnSuccess("新增配置成功！", true);
        } catch (Exception e) {
            log.error("新增配置失败！", e);
            return HttpResult.returnFail("新增配置失败！");
        }
    }

    @ApiOperation("更新配置")
    @PostMapping("/update")
    public HttpResult update(@RequestBody PerformManageParam performManageParam) {
        if (performManageParam == null ) {
            return HttpResult.returnFail("参数实体为空！");
        }
        try {
            performManageService.updatePerformConfig(performManageParam);
            return HttpResult.returnSuccess("更新配置成功！", true);
        } catch (Exception e) {
            log.error("更新配置失败！", e);
            return HttpResult.returnFail("更新配置失败！");
        }
    }

    @ApiOperation("查询配置")
    @PostMapping("/find")
    public HttpResult find() {
        try {
            return HttpResult.returnSuccess(performManageService.findOne());
        } catch (Exception e) {
            log.error("查询配置失败！", e);
            return HttpResult.returnFail("查询配置失败！");
        }
    }

    @ApiOperation("删除配置")
    @PostMapping("/delete")
    public HttpResult delete() {
        try {
            performManageService.deletePerformConfig();
            return HttpResult.returnSuccess("删除配置成功!", true);
        } catch (Exception e) {
            log.error("删除配置失败！", e);
            return HttpResult.returnFail("删除配置失败！");
        }
    }


    @ApiOperation("查询性能观测周期数")
    @GetMapping("/findObservationTime")
    public HttpResult findObservationTime() {
        try {
            return HttpResult.returnSuccess(performManageService.findObservationTime());
        } catch (Exception e) {
            log.error("查询性能观测周期数失败！", e);
            return HttpResult.returnFail("查询性能观测周期数失败！");
        }
    }


    @ApiOperation("更新配置性能观测周期数")
    @GetMapping("/updateObservationTime")
    public HttpResult updateObservationTime(@RequestParam("observationTime") Integer observationTime) {
        if (observationTime == null ) {
            return HttpResult.returnFail("参数实体为空！");
        }
        try {
            performManageService.updateObservationTime(observationTime);
            return HttpResult.returnSuccess("更新观测性能周期成功！", true);
        } catch (Exception e) {
            log.error("更新观测性能周期失败！", e);
            return HttpResult.returnFail("更新观测性能周期失败！");
        }
    }


}
