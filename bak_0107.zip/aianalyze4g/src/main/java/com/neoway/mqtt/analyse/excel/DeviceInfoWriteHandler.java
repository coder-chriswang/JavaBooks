package com.neoway.mqtt.analyse.excel;

import com.alibaba.excel.write.handler.SheetWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder;
import com.neoway.mqtt.analyse.util.OperatorEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFDataValidation;

import java.util.HashMap;
import java.util.Map;

/**
 * <pre>
 *  描述: 给表格列取下拉选择
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/16 14:46
 */
@Slf4j
public class DeviceInfoWriteHandler implements SheetWriteHandler {
    @Override
    public void beforeSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {

    }

    @Override
    public void afterSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {
        try {
            Map<Integer, String[]> operatorMap = new HashMap<>(1);
            String[] operator = {OperatorEnum.CMCC.getOperator(), OperatorEnum.CUCC.getOperator(), OperatorEnum.CTCC.getOperator()};
            operatorMap.put(1, operator);
            Sheet sheet = writeSheetHolder.getSheet();
            DataValidationHelper helper = sheet.getDataValidationHelper();
            for (Map.Entry<Integer, String[]> entry : operatorMap.entrySet()) {
                // 起始行、终止行、起始列、终止列  起始行为1即表示表头不设置
                CellRangeAddressList addressList = new CellRangeAddressList(1, 65535, entry.getKey(), entry.getKey());
                DataValidationConstraint constraint = helper.createExplicitListConstraint(entry.getValue());
                DataValidation dataValidation = helper.createValidation(constraint, addressList);
                // 处理Excel兼容性问题
                if (dataValidation instanceof XSSFDataValidation) {
                    dataValidation.setSuppressDropDownArrow(true);
                    dataValidation.setShowErrorBox(true);
                } else {
                    dataValidation.setSuppressDropDownArrow(false);
                }
                dataValidation.setEmptyCellAllowed(true);
                dataValidation.setShowErrorBox(true);
                dataValidation.createErrorBox("提示","请在下拉框中选择正确的运营商信息");
                sheet.addValidationData(dataValidation);
            }
        } catch (Exception e) {
            log.error("下拉框设置异常");
        }
    }
}
