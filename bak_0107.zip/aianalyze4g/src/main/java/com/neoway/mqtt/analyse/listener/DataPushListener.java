package com.neoway.mqtt.analyse.listener;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.neoway.mqtt.analyse.config.websocket.WebSocketServer;
import com.neoway.mqtt.analyse.model.DiagnoseRespModel;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.util.NetInfoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * 描述：推送数据
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/8/4 10:12
 */
@Component
@Slf4j
public class DataPushListener {

    @Autowired
    WebSocketServer webSocketServer;

    @Autowired
    EmqRedisDao emqRedisDao;

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "4G_moduleSend_resp_MQTT", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "4G_moduleSend_resp", type = "direct", durable = "true"),
                    key = "MQTT") })
    public void diagnoseSendResp(String message) {
        Map<String, String> basicDataMap = JSON.parseObject(message, new TypeReference<Map<String, String>>(){});
        String body = basicDataMap.get("body");
        String imei = basicDataMap.get("imei");
        String authCode = basicDataMap.get("authCode");
        log.info("authCode= {}",authCode);
        Set<String> uniqueFlag = emqRedisDao.getUniqueFlag();
        long endTime = System.currentTimeMillis();
        if (authCode.contains("/")){
            String time = authCode.split("/")[1];
            if (uniqueFlag.contains(time)) {
                long startTime = Long.parseLong(time);
                log.info("下发和响应时间间隔={}秒",(endTime - startTime) / 1000);
                if ((endTime - startTime) / 1000 > 30) {
                    log.info("抛掉的消息={}",authCode);
                    return;
                }
            } else {
                return;
            }
        }
        for (String timeStamp : uniqueFlag){
            long oldTime = Long.parseLong(timeStamp);
            if ((endTime - oldTime) / 1000 > 60){
                emqRedisDao.deleteTimeStamp(timeStamp);
            }
        }
        log.info("监听到模组诊断应答队列消息");
        List<String> tsList = CollectionUtil.newArrayList() ;
        try {
            if (StringUtils.isNotBlank(body)) {
                DiagnoseRespModel diagnoseRespModel = JSON.parseObject(body, new TypeReference<DiagnoseRespModel>(){});
                StringBuffer resultMessage = new StringBuffer();
                if (diagnoseRespModel.getModuleInfo() != null) {
                    String moduleInfoMessage;
                    if ("OK".equals(diagnoseRespModel.getModuleInfo().getStatus())){
                        moduleInfoMessage = String.format("模块厂商信息获取成功,详细信息为：\nmanufactureInfo：%s \nmodeType：%s \nversion：%s", diagnoseRespModel.getModuleInfo().getManufacturerInfo(),diagnoseRespModel.getModuleInfo().getModeType(),diagnoseRespModel.getModuleInfo().getVersion());
                    } else {
                        moduleInfoMessage = "模块厂商信息获取失败";
                    }
                    resultMessage.append(moduleInfoMessage);
                    resultMessage.append("\n");
                }
                if (diagnoseRespModel.getCreg() != null) {
                    String cregMessage;
                    if ("OK".equals(diagnoseRespModel.getCreg().getStatus())){
                        cregMessage = String.format("网络注册状态获取成功,详细信息为：\nnetMode：%s \nregisterStatus：%s", diagnoseRespModel.getCreg().getNetMode(),diagnoseRespModel.getCreg().getRegisterStatus());
                    } else {
                        cregMessage = "网络注册状态获取失败";
                    }
                    resultMessage.append(cregMessage);
                    resultMessage.append("\n");
                }
                if (diagnoseRespModel.getCsq() != null) {
                    String csqMessage;
                    if ("OK".equals(diagnoseRespModel.getCsq().getStatus())){
                        if (diagnoseRespModel.getCsq().getRsrp() != null && diagnoseRespModel.getCsq().getSinr() != null) {
                            String netStatus = NetInfoUtil.getNetStatus(diagnoseRespModel.getCsq().getRsrp(),diagnoseRespModel.getCsq().getSinr());
                            csqMessage = String.format("网络信号等级获取成功,详细信息为：\nsignalLevel：%s", netStatus);
                        } else {
                            csqMessage = "网络信号等级获取失败";
                        }
                    } else {
                        csqMessage = "网络信号等级获取失败";
                    }
                    resultMessage.append(csqMessage);
                }
                Set<String> keySet = emqRedisDao.getClientIdKeys(imei);
                if (CollectionUtil.isEmpty(keySet)){
                    log.error("无法匹配到客户端，推送数据失败");
                    return;
                }
                for (String key : keySet) {
                    String tsKey = key.substring(key.indexOf("#") + 1);
                    tsList.add(tsKey);
                }
                String ts = Collections.min(tsList);
                String clientKey = imei + "#" + ts;
                String clientId = emqRedisDao.getClientId(clientKey);
                WebSocketServer.sendInfo(clientId,resultMessage.toString());
                log.info("推送数据成功==》");
                emqRedisDao.deleteClientId(clientKey);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("推送数据发生异常");
        }
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "4G_moduleConfigSend_resp_MQTT", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "4G_moduleConfigSend_resp", type = "direct", durable = "true"),
                    key = "MQTT") })
    public void moduleConfigSendResp(String message) {
        Map<String, String> basicDataMap = JSON.parseObject(message, new TypeReference<Map<String, String>>(){});
        String body = basicDataMap.get("body");
        String imei = basicDataMap.get("imei");
        log.info("监听到模组配置应答队列消息");
        List<String> tsList = CollectionUtil.newArrayList() ;
        try {
            if (StringUtils.isNotBlank(body)) {
                Map<String,String> moduleConfigRespMap = JSON.parseObject(body, new TypeReference<Map<String,String>>(){});
                String result = moduleConfigRespMap.get("result");
                String configRespInfo;
                if ("OK".equalsIgnoreCase(result)){
                    configRespInfo =  String.format("模块上报时间周期配置成功,状态为：\nresult：%s", result);
                } else {
                    configRespInfo = "模块上报时间周期配置失败";
                }
                Set<String> keySet = emqRedisDao.getClientKeys(imei);
                if (CollectionUtil.isEmpty(keySet)){
                    log.error("无法匹配到客户端，推送数据失败");
                    return;
                }
                for (String key : keySet) {
                    String tsKey = key.substring(key.indexOf("$") + 1);
                    tsList.add(tsKey);
                }
                String ts = Collections.min(tsList);
                String clientKey = imei + "$" + ts;
                String clientId = emqRedisDao.getClientId(clientKey);
                WebSocketServer.sendInfo(clientId,configRespInfo);
                log.info("推送数据成功==》");
                emqRedisDao.deleteClientId(clientKey);
                //从redis中获取远程设置上报时间间隔
                String reportTime = emqRedisDao.getClientId(imei);
                emqRedisDao.updateReportTimeShow(imei, reportTime);

            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("推送数据发生异常");
        }
    }




}
