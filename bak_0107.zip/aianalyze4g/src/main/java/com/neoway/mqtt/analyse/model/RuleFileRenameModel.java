package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 规则文件重命名实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/8/10 10:05
 */
@Data
@ApiModel("文件重命名")
public class RuleFileRenameModel implements Serializable {
    private static final long serialVersionUID = -6123183831246684424L;

    @ApiModelProperty("规则id")
    private String id;

    @ApiModelProperty("文件绝对路径")
    private String filePath;

    @ApiModelProperty("文件新名称")
    private String newName;
}
