package com.neoway.mqtt.analyse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * <pre>
 *  描述: 启动类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/3/31 20:38
 */
@SpringBootApplication
@ComponentScan(value = {"com.neoway"})
public class MqttAnalyseApplication {
    public static void main(String[] args) {
        SpringApplication.run(MqttAnalyseApplication.class, args);
    }
}
