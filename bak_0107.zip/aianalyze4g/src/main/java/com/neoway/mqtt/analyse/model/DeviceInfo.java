package com.neoway.mqtt.analyse.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：设备信息实体
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/17 11:09
 */
@ApiModel("设备信息model")
@Data
public class DeviceInfo implements Serializable {
    private static final long serialVersionUID = 2555386425180452646L;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("鉴权码")
    private String authCode;

    @ApiModelProperty("当前运营商")
    private String operator;

    @ApiModelProperty("小区名称")
    private String cellName;

    @ApiModelProperty("小区位置,经纬度")
    private String cellLocations;

    @ApiModelProperty("小区地址")
    private String cellAddress;

    @ApiModelProperty("设备是否在线")
    private int online;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间")
    private Date createTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("更新时间")
    private Date updateTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("上报时间")
    private Date upTime;
}
