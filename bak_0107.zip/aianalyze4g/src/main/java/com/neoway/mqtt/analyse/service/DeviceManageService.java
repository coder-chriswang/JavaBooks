package com.neoway.mqtt.analyse.service;

import com.neoway.mqtt.analyse.model.DeviceInfo;
import com.neoway.mqtt.analyse.model.DeviceManageParam;
import com.neoway.mqtt.analyse.model.DeviceSearchCondition;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <pre>
 * 描述：性能管理service层
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/6 17:33
 */
public interface DeviceManageService {

    /**
     * 查询设备详情
     * @param imei
     * @return
     */
    DeviceInfo findDetailInfo(String imei);

    /**
     *  更新设备信息
     *  @param deviceManageParam
     */
    void updateDeviceInfo(DeviceManageParam deviceManageParam);

    /**
     * 删除设备信息
     * @param imei
     * @return
     */
    int deleteDeviceInfo(String imei);

    /**
     * 导入设备信息数据
     * @param file
     * @return
     */
    List<String> uploadDeviceInfoData(MultipartFile file);

    /**
     * 查询设备信息列表
     * @param searchCondition
     * @return
     */
    List<DeviceInfo> findDeviceInfo(DeviceSearchCondition searchCondition);

    /**
     * 导出设备信息列表
     *
     * @param searchCondition
     * @param response
     */
    void exportDeviceInfoList(DeviceSearchCondition searchCondition, HttpServletResponse response);

    /**
     * 导出设备信息模板
     * @param response
     */
    void exportDeviceInfoModel(HttpServletResponse response);

    /**
     * 异步excel导入设备信息
     * @param file
     * @return string
     */
    String asyncLoadDeviceInfo(MultipartFile file);

    /**
     * 查询所有在线设备
     * @param imei
     * @return
     */
    List<String> findOnlineDevice(String imei);
}
