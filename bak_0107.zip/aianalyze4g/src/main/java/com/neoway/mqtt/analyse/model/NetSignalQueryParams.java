package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/16 15:36
 */
@Data
@ApiModel("查询运营商网络信息对比趋势实体")
public class NetSignalQueryParams implements Serializable {

    private static final long serialVersionUID = 2557957188825486351L;
    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("类型，天：1；周：2；月：3")
    private String type;
}
