package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：网络状态
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/8/24 19:28
 */
@Data
public class CSQ implements Serializable {
    private static final long serialVersionUID = 1462983055997504844L;

    /**
     * rsrp
     */
    private Double rsrp;

    /**
     * sinr
     */
    private Double sinr;

    /**
     * 返回状态
     */
    private String status;
}
