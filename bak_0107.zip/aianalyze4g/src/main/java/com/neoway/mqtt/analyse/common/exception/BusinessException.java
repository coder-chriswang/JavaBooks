
package com.neoway.mqtt.analyse.common.exception;


import com.neoway.mqtt.analyse.common.bean.ExceptionType;
import lombok.Getter;
import lombok.Setter;

/**
 * <pre>
 *  描述: 业务异常
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/10 13:46
 */
@Getter
@Setter
public class BusinessException extends RuntimeException {

    private static final long serialVersionUID = -8892445345218552215L;
    private int code;

    private String message;

    private int level;

    public BusinessException(ExceptionType exceptionType) {
        this.code = exceptionType.getCode();
        this.message = exceptionType.getMessage();
        this.level = exceptionType.getLevel();
    }

    public BusinessException(int code, String message, int level) {
        this.code = code;
        this.message = message;
        this.level = level;
    }


    @Override
    public String getMessage() {
        return message;
    }

}
