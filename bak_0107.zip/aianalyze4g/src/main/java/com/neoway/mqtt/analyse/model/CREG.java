package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：网络注册状态
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/8/24 17:26
 */
@Data
public class CREG implements Serializable {
    private static final long serialVersionUID = -1186021839527343457L;

    /**
     * 网络模式
     */
    private String netMode;

    /**
     * 注册状态
     */
    private Integer registerStatus;

    /**
     * 返回状态
     */
    private String status;
}
