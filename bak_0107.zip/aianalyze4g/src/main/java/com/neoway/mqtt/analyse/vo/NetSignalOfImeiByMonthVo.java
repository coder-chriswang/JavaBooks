package com.neoway.mqtt.analyse.vo;

import com.neoway.mqtt.analyse.model.NetSignalOfImeiByMonth;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 * 描述：设备月网络质量Vo
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/17 10:48
 */
@Data
@ApiModel("设备月网络质量Vo")
public class NetSignalOfImeiByMonthVo implements Serializable {
    private static final long serialVersionUID = -7584724233271994052L;

    @ApiModelProperty("移动网络质量")
    private List<NetSignalOfImeiByMonth> cmccList;

    @ApiModelProperty("联通网络质量")
    private List<NetSignalOfImeiByMonth> cuccList;

    @ApiModelProperty("电信网络质量")
    private List<NetSignalOfImeiByMonth> ctccList;
}
