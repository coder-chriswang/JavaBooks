package com.neoway.mqtt.analyse.redis.impl;


import cn.hutool.core.collection.CollectionUtil;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * <pre>
 * 描述：redis
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 19:58
 */
@Component
public class EmqRedisDaoImpl implements EmqRedisDao {
    @Autowired
    private StringRedisTemplate template;

    @Override
    public void updateConfig(Map<String, String> value) {
        template.boundHashOps("nw:equ:config:uniqueConfig").putAll(value);
    }

    @Override
    public Map<String, String> findConfig() {
        Map<String, String> configMap =  template.<String, String>boundHashOps("nw:equ:config:uniqueConfig").entries();
        return configMap;
    }

    @Override
    public void deleteConfig() {
        template.delete("nw:equ:config:uniqueConfig");
    }

    @Override
    public Map<String, String> findObservationTimeConfig() {
        Map<String, String> ObservationConfigMap =  template.<String, String>boundHashOps("nw:equ:config:uniqueObservationTimeConfig").entries();
        return ObservationConfigMap;
    }

    @Override
    public void deleteObservationTime() {
        template.delete("nw:equ:config:uniqueObservationTimeConfig");
    }

    @Override
    public void updateObservationTime(Map<String, String> value) {
        template.boundHashOps("nw:equ:config:uniqueObservationTimeConfig").putAll(value);
    }

    @Override
    public Map<String, String> findCellIdInfo() {
        Map<String, String> cellIdMap = template.<String, String>boundHashOps("nw:equ:excel:cellIdInfo").entries();
        return cellIdMap;
    }

    @Override
    public void updateCellIdInfo(Map<String, String> value) {
        template.boundHashOps("nw:equ:excel:cellIdInfo").putAll(value);
    }

    @Override
    public void updateImei(String[] imei) {
        template.boundListOps("nw:equ:excel:imei").leftPushAll(imei);
    }

    @Override
    public List<String> findAllImei() {
        List<String> range = template.boundListOps("nw:equ:excel:imei").range(0, -1);
        return range;
    }

    @Override
    public void updateStatusBit(String id, Map<String, String> statusBit) {
        template.boundHashOps("nw:equ:excel:statusBit:"+ id).putAll(statusBit);
    }

    @Override
    public void deleteStatusBit(String id){
        template.delete("nw:equ:excel:statusBit:"+ id);
    }

    @Override
    public void setClientId(String key,String client) {
        template.boundValueOps("nw:equ:client:" + key).set(client);
        template.boundValueOps("nw:equ:client:" + key).expire(30,TimeUnit.SECONDS);
    }

    @Override
    public void updateReportTimeShow(String imei, String reportTime) {
        template.boundValueOps("nw:equ:client:reportTime:" + imei).set(reportTime);
    }

    @Override
    public String getReportTime(String imei) {
        return template.boundValueOps("nw:equ:client:reportTime:" + imei).get();
    }

    @Override
    public void setMoudleConfig(String imei, int value) {
        template.boundValueOps("nw:equ:client:" + imei).set(String.valueOf(value));
    }

    @Override
    public String getClientId(String key) {
        return template.boundValueOps("nw:equ:client:" + key).get();
    }

    @Override
    public void deleteClientId(String key) {
        template.delete("nw:equ:client:" + key);
    }

    @Override
    public void deleteClientIdByImei(String imei) {
        Set<String> keys = template.keys("nw:equ:client:"+ imei + "#" + "*");
        if (CollectionUtil.isNotEmpty(keys)) {
            template.delete(keys);
        }
    }

    @Override
    public Set<String> getClientIdKeys(String imei) {
        return template.keys("nw:equ:client:"+ imei + "#" + "*");
    }

    @Override
    public Set<String> getClientKeys(String imei) {
        return template.keys("nw:equ:client:"+ imei + "$" + "*");
    }

    @Override
    public Map<String, String> findStatusBit(String id) {
        return template.<String,String>boundHashOps("nw:equ:excel:statusBit:"+ id).entries();
    }

    @Override
    public void updateErrorInfo(String id, Map<String, String> map) {
        template.boundHashOps("nw:equ:excel:result:" + id).putAll(map);
        template.boundHashOps("nw:equ:excel:result:"+ id).expire(1, TimeUnit.MINUTES);
    }

    @Override
    public Map<String, String> getExcelErrorInfo(String id) {
        return template.<String, String>boundHashOps("nw:equ:excel:result:" + id).entries();
    }

    @Override
    public void deleteRedisImei(String imei) {
        template.boundListOps("nw:equ:excel:imei").remove(1,imei);
    }

    @Override
    public void deleteRuleByKey(Integer id) {
        template.delete("nw:4g:internalRule:" + id);
    }

    @Override
    public void updateInternalRule(Integer id, Map<String, String> ruleMap) {
        template.boundHashOps("nw:4g:internalRule:" + id).putAll(ruleMap);
    }

    private Set<String> findCellIdAndImeiKey(){
        return template.keys("nw:equ:cellIdAndImei:*");
    }

    @Override
    public void deleteCellIdAndImeiByImei(String imei) {
        Set<String> keys = this.findCellIdAndImeiKey();
        keys.forEach(key -> {
            if (template.boundSetOps(key).isMember(imei)){
                template.boundSetOps(key).remove(imei);
            }
        });

    }

    @Override
    public void updateUniqueFlag(String timeStamp) {
        template.boundSetOps("nw:4g:remoteDiagnosis:timeStamp").add(timeStamp);
    }

    @Override
    public Set<String> getUniqueFlag() {
        return template.boundSetOps("nw:4g:remoteDiagnosis:timeStamp").members();
    }

    @Override
    public void deleteTimeStamp(String oldTime) {
        template.boundSetOps("nw:4g:remoteDiagnosis:timeStamp").remove(oldTime);
    }
}
