package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 模组上报周期配置参数
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/9/22 16:58
 */
@Data
@ApiModel("模组上报周期配置参数")
public class ModuleConfigParam implements Serializable {

    private static final long serialVersionUID = 7996206012106540712L;

    @ApiModelProperty("0：远程诊断 1：远程配置")
    private int type;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("上报时间周期")
    private ReportTime reportTime;
}
