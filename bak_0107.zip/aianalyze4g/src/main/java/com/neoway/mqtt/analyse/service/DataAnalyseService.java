package com.neoway.mqtt.analyse.service;

import com.neoway.mqtt.analyse.model.*;
import com.neoway.mqtt.analyse.vo.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <pre>
 * 描述：4G管道云数据展现service层接口
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 13:46
 */
public interface DataAnalyseService {

    /**
     * 查询整体数据
     * @param searchCondition
     * @return 实体
     */
    PipeCloudDataVo findInfo(SearchCondition searchCondition);

    /**
     * 查询设备数据
     * @param searchCondition
     * @return
     */
    List<PipeCloudDataOfCellVo> findAllPipeCloudDataOfCell(SearchCondition searchCondition);

    /**
     * 查询设备数据
     * @param searchCondition
     * @return
     */
    List<PipeCloudDataOfCellVo> findV2AllPipeCloudDataOfCell(SearchCondition searchCondition);

    /**
     * 查询运营商网络信号对比
     *
     * @param address
     * @return
     */
    NetSignalOfDayVo findNetSignalOfDay(String address);

    /**
     * 查询多天内运营商网络信号对比
     *
     * @param address
     * @param dayNum
     * @return
     */
    NetSignalOfDayVo findNetSignalOfDays(String address, int dayNum);

    /**
     * 导出设备信息
     *
     * @param searchCondition
     * @param response
     */
    void exportDeviceInfo(SearchCondition searchCondition, HttpServletResponse response);

    /**
     * 根据imei查询最近一条上报数据
     *
     * @param imei
     * @return
     */
    NetReportInfoOfImei findDeviceInfoOfCellByImei(String imei);

    /**
     * 查询过去一个月内的单个设备的网络质量
     *
     * @param imei
     * @return
     */
    NetSignalOfImeiByMonthVo findNetInfoByImei(String imei);

    /**
     *查询设备节点信息
     * @param topoSearchCondition
     * @return
     */
    List<DeviceNodeInfo> getDeviceNodeInfo(TopoSearchCondition topoSearchCondition);

    /**
     *查询基站与节点的topo关系
     * @param topoSearchCondition
     * @return
     */
    CellIdDeviceVo findCellIdDeviceMap(TopoSearchCondition topoSearchCondition);

    /**
     *查询基站与节点的topo关系
     * @param topoSearchCondition
     * @return
     */
    CellIdDeviceVo findCellIdDeviceMapV2(TopoSearchCondition topoSearchCondition);

    /**
     *查询基站与节点的topo关系
     * @param topoSearchCondition
     * @return
     */
    List<CellIdAndDeviceModel> findCellIdDeviceMapV3(TopoSearchCondition topoSearchCondition);

    /**
     * 存储性能指标数据
     * @param imei
     */
    boolean insertCapabilityIndexData(String imei);

    /**
     * 查询性能指标数据
     * @param capabilityIndex
     * @return
     */
    List<CapabilityIndexVo> findCapabilityIndexData(CapabilityIndexSearchCondition capabilityIndex);


    /**
     * 通过Imei号和观测时长查询设备延时指数
     * @param imei
     * @param observationTime
     * @return
     */
    double findDelayIndex(String imei, int observationTime);

    /**
     * 通过Imei号和观测时长查询设备数据接收率r
     * @param imei
     * @param observationTime
     * @return
     */
    double findDataReceivingRate(String imei, int observationTime);

    /**
     * 通过Imei号和观测时长查询设备数据发送率s
     * @param imei
     * @param observationTime
     * @return
     */
    double findDataSendingRate(String imei, int observationTime);

    /**
     * 插入topo图片配置
     * @param picConfigModel
     * @return
     */
    int insertPicConfig(PicConfigModel picConfigModel);

    /**
     * 更新topo图片配置
     * @param picConfigModel
     * @return
     */
    int updatePicConfig(PicConfigModel picConfigModel);

    /**
     * 通过userId获取topo配置
     * @return
     */
    PicConfigModel findPicConfig();

    /**
     * 统计sim卡信息
     * @return
     */
    SimCardStatistic statisticSimCardInfo();

    /**
     * 查询topo整体数据统计
     * @return
     */
    DeviceTopoVo findAllDeviceData();

    /**
     * 查询当天运行商网络信号对比
     * @return
     */
    NetSignalOfDayVo findNetSignalOfToDay();

    /**
     * 查询所有ApiDoc
     * @return
     */
    List<ApiDocVo> findAllApiDoc();

    /**
     * 根据id查询piDoc
     * @return
     */
    ApiDocVo findApiDocById(int id);


    /**
     * 查询当前告警信息概览
     * @return
     */
    AlarmOverviewVo findCurrentAlarmInfo();

    /**
     * 查询历史告警信息概览
     * @param dayNum
     * @return
     */
    AlarmOverviewVo findHistoryAlarmInfoOfDays(int dayNum);

    /**
     * 查询所有基站以及其下的设备数量
     * @param topoSearchCondition
     * @return
     */
    List<CellIdAndDeviceModel> findAllCellIdAndDeviceCount(TopoSearchCondition topoSearchCondition);

    /**
     * 导出性能信息列表
     * @param searchCondition
     * @param response
     */
    void exportCapabilityInfoList(CapabilityIndexSearchCondition searchCondition, HttpServletResponse response);
}
