package com.neoway.mqtt.analyse.vo;

import com.github.pagehelper.PageInfo;
import com.neoway.mqtt.analyse.model.CollectDataModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 * 描述：展示数据vo
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 14:00
 */
@Data
@ApiModel(value = "展示层数据")
public class PipeCloudDataVo implements Serializable {
    private static final long serialVersionUID = 2854580427192838986L;

    @ApiModelProperty("设备总数")
    private String deviceCount;

    @ApiModelProperty("在线总数")
    private String onlineNum;

    @ApiModelProperty("在线率")
    private String rate;

    @ApiModelProperty("网络质量优秀设备数量")
    private int goodQualityOfNetNum;

    @ApiModelProperty("网络质量中等设备数量")
    private int midQualityOfNetNum;

    @ApiModelProperty("网络质量差设备数量")
    private int badQualityOfNetNum;

    @ApiModelProperty("未知网络质量设备数量")
    private int unknownNetNum;

    @ApiModelProperty("设备信息列表")
    private PageInfo<PipeCloudDataOfCellVo> pipeCloudDataList;

    @ApiModelProperty("告警信息列表")
    private List<AlarmInfoVo> alarmInfoList;

    @ApiModelProperty("采集成功率统计信息")
    private CollectDataModel collectDataModel;
}
