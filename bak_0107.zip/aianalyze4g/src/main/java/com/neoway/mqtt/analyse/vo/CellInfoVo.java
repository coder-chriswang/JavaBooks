package com.neoway.mqtt.analyse.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述:基站信息
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/11 11:39
 */
@Data
public class CellInfoVo implements Serializable {
    private static final long serialVersionUID = -8453280136488989615L;
    private String currentCellId = "UNKNOWN";
    private String netMode = "UNKNOWN";
    private String operator = "UNKNOWN";
    private Double sinrValue;
    private Double rsrpValue;
    private String status = "UNKNOWN";
}
