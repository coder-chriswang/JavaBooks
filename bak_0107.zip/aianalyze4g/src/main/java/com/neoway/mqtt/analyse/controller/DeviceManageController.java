package com.neoway.mqtt.analyse.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.github.pagehelper.PageInfo;
import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.model.DeviceInfo;
import com.neoway.mqtt.analyse.model.DeviceManageParam;
import com.neoway.mqtt.analyse.model.DeviceSearchCondition;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.service.DeviceManageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：设备管理controller层
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/07/06 17:03
 */
@RestController
@Slf4j
@RequestMapping("/data/device")
@Api(tags = "4G管道云设备管理" , description = "4G管道云设备管理")
public class DeviceManageController {

    @Autowired
    private DeviceManageService deviceManageService;

    @Autowired
    private EmqRedisDao emqRedisDao;

    @ApiOperation("通过imei号查询设备详情")
    @GetMapping("/findDetailInfoByImei/{imei}")
    public HttpResult<DeviceInfo> findDetailInfo(@PathVariable("imei") String imei){
        if (StringUtils.isEmpty(imei)){
            return HttpResult.returnFail("imei参数为空！");
        }
        try {
            return HttpResult.returnSuccess(deviceManageService.findDetailInfo(imei));
        } catch (Exception e) {
            return HttpResult.returnFail("设备详情查询失败！");
        }
    }

    @ApiOperation("更新单个设备信息")
    @PostMapping("/updateDeviceInfo")
    public HttpResult updateDeviceInfo(@RequestBody DeviceManageParam deviceManageParam){
        if (deviceManageParam == null || StringUtils.isEmpty(deviceManageParam.getImei())
                || StringUtils.isEmpty(deviceManageParam.getCellAddress())
                || StringUtils.isEmpty(deviceManageParam.getCellName())){
            return HttpResult.returnFail("参数传递错误，请检查传参！",false);
        }
        try {
            deviceManageService.updateDeviceInfo(deviceManageParam);
            return HttpResult.returnSuccess("更新设备信息成功！",true);
        } catch (Exception e){
            log.error("更新设备信息失败！", e);
            return HttpResult.returnFail("更新设备信息失败！");
        }
    }

    @ApiOperation("通过imei号删除设备信息")
    @GetMapping("/deleteDeviceInfo/{imei}")
    public HttpResult deleteDeviceInfo(@PathVariable("imei") String imei){
        if (StringUtils.isEmpty(imei)){
            return HttpResult.returnFail("imei参数为空，请传参！",false);
        }
        try {
            int result = deviceManageService.deleteDeviceInfo(imei);
            if (result > 0){
                return HttpResult.returnSuccess("删除设备信息成功！",true);
            } else {
                return HttpResult.returnFail("当前设备在线，不能删除！",false);
            }
        } catch (Exception e){
            return HttpResult.returnFail("删除设备信息失败!",false);
        }
    }

    @ApiOperation("查询设备信息列表")
    @PostMapping("/findDeviceInfoList")
    public HttpResult<PageInfo<DeviceInfo>> findDeviceInfoList(@RequestBody DeviceSearchCondition searchCondition){
        try {
            List<DeviceInfo> deviceInfoList = deviceManageService.findDeviceInfo(searchCondition);
            return HttpResult.returnSuccess(new PageInfo<>(deviceInfoList));
        } catch (Exception e) {
            return HttpResult.returnFail("设备信息列表查询失败");
        }
    }

    @ApiOperation("导出设备信息列表")
    @PostMapping("/exportDeviceInfoList")
    public void exportDeviceInfoList(@RequestBody DeviceSearchCondition searchCondition, HttpServletResponse response) {
        deviceManageService.exportDeviceInfoList(searchCondition, response);
    }

    @ApiOperation("导出设备信息模板")
    @PostMapping("/exportDeviceInfoModel")
    public void exportDeviceInfoModel(HttpServletResponse response) {
        deviceManageService.exportDeviceInfoModel(response);
    }

    @ApiOperation("导入设备信息数据")
    @PostMapping("/uploadDeviceInfo")
    public HttpResult uploadDeviceInfo(MultipartFile file) {
        if (!file.isEmpty()){
            if (file.getOriginalFilename().endsWith(".xlsx")){
                try {
                    List<String> errorInfo = deviceManageService.uploadDeviceInfoData(file);
                    if (CollectionUtils.isEmpty(errorInfo)){

                        return HttpResult.returnSuccess("导入设备信息数据成功！", true);
                    } else {
                        return HttpResult.returnFail("导入失败的设备信息：",errorInfo);
                    }
                }  catch (MultipartException e) {
                    log.error("导入设备信息数据失败！", e);
                    return HttpResult.returnFail("文件大小不能超过20M！");
                } catch (Exception e) {
                    log.error("导入设备信息数据失败！", e);
                    return HttpResult.returnFail("导入设备信息数据失败！");
                }
            } else {
                return HttpResult.returnFail("文件格式不对！请传xlsx格式文件！",false);
            }
        }else {
            return HttpResult.returnFail("请选择文件！",false);
        }
    }

    @ApiOperation("异步上传设备信息")
    @PostMapping("/asyncUploadDeviceInfo")
    public HttpResult asyncLoadDeviceInfo(MultipartFile file){
        try {
            if (!file.isEmpty()) {
                if (file.getOriginalFilename().endsWith(".xlsx")){
                    return HttpResult.returnSuccess(deviceManageService.asyncLoadDeviceInfo(file));
                } else {
                    return HttpResult.returnFail("文件格式不对！请传xlsx格式文件！",false);
                }
            } else {
                return HttpResult.returnFail("请选择文件！",false);
            }
        } catch (Exception e){
            return HttpResult.returnFail("上传设备信息文件失败！",false);
        }
    }

    @ApiOperation("异步获取标志位")
    @GetMapping("/statusBit/{id}")
    public HttpResult getStatusBit(@PathVariable("id") String id){
        try {
            Map<String, String> statusBit = emqRedisDao.findStatusBit(id);
            return HttpResult.returnSuccess(statusBit.get("statusBit"));
        }catch (Exception e){
            return HttpResult.returnFail("获取标志位失败！",false);
        }
    }

    @ApiOperation("异步获取excel导入结果")
    @GetMapping("/excelResult/{id}")
    public HttpResult getResult(@PathVariable("id") String id){
        try {
            Map<String, String> excelErrorInfo = emqRedisDao.getExcelErrorInfo(id);
            String errorInfo = excelErrorInfo.get("errorInfo");
            List<String> errorInfoResult = JSON.parseObject(errorInfo, new TypeReference<List<String>>() {});
            emqRedisDao.deleteStatusBit(id);
            if (CollectionUtils.isEmpty(errorInfoResult)){
                return HttpResult.returnSuccess("导入设备信息数据成功！", true);
            } else {
                return HttpResult.returnFail("导入失败的设备信息：",errorInfoResult);
            }
        } catch (Exception e){
            return HttpResult.returnFail("导入设备信息失败！",false);
        }
    }

    @ApiOperation("查询所有在线设备，支持模糊查询")
    @PostMapping("/findOnlineDevice")
    public HttpResult findOnlineDevice(@RequestBody DeviceManageParam deviceManageParam){
        try {
           return HttpResult.returnSuccess(deviceManageService.findOnlineDevice(deviceManageParam.getImei()));
        } catch (Exception e){
            log.error("查询在线设备信息失败", e);
            return HttpResult.returnFail("查询在线设备信息失败!",false);
        }
    }

    @ApiOperation("回显远程诊断上报时间周期")
    @GetMapping("/reportTimeShow/{imei}")
    public HttpResult reportTimeShow(@PathVariable("imei") String imei){
        if (StringUtils.isEmpty(imei)){
            return HttpResult.returnFail("imei参数为空，请传参！",false);
        }
        try {
            String rt = emqRedisDao.getReportTime(imei);
            log.info("rt={}",rt);
            if (rt == null){
                return HttpResult.returnSuccess(null);
            } else {
                return HttpResult.returnSuccess(Integer.parseInt(rt));
            }
        } catch (Exception e){
            return HttpResult.returnFail("回显远程诊断上报时间周期失败!",false);
        }
    }


}
