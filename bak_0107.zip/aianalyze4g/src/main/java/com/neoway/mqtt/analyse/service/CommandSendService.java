package com.neoway.mqtt.analyse.service;

import com.neoway.mqtt.analyse.model.ModuleConfigParam;
import com.neoway.mqtt.analyse.model.ModuleDiagnoseParam;

/**
 * <pre>
 * 描述：命令下发service
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/20 10:59
 */
public interface CommandSendService {

    /**
     * 下发模组诊断命令
     * @return
     */
    void moduleDiagnoseSend(ModuleDiagnoseParam moduleDiagnoseParam);

    /**
     * 下发模组配置命令
     * @param moduleConfigParam
     */
    void moduleConfigSend(ModuleConfigParam moduleConfigParam);

}
