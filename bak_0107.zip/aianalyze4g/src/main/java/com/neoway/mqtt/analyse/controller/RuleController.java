package com.neoway.mqtt.analyse.controller;


import cn.hutool.core.collection.CollectionUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.bean.AlarmInfo;
import com.neoway.mqtt.analyse.bean.base.BaseModel;
import com.neoway.mqtt.analyse.mapper.RuleMapper;
import com.neoway.mqtt.analyse.model.*;
import com.neoway.mqtt.analyse.service.RuleService;
import com.neoway.mqtt.analyse.util.RuleExecuteUtil;
import com.neoway.mqtt.analyse.vo.InternalRuleVo;
import com.neoway.mqtt.analyse.vo.RuleDesignProjectVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 动态规则Controller
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/11 14:05
 */
@Api(tags = "4G管道云规则引擎" , description = "4G管道云规则引擎")
@RequestMapping(value = "/rules")
@RestController
public class RuleController {

    @Autowired
    private RuleMapper ruleMapper;

    @Autowired
    private RuleService ruleService;
    

    @ApiOperation(value = "验证规则是否合法",notes = verify)
    @PostMapping("/verify")
    public HttpResult<BaseModel> ruleVerify(@RequestBody VerifyRuleParams verifyRuleParams) {
        if (verifyRuleParams == null || StringUtils.isEmpty(verifyRuleParams.getJson()) || StringUtils.isEmpty(verifyRuleParams.getRuleName())) {
            return HttpResult.returnFail("参数存在问题！");
        }
        Gson gson = new Gson();
        AlarmInfo alarmInfo = gson.fromJson(verifyRuleParams.getJson(), AlarmInfo.class);
        Rule rule = ruleMapper.getByName(verifyRuleParams.getRuleName());
        if (rule == null) {
            return HttpResult.returnFail("无此类型的规则！");
        }
        String ruleContent = rule.getRule();
        List<String> ruleList = new ArrayList<>();
        ruleList.add(ruleContent);
        RuleExecuteUtil.execute(ruleList, alarmInfo);
        return HttpResult.returnSuccess(alarmInfo);
    }

    @ApiOperation(value = "添加规则")
    @PostMapping("/add")
    public HttpResult ruleAdd(@RequestBody RuleParams rule) {
        if (rule == null || StringUtils.isEmpty(rule.getRule()) || StringUtils.isEmpty(rule.getName())){
            return HttpResult.returnFail("添加规则参数有误");
        }
        if (ruleMapper.getByName(rule.getName()) != null) {
            return HttpResult.returnFail("规则名称已经存在，请重新输入");
        }
        try {
            ruleMapper.setRule(rule);
            return HttpResult.returnSuccess("规则添加成功", true);
        } catch (Exception e) {
            return HttpResult.returnFail("规则添加失败");
        }
    }

    @ApiOperation(value = "规则列表")
    @PostMapping("/list")
    public HttpResult<PageInfo<Rule>> getRuleList(@RequestBody RuleParams ruleParams) {
        if (ruleParams == null || ruleParams.getPageNum() == null || ruleParams.getPageSize() == null) {
            return HttpResult.returnFail("查询规则列表参数存在问题，请检查");
        }
        try {
            PageHelper.startPage(ruleParams.getPageNum(), ruleParams.getPageSize());
            return HttpResult.returnSuccess(new PageInfo<>(ruleMapper.getRuleList(ruleParams)));
        } catch (Exception e) {
            return HttpResult.returnFail("规则列表查询失败");
        }
    }

    @ApiOperation(value = "删除规则")
    @GetMapping("/delete/{id}")
    public HttpResult delete(@PathVariable("id") Integer id) {
        if (id == null) {
            return HttpResult.returnFail("没有输入有效的规则编号");
        }
        try {
            ruleMapper.deleteRule(id);
            return HttpResult.returnSuccess("规则删除成功", true);
        } catch (Exception e) {
            return HttpResult.returnFail("规则删除失败");
        }
    }

    @ApiOperation(value = "修改规则")
    @PostMapping("/ruleUpdate")
    public HttpResult ruleUpdate(@RequestBody RuleParams ruleParams) {
        if (ruleParams == null || ruleParams.getId() == null) {
            return HttpResult.returnFail("参数存在问题，请检查");
        }
        try {
            ruleService.updateRule(ruleParams);
            return HttpResult.returnSuccess("规则修改成功", true);
        } catch (Exception e) {
            return HttpResult.returnFail("规则修改失败");
        }
    }

    @ApiOperation(value = "通过id查看规则详情")
    @GetMapping("findRuleInfoById/{id}")
    public HttpResult<Rule> findRuleInfoById(@PathVariable("id") Integer id){
        if (id == null) {
            return HttpResult.returnFail("请传入有效id");
        }
        try {
            return HttpResult.returnSuccess(ruleMapper.getById(id));
        } catch (Exception e) {
            return HttpResult.returnFail("规则详情查询失败");
        }
    }

    @ApiOperation(value = "查询规则设计工程列表")
    @PostMapping("/findAllRuleProject")
    public HttpResult<PageInfo<RuleDesignProjectVo>> findAllRuleProject(@RequestBody RuleDesignProjectParam projectParam) {
        if (projectParam == null || projectParam.getPageNum() == null || projectParam.getPageSize() == null) {
            return HttpResult.returnFail("分页参数有误，请检查");
        }
        try {
            List<RuleDesignProjectVo> allRuleProject = ruleService.findAllRuleProject(projectParam);
            return HttpResult.returnSuccess(new PageInfo<>(allRuleProject));
        } catch (Exception e) {
            return HttpResult.returnFail("查询规则设计工程列表查询失败");
        }
    }

    @ApiOperation(value = "创建规则设计工程")
    @PostMapping("/createRuleDesignProject")
    public HttpResult createRuleDesignProject(@RequestBody RuleDesignProjectParam projectParam) {
        if (projectParam == null || StringUtils.isEmpty(projectParam.getProjectName())) {
            return HttpResult.returnFail("参数存在问题，请检查");
        }
        if (StringUtils.isNotEmpty(ruleMapper.findParentIdByParentName(projectParam.getProjectName().toLowerCase()))) {
            return HttpResult.returnFail("工程已经存在", false);
        }
        try {
            return ruleService.createRuleDesignProject(projectParam);
        } catch (Exception e) {
            return HttpResult.returnFail("创建工程失败");
        }
    }

    @ApiOperation(value = "删除规则设计工程")
    @PostMapping("/deleteRuleDesignProject")
    public HttpResult deleteRuleDesignProject(@RequestBody RuleDesignProjectParam projectParam) {
        if (projectParam == null || StringUtils.isEmpty(projectParam.getId()) || StringUtils.isEmpty(projectParam.getPath())) {
            return HttpResult.returnFail("参数传递有误");
        }
        try {
            return ruleService.deleteRuleDesignProject(projectParam);
        } catch (Exception e) {
            return HttpResult.returnFail("规则设计工程删除失败");
        }
    }

    @ApiOperation(value = "更新规则设计工程状态")
    @PostMapping("/updateRuleDesignProjectStatus")
    public HttpResult updateRuleDesignProjectStatus(@RequestBody RuleDesignProjectParam projectParam) {
        if (projectParam == null || StringUtils.isEmpty(projectParam.getId()) || projectParam.getStatus() == null) {
            return HttpResult.returnFail("参数传递有误");
        }
        try {
            ruleService.updateRuleDesignProjectStatus(projectParam);
            return HttpResult.returnSuccess("工程状态更新成功", true);
        } catch (Exception e) {
            return HttpResult.returnFail("工程状态更新失败");
        }
    }

    @ApiOperation(value = "查询规则设计工程详情")
    @GetMapping("/findRuleDesignProjectDetail/{id}")
    public HttpResult<RuleDesignProjectVo> findRuleDesignProjectDetail(@PathVariable("id") String id) {
        if (StringUtils.isEmpty(id)) {
            return HttpResult.returnFail("传入的id为空");
        }
        try {
            return HttpResult.returnSuccess(ruleService.findRuleDesignProjectDetail(id));
        } catch (Exception e) {
            return HttpResult.returnFail("工程详情查询失败");
        }
    }

    @ApiOperation(value = "存储规则设计文件")
    @PostMapping("/createRuleDesignFile")
    public HttpResult createRuleDesignFile(@RequestBody RuleDesignFileParam fileParam) {
        if (fileParam == null || StringUtils.isEmpty(fileParam.getParentPath()) || StringUtils.isEmpty(fileParam.getFileName()) ) {
            return HttpResult.returnFail("参数有误请检查");
        }
        if ((ruleMapper.findFileByFileName(fileParam.getFileName().toLowerCase(), fileParam.getParentPath())) != null) {
            return HttpResult.returnFail("文件已经存在", false);
        }
        if (fileParam.getFileName().endsWith(".drl")) {
            return HttpResult.returnFail("请创建.drl文件");
        }
        try {
            return ruleService.createRuleDesignFile(fileParam);
        } catch (Exception e) {
            return HttpResult.returnFail("文件创建异常");
        }
    }

    @ApiOperation(value = "获取文件目录及文件")
    @PostMapping("/findProjectAndFile/{projectName}")
    public HttpResult findProjectAndFile(@PathVariable("projectName") String projectName) {
        try {
            Map<String, Object> projectAndFile = ruleService.findProjectAndFile(projectName);
            if (CollectionUtil.isEmpty(projectAndFile)) {
                return HttpResult.returnFail("暂无要查询的文件目录，请创建");
            }
            return HttpResult.returnSuccess(projectAndFile);
        } catch (Exception e) {
            return HttpResult.returnFail("获取文件目录及文件异常");
        }
    }

    @ApiOperation(value = "读取文件内容")
    @PostMapping("/readFileContent")
    public HttpResult readFileContent(@RequestBody RuleDesignFileParam fileParam) {
        if (fileParam == null || StringUtils.isEmpty(fileParam.getPath())) {
            return HttpResult.returnFail("请传人正确的文件路径");
        }
        try {
            return ruleService.readFileContent(fileParam.getPath());
        } catch (Exception e) {
            return HttpResult.returnFail("读取文件内容异常");
        }
    }

    @ApiOperation(value = "写入文件内容")
    @PostMapping("/writeFileContent")
    public HttpResult writeFileContent(@RequestBody RuleDesignFileParam fileParam) {
        if (fileParam == null || StringUtils.isEmpty(fileParam.getPath()) || StringUtils.isEmpty(fileParam.getId())
                || StringUtils.isEmpty(fileParam.getContent())) {
            return HttpResult.returnFail("参数传递有误");
        }
        try {
            return ruleService.writeFileContent(fileParam);
        } catch (Exception e) {
            return HttpResult.returnFail("存储文件内容异常");
        }
    }

    @ApiOperation(value = "查看内置规则内容")
    @GetMapping("/checkInternalRule/{id}")
    public HttpResult<InternalRuleVo> checkInternalRule(@PathVariable("id")Integer id){
        try {
            return HttpResult.returnSuccess(ruleService.findRuleContentById(id));
        } catch (Exception e) {
            return HttpResult.returnFail("读取规则内容异常");
        }
    }

    @ApiOperation(value = "规则文件重命名")
    @PostMapping("/ruleFileRename")
    public HttpResult ruleFileRename(@RequestBody RuleFileRenameModel ruleFileRenameModel){
        if (ruleFileRenameModel == null || StringUtils.isEmpty(ruleFileRenameModel.getFilePath())
                || StringUtils.isEmpty(ruleFileRenameModel.getNewName())
                || StringUtils.isEmpty(ruleFileRenameModel.getId())) {
            return HttpResult.returnFail("参数有误，请检查");
        }
        return ruleService.ruleFileRename(ruleFileRenameModel);
    }

    private final static String verify="规则名称：rule_001" +
            "end"+"   数据实体：{\n" +
            "    \"alarmType\":1,\n" +
            "    \"alarmDesc\":\"网络异常\"\n" +
            "}";
}

