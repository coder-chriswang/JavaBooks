package com.neoway.mqtt.analyse.vo;

import com.neoway.mqtt.analyse.model.CellIdDeviceImeiMapModel;
import com.neoway.mqtt.analyse.model.DeviceNodeInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *  描述:基站与节点关系显示层实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/10 14:02
 */
@Data
public class CellIdDeviceVo implements Serializable {
    private static final long serialVersionUID = -6559098230231919909L;
    private List<CellInfoVo> cellInfo;
    private List<DeviceNodeInfo> nodeInfo;
    private List<CellIdDeviceImeiMapModel> links;
    private CellInfoVo cellInfoVo;
    private String currentCellId;
}
