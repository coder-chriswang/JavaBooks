package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述:规则实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/7 8:57
 */
@Data
public class RuleParams implements Serializable {

    private static final long serialVersionUID = -7267823080574698111L;
    private Integer pageSize;
    private Integer pageNum;
    private String rule;
    private String name;
    private Integer id;
    private Integer status;
    private String description;
    private Integer type;
    private String path;
    private String projectName;
    private String ruleFileId;
}
