package com.neoway.mqtt.analyse.task;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Maps;
import com.neoway.mqtt.analyse.mapper.DeviceNodeDataMapper;
import com.neoway.mqtt.analyse.model.AlarmInfo;
import com.neoway.mqtt.analyse.model.PatchInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * <pre>
 *  描述:告警信息定时任务类
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/23 15:00
 */
@Component
@EnableScheduling
@Slf4j
public class AlarmDataTimeTask {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private DeviceNodeDataMapper deviceNodeDataMapper;

    private static final String USER_Id = "nw4g";

    /**
     * 定时将告警信息刷入redis 每天凌晨两点钟开始任务
     */
    // @Scheduled(fixedRate = 60000)
    public void insertDataToRedis() {
        log.info("定时存储告警redis数据开始");
        List<AlarmInfo> deviceAlarmInfo = deviceNodeDataMapper.findDeviceAlarmInfo(null);
        if (CollectionUtil.isEmpty(deviceAlarmInfo)) {
            log.info("无满足情形的告警信息");
            return;
        }
        Map<String, String> resultMap = Maps.newHashMap();
        resultMap.put("alarmInfo", JSON.toJSONString(deviceAlarmInfo));
        redisTemplate.boundHashOps("nw:4g:alarmInfos:" + USER_Id).putAll(resultMap);
        log.info("定时存储告警redis数据结束");
    }

    /**
     * 定时将告警信息刷入派单系统进行派单处理 每天凌晨一点钟开始任务
     */
    // @Scheduled(cron = "0 0 1 * * ?")
    public void autoAlarmDispatch() {
        log.info("定时刷入派单数据开始");
        Map<String, String> entries = redisTemplate.<String, String>boundHashOps("nw:4g:alarmInfos:" + USER_Id).entries();
        if (CollectionUtil.isEmpty(entries)) {
            log.info("当前无需要派单的告警信息");
            return;
        }
        String alarmInfo = entries.get("alarmInfo");
        List<AlarmInfo> alarmInfos = JSON.parseObject(alarmInfo,new TypeReference<List<AlarmInfo>>(){});
        List<PatchInfo> patchInfos = new ArrayList<>();
        for (AlarmInfo alarmInfo1 : alarmInfos) {
            PatchInfo patchInfo = new PatchInfo();
            BeanUtil.copyProperties(alarmInfo1,patchInfo);
            patchInfo.setId(UUID.randomUUID().toString());
            patchInfo.setDispatchTime(DateUtil.now());
        }
        deviceNodeDataMapper.insertAlarmDisPatch(patchInfos);
        //再进行清除redis缓存
        redisTemplate.boundHashOps("nw:4g:alarmInfos:" + USER_Id).delete("alarmInfo");
        log.info("定时刷入派单数据完成");
    }
}
