package com.neoway.mqtt.analyse.task;

import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import com.neoway.mqtt.analyse.mapper.DataAnalyseMapper;
import com.neoway.mqtt.analyse.model.AlarmInfoModel;
import com.neoway.mqtt.analyse.model.DeviceInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * <pre>
 *  描述: 刷新设备离线状态定时任务
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/30 9:14
 */
@Component
@EnableScheduling
@Slf4j
public class OfflineTimeTask {

    @Autowired
    private DataAnalyseMapper dataAnalyseMapper;
    /**
     * 每隔一小时
     */
    private static final int ONLINE_REFRESH_FIXED_RATE = 1000 * 60 * 60;

    /**
     * 三天时长间隔
     */
    private static final long ONE_HOUR = 1000 * 60 * 60;

    @Transactional(rollbackFor = Exception.class)
    @Scheduled(fixedRate = ONLINE_REFRESH_FIXED_RATE)
    public void offlineUpdate() {
        log.info("刷新设备离线状态定时任务开始执行！");
        // 查询所有的设备状态
        List<DeviceInfo> deviceInfos = dataAnalyseMapper.findAllDeviceInfo();
        if (CollectionUtils.isEmpty(deviceInfos)) {
            log.error("无任何设备");
            return;
        }
        // 遍历设备，更新离线状态
        for (DeviceInfo deviceInfo : deviceInfos) {
            String imei = deviceInfo.getImei();
            Date upTime = deviceInfo.getUpTime();
            Integer online = deviceInfo.getOnline();
            if (upTime == null || online == 0) {
                log.info("设备还未上报数据！");
                continue;
            }
            long timeInterval = DateUtil.between(new Date(), upTime, DateUnit.MS);
            if (timeInterval > ONE_HOUR) {
                log.info("超过1小时未上报数据，设备设为离线状态！imei={}", imei);
                AlarmInfoModel alarmInfoModel = new AlarmInfoModel();
                try {
                    dataAnalyseMapper.updateOfflineStatus(imei, new Date());
                    // 插入离线数据
                    alarmInfoModel.setAlarmType(0);
                    alarmInfoModel.setImei(imei);
                    alarmInfoModel.setUpTime(new Date());
                    alarmInfoModel.setAlarmOrigin(0);
                    alarmInfoModel.setAlarmAppearance("设备离线");
                    alarmInfoModel.setAlarmReason("设备连接超过一小时未上报数据");
                    alarmInfoModel.setAlarmAdvice("重新连接");
                    dataAnalyseMapper.insertOfflineAlarmInfo(alarmInfoModel);
                } catch (Exception e) {
                    log.error("定时存储数据发生异常！imei={}", imei, e);
                }
            }
        }
        log.info("任务结束！");
    }
}
