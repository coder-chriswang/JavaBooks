package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：性能管理参数类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 15:34
 */
@Data
@ApiModel(value = "性能管理参数")
public class PerformManageParam implements Serializable {
    private static final long serialVersionUID = 3305140706831540654L;

    @ApiModelProperty("历史数据包阈值")
    private Integer historyDataPacketThreshold;

    @ApiModelProperty("数据接收率阈值")
    private Double dataReceiveRateThreshold;

    @ApiModelProperty("数据发送率阈值")
    private Double dataSendRateThreshold;

    @ApiModelProperty("延时指数阈值")
    private Double delayIndexThreshold;

}
