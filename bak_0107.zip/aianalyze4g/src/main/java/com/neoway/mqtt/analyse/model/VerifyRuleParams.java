package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 校验参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/10 16:21
 */
@ApiModel("校验参数")
@Data
public class VerifyRuleParams implements Serializable {

    @ApiModelProperty("唯一规则名称")
    private String ruleName;

    @ApiModelProperty("实体Json")
    private String json;
}
