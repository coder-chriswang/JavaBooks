package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 上报时间周期实体
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/9/22 17:02
 */
@Data
@ApiModel("模组上报时间周期")
public class ReportTime implements Serializable {

    private static final long serialVersionUID = -1884940764316048511L;

    @ApiModelProperty("上报时间周期")
    private int value;

    @ApiModelProperty("下发命令时间戳")
    private Long time;
}
