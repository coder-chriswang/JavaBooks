package com.neoway.mqtt.analyse.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 设备信息模板类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/7 16:35
 */
@Data
@ContentRowHeight(15)
@HeadRowHeight(20)
@ColumnWidth(25)
public class DeviceInfoTemplate implements Serializable {

    private static final long serialVersionUID = -5248141271357215388L;

    @ExcelProperty(value = "设备序列号", index = 0)
    @ApiModelProperty("设备序列号")
    private String imei;

    @ExcelProperty(value = "运营商", index = 1)
    @ApiModelProperty("运营商")
    private String operator;

    @ExcelProperty(value = "小区名称", index = 2)
    @ApiModelProperty("小区名称")
    private String cellName;

    @ExcelProperty(value = "小区地址", index = 3)
    @ApiModelProperty("小区地址")
    private String cellAddress;
}
