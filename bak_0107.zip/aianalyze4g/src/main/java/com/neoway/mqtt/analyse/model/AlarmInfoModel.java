package com.neoway.mqtt.analyse.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述:告警信息实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/24 11:09
 */
@Data
public class AlarmInfoModel implements Serializable {
    private static final long serialVersionUID = 2286627217680695243L;
    private String imei;
    private int alarmType;
    private int alarmOrigin;
    private String alarmReason;
    private String alarmAppearance;
    private String alarmAdvice;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date upTime;
}
