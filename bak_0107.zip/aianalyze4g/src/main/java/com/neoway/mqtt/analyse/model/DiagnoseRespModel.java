package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：模组命令响应模型
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/8/24 19:30
 */
@Data
public class DiagnoseRespModel implements Serializable{
    private static final long serialVersionUID = -1924553781920116719L;

    /**
     * 模组信息
     */
    private ModuleInfo moduleInfo;

    /**
     * 网络状态
     */
    private CSQ csq;

    /**
     * 网络注册状态
     */
    private CREG creg;
}
