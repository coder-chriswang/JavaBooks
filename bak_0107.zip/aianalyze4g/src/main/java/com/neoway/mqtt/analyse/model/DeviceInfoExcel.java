package com.neoway.mqtt.analyse.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 设备信息实体类(导出)
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/7 14:31
 */
@Data
@ContentRowHeight(15)
@HeadRowHeight(25)
@ColumnWidth(25)
public class DeviceInfoExcel implements Serializable {
    private static final long serialVersionUID = 5856024229824814007L;

    @ExcelProperty(value = {"设备序列号"}, index = 0)
    private String imei;

    @ExcelProperty(value = {"运营商"}, index = 1)
    private String operator;

    @ExcelProperty(value = {"小区ID"}, index = 2)
    private String cellId;

    @ExcelProperty(value = {"小区地址"}, index = 3)
    private String cellAddress;

    @ExcelProperty(value = {"小区名称"}, index = 4)
    private String cellName;

    @ExcelProperty(value = {"经度"}, index = 5)
    private String longitude;

    @ExcelProperty(value = {"纬度"}, index = 6)
    private String latitude;

    @ExcelProperty(value = {"设备状态"}, index = 7)
    private String online;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = {"最新活动时间"}, index = 8)
    private Date upTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = {"设备创建时间"}, index = 9)
    private Date createTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = {"设备更新时间"}, index = 10)
    private Date updateTime;
}
