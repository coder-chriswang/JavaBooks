package com.neoway.mqtt.analyse.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 规则设计工程实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/21 11:23
 */
@Data
@ApiModel("规则设计工程参数")
public class RuleDesignProjectParam implements Serializable {
    private static final long serialVersionUID = -3934526285720956541L;
    @ApiModelProperty(value = "id")
    private String id;

    private String pid;

    @ApiModelProperty(value = "工程名称", example = "rule_design_test")
    private String projectName;

    @ApiModelProperty(value = "规则绝对路径", example = "C:/rule_design_test/")
    private String path;

    @ApiModelProperty(value = "发布状态", example = "0:已发布")
    private Integer status;

    @ApiModelProperty(value = "工程描述")
    private String description;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页面显示数")
    private Integer pageSize;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
}
