package com.neoway.mqtt.analyse.mapper;

import com.neoway.mqtt.analyse.model.TopoModel;
import com.neoway.mqtt.analyse.vo.TopoCapabilityVo;
import com.neoway.mqtt.analyse.vo.TopoNodeDataVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <pre>
 * 描述：拓扑数据展示mapper层
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 11:05
 */
@Mapper
public interface TopoShowDataMapper {

    /**
     * 查找基站与设备拓扑关系
     * @param nowDate
     * @return
     */
    List<TopoModel> findTopoInfo(String nowDate);

    /**
     * 查询基站节点的网络性能指标
     * @param currentCellId
     * @param time
     * @return
     */
    List<TopoCapabilityVo>  findBaseStationSingnal(@Param("currentCellId") String currentCellId, @Param("time") String time);

    /**
     * 查询基站节点的基础数据
     * @param currentCellId
     * @param time
     * @return
     */
    TopoNodeDataVo findBaseStationData(@Param("currentCellId") String currentCellId, @Param("time") String time);

    /**
     * 查询设备节点的网络性能指标
     * @param imei
     * @param time
     * @return
     */
    List<TopoCapabilityVo>  findDeviceNodeSingnal(@Param("imei") String imei, @Param("time") String time);


    /**
     * 查询设备节点的基础数据
     * @param imei
     * @param time
     * @return
     */
    TopoNodeDataVo findDeviceNodeData(@Param("imei") String imei, @Param("time") String time);

    /**
     * 查找基站节点信号平均值
     * @param currentCellId
     * @param time
     * @return
     */
    TopoNodeDataVo findBaseStationAver(@Param("currentCellId") String currentCellId, @Param("time") String time);

    /**
     * 查询多天基站节点的网络性能指标
     * @param currentCellId
     * @param fromDate
     * @param toDate
     * @return
     */
    List<TopoCapabilityVo> findBaseStationSingnalOfDays(@Param("currentCellId") String currentCellId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /**
     * 查询多天设备节点的网络性能指标
     * @param imei
     * @param fromDate
     * @param toDate
     * @return
     */
    List<TopoCapabilityVo> findDeviceNodeSingnalOfDays(@Param("imei") String imei, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /**
     * 查询多天设备节点的基础数据
     * @param imei
     * @param fromDate
     * @param toDate
     * @return
     */
    TopoNodeDataVo findDeviceNodeDataOfDays(@Param("imei") String imei, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /**
     * 查询多天基站节点的基础数据
     * @param currentCellId
     * @param fromDate
     * @param toDate
     * @return
     */
    TopoNodeDataVo findBaseStationDataOfDays(@Param("currentCellId") String currentCellId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /**
     * 查找多天基站节点信号平均值
     * @param currentCellId
     * @param fromDate
     * @param toDate
     * @return
     */
    TopoNodeDataVo findBaseStationAverOfDays(@Param("currentCellId") String currentCellId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);
}
