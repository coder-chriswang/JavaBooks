package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述:查询设备信息条件实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/7 14:01
 */
@Data
public class DeviceSearchCondition implements Serializable {
    private static final long serialVersionUID = -8479957032489763984L;

    @ApiModelProperty("设备序列号")
    private String imei;

    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("运营商")
    private String operator;

    @ApiModelProperty("在线状态，0表示离线，1表示在线")
    private Integer online;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("页面大小")
    private Integer pageSize;

    @ApiModelProperty("页码")
    private Integer pageNum;

}
