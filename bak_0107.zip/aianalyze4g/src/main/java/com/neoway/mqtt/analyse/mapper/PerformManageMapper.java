package com.neoway.mqtt.analyse.mapper;

import com.neoway.mqtt.analyse.model.PerformManageParam;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <pre>
 * 描述：性能管理mapper层
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 17:00
 */
@Mapper
public interface PerformManageMapper {

    /**
     * 新增性能配置
     * @param addParam
     * @return
     */
    void addPerformConfig(@Param("addParam") PerformManageParam addParam);

    /**
     * 更新性能配置
     * @param updateParam
     * @return
     */
    void updatePerformConfig(@Param("updateParam") PerformManageParam updateParam);

    /**
     * 删除性能配置
     * @return
     */
    void deletePerformConfig();


    /**
     * 查询唯一配置
     *
     * @return
     */
    PerformManageParam findOne();

    /**
     * 查询性能观测周期数
     * @return
     */
    int findObservationTime();

    /**
     * 更新性能观测周期数
     * @param observationTime
     */
    void updateObservationTime(@Param("observationTime") Integer observationTime);
}
