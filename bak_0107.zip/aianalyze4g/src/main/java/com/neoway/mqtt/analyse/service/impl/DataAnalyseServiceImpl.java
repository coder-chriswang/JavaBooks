package com.neoway.mqtt.analyse.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neoway.mqtt.analyse.constants.AlarmTypeConstant;
import com.neoway.mqtt.analyse.constants.CapabilityIndexConstant;
import com.neoway.mqtt.analyse.mapper.DataAnalyseMapper;
import com.neoway.mqtt.analyse.mapper.DeviceNodeDataMapper;
import com.neoway.mqtt.analyse.model.*;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.service.DataAnalyseService;
import com.neoway.mqtt.analyse.util.ExcelUtil;
import com.neoway.mqtt.analyse.util.FeatureAnalysisUtil;
import com.neoway.mqtt.analyse.util.NetInfoUtil;
import com.neoway.mqtt.analyse.util.OperatorEnum;
import com.neoway.mqtt.analyse.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <pre>
 * 描述：数据展示层service实现类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 14:36
 */
@Service
@Slf4j
public class DataAnalyseServiceImpl implements DataAnalyseService {

    @Autowired
    DataAnalyseMapper dataAnalyseMapper;

    @Autowired
    DeviceNodeDataMapper deviceNodeDataMapper;

    @Autowired
    private EmqRedisDao emqRedisDao;

    @Override
    public PipeCloudDataVo findInfo(SearchCondition searchCondition) {
        PipeCloudDataVo pipeCloudDataVo = new PipeCloudDataVo();
        String address = searchCondition.getAddress();
        String cellId = dataAnalyseMapper.findCellIdByAddress(address);
        searchCondition.setCellId(cellId);
        // 设备在线统计
        OnlineModel onlineModel = this.findOnlineInfo(cellId);
        pipeCloudDataVo.setDeviceCount(String.valueOf(onlineModel.getSumNum()));
        pipeCloudDataVo.setOnlineNum(String.valueOf(onlineModel.getOnlineNum()));
        pipeCloudDataVo.setRate(onlineModel.getRate());

        // 网络通道质量统计
        List<NetChannelInfo> netChannelInfos = this.findV2AllChannelInfo(cellId);
        handleNetChannelInfo(netChannelInfos, pipeCloudDataVo);

        //数据采集
        CollectDataModel collectDataModel = new CollectDataModel();
        int sum = 0;
        collectDataModel.setFailNum("0");
        collectDataModel.setSuccessRate("100.00%");
        List<Map<String, Object>> msgList = dataAnalyseMapper.findAllMsgInfoByDay(cellId, DateUtil.today());
        for (Map<String, Object> map : msgList) {
            String value = String.valueOf(map.getOrDefault("messageCount", "0"));
            sum += Integer.valueOf(value);
        }
        collectDataModel.setSuccessNum(String.valueOf(sum));
        Date toDate = DateUtil.parse(DateUtil.yesterday().toString("yyyy-MM-dd"));
        Date fromDate = DateUtil.parse(DateUtil.offsetDay(toDate, -7).toString());
        Date endOfNowDate = DateUtil.endOfDay(toDate);
        List<Map<String, Object>> msgListOfWeek = dataAnalyseMapper.findAllMsgInfoByWeek(cellId, fromDate, endOfNowDate);
        collectDataModel.setMsgList(msgListOfWeek);
        pipeCloudDataVo.setCollectDataModel(collectDataModel);
        log.info("pipeCloudDataVo的数据采集信息为 {}",collectDataModel);

        //运营商网络对比信息
        NetSignalOfDayVo netSignalOfDayVo = this.findNetSignalOfDay(searchCondition.getAddress());
        collectDataModel.setNetSignalOfDayVo(netSignalOfDayVo);

        // 告警信息
        List<AlarmInfoVo> alarmInfoVos = this.findAllAlarmInfo(0);
        pipeCloudDataVo.setAlarmInfoList(alarmInfoVos);

        // 设备信息
        List<PipeCloudDataOfCellVo> pipeCloudDataOfCellVoList = this.findV2AllPipeCloudDataOfCell(searchCondition);
        pipeCloudDataVo.setPipeCloudDataList(new PageInfo<>(pipeCloudDataOfCellVoList));
        return pipeCloudDataVo;
    }

    private OnlineModel findOnlineInfo(String cellId) {
        OnlineModel onlineModel = new OnlineModel();
        if (dataAnalyseMapper.findOnlineModel(cellId) == null) {
            onlineModel.setOnlineNum(0);
            onlineModel.setSumNum(0);
            onlineModel.setRate("0.00%");
            return onlineModel;
        }
        return dataAnalyseMapper.findOnlineModel(cellId);
    }

    private List<AlarmInfoVo> findAllAlarmInfo(Integer alarmType) {
        return dataAnalyseMapper.findAllAlarmInfo(alarmType);
    }

    @Override
    public List<PipeCloudDataOfCellVo> findAllPipeCloudDataOfCell(SearchCondition searchCondition) {
        String operatorValue = searchCondition.getOperator();
        String signalLevelValue = searchCondition.getSignalLevel();
        PageHelper.startPage(searchCondition.getPageNum(), searchCondition.getPageSize());
        List<PipeCloudDataOfCellVo> pipeCloudDataOfCellVoList = dataAnalyseMapper.findAllPipeCloudDataOfCell(searchCondition.getImei(), searchCondition.getCellId(), DateUtil.today());
        for (PipeCloudDataOfCellVo pipeCloudDataOfCellVo : pipeCloudDataOfCellVoList) {
            List<NetReportInfoOfImei> netReportInfoOfImeis = dataAnalyseMapper.findAllNetReportInfoOfImei(pipeCloudDataOfCellVo.getImei());
            double rsrpValue;
            double snrValue;
            if (CollectionUtils.isEmpty(netReportInfoOfImeis)) {
                rsrpValue = Double.valueOf(pipeCloudDataOfCellVo.getLteRSRP());
                snrValue = Double.valueOf(pipeCloudDataOfCellVo.getLteSINR());
            } else {
                rsrpValue = Double.valueOf(netReportInfoOfImeis.get(0).getLteRsrpMax());
                snrValue = Double.valueOf(netReportInfoOfImeis.get(0).getLteSinrMax());
            }
            if (snrValue <= 5) {
                if (rsrpValue <= -115) {
                    pipeCloudDataOfCellVo.setSignalLevel("极差");
                } else if (rsrpValue <= -105) {
                    pipeCloudDataOfCellVo.setSignalLevel("较差");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel("正常");
                }
            } else if (snrValue <= 15) {
                if (rsrpValue <= -95) {
                    pipeCloudDataOfCellVo.setSignalLevel("正常");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel("良好");
                }
            } else if (snrValue <= 25) {
                if (rsrpValue > -95 && rsrpValue <= -85) {
                    pipeCloudDataOfCellVo.setSignalLevel("良好");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel("优秀");
                }
            } else {
                pipeCloudDataOfCellVo.setSignalLevel("优秀");
            }
            //其他运营商的网络质量
            OperatorNetScanInfo operatorNetScanInfo = dataAnalyseMapper.findOperatorNetScanInfo(pipeCloudDataOfCellVo.getImei(),DateUtil.today());
            if (operatorNetScanInfo == null) {
                continue;
            }
            pipeCloudDataOfCellVo.setOperator1(operatorNetScanInfo.getOperator1());
            pipeCloudDataOfCellVo.setOperator2(operatorNetScanInfo.getOperator2());
            double rsrpValue1 = operatorNetScanInfo.getRsrpValue1();
            double snrValue1 = operatorNetScanInfo.getSnrValue1();
            double rsrpValue2 = operatorNetScanInfo.getRsrpValue2();
            double snrValue2 = operatorNetScanInfo.getSnrValue2();
            pipeCloudDataOfCellVo.setRsrpValue1(String.valueOf(rsrpValue1));
            pipeCloudDataOfCellVo.setRsrpValue2(String.valueOf(rsrpValue2));
            pipeCloudDataOfCellVo.setSnrValue1(String.valueOf(snrValue1));
            pipeCloudDataOfCellVo.setSnrValue2(String.valueOf(snrValue2));
            //判断运营商1信号等级
            if (snrValue1 <= 5) {
                if (rsrpValue1 <= -115) {
                    pipeCloudDataOfCellVo.setSignalLevel1("极差");
                } else if (rsrpValue1 <= -105) {
                    pipeCloudDataOfCellVo.setSignalLevel1("较差");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel1("正常");
                }
            } else if (snrValue1 <= 15) {
                if (rsrpValue1 <= -95) {
                    pipeCloudDataOfCellVo.setSignalLevel1("正常");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel1("良好");
                }
            } else if (snrValue1 <= 25) {
                if (rsrpValue1 > -95 && rsrpValue1 <= -85) {
                    pipeCloudDataOfCellVo.setSignalLevel1("良好");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel1("优秀");
                }
            } else {
                pipeCloudDataOfCellVo.setSignalLevel1("优秀");
            }
            //判断运营商2信号等级
            if (snrValue2 <= 5) {
                if (rsrpValue2 <= -115) {
                    pipeCloudDataOfCellVo.setSignalLevel2("极差");
                } else if (rsrpValue2 <= -105) {
                    pipeCloudDataOfCellVo.setSignalLevel2("较差");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel2("正常");
                }
            } else if (snrValue2 <= 15) {
                if (rsrpValue2 <= -95) {
                    pipeCloudDataOfCellVo.setSignalLevel2("正常");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel2("良好");
                }
            } else if (snrValue2 <= 25) {
                if (rsrpValue2 > -95 && rsrpValue2 <= -85) {
                    pipeCloudDataOfCellVo.setSignalLevel2("良好");
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel2("优秀");
                }
            } else {
                pipeCloudDataOfCellVo.setSignalLevel2("优秀");
            }
            if (StringUtils.equals("未知", operatorNetScanInfo.getOperator1())) {
                pipeCloudDataOfCellVo.setSignalLevel1("");
            }
            if (StringUtils.equals("未知", operatorNetScanInfo.getOperator2())) {
                pipeCloudDataOfCellVo.setSignalLevel2("");
            }
        }
        //运营商和信号等级遍历获取
        if (StringUtils.isBlank(operatorValue) && StringUtils.isBlank(signalLevelValue)) {
            return pipeCloudDataOfCellVoList;
        }
        List<PipeCloudDataOfCellVo> resultList = new ArrayList<>();
        for (PipeCloudDataOfCellVo pipeCloudDataOfCellVo : pipeCloudDataOfCellVoList) {
            if (StringUtils.isBlank(operatorValue)) {
                if (StringUtils.equals(pipeCloudDataOfCellVo.getSignalLevel(), signalLevelValue)) {
                    resultList.add(pipeCloudDataOfCellVo);
                }
            } else {
                if (StringUtils.isBlank(signalLevelValue)) {
                    if (StringUtils.equals(pipeCloudDataOfCellVo.getOperator(), operatorValue)) {
                        resultList.add(pipeCloudDataOfCellVo);
                    }
                } else {
                    if (StringUtils.equals(pipeCloudDataOfCellVo.getOperator(), operatorValue) && StringUtils.equals(pipeCloudDataOfCellVo.getSignalLevel(), signalLevelValue)) {
                        resultList.add(pipeCloudDataOfCellVo);
                    }
                }
            }
        }
        return resultList;
    }

    @Override
    public List<PipeCloudDataOfCellVo> findV2AllPipeCloudDataOfCell(SearchCondition searchCondition) {
        String operatorValue = searchCondition.getOperator();
        String signalLevelValue = searchCondition.getSignalLevel();
        PageHelper.startPage(searchCondition.getPageNum(), searchCondition.getPageSize());
        List<PipeCloudDataOfCellVo> pipeCloudDataOfCellVoList = dataAnalyseMapper.findV2AllPipeCloudDataOfCell(searchCondition.getImei(), searchCondition.getCellId(), DateUtil.today(), operatorValue);
        for (PipeCloudDataOfCellVo pipeCloudDataOfCellVo : pipeCloudDataOfCellVoList) {
            if (!StringUtils.isEmpty(pipeCloudDataOfCellVo.getLteRSRP()) && !StringUtils.isEmpty(pipeCloudDataOfCellVo.getLteSINR())) {
                Double  rsrpValue = Double.valueOf(pipeCloudDataOfCellVo.getLteRSRP());
                Double  snrValue = Double.valueOf(pipeCloudDataOfCellVo.getLteSINR());
                if (snrValue <= 5) {
                    if (rsrpValue <= -105) {
                        pipeCloudDataOfCellVo.setSignalLevel("差");
                    }else {
                        pipeCloudDataOfCellVo.setSignalLevel("优");
                    }
                } else if (snrValue <= 15) {
                    if (rsrpValue <= -95) {
                        pipeCloudDataOfCellVo.setSignalLevel("优");
                    } else {
                        pipeCloudDataOfCellVo.setSignalLevel("中");
                    }
                } else if (snrValue <= 25) {
                    if (rsrpValue > -95 && rsrpValue <= -85) {
                        pipeCloudDataOfCellVo.setSignalLevel("中");
                    } else {
                        pipeCloudDataOfCellVo.setSignalLevel("优");
                    }
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel("优");
                }
            } else {
                pipeCloudDataOfCellVo.setSignalLevel("未知");
            }

            if (!StringUtils.isBlank(pipeCloudDataOfCellVo.getRsrpValue1()) && !StringUtils.isBlank(pipeCloudDataOfCellVo.getSnrValue1())) {
                double rsrpValue1 = Double.valueOf(pipeCloudDataOfCellVo.getRsrpValue1());
                double snrValue1 = Double.valueOf(pipeCloudDataOfCellVo.getSnrValue1());
                //判断运营商1信号等级
                if (snrValue1 <= 5) {
                    if (rsrpValue1 <= -105) {
                        pipeCloudDataOfCellVo.setSignalLevel1("差");
                    }else {
                        pipeCloudDataOfCellVo.setSignalLevel1("优");
                    }
                } else if (snrValue1 <= 15) {
                    if (rsrpValue1 <= -95) {
                        pipeCloudDataOfCellVo.setSignalLevel1("优");
                    } else {
                        pipeCloudDataOfCellVo.setSignalLevel1("中");
                    }
                } else if (snrValue1 <= 25) {
                    if (rsrpValue1 > -95 && rsrpValue1 <= -85) {
                        pipeCloudDataOfCellVo.setSignalLevel1("中");
                    } else {
                        pipeCloudDataOfCellVo.setSignalLevel1("优");
                    }
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel1("优");
                }
                if (StringUtils.equals("未知", pipeCloudDataOfCellVo.getOperator1())) {
                    pipeCloudDataOfCellVo.setSignalLevel1("");
                }
            } else {
                pipeCloudDataOfCellVo.setSignalLevel1("未知");
            }

            if (!StringUtils.isBlank(pipeCloudDataOfCellVo.getRsrpValue2()) && !StringUtils.isBlank(pipeCloudDataOfCellVo.getSnrValue2())){
                double rsrpValue2 = Double.valueOf(pipeCloudDataOfCellVo.getRsrpValue2());
                double snrValue2 = Double.valueOf(pipeCloudDataOfCellVo.getSnrValue2());
                //判断运营商2信号等级
                if (snrValue2 <= 5) {
                    if (rsrpValue2 <= -105) {
                        pipeCloudDataOfCellVo.setSignalLevel2("差");
                    }else {
                        pipeCloudDataOfCellVo.setSignalLevel2("优");
                    }
                } else if (snrValue2 <= 15) {
                    if (rsrpValue2 <= -95) {
                        pipeCloudDataOfCellVo.setSignalLevel2("优");
                    } else {
                        pipeCloudDataOfCellVo.setSignalLevel2("中");
                    }
                } else if (snrValue2 <= 25) {
                    if (rsrpValue2 > -95 && rsrpValue2 <= -85) {
                        pipeCloudDataOfCellVo.setSignalLevel2("中");
                    } else {
                        pipeCloudDataOfCellVo.setSignalLevel2("优");
                    }
                } else {
                    pipeCloudDataOfCellVo.setSignalLevel2("优");
                }
                if (StringUtils.equals("未知", pipeCloudDataOfCellVo.getOperator2())) {
                    pipeCloudDataOfCellVo.setSignalLevel2("");
                }
            } else {
                pipeCloudDataOfCellVo.setSignalLevel2("未知");
            }
        }
        if (StringUtils.isBlank(signalLevelValue)) {
            return pipeCloudDataOfCellVoList;
        }
        List<PipeCloudDataOfCellVo> resultList = new ArrayList<>();
        for (PipeCloudDataOfCellVo pipeCloudDataOfCellVo : pipeCloudDataOfCellVoList) {
            if (StringUtils.equals(pipeCloudDataOfCellVo.getSignalLevel(), signalLevelValue)) {
                resultList.add(pipeCloudDataOfCellVo);
            }
        }
        return resultList;
    }


    private List<NetChannelInfo> findAllChannelInfo(String cellId) {
        List<NetChannelInfo> netChannelInfoList = dataAnalyseMapper.findAllNetChannelInfo(cellId, DateUtil.today());
        for (NetChannelInfo netChannelInfo : netChannelInfoList) {
            List<NetReportInfoOfImei> netReportInfoOfImeis = dataAnalyseMapper.findAllNetReportInfoOfImei(netChannelInfo.getImei());
            Double rsrpValue;
            Double snrValue;
            if (CollectionUtils.isEmpty(netReportInfoOfImeis)) {
                rsrpValue = netChannelInfo.getRsrpValue();
                snrValue = netChannelInfo.getSnrValue();
            } else {
                rsrpValue = netReportInfoOfImeis.get(0).getLteRsrpAver();
                snrValue = netReportInfoOfImeis.get(0).getLteSinrAver();
            }
            if (rsrpValue != null && snrValue != null) {
                if (snrValue <= 5) {
                    if (rsrpValue <= -115) {
                        netChannelInfo.setSignalLevel("极差");
                    } else if (rsrpValue <= -105) {
                        netChannelInfo.setSignalLevel("较差");
                    } else {
                        netChannelInfo.setSignalLevel("正常");
                    }
                } else if (snrValue <= 15) {
                    if (rsrpValue <= -95) {
                        netChannelInfo.setSignalLevel("正常");
                    } else {
                        netChannelInfo.setSignalLevel("良好");
                    }
                } else if (snrValue <= 25) {
                    if (rsrpValue > -95 && rsrpValue <= -85) {
                        netChannelInfo.setSignalLevel("良好");
                    } else {
                        netChannelInfo.setSignalLevel("优秀");
                    }
                } else {
                    netChannelInfo.setSignalLevel("优秀");
                }
            } else {
                netChannelInfo.setSignalLevel("未知");
            }
        }
        return netChannelInfoList;
    }

    private List<NetChannelInfo> findV2AllChannelInfo(String cellId) {
        List<NetChannelInfo> netChannelInfoList = dataAnalyseMapper.findV2AllNetChannelInfo(cellId, DateUtil.today());
        for (NetChannelInfo netChannelInfo : netChannelInfoList) {
            Double rsrpValue = netChannelInfo.getRsrpValue();
            Double snrValue = netChannelInfo.getSnrValue();
            if (rsrpValue != null && snrValue != null) {
                if (snrValue <= 5) {
                    if (rsrpValue <= -105) {
                        netChannelInfo.setSignalLevel("差");
                    }else {
                        netChannelInfo.setSignalLevel("优");
                    }
                } else if (snrValue <= 15) {
                    if (rsrpValue <= -95) {
                        netChannelInfo.setSignalLevel("优");
                    } else {
                        netChannelInfo.setSignalLevel("中");
                    }
                } else if (snrValue <= 25) {
                    if (rsrpValue > -95 && rsrpValue <= -85) {
                        netChannelInfo.setSignalLevel("中");
                    } else {
                        netChannelInfo.setSignalLevel("优");
                    }
                } else {
                    netChannelInfo.setSignalLevel("优");
                }
            } else {
                netChannelInfo.setSignalLevel("未知");
            }
        }
        return netChannelInfoList;
    }


    private void handleNetChannelInfo(List<NetChannelInfo> netChannelInfos, PipeCloudDataVo pipeCloudDataVo) {
        int count = netChannelInfos.size();
        if (count == 0) {
            return;
        }
        int goodQualityOfNetNum = 0;
        int midQualityOfNetNum = 0;
        int badQualityOfNetNum = 0;
        int unknownOfNetNum = 0;
        for (NetChannelInfo netChannelInfo : netChannelInfos) {
            if ("优".equals(netChannelInfo.getSignalLevel())) {
                goodQualityOfNetNum++ ;
            } else if ("中".equals(netChannelInfo.getSignalLevel())) {
                midQualityOfNetNum++;
            } else if ("差".equals(netChannelInfo.getSignalLevel())) {
                badQualityOfNetNum++;
            } else {
                unknownOfNetNum++;
            }
        }
        pipeCloudDataVo.setGoodQualityOfNetNum(goodQualityOfNetNum);
        pipeCloudDataVo.setMidQualityOfNetNum(midQualityOfNetNum);
        pipeCloudDataVo.setBadQualityOfNetNum(badQualityOfNetNum);
        pipeCloudDataVo.setUnknownNetNum(unknownOfNetNum);
    }

    @Override
    public NetSignalOfDayVo findNetSignalOfDay(String address) {
        String cellId = dataAnalyseMapper.findCellIdByAddress(address);
        NetSignalOfDayVo netSignalOfDayVo = new NetSignalOfDayVo();
        List<NetSignalOfDay> cmccList = dataAnalyseMapper.findNetSignalByDay(DateUtil.today(), cellId, Arrays.asList(OperatorEnum.CMCC.getPlmn().split(",")));
        List<NetSignalOfDay> cuccList = dataAnalyseMapper.findNetSignalByDay(DateUtil.today(), cellId, Arrays.asList(OperatorEnum.CUCC.getPlmn().split(",")));
        List<NetSignalOfDay> ctccList = dataAnalyseMapper.findNetSignalByDay(DateUtil.today(), cellId, Arrays.asList(OperatorEnum.CTCC.getPlmn().split(",")));
        handleSignalLevelOfDay(cmccList);
        handleSignalLevelOfDay(cuccList);
        handleSignalLevelOfDay(ctccList);
        netSignalOfDayVo.setCmccList(cmccList);
        netSignalOfDayVo.setCuccList(cuccList);
        netSignalOfDayVo.setCtccList(ctccList);
        return netSignalOfDayVo;
    }

    @Override
    public NetSignalOfDayVo findNetSignalOfDays(String address, int dayNum) {
        String cellId = dataAnalyseMapper.findCellIdByAddress(address);
        NetSignalOfDayVo netSignalOfDayVo = new NetSignalOfDayVo();
        Date toDate = DateUtil.parse(DateUtil.today());
        Date fromDate = DateUtil.parse(DateUtil.offsetDay(toDate, dayNum + 1).toString());
        Date endOfNowDate = DateUtil.endOfDay(toDate);
        List<NetSignalOfDay> cmccList = dataAnalyseMapper.findNetSignalByDays(fromDate, endOfNowDate, cellId, Arrays.asList(OperatorEnum.CMCC.getPlmn().split(",")));
        List<NetSignalOfDay> cuccList = dataAnalyseMapper.findNetSignalByDays(fromDate, endOfNowDate, cellId, Arrays.asList(OperatorEnum.CUCC.getPlmn().split(",")));
        List<NetSignalOfDay> ctccList = dataAnalyseMapper.findNetSignalByDays(fromDate, endOfNowDate, cellId, Arrays.asList(OperatorEnum.CTCC.getPlmn().split(",")));
        handleSignalLevelOfDay(cmccList);
        handleSignalLevelOfDay(cuccList);
        handleSignalLevelOfDay(ctccList);
        netSignalOfDayVo.setCmccList(cmccList);
        netSignalOfDayVo.setCuccList(cuccList);
        netSignalOfDayVo.setCtccList(ctccList);
        return netSignalOfDayVo;
    }

    @Override
    public DeviceTopoVo findAllDeviceData() {
        DeviceTopoVo deviceTopoVo = new DeviceTopoVo();
        // 查询设备总数据量统计
        DeviceCensusModel allDeviceCensus = dataAnalyseMapper.findAllDeviceCensus(DateUtil.today());
        // 设置上行数据量
        allDeviceCensus.setUploadPackageNo(allDeviceCensus.getTotalPackageNo() - allDeviceCensus.getDownloadPackageNo());
        deviceTopoVo.setDeviceCensusModel(allDeviceCensus);

        // 查询设备当天在线状况
        DeviceOnlineCensusModel allDeviceOnlineCensus = dataAnalyseMapper.findAllDeviceOnlineCensus();
        // 设置离线设备数量
        allDeviceOnlineCensus.setOfflineNo(allDeviceOnlineCensus.getTotalNo() - allDeviceOnlineCensus.getOnlineNo());
        deviceTopoVo.setDeviceOnlineCensusModel(allDeviceOnlineCensus);

        // 获取网络趋势
        NetSignalOfDayVo netSignalOfToDay = this.findNetSignalOfToDay();
        deviceTopoVo.setNetSignalOfDayVo(netSignalOfToDay);

        // 获取当日采集成功率
        CollectDataModel collectDataModel = new CollectDataModel();
        int sum = 0;
        collectDataModel.setFailNum("0");
        collectDataModel.setSuccessRate("100.00%");
        List<Map<String, Object>> msgList = dataAnalyseMapper.findAllMsgInfoByDay(null, DateUtil.today());
        for (Map<String, Object> map : msgList) {
            String value = String.valueOf(map.getOrDefault("messageCount", "0"));
            sum += Integer.valueOf(value);
        }
        collectDataModel.setSuccessNum(String.valueOf(sum));
        collectDataModel.setMsgList(msgList);
        deviceTopoVo.setCollectDataModel(collectDataModel);

        // 统计sim卡使用情况
        SimCardStatistic simCardStatistic = this.statisticSimCardInfo();
        deviceTopoVo.setSimCardStatistic(simCardStatistic);
        return deviceTopoVo;
    }

    @Override
    public NetSignalOfDayVo findNetSignalOfToDay() {
        NetSignalOfDayVo netSignalOfDayVo = new NetSignalOfDayVo();
        List<NetSignalOfDay> cmccList = dataAnalyseMapper.findNetSignalByDay(DateUtil.today(),null, Arrays.asList(OperatorEnum.CMCC.getPlmn().split(",")));
        List<NetSignalOfDay> cuccList = dataAnalyseMapper.findNetSignalByDay(DateUtil.today(),null, Arrays.asList(OperatorEnum.CUCC.getPlmn().split(",")));
        List<NetSignalOfDay> ctccList = dataAnalyseMapper.findNetSignalByDay(DateUtil.today(),null, Arrays.asList(OperatorEnum.CTCC.getPlmn().split(",")));
        handleSignalLevelOfDay(cmccList);
        handleSignalLevelOfDay(cuccList);
        handleSignalLevelOfDay(ctccList);
        netSignalOfDayVo.setCmccList(cmccList);
        netSignalOfDayVo.setCuccList(cuccList);
        netSignalOfDayVo.setCtccList(ctccList);
        return netSignalOfDayVo;
    }

    @Override
    public List<ApiDocVo> findAllApiDoc() {
        return dataAnalyseMapper.findAllApiDoc();
    }

    @Override
    public ApiDocVo findApiDocById(int id) {
        return dataAnalyseMapper.findApiDocById(id);
    }

    private void handleSignalLevelOfDay(List<NetSignalOfDay> list) {
        for (NetSignalOfDay netSignalOfDay : list) {
            Double rsrpValue = netSignalOfDay.getRsrpValue();
            Double snrValue = netSignalOfDay.getSnrValue();
            if ( rsrpValue != null && snrValue != null){
                if (snrValue <= 5) {
                    if (rsrpValue <= -105) {
                        netSignalOfDay.setSignalLevel("差");
                        netSignalOfDay.setSignalValue(1);
                    }else {
                        netSignalOfDay.setSignalLevel("优");
                        netSignalOfDay.setSignalValue(3);
                    }
                } else if (snrValue <= 15) {
                    if (rsrpValue <= -95) {
                        netSignalOfDay.setSignalLevel("优");
                        netSignalOfDay.setSignalValue(3);
                    } else {
                        netSignalOfDay.setSignalLevel("中");
                        netSignalOfDay.setSignalValue(2);
                    }
                } else if (snrValue <= 25) {
                    if (rsrpValue > -95 && rsrpValue <= -85) {
                        netSignalOfDay.setSignalLevel("中");
                        netSignalOfDay.setSignalValue(2);
                    } else {
                        netSignalOfDay.setSignalLevel("优");
                        netSignalOfDay.setSignalValue(3);
                    }
                } else {
                    netSignalOfDay.setSignalLevel("优");
                    netSignalOfDay.setSignalValue(3);
                }
            } else {
                netSignalOfDay.setSignalLevel("未知");
            }
        }
    }

    @Override
    public NetReportInfoOfImei findDeviceInfoOfCellByImei(String imei){
        return dataAnalyseMapper.findNetReportInfoOfImei(imei);
    }

    @Override
    public NetSignalOfImeiByMonthVo findNetInfoByImei(String imei) {
        NetSignalOfImeiByMonthVo netSignalOfImeiByMonthVo = new NetSignalOfImeiByMonthVo();
        Date toDate = DateUtil.parse(DateUtil.today());
        Date fromDate = DateUtil.parse(DateUtil.offsetDay(toDate, -29).toString());
        Date endOfNowDate = DateUtil.endOfDay(toDate);
        List<NetSignalOfImeiByMonth> cmccList = dataAnalyseMapper.findNetSignalOfImeiByMonth(imei, fromDate, endOfNowDate, Arrays.asList(OperatorEnum.CMCC.getPlmn().split(",")));
        List<NetSignalOfImeiByMonth> cuccList = dataAnalyseMapper.findNetSignalOfImeiByMonth(imei, fromDate, endOfNowDate, Arrays.asList(OperatorEnum.CUCC.getPlmn().split(",")));
        List<NetSignalOfImeiByMonth> ctccList = dataAnalyseMapper.findNetSignalOfImeiByMonth(imei, fromDate, endOfNowDate, Arrays.asList(OperatorEnum.CTCC.getPlmn().split(",")));
        handleSignalLevelOfMonth(cmccList);
        handleSignalLevelOfMonth(cuccList);
        handleSignalLevelOfMonth(ctccList);
        netSignalOfImeiByMonthVo.setCmccList(cmccList);
        netSignalOfImeiByMonthVo.setCuccList(cuccList);
        netSignalOfImeiByMonthVo.setCtccList(ctccList);
        return netSignalOfImeiByMonthVo;
    }

    private void handleSignalLevelOfMonth(List<NetSignalOfImeiByMonth> list) {
        for (NetSignalOfImeiByMonth netSignalOfImeiByMonth : list) {
            Double rsrpValue = netSignalOfImeiByMonth.getRsrpValue();
            Double snrValue = netSignalOfImeiByMonth.getSnrValue();
            if (rsrpValue != null && snrValue != null) {
                if (snrValue <= 5) {
                    if (rsrpValue <= -105) {
                        netSignalOfImeiByMonth.setSignalLevel("差");
                        netSignalOfImeiByMonth.setSignalValue(1);
                    }else {
                        netSignalOfImeiByMonth.setSignalLevel("优");
                        netSignalOfImeiByMonth.setSignalValue(3);
                    }
                } else if (snrValue <= 15) {
                    if (rsrpValue <= -95) {
                        netSignalOfImeiByMonth.setSignalLevel("优");
                        netSignalOfImeiByMonth.setSignalValue(3);
                    } else {
                        netSignalOfImeiByMonth.setSignalLevel("中");
                        netSignalOfImeiByMonth.setSignalValue(2);
                    }
                } else if (snrValue <= 25) {
                    if (rsrpValue > -95 && rsrpValue <= -85) {
                        netSignalOfImeiByMonth.setSignalLevel("中");
                        netSignalOfImeiByMonth.setSignalValue(2);
                    } else {
                        netSignalOfImeiByMonth.setSignalLevel("优");
                        netSignalOfImeiByMonth.setSignalValue(3);
                    }
                } else {
                    netSignalOfImeiByMonth.setSignalLevel("优");
                    netSignalOfImeiByMonth.setSignalValue(3);
                }
            } else {
                netSignalOfImeiByMonth.setSignalLevel("未知");
            }
        }
    }
    @Override
    public void exportDeviceInfo(SearchCondition searchCondition, HttpServletResponse response) {
        List<PipeCloudDataOfCellVo> pipeCloudDataOfCellVoList = this.findV2AllPipeCloudDataOfCell(searchCondition);
        List<DeviceInfoOfExcel> deviceInfoOfExcelList = new ArrayList<>();
        for (PipeCloudDataOfCellVo pipeCloudDataOfCellVo : pipeCloudDataOfCellVoList) {
            DeviceInfoOfExcel deviceInfoOfExcel = new DeviceInfoOfExcel();
            convertGasMeterInfo(pipeCloudDataOfCellVo, deviceInfoOfExcel);
            deviceInfoOfExcelList.add(deviceInfoOfExcel);
        }
        try {
            ExcelUtil.export(response, "DeviceInfo", "设备信息", DeviceInfoOfExcel.class, deviceInfoOfExcelList);
        } catch (Exception e) {
            log.error("导出失败！", e);
        }
    }

    private void convertGasMeterInfo(PipeCloudDataOfCellVo pipeCloudDataOfCellVo, DeviceInfoOfExcel deviceInfoOfExcel) {
        NetReportInfoOfImei netReportInfoOfImei = dataAnalyseMapper.findNetReportInfoOfImei(pipeCloudDataOfCellVo.getImei());
        if (netReportInfoOfImei == null) {
            return;
        }
        String netOperator = NetInfoUtil.getNetOperator(netReportInfoOfImei.getPLMN());
        deviceInfoOfExcel.setOperator(netOperator);
        BeanUtil.copyProperties(netReportInfoOfImei, deviceInfoOfExcel);
        String[] cellLocations = pipeCloudDataOfCellVo.getCellLocations().split(",");
        deviceInfoOfExcel.setAddress(pipeCloudDataOfCellVo.getCellAddress());
        deviceInfoOfExcel.setCellName(pipeCloudDataOfCellVo.getCellName());
        deviceInfoOfExcel.setLongitude(cellLocations[0]);
        deviceInfoOfExcel.setLatitude(cellLocations[1]);
        deviceInfoOfExcel.setSinr(pipeCloudDataOfCellVo.getLteSINR());
        deviceInfoOfExcel.setRsrp(pipeCloudDataOfCellVo.getLteRSRP());
        deviceInfoOfExcel.setSignalLevel(pipeCloudDataOfCellVo.getSignalLevel());
        deviceInfoOfExcel.setDate(netReportInfoOfImei.getUpTime());
    }

    @Override
    public List<DeviceNodeInfo> getDeviceNodeInfo(TopoSearchCondition topoSearchCondition) {
        String address = topoSearchCondition.getAddress();
        String cellId = dataAnalyseMapper.findCellIdByAddress(address);
        topoSearchCondition.setCellId(cellId);
        List<DeviceNodeInfo> deviceNodeInfos = deviceNodeDataMapper.findDeviceNodeInfo(topoSearchCondition.getImei(),
                topoSearchCondition.getCellId(),
                topoSearchCondition.getCurrentCellId());
        for (int i = 1; i <= deviceNodeInfos.size(); i++) {
            DeviceNodeInfo deviceNodeInfo = deviceNodeInfos.get(i-1);
            deviceNodeInfo.setNodeName("电表-" + i);
            deviceNodeInfo.setNodeType("电表");
            deviceNodeInfo.setNodeNameEn("Wattmeter-" + i);
            deviceNodeInfo.setNodeTypeEn("Wattmeter");
            if (StringUtils.equals(deviceNodeInfo.getNetMode(), NetMode.LTE.getMode()) || StringUtils.equals(deviceNodeInfo.getNetMode(), NetMode.GSM.getMode())) {
                if (deviceNodeInfo.getLteRsrq() != null && deviceNodeInfo.getLteSnr() != null) {
                    String netStatus = NetInfoUtil.getNetStatus(deviceNodeInfo.getLteRsrq(), deviceNodeInfo.getLteSnr());
                    deviceNodeInfo.setNetworkStatus(netStatus);
                }
            } else if (StringUtils.equals(deviceNodeInfo.getNetMode(),NetMode.WCDMA.getMode())) {
                if (deviceNodeInfo.getWcdRsrp() != null && deviceNodeInfo.getWcdSnr() != null) {
                    String netStatus = NetInfoUtil.getNetStatus(deviceNodeInfo.getWcdRsrp(), deviceNodeInfo.getWcdSnr());
                    deviceNodeInfo.setNetworkStatus(netStatus);
                }
            } else if (StringUtils.equals(deviceNodeInfo.getNetMode(), "UNKNOWN")) {
                deviceNodeInfo.setNetMode("N/A");
            } else {
                deviceNodeInfo.setNetMode(deviceNodeInfo.getNetMode());
            }
        }
        return deviceNodeInfos;
    }

    @Override
    public CellIdDeviceVo findCellIdDeviceMap(TopoSearchCondition topoSearchCondition) {
        List<CellIdDeviceImeiMapModel> cellIdDeviceImeiMapModelList = new ArrayList<>();
        List<CellInfoVo> cellInfoVoList = new ArrayList<>();
        List<DeviceNodeInfo> deviceNodeInfos = this.getDeviceNodeInfo(topoSearchCondition);
        if (CollectionUtils.isEmpty(deviceNodeInfos)) {
            log.error("未查询到设备节点信息");
            return null;
        }
        for (DeviceNodeInfo deviceNodeInfo: deviceNodeInfos) {
            // 封装小区设备拓扑关系
            CellIdDeviceImeiMapModel cellIdDeviceImeiMapModel = new CellIdDeviceImeiMapModel();
            cellIdDeviceImeiMapModel.setCurrentCellId(deviceNodeInfo.getCurrentCellId());
            cellIdDeviceImeiMapModel.setImei(deviceNodeInfo.getImei());
            cellIdDeviceImeiMapModelList.add(cellIdDeviceImeiMapModel);
            // 封装基站信息
            CellInfoVo cellInfoVo = new CellInfoVo();
            CellInfoVo cellInfoVo1;
            if (StringUtils.isNotEmpty(deviceNodeInfo.getCurrentCellId())) {
                cellInfoVo1 = deviceNodeDataMapper.findCellInfo(deviceNodeInfo.getCurrentCellId());
                if (cellInfoVo1 == null || cellInfoVo1.getRsrpValue() == null || cellInfoVo1.getSinrValue() == null) {
                    cellInfoVo.setStatus("UNKNOWN");
                } else {
                    String netStatus = NetInfoUtil.getNetStatus(cellInfoVo1.getRsrpValue(), cellInfoVo1.getSinrValue());
                    cellInfoVo.setStatus(netStatus);
                }
            }
            cellInfoVo.setCurrentCellId(deviceNodeInfo.getCurrentCellId());
            cellInfoVo.setOperator(deviceNodeInfo.getOperator());
            if (StringUtils.isNotEmpty(deviceNodeInfo.getOperator())) {
                String netOperator = NetInfoUtil.getNetOperator(deviceNodeInfo.getOperator());
                cellInfoVo.setOperator(netOperator);
            }

            if (StringUtils.isEmpty(deviceNodeInfo.getNetMode())) {
                cellInfoVo.setNetMode("UNKNOWN");
            } else {
                cellInfoVo.setNetMode(deviceNodeInfo.getNetMode());
            }
            if (StringUtils.isNotBlank(cellInfoVo.getCurrentCellId())) {
                cellInfoVoList.add(cellInfoVo);
            }
        }
        // 对基站列表去重
        List<CellInfoVo> cellInfoVos = cellInfoVoList.stream().distinct().collect(Collectors.toList());
        CellIdDeviceVo cellIdDeviceVo = new CellIdDeviceVo();
        cellIdDeviceVo.setCellInfo(cellInfoVos);
        cellIdDeviceVo.setNodeInfo(deviceNodeInfos);
        cellIdDeviceVo.setLinks(cellIdDeviceImeiMapModelList);
        return cellIdDeviceVo;
    }

    @Override
    public CellIdDeviceVo findCellIdDeviceMapV2(TopoSearchCondition topoSearchCondition) {
        List<CellIdDeviceImeiMapModel> cellIdDeviceImeiMapModelList = new ArrayList<>();
        List<DeviceNodeInfo> deviceNodeInfos = this.getDeviceNodeInfo(topoSearchCondition);
        if (CollectionUtils.isEmpty(deviceNodeInfos)) {
            log.error("未查询到设备节点信息");
            return null;
        }
        CellInfoVo cellInfoVo1;
        CellInfoVo cellInfoVo = new CellInfoVo();
        cellInfoVo1 = deviceNodeDataMapper.findCellInfo(topoSearchCondition.getCurrentCellId());
        if (cellInfoVo1 == null || cellInfoVo1.getRsrpValue() == null || cellInfoVo1.getSinrValue() == null) {
            cellInfoVo.setStatus("UNKNOWN");
        } else {
            String netStatus = NetInfoUtil.getNetStatus(cellInfoVo1.getRsrpValue(), cellInfoVo1.getSinrValue());
            cellInfoVo.setStatus(netStatus);
        }
        for (DeviceNodeInfo deviceNodeInfo: deviceNodeInfos) {
            if (StringUtils.isEmpty(deviceNodeInfo.getCurrentCellId())) {
                deviceNodeInfo.setCurrentCellId("-1");
            }
            // 封装小区设备拓扑关系
            CellIdDeviceImeiMapModel cellIdDeviceImeiMapModel = new CellIdDeviceImeiMapModel();
            cellIdDeviceImeiMapModel.setCurrentCellId(deviceNodeInfo.getCurrentCellId());
            cellIdDeviceImeiMapModel.setImei(deviceNodeInfo.getImei());
            cellIdDeviceImeiMapModelList.add(cellIdDeviceImeiMapModel);

            cellInfoVo.setCurrentCellId(deviceNodeInfo.getCurrentCellId());
            cellInfoVo.setOperator(deviceNodeInfo.getOperator());
            if (StringUtils.isNotEmpty(deviceNodeInfo.getOperator())) {
                String netOperator = NetInfoUtil.getNetOperator(deviceNodeInfo.getOperator());
                cellInfoVo.setOperator(netOperator);
            }
            if (StringUtils.isEmpty(deviceNodeInfo.getNetMode())) {
                cellInfoVo.setNetMode("UNKNOWN");
            } else {
                cellInfoVo.setNetMode(deviceNodeInfo.getNetMode());
            }
        }
        CellIdDeviceVo cellIdDeviceVo = new CellIdDeviceVo();
        cellIdDeviceVo.setCellInfoVo(cellInfoVo);
        cellIdDeviceVo.setNodeInfo(deviceNodeInfos);
        cellIdDeviceVo.setLinks(cellIdDeviceImeiMapModelList);
        return cellIdDeviceVo;
    }

    @Override
    public List<CellIdAndDeviceModel> findCellIdDeviceMapV3(TopoSearchCondition topoSearchCondition) {
        List<CellIdDeviceImeiMapModel> cellIdDeviceImeiMapModelList = new ArrayList<>();
        List<CellIdAndDeviceModel> allCellIdAndDeviceCount = this.findAllCellIdAndDeviceCount(topoSearchCondition);
        List<DeviceNodeInfo> deviceNodeInfos = this.getDeviceNodeInfo(topoSearchCondition);
        if (CollectionUtils.isEmpty(deviceNodeInfos)) {
            log.error("未查询到设备节点信息");
            return null;
        }
        for (DeviceNodeInfo deviceNodeInfo: deviceNodeInfos) {
            if (StringUtils.isEmpty(deviceNodeInfo.getCurrentCellId())) {
                deviceNodeInfo.setCurrentCellId("-1");
            }
            // 封装小区设备拓扑关系
            CellIdDeviceImeiMapModel cellIdDeviceImeiMapModel = new CellIdDeviceImeiMapModel();
            cellIdDeviceImeiMapModel.setCurrentCellId(deviceNodeInfo.getCurrentCellId());
            cellIdDeviceImeiMapModel.setImei(deviceNodeInfo.getImei());
            cellIdDeviceImeiMapModelList.add(cellIdDeviceImeiMapModel);
        }
        allCellIdAndDeviceCount.get(0).setNodeInfo(deviceNodeInfos);
        allCellIdAndDeviceCount.get(0).setLinks(cellIdDeviceImeiMapModelList);
        return allCellIdAndDeviceCount;
    }

    @Override
    public double findDelayIndex(String imei, int observationTime) {
        List<Integer> rxPacketsCounter = CollectionUtil.newArrayList();
        //List<DataPacket> rxPacketsCounters = dataAnalyseMapper.findRxPacketsCounter(DateUtil.today(), imei);
        List<DataPacket>  rxPacketsCounters = dataAnalyseMapper.findRxPacketsCounterByObT(observationTime, imei);
        if (rxPacketsCounters.isEmpty()){
            return -1;
        }
        for (DataPacket dataPacket : rxPacketsCounters){
            long dataPacketCounter = dataPacket.getDataPacketSum();
            rxPacketsCounter.add((int) dataPacketCounter);
        }
        return FeatureAnalysisUtil.delayIndex(rxPacketsCounter);
    }

    @Override
    public double findDataReceivingRate(String imei, int observationTime) {
        List<DataPacket>  rxPacketsCounters = dataAnalyseMapper.findRxPacketsCounterByObT(observationTime, imei);
        return FeatureAnalysisUtil.getDataReceivingRate(observationTime,rxPacketsCounters);
    }

    @Override
    public double findDataSendingRate(String imei, int observationTime) {
        List<DataPacket>  txPacketsCounters = dataAnalyseMapper.findTxPacketsCounterByObT(observationTime, imei);
        return FeatureAnalysisUtil.getDataSendingRate(observationTime,txPacketsCounters);
    }

    @Override
    public List<CapabilityIndexVo> findCapabilityIndexData(CapabilityIndexSearchCondition capabilityIndex) {
        if (capabilityIndex.getPageNum() != null || capabilityIndex.getPageSize() != null ) {
            PageHelper.startPage(capabilityIndex.getPageNum(), capabilityIndex.getPageSize());
        }
        List<CapabilityIndexVo> capabilityIndexVoList = dataAnalyseMapper.findCapabilityIndexData(capabilityIndex);
        return capabilityIndexVoList;
    }

    @Override
    public void exportCapabilityInfoList(CapabilityIndexSearchCondition searchCondition, HttpServletResponse response) {
        List<CapabilityIndexVo> capabilityIndexList = this.findCapabilityIndexData(searchCondition);
        try {
            ExcelUtil.export(response, "CapabilityInfoList", "设备性能信息", CapabilityIndexExcel.class, capabilityIndexList);
        } catch (Exception e) {
            log.error("导出失败！", e);
        }


    }

    @Override
    public boolean insertCapabilityIndexData(String imei) {
        if (StringUtils.isEmpty(imei)) {
            log.error("没有可用的imei号");
            return false;
        }
        CapabilityIndexModel capabilityIndexModel = new CapabilityIndexModel();
        // 从redis中获取阈值信息
        Map<String, String> redisMap = emqRedisDao.findConfig();
        if (CollectionUtils.isEmpty(redisMap)) {
            log.error("redis中暂无阈值信息");
            return false;
        }
        List<DataPacket> historyDataPackets = FeatureAnalysisUtil.statisticHostoryDataPacket(DateUtil.today(), imei);
        if (!CollectionUtils.isEmpty(historyDataPackets)) {
            long historyDataPacketSum = historyDataPackets.get(0).getDataPacketSum();
            capabilityIndexModel.setHistoryDataPackageNum(historyDataPacketSum);
        }
        List<DataPacket> currentDataPackets = FeatureAnalysisUtil.statisticCurrentDataPacket(imei);
        if (!CollectionUtils.isEmpty(currentDataPackets)) {
            long currentDataPacketSum = currentDataPackets.get(0).getDataPacketSum();
            capabilityIndexModel.setCurrentDataPackageNum(currentDataPacketSum);
        }
        // 延迟指数
        // observationTime观测周期暂定10，后续从配置信息中获取
        double delayIndex = this.findDelayIndex(imei, 20);
        capabilityIndexModel.setDelayIndex(delayIndex);
        // 数据接收率
        // observationTime观测周期暂定10，后续从配置信息中获取
        double dataReceivingRate = this.findDataReceivingRate(imei, 20);
        capabilityIndexModel.setReceivingRate(dataReceivingRate);
        // 数据发送率
        // observationTime观测周期暂定10，后续从配置信息中获取
        double dataSendingRate = this.findDataSendingRate(imei, 20);
        capabilityIndexModel.setSendingRate(dataSendingRate);
        // 性能指标数据与阈值判断
        handleCapabilityIndexData(redisMap, capabilityIndexModel);
        capabilityIndexModel.setImei(imei);
        capabilityIndexModel.setUpTime(DateUtil.date());
        int result = dataAnalyseMapper.insertCapabilityIndexData(capabilityIndexModel);
        if (result <= 0) {
            log.error("性质指标数据存储失败");
            return false;
        }
        log.info("性能指标数据存储成功");
        // 存储告警信息
        handleAlarmInfo(capabilityIndexModel);
        return true;
    }

    private void handleCapabilityIndexData(Map<String, String> redisMap, CapabilityIndexModel capabilityIndexModel) {
        try {
            if (redisMap.containsKey(CapabilityIndexConstant.HISTORY_DATA_PACKET_THRESHOLD)) {
                long historyDataPacketThreshold = Long.parseLong(redisMap.getOrDefault(CapabilityIndexConstant.HISTORY_DATA_PACKET_THRESHOLD, "0"));
                long historyDataPackageNum = capabilityIndexModel.getHistoryDataPackageNum();
                if (historyDataPackageNum >= historyDataPacketThreshold) {
                    log.info("历史周期数据包达到阈值");
                    capabilityIndexModel.setReachHistoryDataPackageNum(true);
                }
            }

            if (redisMap.containsKey(CapabilityIndexConstant.CURRENT_DATA_PACKET_THRESHOLD)) {
                long currentDataPacketThreshold = Long.parseLong(redisMap.getOrDefault(CapabilityIndexConstant.CURRENT_DATA_PACKET_THRESHOLD, "0"));
                long currentDataPackageNum = capabilityIndexModel.getCurrentDataPackageNum();
                if (currentDataPackageNum >= currentDataPacketThreshold ) {
                    log.info("当前周期数据包达到阈值");
                    capabilityIndexModel.setReachCurrentDataPackageNum(true);
                }
            }
            if (redisMap.containsKey(CapabilityIndexConstant.DATA_RECEIVE_RATE_THRESHOLD)) {
                double dataReceiveRateThreshold = Double.parseDouble(redisMap.getOrDefault(CapabilityIndexConstant.DATA_RECEIVE_RATE_THRESHOLD, "0.00"));
                double receivingRate = capabilityIndexModel.getReceivingRate();
                if (receivingRate >= dataReceiveRateThreshold) {
                    log.info("数据接收率达到阈值");
                    capabilityIndexModel.setReachReceivingRate(true);
                }
            }
            if (redisMap.containsKey(CapabilityIndexConstant.DATA_SEND_RATE_THRESHOLD)) {
                double dataSendRateThreshold = Double.parseDouble(redisMap.getOrDefault(CapabilityIndexConstant.DATA_SEND_RATE_THRESHOLD, "0.00"));
                double sendingRate = capabilityIndexModel.getSendingRate();
                if (sendingRate >= dataSendRateThreshold) {
                    log.info("数据发送率达到阈值");
                    capabilityIndexModel.setReachSendingRate(true);
                }
            }
            if (redisMap.containsKey(CapabilityIndexConstant.DELAY_INDEX_THRESHOLD)) {
                double delayIndexThreshold = Double.parseDouble(redisMap.getOrDefault(CapabilityIndexConstant.DELAY_INDEX_THRESHOLD, "0.00"));
                double delayIndex = capabilityIndexModel.getDelayIndex();
                if (delayIndex <= delayIndexThreshold) {
                    log.info("数据延迟指数达到阈值");
                    capabilityIndexModel.setReachDelayIndex(true);
                }
            }
        } catch (NumberFormatException e) {
            log.error("处理性能指标数据异常" , e);
        }
    }

    private void handleAlarmInfo(CapabilityIndexModel capabilityIndexModel) {
        List<AlarmInfoModel> alarmInfoModelList = new ArrayList<>();
        if (!capabilityIndexModel.isReachHistoryDataPackageNum()) {
            AlarmInfoModel alarmInfoModel = new AlarmInfoModel();
            alarmInfoModel.setImei(capabilityIndexModel.getImei());
            alarmInfoModel.setAlarmType(AlarmTypeConstant.HISTORY_DATA_PACKAGE_ALARM);
            alarmInfoModel.setUpTime(DateUtil.date());
            alarmInfoModelList.add(alarmInfoModel);
        }
        if (!capabilityIndexModel.isReachCurrentDataPackageNum()) {
            AlarmInfoModel alarmInfoModel = new AlarmInfoModel();
            alarmInfoModel.setImei(capabilityIndexModel.getImei());
            alarmInfoModel.setAlarmType(AlarmTypeConstant.CURRENT_DATA_PACKAGE_ALARM);
            alarmInfoModel.setUpTime(DateUtil.date());
            alarmInfoModelList.add(alarmInfoModel);
        }
        if (!capabilityIndexModel.isReachReceivingRate()) {
            AlarmInfoModel alarmInfoModel = new AlarmInfoModel();
            alarmInfoModel.setImei(capabilityIndexModel.getImei());
            alarmInfoModel.setAlarmType(AlarmTypeConstant.RECEIVING_RATE_ALARM);
            alarmInfoModel.setUpTime(DateUtil.date());
            alarmInfoModelList.add(alarmInfoModel);
        }
        if (!capabilityIndexModel.isReachSendingRate()) {
            AlarmInfoModel alarmInfoModel = new AlarmInfoModel();
            alarmInfoModel.setImei(capabilityIndexModel.getImei());
            alarmInfoModel.setAlarmType(AlarmTypeConstant.SENDING_RATE_ALARM);
            alarmInfoModel.setUpTime(DateUtil.date());
            alarmInfoModelList.add(alarmInfoModel);
        }
        if (!capabilityIndexModel.isReachDelayIndex()) {
            AlarmInfoModel alarmInfoModel = new AlarmInfoModel();
            alarmInfoModel.setImei(capabilityIndexModel.getImei());
            alarmInfoModel.setAlarmType(AlarmTypeConstant.DELAY_INDEX_ALARM);
            alarmInfoModel.setUpTime(DateUtil.date());
            alarmInfoModelList.add(alarmInfoModel);
        }
        if (CollectionUtils.isEmpty(alarmInfoModelList)) {
            log.info("暂无性能指标告警");
            return;
        }
        dataAnalyseMapper.batchInsertAlarmInfo(alarmInfoModelList);
        log.info("性能指标告警存储成功");
    }

    @Override
    public int insertPicConfig(PicConfigModel picConfigModel) {
        picConfigModel.setUpTime(new Date());
        return dataAnalyseMapper.isnertPicConfig(picConfigModel);
    }

    @Override
    public int updatePicConfig(PicConfigModel picConfigModel) {
        picConfigModel.setUpTime(new Date());
        return dataAnalyseMapper.updatePicConfig(picConfigModel);
    }

    @Override
    public PicConfigModel findPicConfig() {
        return dataAnalyseMapper.findPicConfig();
    }

    @Override
    public SimCardStatistic statisticSimCardInfo() {

        int simCardTotalNum = 0;
        int activeNum = 0;
        int todayOnlineNum = 0;
        int todayUsedNum = 0;
        int cmccCardNum = 0;
        int cuccCardNum = 0;
        int ctccCardNum = 0;
        int unkonwnNum = 0;
        double todayOnlineRate = 0;
        SimCardStatistic simCardStatistic = null;
        try {
            simCardStatistic = new SimCardStatistic();
            List<SimCardInfoModel> simCardInfoModels = dataAnalyseMapper.findSimCardInfoList(DateUtil.today());
            if (CollectionUtils.isEmpty(simCardInfoModels)) {
                log.error("暂无sim卡信息");
                return new SimCardStatistic();
            }
            for (SimCardInfoModel simCardInfo : simCardInfoModels) {
                if (StringUtils.isNotEmpty(simCardInfo.getImei())) {
                    simCardTotalNum++ ;
                }
                if (StringUtils.isNotEmpty(simCardInfo.getAuthCode())) {
                    activeNum++ ;
                }
                if (StringUtils.isNotEmpty(simCardInfo.getOperator()) && OperatorEnum.CMCC.getOperator().equals(simCardInfo.getOperator())) {
                    cmccCardNum++;
                } else if (StringUtils.isNotEmpty(simCardInfo.getOperator()) && OperatorEnum.CUCC.getOperator().equals(simCardInfo.getOperator())) {
                    cuccCardNum++;
                } else if (StringUtils.isNotEmpty(simCardInfo.getOperator()) && OperatorEnum.CTCC.getOperator().equals(simCardInfo.getOperator())) {
                    ctccCardNum++;
                } else {
                    unkonwnNum++;
                }
                if (simCardInfo.getOnlineNum() != null && simCardInfo.getOnlineNum() == 1) {
                    todayOnlineNum++;
                }
                if (simCardInfo.getDataNum() != null && simCardInfo.getDataNum() != 0) {
                    todayUsedNum++;
                }
            }
            todayOnlineRate = BigDecimal.valueOf(todayOnlineNum).divide(BigDecimal.valueOf(simCardTotalNum), 2, BigDecimal.ROUND_HALF_UP).doubleValue();
            simCardStatistic.setActiveNum(activeNum);
            simCardStatistic.setCmccCardNum(cmccCardNum);
            simCardStatistic.setCtccCardNum(ctccCardNum);
            simCardStatistic.setCuccCardNum(cuccCardNum);
            simCardStatistic.setSimCardTotalNum(simCardTotalNum);
            simCardStatistic.setTodayOnlineNum(todayOnlineNum);
            simCardStatistic.setTodayUsedNum(todayUsedNum);
            simCardStatistic.setTodayOnlineRate(todayOnlineRate);
        } catch (Exception e) {
            log.error("SIM卡使用情况统计失败");
        }
        return simCardStatistic;
    }

    @Override
    public AlarmOverviewVo findCurrentAlarmInfo() {
        return dataAnalyseMapper.findCurrentAlarmInfo();
    }

    @Override
    public AlarmOverviewVo findHistoryAlarmInfoOfDays(int dayNum){
        Date toDate = DateUtil.parse(DateUtil.today());
        Date fromDate = DateUtil.parse(DateUtil.offsetDay(toDate, dayNum + 1).toString());
        Date endOfNowDate = DateUtil.endOfDay(toDate);
        return dataAnalyseMapper.findHistoryAlarmInfoOfDays(fromDate, endOfNowDate);
    }

    @Override
    public List<CellIdAndDeviceModel> findAllCellIdAndDeviceCount(TopoSearchCondition topoSearchCondition) {
        List<CellIdAndDeviceModel> allCellIdAndDeviceCount = new ArrayList<>();
        try {
            allCellIdAndDeviceCount = deviceNodeDataMapper.findAllCellIdAndDeviceCount(topoSearchCondition.getCurrentCellId());
            if (CollectionUtil.isEmpty(allCellIdAndDeviceCount)) {
                log.info("暂无基站");
                return allCellIdAndDeviceCount;
            }
            for (CellIdAndDeviceModel cellIdAndDevice : allCellIdAndDeviceCount) {
                if (cellIdAndDevice.getDeviceCount() > 0) {
                    cellIdAndDevice.setDeviceExist(true);
                } else {
                    cellIdAndDevice.setDeviceExist(false);
                }
                cellIdAndDevice.setOperator(NetInfoUtil.getNetOperator(cellIdAndDevice.getOperator()));
                if (cellIdAndDevice.getRsrpValue() == null || cellIdAndDevice.getSinrValue() == null) {
                    cellIdAndDevice.setStatus("UNKNOWN");
                } else {
                    String netStatus = NetInfoUtil.getNetStatus(cellIdAndDevice.getRsrpValue(), cellIdAndDevice.getSinrValue());
                    cellIdAndDevice.setStatus(netStatus);
                }
            }
        } catch (Exception e) {
            log.error("查询基站及其设备异常");
        }
        return allCellIdAndDeviceCount;
    }


}
