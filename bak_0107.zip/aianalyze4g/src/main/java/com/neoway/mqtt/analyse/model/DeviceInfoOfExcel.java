package com.neoway.mqtt.analyse.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：设备信息导出实体
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/15 17:46
 */
@Data
public class DeviceInfoOfExcel implements Serializable {
    private static final long serialVersionUID = 7546541641629333630L;
    @ExcelProperty(value = {"日期", "日期"}, index = 0)
    private Date date;
    @ExcelProperty(value = {"基本信息", "设备序列号"}, index = 1)
    private String imei;
    @ExcelProperty(value = {"基本信息", "物理位置"}, index = 2)
    private String address;
    @ExcelProperty(value = {"基本信息", "经度"}, index = 3)
    private String longitude;
    @ExcelProperty(value = {"基本信息", "纬度"}, index = 4)
    private String latitude;
    @ExcelProperty(value = {"基本信息", "所属小区"}, index = 5)
    private String cellName;
    @ExcelProperty(value = {"SIM卡信息", "信号等级"}, index = 6)
    private String signalLevel;
    @ExcelProperty(value = {"模组信息", "模组软件版本号"}, index = 7)
    private String softwareVersion;
    @ExcelProperty(value = {"模组信息", "模组硬件版本号"}, index = 8)
    private String hardwareVersion;
    @ExcelProperty(value = {"模组信息", "模组型号"}, index = 9)
    private String modeType;
    @ExcelProperty(value = {"网络信息", "SINR(信噪比)"}, index = 10)
    private String sinr;
    @ExcelProperty(value = {"网络信息", "RSRP(参考信号接收功率)"}, index = 11)
    private String rsrp;
    @ExcelProperty(value = {"数据包平均延迟"}, index = 12)
    private Integer packagesDelay;
    @ExcelProperty(value = {"网络模式"}, index = 13)
    private String netMode;
    @ExcelProperty(value = {"跟踪区码"}, index = 14)
    private Integer lteTac;
    @ExcelProperty(value = {"物理小区id"}, index = 15)
    private Integer ltePci;
    @ExcelProperty(value = {"频点值"}, index = 16)
    private Integer lteArfcn;
    @ExcelProperty(value = {"拨号apn"}, index = 17)
    private String apn;
    @ExcelProperty(value = {"鉴权方式"}, index = 18)
    private String authType;
    @ExcelProperty(value = {"请求ip类型"}, index = 19)
    private String pdnType;
    @ExcelProperty(value = {"内部协议栈"}, index = 20)
    private String dataCellType;
    @ExcelProperty(value = {"sim卡号"}, index = 21)
    private String iccid;
    @ExcelProperty(value = {"工作电压"}, index = 22)
    private Integer workVot;
    @ExcelProperty(value = {"工作波特率"}, index = 23)
    private Integer workBps;
    @ExcelProperty(value = {"写卡次数"}, index = 24)
    private Integer writeSimCounter;
    @ExcelProperty(value = {"读卡次数"}, index = 25)
    private Integer readSimCounter;
    @ExcelProperty(value = {"小区切换次数"}, index = 26)
    private Integer cellHoCounter;
    @ExcelProperty(value = {"小区重选次数"}, index = 27)
    private Integer cellSelCounter;
    @ExcelProperty(value = {"邻区数量"}, index = 28)
    private Integer cellNeighborNumbers;
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = {"上报时间"}, index = 29)
    private Date upTime;
    @ExcelProperty(value = {"运营商"}, index = 30)
    private String operator;
}
