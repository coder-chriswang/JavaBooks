package com.neoway.mqtt.analyse.init;

import com.neoway.mqtt.analyse.mapper.DeviceManageMapper;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.vo.CellIdInfoVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 启动加载刷新redis
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/23 10:05
 */
@Slf4j
@Component
public class SynchronizationRunner implements ApplicationRunner {

    @Autowired
    private DeviceManageMapper deviceManageMapper;

    @Autowired
    private EmqRedisDao emqRedisDao;

    @Override
    public void run(ApplicationArguments applicationArguments) throws Exception {
       try {
           Map<String, String> cellIdInfo = emqRedisDao.findCellIdInfo();
           List<String> imeiList = emqRedisDao.findAllImei();
           if (CollectionUtils.isEmpty(cellIdInfo) || CollectionUtils.isEmpty(imeiList)){
               log.info("启动redis刷新cellId和gps信息");
               List<CellIdInfoVo> cellIdInfoList = deviceManageMapper.findCellIdInfo();
               List<String> allImei = deviceManageMapper.findAllImei();
               if (CollectionUtils.isEmpty(cellIdInfoList)){
                   log.info("数据库暂无cellId信息");
                   return;
               }
               Map<String, String> refreshMap = new HashMap<>(4);
               cellIdInfoList.forEach(ci -> refreshMap.put(ci.getCellAddress() + ci.getCellName(),ci.getCellId() + ";" + ci.getCellLocations() ));
               emqRedisDao.updateImei(allImei.toArray(new String[0]));
               emqRedisDao.updateCellIdInfo(refreshMap);
               log.info("cellId和gps信息redis刷新成功");
           }else {
               log.info("之前已完成初始化cellId和gps信息redis刷新！");
           }
       } catch (Exception e){
           log.error("启动刷新cellId和gps信息redis异常！", e);
       }
    }
}
