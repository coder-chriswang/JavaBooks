package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 * 描述：
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/21 10:53
 */
@Data
@ApiModel("模组诊断参数")
public class ModuleDiagnoseParam implements Serializable {
    private static final long serialVersionUID = 2941556229494542311L;

    @ApiModelProperty("0：远程诊断 1：远程配置")
    private int type;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("系统时间戳")
    private String time;

    @ApiModelProperty("诊断上报时长")
    private String duration;

    @ApiModelProperty("数据模型")
    private List<String> dataModelList;
}
