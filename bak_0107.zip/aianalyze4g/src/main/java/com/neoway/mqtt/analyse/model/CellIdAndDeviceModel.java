package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *  描述:当前基站与其设备数量实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/8/4 9:25
 */
@Data
@ApiModel("基站与设备拓扑")
public class CellIdAndDeviceModel implements Serializable {
    private static final long serialVersionUID = 1169336115069069556L;

    @ApiModelProperty("设备数量")
    private int deviceCount;

    @ApiModelProperty("基站id")
    private String currentCellId;

    @ApiModelProperty("运营商名称")
    private String operator;

    @ApiModelProperty("网络制式")
    private String netMode;

    @ApiModelProperty("是否存在设备")
    private boolean deviceExist;

    @ApiModelProperty("服务状态")
    private String status;

    private Double sinrValue;

    private Double rsrpValue;

    @ApiModelProperty("节点信息")
    private List<DeviceNodeInfo> nodeInfo;

    @ApiModelProperty("基站与设备的拓扑关系")
    private List<CellIdDeviceImeiMapModel> links;
}
