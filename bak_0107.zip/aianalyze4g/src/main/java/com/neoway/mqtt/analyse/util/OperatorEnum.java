package com.neoway.mqtt.analyse.util;

/**
 * <pre>
 * 描述：运营商分类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/22 17:53
 */
public enum OperatorEnum {
    /**
     * 中国移动
     */
    CMCC("46000,46002,46004,46007,46008","CMCC",1,"中国移动"),

    /**
     * 中国联通
     */
    CUCC("46001,46006,46009,46010","CUCC",2,"中国联通"),

    /**
     * 中国电信
     */
    CTCC("46003,46005,46011,46012,46013,46015","CTCC",3,"中国电信"),

    /**
     * 未知运营商
     */
    UNKNOWN("UNKNOWN","未知",0,"未知运营商");
    OperatorEnum(String plmn,String operator,int operatorValue,String chinaOperator) {
        this.plmn = plmn;
        this.operator = operator;
        this.operatorValue = operatorValue;
        this.chinaOperator = chinaOperator;
    }
    private String plmn;
    private String operator;
    private Integer operatorValue;
    private String chinaOperator;

    public String getPlmn() {
        return plmn;
    }

    public String getOperator() {
        return operator;
    }
    public Integer getOperatorValue() {
        return operatorValue;
    }

    public String getChinaOperator() {
        return chinaOperator;
    }
}
