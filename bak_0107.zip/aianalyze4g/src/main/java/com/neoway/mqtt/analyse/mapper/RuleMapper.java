package com.neoway.mqtt.analyse.mapper;


import com.neoway.mqtt.analyse.model.Rule;
import com.neoway.mqtt.analyse.model.RuleDesignFileParam;
import com.neoway.mqtt.analyse.model.RuleDesignProjectParam;
import com.neoway.mqtt.analyse.model.RuleParams;
import com.neoway.mqtt.analyse.vo.ProjectAndFileVo;
import com.neoway.mqtt.analyse.vo.RuleDesignFileVo;
import com.neoway.mqtt.analyse.vo.RuleDesignProjectVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述: RuleDao
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/10 13:56
 */
@Mapper
public interface RuleMapper {

    /**
     * 根据id查询规则
     * @param id 规则id
     * @return
     */
    Rule getById(@Param("id") Integer id);

    /**
     * 根据规则名称查询规则
     * @param name 规则名称
     * @return
     */
    Rule getByName(@Param("name") String name);

    /**
     * 添加规则
     * @param ruleParams
     * @return
     */
    Integer setRule(@Param("ruleParams") RuleParams ruleParams);

    /**
     * 获取规则列表
     * @param ruleParams
     * @return
     */
    List<Rule> getRuleList(@Param("ruleParams") RuleParams ruleParams);

    /**
     * 根据id删除规则
     * @param id
     * @return
     */
    Integer deleteRule(@Param("id") Integer id);

    /**
     * 修改规则
     * @param ruleParams
     * @return
     */
    Integer updateRule(@Param("ruleParams") RuleParams ruleParams);

    /**
     * 查询所有规则设计工程
     * @param projectParam
     * @return
     */
    List<RuleDesignProjectVo> findAllRuleProject(@Param("projectParam") RuleDesignProjectParam projectParam);

    /**
     * 创建工程数据
     * @param projectParam
     * @return
     */
    int createRuleDesignProject(@Param("projectParam") RuleDesignProjectParam projectParam);

    /**
     * 根据id删除工程目录
     * @param id
     */
    void deleteRuleDesignProject(String id);

    /**
     * 根据id修改工程状态
     * @param projectParam
     * @return
     */
    int updateRuleDesignProjectStatus(@Param("projectParam") RuleDesignProjectParam projectParam);

    /**
     * 根据id修改工程状态
     * @param id
     * @return
     */
    RuleDesignProjectVo findRuleDesignProjectDetail(String id);

    /**
     * 存储规则设计文件
     * @param fileParam
     * @return
     */
    int createRuleDesignFile(@Param("fileParam") RuleDesignFileParam fileParam);

    /**
     * 查询父文件夹
     * @param parentName
     * @return
     */
    String findParentIdByParentName(String parentName);

    /**
     * 查询文件目录与文件
     * @param projectName
     * @return
     */
    List<ProjectAndFileVo> findProjectAndFile(String projectName);

    /**
     * 存贮文件内容
     * @param fileParam
     * @return
     */
    int writeFileContent(@Param("fileParam") RuleDesignFileParam fileParam);

    /**
     * 通过文件名查询文件
     * @param file
     * @param parentPath
     * @return
     */
    RuleDesignFileVo findFileByFileName(@Param("file") String file, @Param("parentPath") String parentPath);

    /**
     * 通过文件id查询文件
     * @param id
     * @return
     */
    RuleDesignFileVo findFileByFileId(@Param("id") String id);

    /**
     * 根据id查询规则
     * @param id 规则id
     * @return
     */
    Rule findRuleContentById(@Param("id") Integer id);

    /**
     * 通过文件名及包名查询规则
     * @param ruleFileId
     * @return
     */
    Rule findRuleByFileName(String ruleFileId);

    /**
     * 通过id更新文件信息
     * @param fileParam
     * @return
     */
    int updateRuleName(@Param("fileParam") RuleDesignFileParam fileParam);

}
