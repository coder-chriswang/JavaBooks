package com.neoway.mqtt.analyse.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 性能指标实体类(导出)
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/9/30 9:31
 */
@Data
@ContentRowHeight(15)
@HeadRowHeight(25)
@ColumnWidth(30)
public class CapabilityIndexExcel implements Serializable {

    private static final long serialVersionUID = -8672121235789828710L;

    @ExcelProperty(value = {"设备序列号"}, index = 0)
    private String imei;

    @ExcelProperty(value = {"过去一周数据包（个）"}, index = 1)
    private long historyDataPackageNum;

    /*@ApiModelProperty("当前周期数据包--指当天")
    private long currentDataPackageNum;*/

    @ExcelProperty(value = {"数据接收率"}, index = 2)
    private double receivingRate;

    @ExcelProperty(value = {"数据发送率"}, index = 3)
    private double sendingRate;

    @ExcelProperty(value = {"数据传输延时指数（秒）"}, index = 4)
    private double delayIndex;

    @ExcelProperty(value = {"RSRQ（dBm）"}, index = 5)
    private Double rsrqValue;

    @ExcelProperty(value = {"RSRP（dBm）"}, index = 6)
    private Double rsrpValue;

    @ExcelProperty(value = {"SINR（dBm）"}, index = 7)
    private Double sinrValue;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ExcelProperty(value = {"上报时间"}, index = 8)
    private Date upTime;
}
