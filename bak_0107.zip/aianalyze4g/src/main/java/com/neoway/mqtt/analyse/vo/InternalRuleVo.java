package com.neoway.mqtt.analyse.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * <pre>
 *  描述: 内置规则vo
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/8/5 16:37
 */
@Data
@ApiModel("内置规则信息")
public class InternalRuleVo implements Serializable {
    private static final long serialVersionUID = -330486933508937347L;

    @ApiModelProperty("内置规则内容")
    private String ruleContent;

    @ApiModelProperty("内置规则路径")
    private String rulePath;

    @ApiModelProperty("父文件夹")
    private String parentFilePackage;

    @ApiModelProperty("文件名称")
    private String fileName;

    private Map<String, String> fileMap;
}
