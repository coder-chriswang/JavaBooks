package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：模组信息
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/8/24 17:12
 */
@Data
public class ModuleInfo implements Serializable {

    private static final long serialVersionUID = 6108657399386883828L;

    /**
     * 厂商信息
     */
    private String manufacturerInfo;

    /**
     * 模组型号
     */
    private String modeType;

    /**
     * 版本
     */
    private String version;

    private String status;
}
