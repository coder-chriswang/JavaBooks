ALTER TABLE `tbl_rule` ADD `project_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '所属工程';
ALTER TABLE `tbl_rule_design_file` ADD  `description` longtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '规则文件描述';
ALTER TABLE `tbl_rule` ADD `rule_file_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '规则文件Id';
