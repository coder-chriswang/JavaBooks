ALTER TABLE `tbl_device_alarm_data` ADD `alarm_origin` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 0 COMMENT '告警来源，平台、设备';
ALTER TABLE `tbl_device_alarm_data` ADD `alarm_reason` LONGTEXT CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警原因';
ALTER TABLE `tbl_device_alarm_data` ADD `alarm_appearance` LONGTEXT CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警现象';
ALTER TABLE `tbl_device_alarm_data` ADD `alarm_advice` LONGTEXT CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '告警建议';


-- ----------------------------
-- Table structure for tbl_device_dispatch_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_dispatch_data`;
CREATE TABLE `tbl_device_dispatch_data`  (
  `id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '告警id',
  `imei` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '设备唯一标识imei号',
  `identification` tinyint(2) DEFAULT 0 COMMENT '工单处理标识，0表示未处理，1表示已处理',
  `handler_name` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '处理人姓名',
  `dispatch_time` datetime(0) DEFAULT NULL COMMENT '派单时间',
  `completion_time` datetime(0) DEFAULT NULL COMMENT '完成时间',
  `alarm_type` tinyint(2) DEFAULT 0 COMMENT '告警类型，0表示离线告警',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------
-- Table structure for tbl_rule
-- ----------------------------
DROP TABLE IF EXISTS `tbl_rule`;
CREATE TABLE `tbl_rule`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rule` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `create_time` timestamp(0) DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp(0) DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `visible` int(11) DEFAULT 1 COMMENT '0表示不可见，1表示可见',
  `status` tinyint(2) DEFAULT 0 COMMENT '0表示停用，1表示启用',
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '规则描述',
  `type` tinyint(2) DEFAULT 0 COMMENT '0表示系统，1表示用户',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `name`(`name`) USING BTREE COMMENT '规则名称'
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `tbl_rule`(`name`, `rule`, `create_time`, `update_time`, `visible`, `status`, `description`, `type`) VALUES ('告警规则01', 'package com.neoway.mqtt.analyse;\r\nimport com.neoway.mqtt.analyse.bean.AlarmInfo;\r\nrule \"2\"\r\n    when\r\n        $a : AlarmInfo(alarmType == 2);\r\n    then\r\n        System.out.println(\"中等告警！\");\r\nend', '2020-07-10 17:15:19', '2020-07-10 17:16:59', 1, 0, '当告警类型为2时，输出相关信息', 0);
INSERT INTO `tbl_rule`(`name`, `rule`, `create_time`, `update_time`, `visible`, `status`, `description`, `type`) VALUES ('告警规则02', 'package com.neoway.ruleengine;\r\nimport com.neoway.ruleengine.bean.AlarmInfo;\r\nrule \"2\"\r\n    when\r\n        $a : AlarmInfo(alarmType == 1);\r\n    then\r\n        System.out.println(\"这是一条严重告警信息！\");\r\nend\r\n\r\nquery \"alarmInfo\"\r\n    alarmInfo : AlarmInfo( alarmType > 0 )\r\nend', '2020-07-10 17:00:45', '2020-07-10 17:15:22', 1, 1, '当告警类型为1时，输出有关信息；并查询条件的告警信息', 0);
INSERT INTO `tbl_rule`(`name`, `rule`, `create_time`, `update_time`, `visible`, `status`, `description`, `type`) VALUES ('告警规则03', 'package com.neoway.ruleengine;\r\nimport com.neoway.ruleengine.bean.AlarmInfo;\r\nrule \"1\"\r\n	when\r\n        $a : AlarmInfo(alarmType == 1);\r\n    then\r\n		System.out.println(\"neoway chris\");\r\n		$a.setAlarmDesc(\"非常严重的告警!\");\r\n		retract($a)\r\nend', '2020-06-10 10:43:14', '2020-07-10 16:18:41', 1, 1, '当告警类型为1时，更新告警描述', 0);


-- ----------------------------
-- Table structure for tbl_package_data_info
-- ----------------------------
DROP TABLE IF EXISTS `tbl_package_data_info`;
CREATE TABLE `tbl_package_data_info`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id标识',
  `imei` varchar(36) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '设备唯一标识',
  `performance_type` int(2) DEFAULT NULL COMMENT '数据来源类型（0代表上行or 1代表下行）',
  `package_data` longtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '数据内容',
  `occurrence_time` datetime(0) DEFAULT NULL COMMENT '触发时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `imei`(`imei`) USING BTREE COMMENT 'IMEI',
  INDEX `search_time`(`occurrence_time`) USING BTREE COMMENT '时间条件'
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;