SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tbl_rule_design_file
-- ----------------------------
DROP TABLE IF EXISTS `tbl_rule_design_file`;
CREATE TABLE `tbl_rule_design_file`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键Id',
  `pid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '文件夹id',
  `file_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '文件名称',
  `file_suffix` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '文件后缀',
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '文件路径',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '文件内容',
  `create_time` datetime(0) DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `id`(`id`) USING BTREE COMMENT '主键id'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tbl_rule_design_project
-- ----------------------------
DROP TABLE IF EXISTS `tbl_rule_design_project`;
CREATE TABLE `tbl_rule_design_project`  (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键id',
  `pid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '父id',
  `project_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '工程名称',
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '工程路径',
  `description` longtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '工程描述',
  `status` tinyint(2) DEFAULT 0 COMMENT '状态：0未发布、1已发布',
  `create_time` datetime(0) DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `update_time`(`update_time`) USING BTREE COMMENT '更新时间',
  INDEX `pid`(`pid`) USING BTREE COMMENT '父id'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tbl_api_doc
-- ----------------------------
DROP TABLE IF EXISTS `tbl_api_doc`;
CREATE TABLE `tbl_api_doc`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'Api标题',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT ' 路由地址',
  `request` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '请求方式：POST/GET',
  `param` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '请求参数',
  `status` tinyint(2) NOT NULL DEFAULT 0 COMMENT '是否开放：0开放、1关闭',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '描述',
  `create_time` timestamp(0) DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` timestamp(0) DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `id`(`id`) USING BTREE COMMENT 'id',
  INDEX `update_time`(`update_time`) USING BTREE COMMENT '更新时间'
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_api_doc
-- ----------------------------
INSERT INTO `tbl_api_doc` (`title`, `url`, `request`, `param`, `status`, `description`, `create_time`, `update_time`) VALUES ('删除设备', '/channel/sqlmode/v1/data/device/deleteDeviceInfo', 'GET', 'imei', 0, '通过imei号删除设备信息', '2020-07-20 10:25:18', '2020-07-20 10:25:18');
INSERT INTO `tbl_api_doc` (`title`, `url`, `request`, `param`, `status`, `description`, `create_time`, `update_time`) VALUES ('更新设备', '/channel/sqlmode/v1/data/device/updateDeviceInfo', 'POST', 'imei,cellName,cellAddress', 0, '更新设备信息', '2020-07-20 10:25:29', '2020-07-20 10:25:29');
INSERT INTO `tbl_api_doc` (`title`, `url`, `request`, `param`, `status`, `description`, `create_time`, `update_time`) VALUES ('统计设备数据', '/channel/sqlmode/v1/data/analyse/findAllDeviceData', 'GET', NULL, 0, '统计当日设备、网络、SIM的运行情况', '2020-07-20 10:25:37', '2020-07-20 10:25:37');
INSERT INTO `tbl_api_doc` (`title`, `url`, `request`, `param`, `status`, `description`, `create_time`, `update_time`) VALUES ('查看拓扑信息', '/channel/sqlmode/v1/data/analyse/findCellDeviceTopo', 'POST', 'imei, address', 0, '查看基站与设备的拓扑关系', '2020-07-20 10:26:00', '2020-07-20 10:26:00');
INSERT INTO `tbl_api_doc` (`title`, `url`, `request`, `param`, `status`, `description`, `create_time`, `update_time`) VALUES ('大屏展示', '/channel/sqlmode/v1/data/analyse/dataInfo', 'POST', 'imei, address,operator,signalLevel', 0, '查询展示数据', '2020-07-20 10:27:16', '2020-07-20 10:27:16');
INSERT INTO `tbl_api_doc` (`title`, `url`, `request`, `param`, `status`, `description`, `create_time`, `update_time`) VALUES ('查询设备参数', '/channel/sqlmode/v1/data/analyse/deviceInfoByImei/{imei}', 'GET', 'imei', 0, '通过Imei号查询设备参数信息', '2020-07-22 18:16:37', '2020-07-22 18:16:37');

SET FOREIGN_KEY_CHECKS = 1;