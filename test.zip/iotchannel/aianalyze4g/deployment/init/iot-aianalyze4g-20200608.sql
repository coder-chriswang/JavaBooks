
/*
 Navicat Premium Data Transfer

 Source Server         : 4g管道云
 Source Server Type    : MySQL
 Source Server Version : 50727
 Source Host           : 192.168.69.11:9000
 Source Schema         : ai4gdb

 Target Server Type    : MySQL
 Target Server Version : 50727
 File Encoding         : 65001

 Date: 15/06/2020 11:47:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tbl_device_alarm_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_alarm_data`;
CREATE TABLE `tbl_device_alarm_data`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `imei` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'imei号',
  `alarm_type` tinyint(2) DEFAULT NULL COMMENT '0表示离线告警',
  `up_time` datetime(0) DEFAULT NULL COMMENT '告警上报时间',
  `identification` tinyint(2) DEFAULT 0 COMMENT '0表示未处理，1表示已处理',
  `complation_time` datetime(0) DEFAULT NULL COMMENT '告警处理完成时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------
-- Table structure for tbl_device_cdma_neighbor_report_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_cdma_neighbor_report_data`;
CREATE TABLE `tbl_device_cdma_neighbor_report_data`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `basic_data_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '基础数据上报id',
  `cdma_channel` int(11) DEFAULT NULL COMMENT '频点',
  `cdma_pn` int(11) DEFAULT NULL COMMENT '物理小区id',
  `cdma_rssi` int(11) DEFAULT NULL COMMENT '信号强度',
  `cdma_ecio` int(11) DEFAULT NULL COMMENT '能量密度比值',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `basic_data_id`(`basic_data_id`) USING BTREE COMMENT '基础数据上报id'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_device_gsm_neighbor_report_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_gsm_neighbor_report_data`;
CREATE TABLE `tbl_device_gsm_neighbor_report_data`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `basic_data_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '基础数据上报id',
  `gsm_bsci` int(11) DEFAULT NULL COMMENT 'BSCI',
  `gsm_arfcn` int(11) DEFAULT NULL COMMENT '频点',
  `gsm_rssi` int(11) DEFAULT NULL COMMENT '接收信号强度',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `basic_data_id`(`basic_data_id`) USING BTREE COMMENT '基础数据上报id'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_device_info
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_info`;
CREATE TABLE `tbl_device_info`  (
  `imei` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '设备号',
  `auth_code` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '鉴权码',
  `operator` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商',
  `cell_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小区id',
  `cell_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小区名称',
  `cell_locations` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小区gps',
  `cell_address` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小区物理地址',
  `online` tinyint(2) DEFAULT 0 COMMENT '在线状态，0离线',
  `up_time` datetime(0) DEFAULT NULL COMMENT '上报数据时间',
  `create_time` datetime(0) DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`imei`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_device_lte_neighbor_report_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_lte_neighbor_report_data`;
CREATE TABLE `tbl_device_lte_neighbor_report_data`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `basic_data_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '关联上报数据id',
  `pci` int(11) DEFAULT NULL COMMENT '小区物理id',
  `arfcn` int(11) DEFAULT NULL COMMENT '频点值',
  `lte_rsrp` int(11) DEFAULT NULL COMMENT 'lte信号强度',
  `lte_rsrq` int(11) DEFAULT NULL COMMENT 'lte信号功率',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `basic_data_id`(`basic_data_id`) USING BTREE COMMENT '基础数据上报id'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_device_report_basic_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_report_basic_data`;
CREATE TABLE `tbl_device_report_basic_data`  (
  `id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '主键',
  `imei` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'imei号',
  `cell_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '小区物理id',
  `net_mode` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '网络模式',
  `mode_type` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '模组型号',
  `software_version` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '模组软件版本型号',
  `hardware_version` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '模组硬件版本型号',
  `lte_tac` int(11) DEFAULT NULL COMMENT '跟踪区码',
  `lte_pci` int(11) DEFAULT NULL COMMENT '物理小区id',
  `lte_arfcn` int(11) DEFAULT NULL COMMENT '频点值',
  `wcdma_ura` int(11) DEFAULT NULL COMMENT '服务区',
  `wcdma_psc` int(11) DEFAULT NULL COMMENT '主扰码',
  `wcdma_arfcn` int(11) DEFAULT NULL COMMENT '频点值',
  `cdma_channel` int(11) DEFAULT NULL COMMENT '频点',
  `cdma_pn` int(11) DEFAULT NULL COMMENT '扰码',
  `cdma_sid_nid` int(11) DEFAULT NULL COMMENT '系统网络识别码',
  `gsm_lac` int(11) DEFAULT NULL COMMENT '位置区码',
  `gsm_bsci` int(11) DEFAULT NULL COMMENT '基站识别码',
  `gsm_arfcn` int(11) DEFAULT NULL COMMENT '频点',
  `lte_rsrp_min` int(11) DEFAULT NULL COMMENT '最小lte信号强度',
  `lte_rsrp_aver` double(11, 0) DEFAULT NULL COMMENT '平均lte信号强度',
  `lte_rsrp_max` int(11) DEFAULT NULL COMMENT '最大lte信号强度',
  `lte_rsrq_min` int(11) DEFAULT NULL COMMENT '最小lte信号功率',
  `lte_rsrq_aver` double(11, 0) DEFAULT NULL COMMENT '平均lte信号功率',
  `lte_rsrq_max` int(11) DEFAULT NULL COMMENT '最大lte信号功率',
  `lte_sinr_min` int(11) DEFAULT NULL COMMENT '最小lte信噪比',
  `lte_sinr_aver` double(11, 0) DEFAULT NULL COMMENT '平均lte信噪比',
  `lte_sinr_max` int(11) DEFAULT NULL COMMENT '最大lte信噪比',
  `wcdma_rscp_min` int(11) DEFAULT NULL COMMENT '最小wcdma信号强度',
  `wcdma_rscp_aver` double(11, 0) DEFAULT NULL COMMENT '平均wcdma信号强度',
  `wcdma_rscp_max` int(11) DEFAULT NULL COMMENT '最大wcdma信号强度',
  `wcdma_ecno_min` int(11) DEFAULT NULL COMMENT '最小wcdma码片能量与总干扰能量的密度比值',
  `wcdma_ecno_aver` double(11, 0) DEFAULT NULL COMMENT '平均wcdma码片能量与总干扰能量的密度比值',
  `wcdma_ecno_max` int(11) DEFAULT NULL COMMENT '最大wcdma码片能量与总干扰能量的密度比值',
  `wcdma_sinr_min` int(11) DEFAULT NULL COMMENT '最小wcdma信噪比',
  `wcdma_sinr_aver` double(11, 0) DEFAULT NULL COMMENT '平均wcdma信噪比',
  `wcdma_sinr_max` int(11) DEFAULT NULL COMMENT '最大wcdma信噪比',
  `cdma_rssi` int(11) DEFAULT NULL COMMENT 'cdma接收信号强度',
  `cdma_ecio` int(11) DEFAULT NULL COMMENT 'cdma码片能量与总干扰能量的密度比值',
  `gsm_rssi` int(11) DEFAULT NULL COMMENT 'gsm接收信号强度',
  `current_cell_id` int(11) DEFAULT NULL COMMENT '当前小区id',
  `plmn` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商plmn',
  `apn` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '拨号apn,内部与外部协议栈同时上报，用逗号分隔',
  `auth_type` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '鉴权方式，内部与外部协议栈同时上报，用逗号分隔',
  `pdn_type` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '请求IP类型，内部与外部协议栈同时上报，用逗号分隔',
  `data_cell_type` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '内部协议栈，内部与外部协议栈同时上报，用逗号分隔',
  `ipv4` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'ipv4地址，内部与外部协议栈同时上报，用逗号分隔',
  `ipv6` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'ipv6地址，内部与外部协议栈同时上报，用逗号分隔',
  `iccid` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'SIM卡序列号',
  `work_vot` int(11) DEFAULT NULL COMMENT '工作电压',
  `work_bps` int(11) DEFAULT NULL COMMENT '工作波特率',
  `write_sim_counter` int(11) DEFAULT NULL COMMENT '写卡次数',
  `read_sim_counter` int(11) DEFAULT NULL COMMENT '读卡次数',
  `cell_ho_counter` int(11) DEFAULT NULL COMMENT '切换次数',
  `cell_sel_counter` int(11) DEFAULT NULL COMMENT '重选次数',
  `cell_neighbor_numbers` int(11) DEFAULT NULL COMMENT '邻区个数',
  `mm_rej_value` int(11) DEFAULT NULL COMMENT '失败码',
  `gmm_rej_value` int(11) DEFAULT NULL COMMENT '失败码',
  `sm_rej_value` int(11) DEFAULT NULL COMMENT '失败码',
  `emm_rej_value` int(11) DEFAULT NULL COMMENT '失败码',
  `esm_rej_value` int(11) DEFAULT NULL COMMENT '失败码',
  `packets_rx_counter` int(11) DEFAULT NULL COMMENT '周期内Rx流量统计',
  `packets_tx_counter` int(11) DEFAULT NULL COMMENT '周期内Tx流量统计',
  `packets_loss_counter` int(11) DEFAULT NULL COMMENT '周期内误包数',
  `up_time` datetime(0) DEFAULT NULL COMMENT '上报时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `imei`(`imei`) USING BTREE COMMENT 'imei号'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_device_wcdma_neighbor_report_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_wcdma_neighbor_report_data`;
CREATE TABLE `tbl_device_wcdma_neighbor_report_data`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `basic_data_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '关联上报数据id',
  `wcdma_psc` int(11) DEFAULT NULL COMMENT '小区物理id',
  `wcdma_arfcn` int(11) DEFAULT NULL COMMENT '频点',
  `wcdma_rscp` int(11) DEFAULT NULL COMMENT '信号强度',
  `wcdma_ecno` int(11) DEFAULT NULL COMMENT '能量密度比值',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `basic_data_id`(`basic_data_id`) USING BTREE COMMENT '基础数据上报id'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_device_operator_net_scan_info
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_operator_net_scan_info`;
CREATE TABLE `tbl_device_operator_net_scan_info`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `imei` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'imei号',
  `current_sim` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '当前运营商',
  `operator_one` int(11) DEFAULT NULL COMMENT '运营商1',
  `operator_one_cell1` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商1信号最好小区',
  `operator_one_rsrp1` int(11) DEFAULT NULL COMMENT '运营商1信号最强的信号强度',
  `operator_one_sinr1` int(11) DEFAULT NULL COMMENT '运营商1信号最好的信噪比',
  `operator_one_cell2` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商1信号次好小区',
  `operator_one_rsrp2` int(11) DEFAULT NULL COMMENT '运营商1信号次强的信号强度',
  `operator_one_sinr2` int(11) DEFAULT NULL COMMENT '运营商1信号次好的信噪比',
  `operator_one_cell3` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商1信号最好的三个小区',
  `operator_one_rsrp3` int(11) DEFAULT NULL COMMENT '运营商1信号最强的三个信号强度',
  `operator_one_sinr3` int(11) DEFAULT NULL COMMENT '运营商1信号最好的三个信噪比',
  `operator_two` int(11) DEFAULT NULL COMMENT '运营商2',
  `operator_two_cell1` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商2信号最好小区',
  `operator_two_rsrp1` int(11) DEFAULT NULL COMMENT '运营商2信号最强的信号强度',
  `operator_two_sinr1` int(11) DEFAULT NULL COMMENT '运营商2信号最好的信噪比',
  `operator_two_cell2` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商2信号次好小区',
  `operator_two_rsrp2` int(11) DEFAULT NULL COMMENT '运营商2信号次强的信号强度',
  `operator_two_sinr2` int(11) DEFAULT NULL COMMENT '运营商2信号次好的信噪比',
  `operator_two_cell3` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '运营商2信号最好的三个小区',
  `operator_two_rsrp3` int(11) DEFAULT NULL COMMENT '运营商2信号最强的三个信号强度',
  `operator_two_sinr3` int(11) DEFAULT NULL COMMENT '运营商2信号最好的三个信噪比',
  `up_time` datetime(0) DEFAULT NULL COMMENT '上报时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `imei`(`imei`) USING BTREE COMMENT 'imei号'
) ENGINE = InnoDB AUTO_INCREMENT = 74 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_device_config
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_config`;
CREATE TABLE `tbl_device_config`  (
  `observation_time` int(11) DEFAULT 20 COMMENT '观测性能周期数',
  `history_data_packet_threshold` int(11) DEFAULT 400 COMMENT '历史数据包阈值',
  `data_receive_rate_threshold` double(11, 2) DEFAULT 0.50 COMMENT '数据接收率阈值',
  `data_send_rate_threshold` double(11, 2) DEFAULT 0.50 COMMENT '数据发送率阈值',
  `delay_index_threshold` double(11, 2) DEFAULT 0.50 COMMENT '延时指数阈值',
  `create_time` datetime(0) DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(0) DEFAULT NULL COMMENT '更新时间'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_device_config
-- ----------------------------
INSERT INTO `tbl_device_config` VALUES (15, 300, 0.60, 0.99, 0.01, '2020-07-01 15:44:50', '2020-07-03 16:22:39');

-- ----------------------------
-- Table structure for tbl_device_capability_index_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_device_capability_index_data`;
CREATE TABLE `tbl_device_capability_index_data`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `imei` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '设备序列号',
  `history_data_package_num` int(11) DEFAULT 0 COMMENT '历史周期数据包',
  `is_reach_history_data_package_num` tinyint(2) DEFAULT 0 COMMENT '历史数据包是否达到阈值 0未达到；1达到',
  `current_data_package_num` int(11) DEFAULT 0 COMMENT '当前周期数据包',
  `is_reach_current_data_package_num` tinyint(2) DEFAULT 0 COMMENT '当前周期数据包是否达到阈值 0未达到；1达到',
  `receiving_rate` double(11, 2) DEFAULT 0.00 COMMENT '数据接收率',
  `is_reach_receiving_rate` tinyint(2) DEFAULT 0 COMMENT '数据接受率是否达到阈值  0未达到；1达到',
  `sending_rate` double(11, 2) DEFAULT 0.00 COMMENT '数据发送率',
  `is_reach_sending_rate` tinyint(2) DEFAULT 0 COMMENT '数据发送率是否达到阈值  0未达到；1达到',
  `delay_index` double(11, 2) DEFAULT 0.00 COMMENT '延迟指数',
  `is_reach_delay_index` tinyint(2) DEFAULT 0 COMMENT '延迟指数是否达到阈值 0未达到；1达到',
  `up_time` datetime(0) DEFAULT NULL COMMENT '上报时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `imei`(`imei`) USING BTREE COMMENT '设备序列号'
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tbl_topo_pic_config
-- ----------------------------
DROP TABLE IF EXISTS `tbl_topo_pic_config`;
CREATE TABLE `tbl_topo_pic_config`  (
  `pic` tinyint(2) DEFAULT 1 COMMENT '图片编号1,2,3',
  `locking` tinyint(2) DEFAULT 1 COMMENT '0解锁，1锁定',
  `extend` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '扩展字段',
  `up_time` datetime(0) DEFAULT NULL COMMENT '时间'
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_topo_pic_config
-- ----------------------------
INSERT INTO `tbl_topo_pic_config` VALUES (2, 1, NULL, '2020-07-04 15:40:27');

SET FOREIGN_KEY_CHECKS = 1;

