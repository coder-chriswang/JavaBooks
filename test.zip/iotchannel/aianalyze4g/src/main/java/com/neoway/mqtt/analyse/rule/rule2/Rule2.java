package com.neoway.mqtt.analyse.rule.rule2;

import com.neoway.mqtt.analyse.bean.AlarmInfo;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

/**
 * 使用kmodule的方式调用drools
 * /resources/META-INF/kmodule.xml
 */
public class Rule2 {
    public static void main(final String[] args) {
        KieContainer kc = KieServices.Factory.get().getKieClasspathContainer();
        execute(kc);
    }

    private static void execute(KieContainer kc) {
        KieSession kiesession = kc.newKieSession("rule2_ksession");

        AlarmInfo a1 = new AlarmInfo(1, "严重的告警");
        AlarmInfo a2 = new AlarmInfo(2, "次要的告警");

        kiesession.insert(a1);
        kiesession.insert(a2);

        kiesession.fireAllRules();

        kiesession.dispose();
    }
}
