package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：某段时间内的运营商的信号
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/15 11:38
 */
@Data
@ApiModel(value = "某段时间内的运营商的信号")
public class NetSignalOfTime implements Serializable {
    private static final long serialVersionUID = -2043847991061647973L;

    @ApiModelProperty("该时段内设备RSRP平均值")
    private Double rsrpValue;

    @ApiModelProperty("该时段内设备SNR平均值")
    private Double snrValue;

    @ApiModelProperty("信号等级")
    private String signalLevel;

    @ApiModelProperty("信号质量")
    private int signalValue;
}
