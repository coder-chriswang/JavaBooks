package com.neoway.mqtt.analyse.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * <pre>
 *  描述: 告警信息实体类
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/23 9:39
 */
@Data
@ApiModel("告警信息model")
public class AlarmInfo {

    @ApiModelProperty(value = "告警编号")
    private int id;

    @ApiModelProperty(value = "设备imei号",example = "865192040629734")
    private String imei;

    @ApiModelProperty(value = "告警类型,0表示离线告警",example = "0")
    private int alarmType;

    @ApiModelProperty(value = "设备所在小区地址信息",example = "陕西省西安市雁塔区锦业路88号满堂悦MOMA")
    private String cellAddress;

    @ApiModelProperty(value = "告警来源", example = "0:平台")
    private int alarmOrigin;

    @ApiModelProperty(value = "告警原因")
    private String alarmReason;

    @ApiModelProperty(value = "告警现象")
    private String alarmAppearance;

    @ApiModelProperty(value = "处理建议")
    private String alarmAdvice;

    @ApiModelProperty(value = "告警上报时间",example = "2019-12-10 09:00:56")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date upTime;

    @ApiModelProperty(value = "告警处理完成时间",example = "2019-12-10 09:15:56")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date complationTime;
}
