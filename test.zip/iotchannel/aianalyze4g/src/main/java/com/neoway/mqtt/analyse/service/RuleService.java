package com.neoway.mqtt.analyse.service;

import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.bean.AlarmInfo;
import com.neoway.mqtt.analyse.model.RuleDesignFileParam;
import com.neoway.mqtt.analyse.model.RuleDesignProjectParam;
import com.neoway.mqtt.analyse.vo.RuleDesignProjectVo;
import org.apache.ibatis.annotations.Param;
import org.kie.api.runtime.KieSession;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 规则Service
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/11 14:02
 */
public interface RuleService {
    /**
     * 动态获取KieSession
     *
     * @param rules rule
     * @return KieSession
     */
    KieSession getKieSession(String rules);

    /**
     * 动态加载已经部署的rule
     *
     * @param id id
     * @param alarmInfo  对象
     * @return 结果对象
     */
    AlarmInfo getRulesWrite(Integer id, AlarmInfo alarmInfo);

    /**
     * 查询所有规则设计工程
     * @param projectParam
     * @return
     */
    List<RuleDesignProjectVo> findAllRuleProject(RuleDesignProjectParam projectParam);

    /**
     * 创建工程数据
     * @param projectParam
     * @return
     */
    HttpResult createRuleDesignProject(RuleDesignProjectParam projectParam);

    /**
     * 根据id删除工程目录
     * @param projectParam
     */
    HttpResult deleteRuleDesignProject(RuleDesignProjectParam projectParam);

    /**
     * 根据id修改工程状态
     * @param projectParam
     * @return
     */
    int updateRuleDesignProjectStatus(RuleDesignProjectParam projectParam );

    /**
     * 根据id修改工程状态
     * @param id
     * @return
     */
    RuleDesignProjectVo findRuleDesignProjectDetail(String id);

    /**
     * 存储规则设计文件
     * @param fileParam
     * @return
     */
    HttpResult createRuleDesignFile(RuleDesignFileParam fileParam);

    /**
     * 查询文件目录与文件
     * @param projectName
     * @return
     */
    Map<String, Object> findProjectAndFile(String projectName);

    /**
     * 读取文件内容
     * @param filePath
     * @return
     */
    HttpResult readFileContent(String filePath);

    /**
     * 存贮文件内容
     * @param fileParam
     * @return
     */
    HttpResult writeFileContent(@Param("fileParam") RuleDesignFileParam fileParam);
}
