package com.neoway.mqtt.analyse.excel;

import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.ReUtil;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.excel.exception.ExcelDataConvertException;
import com.alibaba.fastjson.JSON;
import com.neoway.mqtt.analyse.mapper.DeviceManageMapper;
import com.neoway.mqtt.analyse.model.DeviceInfo;
import com.neoway.mqtt.analyse.model.DeviceInfoModelOfExcel;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.util.AmapTools;
import com.neoway.mqtt.analyse.util.OperatorEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <pre>
 * 描述：设备信息导入Listener类
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/6 11:26
 */
@Slf4j
public class UploadDeviceInfoListener extends AnalysisEventListener<DeviceInfoModelOfExcel> {

    private DeviceManageMapper deviceManageMapper;

    private EmqRedisDao emqRedisDao;

    /**
     * 每隔5条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 50;

    private static final String COLUMN_NAME_0 = "设备序列号";
    private static final String COLUMN_NAME_1 = "运营商";
    private static final String COLUMN_NAME_2 = "小区名称";
    private static final String COLUMN_NAME_3 = "小区地址";

    private static final String CELL_NAME_REGEX = "^[\u4E00-\u9FA5A-Za-z0-9_-]{0,32}";
    private static final String CELL_ADDRESS_REGEX = "^[\u4E00-\u9FA5A-Za-z0-9_-]{0,128}";
    private static final String IMEI_REGEX = "^[0-9]{15}";

    List<DeviceInfo> list = new ArrayList<>();

    private Map<String, String> updateRedisMap = new HashMap<>(1);

    private List<String> errorInfo = new ArrayList<>();

    private int rowNum = 1;

    private Boolean hasStart = false;

    public UploadDeviceInfoListener(DeviceManageMapper deviceManageMapper, EmqRedisDao emqRedisDao) {
        this.deviceManageMapper = deviceManageMapper;
        this.emqRedisDao = emqRedisDao;
    }

    @Override
    public void invoke(DeviceInfoModelOfExcel deviceInfoModelOfExcel, AnalysisContext analysisContext) {
        long startTime = System.currentTimeMillis();
        rowNum += 1;
        StringBuilder sb = new StringBuilder();
        if (!hasStart) {
            log.error("表头数据存在问题！请下载模板进行数据导入！");
            return;
        }
        if (deviceInfoModelOfExcel == null) {
            log.error("数据为空！");
            return;
        }
        if (!ReUtil.isMatch(IMEI_REGEX,deviceInfoModelOfExcel.getImei())){
            sb.append("设备序列号应为15位数字！");
        } else if(!(OperatorEnum.CMCC.getOperator().equals(deviceInfoModelOfExcel.getOperator())
                || OperatorEnum.CTCC.getOperator().equals(deviceInfoModelOfExcel.getOperator())
                || OperatorEnum.CUCC.getOperator().equals(deviceInfoModelOfExcel.getOperator()))) {
                sb.append("运营商只能为CMCC、CTCC、CUCC！");
        } else if (!ReUtil.isMatch(CELL_NAME_REGEX, deviceInfoModelOfExcel.getCellName())){
                sb.append("小区名称应为1-32位，中英文、数字、中划线、下划线！");
        } else if (!ReUtil.isMatch(CELL_ADDRESS_REGEX, deviceInfoModelOfExcel.getCellAddress())){
                sb.append("小区地址应为1-128位，中英文、数字、中划线、下划线！");
        }
        if (StringUtils.isEmpty(sb)){
            // 添加对象
            DeviceInfo deviceInfo = new DeviceInfo();
            deviceInfo.setImei(deviceInfoModelOfExcel.getImei());
            deviceInfo.setOperator(deviceInfoModelOfExcel.getOperator());
            deviceInfo.setCellAddress(deviceInfoModelOfExcel.getCellAddress());
            deviceInfo.setCellName(deviceInfoModelOfExcel.getCellName());
            Map<String, String> cellIdInfo = emqRedisDao.findCellIdInfo();
            Set<String> keySet = cellIdInfo.keySet();
            for (String ks : keySet){
                if ((deviceInfoModelOfExcel.getCellAddress() + deviceInfoModelOfExcel.getCellName()).equals(ks)){
                    deviceInfo.setCellId(cellIdInfo.get(ks).split(";")[0]);
                    deviceInfo.setCellLocations(cellIdInfo.get(ks).split(";")[1]);
                }
            }
            if (!CollectionUtils.isEmpty(list)){
                list.forEach(di-> {
                    if (deviceInfoModelOfExcel.getCellName().equals(di.getCellName())
                            && deviceInfoModelOfExcel.getCellAddress().equals(di.getCellAddress())){
                        deviceInfo.setCellId(di.getCellId());
                        deviceInfo.setCellLocations(di.getCellLocations());
                    }});
            }
            if (StringUtils.isBlank(deviceInfo.getCellId()) && StringUtils.isBlank(deviceInfo.getCellLocations())) {
                deviceInfo.setCellId(IdUtil.simpleUUID());
                String cellDetailAddress = deviceInfoModelOfExcel.getCellAddress() + deviceInfoModelOfExcel.getCellName();
                String agps = AmapTools.getAGPS(cellDetailAddress);
                deviceInfo.setCellLocations(agps);
                updateRedisMap.put(deviceInfo.getCellAddress() + deviceInfo.getCellName(), deviceInfo.getCellId() + ";" + deviceInfo.getCellLocations());
                emqRedisDao.updateCellIdInfo(updateRedisMap);
            }
            list.add(deviceInfo);
            if (list.size() >= BATCH_COUNT) {
                List<String> temImeis = new ArrayList<>();
                List<DeviceInfo> uniqueList = list.stream().filter(
                        di -> {
                            if (!temImeis.contains(di.getImei())) {
                                temImeis.add(di.getImei());
                                return true;
                            } else {
                                sb.append("excel表格中设备序列号:").append(di.getImei()).append("重复添加！");
                                return false;
                            }
                        }
                ).collect(Collectors.toList());
                List<String> imeis = emqRedisDao.findAllImei();
                List<DeviceInfo> endList = uniqueList.stream().filter(
                        di -> {
                            if (!imeis.contains(di.getImei())) {
                                return true;
                            } else {
                                sb.append("设备序列号：").append(di.getImei()).append("已存在！");
                                return false;
                            }
                        }
                ).collect(Collectors.toList());
                if (!StringUtils.isEmpty(sb)) {
                    errorInfo.add(sb.toString());
                }
                if (!CollectionUtils.isEmpty(endList)) {
                    deviceManageMapper.batchInsertDeviceInfo(endList);
                    emqRedisDao.updateImei(endList.stream().map(DeviceInfo::getImei).toArray(String[]::new));
                }
                // 存储完清理数组
                list.clear();
            }
        } else {
            sb.insert(0,"第" + rowNum + "行数据存在错误！");
            errorInfo.add(sb.toString());
        }
        log.info("第" + rowNum + "条用时:" + (System.currentTimeMillis()-startTime) + "毫秒");
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        List<String> temImeis = new ArrayList<>();
        List<DeviceInfo> uniqueList = list.stream().filter(
                di -> {
                    if (!temImeis.contains(di.getImei())) {
                        temImeis.add(di.getImei());
                        return true;
                    } else {
                        sb.append("excel表格中设备序列号:").append(di.getImei()).append("重复添加！");
                        return false;
                    }
                }
        ).collect(Collectors.toList());
        List<String> imeis = emqRedisDao.findAllImei();
        List<DeviceInfo> endList = uniqueList.stream().filter(
                di -> {
                    if (!imeis.contains(di.getImei())) {
                        return true;
                    } else {
                        sb.append("设备序列号：").append(di.getImei()).append("已存在！");
                        return false;
                    }
                }
        ).collect(Collectors.toList());

        if (!StringUtils.isEmpty(sb)) {
            errorInfo.add(sb.toString());
        }
        if (!CollectionUtils.isEmpty(endList)) {
            deviceManageMapper.batchInsertDeviceInfo(endList);
            emqRedisDao.updateImei(endList.stream().map(DeviceInfo::getImei).toArray(String[]::new));
        }
        log.info("所有数据解析导入完成！");
    }

    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        hasStart = true;
        StringBuilder sb = new StringBuilder();
        log.info("解析到一条头数据:{}", JSON.toJSONString(headMap));
        String columnName0 = headMap.get(0);
        String columnName1 = headMap.get(1);
        String columnName2 = headMap.get(2);
        String columnName3 = headMap.get(3);
        if (CollectionUtils.isEmpty(headMap)
                || headMap.size() == 0 || headMap.size() != 4
                || !COLUMN_NAME_0.equals(columnName0) || !COLUMN_NAME_1.equals(columnName1)
                || !COLUMN_NAME_2.equals(columnName2) || !COLUMN_NAME_3.equals(columnName3)) {
            sb.append("Excel表格与模板不符，请先下载模板！");
            hasStart = false;
        }
        if (hasStart.equals(false)) {
            errorInfo.add(sb.toString());
        }
    }

    @Override
    public void onException(Exception exception, AnalysisContext context) {
        log.error("解析导入失败，问题是:{}", exception.getMessage());
        if (exception instanceof ExcelDataConvertException) {
            ExcelDataConvertException excelDataConvertException = (ExcelDataConvertException) exception;
            log.error("第{}行，第{}列解析异常，数据为:{}", excelDataConvertException.getRowIndex(),
                    excelDataConvertException.getColumnIndex(), excelDataConvertException.getCellData());
        }
        throw new ExcelAnalysisException(exception.getMessage());
    }

    public List<String> getErrorInfo() {
        return errorInfo;
    }

}
