package com.neoway.mqtt.analyse.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.neoway.mqtt.analyse.model.GeoCodes;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import java.util.List;

/**
 * <pre>
 *  描述:高德地图转换（Gps坐标转换，逆地理编码）
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/08/08 16:13
 */
public class AmapTools {
    private static final String KEY = "296384ebfec1f7346e930e3245904229";
    private static final String RADIUS = "1000";

    private static final String GPS_TO_AMAP = "https://restapi.amap.com/v3/assistant/coordinate/convert?key=%s&locations=%s&coordsys=gps";
    private static final String AMAP_TO_ADDRESS = "https://restapi.amap.com/v3/geocode/regeo?key=%s&location=%s&radius=%s&extensions=base&batch=false&roadlevel=0";
    private static final String ADDRESS_TO_AGPS = "https://restapi.amap.com/v3/geocode/geo?address=%s&output=json&key=%s";

    private static RestTemplate template = new RestTemplate();

    /**
     * 将GPS数据映射为高德地图上的地址
     *
     * @param longitude 经度
     * @param latitude  纬度
     * @return 地址
     */
    public static String getAmapAddress(String longitude, String latitude) {
        String location = longitude + "," + latitude;
        String gpsToLocationUrl = String.format(GPS_TO_AMAP, KEY, location);
        String locationStr = template.getForObject(gpsToLocationUrl, String.class);
        JSONObject locationObject = JSON.parseObject(locationStr);
        String amapLocation = locationObject.getString("locations");
        if (StringUtils.isBlank(amapLocation)) {
            return "";
        }
        String amapToAddressUrl = String.format(AMAP_TO_ADDRESS, KEY, amapLocation, RADIUS);
        String addressStr = template.getForObject(amapToAddressUrl, String.class);
        JSONObject addressObject = JSON.parseObject(addressStr);
        return addressObject.getJSONObject("regeocode").getString("formatted_address");
    }

    /**
     * 具体地址转高德经纬度数据
     *
     * @param address 具体地址
     * @return String 经纬度数据
     */
    public static String getAGPS(String address) {
        String addressToGpsUrl = String.format(ADDRESS_TO_AGPS, address, KEY);
        String aGpsInfo = template.getForObject(addressToGpsUrl, String.class);
        JSONObject jsonObject = JSON.parseObject(aGpsInfo);
        String geoCodes = jsonObject.getString("geocodes");
        if (StringUtils.isBlank(geoCodes)) {
            return "";
        }
        List<GeoCodes> geoCodesList = jsonObject.getObject("geocodes", new TypeReference<List<GeoCodes>>() {
        });
        if (CollectionUtils.isEmpty(geoCodesList)) {
            return "";
        }
        return geoCodesList.get(0).getLocation();
    }

    public static void main(String[] args) throws Exception {
        // 输出:陕西省西安市雁塔区鱼化寨街道丈八八路西安软件新城软件研发基地2期
        System.out.println(getAmapAddress("108.831696", "34.207836"));
        System.out.println(getAGPS("陕西省西安市雁塔区锦业路88号"));
        System.out.println(Thread.currentThread().getContextClassLoader().getResource("").getPath());
    }
}
