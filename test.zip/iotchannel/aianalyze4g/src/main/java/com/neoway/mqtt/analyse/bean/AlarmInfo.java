package com.neoway.mqtt.analyse.bean;

import com.neoway.mqtt.analyse.bean.base.BaseModel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 告警类实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/10 13:42
 */
@ApiModel("告警类实体")
@Data
@EqualsAndHashCode(callSuper = false)
public class AlarmInfo extends BaseModel implements Serializable {

    private static final long serialVersionUID = -7923877928723452453L;

    @ApiModelProperty("告警类型")
    private Integer alarmType;

    @ApiModelProperty("告警描述")
    private String alarmDesc;

    public AlarmInfo (Integer alarmType, String alarmDesc) {
        this.alarmType = alarmType;
        this.alarmDesc = alarmDesc;
    }
}
