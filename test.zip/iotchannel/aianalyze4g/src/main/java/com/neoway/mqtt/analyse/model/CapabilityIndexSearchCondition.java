package com.neoway.mqtt.analyse.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述:性能指标查询条件
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/23 16:19
 */
@Data
@ApiModel("性能指标查询条件")
public class CapabilityIndexSearchCondition implements Serializable {
    private static final long serialVersionUID = 1359912607629372538L;

    @ApiModelProperty("设备imei")
    private String imei;

    @ApiModelProperty("开始时间")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date fromDate;

    @ApiModelProperty("结束时间")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date toDate;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页面显示数")
    private Integer pageSize;
}
