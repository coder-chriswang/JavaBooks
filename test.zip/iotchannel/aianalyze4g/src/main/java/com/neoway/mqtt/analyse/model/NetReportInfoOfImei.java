package com.neoway.mqtt.analyse.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：设备上报网络信息实体
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/15 17:55
 */
@Data
@ApiModel("设备上报网络信息实体")
public class NetReportInfoOfImei implements Serializable {
    private static final long serialVersionUID = -8361605958092861674L;

    @ApiModelProperty(value = "imei")
    private String imei;

    @ApiModelProperty(value = "小区id")
    private String cellId;

    @ApiModelProperty(value = "网络模式")
    private String netMode;

    @ApiModelProperty(value = "跟踪区码")
    private Integer lteTac;

    @ApiModelProperty(value = "物理小区id")
    private Integer ltePci;

    @ApiModelProperty(value = "频点值")
    private Integer lteArfcn;

    @ApiModelProperty(value = "服务区")
    private Integer wcdmaUra;

    @ApiModelProperty(value = "主扰码")
    private Integer wcdmaPsc;

    @ApiModelProperty(value = "频点值")
    private Integer wcdmaArfcn;

    @ApiModelProperty(value = "频点")
    private Integer cdmaChannel;

    @ApiModelProperty(value = "扰码")
    private Integer cdmaPn;

    @ApiModelProperty(value = "系统网络识别码")
    private Integer cdmaSidNid;

    @ApiModelProperty(value = "位置区码")
    private Integer gsmLac;

    @ApiModelProperty(value = "基站识别码")
    private Integer gsmBsci;

    @ApiModelProperty(value = "频点值")
    private Integer gsmArfcn;

    @ApiModelProperty(value = "最小lte强度")
    private Integer lteRsrpMin;

    @ApiModelProperty(value = "平均lte强度")
    private Double lteRsrpAver;

    @ApiModelProperty(value = "最大lte强度")
    private Integer lteRsrpMax;

    @ApiModelProperty(value = "最小lte信号功率")
    private Integer lteRsrqMin;

    @ApiModelProperty(value = "平均lte信号功率")
    private Double lteRsrqAver;

    @ApiModelProperty(value = "最大lte信号功率")
    private Integer lteRsrqMax;

    @ApiModelProperty(value = "最小lte信噪比")
    private Integer lteSinrMin;

    @ApiModelProperty(value = "平均lte信号功率")
    private Double lteSinrAver;

    @ApiModelProperty(value = "最大lte信号功率")
    private Integer lteSinrMax;

    @ApiModelProperty(value = "最小wcdma信号强度")
    private Integer wcdmaRscpMin;

    @ApiModelProperty(value = "平均wcdma信号强度")
    private Double wcdmaRscpAver;

    @ApiModelProperty(value = "最大wcdma信号强度")
    private Integer wcdmaRscpMax;

    @ApiModelProperty(value = "最小wcdma码片能量与总干扰能量的密度比值")
    private Integer wcdmaEcnoMin;

    @ApiModelProperty(value = "平均wcdma码片能量与总干扰能量的密度比值")
    private Double wcdmaEcnoAver;

    @ApiModelProperty(value = "最大wcdma码片能量与总干扰能量的密度比值")
    private Integer wcdmaEcnoMax;

    @ApiModelProperty(value = "最小wcdma信噪比")
    private Integer wcdmaSinrMin;

    @ApiModelProperty(value = "平均wcdma信噪比")
    private Double wcdmaSinrAver;

    @ApiModelProperty(value = "最大wcdma信噪比")
    private Integer wcdmaSinrMax;

    @ApiModelProperty(value = "cdma接收信号强度")
    private Integer cdmaRssi;

    @ApiModelProperty(value = "cdma码片能量与总干扰能量的密度比值")
    private Integer cdmaEcio;

    @ApiModelProperty(value = "gsm接收信号强度")
    private Integer gsmRssi;

    @ApiModelProperty(value = "拨号apn")
    private String apn;

    @ApiModelProperty(value = "鉴权方式")
    private String authType;

    @ApiModelProperty(value = "请求ip类型")
    private String pdnType;

    @ApiModelProperty(value = "内部协议栈")
    private String dataCellType;

    @ApiModelProperty(value = "sim卡号")
    private String iccid;

    @ApiModelProperty(value = "工作电压")
    private Integer workVot;

    @ApiModelProperty(value = "工作波特率")
    private Integer workBps;

    @ApiModelProperty(value = "写卡次数")
    private Integer writeSimCounter;

    @ApiModelProperty(value = "读卡次数")
    private Integer readSimCounter;

    @ApiModelProperty(value = "小区切换次数")
    private Integer cellHoCounter;

    @ApiModelProperty(value = "小区重选次数")
    private Integer cellSelCounter;

    @ApiModelProperty(value = "邻区数量")
    private Integer cellNeighborNumbers;

    @ApiModelProperty(value = "当前网络小区id")
    private int currentCellId;

    @ApiModelProperty(value = "当前网络小区id运营商Plmn")
    private String PLMN;

    @ApiModelProperty(value = "IPV4")
    private String IPV4;

    @ApiModelProperty(value = "IPV6")
    private String IPV6;

    @ApiModelProperty(value = "周期内Rx流量统计")
    private int packetsRxCounter;

    @ApiModelProperty(value = "周期内Tx流量统计")
    private int packetsTxCounter;

    @ApiModelProperty(value = "周期内误包数")
    private String packetsLossCounter;

    @ApiModelProperty(value = "模组软件版本号")
    private String softwareVersion;

    @ApiModelProperty(value = "模组硬件版本号")
    private String hardwareVersion;

    @ApiModelProperty(value = "模组型号")
    private String modeType;

    @ApiModelProperty(value = "失败码")
    private Integer MmRejValue;

    @ApiModelProperty(value = "失败码")
    private Integer GmmRejValue;

    @ApiModelProperty(value = "失败码")
    private Integer SmRejValue;

    @ApiModelProperty(value = "失败码")
    private Integer EmmRejValue;

    @ApiModelProperty(value = "失败码")
    private Integer EsmRejValue;

    @ApiModelProperty("上报时间")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date upTime;
}
