package com.neoway.mqtt.analyse.oauth;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

/**
 * 解析properties白名单
 * @author tuo.yang
 */
@Slf4j
public class PropertyUtil {

    public static String[] getProperUtilArray(String propName) {
        Properties properties = new Properties();
        List<String> list = new ArrayList<>();
        try {
            File file = new File(propName);
            FileInputStream fileInputStream = new FileInputStream(file);
//            InputStream in = Constants.class.getClassLoader().getResourceAsStream(propName);
            properties.load(fileInputStream);
            Iterator<String> it = properties.stringPropertyNames().iterator();

            while (it.hasNext()) {
                String key = it.next();
                list.add(key);
            }

            fileInputStream.close();
        } catch (Exception e) {
            log.error("getProperUtilArray:{}", e);
        }
        String[] strArr = list.toArray(new String[list.size()]);
        return strArr;
    }

    public static String[] getProByFileSystem(String propName) {
        List<String> list = new ArrayList<>();
        FileSystemResource file = new FileSystemResource(propName);
        Properties prop = new Properties();
        try {
            prop.load(file.getInputStream());
        } catch (IOException e) {
            log.error("getProByFileSystem:{}", e);
        }
        Iterator<String> it = prop.stringPropertyNames().iterator();
        while (it.hasNext()) {
            String key = it.next();
            list.add(key);
        }
        String[] strArr = list.toArray(new String[list.size()]);
        return strArr;
    }
}
