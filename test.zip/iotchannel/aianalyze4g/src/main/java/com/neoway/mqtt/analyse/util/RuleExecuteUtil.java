package com.neoway.mqtt.analyse.util;

import com.neoway.mqtt.analyse.bean.base.BaseModel;
import lombok.extern.slf4j.Slf4j;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.internal.utils.KieHelper;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * <pre>
 *  描述: 规则执行工具类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/12 19:34
 */
@Slf4j
public class RuleExecuteUtil {

    /**
     * 动态执行规则方法
     * @param ruleList
     * @param baseModel
     * @return
     */
    public static BaseModel execute(List<String> ruleList, BaseModel baseModel) {
        if (CollectionUtils.isEmpty(ruleList) || baseModel == null) {
            return baseModel;
        }
        log.info("执行规则引擎 start ....");
        System.setProperty("drools.dateformat", "yyyy-MM-dd HH:mm:ss");
        KieHelper helper = new KieHelper();
        for (String rule : ruleList) {
            helper.addContent(rule, ResourceType.DRL);
        }
        KieSession kSession = helper.build().newKieSession();
        kSession.insert(baseModel);
        kSession.fireAllRules();
        kSession.dispose();
        log.info("执行规则引擎 end ....");
        return baseModel;
    }
}
