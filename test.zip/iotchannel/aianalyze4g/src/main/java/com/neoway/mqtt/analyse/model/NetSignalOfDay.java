package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：一天内运营商的信号
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/15 11:40
 */
@Data
@ApiModel(value = "一天内运营商的信号")
public class NetSignalOfDay extends NetSignalOfTime implements Serializable {
    private static final long serialVersionUID = -4814443277633005194L;

    @ApiModelProperty("时段")
    private String time;
}
