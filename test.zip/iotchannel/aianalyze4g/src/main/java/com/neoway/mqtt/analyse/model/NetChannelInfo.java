package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：网络通道
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/14 15:07
 */
@Data
@ApiModel(value = "网络通道信号质量情况")
public class NetChannelInfo implements Serializable {
    private static final long serialVersionUID = -6770068381560447576L;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("消息总数")
    private Integer messageCount;

    @ApiModelProperty("总信号强度")
    private Integer rsrpSumValue;

    @ApiModelProperty("总信噪比值")
    private Integer snrSumValue;

    @ApiModelProperty("信号强度")
    private Double rsrpValue;

    @ApiModelProperty("信噪比")
    private Double snrValue;

    @ApiModelProperty("信号水平")
    private String signalLevel;
}
