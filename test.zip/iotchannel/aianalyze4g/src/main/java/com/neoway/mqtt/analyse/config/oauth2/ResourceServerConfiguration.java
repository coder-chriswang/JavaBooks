package com.neoway.mqtt.analyse.config.oauth2;



import com.neoway.mqtt.analyse.oauth.PropertyUtil;
import com.neoway.mqtt.analyse.oauth.PublicPropeties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;

@Configuration
@EnableResourceServer
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {

    @Autowired
    private PublicPropeties publicPropeties;

    @Autowired
    private TokenStore tokenStore;

    @Autowired
    private UserAccessDeniedHandler userAccessDeniedHandler;

    /**
     * 请求拦截放行策略
     * @param http
     * @throws Exception
     */
    @Override
    public void configure(HttpSecurity http) throws Exception {
        String uriName = publicPropeties.getWhiteUri();
        http.cors()
                .and()
                .csrf().disable()
                .authorizeRequests()
                .antMatchers(PropertyUtil.getProperUtilArray(uriName)).permitAll()
            .antMatchers("/**").authenticated();
    }

    /**
     * oauth2设置认证授权异常处理及jwt存储策略
     * @param resources
     */
    @Override
    public void configure(ResourceServerSecurityConfigurer resources) {
        resources.authenticationEntryPoint(new AuthExceptionEntryPoint()).tokenStore(tokenStore).accessDeniedHandler(userAccessDeniedHandler);
    }
}
