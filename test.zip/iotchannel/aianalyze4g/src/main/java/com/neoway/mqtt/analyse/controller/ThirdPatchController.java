package com.neoway.mqtt.analyse.controller;

import cn.hutool.core.collection.CollectionUtil;
import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.service.DeviceNodeDataService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <pre>
 *  描述: 第三方派单预留接口
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/23 14:35
 */
@RestController
@Slf4j
@Api(tags = "4G管道云告警派单" , description = "4G管道云告警派单")
public class ThirdPatchController {

    @Autowired
    private DeviceNodeDataService deviceNodeDataService;

    @ApiOperation("告警手动派单")
    @PostMapping("/manualDispatch")
    public HttpResult manualDispatch(@PathVariable String userId, List<String> imeis) {
        if (StringUtils.isBlank(userId)) {
            return HttpResult.returnFail("参数为空",null);
        }
        if (CollectionUtil.isEmpty(imeis)) {
            return HttpResult.returnFail("请勾选对应告警信息进行派单处理");
        }
        try {
            deviceNodeDataService.manualDispatch(userId,imeis);
            return HttpResult.returnSuccess("手动派单成功");
        } catch (Exception e) {
            log.error("手动派单失败",e);
            return HttpResult.returnFail("手动派单失败");
        }

    }
}
