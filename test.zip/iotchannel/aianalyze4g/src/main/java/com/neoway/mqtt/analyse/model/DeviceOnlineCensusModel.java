package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备在线状况封装
 * @author 20190729618
 */
@Data
@ApiModel("设备在线状况统计")
public class DeviceOnlineCensusModel implements Serializable {

    @ApiModelProperty("设备在线数")
    private Integer onlineNo;

    @ApiModelProperty("设备离线数")
    private Integer offlineNo;

    @ApiModelProperty("设备总数")
    private Integer totalNo;
}
