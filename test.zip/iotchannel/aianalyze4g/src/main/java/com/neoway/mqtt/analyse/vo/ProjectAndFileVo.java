package com.neoway.mqtt.analyse.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *  描述: 文件夹与文件关系
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/23 15:01
 */
@Data
@ApiModel("文件目录与文件Vo")
public class ProjectAndFileVo extends RuleDesignFileVo implements Serializable {
    private static final long serialVersionUID = 6897030084332078126L;

    private String projectId;
    private String projectPid;
    private String fileId;
    private String filePid;
    List<RuleDesignFileVo> ruleDesignFileVoList;

    @ApiModelProperty("文件夹目录")
    private String project;

    @ApiModelProperty("文件夹下文件")
    private String file;
}
