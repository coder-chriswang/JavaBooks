package com.neoway.mqtt.analyse.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 告警信息查询条件
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/28 15:29
 */
@Data
@ApiModel("告警信息查询条件")
public class AlarmInfoSearchCondition implements Serializable {
    private static final long serialVersionUID = -7736027075360486880L;

    @ApiModelProperty("设备imei")
    private String imei;

    @ApiModelProperty(value = "告警类型" , example = "0：离线告警")
    private Integer alarmType;

    @ApiModelProperty(value = "告警来源", example = "0:平台")
    private Integer alarmOrigin;

    @ApiModelProperty("开始时间")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date fromDate;

    @ApiModelProperty("结束时间")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date toDate;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页面显示数")
    private Integer pageSize;
}
