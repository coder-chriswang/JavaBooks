package com.neoway.mqtt.analyse.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 * 描述：基站节点信息返回数据
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 19:35
 */
@Data
@ApiModel("基站节点信息返回数据")
public class TopoNodeDataVo implements Serializable {
    private static final long serialVersionUID = -3147567008673523880L;

    @ApiModelProperty("信号功率")
    private Double rsrqValue;

    @ApiModelProperty("信号强度")
    private Double rsrpValue;

    @ApiModelProperty("信噪比")
    private Double sinrValue;

    @ApiModelProperty("运营商")
    private String operator;

    @ApiModelProperty("基站id")
    private String currentCellId;

    @ApiModelProperty("小区id")
    private String ltePci;

    @ApiModelProperty("频点")
    private String arfcn;

    @ApiModelProperty("网络质量")
    private String signalLevel;

    private Double lateRsrqValue;

    private Double lateRsrpValue;

    private Double lateSinrValue;

    private List<TopoCapabilityVo> capabilityVoList;

}
