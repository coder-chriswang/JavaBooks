package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 10:49
 */
@Data
public class TopoModel implements Serializable {
    private static final long serialVersionUID = 292019598818552648L;

    /**
     * 基站id
     */
    private String currentCellId;

    /**
     * imei
     */
    private String imei;
}
