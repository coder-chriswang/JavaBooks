package com.neoway.mqtt.analyse.model;

/**
 * 网络制式枚举类
 * @author tuo.yang
 */
public enum  NetMode {
    LTE("LTE","4G网络"),
    WCDMA("WCDMA","2G网络");
    private String mode;
    private String message;
    NetMode() {
    }

    NetMode(String mode, String message) {
        this.mode = mode;
        this.message = message;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
