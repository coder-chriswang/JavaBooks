package com.neoway.mqtt.analyse.constants;

/**
 * <pre>
 *  描述: 性能指标常量类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/24 14:01
 */
public interface CapabilityIndexConstant {

    /**
     * 历史数据包redis key
     */
    String HISTORY_DATA_PACKET_THRESHOLD = "historyDataPacketThreshold";

    /**
     * 当前数据包redis key
     */
    String CURRENT_DATA_PACKET_THRESHOLD = "currentDataPacketThreshold";

    /**
     * 数据接收率redis key
     */
    String DATA_RECEIVE_RATE_THRESHOLD = "dataReceiveRateThreshold";

    /**
     * 数据发送率redis key
     */
    String DATA_SEND_RATE_THRESHOLD = "dataSendRateThreshold";

    /**
     * 延迟指数redis key
     */
    String DELAY_INDEX_THRESHOLD = "delayIndexThreshold";
}
