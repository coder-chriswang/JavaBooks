package com.neoway.mqtt.analyse.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.IdUtil;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageHelper;
import com.neoway.mqtt.analyse.excel.UploadDeviceInfoListener;
import com.neoway.mqtt.analyse.mapper.DataAnalyseMapper;
import com.neoway.mqtt.analyse.mapper.DeviceManageMapper;
import com.neoway.mqtt.analyse.model.*;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.service.DeviceManageService;
import com.neoway.mqtt.analyse.util.AmapTools;
import com.neoway.mqtt.analyse.util.ExcelUtil;
import com.neoway.mqtt.analyse.util.OperatorEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * <pre>
 * 描述：设备管理service实现
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/6 11:28
 */
@Service
@Slf4j
public class DeviceManageServiceImpl implements DeviceManageService {

    private static ExecutorService executorService;

    static {
        executorService = Executors.newFixedThreadPool(10);
    }

    @Autowired
    private DeviceManageMapper deviceManageMapper;

    @Autowired
    private DataAnalyseMapper dataAnalyseMapper;

    @Autowired
    private EmqRedisDao emqRedisDao;

    @Override
    public DeviceInfo findDetailInfo(String imei) {
        return deviceManageMapper.findDetailInfoByImei(imei);
    }

    @Override
    public void updateDeviceInfo(DeviceManageParam deviceManageParam) {
        DeviceInfo deviceInfo = new DeviceInfo();
        deviceInfo.setImei(deviceManageParam.getImei());
        deviceInfo.setCellAddress(deviceManageParam.getCellAddress());
        deviceInfo.setCellName(deviceManageParam.getCellName());
        String cellId = deviceManageMapper.findCellIdByAddressName(deviceManageParam.getCellAddress(), deviceManageParam.getCellName());
        if (cellId != null){
            deviceInfo.setCellId(cellId);
        } else {
            deviceInfo.setCellId(IdUtil.simpleUUID());
        }
        String cellDetailAddress = deviceManageParam.getCellAddress() + deviceManageParam.getCellName();
        String agps = AmapTools.getAGPS(cellDetailAddress);
        deviceInfo.setCellLocations(agps);
        deviceManageMapper.updateDeviceInfo(deviceInfo);
    }

    @Override
    public int deleteDeviceInfo(String imei) {
        Boolean b = deviceManageMapper.isOnline(imei);
        if (b){
            return 0;
        } else {
            emqRedisDao.deleteRedisImei(imei);
            int i = deviceManageMapper.deleteDeviceInfo(imei);
            return i;
        }

    }

    @Override
    public List<DeviceInfo> findDeviceInfo(DeviceSearchCondition searchCondition) {
        String address = searchCondition.getAddress();
        String cellId = dataAnalyseMapper.findCellIdByAddress(address);
        searchCondition.setCellId(cellId);
        if (searchCondition.getPageNum() != null || searchCondition.getPageSize() != null) {
            PageHelper.startPage(searchCondition.getPageNum(), searchCondition.getPageSize());
        }
        return deviceManageMapper.findDeviceInfo(searchCondition);
    }

    @Override
    public void exportDeviceInfoList(DeviceSearchCondition searchCondition, HttpServletResponse response) {
        List<DeviceInfo> deviceInfoList = this.findDeviceInfo(searchCondition);
        List<DeviceInfoExcel> deviceInfoExcelList = new ArrayList<>();
        for (DeviceInfo deviceInfo : deviceInfoList) {
            DeviceInfoExcel deviceInfoExcel = new DeviceInfoExcel();
            handleDeviceInfoList(deviceInfo, deviceInfoExcel);
            deviceInfoExcelList.add(deviceInfoExcel);
        }
        try {
            ExcelUtil.export(response, "DeviceInfoList", "设备信息", DeviceInfoExcel.class, deviceInfoExcelList);
        } catch (Exception e) {
            log.error("导出失败！", e);
        }

    }

    @Override
    public void exportDeviceInfoModel(HttpServletResponse response) {
        try {
            ExcelUtil.exportWithOption(response, "DeviceInfo-Template", "设备信息模板", DeviceInfoTemplate.class, new ArrayList<>());
        } catch (Exception e) {
            log.error("导出设备信息模板失败！", e);
        }
    }

    @Override
    public List<String> findOnlineDevice(String imei) {
        return deviceManageMapper.findOnlineDevice(imei);
    }

    private void handleDeviceInfoList(DeviceInfo deviceInfo, DeviceInfoExcel deviceInfoExcel) {
        BeanUtil.copyProperties(deviceInfo, deviceInfoExcel);
        String[] cellLocations = deviceInfo.getCellLocations().split(",");
        deviceInfoExcel.setLongitude(cellLocations[0]);
        deviceInfoExcel.setLatitude(cellLocations[1]);
        // 处理运营商信息
        if (OperatorEnum.CMCC.getOperator().equals(deviceInfo.getOperator())){
            deviceInfoExcel.setOperator(OperatorEnum.CMCC.getChinaOperator());
        } else if (OperatorEnum.CUCC.getOperator().equals(deviceInfo.getOperator())) {
            deviceInfoExcel.setOperator(OperatorEnum.CUCC.getChinaOperator());
        } else if (OperatorEnum.CTCC.getOperator().equals(deviceInfo.getOperator())){
            deviceInfoExcel.setOperator(OperatorEnum.CTCC.getChinaOperator());
        } else {
            deviceInfoExcel.setOperator(OperatorEnum.UNKNOWN.getChinaOperator());
        }
        // 处理在线状态
        if (0 == deviceInfo.getOnline()) {
            deviceInfoExcel.setOnline("离线");
        } else {
            deviceInfoExcel.setOnline("在线");
        }
    }

    @Override
    public List<String> uploadDeviceInfoData(MultipartFile file) {
        try {
            UploadDeviceInfoListener uploadDeviceInfoListener = new UploadDeviceInfoListener(deviceManageMapper, emqRedisDao);
            ExcelUtil.upload(file, DeviceInfoModelOfExcel.class, uploadDeviceInfoListener);
            return uploadDeviceInfoListener.getErrorInfo();
        } catch (ExcelAnalysisException e) {
            log.error("导入设备信息数据失败！", e);
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            log.error("导入设备信息数据失败！", e);
            throw new RuntimeException("导入设备信息数据失败！");
        }
    }


    @Override
    public String syncLoadDeviceInfo(MultipartFile file) {
        // 1、创建ID
        String id = IdUtil.simpleUUID();
        Map<String, String> statusMap = new HashMap<>(1);
        statusMap.put("statusBit","0");
        emqRedisDao.updateStatusBit(id,statusMap);
        // 2、异步开启执行Excel解析入库的方法
        executorService.execute(() -> this.uploadDeviceInfo(file,id));
        // 3、return id 给前台
        return id;
    }

    private void uploadDeviceInfo(MultipartFile file, String id){
        try {
            UploadDeviceInfoListener uploadDeviceInfoListener = new UploadDeviceInfoListener(deviceManageMapper, emqRedisDao);
            ExcelUtil.upload(file, DeviceInfoModelOfExcel.class, uploadDeviceInfoListener);
            List<String> errorInfo = uploadDeviceInfoListener.getErrorInfo();
            Map<String, String> map = new HashMap<>(1);
            map.put("errorInfo", JSON.toJSONString(errorInfo));
            emqRedisDao.updateErrorInfo(id, map);
            Map<String, String> statusMap = new HashMap<>(1);
            statusMap.put("statusBit","1");
            emqRedisDao.updateStatusBit(id,statusMap);
        }catch (Exception e){
            log.error("导入设备信息数据失败", e);
            throw new RuntimeException("导入设备信息数据失败！");
        }
    }
}
