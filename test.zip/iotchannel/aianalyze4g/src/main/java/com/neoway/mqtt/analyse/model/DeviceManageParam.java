package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：设备管理参数类
 * </pre>
 *
 * @author Adolf(Wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/6 17:37
 */
@Data
@ApiModel(value = "设备管理参数")
public class DeviceManageParam implements Serializable {

    private static final long serialVersionUID = -8983860430455856658L;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("小区名称")
    private String cellName;

    @ApiModelProperty("小区地址")
    private String cellAddress;
}
