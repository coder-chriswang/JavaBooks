package com.neoway.mqtt.analyse.model;

import com.neoway.mqtt.analyse.vo.NetSignalOfDayVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：采集数据model
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/14 16:18
 */
@Data
@ApiModel("采集数据model")
public class CollectDataModel implements Serializable {
    private static final long serialVersionUID = -9066363848260842070L;

    @ApiModelProperty("成功率")
    private String successRate;

    @ApiModelProperty("成功次数")
    private String successNum;

    @ApiModelProperty("失败次数")
    private String failNum;

    @ApiModelProperty("消息总数表")
    private List<Map<String, Object>> msgList;

    @ApiModelProperty("默认当天的网络趋势")
    private NetSignalOfDayVo netSignalOfDayVo;
}
