package com.neoway.mqtt.analyse.mapper;


import com.neoway.mqtt.analyse.model.AlarmInfo;
import com.neoway.mqtt.analyse.model.AlarmInfoSearchCondition;
import com.neoway.mqtt.analyse.model.DeviceNodeInfo;
import com.neoway.mqtt.analyse.model.PatchInfo;
import com.neoway.mqtt.analyse.vo.CellInfoVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 节点设备信息mapper接口
 * @author tuo.yang
 */
@Mapper
public interface DeviceNodeDataMapper {

    /**
     * 查询节点设备具体信息
     * @param imei
     * @param cellId
     * @return list
     */
    List<DeviceNodeInfo> findDeviceNodeInfo(@Param("imei") String imei, @Param("cellId") String cellId);

    /**
     * 查询当前设备告警信息
     * @param alarmInfoSearchCondition
     * @return AlarmInfo
     */
    List<AlarmInfo> findDeviceAlarmInfo(AlarmInfoSearchCondition alarmInfoSearchCondition);

    /**
     * 更新设备处理告警信息状态
     * @param ids
     */
    void updateAlarmStatus(@Param("ids") List<Integer> ids);

    /**
     * 插入派单信息
     * @param patchInfos
     */
    void insertAlarmDisPatch(@Param("patchInfos") List<PatchInfo> patchInfos);

    /**
     * 查询历史告警信息
     * @param alarmInfoSearchCondition
     * @return
     */
    List<AlarmInfo> findHistoryDeviceAlarmInfo(AlarmInfoSearchCondition alarmInfoSearchCondition);

    /**
     * 通过Id查询告警详情
     * @param id
     * @return
     */
    AlarmInfo findAlarmInfoById(Integer id);

    /**
     * 获取基站信息中的信噪比、信号强度
     * @param currentCellId
     * @return
     */
    CellInfoVo findCellInfo(String currentCellId);
}
