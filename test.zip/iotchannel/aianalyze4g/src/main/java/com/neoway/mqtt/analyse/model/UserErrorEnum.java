package com.neoway.mqtt.analyse.model;

/**
 * <pre>
 *  描述: 认证失败枚举类
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/19 15:18
 */
public enum UserErrorEnum {
    TOKEN_EXPIRE(1006,"电力管道云服务token过期失效"),
    REFRESH_TOKEN_EXPIRE(1010,"电力管道云服务refreshToke过期失效"),
    SERVER_FIRST_ERROR(1013,"电力管道云服务端异常");

    private Integer code;
    private String message;

    UserErrorEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
