package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：查询数据条件
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 13:54
 */
@Data
@ApiModel("数据查询条件")
public class SearchCondition implements Serializable {
    private static final long serialVersionUID = -2854006298753379908L;

    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("设备imei号")
    private String imei;

    @ApiModelProperty("运营商:CMCC,CUCC,CTCC")
    private String operator;

    @ApiModelProperty("信号等级:异常,缓慢,畅通")
    private String signalLevel;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页面显示数")
    private Integer pageSize;

}
