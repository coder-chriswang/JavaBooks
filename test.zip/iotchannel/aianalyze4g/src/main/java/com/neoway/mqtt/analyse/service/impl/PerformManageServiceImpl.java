package com.neoway.mqtt.analyse.service.impl;

import com.google.common.collect.Maps;
import com.neoway.mqtt.analyse.mapper.PerformManageMapper;
import com.neoway.mqtt.analyse.model.PerformManageParam;
import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import com.neoway.mqtt.analyse.service.PerformManageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Map;

/**
 * <pre>
 * 描述：
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/23 14:01
 */
@Service
@Slf4j
public class PerformManageServiceImpl implements PerformManageService {

    @Autowired
    PerformManageMapper performManageMapper;

    @Autowired
    EmqRedisDao emqRedisDao;

    @Override
    public void addPerformConfig(PerformManageParam addParam) {
        performManageMapper.addPerformConfig(addParam);
        PerformManageParam performManageParam = performManageMapper.findOne();
        Map<String, String> configMap = Maps.newHashMap();
        if (performManageParam != null) {
            if (performManageParam.getHistoryDataPacketThreshold() != null){
                configMap.put("historyDataPacketThreshold", String.valueOf(performManageParam.getHistoryDataPacketThreshold()));
            }
            if (performManageParam.getDataReceiveRateThreshold() != null){
                configMap.put("dataReceiveRateThreshold", String.valueOf(performManageParam.getDataReceiveRateThreshold()));
            }
            if (performManageParam.getDataSendRateThreshold() != null){
                configMap.put("dataSendRateThreshold", String.valueOf(performManageParam.getDataSendRateThreshold()));
            }
            if (performManageParam.getDelayIndexThreshold() != null){
                configMap.put("delayIndexThreshold", String.valueOf(performManageParam.getDelayIndexThreshold()));
            }
            emqRedisDao.updateConfig(configMap);
            log.info("存储配置信息至数据库及redis成功");
        } else {
            log.error("配置信息存储失败");
        }
    }

    @Override
    public void updatePerformConfig(PerformManageParam updateParam) {
        performManageMapper.updatePerformConfig(updateParam);
        PerformManageParam param = performManageMapper.findOne();
        Map<String, String> configMap = Maps.newHashMap();
        if (param != null) {
            configMap.put("historyDataPacketThreshold", String.valueOf(param.getHistoryDataPacketThreshold()));
            configMap.put("dataReceiveRateThreshold", String.valueOf(param.getDataReceiveRateThreshold()));
            configMap.put("dataSendRateThreshold", String.valueOf(param.getDataSendRateThreshold()));
            configMap.put("delayIndexThreshold", String.valueOf(param.getDelayIndexThreshold()));
            emqRedisDao.deleteConfig();
            emqRedisDao.updateConfig(configMap);
            log.info("更新配置信息至数据库及redis成功");
        } else {
            log.error("配置信息更新失败");
        }
    }

    @Override
    public void deletePerformConfig() {
        emqRedisDao.deleteConfig();
        performManageMapper.deletePerformConfig();
    }

    @Override
    public PerformManageParam findOne() {
        Map<String, String > configMap = emqRedisDao.findConfig();
        if (!CollectionUtils.isEmpty(configMap)) {
            PerformManageParam performManageParam = new PerformManageParam();
            performManageParam.setHistoryDataPacketThreshold(Integer.valueOf(configMap.get("historyDataPacketThreshold")));
            performManageParam.setDataReceiveRateThreshold(Double.valueOf(configMap.get("dataReceiveRateThreshold")));
            performManageParam.setDataSendRateThreshold(Double.valueOf(configMap.get("dataSendRateThreshold")));
            performManageParam.setDelayIndexThreshold(Double.valueOf(configMap.get("delayIndexThreshold")));
            return performManageParam;
        } else {
            return performManageMapper.findOne();
        }
    }

    @Override
    public int findObservationTime() {
        Map<String, String> observationTimeConfig = emqRedisDao.findObservationTimeConfig();
        if (!CollectionUtils.isEmpty(observationTimeConfig)){
            return Integer.valueOf(observationTimeConfig.get("observationTime"));
        } else {
            return performManageMapper.findObservationTime();
        }
    }

    @Override
    public void updateObservationTime(Integer observationTime) {
        performManageMapper.updateObservationTime(observationTime);
        Integer obt = performManageMapper.findObservationTime();
        Map<String, String> observationTimeMap = Maps.newHashMap();
        if (obt != null) {
            observationTimeMap.put("observationTime", String.valueOf(obt));
            emqRedisDao.deleteObservationTime();
            emqRedisDao.updateObservationTime(observationTimeMap);
            log.info("更新观测性能周期数信息至数据库及redis成功");
        } else {
            log.error("更新观测性能周期数信息");
        }
    }

}
