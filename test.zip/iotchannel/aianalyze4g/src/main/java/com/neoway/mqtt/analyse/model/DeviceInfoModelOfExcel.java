package com.neoway.mqtt.analyse.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

import java.io.Serializable;

/**
 * @author 20190712158
 */
@Data
@ContentRowHeight(15)
@HeadRowHeight(20)
@ColumnWidth(25)
public class DeviceInfoModelOfExcel implements Serializable {

    private static final long serialVersionUID = 8334316932435923895L;

    @ExcelProperty(value = "设备序列号", index = 0)
    private String imei;

    @ExcelProperty(value = "运营商",index = 1)
    private String operator;

    @ExcelProperty(value = "小区名称", index = 2)
    private String cellName;

    @ExcelProperty(value = "小区详细地址", index = 3)
    private String cellAddress;

}
