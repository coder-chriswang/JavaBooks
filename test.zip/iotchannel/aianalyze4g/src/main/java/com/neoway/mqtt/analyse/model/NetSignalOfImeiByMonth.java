package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：设备月网络质量
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/17 10:50
 */
@Data
@ApiModel("设备月网络质量")
public class NetSignalOfImeiByMonth implements Serializable {
    private static final long serialVersionUID = -2726062201052115395L;

    @ApiModelProperty("天")
    private String time;

    @ApiModelProperty("信号接收强度")
    private Double rsrpValue;

    @ApiModelProperty("信噪比")
    private Double snrValue;

    @ApiModelProperty("信号等级")
    private String signalLevel;

    @ApiModelProperty("信号质量，1，极差；2，较差；3，正常；4，良好；5，优秀")
    private int signalValue;
}
