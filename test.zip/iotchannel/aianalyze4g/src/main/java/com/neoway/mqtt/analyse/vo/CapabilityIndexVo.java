package com.neoway.mqtt.analyse.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述:性能指标数据vo层
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/22 19:14
 */
@Data
@ApiModel("性能指标数据")
public class CapabilityIndexVo implements Serializable {
    private static final long serialVersionUID = 3926179980486937500L;

    @ApiModelProperty("设备imei号")
    private String imei;

    @ApiModelProperty("历史周期数据包--指7天")
    private long historyDataPackageNum;

    @ApiModelProperty("当前周期数据包--指当天")
    private long currentDataPackageNum;

    @ApiModelProperty("数据接收率")
    private double receivingRate;

    @ApiModelProperty("数据发送率")
    private double sendingRate;

    @ApiModelProperty("延迟指数")
    private double delayIndex;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("上报时间")
    private Date upTime;
}
