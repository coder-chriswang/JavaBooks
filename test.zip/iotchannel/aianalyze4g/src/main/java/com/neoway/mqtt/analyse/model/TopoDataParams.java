package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 17:24
 */
@Data
public class TopoDataParams implements Serializable {
    private static final long serialVersionUID = -7203458624472653334L;

    @ApiModelProperty("基站id")
    private String currentCellId;

    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("类型 1：基站id  2:imei")
    private String type;
}
