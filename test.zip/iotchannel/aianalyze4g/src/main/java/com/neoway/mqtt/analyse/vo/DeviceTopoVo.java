package com.neoway.mqtt.analyse.vo;


import com.neoway.mqtt.analyse.model.CollectDataModel;
import com.neoway.mqtt.analyse.model.DeviceCensusModel;
import com.neoway.mqtt.analyse.model.DeviceOnlineCensusModel;
import com.neoway.mqtt.analyse.model.SimCardStatistic;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * topo管理总体数据封装
 * @author 20190729618
 */
@Data
@ApiModel(value = "topo管理总体数据封装")
public class DeviceTopoVo {

    @ApiModelProperty("日采集率成功趋势")
    private CollectDataModel collectDataModel;

    @ApiModelProperty("运行商网络信号对比")
    private NetSignalOfDayVo netSignalOfDayVo;

    @ApiModelProperty("设备统计数据")
    private DeviceCensusModel deviceCensusModel;

    @ApiModelProperty("设备在线率")
    private DeviceOnlineCensusModel deviceOnlineCensusModel;

    @ApiModelProperty("当日SIM卡使用情况")
    private SimCardStatistic simCardStatistic;


}
