package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述:基站与节点对应关系实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/10 10:44
 */
@Data
public class CellIdDeviceImeiMapModel implements Serializable {
    private static final long serialVersionUID = 5960269640935942101L;
    private String currentCellId;
    private String imei;
}
