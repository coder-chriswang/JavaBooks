package com.neoway.mqtt.analyse.service;

import com.neoway.mqtt.analyse.model.PerformManageParam;

/**
 * <pre>
 * 描述：性能管理service层
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 16:58
 */
public interface PerformManageService {
    /**
     * 新增性能配置
     * @param addParam
     * @return
     */
    void addPerformConfig(PerformManageParam addParam);

    /**
     * 更新性能配置
     * @param updateParam
     * @return
     */
    void updatePerformConfig(PerformManageParam updateParam);

    /**
     * 删除性能配置
     * @return
     */
    void deletePerformConfig();


    /**
     * 查询唯一配置
     *
     * @return
     */
    PerformManageParam findOne();

    /**
     * 查询观测性能周期数
     * @return
     */
    int findObservationTime();

    /**
     * 更新性能观测周期数
     * @param observationTime
     */
    void updateObservationTime(Integer observationTime);
}
