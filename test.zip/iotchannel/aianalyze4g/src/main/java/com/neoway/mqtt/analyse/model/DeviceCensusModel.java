package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 设备信息封装
 * @author 20190729618
 */
@Data
@ApiModel(value = "设备数据量统计")
public class DeviceCensusModel implements Serializable {

    @ApiModelProperty("上行数据量")
    private Integer uploadPackageNo;

    @ApiModelProperty("下行数据量")
    private Integer downloadPackageNo;

    @ApiModelProperty("总数据量")
    private Integer totalPackageNo;
}
