package com.neoway.mqtt.analyse.bean.base;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 基础类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/11 19:40
 */
public class BaseModel implements Serializable {
    private static final long serialVersionUID = 9208570328541536472L;
}
