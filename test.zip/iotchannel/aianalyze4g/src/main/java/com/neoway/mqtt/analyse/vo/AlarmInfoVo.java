package com.neoway.mqtt.analyse.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：告警数据vo
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 14:10
 */
@Data
@ApiModel(value = "告警数据")
public class AlarmInfoVo implements Serializable {
    private static final long serialVersionUID = 5940771235730946989L;

    @ApiModelProperty("imei号")
    private String imei;

    @ApiModelProperty("告警类型")
    private Integer type;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("上报时间")
    private Date recordTime;
}
