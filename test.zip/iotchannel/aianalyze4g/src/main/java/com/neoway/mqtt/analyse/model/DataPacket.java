package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述:数据包数量实体
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/9 19:09
 */
@Data
public class DataPacket implements Serializable {

    private static final long serialVersionUID = 8430318828136217306L;
    private String imei;
    private long dataPacketSum;
}
