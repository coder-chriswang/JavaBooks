package com.neoway.mqtt.analyse.redis.impl;


import com.neoway.mqtt.analyse.redis.EmqRedisDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * <pre>
 * 描述：redis
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 19:58
 */
@Component
public class EmqRedisDaoImpl implements EmqRedisDao {
    @Autowired
    private StringRedisTemplate template;

    @Override
    public void updateConfig(Map<String, String> value) {
        template.boundHashOps("nw:equ:config:uniqueConfig").putAll(value);
    }

    @Override
    public Map<String, String> findConfig() {
        Map<String, String> configMap =  template.<String, String>boundHashOps("nw:equ:config:uniqueConfig").entries();
        return configMap;
    }

    @Override
    public void deleteConfig() {
        template.delete("nw:equ:config:uniqueConfig");
    }

    @Override
    public Map<String, String> findObservationTimeConfig() {
        Map<String, String> ObservationConfigMap =  template.<String, String>boundHashOps("nw:equ:config:uniqueObservationTimeConfig").entries();
        return ObservationConfigMap;
    }

    @Override
    public void deleteObservationTime() {
        template.delete("nw:equ:config:uniqueObservationTimeConfig");
    }

    @Override
    public void updateObservationTime(Map<String, String> value) {
        template.boundHashOps("nw:equ:config:uniqueObservationTimeConfig").putAll(value);
    }

    @Override
    public Map<String, String> findCellIdInfo() {
        Map<String, String> cellIdMap = template.<String, String>boundHashOps("nw:equ:excel:cellIdInfo").entries();
        return cellIdMap;
    }

    @Override
    public void updateCellIdInfo(Map<String, String> value) {
        template.boundHashOps("nw:equ:excel:cellIdInfo").putAll(value);
    }

    @Override
    public void updateImei(String[] imei) {
        template.boundListOps("nw:equ:excel:imei").leftPushAll(imei);
    }

    @Override
    public List<String> findAllImei() {
        List<String> range = template.boundListOps("nw:equ:excel:imei").range(0, -1);
        return range;
    }

    @Override
    public void updateStatusBit(String id, Map<String, String> statusBit) {
        template.boundHashOps("nw:equ:excel:statusBit:"+ id).putAll(statusBit);
        template.boundListOps("nw:equ:excel:statusBit:"+ id).expire(15, TimeUnit.MINUTES);
    }

    @Override
    public Map<String, String> findStatusBit(String id) {
        return template.<String,String>boundHashOps("nw:equ:excel:statusBit:"+ id).entries();
    }

    @Override
    public void updateErrorInfo(String id, Map<String, String> map) {
        template.boundHashOps("nw:equ:excel:result:" + id).putAll(map);
        template.boundHashOps("nw:equ:excel:result:"+ id).expire(1, TimeUnit.MINUTES);
    }

    @Override
    public Map<String, String> getExcelErrorInfo(String id) {
        return template.<String, String>boundHashOps("nw:equ:excel:result:" + id).entries();
    }

    @Override
    public void deleteRedisImei(String imei) {
        template.boundListOps("nw:equ:excel:imei").remove(1,imei);
    }

}
