package com.neoway.mqtt.analyse.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 统一cellIdVo
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/23 10:16
 */
@Data
public class CellIdInfoVo implements Serializable {
    private static final long serialVersionUID = 6929157006533199181L;

    private String cellId;

    private String cellName;

    private String cellAddress;

    private String cellLocations;
}
