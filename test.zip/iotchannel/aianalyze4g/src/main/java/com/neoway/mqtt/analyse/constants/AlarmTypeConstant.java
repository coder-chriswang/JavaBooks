package com.neoway.mqtt.analyse.constants;

/**
 * <pre>
 *  描述: 告警类型常量类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/24 13:45
 */
public interface AlarmTypeConstant {

    /**
     * 历史数据包低于阈值告警
     */
    Integer HISTORY_DATA_PACKAGE_ALARM = 1;

    /**
     * 当前数据包低于阈值告警
     */
    Integer CURRENT_DATA_PACKAGE_ALARM = 2;

    /**
     * 数据接收率低于阈值告警
     */
    Integer RECEIVING_RATE_ALARM = 3;

    /**
     * 数据发送率低于阈值告警
     */
    Integer SENDING_RATE_ALARM = 4;

    /**
     * 延迟时间高于阈值告警
     */
    Integer DELAY_INDEX_ALARM = 5;
}
