package com.neoway.mqtt.analyse.service.impl;


import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.IdUtil;
import com.github.pagehelper.PageHelper;
import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.bean.AlarmInfo;
import com.neoway.mqtt.analyse.common.bean.ExceptionType;
import com.neoway.mqtt.analyse.common.exception.BusinessException;
import com.neoway.mqtt.analyse.mapper.RuleMapper;
import com.neoway.mqtt.analyse.model.Rule;
import com.neoway.mqtt.analyse.model.RuleDesignFileParam;
import com.neoway.mqtt.analyse.model.RuleDesignProjectParam;
import com.neoway.mqtt.analyse.service.RuleService;
import com.neoway.mqtt.analyse.vo.ProjectAndFileVo;
import com.neoway.mqtt.analyse.vo.RuleDesignFileVo;
import com.neoway.mqtt.analyse.vo.RuleDesignProjectVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Results;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.*;

/**
 * <pre>
 *  描述: 规则ServiceImpl
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/11 14:02
 */
@Service
@Slf4j
public class RuleServiceImpl implements RuleService {

    @Autowired
    private RuleMapper ruleMapper;

    @Value("${linux.disk.path}")
    private String linuxDisk;

    private static final String SYSTEM_PROPERTY = "os.name";

    private static final String OS_WINDOWS = "WINDOWS";

    private static final String OS_LINUX = "LINUX";


    @Override
    public KieSession getKieSession(String rules) {
        KieServices kieServices = KieServices.Factory.get();
        KieFileSystem kfs = kieServices.newKieFileSystem();
        kfs.write("src/main/resources/rules/rules.drl", rules.getBytes());
        KieBuilder kieBuilder = kieServices.newKieBuilder(kfs).buildAll();
        Results results = kieBuilder.getResults();
        if (results.hasMessages(org.kie.api.builder.Message.Level.ERROR)) {
            System.out.println(results.getMessages());
            throw new BusinessException(300003,results.getMessages().toString(),4);
        }
        KieContainer kieContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
        KieBase kieBase = kieContainer.getKieBase();
        return kieBase.newKieSession();
    }

    @Override
    public AlarmInfo getRulesWrite(Integer id, AlarmInfo alarmInfo) {
        String rules;
        Rule ru = ruleMapper.getById(id);
        if (ru != null && ru.getRule() != null) {
            rules = ru.getRule();
        } else {
            throw new BusinessException(ExceptionType.RULE_IS_NULL);
        }
        KieServices kieServices = KieServices.Factory.get();
        KieFileSystem kfs = kieServices.newKieFileSystem();
        kfs.write("src/main/resources/rules/rules.drl", rules.getBytes());
        KieBuilder kieBuilder = kieServices.newKieBuilder(kfs).buildAll();
        Results results = kieBuilder.getResults();
        if (results.hasMessages(org.kie.api.builder.Message.Level.ERROR)) {
            System.out.println(results.getMessages());
            throw new IllegalStateException("### errors ###");
        }
        KieContainer kieContainer = kieServices.newKieContainer(kieServices.getRepository().getDefaultReleaseId());
        KieBase kieBase = kieContainer.getKieBase();
        KieSession kiesession = kieBase.newKieSession();
        kiesession.insert(alarmInfo);
        kiesession.fireAllRules();
        return alarmInfo;
    }

    @Override
    public List<RuleDesignProjectVo> findAllRuleProject(RuleDesignProjectParam projectParam) {
        PageHelper.startPage(projectParam.getPageNum(), projectParam.getPageSize());
        return ruleMapper.findAllRuleProject(projectParam);
    }

    @Override
    public HttpResult createRuleDesignProject(RuleDesignProjectParam projectParam) {
        String path = "";
        File dir;
        try {

            dir = new File(linuxDisk + File.separator + projectParam.getProjectName());
            if (dir.exists()) {
                return HttpResult.returnFail("文件目录已经存在", false);
            }
            // Linux下需要设置文件可写权限
            dir.setWritable(true, true);
            dir.mkdirs();
            path = dir.getAbsolutePath();
            projectParam.setPid("-1");
            projectParam.setId(IdUtil.simpleUUID());
            projectParam.setPath(path);
            projectParam.setProjectName(projectParam.getProjectName());
            projectParam.setDescription(projectParam.getDescription());
            projectParam.setCreateTime(new Date());
            projectParam.setStatus(0);
            int result = ruleMapper.createRuleDesignProject(projectParam);
            if (result <= 0) {
                return HttpResult.returnFail("工程目录创建失败", false);
            }
            return HttpResult.returnSuccess("工程创建成功", true);
        } catch (Exception e) {
            log.error("创建工程目录异常", false);
            return HttpResult.returnFail("工程目录创建异常", false);
        }
    }

    @Override
    public int updateRuleDesignProjectStatus(RuleDesignProjectParam projectParam) {
        projectParam.setUpdateTime(new Date());
        return ruleMapper.updateRuleDesignProjectStatus(projectParam);
    }

    @Override
    public RuleDesignProjectVo findRuleDesignProjectDetail(String id) {
        return ruleMapper.findRuleDesignProjectDetail(id);
    }

    @Override
    public HttpResult deleteRuleDesignProject(RuleDesignProjectParam projectParam) {
        try {
            boolean result = deleteFileDir(projectParam.getPath());
            if (result) {
                ruleMapper.deleteRuleDesignProject(projectParam.getId());
                return HttpResult.returnSuccess("工程目录删除成功", true);
            }
            return HttpResult.returnFail("工程目录删除失败", false);
        } catch (Exception e) {
            log.error("工程目录删除失败", false);
            return HttpResult.returnFail("工程目录删除异常", false);
        }
    }

    private boolean deleteFileDir(String filePath) {
        try {
            File dir = new File(filePath);
            if (!dir.exists()) {
                log.error("文件目录不存在");
                return false;
            }
            File[] files = dir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        log.info("当前为文件夹，递归");
                        deleteFileDir(file.getAbsolutePath());
                    }
                    log.info("当前为文件，直接删除");
                    file.delete();
                }
            }
            dir.delete();
            return true;
        } catch (Exception e) {
            log.error("工程目录删除失败");
            return false;
        }
    }

    @Override
    public HttpResult createRuleDesignFile(RuleDesignFileParam fileParam) {
        File file;
        String filePath = "";
        try {
            file = new File(fileParam.getParentPath() + File.separator + fileParam.getFileName() + fileParam.getFileSuffix());
            if (file.exists()) {
                return HttpResult.returnFail("文件已经存在", false);
            }
            // Linux下需要设置文件可写权限
            file.setWritable(true, true);
            file.createNewFile();
            filePath = file.getAbsolutePath();
            String parentName = file.getParentFile().getName();
            String parentId = ruleMapper.findParentIdByParentName(parentName);
            fileParam.setId(IdUtil.simpleUUID());
            fileParam.setPath(filePath);
            fileParam.setFileSuffix(fileParam.getFileSuffix());
            fileParam.setPid(parentId);
            fileParam.setFileName(fileParam.getFileName());
            fileParam.setCreateTime(new Date());
            ruleMapper.createRuleDesignFile(fileParam);
            return HttpResult.returnSuccess("文件创建成功", true);
        } catch (IOException e) {
            e.printStackTrace();
            return HttpResult.returnFail("文件创建异常", false);
        }
    }

    @Override
    public Map<String, Object> findProjectAndFile(String projectName) {
        try {
            List<ProjectAndFileVo> projectAndFile = ruleMapper.findProjectAndFile(projectName);
            if (CollectionUtil.isEmpty(projectAndFile)) {
                log.info("暂无要查询的目录结构");
                return null;
            }
            List<RuleDesignFileVo> ruleDesignFileVos = new ArrayList<>();
            Map<String, Object> map = new HashMap<>(1);
            for (ProjectAndFileVo projectAndFileVo : projectAndFile) {
                if (StringUtils.isEmpty(projectAndFileVo.getFilePid()) && StringUtils.isNotEmpty(projectAndFileVo.getProjectId())) {
                    map.put("project", projectAndFileVo.getProject());
                    map.put("children", ruleDesignFileVos);
                    return map;
                }
                if (projectAndFileVo.getFilePid().equalsIgnoreCase(projectAndFileVo.getProjectId())) {
                    RuleDesignFileVo ruleDesignFileVo = new RuleDesignFileVo();
                    ruleDesignFileVo.setId(projectAndFileVo.getFileId());
                    ruleDesignFileVo.setFile(projectAndFileVo.getFile());
                    ruleDesignFileVo.setFilePath(projectAndFileVo.getFilePath());
                    ruleDesignFileVos.add(ruleDesignFileVo);
                }
                map.put("project", projectAndFileVo.getProject());
                map.put("children", ruleDesignFileVos);
            }
            return map;
        } catch (Exception e) {
            log.error("获取文件目录及其文件异常");
            return null;
        }
    }

    @Override
    public HttpResult readFileContent(String path) {
        BufferedReader bufferedReader = null;
        StringBuilder stringBuilder;
        try {
            File file = new File(path);
            if (!file.exists()) {
                return HttpResult.returnFail("文件不存在,请检查", false);
            }
            FileReader fileReader = new FileReader(file);
            bufferedReader = new BufferedReader(fileReader);
            stringBuilder = new StringBuilder();
            String content;
            while ((content = bufferedReader.readLine()) != null) {
                stringBuilder.append(content).append("\n");
            }
        } catch (IOException e) {
            log.error("读取文件内容异常");
            return HttpResult.returnFail("读取文件内容异常", false);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            } catch (IOException e) {
                log.error("BufferReader关闭异常");
            }
        }
        if (StringUtils.isEmpty(stringBuilder)) {
            log.info("暂无内容");
            return HttpResult.returnSuccess("文件内容为空", "");
        }
        log.info(stringBuilder.toString());
        return HttpResult.returnSuccess(stringBuilder.toString());
    }

    @Override
    public HttpResult writeFileContent(RuleDesignFileParam fileParam) {
        BufferedWriter bufferedWriter = null;
        try {
            File file = new File(fileParam.getPath());
            if (!file.exists()) {
                HttpResult.returnFail("文件路径不存在，请检查", false);
            }
            if (!file.isFile()) {
                HttpResult.returnFail("非文件路径，请检查", false);
            }
            FileWriter fileWriter = new FileWriter(file);
            bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(fileParam.getContent());
            bufferedWriter.newLine();
            fileParam.setUpdateTime(new Date());
            ruleMapper.writeFileContent(fileParam);
        } catch (IOException e) {
            return HttpResult.returnFail("保存文件异常", false);
        } finally {
            try {
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
            } catch (IOException e) {
                log.error("BufferedWriter关闭异常");
            }
        }
        return HttpResult.returnSuccess("文件内容保存成功", true);
    }
}
