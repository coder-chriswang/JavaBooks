package com.neoway.mqtt.analyse.controller;

import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.model.ModuleDiagnoseParam;
import com.neoway.mqtt.analyse.service.CommandSendService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <pre>
 * 描述：
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/20 10:19
 */
@RestController
@Slf4j
@RequestMapping("/command/send")
@Api(tags = "下发远程诊断命令" , description = "下发远程诊断命令")
public class CommandSendController {

    @Autowired
    CommandSendService commandSendService;

    @ApiOperation("远程诊断命令下发")
    @PostMapping("/moduleDiagnose")
    public HttpResult moduleDiagnoseSend(@RequestBody ModuleDiagnoseParam moduleDiagnoseParam){
        if (moduleDiagnoseParam == null || StringUtils.isBlank(moduleDiagnoseParam.getImei())) {
            return HttpResult.returnFail("参数有误，请检查参数传递");
        }
        try {
            return HttpResult.returnSuccess(commandSendService.moduleDiagnoseSend(moduleDiagnoseParam));
        } catch (Exception e) {
            log.error("远程诊断命令下发失败", e);
            return HttpResult.returnFail("远程诊断命令下发失败");
        }
    }
}
