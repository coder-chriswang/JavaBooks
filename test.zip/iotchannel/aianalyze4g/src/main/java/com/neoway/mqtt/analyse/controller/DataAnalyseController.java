package com.neoway.mqtt.analyse.controller;

import cn.hutool.core.collection.CollectionUtil;
import com.github.pagehelper.PageInfo;
import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.model.*;
import com.neoway.mqtt.analyse.service.DataAnalyseService;
import com.neoway.mqtt.analyse.service.DeviceNodeDataService;
import com.neoway.mqtt.analyse.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <pre>
 * 描述：数据展示controller层
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 11:26
 */
@RestController
@Slf4j
@RequestMapping("/data/analyse")
@Api(tags = "4G管道云数据展示" , description = "4G管道云数据展示")
public class DataAnalyseController {

    @Autowired
    DataAnalyseService dataAnalyseService;

    @Autowired
    private DeviceNodeDataService deviceNodeDataService;

    @ApiOperation("查询展示数据")
    @PostMapping("/dataInfo")
    public HttpResult<PipeCloudDataVo> dataInfo(@RequestBody SearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询展示数据，分页参数存在问题！请检查传参！");
        }
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findInfo(searchCondition));
        } catch (Exception e) {
            log.error("展示数据查询失败", e);
            return HttpResult.returnFail("展示数据查询失败");
        }
    }

    @ApiOperation("查询小区设备信息")
    @PostMapping("/meterData")
    public HttpResult<PageInfo> findGasMeterData(@RequestBody SearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询小区设备信息，分页参数存在问题！请检查传参！");
        }
        try {
            return HttpResult.returnSuccess(new PageInfo<>(dataAnalyseService.findAllPipeCloudDataOfCell(searchCondition)));
        } catch (Exception e) {
            return HttpResult.returnFail("小区数据查询失败");
        }
    }

    @ApiOperation("通过Imei号查询设备参数信息")
    @GetMapping("/deviceInfoByImei/{imei}")
    public HttpResult<NetReportInfoOfImei> findNetDataByImei(@PathVariable("imei") String imei) {
        if (StringUtils.isBlank(imei)) {
            return HttpResult.returnFail("参数为空，请检查传参！");
        }
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findDeviceInfoOfCellByImei(imei));
        } catch (Exception e) {
            return HttpResult.returnFail("设备参数查询失败");
        }

    }

    @ApiOperation("运营商网络信号对比趋势")
    @PostMapping("/operatorSignal")
    public HttpResult operatorSignal(@RequestBody NetSignalQueryParams netSignalQueryParams) {
        if (netSignalQueryParams == null || StringUtils.isBlank(netSignalQueryParams.getType())) {
            return HttpResult.returnFail("参数传递有误，请检查传参！");
        }
        try {
            if (StringUtils.equals("1", netSignalQueryParams.getType())) {
                return HttpResult.returnSuccess(dataAnalyseService.findNetSignalOfDay(netSignalQueryParams.getAddress()));
            } else if (StringUtils.equals("2", netSignalQueryParams.getType())) {
                return HttpResult.returnSuccess(dataAnalyseService.findNetSignalOfDays(netSignalQueryParams.getAddress(), -7));
            } else if (StringUtils.equals("3", netSignalQueryParams.getType())) {
                return HttpResult.returnSuccess(dataAnalyseService.findNetSignalOfDays(netSignalQueryParams.getAddress(), -30));
            } else {
                return HttpResult.returnFail("type参数不符合要求！");
            }
        } catch (Exception e) {
            return HttpResult.returnFail("运营商网络信息查询失败！");
        }

    }

    @ApiOperation("通过Imei号查询设备过去一月内网络的信息")
    @GetMapping("/netInfoByImei/{imei}")
    public HttpResult<NetSignalOfImeiByMonthVo> findNetInfoByImei(@PathVariable("imei") String imei) {
        if (StringUtils.isBlank(imei)) {
            return HttpResult.returnFail("参数是空！");
        }
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findNetInfoByImei(imei));
        } catch (Exception e) {
            return HttpResult.returnFail("网络轨迹信息查询失败！");
        }

    }

    @ApiOperation("导出小区设备信息")
    @PostMapping("/exportDeviceInfo")
    public void exportDeviceInfo(@RequestBody SearchCondition searchCondition, HttpServletResponse response) {
        dataAnalyseService.exportDeviceInfo(searchCondition, response);
    }

    @ApiOperation("查询基站与节点的拓扑关系")
    @PostMapping("/findCellDeviceTopo")
    public HttpResult<CellIdDeviceVo> findCellDeviceTopo(@RequestBody TopoSearchCondition topoSearchCondition) {
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findCellIdDeviceMap(topoSearchCondition));
        } catch (Exception e) {
            return HttpResult.returnFail("基站与节点拓扑关系查询失败！");
        }
    }

    @ApiOperation("查询性能指标数据")
    @PostMapping("/findCapabilityIndexData")
    public HttpResult<PageInfo<CapabilityIndexVo>> findCapabilityIndexData(@RequestBody CapabilityIndexSearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询性能指标数据，分页参数存在问题！请检查传参！");
        }
        try {
            return HttpResult.returnSuccess(new PageInfo<>(dataAnalyseService.findCapabilityIndexData(searchCondition)));
        } catch (Exception e) {
            return HttpResult.returnFail("性能指标数据查询失败");
        }
    }

    @ApiOperation("查询当前设备告警信息")
    @PostMapping("/alarmInfo/current")
    public HttpResult<PageInfo<AlarmInfo>> getAlarmInfo(@RequestBody AlarmInfoSearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询当前告警数据数据，分页参数存在问题！请检查传参！");
        }
        try {
            List<AlarmInfo> alarmInfos = deviceNodeDataService.getAlarmInfo(searchCondition);
            return HttpResult.returnSuccess(new PageInfo<>(alarmInfos));
        } catch (Exception e) {
            return HttpResult.returnFail("查询失败！,请稍后再试！");
        }
    }

    @ApiOperation("查询历史告警信息")
    @PostMapping("/alarmInfo/history")
    public HttpResult<PageInfo<AlarmInfo>> getHistoryAlarmInfo(@RequestBody AlarmInfoSearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询历史告警数据，分页参数存在问题！请检查传参！");
        }
        try {
            List<AlarmInfo> historyInfos = deviceNodeDataService.getHistoryInfo(searchCondition);
            return HttpResult.returnSuccess(new PageInfo<>(historyInfos));
        } catch (Exception e) {
            return HttpResult.returnFail("查询失败！,请稍后再试！");
        }
    }


    @ApiOperation("清除设备告警信息")
    @PostMapping("/delAlarmInfo")
    public HttpResult delAlarmInfo(@RequestBody List<Integer> ids) {
        if (CollectionUtil.isEmpty(ids)) {
            return HttpResult.returnFail("清除告警信息失败，缺少清除参数");
        }
        try {
            deviceNodeDataService.updateAlarmStatus(null, ids);
            return HttpResult.returnSuccess("清除告警信息成功！", true);
        } catch (Exception e) {
            log.error("清除告警信息失败", e);
            return HttpResult.returnFail("清除告警信息失败");
        }
    }

    @ApiOperation("插入拓扑配置")
    @PostMapping("/insertPicConfig")
    public HttpResult insertPicConfig(@RequestBody PicConfigModel picConfigModel) {
        if (picConfigModel == null || picConfigModel.getPic() == null || picConfigModel.getLocking() == null) {
            return HttpResult.returnFail("插入拓扑配置参数存在问题！请检查传参！");
        }
        try {
            dataAnalyseService.insertPicConfig(picConfigModel);
            return HttpResult.returnSuccess("拓扑配置成功", true);
        } catch (Exception e) {
            return HttpResult.returnFail("拓扑配置失败");
        }

    }

    @ApiOperation("更新拓扑配置")
    @PostMapping("/updatePicConfig")
    public HttpResult updatePicConfigByUserId(@RequestBody PicConfigModel picConfigModel) {
        if (picConfigModel == null || picConfigModel.getPic() == null || picConfigModel.getLocking() == null) {
            return HttpResult.returnFail("更新拓扑配置参数存在问题！请检查传参！");
        }
        try {
            dataAnalyseService.updatePicConfig(picConfigModel);
            return HttpResult.returnSuccess("拓扑配置更新成功", true);
        } catch (Exception e) {
            return HttpResult.returnFail("拓扑配置更新失败");
        }
    }

    @ApiOperation("查询拓扑配置")
    @GetMapping("/findPicConfig")
    public HttpResult findPicConfig() {
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findPicConfig());
        } catch (Exception e) {
            return HttpResult.returnFail("拓扑配置查询失败");
        }
    }

    @ApiOperation("统计sim卡使用情况")
    @GetMapping("/getSimCardInfo")
    public HttpResult<SimCardStatistic> getSimCardInfo(){
        return HttpResult.returnSuccess(dataAnalyseService.statisticSimCardInfo());
    }

    @ApiOperation("统计当日设备数据")
    @GetMapping("/findAllDeviceData")
    public HttpResult findAllDeviceData(){
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findAllDeviceData());
        } catch (Exception e) {
            return HttpResult.returnFail("当日设备数据统计失败");
        }
    }

    @ApiOperation("通过id查看告警详情")
    @GetMapping("/findAlarmInfoById/{id}")
    public HttpResult<AlarmInfo> findAlarmInfoById(@PathVariable("id") Integer id) {
        if (id == null) {
            return HttpResult.returnFail("参数是空！");
        }
        try {
            return HttpResult.returnSuccess(deviceNodeDataService.findAlarmInfoById(id));
        } catch (Exception e) {
            return HttpResult.returnFail("告警详情查询失败！");
        }

    }


    @ApiOperation("查询所有apiDoc")
    @GetMapping("/findAllApiDoc")
    public HttpResult findAllApiDoc(){
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findAllApiDoc());
        } catch (Exception e) {
            return HttpResult.returnFail("apiDoc查询失败");
        }
    }

    @ApiOperation("根据id查询apiDoc")
    @GetMapping("/findAllApiDocById/{id}")
    public HttpResult findAllApiDocById(@PathVariable("id") int id){
        try {
            return HttpResult.returnSuccess(dataAnalyseService.findApiDocById(id));
        } catch (Exception e) {
            return HttpResult.returnFail("apiDoc查询失败");
        }
    }



    @ApiOperation("告警信息概览")
    @GetMapping("/alarmInfoOverview/{type}")
    public HttpResult<AlarmOverviewVo> alarmInfoOverview(@PathVariable("type")Integer type) {
        if (type == null){
            return HttpResult.returnFail("参数为空，请传参！");
        }
        if (type == 0){
            return HttpResult.returnSuccess(dataAnalyseService.findCurrentAlarmInfo());
        } else if (type == 1){
            return HttpResult.returnSuccess(dataAnalyseService.findHistoryAlarmInfoOfDays(-7));
        } else if (type == 2){
            return HttpResult.returnSuccess(dataAnalyseService.findHistoryAlarmInfoOfDays(-30));
        } else {
            return HttpResult.returnFail("type参数不符合要求！");
        }
    }

}