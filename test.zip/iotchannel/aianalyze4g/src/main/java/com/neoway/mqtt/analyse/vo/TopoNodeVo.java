package com.neoway.mqtt.analyse.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 * 描述：拓扑节点返回
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 17:16
 */
@Data
public class TopoNodeVo implements Serializable {

    private static final long serialVersionUID = 6990411869747852092L;

    /**
     * 基站id
     */
    private String currentCellId;

    /**
     * imei
     */
    private List<String> imeis;


}
