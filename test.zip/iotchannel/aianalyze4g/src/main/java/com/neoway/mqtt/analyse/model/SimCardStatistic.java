package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: sim卡信息统计
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/8 14:09
 */
@Data
public class SimCardStatistic implements Serializable {
    private static final long serialVersionUID = -6052739487206991611L;
    private Integer simCardTotalNum;

    private Integer activeNum;

    private Integer todayOnlineNum;

    private Integer todayUsedNum;

    private Double todayOnlineRate;

    private Integer cmccCardNum;

    private Integer cuccCardNum;

    private Integer ctccCardNum;
}
