package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.util.Date;

/**
 * <pre>
 *  描述:派单信息实体类
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/23 16:01
 */
@Data
public class PatchInfo {

    private String id;

    private String imei;

    private int alarmType;

    private int identification;

    private String handlerName;

    private String dispatchTime;

    private String completionTime;

}
