package com.neoway.mqtt.analyse.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 * 描述：设备在线情况
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 14:38
 */
@Data
@ApiModel(value = "设备在线状态实体")
public class OnlineModel implements Serializable {
    private static final long serialVersionUID = 3281357516498560721L;

    @ApiModelProperty("设备总数")
    private Integer sumNum;

    @ApiModelProperty("在线设备数")
    private Integer onlineNum;

    @ApiModelProperty("在线率")
    private String rate;
}
