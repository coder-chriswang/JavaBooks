package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: sim卡信息实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/8 14:14
 */
@Data
public class SimCardInfoModel implements Serializable {
    private static final long serialVersionUID = 643605425824779286L;

    private String imei;

    private String operator;

    private Integer onlineNum;

    private Integer dataNum;

    private String authCode;
}
