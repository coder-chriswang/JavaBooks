package com.neoway.mqtt.analyse.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：性能指标值
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 19:48
 */
@Data
@ApiModel("性能指标值")
public class TopoCapabilityVo implements Serializable {
    private static final long serialVersionUID = 5037976114503046635L;
    @ApiModelProperty("信号功率")
    private Double rsrqValue;

    @ApiModelProperty("信号强度")
    private Double rsrpValue;

    @ApiModelProperty("信噪比")
    private Double sinrValue;

    @ApiModelProperty("deviceTime")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date deviceTime;

    @ApiModelProperty("nodeTime")
    private String nodeTime;
}
