package com.neoway.mqtt.analyse.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述:高德GeoCodeS
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/21 19:33
 */
@Data
public class GeoCodes implements Serializable {
    private static final long serialVersionUID = 6980962359315250644L;

    private String formatted_address;

    private String country;

    private String province;

    private String cityCode;

    private String district;

    private String adcode;

    private String street;

    private String number;

    private String location;

    private String level;
}
