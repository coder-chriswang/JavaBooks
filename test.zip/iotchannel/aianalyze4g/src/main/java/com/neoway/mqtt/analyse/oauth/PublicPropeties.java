package com.neoway.mqtt.analyse.oauth;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@Data
@ConfigurationProperties(prefix = "resources.path")
public class PublicPropeties {
    private String cert;
    private String whiteUri;
}
