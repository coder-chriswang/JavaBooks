package com.neoway.mqtt.analyse.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 告警概览VO
 * </pre>
 *
 * @author Adolf(wangjiaolong)
 * @version 1.0.0
 * @date 2020/7/20 10:41
 */
@Data
@ApiModel(value = "告警概览数据")
public class AlarmOverviewVo implements Serializable {

    private static final long serialVersionUID = 5890753520897301889L;

    @ApiModelProperty("告警总数")
    private int alarmSum;

    @ApiModelProperty("离线告警数量")
    private int offLineAlarmSum;

    @ApiModelProperty("离线告警占比")
    private double offLineAlarmRate;

    @ApiModelProperty("网络阻塞告警数量")
    private int networkBlockAlarmSum;

    @ApiModelProperty("网络阻塞告警占比")
    private double networkBlockAlarmRate;

    @ApiModelProperty("电源模块故障告警数量")
    private int powerModFailAlarmSum;

    @ApiModelProperty("电源模块故障告警占比")
    private double powerModFailAlarmRate;

    @ApiModelProperty("处理器模块故障告警数量")
    private int processorModFailAlarmSum;

    @ApiModelProperty("处理器模块故障告警占比")
    private double processorModFailAlarmRate;

    @ApiModelProperty("链路质量差告警数量")
    private int linkQuaPoorAlarmSum;

    @ApiModelProperty("链路质量差告警占比")
    private double linkQuaPoorAlarmRate;

    @ApiModelProperty("SIM卡故障告警数量")
    private int simCardFailAlarmSum;

    @ApiModelProperty("SIM卡故障告警占比")
    private double simCardFailAlarmRate;

    @ApiModelProperty("网络异常告警数量")
    private int networkAnomalyAlarmSum;

    @ApiModelProperty("网络异常告警占比")
    private double networkAnomalyAlarmRate;

    @ApiModelProperty("网络安全故障告警数量")
    private int networkSecurityFailAlarmSum;

    @ApiModelProperty("网络安全故障告警占比")
    private double networkSecurityFailAlarmRate;

    @ApiModelProperty("传感器模块故障告警数量")
    private int sensorModFailAlarmSum;

    @ApiModelProperty("传感器模块故障告警占比")
    private double sensorModFailAlarmRate;

    @ApiModelProperty("通讯模块故障告警数量")
    private int communicationModFailAlarmSum;

    @ApiModelProperty("通讯模块故障告警占比")
    private double communicationModFailAlarmRate;

    @ApiModelProperty("SIM卡欠费告警数量")
    private int simCardArrearsAlarmSum;

    @ApiModelProperty("SIM卡欠费告警占比")
    private double simCardArrearsAlarmRate;

    @ApiModelProperty("参数配置错误告警数量")
    private int paramConfigErrorAlarmSum;

    @ApiModelProperty("参数配置错误告警占比")
    private double paramConfigErrorAlarmRate;

}
