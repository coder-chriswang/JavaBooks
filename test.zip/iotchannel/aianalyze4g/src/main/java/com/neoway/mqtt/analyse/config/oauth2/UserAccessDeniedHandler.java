package com.neoway.mqtt.analyse.config.oauth2;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * <pre>
 *  描述: 用户认证后无权限访问资源异常
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/19 16:31
 */
@Component("userAccessDeniedHandler")
public class UserAccessDeniedHandler implements AccessDeniedHandler {

    @Autowired
   private ObjectMapper objectMapper;

    @Override
    public void handle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
                       AccessDeniedException e) throws IOException, ServletException {
        //设置响应格式
        httpServletResponse.setContentType("application/json;charset=UTF-8");
        //设置响应码
        final int badReqCode = 400;
        //设置响应体
        Map map = new HashMap();
        map.put("code", badReqCode);
        map.put("message", e.getMessage());
        map.put("path", httpServletRequest.getServletPath());
        httpServletResponse.setContentType("application/json");
        httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        httpServletResponse.getWriter().write(objectMapper.writeValueAsString(map));
    }
}
