package com.neoway.mqtt.analyse.service.impl;

import com.alibaba.fastjson.JSON;
import com.neoway.mqtt.analyse.model.ModuleDiagnoseParam;
import com.neoway.mqtt.analyse.service.CommandSendService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <pre>
 * 描述：命令下发service实现类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/20 19:49
 */
@Service
@Slf4j
public class CommandSendServiceImpl implements CommandSendService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

   @Override
    public String moduleDiagnoseSend(ModuleDiagnoseParam moduleDiagnoseParam) {
        log.info("下发远程诊断命令，imei = {}", moduleDiagnoseParam.getImei());
        Object resultObject = rabbitTemplate.convertSendAndReceive("4G_moduleSend","MQTT",JSON.toJSONString(moduleDiagnoseParam));
        return String.valueOf(resultObject);
    }
}
