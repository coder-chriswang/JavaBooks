package com.neoway.mqtt.analyse.redis;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：redis
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/6/22 19:58
 */
public interface EmqRedisDao {

    /**
     * 存储更新配置信息
     * @param value
     */
    void updateConfig(Map<String, String> value);

    /**
     * 查询唯一配置
     * @return
     */
    Map<String, String> findConfig();

    /**
     * 删除配置信息
     */
    void deleteConfig();

    /**
     * 查询观测性能周期数
     * @return
     */
    Map<String,String> findObservationTimeConfig();

    /**
     * 删除观测性能周期数
     */
    void deleteObservationTime();

    /**
     * 更新观测性能周期数信息
     * @param observationTimeMap
     */
    void updateObservationTime(Map<String, String> observationTimeMap);

    /**
     * 查询cellId
     * @return
     */
    Map<String, String> findCellIdInfo();

    /**
     * 存储更新cellId信息
     * @param refreshMap
     */
    void updateCellIdInfo(Map<String, String> refreshMap);

    /**
     * 存储更新IMEI号
     * @param imei
     */
    void updateImei(String[] imei);

    /**
     * 查询所有的imei
     * @return
     */
    List<String> findAllImei();

    /**
     *  状态位设置
     * @param id
     * @param statusBit
     */
    void updateStatusBit(String id, Map<String, String> statusBit);

    /**
     * 查询状态位
     * @param id
     * @return
     */
    Map<String, String> findStatusBit(String id);

    /**
     *  存储excel导入信息
     * @param id
     * @param map
     */
    void updateErrorInfo(String id, Map<String, String> map);

    /**
     * 获取excel导入信息
     * @param id
     * @return
     */

    Map<String,String> getExcelErrorInfo(String id);

    /**
     * 删除缓存中的imei号
     * @param imei
     */
    void deleteRedisImei(String imei);

}
