package com.neoway.mqtt.analyse.oauth;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <pre>
 *  描述: token验证响应体
 * </pre>
 *
 * @author Gavin yang(yangtuo)
 * @version 1.0.0
 * @date 2020/6/19 15:21
 */
@Data
@ApiModel("验证请求token响应体")
public class HttpTokenVo {

    @ApiModelProperty("响应码状态码")
    private int code;

    @ApiModelProperty("验证失败信息")
    private String message;

    public HttpTokenVo(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public static HttpTokenVo fail(int code,String message) {
        return new HttpTokenVo(code,message);
    }
}
