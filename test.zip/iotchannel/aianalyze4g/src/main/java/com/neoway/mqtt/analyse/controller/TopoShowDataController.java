package com.neoway.mqtt.analyse.controller;

import com.neoway.kernel.model.response.HttpResult;
import com.neoway.mqtt.analyse.model.TopoDataParams;
import com.neoway.mqtt.analyse.service.TopoShowDataService;
import com.neoway.mqtt.analyse.vo.TopoNodeDataVo;
import com.neoway.mqtt.analyse.vo.TopoNodeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <pre>
 * 描述：拓扑展示数据
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/7 14:07
 */
@RestController
@Slf4j
@RequestMapping("/data/topo")
@Api(tags = "topo数据展示" , description = "topo数据展示")
public class TopoShowDataController {

    @Autowired
    TopoShowDataService topoShowDataService;

    @ApiOperation("topo树状图显示")
    @PostMapping("/nodeTopoInfo")
    public HttpResult<List<TopoNodeVo>> nodeTopoInfo() {
        try {
            return HttpResult.returnSuccess(topoShowDataService.findTopoInfo());
        } catch (Exception e) {
            log.error("topo节点关系查询失败", e);
            return HttpResult.returnFail("topo节点关系查询失败");
        }
    }

    @ApiOperation("topo节点数据显示")
    @PostMapping("/nodeTopoData")
    public HttpResult<TopoNodeDataVo> nodeTopoData(@RequestBody TopoDataParams topoDataParams) {
        if (topoDataParams == null || StringUtils.isBlank(topoDataParams.getType())) {
            return HttpResult.returnFail("参数传递有误，请检查传参！");
        }
        try {
            if (StringUtils.equals("1",topoDataParams.getType())){
                return HttpResult.returnSuccess(topoShowDataService.findBaseStationData(topoDataParams.getCurrentCellId()));
            } else if (StringUtils.equals("2",topoDataParams.getType())){
                if (StringUtils.isBlank(topoDataParams.getImei())) {
                    return HttpResult.returnFail("参数传递有误，imei不能为空！");
                }
                return HttpResult.returnSuccess(topoShowDataService.findDeviceNodeData(topoDataParams.getImei()));
            } else {
                return HttpResult.returnFail("type参数不符合要求！");
            }
        } catch (Exception e) {
            log.error("topo节点关系查询失败", e);
            return HttpResult.returnFail("topo节点关系查询失败");
        }
    }
}
