package com.neoway.mqtt.analyse.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 规则设计文件Vo
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/7/21 11:09
 */
@Data
@ApiModel("规则设计文件Vo")
public class RuleDesignFileVo implements Serializable {
    private static final long serialVersionUID = -8074392680068613748L;

    private String id;

    private String file;

    @ApiModelProperty(value = "规则文件绝对路径", example = "C:/rule_design_test/告警规则.drl")
    private String filePath;

}
