package com.neoway.mqtt.analyse.rule.rule1;

import com.neoway.mqtt.analyse.bean.AlarmInfo;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;

/**
 * <pre>
 *  描述: Rule1 重要告警
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/06/10 13:56
 */
public class Rule1 {
    public static void main(final String[] args) {
        KieContainer kc = KieServices.Factory.get().getKieClasspathContainer();
        execute(kc);
    }

    private static void execute(KieContainer kc) {
        KieSession kiesession = kc.newKieSession("rule1_ksession");
        AlarmInfo a1 = new AlarmInfo(1, "严重的告警");
        AlarmInfo a2 = new AlarmInfo(2, "次要的告警");
        kiesession.insert(a1);
        kiesession.insert(a2);
        kiesession.fireAllRules();

        QueryResults results = kiesession.getQueryResults("alarmInfo");
        System.out.println("查询匹配的结果有" + results.size() + "条告警信息！");

        System.out.println("所有的告警信息是:");

        for (QueryResultsRow row : results) {
            AlarmInfo alarmInfo = (AlarmInfo) row.get("alarmInfo");
            System.out.println(alarmInfo.getAlarmType() + " " + alarmInfo.getAlarmDesc());
        }

        kiesession.dispose();
    }
}
