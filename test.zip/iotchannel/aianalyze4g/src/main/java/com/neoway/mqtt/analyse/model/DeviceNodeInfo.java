package com.neoway.mqtt.analyse.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 设备节点信息封装类
 * @author tuo.yang
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceNodeInfo {

    // 设备imei
    private String imei;

    private String currentCellId;

    private String operator;

    //节点名称
    private String nodeName;

    //网络制式
    private String netMode;
    //小区id
    private String cellId;

    //节点类型（暂无）
    private String nodeType;

    //通讯模组类型
    private String modeType;

    //SIM卡型号
    private String simType;

    //小区PCI
    private String cellPci;

    //网络状态
    private String networkStatus;

    //严重告警总数
    private int severeAlarmNo = 0;

    //平均lte信号功率
    private Double lteRsrq;

    //平均lte信噪比
    private Double lteSnr;

    //平均wcd信号功率
    private Double wcdRsrp;

    //平均wcd信噪比
    private Double wcdSnr;

    //上报时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",locale = "zh",timezone = "GMT+8")
    private Date upTime;
}
