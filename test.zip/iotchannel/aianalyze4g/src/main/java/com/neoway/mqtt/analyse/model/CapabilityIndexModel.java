package com.neoway.mqtt.analyse.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述:性能指标实体类
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/6/22 11:45
 */
@Data
public class CapabilityIndexModel implements Serializable {
    private static final long serialVersionUID = -5507676213229619149L;

    /**
     * 设备imei
     */
    private String imei;

    /**
     * 历史周期数据包（7天为一个周期）
     */
    private long historyDataPackageNum;

    /**
     * 是否达到历史数据包阈值
     */
    private boolean reachHistoryDataPackageNum;

    /**
     * 当前周期数据包（指当天）
     */
    private long currentDataPackageNum;

    /**
     * 是否达到当前数据包阈值
     */
    private boolean reachCurrentDataPackageNum;

    /**
     * 数据接收率
     */
    private double receivingRate;

    /**
     * 是否达到数据接收率阈值
     */
    private boolean reachReceivingRate;

    /**
     * 数据发送率
     */
    private double sendingRate;

    /**
     * 是否达到数据发送率阈值
     */
    private boolean reachSendingRate;

    /**
     * 延迟指数
     */
    private double delayIndex;

    /**
     * 是否达到延迟指数阈值
     */
    private boolean reachDelayIndex;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date upTime;
}
