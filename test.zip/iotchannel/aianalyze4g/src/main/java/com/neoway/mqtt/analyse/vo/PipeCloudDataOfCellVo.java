package com.neoway.mqtt.analyse.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：小区数据展示vo
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 14:13
 */
@Data
@ApiModel(value = "小区数据展示")
public class PipeCloudDataOfCellVo implements Serializable {
    private static final long serialVersionUID = -1716200682412039972L;
    @ApiModelProperty("imei")
    private String imei;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("小区信号强度")
    private String lteRSRP;

    @ApiModelProperty("信噪比")
    private String lteSINR;

    @ApiModelProperty("丢包率")
    private String losePkgRate = "0.00%";

    @ApiModelProperty("总流量")
    private String sumFlow;

    @ApiModelProperty("EPS附着成功率")
    private String epsSuccessRate;

    @ApiModelProperty("EPS平均附着时长")
    private String epsTime;

    @ApiModelProperty("小区切换频率")
    private String cellChangeRate;

    @ApiModelProperty("小区重选频率")
    private String cellReSleRate;

    @ApiModelProperty("用户面时延")
    private String userTimeDelay = "NA";

    @ApiModelProperty("小区地址")
    private String cellAddress;

    @ApiModelProperty("小区名")
    private String cellName;

    @ApiModelProperty("小区位置")
    private String cellLocations;

    @ApiModelProperty("运营商")
    private String operator;

    @ApiModelProperty("运营商1")
    private String operator1;

    @ApiModelProperty("运营商1接收功率")
    private String rsrpValue1;

    @ApiModelProperty("运营商1信噪比")
    private String snrValue1;

    @ApiModelProperty("运营商2")
    private String operator2;

    @ApiModelProperty("运营商2接收功率")
    private String rsrpValue2;

    @ApiModelProperty("运营商2信噪比")
    private String snrValue2;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("上报时间")
    private Date upTime;

    @ApiModelProperty("信号水平")
    private String signalLevel;

    @ApiModelProperty("运营商1信号等级描述")
    private String signalLevel1;

    @ApiModelProperty("运营商2信号等级描述")
    private String signalLevel2;
}
