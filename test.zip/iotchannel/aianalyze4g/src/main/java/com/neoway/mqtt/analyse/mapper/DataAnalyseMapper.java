package com.neoway.mqtt.analyse.mapper;

import com.neoway.mqtt.analyse.model.*;
import com.neoway.mqtt.analyse.vo.AlarmInfoVo;
import com.neoway.mqtt.analyse.vo.AlarmOverviewVo;
import com.neoway.mqtt.analyse.vo.ApiDocVo;
import com.neoway.mqtt.analyse.vo.CapabilityIndexVo;
import com.neoway.mqtt.analyse.vo.PipeCloudDataOfCellVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：数据分析mapper层
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/1 14:42
 */
@Mapper
public interface DataAnalyseMapper {

    /**
     * 通过imei号查询实体
     * @param imei imei
     * @return DeviceInfo
     */
    DeviceInfo findByImei(@Param("imei") String imei);

    /**
     * 查询在线实体数据
     * @param cellId
     * @return
     */
    OnlineModel findOnlineModel(@Param("cellId") String cellId);

    /**
     * 通过地址查询小区id
     *
     * @param address
     * @return
     */
    String findCellIdByAddress(@Param("address") String address);

    /**
     * 根据告警类型查询所有的告警信息
     * @param alarmType
     * @return
     */
    List<AlarmInfoVo> findAllAlarmInfo(@Param("alarmType") Integer alarmType);

    /**
     * 查询设备上报数据
     * @param imei
     * @param cellId
     * @param nowDate
     * @return
     */
    List<PipeCloudDataOfCellVo> findAllPipeCloudDataOfCell(@Param("imei") String imei, @Param("cellId") String cellId, @Param("nowDate") String nowDate);

    /**
     * 查询设备上报数据
     * @param imei
     * @param cellId
     * @param nowDate
     * @param operator
     * @return
     */
    List<PipeCloudDataOfCellVo> findV2AllPipeCloudDataOfCell(@Param("imei") String imei, @Param("cellId") String cellId, @Param("nowDate") String nowDate, @Param("operator") String operator);

    /**
     * 查询整体网络质量情况
     * @param cellId
     * @param nowDate
     * @return
     */
    List<NetChannelInfo> findAllNetChannelInfo(@Param("cellId") String cellId, @Param("nowDate") String nowDate);

    /**
     * 查询整体网络质量情况
     * @param cellId
     * @param nowDate
     * @return
     */
    List<NetChannelInfo> findV2AllNetChannelInfo(@Param("cellId") String cellId, @Param("nowDate") String nowDate);

    /**
     * 查询一天的消息时段数据
     *
     * @param cellId
     * @param time
     * @return
     */
    List<Map<String, Object>> findAllMsgInfoByDay(@Param("cellId") String cellId, @Param("time") String time);

    /**
     * 查询一周的消息时段数据
     *
     * @param cellId
     * @param fromDate
     * @param toDate
     * @return
     */
    List<Map<String, Object>> findAllMsgInfoByWeek(@Param("cellId") String cellId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /**
     * 查询当天网络信号
     *
     * @param time
     * @param cellId
     * @param plmnList
     * @return
     */
    List<NetSignalOfDay> findNetSignalByDay(@Param("time") String time, @Param("cellId") String cellId, @Param("plmnList") List<String> plmnList);

    /**
     * 查询一周的网络信号
     * @param fromDate
     * @param toDate
     * @param cellId
     * @param plmnList
     * @return
     */
    List<NetSignalOfDay> findNetSignalByDays(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("cellId") String cellId, @Param("plmnList") List<String> plmnList);

    /**
     * 查询一天的设备其他运营商的网络质量
     *
     * @param imei
     * @param nowDate
     * @return
     */
    OperatorNetScanInfo findOperatorNetScanInfo(@Param("imei") String imei, @Param("nowDate") String nowDate);

    /**
     * 查询最近一条上报网络数据
     *
     * @param imei
     * @return
     */
    NetReportInfoOfImei findNetReportInfoOfImei(@Param("imei") String imei);

    /**
     * 查询上报网络数据
     *
     * @param imei
     * @return
     */
    List<NetReportInfoOfImei> findAllNetReportInfoOfImei(@Param("imei") String imei);

    /**
     * 查询设备月网络质量
     *
     * @param imei
     * @param fromDate
     * @param nowDate
     * @param plmnList
     * @return
     */
    List<NetSignalOfImeiByMonth> findNetSignalOfImeiByMonth(@Param("imei") String imei, @Param("fromDate") Date fromDate, @Param("nowDate") Date nowDate, @Param("plmnList") List<String> plmnList);

    /**
     * 查询当前周期数据包
     * @param nowDate
     * @param imei
     * @return
     */
    List<DataPacket> findCurrentDataPacket(@Param("nowDate") String nowDate, @Param("imei") String imei);

    /**
     * 查询历史周期数据包（一周为一个历史周期）
     * @param fromDate
     * @param toDate
     * @param imei
     * @return
     */
    List<DataPacket> findHistoryDataPacket(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("imei") String imei);

    /**
     * 批量插入性能指标数据
     * @param capabilityIndexModel
     * @returni
     */
    int insertCapabilityIndexData(CapabilityIndexModel capabilityIndexModel);

    /**
     * 查询设备性能指标
     * @param capabilityIndex
     * @return
     */
    List<CapabilityIndexVo> findCapabilityIndexData(@Param("capabilityIndex") CapabilityIndexSearchCondition capabilityIndex);

    /**
     * 批量存储告警信息
     * @param list
     * @return
     */
    int batchInsertAlarmInfo(@Param("list") List<AlarmInfoModel> list);

    /**
     * 查询所有设备
     * @return
     */
    List<DeviceInfo> findAllDeviceInfo();

    /**
     * 更新离线状态
     *
     * @param imei 设备号
     * @param time 更新时间
     */
    void updateOfflineStatus(@Param("imei") String imei, @Param("time") Date time);

    /**
     * 存储离线告警
     *
     * @param alarmInfoModel
     */
    void insertOfflineAlarmInfo(@Param("alarmInfoModel") AlarmInfoModel alarmInfoModel);

    /**
     * 查询当前周期数据包数量
     * @param nowDate
     * @param imei
     * @return
     */
    List<DataPacket> findRxPacketsCounter(@Param("nowDate") String nowDate, @Param("imei") String imei);

    /**
     * 查询观测周期内的接收流量数据
     * @param observationTime
     * @param imei
     * @return
     */
    List<DataPacket> findRxPacketsCounterByObT(@Param("observationTime") int observationTime, @Param("imei") String imei);

    /**
     * 查询观测周期内的发送流量数据
     * @param observationTime
     * @param imei
     * @return
     */
    List<DataPacket> findTxPacketsCounterByObT(@Param("observationTime") int observationTime, @Param("imei") String imei);

    /**
     * 插入topo图片配置
     * @param picConfigModel
     * @return
     */
    int isnertPicConfig(@Param("picConfigModel") PicConfigModel picConfigModel);

    /**
     * 更新topo图片配置
     * @param picConfigModel
     * @return
     */
    int updatePicConfig(@Param("picConfigModel") PicConfigModel picConfigModel);

    /**
     * 通过userId获取topo配置
     * @return
     */
    PicConfigModel findPicConfig();

    /**
     * 查询当时sim卡相关信息
     * @param time
     * @return
     */
    List<SimCardInfoModel> findSimCardInfoList(@Param("time") String time);

    /**
     * 查询设备总体统数据量
     * @param time
     * @return
     */
    DeviceCensusModel findAllDeviceCensus(@Param("time") String time);

    /**
     * 查询设备当天在线状况
     * @return
     */
    DeviceOnlineCensusModel findAllDeviceOnlineCensus();

    /**
     * 查询所有ApiDoc
     * @return
     */
    List<ApiDocVo> findAllApiDoc();


    /**
     * 根据id查询piDoc
     * @return
     */
    ApiDocVo findApiDocById(int id);

    /**
     * 查询当前告警信息概览
     * @return
     */
    AlarmOverviewVo findCurrentAlarmInfo();

    /**
     * 查询历史告警信息
     * @param fromDate
     * @param toDate
     * @return
     */
    AlarmOverviewVo findHistoryAlarmInfoOfDays(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);
}
