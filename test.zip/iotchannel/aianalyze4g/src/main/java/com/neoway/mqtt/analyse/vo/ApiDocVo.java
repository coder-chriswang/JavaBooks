package com.neoway.mqtt.analyse.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 * 描述：开放api返回对象
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/7/20 14:44
 */
@Data
@ApiModel(value = "API文档")
public class ApiDocVo implements Serializable {
    private static final long serialVersionUID = 8072630507688559L;

    @ApiModelProperty(value = "Api标题", example = "查询设备信息")
    private String title;

    @ApiModelProperty(value = "主键id", hidden = true)
    private int id;

    @ApiModelProperty(value = "请求方式", example = "POST")
    private String requestMethod;

    @ApiModelProperty(value = "请求路由", example = "/channel/sqlmode/v1/data/device/deleteDeviceInfo")
    private String url;

    @ApiModelProperty(value = "请求参数", example = "imei")
    private String param;

    @ApiModelProperty(value = "开放状态", example = "0：开放")
    private int status;

    @ApiModelProperty(value = "描述")
    private String description;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

}

