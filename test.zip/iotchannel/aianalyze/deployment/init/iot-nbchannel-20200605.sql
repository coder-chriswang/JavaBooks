
USE `aidb`;
-- ----------------------------
-- Table structure for tbl_gasmeter_alarm
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_alarm`;
CREATE TABLE `tbl_gasmeter_alarm` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `imei` varchar(128) DEFAULT NULL COMMENT '设备imei号',
  `alarm_type` tinyint(2) DEFAULT '0' COMMENT '告警类型（0：离线；1：其他待补充）',
  `record_time` datetime DEFAULT NULL COMMENT '存储时间',
  `rsrp` varchar(64) DEFAULT NULL COMMENT 'rsrp',
  `snr` varchar(64) DEFAULT NULL COMMENT 'snr',
  `signal_level` varchar(64) DEFAULT NULL COMMENT '信号等级',
  `operator` varchar(64) DEFAULT NULL COMMENT '运营商',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=170995 DEFAULT CHARSET=utf8;
-- ----------------------------
-- Table structure for tbl_gasmeter_battery
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_battery`;
CREATE TABLE `tbl_gasmeter_battery` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `battery_type` varchar(64) DEFAULT NULL COMMENT '电池型号',
  `nominal_capacity` varchar(64) DEFAULT NULL COMMENT '标称容量',
  `nominal_voltage` varchar(64) DEFAULT NULL COMMENT '标称电压',
  `discharge_capacity` varchar(64) DEFAULT NULL COMMENT '放电容量',
  `load_voltage` varchar(64) DEFAULT NULL COMMENT '负载电压',
  `discharge_rate_year` varchar(64) DEFAULT '0' COMMENT '年自放电率',
  `max_discharge_current` varchar(64) DEFAULT NULL COMMENT '最大放电流量',
  `max_pulse_discharge_current` varchar(64) DEFAULT NULL COMMENT '最大脉冲放电电流',
  `end_voltage` varchar(64) DEFAULT NULL COMMENT '终止电压',
  `working_current` varchar(64) DEFAULT NULL COMMENT '工作电流',
  `standby_current` varchar(64) DEFAULT NULL COMMENT '待机电流',
  `complete_discharge_capacity` varchar(64) DEFAULT NULL COMMENT '完全放电能力系数',
  `matching_module` varchar(64) DEFAULT NULL COMMENT '配合模块',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8712 DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for tbl_gasmeter_config
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_config`;
CREATE TABLE `tbl_gasmeter_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` varchar(64) NOT NULL COMMENT '用户id，唯一键',
  `alarm_day_config` int(11) DEFAULT '5' COMMENT '告警配置天数，默认5天',
  `net_change_hour_config` int(11) DEFAULT '48' COMMENT '自动切网小时，默认48小时',
  `auto_net_change` tinyint(2) DEFAULT '0' COMMENT '自动切网开关，0为关闭，1为开启',
  `power_optimization` tinyint(2) DEFAULT '0' COMMENT '功耗优化开关，0为关闭，1为开启',
  `opening_time` varchar(64) DEFAULT NULL COMMENT '每日功耗优化开启时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`) USING BTREE COMMENT '唯一键',
  KEY `id` (`id`) USING BTREE COMMENT '主键'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table tbl_gasmeter_config 初始化数据
-- ----------------------------
INSERT INTO `tbl_gasmeter_config` (user_id,alarm_day_config,net_change_hour_config,auto_net_change,power_optimization,opening_time,create_time,update_time)
VALUES ("aaaaaa",20,37,1,1,"02:00","2020-03-04 17:07:23","2020-06-01 19:17:04");

-- ----------------------------
-- Table structure for tbl_gasmeter_current_misspeak
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_current_misspeak`;
CREATE TABLE `tbl_gasmeter_current_misspeak` (
  `miss_peak_id` varchar(32) NOT NULL COMMENT '错峰id',
  `miss_peak_result` text COMMENT '本次错峰结果',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`miss_peak_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

CREATE TABLE `tbl_gasmeter_current_netchange` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `net_change_data` text COMMENT '切网数据',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for tbl_gasmeter_data
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_data`;
CREATE TABLE `tbl_gasmeter_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `imei` varchar(64) DEFAULT NULL COMMENT 'IMEI号',
  `software_version` varchar(64) DEFAULT NULL COMMENT '软件版本',
  `hardware_version` varchar(64) DEFAULT NULL COMMENT '硬件版本',
  `basic_version` varchar(64) DEFAULT NULL COMMENT '基线版本',
  `longitude` varchar(64) DEFAULT NULL COMMENT '经度',
  `latitude` varchar(64) DEFAULT NULL COMMENT '纬度',
  `ccid` varchar(64) DEFAULT NULL COMMENT 'ccid',
  `imsi` varchar(64) DEFAULT NULL COMMENT 'imsi',
  `operator` varchar(64) DEFAULT NULL COMMENT '运营商',
  `earfcn` varchar(64) DEFAULT NULL COMMENT '频点',
  `map_cell_id` varchar(64) DEFAULT NULL COMMENT '小区id',
  `cell_id` varchar(64) DEFAULT NULL COMMENT '网络小区id',
  `pci` varchar(64) DEFAULT NULL COMMENT '物理小区id',
  `rsrp` varchar(64) DEFAULT NULL COMMENT '信号接收功率',
  `rsrq` varchar(64) DEFAULT NULL COMMENT '信号接收质量',
  `rssi` varchar(64) DEFAULT NULL COMMENT '信号强度指示',
  `snr` varchar(64) DEFAULT NULL COMMENT '信噪比',
  `ecl` varchar(64) DEFAULT NULL COMMENT '覆盖等级',
  `address` varchar(128) DEFAULT NULL COMMENT '小区地址',
  `base_station` varchar(128) DEFAULT NULL COMMENT '基站',
  `signal_level` varchar(16) DEFAULT NULL COMMENT '信号等级',
  `up_time` datetime DEFAULT NULL COMMENT '上报时间',
  `rrc` varchar(64) DEFAULT NULL COMMENT '接入成功数',
  `rrc_code` varchar(64) DEFAULT NULL COMMENT '接入失败原因',
  `rrc_sum` varchar(64) DEFAULT NULL COMMENT '接入总数',
  `work_count` varchar(32) DEFAULT NULL COMMENT '工作次数',
  `work_time` varchar(32) DEFAULT NULL COMMENT '工作总时长',
  `cost_time` int(11) DEFAULT '0' COMMENT '上一次上报花费的时间（单位:s）',
  PRIMARY KEY (`id`),
  KEY `imei` (`imei`) USING BTREE COMMENT 'imei',
  KEY `upTime` (`up_time`) USING BTREE COMMENT 'upTime',
  KEY `mapCellId` (`map_cell_id`) USING BTREE COMMENT 'mapCellId'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tbl_gasmeter_device_battery
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_device_battery`;
CREATE TABLE `tbl_gasmeter_device_battery` (
  `imei` varchar(64) NOT NULL COMMENT 'IMEI主键',
  `battery_type` varchar(64) DEFAULT NULL COMMENT '电池型号',
  `module_type` varchar(64) DEFAULT NULL COMMENT '模组型号',
  PRIMARY KEY (`imei`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tbl_gasmeter_misspeak_id
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_misspeak_id`;
CREATE TABLE `tbl_gasmeter_misspeak_id` (
  `id` varchar(32) NOT NULL COMMENT '错峰id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for tbl_gasmeter_misspeak_info
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_misspeak_info`;
CREATE TABLE `tbl_gasmeter_misspeak_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `miss_peak_id` varchar(32) NOT NULL COMMENT '错峰id',
  `imei` varchar(128) NOT NULL COMMENT 'imei号',
  `start_time` datetime DEFAULT NULL COMMENT '设备上报开始时间',
  `plan_time` datetime DEFAULT NULL COMMENT '设备上报计划结束时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_change` tinyint(2) DEFAULT '0' COMMENT '错峰时间是否更改 (0 :无改变)',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `imei` (`imei`) USING BTREE COMMENT 'imei号'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for tbl_gasmeter_misspeak_peroid
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_misspeak_peroid`;
CREATE TABLE `tbl_gasmeter_misspeak_peroid` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `start_time` datetime DEFAULT NULL COMMENT '预计开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '预计结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tbl_gasmeter_online
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_online`;
CREATE TABLE `tbl_gasmeter_online` (
  `imei` varchar(128) NOT NULL COMMENT '主键IMEI',
  `operator` varchar(128) DEFAULT NULL COMMENT '运营商',
  `map_cell_id` varchar(128) DEFAULT NULL COMMENT '地图小区id',
  `cell_name` varchar(255) DEFAULT NULL COMMENT '小区名称',
  `cell_locations` varchar(255) DEFAULT NULL COMMENT '小区gps',
  `cell_address` varchar(255) DEFAULT NULL COMMENT '小区物理位置',
  `building_address` varchar(255) DEFAULT NULL COMMENT '具体楼栋位置',
  `building_locations` varchar(255) DEFAULT NULL COMMENT '楼栋gps',
  `online` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1,在线；0,离线',
  `up_time` datetime DEFAULT NULL COMMENT '录入时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新设备时间',
  `oc_device_id` varchar(128) DEFAULT NULL COMMENT 'OC设备id',
  PRIMARY KEY (`imei`),
  KEY `imei` (`imei`) USING BTREE COMMENT 'imei'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for tbl_gasmeter_scan
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_scan`;
CREATE TABLE `tbl_gasmeter_scan` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `imei` varchar(64) DEFAULT NULL COMMENT 'imei号',
  `cell_id` varchar(64) DEFAULT NULL COMMENT '小区id',
  `software_version` varchar(64) DEFAULT NULL COMMENT '软件版本号',
  `hardware_version` varchar(64) DEFAULT NULL COMMENT '硬件版本号',
  `sim_card` varchar(64) DEFAULT NULL COMMENT '已有sim卡',
  `operator1` varchar(64) DEFAULT NULL COMMENT '运营商1',
  `arfcn11` varchar(64) DEFAULT NULL COMMENT 'ARFCN11',
  `rsrp11` varchar(64) DEFAULT NULL COMMENT 'RSRP11',
  `snr11` varchar(64) DEFAULT NULL COMMENT 'SNR11',
  `arfcn12` varchar(64) DEFAULT NULL COMMENT 'ARFCN12',
  `rsrp12` varchar(64) DEFAULT NULL COMMENT 'RSRP12',
  `snr12` varchar(64) DEFAULT NULL COMMENT 'SNR12',
  `arfcn13` varchar(64) DEFAULT NULL COMMENT 'ARFCN13',
  `rsrp13` varchar(64) DEFAULT NULL COMMENT 'RSRP13',
  `snr13` varchar(64) DEFAULT NULL COMMENT 'SNR13',
  `operator2` varchar(64) DEFAULT NULL COMMENT '运营商2',
  `arfcn21` varchar(64) DEFAULT NULL COMMENT 'ARFCN21',
  `rsrp21` varchar(64) DEFAULT NULL COMMENT 'RSRP21',
  `snr21` varchar(64) DEFAULT NULL COMMENT 'SNR21',
  `arfcn22` varchar(64) DEFAULT NULL COMMENT 'ARFCN22',
  `rsrp22` varchar(64) DEFAULT NULL COMMENT 'RSRP22',
  `snr22` varchar(64) DEFAULT NULL COMMENT 'SNR22',
  `arfcn23` varchar(64) DEFAULT NULL COMMENT 'ARFCN23',
  `rsrp23` varchar(64) DEFAULT NULL COMMENT 'RSRP23',
  `snr23` varchar(64) DEFAULT NULL COMMENT 'SNR23',
  `up_time` datetime DEFAULT NULL COMMENT '上报时间',
  PRIMARY KEY (`id`),
  KEY `imei` (`imei`) USING BTREE COMMENT 'imei',
  KEY `cellId` (`cell_id`) USING BTREE COMMENT 'cellId',
  KEY `upTime` (`up_time`) USING BTREE COMMENT 'upTime'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tbl_gasmeter_task
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_task`;
CREATE TABLE `tbl_gasmeter_task` (
  `id` varchar(64) NOT NULL COMMENT '主键任务id',
  `imeis` varchar(4096) DEFAULT NULL COMMENT '切网设备总数',
  `processing` tinyint(2) DEFAULT '0' COMMENT '任务是否结束,0进行中，1结束',
  `create_time` datetime DEFAULT NULL COMMENT '任务创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for tbl_gasmeter_voltage
-- ----------------------------
DROP TABLE IF EXISTS `tbl_gasmeter_voltage`;
CREATE TABLE `tbl_gasmeter_voltage` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `imei` varchar(128) DEFAULT NULL COMMENT 'imei号',
  `voltage` varchar(64) DEFAULT NULL COMMENT '电压值',
  `up_time` datetime DEFAULT NULL COMMENT '上报时间',
  PRIMARY KEY (`id`),
  KEY `imei` (`imei`) USING BTREE COMMENT 'imei索引',
  KEY `upTime` (`up_time`) USING BTREE COMMENT '上报时间索引'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for tbl_net_change_info
-- ----------------------------
DROP TABLE IF EXISTS `tbl_net_change_info`;
CREATE TABLE `tbl_net_change_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `imei` varchar(64) DEFAULT NULL COMMENT 'imei',
  `map_cell_id` varchar(64) DEFAULT NULL COMMENT '小区id',
  `source_operator` varchar(16) DEFAULT NULL COMMENT '原运营商',
  `source_snr` varchar(64) DEFAULT NULL COMMENT '原运营商SNR',
  `source_rsrp` varchar(64) DEFAULT NULL COMMENT '原运营商RSRP',
  `source_net_signal` varchar(16) DEFAULT NULL COMMENT '原网络质量',
  `target_operator` varchar(16) DEFAULT NULL COMMENT '目标运营商',
  `target_snr` varchar(64) DEFAULT NULL COMMENT '目标运营商SNR',
  `target_rsrp` varchar(64) DEFAULT NULL COMMENT '目标运营商RSRP',
  `target_net_signal` varchar(16) DEFAULT NULL COMMENT '目标网络质量',
  `result` tinyint(2) DEFAULT '1' COMMENT '切换网络结果（1成功，0失败）',
  `up_time` datetime DEFAULT NULL COMMENT '切换时间',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务id',
  `processed` tinyint(2) DEFAULT '0' COMMENT '是否处理过，0未处理，1已处理',
  PRIMARY KEY (`id`),
  KEY `up_time` (`up_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tbl_nw_channel
-- ----------------------------
DROP TABLE IF EXISTS `tbl_nw_channel`;
CREATE TABLE `tbl_nw_channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `app_id` varchar(32) DEFAULT NULL COMMENT '第三方应用Id',
  `secret_key` varchar(32) DEFAULT NULL COMMENT '秘钥',
  `app_name` varchar(32) DEFAULT NULL COMMENT '第三方应用名称',
  `active` tinyint(2) DEFAULT '0' COMMENT '是否生效（0:生效;1:失活）',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `expired_days` int(11) DEFAULT '7' COMMENT '有效天数，默认7天',
  PRIMARY KEY (`id`),
  KEY `appId` (`app_id`) USING BTREE COMMENT '第三方应用id',
  KEY `app_name` (`app_name`) USING BTREE COMMENT '第三方应用名称'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_nw_channel` (app_id,secret_key,app_name,active,create_time,update_time,expired_days)
VALUES ("yuehai","f82b53dae7a144828da9ac096b2f5974","yuehai",0,"2020-05-19 15:39:57",NULL ,180);