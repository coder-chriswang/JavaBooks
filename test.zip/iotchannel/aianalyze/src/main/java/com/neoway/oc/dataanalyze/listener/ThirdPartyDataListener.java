package com.neoway.oc.dataanalyze.listener;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.neoway.oc.dataanalyze.mapper.DeviceBatteryMapper;
import com.neoway.oc.dataanalyze.mapper.GasMeterMapper;
import com.neoway.oc.dataanalyze.mapper.MissPeakMapper;
import com.neoway.oc.dataanalyze.model.DeviceBatteryInfoModel;
import com.neoway.oc.dataanalyze.model.DeviceInfo;
import com.neoway.oc.dataanalyze.model.DevicePhysicalAddressModel;
import com.neoway.oc.dataanalyze.model.MissPeakPeroid;
import com.neoway.oc.dataanalyze.service.MissPeakService;
import com.neoway.oc.dataanalyze.service.NetChangeService;
import com.neoway.oc.dataanalyze.util.IdUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * <pre>
 *  描述: 监听第三方数据回调
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/05/19 9:04
 */
@Component
@Slf4j
public class ThirdPartyDataListener {

    @Autowired
    private MissPeakMapper missPeakMapper;

    @Autowired
    private DeviceBatteryMapper deviceBatteryMapper;

    @Autowired
    private GasMeterMapper gasMeterMapper;

    @Autowired
    private MissPeakService missPeakService;

    @Autowired
    private NetChangeService netChangeService;

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_order_netChangeDataQueue_yuehai", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_order_netChangeData", type = "direct", durable = "true"),
                    key = "yuehai")
    })
    public Object netChangeOrderData(String msg) {
        if (StringUtils.isBlank(msg)) {
            return null;
        }
        try {
            return netChangeService.findChangeNetResult();
        } catch (Exception e) {
            log.error("获取下行切网命令有误");
            return null;
        }
    }


    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_order_missPeakDataQueue_yuehai", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_order_missPeakData", type = "direct", durable = "true"),
                    key = "yuehai")
    })
    public Object missPeakTimeOrderData(String msg) {
        if (StringUtils.isBlank(msg)) {
            return null;
        }
        try {
            return missPeakService.findMissPeakResult();
        } catch (Exception e) {
            log.error("获取下行错峰数据有误");
            return null;
        }
    }


    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_devicePhysicalData_addQueue_yuehai", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_devicePhysicalData_add", type = "direct", durable = "true"),
                    key = "yuehai")
    })
    public void handleDevicePhysicalDataAdd(String msg) {
        if (StringUtils.isBlank(msg)) {
            return;
        }
        try {
            List<DevicePhysicalAddressModel> devicePhysicalModels = JSON.parseObject(msg, new TypeReference<List<DevicePhysicalAddressModel>>(){});
            if(CollectionUtils.isEmpty(devicePhysicalModels)) {
                log.error("传入的设备集合为空！请检查");
                return;
            }
            List<String> cellAddressList = gasMeterMapper.findCellAddress();
            List<DevicePhysicalAddressModel> devicePhysicalAddressModelList = CollectionUtil.newArrayList();
            for (DevicePhysicalAddressModel physicalModel : devicePhysicalModels) {
                DeviceInfo deviceInfo = gasMeterMapper.findDeviceInfoByImei(physicalModel.getImei());
                if (deviceInfo != null) {
                    log.info("该imei已存在，请不要重复插入！");
                    continue;
                }
                String address = physicalModel.getAddress() + physicalModel.getArea();
                if (cellAddressList.contains(address)) {
                    String cellId = gasMeterMapper.findCellIdByAddress(address);
                    physicalModel.setCellId(cellId);
                } else {
                    String cellId = IdUtil.getSeqID();
                    physicalModel.setCellId(cellId);
                }
                if (StringUtils.isBlank(physicalModel.getOperator())) {
                    physicalModel.setOperator("CMCC");
                }
                physicalModel.setUpTime(new Date());
                devicePhysicalAddressModelList.add(physicalModel);
            }
            if (CollectionUtils.isEmpty(devicePhysicalAddressModelList)) {
                log.error("要插入的集合为空!");
                return;
            }
            gasMeterMapper.batchInsertDevicePhysicalInfo(devicePhysicalAddressModelList);
            log.info("批量插入设备物理地址成功！");
        } catch (Exception e) {
            log.error("设备物理地址信息存储失败", e);
        }
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_devicePhysicalData_deleteQueue_yuehai", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_devicePhysicalData_delete", type = "direct", durable = "true"),
                    key = "yuehai")
    })
    public void handleDevicePhysicalDataDelete(String msg) {
        if (StringUtils.isBlank(msg)) {
            return;
        }
        try {
            List<DevicePhysicalAddressModel> devicePhysicalModels = JSON.parseObject(msg, new TypeReference<List<DevicePhysicalAddressModel>>(){});
            if (CollectionUtils.isEmpty(devicePhysicalModels)) {
                log.error("传入的设备集合为空！请检查");
                return;
            }
            gasMeterMapper.batchDeleteDevicePhysicalInfo(devicePhysicalModels);
            log.info("批量删除设备物理地址成功！");
        } catch (Exception e) {
            log.error("设备物理地址信息删除失败", e);
        }
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_devicePhysicalData_updateQueue_yuehai", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_devicePhysicalData_update", type = "direct", durable = "true"),
                    key = "yuehai")
    })
    public void handleDevicePhysicalDataUpdate(String msg) {
        if (StringUtils.isBlank(msg)) {
            return;
        }
        try {
            List<DevicePhysicalAddressModel> devicePhysicalModels = JSON.parseObject(msg, new TypeReference<List<DevicePhysicalAddressModel>>(){});
            if (CollectionUtils.isEmpty(devicePhysicalModels)) {
                log.error("传入的设备集合为空！请检查");
                return;
            }
            for (DevicePhysicalAddressModel physicalModel : devicePhysicalModels) {
                physicalModel.setUpdateTime(new Date());
            }
            gasMeterMapper.batchUpdateDevicePhysicalInfo(devicePhysicalModels);
            log.info("批量更新设备物理地址成功！");
        } catch (Exception e) {
            log.error("设备物理地址信息更新失败", e);
        }
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_deviceBatteryDataQueue_yuehai", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_deviceBatteryData", type = "direct", durable = "true"),
                    key = "yuehai")
    })
    public void handleDeviceBatteryData(String msg) {
        if (StringUtils.isBlank(msg)) {
            return;
        }
        try {
            List<DeviceBatteryInfoModel> deviceBatteryInfoModels = JSON.parseObject(msg, new TypeReference<List<DeviceBatteryInfoModel>>(){});
            if (CollectionUtils.isEmpty(deviceBatteryInfoModels)) {
                return;
            }
            deviceBatteryMapper.insertDeviceUpVoltageData(deviceBatteryInfoModels);
        } catch (Exception e) {
            log.error("存储设备电池数据存在异常！", e);
        }
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_missPeakTimeDataQueue_yuehai", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_missPeakTimeData", type = "direct", durable = "true"),
                    key = "yuehai")
    })
    public void handleMissPeakTimeData(String msg) {
        if (StringUtils.isBlank(msg)) {
            return;
        }
        try {
            MissPeakPeroid missPeakPeroid = JSON.parseObject(msg, new TypeReference<MissPeakPeroid>(){});
            if (missPeakPeroid == null) {
                return;
            }
            missPeakMapper.insertMissPeakPeroid(missPeakPeroid.getStartTime(), missPeakPeroid.getEndTime());
        } catch (Exception e) {
            log.error("存储错峰区间时间失败！", e);
        }

    }
}
