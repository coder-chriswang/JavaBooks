package com.neoway.oc.dataanalyze.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 配置新增模型
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/03 15:21
 */
@Data
@ApiModel("配置新增或更新模型")
public class ConfigAddOrUpdateParams implements Serializable {
    private static final long serialVersionUID = 5958673268599779844L;

    @ApiModelProperty("用户id")
    private String userId;

    @ApiModelProperty("告警配置时长，单位：天，默认5天")
    private Integer alarmDayConfig;

    @ApiModelProperty("自动切网配置时长，单位：小时，默认48")
    private Integer netChangeHourConfig;

    @ApiModelProperty("自动切网开关，默认为0，0关闭，1开启")
    private Integer autoNetChange;

    //tag  yangTuo

    @ApiModelProperty("开启功耗优化，默认为0,0关闭，1开启")
    private Integer powerOptimization;

    @ApiModelProperty("开启时间")
    private String openingTime;
}
