package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 小区设备上报展示信息
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/23 10:27
 */
@Data
@ApiModel("小区设备上报展示信息")
public class GasMeterInfoOfCell implements Serializable {
    private static final long serialVersionUID = 4340488210946406739L;

    @ApiModelProperty("设备IMEI号")
    private String imei;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("oc设备Id")
    private String ocDeviceId;

    @ApiModelProperty("参考信息接收功率")
    private String rsrp;

    @ApiModelProperty("信噪比")
    private String snr;

    @ApiModelProperty("运营商1")
    private String operator1;

    @ApiModelProperty("运营商1接收功率")
    private String rsrp1;

    @ApiModelProperty("运营商1信噪比")
    private String snr1;

    @ApiModelProperty("运营商2")
    private String opeator2;

    @ApiModelProperty("运营商2接收功率")
    private String rsrp2;

    @ApiModelProperty("运营商2信噪比")
    private String snr2;

    @ApiModelProperty("小区地址")
    private String cellAddress;

    @ApiModelProperty("小区名称")
    private String cellName;

    @ApiModelProperty("楼栋地址")
    private String buildingAddress;

    @ApiModelProperty("小区经纬度信息")
    private String cellLocations;

    @ApiModelProperty("运营商")
    private String operator;

    @ApiModelProperty("上报时间")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date upTime;

    @ApiModelProperty("信号等级描述（好，良，差）")
    private String signalLevel;

    @ApiModelProperty("运营商1信号等级描述（好，良，差）")
    private String signalLevel1;

    @ApiModelProperty("运营商2信号等级描述（好，良，差）")
    private String signalLevel2;
}
