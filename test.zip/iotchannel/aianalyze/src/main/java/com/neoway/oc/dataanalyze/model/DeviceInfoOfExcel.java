package com.neoway.oc.dataanalyze.model;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 设备信息导出实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/12/12 9:40
 */
@Data
public class DeviceInfoOfExcel implements Serializable {
    private static final long serialVersionUID = 5187503485701314727L;
    @ExcelProperty(value = {"日期", "日期"}, index = 0)
    private Date date;
    @ExcelProperty(value = {"基本信息", "设备序列号"}, index = 1)
    private String imei;
    @ExcelProperty(value = {"基本信息", "物理位置"}, index = 2)
    private String address;
    @ExcelProperty(value = {"基本信息", "经度"}, index = 3)
    private String longitude;
    @ExcelProperty(value = {"基本信息", "纬度"}, index = 4)
    private String latitude;
    @ExcelProperty(value = {"基本信息", "所属小区"}, index = 5)
    private String cellName;
    @ExcelProperty(value = {"模组信息", "软件版本"}, index = 6)
    private String softwareVersion;
    @ExcelProperty(value = {"模组信息", "硬件版本"}, index = 7)
    private String hardwareVersion;
    @ExcelProperty(value = {"模组信息", "基线版本"}, index = 8)
    private String basicVersion;
    @ExcelProperty(value = {"SIM卡信息", "CCID"}, index = 9)
    private String ccid;
    @ExcelProperty(value = {"SIM卡信息", "IMSI"}, index = 10)
    private String imsi;
    @ExcelProperty(value = {"SIM卡信息", "当前运营商"}, index = 11)
    private String operator;
    @ExcelProperty(value = {"SIM卡信息", "信号等级"}, index = 12)
    private String signalLevel;
    @ExcelProperty(value = {"网络信息", "EARFCN(频点)"}, index = 13)
    private String earfcn;
    @ExcelProperty(value = {"网络信息", "CELL_ID(小区ID)"}, index = 14)
    private String netCellId;
    @ExcelProperty(value = {"网络信息", "PCI(物理小区)"}, index = 15)
    private String pci;
    @ExcelProperty(value = {"网络信息", "RSRP(参考信号接收功率)"}, index = 16)
    private String rsrp;
    @ExcelProperty(value = {"网络信息", "RSRQ(参考信号接收质量)"}, index = 17)
    private String rsrq;
    @ExcelProperty(value = {"网络信息", "RSSI(接收信号强度指示)"}, index = 18)
    private String rssi;
    @ExcelProperty(value = {"网络信息", "SINR(信噪比)"}, index = 19)
    private String sinr;
    @ExcelProperty(value = {"网络信息", "ECL(覆盖等级)"}, index = 20)
    private String ecl;
}
