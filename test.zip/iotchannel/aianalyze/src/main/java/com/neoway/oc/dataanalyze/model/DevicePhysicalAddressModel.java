package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 设备物理地址信息
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/04/09 10:39
 */
@Data
public class DevicePhysicalAddressModel implements Serializable {
    private static final long serialVersionUID = -9066769181418901596L;

    /**
     * IMEI号
     */
    private String imei;

    /**
     * 物理地址
     */
    private String address;

    /**
     * 小区信息
     */
    private String area;

    /**
     * 经纬度
     */
    private String coordinate;

    /**
     * 运营商
     */
    private String operator;

    /**
     * 在线状态
     */
    private Integer online;

    /**
     * 小区id
     */
    private String cellId;

    /**
     * 具体楼栋地址
     */
    private String buildingAddress;

    /**
     * 楼栋经纬度
     */
    private String buildingLocations;

    /**
     * 上报数据时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date upTime;

    /**
     * 更新数据时间
     */
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
}
