package com.neoway.oc.dataanalyze.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 录入设备参数实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/21 19:53
 */
@Data
@ApiModel("录入设备参数实体")
public class DeviceParam implements Serializable {
    private static final long serialVersionUID = -4400903488289422736L;

    @ApiModelProperty("设备IMEI号")
    private String imei;

    @ApiModelProperty("小区名称")
    private String cellName;

    @ApiModelProperty("小区物理地址")
    private String cellAddress;

    @ApiModelProperty("具体楼栋地址")
    private String buildingAddress;
}
