package com.neoway.oc.dataanalyze.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 分页基础传参实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/20 15:44
 */
@Data
@ApiModel("分页基础传参实体")
public class BasedPageParams implements Serializable {
    private static final long serialVersionUID = -8060941844105827672L;
    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页面显示数")
    private Integer pageSize;
}
