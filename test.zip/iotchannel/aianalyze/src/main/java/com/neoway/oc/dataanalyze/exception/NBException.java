package com.neoway.oc.dataanalyze.exception;

/**
 * <pre>
 *  描述: 自定义异常
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/17 11:46
 */
public class NBException extends RuntimeException {
    private static final long serialVersionUID = -8267960965875869940L;

    public NBException(String message) {
        super(message);
    }
}
