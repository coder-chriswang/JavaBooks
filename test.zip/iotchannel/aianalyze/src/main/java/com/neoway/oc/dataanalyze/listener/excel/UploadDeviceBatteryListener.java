package com.neoway.oc.dataanalyze.listener.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.excel.exception.ExcelDataConvertException;
import com.alibaba.fastjson.JSON;
import com.neoway.oc.dataanalyze.mapper.DeviceBatteryMapper;
import com.neoway.oc.dataanalyze.mapper.GasMeterMapper;
import com.neoway.oc.dataanalyze.model.DeviceBatteryModelOfExcel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 上传设备电池信息listener
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/20 13:10
 */
@Slf4j
public class UploadDeviceBatteryListener extends AnalysisEventListener<DeviceBatteryModelOfExcel> {

    private DeviceBatteryMapper deviceBatteryMapper;

    private GasMeterMapper gasMeterMapper;
    /**
     * 每隔5条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 5;

    private static final String COLUMN_NAME_0 = "设备编号";
    private static final String COLUMN_NAME_1 = "模组型号";
    private static final String COLUMN_NAME_2 = "电池型号";

    List<DeviceBatteryModelOfExcel> list = new ArrayList<>();

    private Boolean hasStart = false;

    public UploadDeviceBatteryListener(DeviceBatteryMapper deviceBatteryMapper, GasMeterMapper gasMeterMapper) {
        this.deviceBatteryMapper = deviceBatteryMapper;
        this.gasMeterMapper = gasMeterMapper;
    }

    @Override
    public void invoke(DeviceBatteryModelOfExcel deviceBatteryModelOfExcel, AnalysisContext analysisContext) {
        if (!hasStart) {
            log.error("表头数据为空！");
            throw new ExcelAnalysisException("Excel模板标题是空！请下载模板进行数据导入！");
        }
        if (deviceBatteryModelOfExcel == null) {
            log.error("数据为空！");
            return;
        }
        if (gasMeterMapper.findOnlineInfoByImei(deviceBatteryModelOfExcel.getImei()) == null) {
            log.error("系统无此设备信息！");
            return;
        }
        if (deviceBatteryMapper.findBatteryModelByType(deviceBatteryModelOfExcel.getBatteryType()) == null) {
            log.error("系统无此电池类型！");
            return;
        }

        // yangTuo 修改tag
        if (deviceBatteryMapper.findBatteryModelByModuleType(deviceBatteryModelOfExcel.getModuleType()) == null) {
            log.error("系统无此模组信息！");
            return;
        }
        // 添加对象
        list.add(deviceBatteryModelOfExcel);
        if (list.size() >= BATCH_COUNT) {
            deviceBatteryMapper.batchInsertDeviceAndBatteryInfo(list);
            // 存储完清理数组
            list.clear();
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        deviceBatteryMapper.batchInsertDeviceAndBatteryInfo(list);
        log.info("所有数据解析导入完成！");
    }

    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        hasStart = true;
        log.info("解析到一条头数据:{}", JSON.toJSONString(headMap));
        if (CollectionUtils.isEmpty(headMap) || headMap.size() == 0) {
            throw new ExcelAnalysisException("Excel模板标题是空！");
        }
        String columnName0 = headMap.get(0);
        if (!COLUMN_NAME_0.equals(columnName0)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName0 + " 与 设备编号不匹配");
        }
        // yangTuo 修改tag
        String columnName1 = headMap.get(1);
        if (!COLUMN_NAME_1.equals(columnName1)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName1 + "与 模组编号不匹配");
        }
        String columnName2 = headMap.get(2);
        if (!COLUMN_NAME_2.equals(columnName2)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName1 + " 与 电池型号不匹配");
        }


    }

    @Override
    public void onException(Exception exception, AnalysisContext context) {
        log.error("解析导入失败，问题是:{}", exception.getMessage());
        if (exception instanceof ExcelDataConvertException) {
            ExcelDataConvertException excelDataConvertException = (ExcelDataConvertException) exception;
            log.error("第{}行，第{}列解析异常，数据为:{}", excelDataConvertException.getRowIndex(),
                    excelDataConvertException.getColumnIndex(), excelDataConvertException.getCellData());
        }
        throw new ExcelAnalysisException(exception.getMessage());
    }
}
