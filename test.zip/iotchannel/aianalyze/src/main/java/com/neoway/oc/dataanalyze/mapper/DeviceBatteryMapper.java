package com.neoway.oc.dataanalyze.mapper;

import com.neoway.oc.dataanalyze.model.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 设备电池Mapper
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/20 13:13
 */
@Mapper
public interface DeviceBatteryMapper {

    /**
     * 批量存入设备电池信息
     *
     * @param list
     */
    void batchInsertDeviceAndBatteryInfo(@Param("list") List<DeviceBatteryModelOfExcel> list);

    /**
     * 批量存入电池信息
     *
     * @param list
     */
    void batchInsertBatteryInfo(@Param("list") List<BatteryModelOfExcel> list);

    /**
     * 查询所有的电池信息
     *
     * @return list
     */
    List<BatteryModel> findAllBatteryInfo();

    /**
     * 批量删除电池信息
     *
     * @param ids
     */
    void deleteBatteryInfoByIds(@Param("ids") List<Integer> ids);

    /**
     * 查询此次删除操作中是否存在绑定的设备信息
     *
     * @param ids
     * @return
     */
    int findCountByBatteryInfoIds(@Param("ids") List<Integer> ids);

    /**
     * 查询设备电池列表
     *
     * @param cellId
     * @param time
     * @param imei
     * @return
     */
    List<PowerDataInfo> findAllPowerDataInfosByCellId(@Param("cellId") String cellId, @Param("time") String time, @Param("imei") String imei);

    /**
     * 查询系统分布
     *
     * @param cellId
     * @return
     */
    List<Map<String, Object>> findSystemDistribution(@Param("cellId") String cellId);

    /**
     * 通过类型查找电池信息
     *
     * @param batteryType
     * @return
     */
    BatteryModel findBatteryModelByType(@Param("batteryType") String batteryType);

    /**
     * 通过模组类型查找电池信息
     * @param moduleType
     * @return
     */
    BatteryModel findBatteryModelByModuleType(@Param("moduleType") String moduleType);

    /**
     * 存储上报的电压值数据
     * @param deviceBatteryInfoModels
     */
    void insertDeviceUpVoltageData(@Param("list") List<DeviceBatteryInfoModel> deviceBatteryInfoModels);

}
