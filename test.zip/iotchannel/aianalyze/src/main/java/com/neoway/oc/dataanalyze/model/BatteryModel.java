package com.neoway.oc.dataanalyze.model;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 电池型号实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/20 16:19
 */
@Data
@ApiModel("电池型号实体")
public class BatteryModel implements Serializable {

    private static final long serialVersionUID = -8969642934894986606L;

    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("电池型号")
    private String batteryType;

    @ApiModelProperty("标称容量(Ah)")
    private String nominalCapacity;

    @ApiModelProperty("标称电压(V)")
    private String nominalVoltage;

    @ApiModelProperty("放电容量(Ah)")
    private String dischargeCapacity;

    @ApiModelProperty("负载电压(V)")
    private String loadVoltage;

    @ApiModelProperty("年自放电率(%)")
    private String dischargeRateYear;

    @ApiModelProperty("最大放电电流(mA)")
    private String maxDischargeCurrent;

    @ApiModelProperty("最大脉冲放电电流(mA)")
    private String maxPulseDischargeCurrent;

    /**
     * yangTuo 修改tag
     */
    @ApiModelProperty("终止电压(V)")
    private String endVoltage;
    @ApiModelProperty("工作电流(mA)")
    private String workingCurrent;
    @ApiModelProperty("待机电流(mA)")
    private String standbyCurrent;
    @ApiModelProperty("完全能力放电系数(%)")
    private String completeDischargeCapacity;
    @ApiModelProperty("配合模块")
    private String matchingModule;
}
