package com.neoway.oc.dataanalyze.controller;

import com.github.pagehelper.PageInfo;
import com.neoway.oc.dataanalyze.exception.NBException;
import com.neoway.oc.dataanalyze.model.BasedPageParams;
import com.neoway.oc.dataanalyze.model.SearchCondition;
import com.neoway.oc.dataanalyze.service.PowerOptimizeService;
import com.neoway.oc.dataanalyze.util.HttpResult;
import com.neoway.oc.dataanalyze.vo.PowerDataVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <pre>
 *  描述: 功耗优化Controller
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/20 10:50
 */
@RestController
@RequestMapping("/power/optimize")
@Slf4j
@Api(tags = "功耗优化", description = "功耗优化")
public class PowerOptimizeController {

    @Autowired
    private PowerOptimizeService powerOptimizeService;

    @ApiOperation("导出设备电池信息模板")
    @PostMapping("/exportDeviceBatteryModel")
    public void exportDeviceBatteryModel(HttpServletResponse response) {
        powerOptimizeService.exportDeviceBatteryModel(response);
    }

    @ApiOperation("导出电池信息模板")
    @PostMapping("/exportBatteryModel")
    public void exportBatteryModel(HttpServletResponse response) {
        powerOptimizeService.exportBatteryInfoModel(response);
    }

    @ApiOperation("查询所有电池信息")
    @PostMapping("/findAllBatteryInfo")
    public HttpResult<PageInfo> findAllBatteryInfo(@RequestBody BasedPageParams basedPageParams) {
        if (basedPageParams == null || basedPageParams.getPageNum() == null || basedPageParams.getPageSize() == null) {
            return HttpResult.returnFail("参数存在错误！");
        }
        return HttpResult.returnSuccess(new PageInfo<>(powerOptimizeService.findAllBatteryInfo(basedPageParams)));
    }

    @ApiOperation("导入设备电池信息")
    @PostMapping("/uploadDeviceBattery")
    public HttpResult uploadDeviceBattery(MultipartFile file) {
        try {
            powerOptimizeService.uploadDeviceBatteryData(file);
            return HttpResult.returnSuccess("导入数据成功！", true);
        } catch (NBException e) {
            log.error("导入数据失败！", e);
            return HttpResult.returnFail(e.getMessage());
        } catch (MultipartException e) {
            log.error("导入数据失败！", e);
            return HttpResult.returnFail("文件大小不能超过20M！");
        } catch (Exception e) {
            log.error("导入数据失败！", e);
            return HttpResult.returnFail("导入数据失败！");
        }
    }

    @ApiOperation("导入电池信息")
    @PostMapping("/uploadBattery")
    public HttpResult uploadBattery(MultipartFile file) {
        try {
            powerOptimizeService.uploadBatteryData(file);
            return HttpResult.returnSuccess("导入数据成功！", true);
        } catch (NBException e) {
            log.error("导入数据失败！", e);
            return HttpResult.returnFail(e.getMessage());
        } catch (MultipartException e) {
            log.error("导入数据失败！", e);
            return HttpResult.returnFail("文件大小不能超过20M！");
        } catch (Exception e) {
            log.error("导入数据失败！", e);
            return HttpResult.returnFail("导入数据失败！");
        }
    }

    @ApiOperation("批量删除电池信息")
    @PostMapping("/batchDeleteBatteryData")
    public HttpResult deleteBatteryDataByIds(@RequestBody List<Integer> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return HttpResult.returnFail("参数ids数组为空!");
        }
        try {
            powerOptimizeService.batchDeleteBatteryData(ids);
            return HttpResult.returnSuccess("删除成功！", true);
        } catch (NBException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("获取功耗优化页面整体信息")
    @PostMapping("/fetchPowerData")
    public HttpResult<PowerDataVo> fetchPowerData(@RequestBody SearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageSize() == null || searchCondition.getPageNum() == null) {
            return HttpResult.returnFail("分页参数存在问题!");
        }
        return HttpResult.returnSuccess(powerOptimizeService.getPowerData(searchCondition));
    }
}
