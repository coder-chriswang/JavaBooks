package com.neoway.oc.dataanalyze.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 设备与电池型号导入导出模板
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/19 9:34
 */
@Data
@ContentRowHeight(15)
@HeadRowHeight(20)
@ColumnWidth(25)
public class DeviceBatteryModelOfExcel implements Serializable {
    private static final long serialVersionUID = -2890761351622917829L;
    @ExcelProperty(value = "设备编号", index = 0)
    private String imei;
    /**
     * yangTuo 修改tag
     */
    @ExcelProperty(value = "模组型号",index = 1)
    private String moduleType;
    @ExcelProperty(value = "电池型号", index = 2)
    private String batteryType;
}
