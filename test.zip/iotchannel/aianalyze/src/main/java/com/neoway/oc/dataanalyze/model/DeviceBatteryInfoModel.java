package com.neoway.oc.dataanalyze.model;

import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 设备电压信息实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/04/10 13:45
 */
@Data
public class DeviceBatteryInfoModel implements Serializable {
    private static final long serialVersionUID = 1985582592157953699L;

    /**
     * IMEI号
     */
    private String imei;

    /**
     * 电压值
     */
    private String voltage;

    /**
     * 时间
     */
    private String time;
}
