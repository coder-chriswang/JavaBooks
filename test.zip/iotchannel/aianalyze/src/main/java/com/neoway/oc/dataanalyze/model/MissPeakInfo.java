package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * <pre>
 * 描述：错峰算法返回实体类
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/8 16:27
 */
@Data
public class MissPeakInfo implements Serializable {
    private static final long serialVersionUID = 4663921313825983801L;

    private String imei;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date planTime;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MissPeakInfo)) {
            return false;
        }
        MissPeakInfo timeInfo = (MissPeakInfo) o;
        return Objects.equals(imei, timeInfo.imei);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imei);
    }
}
