package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 设备基础信息
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/17 9:50
 */
@Data
@ApiModel("设备基础信息")
public class DeviceInfo implements Serializable {
    private static final long serialVersionUID = 1452947578010910434L;

    @ApiModelProperty("设备IMEI号")
    private String imei;

    @ApiModelProperty("设备OC平台id")
    private String ocDeviceId;

    @ApiModelProperty("在线状态 1:在线，0:离线")
    private Integer online;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("小区名称")
    private String cellName;

    @ApiModelProperty("小区物理地址")
    private String cellAddress;

    @ApiModelProperty("小区经纬度")
    private String cellLocations;

    @ApiModelProperty("具体楼栋地址")
    private String buildingAddress;

    @ApiModelProperty("上报数据时间")
    private Date upTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("更新设备时间")
    private Date updateTime;
}
