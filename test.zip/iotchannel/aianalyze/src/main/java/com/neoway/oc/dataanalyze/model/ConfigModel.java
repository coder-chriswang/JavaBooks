package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 配置类模型
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/03 15:12
 */
@Data
@ApiModel("配置类模型")
public class ConfigModel implements Serializable {
    private static final long serialVersionUID = -4391159321957575413L;

    @ApiModelProperty("主键id")
    private Integer id;

    @ApiModelProperty("用户id")
    private String userId;

    @ApiModelProperty("告警配置时长，单位：天，默认5天")
    private Integer alarmDayConfig;

    @ApiModelProperty("自动切网配置时长，单位：小时，默认48")
    private Integer netChangeHourConfig;

    @ApiModelProperty("自动切网开关，默认为0，0关闭，1开启")
    private Integer autoNetChange;

    //tag yangTuo

    @ApiModelProperty("功耗优化开关，0为关闭，1为开启")
    private Integer powerOptimization;

    @ApiModelProperty("每日功耗优化开启时间")
    private String openingTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("添加配置时间")
    private Date createTime;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("更新配置时间")
    private Date updateTime;

}
