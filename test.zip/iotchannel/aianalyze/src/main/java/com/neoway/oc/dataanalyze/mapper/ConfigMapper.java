package com.neoway.oc.dataanalyze.mapper;

import com.neoway.oc.dataanalyze.model.ConfigAddOrUpdateParams;
import com.neoway.oc.dataanalyze.model.ConfigModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <pre>
 *  描述: 配置Mapper
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/03 15:39
 */
@Mapper
public interface ConfigMapper {

    /**
     * 新增配置
     *
     * @param configAddParams
     */
    void addConfig(@Param("configAddParams") ConfigAddOrUpdateParams configAddParams);

    /**
     * 更新配置
     *
     * @param configUpdateParams
     */
    void updateConfig(@Param("configUpdateParams") ConfigAddOrUpdateParams configUpdateParams);

    /**
     * 查询配置信息
     *
     * @param userId
     * @return
     */
    ConfigModel findByUserId(@Param("userId") String userId);


    /**
     * 查询唯一配置
     *
     * @return
     */
    ConfigModel findOne();
}
