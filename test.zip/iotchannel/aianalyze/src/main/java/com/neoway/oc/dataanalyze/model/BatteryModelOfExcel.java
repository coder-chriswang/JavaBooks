package com.neoway.oc.dataanalyze.model;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 电池信息导入导出模板
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/19 9:41
 */
@Data
@ContentRowHeight(15)
@HeadRowHeight(20)
@ColumnWidth(25)
@ApiModel("电池信息实体")
public class BatteryModelOfExcel implements Serializable {
    private static final long serialVersionUID = -6973824003132738884L;
    @ExcelProperty(value = "电池型号", index = 0)
    @ApiModelProperty("电池型号")
    private String batteryType;
    @ExcelProperty(value = "标称容量(Ah)", index = 1)
    @ApiModelProperty("标称容量(Ah)")
    private String nominalCapacity;
    @ExcelProperty(value = "标称电压(V)", index = 2)
    @ApiModelProperty("标称电压(V)")
    private String nominalVoltage;
    @ExcelProperty(value = "放电容量(Ah)", index = 3)
    @ApiModelProperty("放电容量(Ah)")
    private String dischargeCapacity;
    @ExcelProperty(value = "负载电压(V)", index = 4)
    @ApiModelProperty("负载电压(V)")
    private String loadVoltage;
    @ExcelProperty(value = "年自放电率(%)", index = 5)
    @ApiModelProperty("年自放电率(%)")
    private String dischargeRateYear;
    @ExcelProperty(value = "最大放电电流(mA)", index = 6)
    @ApiModelProperty("最大放电电流(mA)")
    private String maxDischargeCurrent;
    @ExcelProperty(value = "最大脉冲放电电流(mA)", index = 7)
    @ApiModelProperty("最大脉冲放电电流(mA)")
    private String maxPulseDischargeCurrent;

    /**
     * yangTuo 修改tag
     */
    @ExcelProperty(value = "终止电压(V)",index = 8)
    @ApiModelProperty("中止电压(V)")
    private String endVoltage;
    @ExcelProperty(value = "工作电流(mA)",index = 9)
    @ApiModelProperty("工作电流(mA)")
    private String workingCurrent;
    @ExcelProperty(value = "待机电流(mA)",index = 10)
    @ApiModelProperty("待机电流(mA)")
    private String standbyCurrent;
    @ExcelProperty(value = "完全能力放电系数(%)",index = 11)
    @ApiModelProperty("完全能力放电系数(%)")
    private String completeDischargeCapacity;
    @ExcelProperty(value = "配合模块",index = 12)
    @ApiModelProperty("配合模块")
    private String matchingModule;
}
