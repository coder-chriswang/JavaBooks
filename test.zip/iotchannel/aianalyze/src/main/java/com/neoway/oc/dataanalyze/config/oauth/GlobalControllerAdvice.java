package com.neoway.oc.dataanalyze.config.oauth;


import com.neoway.oc.dataanalyze.oauth.HttpTokenVo;
import com.neoway.oc.dataanalyze.oauth.UserErrorEnum;
import com.neoway.oc.dataanalyze.util.HttpResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletResponse;

/**
 * 全局异常处理
 */
@Slf4j
@RestControllerAdvice
public class GlobalControllerAdvice {

    /**
     * 参数类型转换异常
     */
    @ExceptionHandler(value = HttpMessageConversionException.class)
    public HttpResult parameterTypeExceptionHandler(HttpMessageConversionException ex) {
        return HttpResult.returnFail(ex.getCause().getLocalizedMessage());
    }

    /**
     * 认证失败返回结果
     */
    @ExceptionHandler({AuthenticationException.class})
    public HttpResult authenticationException(Exception ex, HttpServletResponse response) {
        HttpResult httpResult = resolveException(ex);
        response.setStatus(200);
        return httpResult;
    }

    /**
     * 静态解析异常。可以直接调用
     */
    public static HttpResult resolveException(Exception ex) {
        UserErrorEnum userErrorEnum = null;
        String className = ex.getClass().getName();
        log.debug("className is {}", className);
         if (className.contains("InsufficientAuthenticationException")
            || className.contains("AuthenticationCredentialsNotFoundException")) {
            userErrorEnum = UserErrorEnum.TOKEN_EXPIRE;
        } else if (className.contains("InvalidTokenException")) {
            userErrorEnum = UserErrorEnum.REFRESH_TOKEN_EXPIRE;
        }
        return buildBody(userErrorEnum);
    }

    /**
     * 构建返回结果对象
     */
    private static HttpResult buildBody(UserErrorEnum userErrorEnum) {
        if (userErrorEnum == null) {
            userErrorEnum = UserErrorEnum.SERVER_FIRST_ERROR;
        }
        //自定义httpResult内容
        HttpResult httpResult = HttpResult.returnSuccess
                ("fail",new HttpTokenVo(userErrorEnum.getCode(),userErrorEnum.getMessage()));
        return httpResult;
    }


}
