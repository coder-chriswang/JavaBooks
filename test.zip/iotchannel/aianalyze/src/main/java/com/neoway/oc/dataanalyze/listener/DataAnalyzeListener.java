package com.neoway.oc.dataanalyze.listener;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.neoway.oc.dataanalyze.constants.Constant;
import com.neoway.oc.dataanalyze.exception.NBException;
import com.neoway.oc.dataanalyze.mapper.ConfigMapper;
import com.neoway.oc.dataanalyze.mapper.GasMeterMapper;
import com.neoway.oc.dataanalyze.mapper.TaskMapper;
import com.neoway.oc.dataanalyze.model.*;
import com.neoway.oc.dataanalyze.model.pipe.NeopipeData;
import com.neoway.oc.dataanalyze.model.pipe.OtherNetworkModel;
import com.neoway.oc.dataanalyze.model.pipe.SimChangeModel;
import com.neoway.oc.dataanalyze.redis.NbRedisDao;
import com.neoway.oc.dataanalyze.util.IdUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 监听回调接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/14 14:12
 */
@Component
@Slf4j
public class DataAnalyzeListener {

    /**
     * 分隔符
     */
    private static final String SPLIT_STR = ";";

    @Autowired
    private GasMeterMapper gasMeterMapper;

    @Autowired
    private NbRedisDao nbRedisDao;

    @Autowired
    private ConfigMapper configMapper;

    @Autowired
    private TaskMapper taskMapper;

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_infoReportQueue_oc", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_infoReport", type = "direct", durable = "true"),
                    key = "oc")
    })
    public void analyzeData(String message) {
        log.info("消息队列---处理DeviceInfo数据，message={}", message);
        Map<String, String> deviceInfoMap = JSON.parseObject(message, new TypeReference<Map<String, String>>() {
        });
        String deviceId = deviceInfoMap.get("deviceId");
        String deviceData = deviceInfoMap.get("info");
        handleInfo(deviceData, deviceId);
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_netScanQueue_oc", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_netScan", type = "direct", durable = "true"),
                    key = "oc")
    })
    public void analyzeNetScanInfo(String message) {
        log.info("消息队列---处理netScanInfo数据，message={}", message);
        Map<String, String> netScanInfoMap = JSON.parseObject(message, new TypeReference<Map<String, String>>() {
        });
        String deviceId = netScanInfoMap.get("deviceId");
        log.info("deviceId = {}", deviceId);
        String netScanData = netScanInfoMap.get("scanInfo");
        handleNetScanInfo(netScanData);
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "gasMeter_configAckQueue_oc", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "gasMeter_configAck", type = "direct", durable = "true"),
                    key = "oc")
    })
    public void analyzeConfigSetAck(String message) {
        log.info("消息队列---处理configAckInfo数据，message={}", message);
        Map<String, String> configAckInfoMap = JSON.parseObject(message, new TypeReference<Map<String, String>>() {
        });
        String deviceId = configAckInfoMap.get("deviceId");
        String configAckData = configAckInfoMap.get("configAckInfo");
        handleAutoNetChange(deviceId, configAckData);
        // 比对是否存在下发切网相关信息
        Map<String, String> ackMap = nbRedisDao.findNetSetResultByOcDeviceId(deviceId);
        // 不存在手动下发切网参数，则直接返回，不进行结果存储
        if (CollectionUtils.isEmpty(ackMap) || StringUtils.isBlank(ackMap.get("simInfo"))) {
            return;
        }
        Map<String, String> resultMap = new HashMap<>(1);
        resultMap.put("configAckInfo", configAckData);
        // 将结果缓存至redis
        nbRedisDao.updateNetSet(deviceId, resultMap);
    }

    @RabbitListener(bindings = {
            @org.springframework.amqp.rabbit.annotation.QueueBinding(
                    value = @org.springframework.amqp.rabbit.annotation.Queue(value = "a2b_gasMeter_infoReportQueue_oc", durable = "true"),
                    exchange = @org.springframework.amqp.rabbit.annotation.Exchange(value = "a2b_gasMeter_infoReport", type = "direct", durable = "true"),
                    key = "oc")
    })
    public void analyze16Data(String message) {
        log.info("消息队列---处理A2B数据，message={}", message);
        Map<String, String> a2bDataMap = JSON.parseObject(message, new TypeReference<Map<String, String>>() {
        });
        String deviceId = a2bDataMap.get("deviceId");
        String neopipeData = a2bDataMap.get("neopipeData");
        try {
            handleNeopipeData(deviceId, neopipeData);
        } catch (NBException e) {
            log.error(e.getMessage());
        }
    }

    /**
     * 处理上报的数据
     *
     * @param info 数据（字段以分号分隔）
     */
    private void handleInfo(String info, String deviceId) {
        String[] infoStr = info.split(SPLIT_STR);
        String imei = infoStr[3];
        log.info("设备IMEI={}", imei);
        String longitude = infoStr[4];
        String latitude = infoStr[5];
        String rrcStr = infoStr[17];
        String[] rrcStrSplit = rrcStr.split("/");
        String rrc = rrcStrSplit[0];
        String rrcSum = rrcStrSplit[1];
        GasMeterData gasMeterData = new GasMeterData();
        gasMeterData.setUpTime(new Date());
        try {
            gasMeterData.setSoftwareVersion(infoStr[0]);
            gasMeterData.setHardwareVersion(infoStr[1]);
            gasMeterData.setBasicVersion(infoStr[2]);
            gasMeterData.setImei(imei);
            gasMeterData.setLongitude(longitude);
            gasMeterData.setLatitude(latitude);
            gasMeterData.setCcid(infoStr[6]);
            gasMeterData.setImsi(infoStr[7]);
            gasMeterData.setOperator(infoStr[8]);
            gasMeterData.setEarfcn(infoStr[9]);
            gasMeterData.setNetCellId(infoStr[10]);
            gasMeterData.setPci(infoStr[11]);
            gasMeterData.setRsrp(infoStr[12]);
            gasMeterData.setRsrq(infoStr[13]);
            gasMeterData.setRssi(infoStr[14]);
            gasMeterData.setSnr(infoStr[15]);
            gasMeterData.setEcl(infoStr[16]);
            gasMeterData.setRrc(rrc);
            gasMeterData.setRrcSum(rrcSum);
            gasMeterData.setRrcCode(infoStr[18]);
            // 网络等级
            handleNetQuality(infoStr[12], infoStr[15], gasMeterData);
            // 网络告警处理
            insertNetAlarm(gasMeterData);
            log.info("存储上报数据！");
            // 存储数据
            OnlineInfo onlineInfoBefore = gasMeterMapper.findOnlineInfoByImei(imei);
            if (onlineInfoBefore == null) {
                DeviceInfo deviceInfo = new DeviceInfo();
                deviceInfo.setImei(imei);
                deviceInfo.setCellId(IdUtil.getSeqID());
                deviceInfo.setOnline(1);
                deviceInfo.setUpTime(new Date());
                deviceInfo.setOcDeviceId(deviceId);
                gasMeterMapper.insertOnlineInfo(deviceInfo);
            } else {
                gasMeterMapper.updateOnlineInfo(imei, 1, new Date(), gasMeterData.getOperator());
            }
            OnlineInfo onlineInfo = gasMeterMapper.findOnlineInfoByImei(imei);
            gasMeterData.setCellId(onlineInfo.getCellId());
            gasMeterMapper.insertData(gasMeterData);
        } catch (Exception e) {
            log.error("存储失败！", e);
        }
    }

    /**
     * 处理扫网上报数据
     *
     * @param netScanData
     */
    private void handleNetScanInfo(String netScanData) {
        try {
            String[] netScanInfoStr = netScanData.split(SPLIT_STR);
            int netScanInfoStrSize = netScanInfoStr.length;
            String softwareVersion = netScanInfoStr[0];
            String hardwareVersion = netScanInfoStr[1];
            String imei = netScanInfoStr[2];
            log.info("imei={},处理网络扫描数据", imei);
            String simCard = netScanInfoStr[3];
            String[] operator1Str;
            String[] operator2Str;
            NetScanInfo netScanInfo = new NetScanInfo();
            if (netScanInfoStrSize >= 5) {
                operator1Str = netScanInfoStr[4].split(",");
                // 组装数据
                String operator1 = operator1Str[0];
                String arfcn11 = operator1Str[1];
                String rsrp11 = operator1Str[2];
                String snr11 = operator1Str[3];
                String arfcn12 = operator1Str[4];
                String rsrp12 = operator1Str[5];
                String snr12 = operator1Str[6];
                String arfcn13 = operator1Str[7];
                String rsrp13 = operator1Str[8];
                String snr13 = operator1Str[9];
                netScanInfo.setOperator1(operator1);
                netScanInfo.setArfcn11(arfcn11);
                netScanInfo.setRsrp11(rsrp11);
                netScanInfo.setSnr11(snr11);
                netScanInfo.setArfcn12(arfcn12);
                netScanInfo.setRsrp12(rsrp12);
                netScanInfo.setSnr12(snr12);
                netScanInfo.setArfcn13(arfcn13);
                netScanInfo.setRsrp13(rsrp13);
                netScanInfo.setSnr13(snr13);
            }
            if (netScanInfoStrSize >= 6) {
                operator2Str = netScanInfoStr[5].split(",");
                String operator2 = operator2Str[0];
                String arfcn21 = operator2Str[1];
                String rsrp21 = operator2Str[2];
                String snr21 = operator2Str[3];
                String arfcn22 = operator2Str[4];
                String rsrp22 = operator2Str[5];
                String snr22 = operator2Str[6];
                String arfcn23 = operator2Str[7];
                String rsrp23 = operator2Str[8];
                String snr23 = operator2Str[9];
                netScanInfo.setOperator2(operator2);
                netScanInfo.setArfcn21(arfcn21);
                netScanInfo.setRsrp21(rsrp21);
                netScanInfo.setSnr21(snr21);
                netScanInfo.setArfcn22(arfcn22);
                netScanInfo.setRsrp22(rsrp22);
                netScanInfo.setSnr22(snr22);
                netScanInfo.setArfcn23(arfcn23);
                netScanInfo.setRsrp23(rsrp23);
                netScanInfo.setSnr23(snr23);
            }
            netScanInfo.setUpTime(new Date());
            netScanInfo.setSoftwareVersion(softwareVersion);
            netScanInfo.setHardwareVersion(hardwareVersion);
            netScanInfo.setImei(imei);
            netScanInfo.setSimCard(simCard);
            OnlineInfo onlineInfo = gasMeterMapper.findOnlineInfoByImei(imei);
            netScanInfo.setCellId(onlineInfo.getCellId());
            log.info("存储扫网上数据");
            gasMeterMapper.insertNetScanInfo(netScanInfo);
        } catch (Exception e) {
            log.error("存储扫网数据失败！", e);
        }

    }

    /**
     * 判断网络状态
     *
     * @param rsrp         信号接收功率
     * @param snr          信噪比
     * @param gasMeterData 数据对象
     */
    private void handleNetQuality(String rsrp, String snr, GasMeterData gasMeterData) {
        double rsrpValue = Double.valueOf(rsrp);
        double snrValue = Double.valueOf(snr);
        if (rsrpValue >= -105 && snrValue >= 7) {
            gasMeterData.setSignalLevel("畅通");
        } else if (rsrpValue < -115 || snrValue < -3) {
            gasMeterData.setSignalLevel("异常");
        } else {
            gasMeterData.setSignalLevel("缓慢");
        }
    }

    /**
     * 存储网络告警拥堵和缓慢的告警
     *
     * @param gasMeterData
     */
    private void insertNetAlarm(GasMeterData gasMeterData) {
        if (StringUtils.equals("缓慢", gasMeterData.getSignalLevel())) {
            gasMeterMapper.insertAlarmInfo(gasMeterData, 1, new Date());
        }
        if (StringUtils.equals("异常", gasMeterData.getSignalLevel())) {
            gasMeterMapper.insertAlarmInfo(gasMeterData, 2, new Date());
        }
        if (StringUtils.equals("畅通", gasMeterData.getSignalLevel())) {
            handleNetAlarmInfo(gasMeterData.getImei());
        }
    }

    /**
     * 清理相关网络告警信息
     *
     * @param imei
     */
    private void handleNetAlarmInfo(String imei) {
        ConfigModel configModel = configMapper.findOne();
        String userId;
        if (configModel == null) {
            userId = "Neoway2020";
        } else {
            userId = configModel.getUserId();
        }
        try {
            Map<String, String> netAlarmInfoMap = nbRedisDao.findNetAlarmInfoByUserId(userId);
            if (CollectionUtils.isEmpty(netAlarmInfoMap)) {
                return;
            }
            String dataJson = netAlarmInfoMap.get("netAlarmInfo");
            List<NetAlarmInfo> resultList = Lists.newArrayList();
            List<NetAlarmInfo> netAlarmInfos = JSON.parseObject(dataJson, new TypeReference<List<NetAlarmInfo>>() {
            });
            for (NetAlarmInfo netAlarmInfo : netAlarmInfos) {
                if (!imei.equals(netAlarmInfo.getImei())) {
                    resultList.add(netAlarmInfo);
                }
            }
            Map<String, String> resultMap = Maps.newHashMap();
            resultMap.put("netAlarmInfo", JSON.toJSONString(resultList));
            nbRedisDao.updateNetAlarmInfo(userId, resultMap);
        } catch (Exception e) {
            log.error("网络告警信息清除存在问题！", e);
        }
    }

    private void handleAutoNetChange(String deviceId, String configAckData) {
        Map<String, String> autoAckMap = nbRedisDao.findAutoNetSetResultByOcDeviceId(deviceId);
        if (CollectionUtils.isEmpty(autoAckMap)) {
            return;
        }
        // 删除缓存
        nbRedisDao.deleteAutoNetSetByOcDeviceId(deviceId);
        String taskId = autoAckMap.get("taskId");
        String operator = autoAckMap.get("operator");
        long netChangeInfoId = Long.valueOf(autoAckMap.get("netChangeInfoId"));
        String imei = autoAckMap.get("imei");
        NetChangeTaskModel netChangeTaskModel = taskMapper.findOneById(taskId);
        if (netChangeTaskModel == null || netChangeTaskModel.getProcessing() == 1) {
            return;
        }
        String imeis = netChangeTaskModel.getImeis();
        if (!imeis.contains(imei)) {
            return;
        }
        if (StringUtils.equals("0", configAckData)) {
            gasMeterMapper.updateResultOfNetChange(netChangeInfoId, 0);
        } else {
            // 更新网络切卡结果
            gasMeterMapper.updateResultOfNetChange(netChangeInfoId, 1);
            // 切卡成功，则更新设备operator数据
            gasMeterMapper.updateDeviceOperator(deviceId, operator);
        }
        int imeiNum = imeis.split(",").length;
        int processedNum = gasMeterMapper.findProcessedNumByTaskId(taskId);
        // 已处理的切网设备数与切网预计总数相同，则更新任务状态为结束值1
        if (imeiNum == processedNum) {
            netChangeTaskModel.setProcessing(1);
            taskMapper.update(netChangeTaskModel);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void handleNeopipeData(String ocDeviceId, String neopipeDataStr) {
        try {
            NeopipeData neopipeData = JSON.parseObject(neopipeDataStr, new TypeReference<NeopipeData>(){});
            if (neopipeData == null || StringUtils.isBlank(neopipeData.getTotalLength())) {
                log.error("管道云数据为空！");
                return;
            }
            String model = replaceU0(neopipeData.getModel());
            neopipeData.setModel(model);
            String imei = ignoreFirstZeroCase(neopipeData.getImei());
            neopipeData.setImei(imei);
            String imsi = ignoreFirstZeroCase(neopipeData.getImsi());
            neopipeData.setImsi(imsi);
            String imsiOperator = imsi.substring(0,5);
            if (Constant.ImsiMappingEnum.CMCC.getCode().contains(imsiOperator)) {
                neopipeData.setOperator(Constant.ImsiMappingEnum.CMCC.getDesc());
            } else if (Constant.ImsiMappingEnum.CUCC.getCode().contains(imsiOperator)) {
                neopipeData.setOperator(Constant.ImsiMappingEnum.CUCC.getDesc());
            } else if (Constant.ImsiMappingEnum.CTCC.getCode().contains(imsiOperator)) {
                neopipeData.setOperator(Constant.ImsiMappingEnum.CTCC.getDesc());
            } else {
                neopipeData.setOperator(Constant.UNKNOWN);
            }
            // 存储本身网络信息
            insertBasicData(neopipeData, ocDeviceId);
            // 存储扫网信息
            String otherNetworkSwitch = neopipeData.getOtherNetworkSwitch();
            if (Constant.ONE_STR.equals(otherNetworkSwitch)) {
                insertOtherNetworkData(neopipeData.getOtherNetwork(), imei);
            }
            // 处理切网返回数据信息
            String simChangeSwitch = neopipeData.getSimChangeSwitch();
            if (Constant.ONE_STR.equals(simChangeSwitch)) {
                handleNetChangeResult(neopipeData.getSimChange(), ocDeviceId);
            }
        } catch (Exception e) {
            log.error("处理管道云上报数据存在问题！", e);
            throw new NBException("处理管道云上报数据存在问题！");
        }


    }

    private String replaceU0(String s) {
        return s.replaceAll(Constant.U0_STR, Constant.BLANK_STR);
    }

    private String ignoreFirstZeroCase(String s) {
        return s.substring(0, 1).equalsIgnoreCase(Constant.ZERO_STR) ? s.substring(1) : s;
    }

    private void insertBasicData(NeopipeData neopipeData, String ocDeviceId) {
        String imei = neopipeData.getImei();
        handleBasicNetQuality(neopipeData);
        insertBasicNetAlarm(neopipeData);
        neopipeData.setUpTime(new Date());
        OnlineInfo onlineInfoBefore = gasMeterMapper.findOnlineInfoByImei(imei);
        if (onlineInfoBefore == null) {
            DeviceInfo deviceInfo = new DeviceInfo();
            deviceInfo.setImei(imei);
            deviceInfo.setCellId(IdUtil.getSeqID());
            deviceInfo.setOnline(1);
            deviceInfo.setUpTime(new Date());
            deviceInfo.setOcDeviceId(ocDeviceId);
            gasMeterMapper.insertOnlineInfo(deviceInfo);
        } else {
            gasMeterMapper.updateOnlineInfo(imei, 1, new Date(), neopipeData.getOperator());
        }
        OnlineInfo onlineInfo = gasMeterMapper.findOnlineInfoByImei(imei);
        neopipeData.setMapCellId(onlineInfo.getCellId());
        // 计算工作时长
        NetReportInfoOfImei netReportInfoOfImei = gasMeterMapper.findNetReportInfoOfImei(imei);
        try {
            if (netReportInfoOfImei != null && StringUtils.isNotBlank(netReportInfoOfImei.getWorkTime())) {
                int workTime = Integer.valueOf(neopipeData.getWorkTime());
                int lastWorkTime = Integer.valueOf(netReportInfoOfImei.getWorkTime());
                neopipeData.setCostTime(workTime - lastWorkTime);
            } else {
                neopipeData.setCostTime(0);
            }
        } catch (Exception e) {
            log.error("计算设备工作时间类型转化错误！");
            neopipeData.setCostTime(0);
        }
        log.info("16-存储设备基本网络数据！");
        gasMeterMapper.insertBasicData(neopipeData);
    }

    private void insertOtherNetworkData(String otherNetwork, String imei) {
        OtherNetworkModel otherNetworkModel = JSON.parseObject(otherNetwork, new TypeReference<OtherNetworkModel>(){});
        if (otherNetworkModel == null || StringUtils.isBlank(otherNetworkModel.getCurrentSim())) {
            log.error("扫网数据有误！");
            return;
        }
        OnlineInfo onlineInfo = gasMeterMapper.findOnlineInfoByImei(imei);
        otherNetworkModel.setMapCellId(onlineInfo.getCellId());
        log.info("16-存储扫网的网络数据！");
        gasMeterMapper.insertOtherNetworkInfo(otherNetworkModel, imei, new Date());
    }

    private void handleNetChangeResult(String simChangeInfo, String ocDeviceId) {
        SimChangeModel simChangeModel = JSON.parseObject(simChangeInfo, new TypeReference<SimChangeModel>(){});
        if (simChangeModel == null || StringUtils.isBlank(simChangeModel.getResult())) {
            log.error("切网返回数据有误！");
            return;
        }
        String result = simChangeModel.getResult();
        // 比对是否存在下发切网相关信息
        Map<String, String> ackMap = nbRedisDao.findNetSetResultByOcDeviceId(ocDeviceId);
        // 不存在手动下发切网参数，则直接返回，不进行结果存储
        if (CollectionUtils.isEmpty(ackMap) || StringUtils.isBlank(ackMap.get("simInfo"))) {
            return;
        }
        Map<String, String> resultMap = new HashMap<>(1);
        resultMap.put("result", result);
        // 将结果缓存至redis
        nbRedisDao.updateNetSet(ocDeviceId, resultMap);
    }


    private void handleBasicNetQuality(NeopipeData neopipeData) {
        double rsrpValue = Double.valueOf(neopipeData.getRsrp());
        double snrValue = Double.valueOf(neopipeData.getNeoSnr());
        if (rsrpValue >= -105 && snrValue >= 7) {
            neopipeData.setSignalLevel("畅通");
        } else if (rsrpValue < -115 || snrValue < -3) {
            neopipeData.setSignalLevel("异常");
        } else {
            neopipeData.setSignalLevel("缓慢");
        }
    }

    private void insertBasicNetAlarm(NeopipeData neopipeData) {
        if (StringUtils.equals("缓慢", neopipeData.getSignalLevel())) {
            gasMeterMapper.insertBasicAlarmInfo(neopipeData, 1, new Date());
        }
        if (StringUtils.equals("异常", neopipeData.getSignalLevel())) {
            gasMeterMapper.insertBasicAlarmInfo(neopipeData, 2, new Date());
        }
        if (StringUtils.equals("畅通", neopipeData.getSignalLevel())) {
            handleNetAlarmInfo(neopipeData.getImei());
        }
    }
}
