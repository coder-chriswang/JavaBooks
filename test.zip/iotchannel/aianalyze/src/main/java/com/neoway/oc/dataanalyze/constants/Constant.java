package com.neoway.oc.dataanalyze.constants;

/**
 * <pre>
 *  描述: analyze工程常量接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/04/23 10:00
 */
public interface Constant {

    String ZERO_STR = "0";

    String ONE_STR = "1";

    String U0_STR = "[\u0000]";

    String BLANK_STR = "";

    String UNKNOWN = "UNKNOWN";
    /**
     * 运营商与IMSI映射
     */
    enum ImsiMappingEnum {
        CMCC("46000,46002,46004,46007,46008","CMCC"),
        CUCC("46001,46006,46009,46010","CUCC"),
        CTCC("46003,46005,46011,46012,46013,46015","CTCC"),
        ;

        ImsiMappingEnum(String code, String desc) {
            this.code = code;
            this.desc = desc;
        }

        private String code;
        private String desc;

        public String getCode() {
            return code;
        }

        public String getDesc() {
            return desc;
        }
    }

    String OS = System.getProperty("os.name").toLowerCase();

    static boolean isWindows() {
        return Constant.OS.contains("windows");
    }
}
