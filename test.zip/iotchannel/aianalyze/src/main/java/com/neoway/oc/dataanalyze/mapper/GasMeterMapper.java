package com.neoway.oc.dataanalyze.mapper;

import com.neoway.oc.dataanalyze.model.*;
import com.neoway.oc.dataanalyze.model.pipe.NeopipeData;
import com.neoway.oc.dataanalyze.model.pipe.OtherNetworkModel;
import com.neoway.oc.dataanalyze.vo.GasMeterOfNetOpsVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 燃气表数据
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/07/16 15:07
 */
@Mapper
public interface GasMeterMapper {

    /**
     * 存储数据
     *
     * @param gasMeterData 数据
     */
    void insertData(@Param("gasMeterData") GasMeterData gasMeterData);

    /**
     * 存储告警数据
     *
     * @param gasMeterData
     * @param type         告警类型
     * @param time         时间
     */
    void insertAlarmInfo(@Param("gasMeterData") GasMeterData gasMeterData, @Param("type") Integer type, @Param("time") Date time);

    /**
     * 存储离线告警
     *
     * @param imei
     * @param type
     * @param time
     */
    void insertOfflineAlarmInfo(@Param("imei") String imei, @Param("type") Integer type, @Param("time") Date time);

    /**
     * 存入设备在线数据
     *
     * @param deviceInfo 设备信息
     */
    void insertOnlineInfo(@Param("deviceInfo") DeviceInfo deviceInfo);

    /**
     * 通过imei号查询在线设备
     *
     * @param imei imei号
     * @return 0 或 many
     */
    OnlineInfo findOnlineInfoByImei(@Param("imei") String imei);

    /**
     * 查询在线状态
     *
     * @param cellId
     * @return model
     */
    OnlineModel findOnlineModel(@Param("cellId") String cellId);

    /**
     * 更新设备在线信息
     *
     * @param imei     设备imei号
     * @param online   在线为1，离线为0
     * @param time     时间
     * @param operator 运营商
     */
    void updateOnlineInfo(@Param("imei") String imei, @Param("online") Integer online, @Param("time") Date time, @Param("operator") String operator);

    /**
     * 更新离线状态
     *
     * @param imei 设备号
     * @param time 更新时间
     */
    void updateOfflineStatus(@Param("imei") String imei, @Param("time") Date time);

    /**
     * 根据查询条件查询相关数据
     *
     * @param searchCondition 查询条件
     * @return list
     */
    List<GasMeterData> findAllGasMeterData(@Param("searchCondition") SearchCondition searchCondition);

    /**
     * 根据查询条件查询相关数据
     *
     * @param imei    查询条件
     * @param cellId
     * @param nowDate
     * @return list
     */
    List<GasMeterInfoOfCell> findAllGasMeterInfoOfCell(@Param("imei") String imei, @Param("cellId") String cellId, @Param("nowDate") String nowDate);

    /**
     * 根据查询条件查询相关数据
     *
     * @param imei    查询条件
     * @param cellId
     * @param nowDate
     * @return list
     */
    List<GasMeterInfoOfCell> findV2AllGasMeterInfoOfCell(@Param("imei") String imei, @Param("cellId") String cellId, @Param("nowDate") String nowDate, @Param("operator") String operator);

    /**
     * 查询推荐网络信息列表
     *
     * @param imei
     * @param cellId
     * @param nowDate
     * @return
     */
    List<GasMeterInfoOfCell> findAllNetChoiceOfCellInfo(@Param("imei") String imei, @Param("cellId") String cellId, @Param("nowDate") String nowDate);

    /**
     * 查询所有告警信息
     *
     * @param type 告警类型
     * @return list
     */
    List<AlarmInfo> findAllAlarmInfo(@Param("type") Integer type);


    /**
     * 通过imei号查询网络异常告警
     *
     * @param fromDate
     * @param toDate
     * @return
     */
    List<NetAlarmInfo> findNetAlarmInfo(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);


    /**
     * 根据小区id进行查询整体设备的网络状态
     *
     * @param cellId  小区id
     * @param nowDate 当前日期
     * @return list
     */
    List<NetChannelInfo> findAllNetChannelInfo(@Param("cellId") String cellId, @Param("nowDate") String nowDate);

    /**
     * 根据小区进行分组统计小区的网络状态
     *
     * @param time 时间（2019-10-16）
     * @return list
     */
    List<NetChannelInfoOfCell> findAllNetChannelInfoOfCell(@Param("time") String time);

    /**
     * 今日该小区时段网络质量
     *
     * @param cellId 小区id
     * @param time   时间（2019-10-16）
     * @return list
     */
    List<NetQualityOfCellByDay> findAllNetQualityByDay(@Param("cellId") String cellId, @Param("time") String time);

    /**
     * 查询所有的设备信息
     *
     * @return list
     */
    List<DeviceInfo> findAllDeviceInfo();

    /**
     * 根据imei号查询设备信息
     *
     * @param imei
     * @return
     */
    DeviceInfo findDeviceInfoByImei(@Param("imei") String imei);

    /**
     * 录入设备信息
     *
     * @param deviceInfo 设备信息
     */
    void insertDeviceInfo(@Param("deviceInfo") DeviceInfo deviceInfo);

    /**
     * 批量增加设备物理地址信息
     *
     * @param physicalModels
     */
    void batchInsertDevicePhysicalInfo(@Param("physicalModels") List<DevicePhysicalAddressModel> physicalModels);

    /**
     * 批量删除设备物理地址信息
     *
     * @param physicalModels
     */
    void batchDeleteDevicePhysicalInfo(@Param("physicalModels") List<DevicePhysicalAddressModel> physicalModels);

    /**
     * 批量更新设备物理地址信息
     *
     * @param physicalModels
     */
    void batchUpdateDevicePhysicalInfo(@Param("physicalModels") List<DevicePhysicalAddressModel> physicalModels);

    /**
     * 根据imei号查询上报网络数据
     *
     * @param imei imei号
     * @return list
     */
    List<NetReportInfoOfImei> findAllNetReportInfoOfImei(@Param("imei") String imei);

    /**
     * 查询最近一条上报网络数据
     *
     * @param imei
     * @return
     */
    NetReportInfoOfImei findNetReportInfoOfImei(@Param("imei") String imei);

    /**
     * 存储扫网数据
     *
     * @param netScanInfo
     */
    void insertNetScanInfo(@Param("netScanInfo") NetScanInfo netScanInfo);

    /**
     * 存储切网日志
     *
     * @param configParam
     * @return
     */
    long insertNetChangeInfo(ConfigParam configParam);

    /**
     * 批量存储切网日志
     *
     * @param configParam
     * @return
     */
    int batchInsertNetChangeInfo(@Param("list") List<ConfigParam> configParam);

    /**
     * 通过地址查询小区id
     *
     * @param address
     * @return
     */
    String findCellIdByAddress(@Param("address") String address);

    /**
     * 通过ocDeviceId查询cellId
     *
     * @param ocDeviceId
     * @return
     */
    String findCellIdByOcDeviceId(@Param("ocDeviceId") String ocDeviceId);

    /**
     * 查询当天网络信号
     *
     * @param time
     * @param cellId
     * @param operator
     * @return
     */
    List<NetSignalOfDay> findNetSignalByDay(@Param("time") String time, @Param("cellId") String cellId, @Param("operator") String operator);

    /**
     * 查询一天的消息时段数据
     *
     * @param cellId
     * @param time
     * @return
     */
    List<Map<String, Object>> findAllMsgInfoByDay(@Param("cellId") String cellId, @Param("time") String time);

    /**
     * 查询一周的消息时段数据
     *
     * @param cellId
     * @param fromDate
     * @param toDate
     * @return
     */
    List<Map<String, Object>> findAllMsgInfoByWeek(@Param("cellId") String cellId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /**
     * 查询一天的网络切换时段数据
     *
     * @param cellId
     * @param time
     * @return
     */
    List<Map<String, Object>> findAllNetChangeInfoByDay(@Param("cellId") String cellId, @Param("time") String time);

    /**
     * 查询一周的网络切换数据
     *
     * @param cellId
     * @param fromDate
     * @param toDate
     * @return
     */
    List<Map<String, Object>> findAllNetChangeInfoByWeek(@Param("cellId") String cellId, @Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

    /**
     * 查询一周的网络信号
     *
     * @param fromDate
     * @param toDate
     * @param cellId
     * @param operator
     * @return
     */
    List<NetSignalOfDays> findNetSignalByDays(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("cellId") String cellId, @Param("operator") String operator);

    /**
     * 查询一天的设备其他运营商的网络质量
     *
     * @param imei
     * @param nowDate
     * @return
     */
    OperatorNetScanInfoModel findOperatorNetScanInfo(@Param("imei") String imei, @Param("nowDate") String nowDate);

    /**
     * 查询设备月网络质量
     *
     * @param imei
     * @param fromDate
     * @param nowDate
     * @param operator
     * @return
     */
    List<NetSignalOfImeiByMonth> findNetSignalOfImeiByMonth(@Param("imei") String imei, @Param("fromDate") Date fromDate, @Param("nowDate") Date nowDate, @Param("operator") String operator);

    /**
     * 更新设备运营商数据
     *
     * @param ocDeviceId
     * @param operator
     */
    void updateDeviceOperator(@Param("ocDeviceId") String ocDeviceId, @Param("operator") String operator);

    /**
     * Test创建表
     *
     * @param uuId
     */
    void createTable(@Param("uuId") String uuId);

    /**
     * 根据imei号查询最近一条扫网数据
     *
     * @param imei
     * @param nowDate
     * @return
     */
    NetScanInfo findNetScanInfoByImei(@Param("imei") String imei, @Param("nowDate") String nowDate);

    /**
     * 根据imei号查询设备网络切换日志
     *
     * @param imei
     * @param nowDate
     * @param result
     * @return
     */
    List<NetChangeInfo> findNetChangeInfosByImei(@Param("imei") String imei, @Param("nowDate") String nowDate, @Param("result") Integer result);

    /**
     * 查询所有设备网络切换日志
     *
     * @param imei
     * @param cellId
     * @return
     */
    List<NetChangeLog> findNetChangeLogList(@Param("imei") String imei, @Param("cellId") String cellId);

    /**
     * 更新网络切换结果
     *
     * @param id
     * @param result
     */
    void updateResultOfNetChange(@Param("id") long id, @Param("result") int result);

    /**
     * 根据任务id查询已处理的切网数量
     *
     * @param taskId
     * @return
     */
    int findProcessedNumByTaskId(@Param("taskId") String taskId);

    /**
     * 查找小区地址集合
     *
     * @return
     */
    List<String> findCellAddress();

    /**
     * 查询单个设备网络切换次数（一天不能超过三次）
     *
     * @param imei
     * @param nowDate
     * @return
     */
    int findNetChangeCount(@Param("imei") String imei, @Param("nowDate") String nowDate);

    /**
     * 微信端查询设备网络质量
     *
     * @param imei
     * @param imei
     * @return
     */
    List<GasMeterOfNetOpsVo> findGasMeterOfNetOpsVo(@Param("imei") String imei);

    /**
     * 微信端查询最新其他网络运行商的网络质量
     *
     * @param imei
     * @return
     */
    OperatorNetScanInfoModel findNetScanInfoByImeiForWeChat(@Param("imei") String imei);

    /**
     * 微信端录入设备信息
     *
     * @param deviceInfo
     */
    void insertDeviceInfoOfWeChat(@Param("deviceInfo") DeviceInfo deviceInfo);

    /**
     * 查询imei是否唯一
     *
     * @param imei
     * @return
     */
    int findImeiOfWeChat(@Param("imei") String imei);

    /**
     * 查询设备切网信息
     *
     * @param imei    设备唯一序列号
     * @param cellId  小区Id
     * @param nowDate 时间
     * @return
     */
    List<NetChoiceInfoModel> findV2AllNetChoiceInfo(@Param("imei") String imei, @Param("cellId") String cellId, @Param("nowDate") String nowDate, @Param("operator") String operator);

    /**
     * 插入管道云基础数据
     *
     * @param neopipeData
     */
    void insertBasicData(@Param("neopipeData") NeopipeData neopipeData);

    /**
     * 插入告警信息
     *
     * @param neopipeData
     * @param type
     * @param time
     */
    void insertBasicAlarmInfo(@Param("neopipeData") NeopipeData neopipeData, @Param("type") Integer type, @Param("time") Date time);

    /**
     * 插入新版扫网数据
     *
     * @param otherNetworkModel
     * @param imei
     * @param time
     */
    void insertOtherNetworkInfo(@Param("otherNetworkModel") OtherNetworkModel otherNetworkModel, @Param("imei") String imei, @Param("time") Date time);

    /**
     * 存储切换网络结果
     *
     * @param netChangeData 网络切换结果
     * @param createTime    插入时间
     * @return
     */
    int insertAutoChangeNetResult(@Param("netChangeData") String netChangeData, @Param("createTime") Date createTime);

    /**
     * 查询网络切换执行结果
     *
     * @return
     */
    String findChangeNetResult();

}