package com.neoway.oc.dataanalyze.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.github.pagehelper.PageInfo;
import com.neoway.oc.dataanalyze.model.*;
import com.neoway.oc.dataanalyze.redis.NbRedisDao;
import com.neoway.oc.dataanalyze.service.DataDashboardShowService;
import com.neoway.oc.dataanalyze.util.HttpResult;
import com.neoway.oc.dataanalyze.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 展示数据Controller
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/11 17:19
 */
@RestController
@RequestMapping("/data/analyze")
@Slf4j
@Api(tags = "数据展示", description = "数据展示")
public class DataAnalyzeController {

    @Autowired
    private DataDashboardShowService dataDashboardShowService;

    @Autowired
    private NbRedisDao nbRedisDao;

    @ApiOperation("查询展示数据")
    @PostMapping("/dataInfo")
    public HttpResult<GasMeterDataVo> dataInfo(@RequestBody SearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询展示数据，分页参数存在问题！请检查传参！");
        }
        return HttpResult.returnSuccess(dataDashboardShowService.findInfo(searchCondition));
    }

    @ApiOperation("查询小区设备信息")
    @PostMapping("/meterData")
    public HttpResult<PageInfo> findGasMeterData(@RequestBody SearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询小区设备信息，分页参数存在问题！请检查传参！");
        }
        return HttpResult.returnSuccess(new PageInfo<>(dataDashboardShowService.findAllGasMeterInfoOfCell(searchCondition)));
    }

    @ApiOperation("查询切网推荐概览")
    @PostMapping("/netChangeChoice")
    public HttpResult<NetChangeChoiceVo> findNetChangeChoice(@RequestBody SearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询切网推荐概览，分页参数存在问题！请检查传参！");
        }
        return HttpResult.returnSuccess(dataDashboardShowService.findNetChangeChoiceVo(searchCondition));
    }

    @ApiOperation("导出小区设备信息")
    @PostMapping("/exportDeviceInfo")
    public void exportDeviceInfo(@RequestBody SearchCondition searchCondition, HttpServletResponse response) {
        dataDashboardShowService.exportDeviceInfo(searchCondition, response);
    }

    @ApiOperation("导出小区设备网络切换日志")
    @PostMapping("/exportNetChangeInfo")
    public void exportNetChangeLog(@RequestBody SearchCondition searchCondition, HttpServletResponse response) {
        dataDashboardShowService.exportNetChangeInfo(searchCondition, response);
    }

    @ApiOperation("通过Imei号查询设备参数信息")
    @GetMapping("/deviceInfoByImei/{imei}")
    public HttpResult<GasMeterDataOfCellVo> findNetDataByImei(@PathVariable("imei") String imei) {
        if (StringUtils.isBlank(imei)) {
            return HttpResult.returnFail("参数是空！");
        }
        return HttpResult.returnSuccess(dataDashboardShowService.findGasMeterInfoOfCellByImei(imei));
    }

    @ApiOperation("通过Imei号查询设备过去一月内网络的信息")
    @GetMapping("/netInfoByImei/{imei}")
    public HttpResult<NetSignalOfImeiByMonthVo> findNetInfoByImei(@PathVariable("imei") String imei) {
        if (StringUtils.isBlank(imei)) {
            return HttpResult.returnFail("参数是空！");
        }
        return HttpResult.returnSuccess(dataDashboardShowService.findNetInfoByImei(imei));
    }

    @ApiOperation("运营商网络信号对比趋势")
    @PostMapping("/operatorSignal")
    public HttpResult operatorSignal(@RequestBody NetSignalQueryParams netSignalQueryParams) {
        if (netSignalQueryParams == null || StringUtils.isBlank(netSignalQueryParams.getType())) {
            return HttpResult.returnFail("参数存在问题！");
        }
        if (StringUtils.equals("1", netSignalQueryParams.getType())) {
            return HttpResult.returnSuccess(dataDashboardShowService.findNetSignalOfDay(netSignalQueryParams.getAddress()));
        } else if (StringUtils.equals("2", netSignalQueryParams.getType())) {
            return HttpResult.returnSuccess(dataDashboardShowService.findNetSignalOfDays(netSignalQueryParams.getAddress(), -7));
        } else if (StringUtils.equals("3", netSignalQueryParams.getType())) {
            return HttpResult.returnSuccess(dataDashboardShowService.findNetSignalOfDays(netSignalQueryParams.getAddress(), -30));
        } else {
            return HttpResult.returnFail("type参数不符合要求！");
        }
    }

    @ApiOperation("切换网络")
    @PostMapping("/changeNet")
    public HttpResult changeNet(@RequestBody ConfigParam configParam) {
        if (configParam == null || StringUtils.isBlank(configParam.getOcDeviceId())
                || configParam.getSimInfo() == null
                || StringUtils.isBlank(configParam.getSourceSignal())
                || StringUtils.isBlank(configParam.getTargetSignal())
                || configParam.getSourceSimInfo() == null
                || StringUtils.isBlank(configParam.getImei())
                || StringUtils.isBlank(configParam.getCellId())
                || StringUtils.isBlank(configParam.getSourceSnr())
                || StringUtils.isBlank(configParam.getSourceRsrp())
                || StringUtils.isBlank(configParam.getTargetSnr())
                || StringUtils.isBlank(configParam.getTargetRsrp())) {
            return HttpResult.returnFail("参数存在问题！");
        }
        int count = dataDashboardShowService.findNetChangeCountByImei(configParam.getImei());
        if (count == 1000000) {
            return HttpResult.returnFail("今日该设备已经切换网络3次，超过上限！");
        }
        boolean result = dataDashboardShowService.changeNet(configParam);
        if (result) {
            return HttpResult.returnSuccess("切换网络成功", true);
        } else {
            return HttpResult.returnFail("切换网络失败", false);
        }
    }

    @ApiOperation("配置上报周期")
    @PostMapping("/setReportBeat")
    public HttpResult setReportBeat(@RequestBody NetBeatParams netBeatParams) {
        if (netBeatParams == null || StringUtils.isBlank(netBeatParams.getOcDeviceId()) || netBeatParams.getNetScanBeat() == null || netBeatParams.getPipeReportBeat() == null) {
            return HttpResult.returnFail("参数存在问题！");
        }
        if (netBeatParams.getNetScanBeat() == 0 || netBeatParams.getPipeReportBeat() == 0) {
            return HttpResult.returnFail("周期设定分钟数值不能为0!");
        }
        boolean result = dataDashboardShowService.setReportBeat(netBeatParams);
        if (result) {
            return HttpResult.returnSuccess("设置上报周期成功", true);
        } else {
            return HttpResult.returnFail("设置上报周期失败", false);
        }
    }

    @ApiOperation("获取配置返回结果")
    @GetMapping("/getConfigAck/{deviceId}")
    public HttpResult getConfigAck(@PathVariable("deviceId") String deviceId) {
        if (StringUtils.isBlank(deviceId)) {
            return HttpResult.returnFail("参数为空！");
        }
        int result = dataDashboardShowService.getConfigAck(deviceId);
        if (result == 1) {
            return HttpResult.returnSuccess("操作成功！", true);
        } else if (result == 0) {
            return HttpResult.returnSuccess("由于网络原因，此次切换网络失败，请稍后重试", false);
        } else {
            // 继续请求
            return HttpResult.returnSuccess(0);
        }
    }

    @ApiOperation("查询小区设备切网信息")
    @PostMapping("/findNetChoiceOfCell")
    public HttpResult<PageInfo<NetChoiceOfCellVo>> findNetChoiceOfCell(@RequestBody SearchCondition searchCondition) {
        if (searchCondition == null || searchCondition.getPageNum() == null || searchCondition.getPageSize() == null) {
            return HttpResult.returnFail("查询小区设备切网信息，分页参数存在问题！请检查传参！");
        }
        return HttpResult.returnSuccess(new PageInfo<>(dataDashboardShowService.findV2AllNetChoiceOfCell(searchCondition)));
    }

    @ApiOperation("查询单个设备当天切网信息")
    @GetMapping("/findNetChangeInfoByImei/{imei}")
    public HttpResult<List<NetChangeInfo>> findNetChangeInfoByImei(@PathVariable("imei") String imei) {
        if (StringUtils.isBlank(imei)) {
            return HttpResult.returnFail("参数为空！");
        }
        return HttpResult.returnSuccess(dataDashboardShowService.findNetChangeInfoByImei(imei));
    }

    @ApiOperation("查询配置网络告警信息")
    @GetMapping("/findNetAlarmInfo/{userId}")
    public HttpResult<List<NetAlarmInfo>> findNetAlarmInfo(@PathVariable("userId") String userId) {
        if (StringUtils.isBlank(userId)) {
            return HttpResult.returnFail("参数为空！");
        }
        try {
            Map<String, String> resultMap = nbRedisDao.findNetAlarmInfoByUserId(userId);
            if (CollectionUtils.isEmpty(resultMap)) {
                return HttpResult.returnSuccess("暂无数据！", null);
            } else {
                String resultJson = resultMap.get("netAlarmInfo");
                List<NetAlarmInfo> result = JSON.parseObject(resultJson, new TypeReference<List<NetAlarmInfo>>() {
                });
                return HttpResult.returnSuccess(result);
            }
        } catch (Exception e) {
            return HttpResult.returnFail("查询失败！请稍后再试！");
        }
    }

    @ApiOperation("查询告警信息")
    @GetMapping("/findAlarmInfo")
    public HttpResult<List<AlarmInfo>> findAlarmInfo() {
        return HttpResult.returnSuccess(dataDashboardShowService.findAllAlarmInfo(null));
    }

    @ApiOperation("微信端新增设备信息")
    @PostMapping("/importInfoByWeChat")
    public HttpResult importInfoByWeChat(@RequestBody DeviceParamOfWeChat deviceParamOfWeChat) {
        if (StringUtils.isBlank(deviceParamOfWeChat.getImei())) {
            return HttpResult.returnFail("设备imei号为空");
        }
        if (StringUtils.isBlank(deviceParamOfWeChat.getCellAddress()) || StringUtils.isBlank(deviceParamOfWeChat.getCellName())) {
            return HttpResult.returnFail("小区信息为空");
        }

        String imei = deviceParamOfWeChat.getImei();
        if (dataDashboardShowService.findImeiOfWeChat(imei) != 0) {
            return HttpResult.returnFail("当前设备不能重复注册");
        }
        try {
            dataDashboardShowService.insertDeviceInfoOfWeChat(deviceParamOfWeChat);
            return HttpResult.returnSuccess();
        } catch (Exception e) {
            log.error("{}-----新增设备信息失败:" + e, deviceParamOfWeChat.getImei());
            return HttpResult.returnFail("新增设备信息失败");
        }
    }

    @ApiOperation("微信端查询设备网络" +
            "" +
            "" +
            "质量")
    @GetMapping("/findNetOpsByImeiForWeChat")
    public HttpResult<List<GasMeterOfNetOpsVo>> findNetOpsByImeiForWeChat(String imei) {
        try {
            List<GasMeterOfNetOpsVo> gasMeterOfNetOpsVo = dataDashboardShowService.findGasMeterOfNetOpsVo(imei);
            if (CollectionUtils.isEmpty(gasMeterOfNetOpsVo)) {
                return HttpResult.returnFail("无此设备上报数据");
            }
            return HttpResult.returnSuccess(gasMeterOfNetOpsVo);
        } catch (Exception e) {
            log.error("{}-----查询设备网络质量失败：" + e, imei);
            return HttpResult.returnFail("查询设备网络质量失败");
        }
    }

    @ApiOperation("微信端查询设备扫网数据及设备网络数据")
    @PostMapping("/findAllOperatorOpsForWeChat")
    public HttpResult<AllOperatorVo> findAllOperatorOpsForWeChat(@RequestBody DeviceParamOfWeChat deviceParamOfWeChat) {
        if (StringUtils.isBlank(deviceParamOfWeChat.getImei())) {
            return HttpResult.returnFail("设备imei号为空");
        }
        if (StringUtils.isBlank(deviceParamOfWeChat.getCellAddress()) || StringUtils.isBlank(deviceParamOfWeChat.getCellName())) {
            return HttpResult.returnFail("小区信息为空");
        }
        if (StringUtils.isBlank(deviceParamOfWeChat.getCellLocations())) {
            return HttpResult.returnFail("设备数据错误");
        }
        try {
            return HttpResult.returnSuccess(dataDashboardShowService.findAllNetOpsForWeChat(deviceParamOfWeChat));
        } catch (Exception e) {
            log.error("{}-----查询设备扫网数据及设备网络数据失败:" + e, deviceParamOfWeChat.getImei());
            return HttpResult.returnFail("查询设备扫网数据及设备网络数据失败");
        }
    }

}
