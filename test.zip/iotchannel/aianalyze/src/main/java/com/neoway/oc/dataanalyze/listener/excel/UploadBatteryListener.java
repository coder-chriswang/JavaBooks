package com.neoway.oc.dataanalyze.listener.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.excel.exception.ExcelDataConvertException;
import com.alibaba.fastjson.JSON;
import com.neoway.oc.dataanalyze.mapper.DeviceBatteryMapper;
import com.neoway.oc.dataanalyze.model.BatteryModelOfExcel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 上传设备电池信息listener
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/20 13:10
 */
@Slf4j
public class UploadBatteryListener extends AnalysisEventListener<BatteryModelOfExcel> {

    private DeviceBatteryMapper deviceBatteryMapper;
    /**
     * 每隔5条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 10;

    private static final String COLUMN_NAME_0 = "电池型号";
    private static final String COLUMN_NAME_1 = "标称容量(Ah)";
    private static final String COLUMN_NAME_2 = "标称电压(V)";
    private static final String COLUMN_NAME_3 = "放电容量(Ah)";
    private static final String COLUMN_NAME_4 = "负载电压(V)";
    private static final String COLUMN_NAME_5 = "年自放电率(%)";
    private static final String COLUMN_NAME_6 = "最大放电电流(mA)";
    private static final String COLUMN_NAME_7 = "最大脉冲放电电流(mA)";
    private static final String COLUMN_NAME_8 = "终止电压(V)";
    private static final String COLUMN_NAME_9 = "工作电流(mA)";
    private static final String COLUMN_NAME_10 = "待机电流(uA)";
    private static final String COLUMN_NAME_11 = "完全放电能力系数(%)";
    private static final String COLUMN_NAME_12 = "配合模块";

    List<BatteryModelOfExcel> list = new ArrayList<>();

    private Boolean hasStart = false;

    public UploadBatteryListener(DeviceBatteryMapper deviceBatteryMapper) {
        this.deviceBatteryMapper = deviceBatteryMapper;
    }

    @Override
    public void invoke(BatteryModelOfExcel batteryModelOfExcel, AnalysisContext analysisContext) {
        if (!hasStart) {
            log.error("表头数据为空！");
            throw new ExcelAnalysisException("Excel模板标题是空！请下载模板进行数据导入！");
        }
        if (batteryModelOfExcel == null) {
            log.error("数据为空！");
            return;
        }
        // 添加对象
        list.add(batteryModelOfExcel);
        if (list.size() >= BATCH_COUNT) {
            deviceBatteryMapper.batchInsertBatteryInfo(list);
            // 存储完清理数组
            list.clear();
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        deviceBatteryMapper.batchInsertBatteryInfo(list);
        log.info("所有数据解析导入完成！");
    }

    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        hasStart = true;
        log.info("解析到一条头数据:{}", JSON.toJSONString(headMap));
        if (CollectionUtils.isEmpty(headMap) || headMap.size() == 0) {
            throw new ExcelAnalysisException("Excel模板标题是空！");
        }
        String columnName0 = headMap.get(0);
        if (!COLUMN_NAME_0.equals(columnName0)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName0 + " 与 电池型号不匹配");
        }
        String columnName1 = headMap.get(1);
        if (!COLUMN_NAME_1.equals(columnName1)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName1 + " 与 标称容量(Ah)不匹配");
        }
        String columnName2 = headMap.get(2);
        if (!COLUMN_NAME_2.equals(columnName2)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName2 + " 与 标称电压(V)不匹配");
        }
        String columnName3 = headMap.get(3);
        if (!COLUMN_NAME_3.equals(columnName3)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName3 + " 与 放电容量(Ah)不匹配");
        }
        String columnName4 = headMap.get(4);
        if (!COLUMN_NAME_4.equals(columnName4)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName4 + " 与 负载电压(V)不匹配");
        }
        String columnName5 = headMap.get(5);
        if (!COLUMN_NAME_5.equals(columnName5)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName5 + " 与 年自放电率(%)不匹配");
        }
        String columnName6 = headMap.get(6);
        if (!COLUMN_NAME_6.equals(columnName6)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName6 + " 与 最大放电电流(mA)不匹配");
        }
        String columnName7 = headMap.get(7);
        if (!COLUMN_NAME_7.equals(columnName7)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName7 + " 与 最大脉冲放电电流(mA)不匹配");
        }

        //yangTuo 修改tag
        String columnName8 = headMap.get(8);
        if (!COLUMN_NAME_8.equals(columnName8)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName8 + " 与 终止电压(V)不匹配");
        }
        String columnName9 = headMap.get(9);
        if (!COLUMN_NAME_9.equals(columnName9)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName9 + " 与 工作电流(mA)不匹配");
        }
        String columnName10 = headMap.get(10);
        if (!COLUMN_NAME_10.equals(columnName10)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName10 + " 与 待机电流(mA)不匹配");
        }
        String columnName11 = headMap.get(11);
        if (!COLUMN_NAME_11.equals(columnName11)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName11 + " 与 完全能力放电系数(%)不匹配");
        }
        String columnName12 = headMap.get(12);
        if (!COLUMN_NAME_12.equals(columnName12)) {
            throw new ExcelAnalysisException("模板列名 - " + columnName12 + " 与 配合模块不匹配");
        }
    }

    @Override
    public void onException(Exception exception, AnalysisContext context) {
        log.error("解析导入失败，问题是:{}", exception.getMessage());
        if (exception instanceof ExcelDataConvertException) {
            ExcelDataConvertException excelDataConvertException = (ExcelDataConvertException) exception;
            log.error("第{}行，第{}列解析异常，数据为:{}", excelDataConvertException.getRowIndex(),
                    excelDataConvertException.getColumnIndex(), excelDataConvertException.getCellData());
        }
        throw new ExcelAnalysisException(exception.getMessage());
    }
}
