package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: NB燃气表上报数据实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/11 13:48
 */
@Data
@ApiModel("NB燃气表上报数据实体")
public class GasMeterData implements Serializable {

    private static final long serialVersionUID = 4124303771896281792L;

    @ApiModelProperty("主键id")
    private int id;

    @ApiModelProperty("模块软件版本")
    private String softwareVersion;

    @ApiModelProperty("模块硬件版本")
    private String hardwareVersion;

    @ApiModelProperty("模块平台基线版本")
    private String basicVersion;

    @ApiModelProperty("设备IMEI号")
    private String imei;

    @ApiModelProperty("经度")
    private String longitude;

    @ApiModelProperty("纬度")
    private String latitude;

    @ApiModelProperty("CCID")
    private String ccid;

    @ApiModelProperty("IMSI")
    private String imsi;

    @ApiModelProperty("运营商")
    private String operator;

    @ApiModelProperty("频点")
    private String earfcn;

    @ApiModelProperty("网络小区Id")
    private String netCellId;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("物理小区id")
    private String pci;

    @ApiModelProperty("参考信息接收功率")
    private String rsrp;

    @ApiModelProperty("参考信号接收质量")
    private String rsrq;

    @ApiModelProperty("接收信号强度指示")
    private String rssi;

    @ApiModelProperty("信噪比")
    private String snr;

    @ApiModelProperty("覆盖等级")
    private String ecl;

    @ApiModelProperty("接入成功数")
    private String rrc;

    @ApiModelProperty("接入总数")
    private String rrcSum;

    @ApiModelProperty("接入失败原因")
    private String rrcCode;

    @ApiModelProperty("小区地址")
    private String cellAddress;

    @ApiModelProperty("小区名称")
    private String cellName;

    @ApiModelProperty("楼栋地址")
    private String buildingAddress;

    @ApiModelProperty("小区经纬度信息")
    private String cellLocations;

    @ApiModelProperty("上报时间")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date upTime;

    @ApiModelProperty("信号等级描述（好，良，差）")
    private String signalLevel;

}
