package com.neoway.oc.dataanalyze.mapper;

import com.neoway.oc.dataanalyze.model.NetChangeTaskModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <pre>
 *  描述: 任务Mapper
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/05 19:55
 */
@Mapper
public interface TaskMapper {

    /**
     * 存储切网任务
     *
     * @param netChangeTaskModel
     */
    void insert(@Param("netChangeTaskModel") NetChangeTaskModel netChangeTaskModel);

    /**
     * 更新切网状态数据
     *
     * @param netChangeTaskModel
     */
    void update(@Param("netChangeTaskModel") NetChangeTaskModel netChangeTaskModel);

    /**
     * 查询任务实体
     *
     * @param taskId
     * @return
     */
    NetChangeTaskModel findOneById(@Param("taskId") String taskId);

    /**
     * 查询最近一次任务信息
     *
     * @return
     */
    NetChangeTaskModel findLatestOne();
}
