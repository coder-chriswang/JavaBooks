package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述:切网信息属性
 * </pre>
 *
 * @author Kyle Wong(wangfan)
 * @version 1.0.0
 * @date 2020/5/19 19:28
 */
@Data
public class AutoChangeNetModel implements Serializable {
    private static final long serialVersionUID = 3991608258368523039L;

    private String imei;

    private Integer simInfo;

    private Integer simChange;

    private Integer scanSwitch;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date time;
}
