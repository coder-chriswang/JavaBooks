package com.neoway.oc.dataanalyze.controller;

import com.neoway.oc.dataanalyze.model.ConfigAddOrUpdateParams;
import com.neoway.oc.dataanalyze.model.ConfigModel;
import com.neoway.oc.dataanalyze.service.ConfigService;
import com.neoway.oc.dataanalyze.util.HttpResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <pre>
 *  描述: 配置处理Controller
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/03 15:06
 */
@RestController
@RequestMapping("/config/handle")
@Slf4j
@Api(tags = "配置处理", description = "配置处理")
public class ConfigController {

    @Autowired
    private ConfigService configService;

    @ApiOperation("新增配置")
    @PostMapping("/add")
    public HttpResult add(@RequestBody ConfigAddOrUpdateParams configAddParams) {
        if (configAddParams == null || StringUtils.isBlank(configAddParams.getUserId())) {
            return HttpResult.returnFail("userId参数为空！");
        }
        try {
            configService.addConfig(configAddParams);
            return HttpResult.returnSuccess("新增配置成功！");
        } catch (Exception e) {
            return HttpResult.returnFail("新增配置失败！");
        }
    }

    @ApiOperation("更新配置")
    @PostMapping("/update")
    public HttpResult update(@RequestBody ConfigAddOrUpdateParams configUpdateParams) {
        if (configUpdateParams == null || StringUtils.isBlank(configUpdateParams.getUserId())) {
            return HttpResult.returnFail("userId参数为空！");
        }
        try {
            configService.updateConfig(configUpdateParams);
            return HttpResult.returnSuccess("更新配置成功！");
        } catch (Exception e) {
            return HttpResult.returnFail("更新配置失败！");
        }
    }

    @ApiOperation("查询配置")
    @GetMapping("/findByUserId/{userId}")
    public HttpResult<ConfigModel> findById(@PathVariable("userId") String userId) {
        if (StringUtils.isBlank(userId)) {
            return HttpResult.returnFail("userId参数为空！");
        }
        return HttpResult.returnSuccess(configService.findByUserId(userId));
    }
}
