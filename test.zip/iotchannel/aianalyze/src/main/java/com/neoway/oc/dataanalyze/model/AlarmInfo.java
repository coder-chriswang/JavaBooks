package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述: 警告信息实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/10/15 10:49
 */
@Data
@ApiModel("告警实体")
public class AlarmInfo implements Serializable {
    private static final long serialVersionUID = 4355199626344571102L;

    @ApiModelProperty("主键id")
    private int id;

    @ApiModelProperty("设备IMEI号")
    private String imei;

    @ApiModelProperty("异常类型（0，离线；1，网络缓慢；2，网络异常）")
    private Integer type;

    @ApiModelProperty("异常记录时间")
    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date recordTime;
}
