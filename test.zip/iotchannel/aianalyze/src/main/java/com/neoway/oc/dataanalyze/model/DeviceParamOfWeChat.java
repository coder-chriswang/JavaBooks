package com.neoway.oc.dataanalyze.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 微信端录入设备实体类
 *
 * @author 20190729618
 */
@Data
@ApiModel("微信端录入设备信息")
public class DeviceParamOfWeChat implements Serializable {

    private static final long serialVersionUID = -6573889305435941895L;

    @ApiModelProperty("设备IMEI号")
    private String imei;

    @ApiModelProperty("小区物理地址")
    private String cellAddress;

    @ApiModelProperty("小区名称")
    private String cellName;

    @ApiModelProperty("具体楼栋地址")
    private String buildingAddress;

    @ApiModelProperty("小区经纬度")
    private String cellLocations;
}
