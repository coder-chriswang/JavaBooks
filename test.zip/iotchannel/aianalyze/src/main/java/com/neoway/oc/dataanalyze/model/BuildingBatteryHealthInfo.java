package com.neoway.oc.dataanalyze.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <pre>
 *  描述: 楼栋住户电池健康实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/03/23 15:41
 */
@ApiModel("楼栋住户电池健康实体")
@Data
public class BuildingBatteryHealthInfo implements Serializable {
    private static final long serialVersionUID = 2216580401904417458L;

    @ApiModelProperty("楼栋名称")
    private String buildingName;

    @ApiModelProperty("楼栋经纬度")
    private String buildingLocations;

    @ApiModelProperty("住户电池健康列表")
    private List<RoomBatteryHealthInfo> roomBatteryHealthInfos;
}
