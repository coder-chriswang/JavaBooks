package com.neoway.oc.dataanalyze.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  描述:终端切换网络和定时配置实体
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/11/29 14:57
 */
@ApiModel("终端切换网络和定时配置")
@Data
public class ConfigParam implements Serializable {
    private static final long serialVersionUID = 5420985550447752068L;

    @ApiModelProperty(value = "返回的主键id", hidden = true)
    private long id;

    @ApiModelProperty("oc设备id")
    private String ocDeviceId;

    @ApiModelProperty(value = "任务id", hidden = true)
    private String taskId;

    @ApiModelProperty("设备imei")
    private String imei;

    @ApiModelProperty("小区id")
    private String cellId;

    @ApiModelProperty("原网络，如1,代表CMCC;2,代表CUCC;3,代表CTCC")
    private Integer sourceSimInfo;

    @ApiModelProperty("需要切换的网络，如1,代表CMCC;2,代表CUCC;3,代表CTCC")
    private Integer simInfo;

    @ApiModelProperty("原网络质量")
    private String sourceSignal;

    @ApiModelProperty("目标网络质量")
    private String targetSignal;

    @ApiModelProperty(value = "管道云数据上报周期，单位：分钟", hidden = true)
    private Integer pipeReportBeat = 60;

    @ApiModelProperty(value = "网络扫描周期，单位：分钟", hidden = true)
    private Integer netScanBeat = 60;

    @ApiModelProperty("原运营商SNR")
    private String sourceSnr;

    @ApiModelProperty("原运营商RSRP")
    private String sourceRsrp;

    @ApiModelProperty("目标运营商Snr")
    private String targetSnr;

    @ApiModelProperty("目标运营商RSRP")
    private String targetRsrp;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "录入时间", hidden = true)
    private Date upTime;
}
