package com.neoway.oc.dataanalyze.mapper;

import com.neoway.oc.dataanalyze.model.MissPeakInfo;
import com.neoway.oc.dataanalyze.model.MissPeakModel;
import com.neoway.oc.dataanalyze.model.MissPeakParams;
import com.neoway.oc.dataanalyze.model.MissPeakPeroid;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * 描述：错峰算法接口
 * </pre>
 *
 * @author Nancy(Leilanjie)
 * @version 1.0.0
 * @date 2020/4/10 15:08
 */
@Mapper
public interface MissPeakMapper {

    /**
     * 查询上次错峰信息
     * @return
     */
    List<MissPeakInfo> selectPreMissPeakInfo();

    /**
     * 插入错峰id及更新时间
     * @param id
     * @param createTime
     * @return
     */
    int addMissPeakId(@Param("id") String id, @Param("createTime") Date createTime);

    /**
     * 存储错峰信息
     * @param missPeakModel
     * @return
     */
    int addMissPeakInfo(@Param("missPeakModel") MissPeakModel missPeakModel);

    /**
     * 存储错峰区间信息
     * @param startTime
     * @param endTime
     */
    void insertMissPeakPeroid(@Param("startTime") Date startTime, @Param("endTime") Date endTime);

    /**
     * 查询错峰区间
     * @return
     */
    MissPeakPeroid findLatestOne();

    /**
     * 更新有变化的标志位
     * @param list
     * @param isChange
     * @param missPeakId
     * @return
     */
    int addIsChangeDevice(@Param("list") List<String> list, @Param("isChange") int isChange, @Param("missPeakId") String missPeakId);

    /**
     * 查询错峰算法参数列表
     * @param nowDate 当日时间
     * @return
     */
    List<MissPeakParams> selectMissPeakParams(@Param("nowDate") String nowDate);

    /**
     * 存储当前错峰结果
     * @param missPeakMap
     * @param createTime
     * @return
     */
    int insertMissPeakResult(@Param("missPeakMap") Map<String, Object> missPeakMap, @Param("createTime") Date createTime);

    /**
     * 查询错峰结果
     * @return
     */
    String findMissPeakResult();

}
