package com.neoway.iot.dmm;

/**
 * @desc: DMMRequest
 * @author: 20200312686
 * @date: 2020/7/21 11:00
 */
public class DMMRequest {
    //产品域
    private String ns;
    //资源类型
    private String ci;
    //操作指令
    private String action;
    private String reqId;
    private long ts;
    //操作参数
    private Object data;

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getCi() {
        return ci;
    }

    public String getAction() {
        return action;
    }
}
