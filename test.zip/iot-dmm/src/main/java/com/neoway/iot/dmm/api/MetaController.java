package com.neoway.iot.dmm.api;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.dmm.handler.MetaHandler;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @desc: MetaController
 * @author: 20200312686
 * @date: 2020/7/21 10:56
 */
@RestController
@RequestMapping("/v1/meta")
@Api(tags = "元数据")
public class MetaController {
    private MetaHandler handler=new MetaHandler();
    @ApiOperation("查询系统中CI元数据")
    @GetMapping("/ci")
    public DMMResponse queryCI() {
        DMMResponse response=new DMMResponse();
        try{
            List<DMMetaCI> metaCis=handler.queryMetaCI();
            response.setData(metaCis);
            return response;
        }catch (Exception e){
            response.setCode(DMMResponse.NOK);
            response.setMsg(e.getMessage());
            return response;
        }

    }

    @ApiOperation("查询CI元数据")
    @GetMapping("/{ns}/{ci}")
    public DMMResponse getMeta(@PathVariable("ns") String ns,@PathVariable("ci") String ci) {
        DMMResponse response=new DMMResponse();
        try{
            DMMetaCI metaCI=handler.getMetaCI(ns,ci);
            response.setData(metaCI);
            return response;
        }catch (Exception e){
            response.setCode(DMMResponse.NOK);
            response.setMsg(e.getMessage());
            return response;
        }
    }
}
