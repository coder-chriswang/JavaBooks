package com.neoway.iot.dmm.api;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

/**
 * @desc: 拓扑查询
 * @author: 20200312686
 * @date: 2020/7/21 10:56
 */
@RestController
@RequestMapping("/v1/topo")
@Api(tags = "关系")
public class TopoController {
    @ApiOperation("查询资源拓扑关系")
    @GetMapping("/{ns}/{instanceid}")
    public DMMResponse getLink(@PathVariable("ns") String ns,
                               @PathVariable("instanceid") long instanceid) {
        return null;
    }

    @ApiOperation("查询指定位置的拓扑视图")
    @PostMapping("/view")
    public DMMResponse getLinkView(@RequestBody DMMRequest request) {
        return null;
    }
}
