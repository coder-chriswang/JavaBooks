package com.neoway.iot.dmm.api;

import com.neoway.iot.dmm.DMMRequest;
import com.neoway.iot.dmm.DMMResponse;
import com.neoway.iot.dmm.handler.DataHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

/**
 * @desc: DataController
 * @author: 20200312686
 * @date: 2020/7/21 10:56
 */
@RestController
@RequestMapping("/v1/command")
@Api(tags = "资源")
public class DataController {
    private DataHandler handler=new DataHandler();

    @ApiOperation("资源指令执行")
    @PostMapping("")
    public DMMResponse execute(@RequestBody DMMRequest request) {
        DMMResponse response=handler.execute(request);
        return response;
    }
}
