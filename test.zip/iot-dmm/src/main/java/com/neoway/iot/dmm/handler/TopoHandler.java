package com.neoway.iot.dmm.handler;

import com.neoway.iot.sdk.dmk.DMRunner;

/**
 * @desc: 拓扑构建
 * @author: 20200312686
 * @date: 2020/7/21 11:00
 */
public class TopoHandler {
    private DMRunner runner;
    public TopoHandler(){
        this.runner=DMRunner.getInstance();
    }
}
