package com.neoway.iot.dgw.channel;

/**
 * @desc: ChannelManager
 * @author: 20200312686
 * @date: 2020/6/30 10:03
 */
public enum ChannelType {
    DIRECT("com.neoway.iot.dgw.channel.direct.DirectChannel"),
    MEMORY("com.neoway.iot.dgw.channel.mem.MemChannel"),
    REDIS("com.neoway.iot.dgw.channel.redis.RedisChannel"),
    OTHER(null);
    private final String channelClassName;

    private ChannelType(String channelClassName) {
        this.channelClassName = channelClassName;
    }

    public String getChannelClassName() {
        return channelClassName;
    }
}
