package com.neoway.iot.dgw.output.iotlm.handler;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotem.storage.EMDPoint;
import com.neoway.iot.dgw.output.iotem.storage.EMDSink;
import com.neoway.iot.dgw.output.iotlm.storage.LMDPoint;
import com.neoway.iot.dgw.output.iotlm.LmCmd;
import com.neoway.iot.dgw.output.iotlm.storage.LMDSink;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: LmCmdHandlerUplinkData
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 14:38
 */
public class LmCmdHandlerUplinkData implements LmCmdHandler{
    private static final Logger LOG = LoggerFactory.getLogger(LmCmdHandlerUplinkData.class);

    private LMDSink sink;

    public LmCmdHandlerUplinkData(LMDSink sink) {
        this.sink = sink;
    }

    @Override
    public String name() {
        return LmCmd.UPLINK_LM_DATA.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> events = event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(events)){
            return response;
        }
        Gson gson = new Gson();
        try{
            String pointArrJson = gson.toJson(events);
            List<LMDPoint> points = gson.fromJson(pointArrJson,new TypeToken<List<LMDPoint>>(){}.getType());
            this.sink.write(points);
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }
}
