package com.neoway.iot.dgw.output.iotlm.storage;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;

import java.util.List;

/**
 * @desc: LMDSink
 * @author: 20200312686
 * @date: 2020/7/1 16:45
 */
public interface LMDSink {
    String BACKEND_MYSQL="mysql";
    String BACKEND_ELASTIC="elastic";
    void start(DGWConfig env) throws DGWException;
    /**
     * @desc 数据写入
     * @param points 数据点
     */
    void write(List<LMDPoint> points) throws DGWException;
}
