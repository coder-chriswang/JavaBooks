package com.neoway.iot.dgw.output.iotpm.storage;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.jdbc.JdbcPool;
import com.neoway.iot.dgw.common.tsd.TSDPoint;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: PMDAbstracStorage
 * @author: 20200312686
 * @date: 2020/7/1 9:58
 */
public abstract class PMDAbstractSink implements PMDSink {
    private static final Logger LOG = LoggerFactory.getLogger(PMDAbstractSink.class);
    public static final String INSTANCEID = "instanceid";
    public static final String NATIVEID = "nativeid";
    public static final String INSTANCENAME = "name";
    public static final String CI = "ci";
    public static final String JDBC_URI = "dgw.output.pm.mysql.uri";
    public static final String JDBC_MAX_CONN = "dgw.output.pm.mysql.max_conn";
    public static final String JDBC_USER = "dgw.output.pm.mysql.user";
    public static final String JDBC_PWD = "dgw.output.pm.mysql.pwd";
    public static final String JDBC_CONN_TIMEOUT = "dgw.output.pm.mysql.conn_timeout";
    public static final String JDBC_IDEL_TIMEOUT = "dgw.output.pm.mysql.idel_timeout";
    public static final String JDBC_MIN_NUM = "dgw.output.pm.mysql.min_conn";
    //建表语句
    public static final String CREATE_TABLE_META =
            "CREATE TABLE IF NOT EXISTS PM_META_METRIC ( "
                    + "`code` int(10) NOT NULL, "
                    + "`ns` VARCHAR(32) NOT NULL, "
                    + "`ci` VARCHAR(32) NOT NULL, "
                    + "`metric` VARCHAR(64) NOT NULL, "
                    + "`metric_name` VARCHAR(128) NOT NULL, "
                    + "`group` VARCHAR(64) NOT NULL, "
                    + "`group_name` VARCHAR(128) NOT NULL, "
                    + "`type` VARCHAR(32) NOT NULL, "
                    + "`unit` VARCHAR(32), "
                    + "`desc` VARCHAR(128), "
                    + "PRIMARY KEY(`code`), "
                    + "index `metric_idx`(`metric`) "
                    + " ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='指标元数据' ROW_FORMAT=DYNAMIC;";

    //批量插入语句
    public static final String BATCH_INSERT_META=
            "REPLACE INTO PM_META_METRIC(`code`,`ns`,`ci`,`metric`,`metric_name`,`group`,`group_name`,`type`,`unit`,`desc`) VALUES(?,?,?,?,?,?,?,?,?,?)";
    public static final String GET_META=
            "SELECT * FROM PM_META_METRIC WHERE METRIC=?";
    public static final String QUERY_META=
            "SELECT * FROM PM_META_METRIC";
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    protected JdbcPool client;
    protected DGWConfig env;

    //元数据缓存
    private LoadingCache<String, PmMetaMetric> metaCache;

    @Override
    public void start(DGWConfig env) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        this.env=env;
        try {
            JdbcPool.Builder builder=new JdbcPool.Builder();
            this.client=builder.jdbcUri(env.getValue(JDBC_URI).toString()).jdbcUser(env.getValue(JDBC_USER).toString())
                    .jdbcPwd(env.getValue(JDBC_PWD).toString()).jdbcMaxConn(Integer.valueOf(env.getValue(JDBC_MAX_CONN).toString()))
                    .jdbcMinConn(Integer.valueOf(env.getValue(JDBC_MIN_NUM).toString()))
                    .jdbcConnTimeOut(Integer.valueOf(env.getValue(JDBC_CONN_TIMEOUT).toString()))
                    .jdbcIdelTimeOut(Integer.valueOf(env.getValue(JDBC_IDEL_TIMEOUT).toString()))
                    .jdbcReadOnly(false).jdbcAutoCommit(true).build();
            this.client.start();
            this.createTableMeta();

            metaCache= CacheBuilder.newBuilder()
                    .maximumSize(100)
                    .recordStats()
                    .initialCapacity(100)
                    .build(new CacheLoader<String, PmMetaMetric>() {
                        @Override
                        public PmMetaMetric load(String s) throws Exception {
                            LOG.info("MetricMeta缓存不存在，从数据库加载:K={}",s);
                            PmMetaMetric meta=loadMetaMetric(s);
                            return meta;
                        }
                    });
            this.loadMetaMetrics();

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new DGWException("", e.getMessage());
        }

        isStarted.set(true);
    }

    /**
     * @desc 创建元数据表
     * @throws SQLException
     */
    private void createTableMeta() throws SQLException {
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        runner.update(CREATE_TABLE_META);
    }
    private PmMetaMetric loadMetaMetric(String metric) throws SQLException{
        Object[] param=new Object[]{metric};
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        Map<String,Object> result=runner.query(GET_META,new MapHandler(),param);
        PmMetaMetric metaMetric= PmMetaMetric.buildMetaMetric(result);
        return metaMetric;
    }
    private void loadMetaMetrics() throws Exception{
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        List<Map<String,Object>> metaMetricMaps=runner.query(QUERY_META,new MapListHandler());
        if(CollectionUtils.isEmpty(metaMetricMaps)){
            return;
        }
        for(Map<String,Object> metricMap:metaMetricMaps){
            PmMetaMetric metaMetric= PmMetaMetric.buildMetaMetric(metricMap);
            metaCache.put(metaMetric.getMetric(),metaMetric);
        }
    }
    @Override
    public void registerMeta(List<PmMetaMetric> metas) throws DGWException{
        if(CollectionUtils.isEmpty(metas)){
            return;
        }
        Object[][] params=new Object[metas.size()][];
        int index=0;
        for(PmMetaMetric meta:metas){
            params[index]=meta.getParam();
            index++;
        }
        try{
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            runner.batch(BATCH_INSERT_META,params);
        }catch (SQLException e){
            LOG.error(e.getSQLState(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }

    }
    @Override
    public PmMetaMetric getMeta(String metric) throws DGWException{
        try{
            return metaCache.get(metric);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }
    }
    @Override
    public void write(List<TSDPoint> points) throws DGWException {
        //1：数据补齐
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        /*for(TSDPoint point:points){
            Map<String,String> tag=point.getTags();
            String nativeId=tag.get(NATIVEID);
            DMDHot hot= DMRunner.getInstance().getHot(nativeId);
            tag.put(INSTANCEID,hot.getInstanceId());
            tag.put(INSTANCENAME,hot.getName());
            tag.put(CI,hot.getCi());
        }*/
        doWrite(points);
    }
    abstract void doWrite(List<TSDPoint> points) throws DGWException;
}
