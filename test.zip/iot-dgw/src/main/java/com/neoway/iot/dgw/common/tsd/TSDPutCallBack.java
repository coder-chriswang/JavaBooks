package com.neoway.iot.dgw.common.tsd;

import java.util.List;

/**
 * @desc: TSDPutCallBack
 * @author: 20200312686
 * @date: 2020/6/30 19:49
 */
public interface TSDPutCallBack {
    /***
     * 在请求完成并且response code成功时回调
     * @param points 数据点
     * @param result 请求结果
     */
    void response(List<TSDPoint> points, TSDResult result);

    /***
     * 在response code失败时回调
     * @param points 数据点
     * @param result 请求结果
     */
    void responseError(List<TSDPoint> points, TSDResult result);

    /***
     * 在发生错误是回调
     * @param points 数据点
     * @param e 异常
     */
    void failed(List<TSDPoint> points, Exception e);
}
