package com.neoway.iot.dgw.output.iotfm.handler;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotfm.FmCmd;
import com.neoway.iot.dgw.output.iotfm.storage.FMDPoint;
import com.neoway.iot.dgw.output.iotfm.storage.FMDSink;
import com.neoway.iot.dgw.output.iotfm.storage.FMMeta;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: FmCmdHandlerUplinkMeta
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 16:41
 */
public class FmCmdHandlerUplinkMeta implements FmCmdHandler{
    private static final Logger LOG = LoggerFactory.getLogger(FmCmdHandlerUplinkMeta.class);

    private FMDSink sink;

    public FmCmdHandlerUplinkMeta(FMDSink sink) {
        this.sink = sink;
    }

    @Override
    public String name() {
        return FmCmd.UPLINK_FM_META.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> events=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(events)){
            return response;
        }
        Gson gson = new Gson();
        try{
            String pointArrJson = gson.toJson(events);

            List<FMMeta> metas = gson.fromJson(pointArrJson, new TypeToken<List<FMMeta>>(){}.getType());
            for(FMMeta meta:metas){
                meta.validate();
                meta.buildCode();
            }
            this.sink.registerMeta(metas);
            return response;
        }catch (DGWException e){
            response.setCode(e.getCode());
            response.setMsg(e.getMessage());
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }
}
