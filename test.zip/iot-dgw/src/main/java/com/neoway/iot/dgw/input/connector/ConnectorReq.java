package com.neoway.iot.dgw.input.connector;

import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: ConnectorReq
 * @author: 20200312686
 * @date: 2020/6/29 17:34
 */
public class ConnectorReq {
    private Map<String,String> header=new HashMap<>();
    private String endpoint;
    private String request;

    public ConnectorReq(){

    }
    public ConnectorReq(String header, String endpoint, String request) {
        this.header = new Gson().fromJson(header,Map.class);
        this.endpoint = endpoint;
        this.request = request;
    }

    public Map<String, String> getHeader() {
        return header;
    }

    public void setHeader(Map<String, String> header) {
        this.header = header;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }
}
