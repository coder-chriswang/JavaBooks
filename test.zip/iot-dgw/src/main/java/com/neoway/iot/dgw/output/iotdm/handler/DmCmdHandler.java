package com.neoway.iot.dgw.output.iotdm.handler;

import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;

/**
 * @desc: cmd处理结构
 * @author: 20200312686
 * @date: 2020/7/17 10:13
 */
public interface DmCmdHandler {
    /**
     * @desc
     * @return cmd指令名称
     */
    String name();

    /**
     * @desc 指令处理
     * @param event 数据输入
     * @return 处理结果
     */
    DGWResponse execute(OutputEvent event);
}
