package com.neoway.iot.dgw.output.iotpm;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.tsd.TSDJson;
import com.neoway.iot.dgw.common.tsd.TSDPoint;
import com.neoway.iot.dgw.output.AbstractOutput;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotdm.DmCmd;
import com.neoway.iot.dgw.output.iotdm.DmCmdFactory;
import com.neoway.iot.dgw.output.iotdm.handler.DmCmdHandler;
import com.neoway.iot.dgw.output.iotpm.handler.PmCmdHandler;
import com.neoway.iot.dgw.output.iotpm.storage.PMDMySqLSink;
import com.neoway.iot.dgw.output.iotpm.storage.PMDSink;
import com.neoway.iot.dgw.output.iotpm.storage.PMDTsdSink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: PmOut
 * @author: 20200312686
 * @date: 2020/7/1 9:18
 */
public class PmOutput extends AbstractOutput {
    private static final Logger LOG = LoggerFactory.getLogger(PmOutput.class);
    public static final String BACKEND = "dgw.output.pm.backend";
    public static final String SUBCRIBE = "dgw.output.pm.subcribe_topic";
    private AtomicBoolean isStarted = new AtomicBoolean(false);
    private PMDSink sink;
    private PMDSink metaSink;
    private DGWConfig env;

    @Override
    public void start(DGWConfig config) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        this.env = config;
        String backend = String.valueOf(config.getValue(BACKEND));
        if (PMDSink.BACKEND_MYSQL.equals(backend)) {
            sink = new PMDMySqLSink();
        } else if (PMDSink.BACKEND_OPENTSDB.equals(backend)) {
            metaSink = new PMDMySqLSink();
            sink = new PMDTsdSink();
        } else {
            sink = new PMDMySqLSink();
        }
        sink.start(config);
        super.start(config);
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> configuration=new HashMap<>();
        configuration.put(SUBCRIBE,getTopics());
        configuration.put(BACKEND,env.getValue(BACKEND));
        configuration.putAll(this.sink.configuration());
        return configuration;
    }

    @Override
    public String name() {
        return "output-plugin-pm";
    }

    @Override
    public List<String> getTopics() {
        return Arrays.asList(DGWCmd.UPLINK_PM_DATA.name(),
                DGWCmd.UPLINK_PM_META.name(),
                DGWCmd.UPLINK_DM_DATA.name(),
                DGWCmd.MSG_PM.name());
    }

    @Override
    public DGWResponse doProcess(OutputEvent event) throws DGWException {
        String topic=event.getHeader().getTopic();
        PmCmdHandler handler;
        if(PmCmd.UPLINK_PM_META.name().equals(topic)){
            handler= PmCmdFactory.buildHandler(PmCmd.UPLINK_PM_META.name(),this.sink);
        }else if(PmCmd.UPLINK_PM_DATA.name().equals(topic)){
            handler=PmCmdFactory.buildHandler(PmCmd.UPLINK_PM_DATA.name(),this.sink);
        }else if(DGWCmd.UPLINK_DM_DATA.name().equals(topic)){
            //订阅DM数据上报事件。从Status这个CI获取时序数据
            handler=PmCmdFactory.buildHandler(PmCmd.SUBCRIBE_DM_DATA.name(),this.sink);
        }else if(DGWCmd.MSG_PM.name().equals(topic)){
            DGWHeader head=event.getHeader();
            handler=PmCmdFactory.buildHandler(head.getCmdId(),this.sink);
        }else{
            String errMsg="接收到的topic非法:"+topic;
            DGWResponse rsp = new DGWResponse(DGWCodeEnum.EXCEPTION_CODE.getCode(),errMsg);
            return rsp;
        }
        return handler.execute(event);
    }
}
