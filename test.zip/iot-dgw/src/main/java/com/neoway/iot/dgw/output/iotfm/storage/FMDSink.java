package com.neoway.iot.dgw.output.iotfm.storage;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;

import java.util.List;

/**
 * <pre>
 *  描述: FMDSink
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/09 14:46
 */
public interface FMDSink {
    String BACKEND_MYSQL="mysql";

    void start(DGWConfig env) throws DGWException;
    /**
     * @desc 数据写入
     * @param points 数据点
     */
    void write(List<FMDPoint> points) throws DGWException;

    /**
     * 模型注册
     * @param metas
     * @throws DGWException
     */
    void registerMeta(List<FMMeta> metas) throws DGWException;

    /**
     * @desc 获取meta信息
     * @param code 告警code
     * @return
     * @throws DGWException
     */
    FMMeta getMeta(int code);
}
