package com.neoway.iot.dgw.output.iotdm.handler;

import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotdm.DmCmd;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: 资源数据上报
 * @author: 20200312686
 * @date: 2020/7/17 10:23
 */
public class DmCmdHandlerUplinkData implements DmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DmCmdHandlerUplinkData.class);
    @Override
    public String name() {
        return DmCmd.UPLINK_DM_DATA.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> values=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(values)){
            return response;
        }
        String ns=event.getHeader().getProduct();
        List<DMDataPoint> points=new ArrayList<>();
        try{
            for(Map<String,Object> value:values){
                String ci=(String)value.get("ci");
                String tenent="";
                if(value.containsKey("tenent")){
                    tenent=(String)value.get("tenent");
                }else{
                    tenent= DMMetaCI.DEFAULT_TENENT;
                }
                DMDataPoint point=DMDataPoint.builder(ns,tenent,ci);
                points.add(point.buildColumns(value));
            }
            DMRunner.getInstance().write(points);
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }
}
