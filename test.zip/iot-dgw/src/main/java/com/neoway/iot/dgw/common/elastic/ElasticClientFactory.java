package com.neoway.iot.dgw.common.elastic;

import java.util.Objects;

/**
 * @desc: 之所以提供两种client，是因为我们默认按照transport client操作，
 * 比rest client效率高。但是我们存在使用第三方公云es服务的场景，
 * 此场景下较大多数只提供rest 操作模式的。
 * @author Chris(wangchao)
 * @date: 2020/7/1 15:44
 */
public class ElasticClientFactory {
    public static final String TransportClient = "transport";
    public static final String RestClient = "rest";

    public static ElasticClient getClient(ElasticConfig elasticConfig) {
        Objects.requireNonNull(elasticConfig);
        String clientType = elasticConfig.getClientType();
        if (TransportClient.equals(clientType)) {
            return new ElasticTransportClient(elasticConfig);
        } else if (RestClient.equals(clientType)) {
            return new ElasticRestClient(elasticConfig);
        } else {
            return null;
        }
    }
}
