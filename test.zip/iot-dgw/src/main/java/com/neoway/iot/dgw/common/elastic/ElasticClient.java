package com.neoway.iot.dgw.common.elastic;

import java.util.List;

/**
 * @desc: ElasticClient
 * @author: 20200312686
 * @date: 2020/7/1 15:38
 */
public interface ElasticClient {

    /**
     * 存储单个
     * @param event
     * @param indexNameBuilder
     * @param indexType
     * @param ttlMs
     * @throws Exception
     */
    void addEvent(ElasticPoint event, ElasticIndexNameBuilder indexNameBuilder, String indexType, long ttlMs) throws Exception;

    /**
     * 批量处理
     * @param events
     * @param indexNameBuilder
     * @param indexType
     * @param ttlMs
     * @throws Exception
     */
    void execute(List<ElasticPoint> events, ElasticIndexNameBuilder indexNameBuilder, String indexType, long ttlMs) throws Exception;
}
