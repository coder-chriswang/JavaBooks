package com.neoway.iot.dgw.channel.direct;

import com.neoway.iot.dgw.channel.AbstractChannel;
import com.neoway.iot.dgw.channel.DGWChannelEvent;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.output.OutputProcessor;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: 透传channel
 * @author: 20200312686
 * @date: 2020/6/23 9:27
 */
public class DirectChannel extends AbstractChannel {
    OutputProcessor processor=OutputProcessor.getInstance();
    @Override
    public DGWResponse process(DGWContext context) {
        List<DGWChannelEvent> events=new ArrayList<>();
        List<Map<String,Object>> values=context.decodeData();
        for(Map<String,Object> value:values){
            DGWContext cc=new DGWContext(context.getHeader(),value);
            DGWChannelEvent event=new DGWChannelEvent(cc,null);
            events.add(event);
        }
        return this.doProcess(events);
    }

    @Override
    public String name() {
        return "channel-plugin-direct";
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public DGWResponse doProcess(List<DGWChannelEvent> events) {
        if(CollectionUtils.isNotEmpty(events)){
            return processor.process(events);
        }
        return new DGWResponse();
    }

    @Override
    public List<DGWContext> take() throws DGWException {
        return null;
    }

    @Override
    public void commit(String eventId, String topic, boolean status){
        return;
    }

}
