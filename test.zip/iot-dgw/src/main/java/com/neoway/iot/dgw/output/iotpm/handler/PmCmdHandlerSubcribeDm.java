package com.neoway.iot.dgw.output.iotpm.handler;

import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.common.tsd.TSDPoint;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotpm.storage.PMDSink;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @desc: 性能数据上报-订阅DM数据
 * @author: 20200312686
 * @date: 2020/7/17 16:22
 */
public class PmCmdHandlerSubcribeDm implements PmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(PmCmdHandlerSubcribeDm.class);
    private PMDSink sink;

    public PmCmdHandlerSubcribeDm(PMDSink sink){
        this.sink=sink;
    }
    @Override
    public String name() {
        return null;
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> values=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(values)){
            return response;
        }
        List<TSDPoint> points = new ArrayList<>();
        try{
            for(Map<String,Object> valueMap:values){
                String ci=(String)valueMap.get("ci");
                if(!ci.equals("Status")){
                    continue;
                }
                String instanceid=valueMap.get("instanceid").toString();
                String metric=(String)valueMap.get("metric");
                int ts=((Double)valueMap.get("rs")).intValue();
                double value=(double) valueMap.get("value");
                TSDPoint point=TSDPoint.metric(metric)
                        .value(ts,value)
                        .tag("instanceid",instanceid)
                        .build();
                points.add(point);
            }
            sink.write(points);
            LOG.info("写入TSD成功。写入记录数={}",points.size());
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }
}
