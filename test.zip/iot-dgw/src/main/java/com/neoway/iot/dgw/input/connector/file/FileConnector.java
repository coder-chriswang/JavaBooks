package com.neoway.iot.dgw.input.connector.file;

import com.neoway.iot.dgw.input.connector.Connector;
import com.neoway.iot.dgw.input.connector.ConnectorReq;
import com.neoway.iot.dgw.input.connector.ConnectorRsp;

import java.util.Map;

/**
 * @desc: FileClient
 * @author: 20200312686
 * @date: 2020/6/23 14:13
 */
public class FileConnector extends Connector {

    @Override
    public ConnectorRsp downlink(ConnectorReq request) {
        return null;
    }

    @Override
    public Map<String, Object> configuration() {
        return null;
    }

    @Override
    public String name() {
        return "input-connector-file";
    }

}
