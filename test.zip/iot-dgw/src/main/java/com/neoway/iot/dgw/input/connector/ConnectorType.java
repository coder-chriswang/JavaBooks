package com.neoway.iot.dgw.input.connector;

/**
 * @desc: ConnectorType
 * @author: 20200312686
 * @date: 2020/6/30 15:59
 */
public enum ConnectorType {
    FILE("com.neoway.iot.dgw.input.connector.file.FileConnector"),
    JT808("com.neoway.iot.dgw.input.connector.jt808.JT808Connector"),
    MQTT("com.neoway.iot.dgw.input.connector.mqtt.MQTTConnector"),
    RESTFUL("com.neoway.iot.dgw.input.connector.restful.HTTPConnector"),
    OTHER(null);
    private final String connectorClassName;

    private ConnectorType(String connectorClassName) {
        this.connectorClassName = connectorClassName;
    }

    public String getConnectorClassName() {
        return connectorClassName;
    }
}
