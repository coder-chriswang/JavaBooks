package com.neoway.iot.dgw.output.iotdm;

import com.neoway.iot.dgw.output.iotdm.handler.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: DmCmdFactory
 * @author: 20200312686
 * @date: 2020/7/17 10:33
 */
public class DmCmdFactory {
    private static final Logger LOG = LoggerFactory.getLogger(DmCmdFactory.class);
    private static Map<DmCmd,DmCmdHandler> handlers=new HashMap<>();
    /**
     * @desc
     * @param cmdId
     * @return
     */
    public static DmCmdHandler buildHandler(String cmdId){
        DmCmd cmd=DmCmd.valueOf(cmdId.toUpperCase());;
        DmCmdHandler handler=handlers.get(cmd);
        if(null != handler){
            return handler;
        }else if(cmd == DmCmd.CMD_AUTH) {
            handler=new DmCmdHandlerAuth();
        }else if(cmd == DmCmd.CMD_INIT) {
            handler=new DmCmdHandlerUplinkData();
        }else if(cmd == DmCmd.CMD_REGISTER) {
            handler=new DmCmdHandlerRegister();
        }else if(cmd == DmCmd.CMD_CONFIG_GET) {
            handler=new DmCmdHandlerConfigGet();
        }else if(cmd == DmCmd.UPLINK_DM_DATA) {
            handler=new DmCmdHandlerUplinkData();
        }else if(cmd == DmCmd.UPLINK_DM_META) {
            handler=new DmCmdHandlerUplinkMeta();
        }else{
            return null;
        }
        LOG.info("cmdId={},desc={}",cmd.name(),cmd.getDesc());
        handlers.put(cmd,handler);
        return handler;
    }
}
