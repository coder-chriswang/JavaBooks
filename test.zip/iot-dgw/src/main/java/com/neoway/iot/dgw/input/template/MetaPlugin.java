package com.neoway.iot.dgw.input.template;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWRequest;
import org.dom4j.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @desc: 模板-plugin对象
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
public class MetaPlugin {
    private static final Logger LOG = LoggerFactory.getLogger(MetaPlugin.class);
    private String type;
    private String pluginText;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPluginText() {
        return pluginText;
    }

    public void setPluginText(String pluginText) {
        this.pluginText = pluginText;
    }

    /**
     * 创建前置插件对象
     * @param doc
     * @return
     * @throws DGWException
     */
    public static MetaPlugin createReqPlugin(Document doc) throws DGWException {
        return null;

    }

    /**
     * 创建后置插件对象
     * @param doc
     * @return
     * @throws DGWException
     */
    public static MetaPlugin createRspPlugin(Document doc) throws DGWException {
        return null;

    }
    /**
     * 属性校验
     * @param ns
     * @param id
     * @throws DGWException
     */
    public void validate(String ns,String id) throws DGWException{

    }

    /**
     * 模板翻译
     * @param req
     * @return
     * @throws DGWException
     */
    public String transfter(DGWRequest req) throws DGWException{
        return null;
    }
}
