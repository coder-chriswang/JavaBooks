package com.neoway.iot.dgw.common.redis;

import org.apache.commons.lang3.StringUtils;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @desc: JedisPool
 * @author: 20200312686
 * @date: 2020/7/7 11:50
 */
public class JedisUtil {
    private JedisPool jedisPool=null;
    public void start(Builder builder){
        if(null != jedisPool){
            return;
        }
        JedisPoolConfig config=builder.config();
        this.jedisPool=new JedisPool(config,builder.host,builder.port,builder.timeout,builder.pwd,builder.db);
    }

    public JedisPool getJedisPool() {
        return jedisPool;
    }

    public static Builder builder(){
        return new Builder();
    }
    public static class Builder {
        private int maxIdel=8;
        private int minIdel=1;
        private int maxWait=60000;
        private int maxActive=20;
        private boolean blockWhenExhausted=true;
        private String host;
        private int port;
        private int timeout=3000;
        private String pwd;
        private int db=0;
        public Builder(){
        }
        public Builder buildPool(String maxActive,String maxWait,String maxIdel,String minIdle){
            if(StringUtils.isNotEmpty(maxIdel)){
                this.maxIdel= Integer.valueOf(maxIdel);
            }
            if(StringUtils.isNotEmpty(maxActive)){
                this.maxIdel=Integer.valueOf(maxActive);
            }
            if(StringUtils.isNotEmpty(maxWait)){
                this.maxWait=Integer.valueOf(maxWait);
            }
            if(StringUtils.isNotEmpty(minIdle)){
                this.minIdel=Integer.valueOf(minIdle);
            }
            return this;
        }
        public Builder buildURI(String host,String port,String timeout,String pwd,String db){
            this.host=host;
            this.port=Integer.valueOf(port);
            this.timeout=Integer.valueOf(timeout);
            this.pwd=pwd;
            this.db=Integer.valueOf(db);
            return this;
        }

        public JedisPoolConfig config(){
            JedisPoolConfig config=new JedisPoolConfig();
            config.setTestOnBorrow(true);
            config.setMaxIdle(this.maxIdel);
            config.setMaxTotal(this.maxActive);
            config.setMinIdle(this.minIdel);
            config.setMaxWaitMillis(this.maxWait);
            config.setBlockWhenExhausted(this.blockWhenExhausted);
            return config;
        }
    }
}
