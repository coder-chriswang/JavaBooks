package com.neoway.iot.dgw.common.config;

import com.google.gson.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileInputStream;
import java.util.Map;

/**
 * @desc: DGW运行配置参数
 * @author: 20200312686
 * @date: 2020/6/23 10:08
 */
public class DGWConfig  {
    private static final Logger LOG = LoggerFactory.getLogger(DGWConfig.class);
    private static DGWConfig env=null;
    private Map<String,Object> pro;
    private DGWConfig(){
    }
    public static DGWConfig getInstance(){
        if(env == null){
            env=new DGWConfig();
        }
        return env;
    }
    public void start(String etc) throws Exception{
        Yaml dgwYml=new Yaml();
        File f=new File(etc);
        Map<String,Object> result=dgwYml.load(new FileInputStream(f));
        this.pro=result;
        LOG.debug("DGW配置加载：{}", new Gson().toJson(this.pro));
    }
    public void stop(){
        this.pro.clear();
    }
    public Object getValue(String key){
        return pro.get(key);
    }

    public Map<String, Object> getPro() {
        return pro;
    }
}
