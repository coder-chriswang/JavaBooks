package com.neoway.iot.dgw.output.iotem.storage;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.elastic.*;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: EMDElasticSink
 * @author: Chris(wangchao)
 * @date: 2020/7/1 16:44
 */
public class EMDElasticSink extends EMDAbstractSink {
    private static final Logger LOG = LoggerFactory.getLogger(EMDElasticSink.class);
    private static final String CLIENT_TYPE = "dgw.output.em.es.client.type";
    private static final String HOST_NAMES = "dgw.output.em.es.host.names";
    private static final String CLUSTER_NAME = "dgw.output.em.es.cluster.name";
    private static final String REST_PORT = "dgw.output.em.es.rest.port";
    private static final String TRANSPORT_PORT = "dgw.output.em.es.transport.port";
    private static final String REST_SCHEME = "dgw.output.em.es.rest.scheme";
    private static final String SIMPLE_INDEX_START = "dgw.output.em.es.simple.index.start";
    private static final String INDEX_PREFIX = "dgw.output.em.es.index.name";
    private static final String TIME_FORM = "dgw.output.em.es.index.time.form";
    private static final String INDEX_TYPE = "dgw.output.em.es.index.type";
    private static final String DATA_TTL = "dgw.output.em.es.index.ttl";
    private static final String SPLIT_REGEX = ",";
    private AtomicBoolean isStarted = new AtomicBoolean(Boolean.FALSE);
    private ElasticClient client;
    private boolean simpleIndexStart;
    private String indexPrefix;
    private String indexType;
    private String timeForm;
    private long ttl;

    @Override
    public void start(DGWConfig env) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        try {
            ElasticConfig config = new ElasticConfig();
            processEsConfig(config, env);
            this.simpleIndexStart = Boolean.valueOf(String.valueOf(env.getValue(SIMPLE_INDEX_START)));
            this.indexPrefix = String.valueOf(env.getValue(INDEX_PREFIX));
            this.timeForm = String.valueOf(env.getValue(TIME_FORM));
            this.indexType = String.valueOf(env.getValue(INDEX_TYPE));
            this.ttl = Long.valueOf(String.valueOf(env.getValue(DATA_TTL)));
            this.client = ElasticClientFactory.getClient(config);
        } catch (Exception e) {
            LOG.error("创建es client失败！", e);
            throw new DGWException("", e.getMessage());
        }
        isStarted.set(true);
        LOG.info("em-out-elastic-sink启动成功!");
    }

    private void processEsConfig(ElasticConfig config, DGWConfig dgwConfig) {
        config.setClientType(String.valueOf(dgwConfig.getValue(CLIENT_TYPE)));
        config.setHostNames(String.valueOf(dgwConfig.getValue(HOST_NAMES)).split(SPLIT_REGEX));
        config.setClusterName(String.valueOf(dgwConfig.getValue(CLUSTER_NAME)));
        config.setRestPort(Integer.valueOf(dgwConfig.getValue(REST_PORT).toString()));
        config.setRestScheme(String.valueOf(dgwConfig.getValue(REST_SCHEME)));
        config.setTransportPort(Integer.valueOf(dgwConfig.getValue(TRANSPORT_PORT).toString()));
    }

    @Override
    void doWrite(List<EMDPoint> points) throws DGWException {
        if (CollectionUtils.isEmpty(points)) {
            return;
        }
        List<ElasticPoint> elasticPointList = new ArrayList<>();
        for (EMDPoint point : points) {
            ElasticPoint elasticPoint = new ElasticPoint();
            elasticPoint.setTs(point.getEventSt());
            elasticPoint.setValue(point.toString());
            elasticPointList.add(elasticPoint);
        }
        ElasticIndexNameBuilder elasticIndexNameBuilder;
        // 默认开启简单索引
        if (Boolean.FALSE.equals(simpleIndexStart)) {
            elasticIndexNameBuilder = new ElasticTimeBasedIndexNameBuilder(timeForm);
        } else {
            elasticIndexNameBuilder = new ElasticSimpleIndexNameBuilder(indexPrefix);
        }
        try {
            this.client.execute(elasticPointList, elasticIndexNameBuilder, indexType, ttl);
        } catch (Exception e) {
            LOG.error("批量执行插入es失败！", e);
        }
    }
}
