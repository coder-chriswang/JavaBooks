package com.neoway.iot.dgw.common;

/**
 * @desc: 指令ID
 * @author: 20200312686
 * @date: 2020/7/2 13:48
 */
public enum DGWCmd {
    UPLINK_DM_DATA("资源数据上报"),
    UPLINK_DM_META("资源模型上报"),
    MSG_DM("资源消息"),
    UPLINK_PM_DATA("指标数据上报"),
    UPLINK_PM_META("指标模型上报"),
    MSG_PM("指标消息"),
    UPLINK_EM_DATA("事件数据上报"),
    UPLINK_EM_META("事件模型上报"),
    MSG_EM("事件消息"),
    UPLINK_FM_DATA("告警数据上报"),
    UPLINK_FM_META("告警模型上报"),
    MSG_FM("告警消息"),
    UPLINK_LM_DATA("位置数据上报"),
    UPLINK_LM_META("位置模型上报"),
    MSG_LM("位置消息");
    private final String desc;

    private DGWCmd(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
