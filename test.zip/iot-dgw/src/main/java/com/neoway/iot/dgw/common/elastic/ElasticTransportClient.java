package com.neoway.iot.dgw.common.elastic;

import com.neoway.iot.dgw.common.utils.DgwJsonUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.util.List;
import java.util.Objects;

/**
 * @desc: 基于elasticsearch-client-transport实现。
 * @author Chris(wangchao)
 * @date: 2020/7/1 15:43
 */
public class ElasticTransportClient implements ElasticClient {
    public static final Logger LOG = LoggerFactory.getLogger(ElasticTransportClient.class);
    private static final String CLUSTER_NAME = "cluster.name";
    private static final String CLUSTER_TRANSPORT_SNIFF = "client.transport.sniff";
    private static final String EVENT = "event";

    private TransportClient transportClient;

    public ElasticTransportClient(ElasticConfig elasticConfig) {
        this.transportClient = this.createClient(elasticConfig);
    }

    private TransportClient createClient(ElasticConfig elasticConfig) {
        Objects.requireNonNull(elasticConfig);
        TransportClient client = null;
        String clusterName = elasticConfig.getClusterName();
        String [] hostNames = elasticConfig.getHostNames();
        int port = elasticConfig.getTransportPort();
        try {
            Settings settings = Settings.builder()
                    .put(CLUSTER_NAME, clusterName)
                    .put(CLUSTER_TRANSPORT_SNIFF, Boolean.TRUE.toString()).build();
            PreBuiltTransportClient preBuiltTransportClient = new PreBuiltTransportClient(settings);
            // 取值单个节点
            client = preBuiltTransportClient.addTransportAddress(new TransportAddress(InetAddress.getByName(hostNames[0]), port));
            // 采取集群模式
            for (int i=1; i<hostNames.length; i++) {
                client.addTransportAddress(new TransportAddress(InetAddress.getByName(hostNames[i]), port));
            }
        } catch (Exception e) {
            LOG.error("创建TransportClient失败！", e);
        }
        return client;
    }

    @Override
    public void addEvent(ElasticPoint event, ElasticIndexNameBuilder indexNameBuilder, String indexType, long ttlMs) throws Exception {
        long start = System.currentTimeMillis();
        if (event == null) {
            return;
        }
        XContentBuilder contentBuilder= XContentFactory.jsonBuilder()
                .startObject().field(EVENT, DgwJsonUtils.writeValueAsString(event))
                .endObject();
        try {
            transportClient.prepareIndex(indexNameBuilder.getIndexName(event), indexType).setSource(contentBuilder).get();
        } catch (Exception e) {
            LOG.error("es存储错误！", e);
            throw new RuntimeException(e);
        }
        LOG.info("es存储耗时:{}ms", System.currentTimeMillis() - start);
    }

    @Override
    public void execute(List<ElasticPoint> events, ElasticIndexNameBuilder indexNameBuilder, String indexType, long ttlMs) throws Exception {
        long start = System.currentTimeMillis();
        if (CollectionUtils.isEmpty(events)) {
            return;
        }
        try {
            BulkRequestBuilder bulkRequest = transportClient.prepareBulk();
            for (ElasticPoint elasticPoint : events) {
                XContentBuilder contentBuilder= XContentFactory.jsonBuilder()
                        .startObject().field(EVENT, DgwJsonUtils.writeValueAsString(elasticPoint))
                        .endObject();
                bulkRequest.add(transportClient.prepareIndex(indexNameBuilder.getIndexName(elasticPoint), indexType).setSource(contentBuilder));
            }
            bulkRequest.get();
        } catch (Exception e) {
            LOG.error("es存储错误！", e);
            throw new RuntimeException(e);
        }
        LOG.info("es存储耗时:{}ms", System.currentTimeMillis() - start);
    }
}
