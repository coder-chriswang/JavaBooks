package com.neoway.iot.dgw.output.iotdm.handler;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.*;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotdm.DmCmd;
import com.neoway.iot.sdk.dmk.DMRunner;
import com.neoway.iot.sdk.dmk.data.DMDataPoint;
import com.neoway.iot.sdk.dmk.meta.DMMMetaNs;
import com.neoway.iot.sdk.dmk.meta.DMMetaCI;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.*;

/**
 * @desc: 资源模型信息注册
 * @author: 20200312686
 * @date: 2020/7/17 10:23
 */
public class DmCmdHandlerUplinkMeta implements DmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(DmCmdHandlerUplinkMeta.class);
    private static final String DM_DIR_NAME="cmdb";
    private static final String EXT_DIR_NAME="ext";
    @Override
    public String name() {
        return DmCmd.UPLINK_DM_META.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        Gson gson = new Gson();
        DGWResponse response=new DGWResponse();
        List<Map<String,Object>> messages=event.getEvents();
        for(Map<String,Object> proMap:messages){
            String proJson=gson.toJson(proMap);
            DGWProduct product = gson.fromJson(proJson, DGWProduct.class);
            try{
                String path=product.getPath()+ File.separator+DM_DIR_NAME;
                DMRunner.getInstance().addMeta(path,buildMetaNS(product));
                List<DGWProModle> models=product.getModels();
                for(DGWProModle model:models){
                    String cmdbPath=model.getPath()+File.separator+DM_DIR_NAME;
                    List<DMMetaCI> metaCis=DMRunner.getInstance().addMeta(cmdbPath,buildMetaNS(product));
                    if(CollectionUtils.isEmpty(metaCis)){
                        continue;
                    }
                    for(DMMetaCI metaCi:metaCis){
                        model.addCis(metaCi.getCi());
                    }

                }
                addDataForModle(product);

            }catch (Exception e){
                LOG.error(e.getMessage(),e);
                response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
                response.setMsg(e.getMessage());
                break;
            }

        }

        return response;
    }

    /**
     * @desc 添加模型域
     * @param product
     */
    private void addDataForModle(DGWProduct product){
        List<DGWProModle> models=product.getModels();
        if(CollectionUtils.isEmpty(models)){
            return;
        }
        List<DMDataPoint> points=new ArrayList<>();
        for(DGWProModle model:models){
            DMDataPoint point=DMDataPoint.builder(product.getId(), DMMetaCI.DEFAULT_TENENT,model.getCi());
            Map<String,Object> value=model.buildColumn();
            points.add(point.buildColumns(value));
        }
        DMRunner.getInstance().write(points);
    }
    /**
     * @desc
     * @param pro
     * @return
     */
    private DMMMetaNs buildMetaNS(DGWProduct pro){
        DMMMetaNs ns=new DMMMetaNs();
        ns.setId(pro.getId());
        ns.setName(pro.getName());
        ns.setNamespace(pro.getNamespace());
        ns.setDesc(pro.getDesc());
        ns.setVendor(pro.getVendor());
        ns.setVendorName(pro.getVendorName());
        ns.setNeedCreateDB(pro.isCreateDB());
        return ns;
    }
}
