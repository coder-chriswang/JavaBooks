package com.neoway.iot.dgw.common.freemarker;

import com.google.common.hash.Hashing;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.input.connector.mqtt.MQTTConnector;
import freemarker.cache.MruCacheStorage;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.commons.codec.Charsets;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.StringWriter;

/**
 * @desc: FreeMarkerTemplate
 * @author: 20200312686
 * @date: 2020/7/2 9:28
 */
public class FreeMarkerTemplate {
    private static final Logger LOG = LoggerFactory.getLogger(FreeMarkerTemplate.class);
    private static Configuration configuration;

    public static void init(DGWConfig env) throws DGWException{
        try{
            configuration=Configuration.getDefaultConfiguration();
            configuration.setDefaultEncoding("UTF-8");
            configuration.setSharedVariable("env",env.getPro());
            //添加自定义指令：hash指令
            configuration.setSharedVariable("dgw_hash",new FreemarkerDgwHash());
            //添加自定义指令：UTC字符串事件转换为毫秒时间戳
            configuration.setSharedVariable("dgw_ts",null);
            configuration.setSharedVariable("dgw_base64",new FreemarkerDgwBase64());
            configuration.setNumberFormat("#");
            configuration.setCacheStorage(new MruCacheStorage(20,50));
            StringTemplateLoader loader= new StringTemplateLoader();
            configuration.setTemplateLoader(loader);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }

    }

    /**
     * @desc 模板翻译
     * @param tpl 模板
     * @param context 数据上下文
     * @return 翻译后字符串
     * @throws IOException
     * @throws TemplateException
     */
    public static String transform(String tpl,Object context) throws IOException, TemplateException {
        String tplName=Hashing.md5().hashString(tpl, Charsets.UTF_8).toString();

        Template template=configuration.getTemplate(tplName, null, null,
                null, true, true);
        if(null == template){
            StringTemplateLoader loader=(StringTemplateLoader)configuration.getTemplateLoader();
            template=new Template(tplName,tpl,configuration);
            loader.putTemplate(tplName,tpl);
        }
        StringWriter writer = null;
        try{
            writer=new StringWriter();
            template.process(context,writer);
            writer.flush();
            return StringUtils.trimToEmpty(writer.toString());
        }finally {
            if(null != writer){
                writer.close();
            }
        }

    }


}
