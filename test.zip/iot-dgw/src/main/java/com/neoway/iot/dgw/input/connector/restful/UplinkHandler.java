package com.neoway.iot.dgw.input.connector.restful;

import com.neoway.iot.dgw.common.DGWRequest;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.input.connector.Connector;
import com.neoway.iot.dgw.input.connector.ConnectorManager;
import com.neoway.iot.dgw.input.connector.ConnectorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 上行数据报文
 * @author: 20200312686
 * @date: 2020/6/30 9:53
 */
public class UplinkHandler {
    private static final Logger LOG = LoggerFactory.getLogger(UplinkHandler.class);
    public static Mono<ServerResponse> uplinkEvent(ServerRequest request){
        Map<String,Object> mapBody=new HashMap<>();
        try{
            request.bodyToMono(Map.class).subscribe(map -> BeanUtils.copyProperties(map,mapBody));
            Connector connector= ConnectorManager.getInstance().getConnector(ConnectorType.RESTFUL.name());
            DGWRequest innReq=new DGWRequest();
            //TODO 构造完整innReq
            DGWResponse response=connector.uplink(innReq);
            return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(BodyInserters.fromObject(response));

        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return ServerResponse.status(500).contentType(MediaType.APPLICATION_JSON).body(BodyInserters.empty());
        }
    }
}
