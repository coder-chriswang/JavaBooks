package com.neoway.iot.dgw.common.elastic;

import cn.hutool.core.date.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

/**
 * @desc: 根据配置，Y、M、D三种 分别表示按年，按月，按天构建索引
 * @author: 20200312686
 * @date: 2020/7/1 15:49
 */
public class ElasticTimeBasedIndexNameBuilder implements ElasticIndexNameBuilder {
    private static final Logger LOG = LoggerFactory.getLogger(ElasticTimeBasedIndexNameBuilder.class);
    private static final String YEAR_FORMAT = "yyyy";
    private static final String MONTH_FORMAT = "yyyy-MM";
    private static final String DAY_FORMAT = "yyyy-MM-dd";
    private static final String YEAR_FORM = "Y";
    private static final String MONTH_FORM = "M";
    private static final String DAY_FORM = "D";
    private String timeForm;

    public ElasticTimeBasedIndexNameBuilder(String timeForm) {
        this.timeForm = timeForm;
    }

    @Override
    public String getIndexName(ElasticPoint event) {
        String index;
        if (event == null || event.getTs() <= 0) {
            return "";
        }
        long ts = event.getTs();
        try {
            Date date = DateUtil.date(ts);
            if (YEAR_FORM.equals(timeForm)) {
                index = DateUtil.format(date, YEAR_FORMAT);
            } else if (MONTH_FORM.equals(timeForm)) {
                index = DateUtil.format(date, MONTH_FORMAT);
            } else if (DAY_FORM.equals(timeForm)) {
                index = DateUtil.format(date, DAY_FORMAT);
            } else {
                index = "";
                LOG.error("配置的索引规则存在问题！timeForm={}", timeForm);
            }
        } catch (Exception e) {
            LOG.error("日期转换失败！", e);
            index = "";
        }
        return index;
    }

}
