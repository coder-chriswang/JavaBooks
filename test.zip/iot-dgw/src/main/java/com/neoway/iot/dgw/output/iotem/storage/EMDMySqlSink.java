package com.neoway.iot.dgw.output.iotem.storage;

import com.google.common.hash.Hashing;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.apache.commons.codec.Charsets;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: EMDMySqlSink
 * @author: Chris(wangchao)
 * @date: 2020/7/1 16:44
 */
public class EMDMySqlSink extends EMDAbstractSink {
    private static final Logger LOG = LoggerFactory.getLogger(EMDMySqlSink.class);
    public static final String PARTITION = "dgw.output.em.mysql.partition";
    public static final String TABLE_NAME = "EM_VALUE";
    /**
     * 建表语句
     */
    public static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS %s ( "
                    + "event_no BIGINT NOT NULL COMMENT '流水号', "
                    + "event_id VARCHAR(32) NOT NULL COMMENT '事件ID', "
                    + "event_name VARCHAR(64) NOT NULL COMMENT '事件名称', "
                    + "event_category VARCHAR(32) NOT NULL COMMENT '事件分类(OM,Device)', "
                    + "event_type VARCHAR(32) NOT NULL COMMENT '事件类型(System,Operate)', "
                    + "event_severity VARCHAR(32) NOT NULL COMMENT '事件级别(Major,Normal)', "
                    + "event_info TEXT NOT NULL COMMENT '事件详情', "
                    + "event_st int(10) DEFAULT NULL COMMENT '事件发生时间', "
                    + "event_et int(10) DEFAULT NULL COMMENT '事件结束时间', "
                    + "event_result TEXT NOT NULL COMMENT '事件处理结果', "
                    + "client_ip VARCHAR(128) DEFAULT NULL COMMENT '客户端IP', "
                    + "instance_id BIGINT NOT NULL COMMENT '资源ID', "
                    + "PRIMARY KEY(`event_no`), "
                    + "INDEX `event_st`(`event_st`) USING BTREE, "
                    + "INDEX `event_et`(`event_et`) USING BTREE"
                    + " ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='事件数据表' ROW_FORMAT=DYNAMIC;";
    /**
     * 批量插入语句
     */
    public static final String BATCH_INSERT ="INSERT INTO {0}(" +
            "`event_no`," +
            "`event_id`," +
            "`event_name`," +
            "`event_category`," +
            "`event_type`," +
            "`event_severity`," +
            "`event_info`," +
            "`event_st`," +
            "`event_et`," +
            "`event_result`," +
            "`client_ip`," +
            "`instance_id`" +
            ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

    private AtomicBoolean isStarted = new AtomicBoolean(Boolean.FALSE);
    private int partition = 1;
    @Override
    public void start(DGWConfig env) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        try {
            super.start(env);
            this.partition = (Integer) env.getValue(PARTITION);
            if(this.partition < 1){
                this.partition = 1;
            }
            this.createTableIfNotExist(this.partition);
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new DGWException("", e.getMessage());
        }
        isStarted.set(true);
        LOG.info("em-out-mysql-sink启动成功!");
    }

    /**
     * 创建数据表
     */
    private void createTableIfNotExist(int partition) throws SQLException {
        for (int index = 0; index<partition; index++) {
            String tableName = TABLE_NAME + "_" + index;
            String sql = String.format(CREATE_TABLE, tableName);
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            runner.update(sql);
        }
    }

    /**
     * @desc 定位数据表
     * @param point
     * @return
     */
    private String getTable(EMDPoint point){
        String instanceid=String.valueOf(point.getInstanceId());
        int bucket=Hashing.consistentHash(Hashing.md5().hashString(instanceid, Charsets.UTF_8),this.partition);
        String table=TABLE_NAME+"_"+bucket;
        return table;
    }

    @Override
    void doWrite(List<EMDPoint> points) throws DGWException {
        if(CollectionUtils.isEmpty(points)){
            return;
        }
        Map<String,List<Object[]>> groupMap=new HashMap<>();
        try{
            for(EMDPoint point:points){
                if(point.getEventNo() <= 0){
                    point.buildEventNo();
                }
                String table=getTable(point);
                Object[] param=point.getParam();
                List<Object[]> params=groupMap.get(table);
                if(null == params){
                    params=new ArrayList<>();
                    groupMap.put(table,params);
                }
                params.add(param);
            }
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            for(Map.Entry<String,List<Object[]>> entry:groupMap.entrySet()){
                Object[][] params=new Object[entry.getValue().size()][];
                String sql=MessageFormat.format(BATCH_INSERT,entry.getKey());
                params=entry.getValue().toArray(params);
                runner.batch(sql,params);

            }
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException(DGWCodeEnum.EXCEPTION_CODE.getCode(),e.getMessage());
        }

    }
}
