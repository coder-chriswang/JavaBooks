package com.neoway.iot.dgw.common.tsd;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

/**
 * @desc: 异步写入回调
 * @author: 20200312686
 * @date: 2020/6/30 18:16
 */
public class TSDputHttpCallback implements FutureCallback<HttpResponse> {
    private static final Logger LOG = LoggerFactory.getLogger(TSDputHttpCallback.class);
    private TSDPutCallBack callBack;
    private List<TSDPoint> points;
    public TSDputHttpCallback() {
    }

    public TSDputHttpCallback(TSDPutCallBack callBack, List<TSDPoint> points) {
        this.callBack = callBack;
        this.points = points;
    }

    @Override
    public void completed(HttpResponse response) {
        if (callBack != null) {
            // 无论成功失败，response body的格式始终是DetailResult的形式
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                try {
                    String content = EntityUtils.toString(entity, Charset.defaultCharset());
                    TSDResult tsdResult = TSDJson.readValue(content, TSDResult.class);
                    if (tsdResult.getFailed() == 0) {
                        LOG.debug("批量添加错误数量为0，全部成功");
                        this.callBack.response(points, tsdResult);
                    } else {
                        LOG.debug("批量添加出现错误，错误个数:{}", tsdResult.getFailed());
                        this.callBack.responseError(points, tsdResult);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void failed(Exception e) {
        if (callBack != null) {
            LOG.error("批量添加请求失败,error:{}", e.getMessage());
            this.callBack.failed(points, e);
        }
    }

    @Override
    public void cancelled() {

    }

}
