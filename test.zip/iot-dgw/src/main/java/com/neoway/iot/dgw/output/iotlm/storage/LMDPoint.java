package com.neoway.iot.dgw.output.iotlm.storage;

/**
 * @desc: LMDPoint
 * @author: 20200312686
 * @date: 2020/7/1 18:28
 */
public class LMDPoint {
    //经度
    private float lat;
    //纬度
    private float lon;
    //上报时间
    private long ts;
    //资源ID
    private String instanceId;

    public float getLat() {
        return lat;
    }

    public void setLat(float lat) {
        this.lat = lat;
    }

    public float getLon() {
        return lon;
    }

    public void setLon(float lon) {
        this.lon = lon;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public Object[] getParam() {
        Object[] param = new Object[]{
                this.getInstanceId(),
                this.getLat(),
                this.getLon(),
                this.getTs()
        };
        return param;
    }
}
