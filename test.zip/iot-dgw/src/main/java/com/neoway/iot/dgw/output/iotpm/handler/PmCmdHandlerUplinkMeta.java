package com.neoway.iot.dgw.output.iotpm.handler;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotpm.PmCmd;
import com.neoway.iot.dgw.output.iotpm.storage.PMDSink;
import com.neoway.iot.dgw.output.iotpm.storage.PmMetaMetric;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * @desc: 指标元数据上报
 * @author: 20200312686
 * @date: 2020/7/17 15:07
 */
public class PmCmdHandlerUplinkMeta implements PmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(PmCmdHandlerUplinkMeta.class);
    private PMDSink sink;

    public PmCmdHandlerUplinkMeta(PMDSink sink){
        this.sink=sink;

    }
    @Override
    public String name() {
        return PmCmd.UPLINK_PM_DATA.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> events=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(events)){
            return response;
        }
        Gson gson = new Gson();
        try{
            String pointArrJson = gson.toJson(events);

            List<PmMetaMetric> metas = gson.fromJson(pointArrJson, new TypeToken<List<PmMetaMetric>>() {}.getType());
            for(PmMetaMetric meta:metas){
                meta.validate();
                meta.buildCode();
            }
            this.sink.registerMeta(metas);
            return response;
        }catch (DGWException e){
            response.setCode(e.getCode());
            response.setMsg(e.getMessage());
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }

    }
}
