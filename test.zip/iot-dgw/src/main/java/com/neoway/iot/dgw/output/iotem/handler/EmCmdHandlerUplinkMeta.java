package com.neoway.iot.dgw.output.iotem.handler;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neoway.iot.dgw.common.DGWCodeEnum;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotem.EmCmd;
import com.neoway.iot.dgw.output.iotem.storage.EMDSink;
import com.neoway.iot.dgw.output.iotem.storage.EMMeta;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * @desc: EmCmdHandlerUplinkMeta
 * @author: 20200312686
 * @date: 2020/7/20 17:13
 */
public class EmCmdHandlerUplinkMeta implements EmCmdHandler {
    private static final Logger LOG = LoggerFactory.getLogger(EmCmdHandlerUplinkMeta.class);
    private EMDSink sink;
    public EmCmdHandlerUplinkMeta(EMDSink sink){
        this.sink=sink;
    }
    @Override
    public String name() {
        return EmCmd.UPLINK_EM_META.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        List<Map<String,Object>> events=event.getEvents();
        DGWResponse response=new DGWResponse();
        if(CollectionUtils.isEmpty(events)){
            return response;
        }
        Gson gson = new Gson();
        try{
            String pointArrJson = gson.toJson(events);

            List<EMMeta> metas = gson.fromJson(pointArrJson, new TypeToken<List<EMMeta>>() {}.getType());
            for(EMMeta meta:metas){
                meta.validate();
            }
            this.sink.registerMeta(metas);
            return response;
        }catch (DGWException e){
            response.setCode(e.getCode());
            response.setMsg(e.getMessage());
            return response;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            response.setCode(DGWCodeEnum.EXCEPTION_CODE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
    }
}
