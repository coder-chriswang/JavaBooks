package com.neoway.iot.dgw.common.elastic;

import com.neoway.iot.dgw.common.utils.DgwJsonUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.http.HttpHost;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.Objects;


/**
 * @desc: 基于elasticsearch-rest-client实现
 * @author Chris(wangchao)
 * @date: 2020/7/1 15:42
 */
public class ElasticRestClient implements ElasticClient {
    private static final Logger LOG = LoggerFactory.getLogger(ElasticRestClient.class);

    private RestHighLevelClient restClient;
    public ElasticRestClient(ElasticConfig elasticConfig) {
        this.restClient = this.createClient(elasticConfig);
    }

    private RestHighLevelClient createClient(ElasticConfig elasticConfig) {
        Objects.requireNonNull(elasticConfig);
        RestHighLevelClient client = null;
        try {
            // 取值单个节点
            String[] hostNames = elasticConfig.getHostNames();
            int port = elasticConfig.getRestPort();
            String scheme = elasticConfig.getRestScheme();
            RestClientBuilder restClientBuilder = RestClient.builder(new HttpHost(hostNames[0], port, scheme));
            // 存在集群模式
            for (int i=1; i < hostNames.length; i++) {
                restClientBuilder = RestClient.builder(new HttpHost(hostNames[i], port, scheme));
            }
            client = new RestHighLevelClient(restClientBuilder);
        } catch (Exception e) {
            LOG.error("创建RestHighLevelClient失败！", e);
        }
        return client;
    }

    @Override
    public void addEvent(ElasticPoint event, ElasticIndexNameBuilder indexNameBuilder, String indexType, long ttlMs) throws Exception {
        long start = System.currentTimeMillis();
        if (event == null) {
            return;
        }
        IndexRequest indexRequest = new IndexRequest();
        indexRequest.index(indexNameBuilder.getIndexName(event)).type(indexType);
        indexRequest.source(DgwJsonUtils.writeValueAsString(event), XContentType.JSON);
        try {
            RequestOptions.Builder builder = RequestOptions.DEFAULT.toBuilder();
            restClient.index(indexRequest, builder.build());
        } catch (IOException e) {
            LOG.error("es存储错误！", e);
            throw new RuntimeException(e);
        }
        LOG.info("es存储耗时:{}ms", System.currentTimeMillis() - start);
    }

    @Override
    public void execute(List<ElasticPoint> events, ElasticIndexNameBuilder indexNameBuilder, String indexType, long ttlMs) throws Exception {
        long start = System.currentTimeMillis();
        if (CollectionUtils.isEmpty(events)) {
            return;
        }
        BulkRequest bulkRequest = new BulkRequest();
        for (ElasticPoint elasticPoint : events) {
            IndexRequest indexRequest = new IndexRequest();
            indexRequest.index(indexNameBuilder.getIndexName(elasticPoint)).type(indexType);
            indexRequest.source(DgwJsonUtils.writeValueAsString(elasticPoint), XContentType.JSON);
            bulkRequest.add(indexRequest);
        }
        try {
            RequestOptions.Builder builder = RequestOptions.DEFAULT.toBuilder();
            restClient.bulk(bulkRequest, builder.build());
        } catch (IOException e) {
            LOG.error("es存储错误！", e);
            throw new RuntimeException(e);
        }
        LOG.info("es存储耗时:{}ms", System.currentTimeMillis() - start);
    }
}
