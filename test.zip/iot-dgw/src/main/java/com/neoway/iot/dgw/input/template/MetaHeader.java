package com.neoway.iot.dgw.input.template;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWRequest;
import com.neoway.iot.dgw.common.freemarker.FreeMarkerTemplate;
import com.neoway.iot.dgw.common.utils.DGWUtils;
import com.neoway.iot.dgw.input.InputManager;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 模板-header对象
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
public class MetaHeader {
    private static final Logger LOG = LoggerFactory.getLogger(MetaHeader.class);
    private static final String TPL = "<#if template.header??>${template.header}</#if>";
    //header模板
    private String headerText;

    public String getHeaderText() {
        return this.headerText;
    }

    /**
     *
     * 解析模板文件
     * @param data 模板数据
     * @return
     * @throws DGWException
     */
    public static MetaHeader build(Map<String,Object> data) throws DGWException {
        try{
            String transValue=FreeMarkerTemplate.transform(TPL,data);
            MetaHeader header = new MetaHeader();
            header.headerText= DGWUtils.replaceBlank(transValue);
            if(StringUtils.isEmpty(header.getHeaderText())){
                return null;
            }
            return header;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }

    }

    /**
     * 模板翻译
     * @param req
     * @return
     * @throws DGWException
     */
    public String transfter(DGWRequest req) throws DGWException{
        try {
            Map<String,Object> contextMap=new HashMap<>();
            contextMap.put("request",req);
            return FreeMarkerTemplate.transform(this.getHeaderText(),contextMap);
        } catch (IOException e) {
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        } catch (TemplateException e) {
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        } catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new DGWException("",e.getMessage());
        }
    }
}
