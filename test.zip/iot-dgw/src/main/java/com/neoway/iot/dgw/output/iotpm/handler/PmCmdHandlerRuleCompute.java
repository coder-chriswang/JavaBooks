package com.neoway.iot.dgw.output.iotpm.handler;

import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;
import com.neoway.iot.dgw.output.iotpm.PmCmd;
import com.neoway.iot.dgw.output.iotpm.storage.PMDSink;

/**
 * @desc: 阈值告警计算
 * @author: 20200312686
 * @date: 2020/7/17 15:11
 */
public class PmCmdHandlerRuleCompute implements PmCmdHandler {
    private PMDSink sink;

    public PmCmdHandlerRuleCompute(PMDSink sink){
        this.sink=sink;
    }
    @Override
    public String name() {
        return PmCmd.CMD_RULE_COMPUTE.name();
    }

    @Override
    public DGWResponse execute(OutputEvent event) {
        return null;
    }
}
