package com.neoway.iot.dgw;

import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @desc: 组件生命周期管理基类
 * @author: 20200312686
 * @date: 2020/6/22 12:32
 */
public abstract class DGAbstractLifecycleComponent implements DGLifecycleComponent {
    private static final Logger LOG = LoggerFactory.getLogger(DGAbstractLifecycleComponent.class);
    protected DGAbstractLifecycleComponent() {}
    @Override
    public void start() throws DGWException {
        LOG.info("组件：{} 开始启动", this.name());
        DGWConfig config=DGWConfig.getInstance();
        try{
            doStart(config);
            LOG.info("组件：{} 启动成功", this.name());
        }catch (DGWException e){

        }

    }

    protected abstract void doStart(DGWConfig env) throws DGWException;

    protected abstract String name();
    @Override
    public void stop() {
        LOG.info("组件：{} 停止", this.name());
    }


}
