package com.neoway.iot.dgw.output.iotlm.handler;

import com.neoway.iot.dgw.common.DGWResponse;
import com.neoway.iot.dgw.output.OutputEvent;

/**
 * <pre>
 *  描述: LmCmdHandler
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/21 14:36
 */
public interface LmCmdHandler {
    /**
     * @desc
     * @return cmd指令名称
     */
    String name();

    /**
     * @desc 指令处理
     * @param event 数据
     * @return
     */
    DGWResponse execute(OutputEvent event);
}
