package com.neoway.iot.dgw.input.connector;


import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.input.AbstractInput;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: Connector构造工厂
 * @author: 20200312686
 * @date: 2020/6/23 14:11
 */
public class ConnectorManager extends AbstractInput {
    private static final Logger LOG = LoggerFactory.getLogger(ConnectorManager.class);
    private static ConnectorManager factory=null;
    private Map<String,Connector> connectorMap=new HashMap<>();
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private ConnectorManager() {

    }
    public static ConnectorManager getInstance() {
        if (factory == null) {
            synchronized (ConnectorManager.class) {
                if (factory == null) {
                    factory = new ConnectorManager();
                }
            }
        }
        return factory;
    }
    @Override
    public void start(DGWConfig env) throws DGWException {
        if(isStarted.get()){
            return;
        }
        for(ConnectorType connectorType:ConnectorType.values()){
            if(connectorType == ConnectorType.OTHER){
                continue;
            }
            Connector connector=create(connectorType.name(),connectorType.getConnectorClassName());
            if(connector.isEnable()){
                connectorMap.put(connectorType.name().toLowerCase(),connector);
                connector.start(env);
            }
        }
        isStarted.set(true);
    }

    @Override
    public Map<String, Object> configuration() {
        Map<String,Object> values=new HashMap<>();
        for(Connector connector:connectorMap.values()){
            values.put(connector.name(),connector.configuration());
        }
        return values;
    }

    private Connector create(String name, String type) throws DGWException {
        LOG.info("创建Connector实例 类型={} clazz={}", name, type);
        Class<? extends Connector> clazz = getClass(name);
        try {
            return clazz.newInstance();
        } catch (Exception ex) {
            throw new DGWException("",ex.getMessage());
        }
    }

    /**
     * @desc 获取channel clazz
     * @param type
     * @return
     * @throws DGWException
     */
    private Class<? extends Connector> getClass(String type) throws DGWException {
        String clazzName = type;
        ConnectorType connectorType=ConnectorType.OTHER;
        try {
            connectorType=ConnectorType.valueOf(type.toUpperCase(Locale.ENGLISH));
        } catch (IllegalArgumentException ex) {
            LOG.error("Connector类型非内置，属于自定义", type);
        }
        if (!connectorType.equals(connectorType.OTHER)) {
            clazzName = connectorType.getConnectorClassName();
        }
        try {
            return (Class<? extends Connector>) Class.forName(clazzName);
        } catch (Exception ex) {
            throw new DGWException("",ex.getMessage());
        }
    }

    @Override
    public String name() {
        return "module-input-connector";
    }

    public Connector getConnector(String protocol){
       return connectorMap.get(StringUtils.trim(protocol).toLowerCase());
    }
}
