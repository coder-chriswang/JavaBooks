package com.neoway.iot.dgw.input.template;

import com.google.gson.Gson;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.DGWProModle;
import com.neoway.iot.dgw.common.DGWProduct;
import com.neoway.iot.dgw.common.freemarker.FreeMarkerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @desc: 模板对象
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
public class MetaTemplate {
    private static final Logger LOG = LoggerFactory.getLogger(MetaTemplate.class);
    public static final String POLICY_INIT="init";
    private static final String TPL = "{\"protocol\":\"${template.protocol}\"," +
            "\"log\":\"${(template.log)! \"\"}\"," +
            "\"name\":\"${template.name}\"," +
            "\"id\":\"${template.id}\"," +
            "\"policy\":\"${(template.policy)! \"\"}\"," +
            "\"desc\":\"${(template.desc) ! \"\"}\"}";
    //产品域
    private String pro;
    //模型域
    private String model;
    //模板标识
    private String id;
    //模板执行策略【init(启动即自动执行)】
    private String policy;
    //模板名称
    private String name;
    //模板使用的协议
    private String protocol;
    //模板日志级别
    private String log;
    //endpoint
    private MetaEndpoint endpoint;
    //header
    private MetaHeader header;
    //request
    private MetaRequest request;
    //response
    private MetaResponse response;

    private MetaTemplateEvent event;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MetaTemplate that = (MetaTemplate) o;
        return Objects.equals(pro, that.pro) &&
                Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pro, id);
    }

    public String getPro() {
        return pro;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getProtocol() {
        return protocol;
    }

    public String getLog() {
        return log;
    }

    public MetaEndpoint getEndpoint() {
        return endpoint;
    }

    public MetaHeader getHeader() {
        return header;
    }

    public MetaRequest getRequest() {
        return request;
    }

    public MetaResponse getResponse() {
        return response;
    }

    public String getPolicy() {
        return policy;
    }

    public MetaTemplateEvent getEvent() {
        return event;
    }

    /**
     *
     * 解析模板文件
     * @param f 模板
     * @param pro 产品域
     * @return
     * @throws DGWException
     */
    public static MetaTemplate build(File f, DGWProduct pro, DGWProModle model) throws DGWException {
        try{
            SAXReader reader = new SAXReader();
            Document doc = reader.read(f);
            JSONObject data= XML.toJSONObject(doc.asXML());
            Map<String,Object> dataMap=new HashMap<>();
            dataMap=new Gson().fromJson(data.toString(),Map.class);
            String transValue= FreeMarkerTemplate.transform(TPL,dataMap);
            MetaTemplate template = new Gson().fromJson(transValue,MetaTemplate.class);
            if(StringUtils.isEmpty(template.getId())){
                return null;
            }
            if(null != model){
                template.model=model.getId();
            }
            template.pro=pro.getId();
            template.endpoint=MetaEndpoint.build(dataMap);
            template.header=MetaHeader.build(dataMap);
            template.request=MetaRequest.build(dataMap);
            template.response=MetaResponse.build(dataMap);
            template.event=MetaTemplateEvent.build(dataMap);
            return template;
        }catch (DGWException e){
            LOG.error(f.getName(),e);
            throw e;
        }catch (Exception e){
            LOG.error(f.getName(),e);
            throw new DGWException("",e.getMessage());
        }
    }

    /**
     * 属性校验
     * @throws DGWException
     */
    public void validate() throws DGWException{

    }

    public boolean isDebugger(){
        if(this.getLog().equalsIgnoreCase("DEBUG")){
            return true;
        }else{
            return false;
        }
    }
}
