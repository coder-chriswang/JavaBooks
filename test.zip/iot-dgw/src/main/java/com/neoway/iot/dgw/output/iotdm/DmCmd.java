package com.neoway.iot.dgw.output.iotdm;

/**
 * @desc: DmCmd
 * @author: 20200312686
 * @date: 2020/7/17 10:12
 */
public enum DmCmd {
    UPLINK_DM_DATA("上报资源数据"),
    UPLINK_DM_META("注册资源模型"),
    CMD_INIT("数据初始化"),
    CMD_REGISTER("资源激活"),
    CMD_AUTH("资源登录鉴权"),
    CMD_CONFIG_GET("资源配置查询");
    private final String desc;

    private DmCmd(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
