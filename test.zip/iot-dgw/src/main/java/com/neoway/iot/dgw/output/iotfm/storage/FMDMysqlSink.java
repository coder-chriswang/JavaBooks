package com.neoway.iot.dgw.output.iotfm.storage;

import com.google.common.hash.Hashing;
import com.neoway.iot.dgw.common.DGWException;
import com.neoway.iot.dgw.common.config.DGWConfig;
import com.neoway.iot.dgw.common.jdbc.JdbcPool;
import com.neoway.iot.dgw.common.utils.DgwJsonUtils;
import com.neoway.iot.dgw.common.utils.IDWorker;
import org.apache.commons.codec.Charsets;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * <pre>
 *  描述: FMDMysqlSink
 *  我计划的流程：
 *  告警数据，在进行存储时候，将上报的活动告警数据缓存至Redis，并进行持久化至Mysql
 *  缓存的是instance_id下，alarm_serial_no, alarm_id,alarm_status, device_id
 *  更新告警状态或信息放在FMM工程操作
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/09 14:49
 */
public class FMDMysqlSink extends FMDAbstractSink {
    private static final Logger LOG = LoggerFactory.getLogger(FMDMysqlSink.class);
    private static final String PARTITION = "dgw.output.fm.data.partition";
    private static final String TABLE_NAME = "FM_VALUE";



    private AtomicBoolean isStarted = new AtomicBoolean(Boolean.FALSE);
    private int partition = 1;

    private static final String CREATE_TABLE =
            "CREATE TABLE IF NOT EXISTS %s ( "
            + "serial_no BIGINT(20) NOT NULL, "
            + "alarm_id VARCHAR(32) NOT NULL, "
            + "instance_id VARCHAR(32) NOT NULL, "
            + "instance_name VARCHAR(64) NOT NULL, "
            + "ci VARCHAR(64) NOT NULL, "
            + "alarm_name VARCHAR(64) NOT NULL, "
            + "alarm_severity VARCHAR(32) NOT NULL, "
            + "alarm_category VARCHAR(32) NOT NULL, "
            + "alarm_cause_text TEXT NOT NULL, "
            + "alarm_repair_text TEXT NOT NULL, "
            + "alarm_effect_business TEXT NOT NULL, "
            + "alarm_effect_device TEXT NOT NULL, "
            + "alarm_source VARCHAR(128) NOT NULL, "
            + "alarm_st BIGINT NOT NULL, "
            + "alarm_et BIGINT DEFAULT NULL, "
            + "alarm_status TINYINT NOT NULL, "
            + "alarm_desc TEXT DEFAULT NULL, "
            + "nativeid VARCHAR(32) DEFAULT NULL, "
            + "tenant_id VARCHAR(32) DEFAULT NULL, "
            + "alarm_count INT(11) DEFAULT 1, "
            + "PRIMARY KEY(serial_no) USING BTREE, "
            + "INDEX `alarm_id`(`alarm_id`) USING BTREE, "
            + "INDEX `alarm_status`(`alarm_status`) USING BTREE, "
            + "INDEX `alarm_st`(`alarm_st`) USING BTREE, "
            + "INDEX `alarm_et`(`alarm_et`) USING BTREE, "
            + "INDEX `nativeid`(`nativeid`) USING BTREE, "
            + "INDEX `instance_id`(`instance_id`) USING BTREE, "
            + "INDEX `tenant_id`(`tenant_id`) "
            + " ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='告警数据活动表' ROW_FORMAT=DYNAMIC;";

    private static final String QUERY_ONE_SQL = "SELECT COUNT(*) FROM %s WHERE alarm_id = ? AND nativeid = ?";
    private static final String UPDATE_ONE_SQL = "UPDATE %s SET alarm_count = alarm_count + 1 WHERE alarm_id = ? AND nativeid = ?";
    private static final String INSERT_ONE_SQL = "INSERT INTO %s VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

    @Override
    public void start(DGWConfig env) throws DGWException {
        if (isStarted.get()) {
            return;
        }
        try {
            super.start(env);
            this.partition = (Integer) env.getValue(PARTITION);
            if(this.partition < 1) {
                this.partition = 1;
            }
            this.createActiveTableIfNotExist(this.partition);

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
            throw new DGWException("", e.getMessage());
        }
        isStarted.set(true);
        LOG.info("fm-out-mysql-sink启动成功!");
    }



    @Override
    void doWrite(List<FMDPoint> points) throws DGWException {
        if (CollectionUtils.isEmpty(points)) {
            return;
        }
        QueryRunner runner = new QueryRunner(this.client.getDataSource());
        IDWorker idWorker = new IDWorker();
        for (FMDPoint point : points) {
            long serialNo = idWorker.nextId();
            point.setSerialNo(serialNo);
            String instanceId = point.getInstanceId();
            String instanceName = point.getInstanceName();
            String ci = point.getCi();
            String alarmId = point.getAlarmId();
            String deviceId = point.getNativeId();
            String alarmSource = point.getAlarmSource();
            // TODO 更新fmk之后 重新调整此处获取静态资源的逻辑
            String alarmName = "CPU使用过高";
            String alarmSeverity = "Major";
            String alarmCategory = "Device";
            String alarmCauseText = "CPU负载太高";
            String alarmRepairText = "确认模组软件问题或联系CPU厂商进行问题确认";
            String alarmEffectBusiness = "业务数据无法及时被获取";
            String alarmEffectDevice = "CPU持续负载过高影响模组正常功能性能";
            long alarmSt = point.getAlarmSt();
            long alarmEt = point.getAlarmEt();
            int alarmStatus = 1;
            String alarmDesc = point.getAlarmDesc();
            String tenantId = point.getTenantId();
            String tableName = getTable(point);
            String querySql = String.format(QUERY_ONE_SQL, tableName);
            String pointJson = "";
            try {
                pointJson = DgwJsonUtils.writeValueAsString(point);
                // 动态告警数据若存在则更新次数
                if ((Long) runner.query(querySql,new ScalarHandler(),alarmId, deviceId) == 1) {
                    String updateSql = String.format(UPDATE_ONE_SQL, tableName);
                    // 更新告警次数
                    runner.update(updateSql, alarmId, deviceId);
                } else {
                    String insertSql = String.format(INSERT_ONE_SQL, tableName);
                    // 插入数据
                    runner.update(insertSql, serialNo, alarmId, instanceId, instanceName,ci, alarmName, alarmSeverity, alarmCategory, alarmCauseText, alarmRepairText, alarmEffectBusiness, alarmEffectDevice, alarmSource, alarmSt, alarmEt, alarmStatus, alarmDesc, deviceId, tenantId, 1);
                }
            } catch (Exception e) {
                LOG.error("数据库插入动态告警数据操作异常！告警数据={}", pointJson, e);
            }
        }
        // 缓存热点告警数据
        try (Jedis jedis = this.jedisPool.getResource()) {
            for (FMDPoint point : points) {
                Map<String, String> dataMap = new HashMap<>();
                dataMap.put("alarmSerialNo", String.valueOf(point.getSerialNo()));
                dataMap.put("alarmId", point.getAlarmId());
                dataMap.put("alarmStatus", String.valueOf(1));
                dataMap.put("nativeId", point.getNativeId());
                String key = "FM:DATA:" + point.getInstanceId() + "#" + point.getNativeId();
                jedis.hmset(key, dataMap);
                // 假定缓存失效时间 7天
                jedis.expire(key, 7 * 24 * 3600);
            }
        } catch (Exception e) {
            LOG.error("缓存热点告警数据失败！", e);
            throw new DGWException("", e.getMessage());
        }
    }

    /**
     * 创建活动告警数据表
     */
    private void createActiveTableIfNotExist(int partition) throws SQLException {
        for (int index = 0; index<partition; index++) {
            String tableName = TABLE_NAME + "_" + index;
            String sql = String.format(CREATE_TABLE, tableName);
            QueryRunner runner = new QueryRunner(this.client.getDataSource());
            runner.update(sql);
        }
    }

    /**
     * @desc 定位数据表
     * @param point
     * @return 数据表名
     */
    private String getTable(FMDPoint point){
        String instanceId = String.valueOf(point.getInstanceId());
        int bucket = Hashing.consistentHash(Hashing.md5().hashString(instanceId, Charsets.UTF_8),this.partition);
        return TABLE_NAME + "_" + bucket;
    }

    /**
     * 获取FM的数据源
     * @return
     */
    public JdbcPool getClient() {
        return this.client;
    }
}
