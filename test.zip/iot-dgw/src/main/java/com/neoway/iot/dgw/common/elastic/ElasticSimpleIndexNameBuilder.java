package com.neoway.iot.dgw.common.elastic;

/**
 * @desc: 返回配置指定的索引名称
 * @author: 20200312686
 * @date: 2020/7/1 15:48
 */
public class ElasticSimpleIndexNameBuilder implements ElasticIndexNameBuilder {

    private String indexPrefix;

    public ElasticSimpleIndexNameBuilder(String indexPrefix) {
        this.indexPrefix = indexPrefix;
    }

    @Override
    public String getIndexName(ElasticPoint event) {
        return indexPrefix;
    }

}
