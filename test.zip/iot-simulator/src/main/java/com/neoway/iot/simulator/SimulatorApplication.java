package com.neoway.iot.simulator;

import com.neoway.iot.simulator.common.FreeMarkerTemplate;
import com.neoway.iot.simulator.connector.ConnectorManager;
import com.neoway.iot.simulator.scheduler.SimJobManager;
import com.neoway.iot.simulator.template.TemplateManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class SimulatorApplication implements CommandLineRunner {
	private static final Logger LOG = LoggerFactory.getLogger(SimulatorApplication.class);
	@Autowired
	private Environment env;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LOG.info("开始启动");
		SpringApplication.run(SimulatorApplication.class, args);
		LOG.info("启动成功");
	}
	@Override
	public void run(String... strings) throws Exception {
		SimConfig.getInstance().start(env);
		//模板引擎初始化
		FreeMarkerTemplate.init(SimConfig.getInstance());
		//模板初始化
		TemplateManager.getInstance().start(env);
		//任务初始化
		SimJobManager.getInstance().start();
		//connector初始化
		ConnectorManager.getInstance().start();
		//默认启动任务
		Boolean flag=env.getProperty("simulator.autostart",Boolean.class,false);
		if(flag){
			SimJobManager.getInstance().startJobs();
		}
	}
}
