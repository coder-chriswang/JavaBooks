package com.neoway.iot.simulator.common;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;
import java.util.Random;

/**
 * @desc: 生成随机数
 * @author: 20200312686
 * @date: 2020/7/15 16:36
 */
public class FreeMarkerSimRandom implements TemplateDirectiveModel {
    @Override
    public void execute(Environment environment, Map params, TemplateModel[] templateModels, TemplateDirectiveBody templateDirectiveBody) throws TemplateException, IOException {
        Random r=new Random();
        int num=r.nextInt(100)+1;
        Writer out=environment.getOut();
        out.write(String.valueOf(num));
    }
}
