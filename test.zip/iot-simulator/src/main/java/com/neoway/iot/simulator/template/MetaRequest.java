package com.neoway.iot.simulator.template;

import com.neoway.iot.simulator.SimRequest;
import com.neoway.iot.simulator.common.FreeMarkerTemplate;
import com.neoway.iot.simulator.common.SimUtils;
import com.neoway.iot.simulator.scheduler.SimTask;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 模板-request对象
 * @author: 20200312686
 * @date: 2020/6/23 10:29
 */
public class MetaRequest {
    private static final Logger LOG = LoggerFactory.getLogger(MetaRequest.class);
    private static final String TPL = "<#if template.request??>${template.request}<#else>\"\"</#if>";
    //request模板
    private String requestText;

    public String getRequestText() {
        return requestText;
    }

    /**
     * 创建Request对象
     * @param data 模板数据
     * @return
     */
    public static MetaRequest build(Map<String,Object> data){
        try{
            String transValue= FreeMarkerTemplate.transform(TPL,data);
            MetaRequest request = new MetaRequest();
            request.requestText= SimUtils.replaceBlank(transValue);
            if(StringUtils.isEmpty(request.getRequestText())){
                return null;
            }
            return request;
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        }
    }

    /**
     * 模板翻译
     * @param req
     * @return
     */
    public String transfter(SimTask req){
        try {
            Map<String,Object> contextMap=new HashMap<>();
            contextMap.put("task",req);
            return FreeMarkerTemplate.transform(this.getRequestText(),contextMap);
        } catch (IOException e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        } catch (TemplateException e) {
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        } catch (Exception e){
            LOG.error(e.getMessage(),e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
