package com.neoway.iot.simulator.common;

import com.neoway.iot.simulator.template.MetaTemplate;

import java.util.List;

/**
 * @desc: 链表实现
 * @author: 20200312686
 * @date: 2020/7/16 9:48
 */
public class SimLinkList {
    //当前节点
    private MetaTemplate node;
    //下一个节点列表
    private List<MetaTemplate> next;


}
