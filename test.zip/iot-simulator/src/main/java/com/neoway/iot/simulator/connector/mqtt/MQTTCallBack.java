package com.neoway.iot.simulator.connector.mqtt;

import org.eclipse.paho.client.mqttv3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @desc: MQTTCallBack
 * @author: 20200312686
 * @date: 2020/6/29 20:04
 */
public class MQTTCallBack implements MqttCallbackExtended {
    private static final Logger LOG = LoggerFactory.getLogger(MQTTCallBack.class);
    private MQTTClient mclient;
    private MqttAsyncClient client;
    private MQTTTopic topic;
    private MQTTConnector connector;
    public MQTTCallBack(MQTTClient client,MQTTTopic topic,MQTTConnector connector){
        this.mclient=client;
        this.topic=topic;
        this.client=mclient.getClient();
        this.connector=connector;
    }
    @Override
    public void connectComplete(boolean b, String s) {
        LOG.info("连接完成");
        try{
            LOG.info("重新订阅主题：topic={},name={},qos={}",topic.getTopic(),topic.getName(),topic.getQos());
            client.subscribe(topic.getTopic(),topic.getQos());
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
        }
    }
    @Override
    public void connectionLost(Throwable throwable) {
        LOG.info("失去连接：topic={},name={},qos={}",topic.getTopic(),topic.getName(),topic.getQos());
    }
    @Override
    public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
        String data=new String(mqttMessage.getPayload());
        LOG.info("收到订阅消息:{}",data);
    }
    @Override
    public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
        LOG.debug("失去连接：topic={},name={},qos={}",topic.getTopic(),topic.getName(),topic.getQos());
    }
}
