package com.neoway.iot.simulator.template;

import com.google.gson.Gson;
import com.neoway.iot.simulator.common.FreeMarkerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * @desc: 编排模板解析
 * @author: 20200312686
 * @date: 2020/7/16 9:44
 */
public class OrchestratorTemplate {
    private static final Logger LOG = LoggerFactory.getLogger(OrchestratorTemplate.class);
    private static final String TPL = "{\"protocol\":\"${template.protocol}\"," +
            "\"log\":\"${(template.log)! \"\"}\"," +
            "\"name\":\"${template.name}\"," +
            "\"id\":\"${template.id}\"," +
            "\"policy\":\"${(template.policy)! \"\"}\"," +
            "\"desc\":\"${(template.desc) ! \"\"}\"}";
    //产品域
    private String pro;
    //模板标识
    private String id;
    //模板名称
    private String name;
    //模板日志级别
    private String log;
    //header
    private MetaHeader header;
    //executor
    private String executor;

    public String getPro() {
        return pro;
    }

    public void setPro(String pro) {
        this.pro = pro;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public MetaHeader getHeader() {
        return header;
    }

    public void setHeader(MetaHeader header) {
        this.header = header;
    }

    public String getExecutor() {
        return executor;
    }

    public void setExecutor(String executor) {
        this.executor = executor;
    }

    /**
     * 解析模板文件
     *
     * @param f 模板
     * @return
     */
    public static OrchestratorTemplate build(File f, String pro) {
        try {
            SAXReader reader = new SAXReader();
            Document doc = reader.read(f);
            JSONObject data = XML.toJSONObject(doc.asXML());
            Map<String, Object> dataMap = new HashMap<>();
            dataMap = new Gson().fromJson(data.toString(), Map.class);
            String transValue = FreeMarkerTemplate.transform(TPL, dataMap);
            OrchestratorTemplate template = new Gson().fromJson(transValue, OrchestratorTemplate.class);
            if (StringUtils.isEmpty(template.getId())) {
                return null;
            }
            template.pro = pro;
            template.header = MetaHeader.build(dataMap);
            return template;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            LOG.error(f.getName(), e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
