package com.neoway.iot.simulator.connector;

/**
 * @desc: ConnectorType
 * @author: 20200312686
 * @date: 2020/6/30 15:59
 */
public enum ConnectorType {
    JT808,
    MQTT,
    RESTFUL;
}
