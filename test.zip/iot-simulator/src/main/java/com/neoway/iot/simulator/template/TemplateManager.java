package com.neoway.iot.simulator.template;

import com.neoway.iot.simulator.SimConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @desc: AbstractInput
 * @author: 20200312686
 * @date: 2020/6/23 16:10
 */
public class TemplateManager {
    private static final Logger LOG = LoggerFactory.getLogger(TemplateManager.class);
    private static final String MODEL_PATH="simulator.model";
    private static TemplateManager manager=null;
    private AtomicBoolean isStarted=new AtomicBoolean(false);
    private TemplateStorage storage=null;
    private Set<String> pros=new HashSet<>();
    //静默执行的模板队列
    private List<MetaTemplate> initTemplateQueue=new ArrayList<MetaTemplate>();
    private SimConfig env;
    private TemplateManager() {
        env=SimConfig.getInstance();
    }
    public static TemplateManager getInstance() {
        if (manager == null) {
            synchronized (TemplateManager.class) {
                if (manager == null) {
                    manager = new TemplateManager();
                }
            }
        }
        return manager;
    }

    public TemplateStorage getStorage() {
        return storage;
    }

    /**
     * @desc 系统启动阶段，加载本地的模型文件
     * @param env
     */
    public void start(Environment env){
        if(isStarted.get()){
            return;
        }
        this.storage=TemplateStorageMem.getInstance();
        String dir=String.valueOf(env.getProperty(MODEL_PATH));
        LOG.info("simulator.model={}",env.getProperty(MODEL_PATH));
        this.load(dir);

    }

    /**
     * @desc 模板加载
     * @param path 模板路径
     */
    private void load(String path){
        File dir=new File(path);
        if(!dir.exists()){
            try{
                LOG.info("模型包目录不存在:{}",path);
                dir.createNewFile();
                return;
            }catch (IOException e){
                LOG.error(e.getMessage(),e);
            }

        }
        initPro(dir);
        initTemplate();
    }

    /**
     * @desc 初始化产品域信息
     * @param dir
     * @return
     */
    private void initPro(File dir){
        File[] fs=dir.listFiles();
        if(null == fs || fs.length == 0){
            return;
        }
        for(File f:fs){
            pros.add(f.getAbsolutePath());
        }

    }

    /**
     * @desc 初始化模板
     */
    private void initTemplate(){
        for(String pro:pros){
            File f=new File(pro);
            if(!f.exists()){
                return;
            }
            File[] files=f.listFiles();
            for(File ff:files){
                if(ff.isDirectory()){
                    continue;
                }
                MetaTemplate template=MetaTemplate.build(ff,f.getName());
                this.storage.addTempate(template);
                if(template.getPolicy().equals(MetaTemplate.POLICY_INIT)){
                    this.initTemplateQueue.add(template);
                }
            }

        }
    }
}
