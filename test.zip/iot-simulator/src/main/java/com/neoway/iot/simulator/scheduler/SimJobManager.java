package com.neoway.iot.simulator.scheduler;

import com.google.gson.Gson;
import com.neoway.iot.simulator.SimConfig;
import com.neoway.iot.simulator.template.MetaHeader;
import com.neoway.iot.simulator.template.MetaTemplate;
import com.neoway.iot.simulator.template.TemplateManager;
import com.neoway.iot.simulator.template.TemplateStorage;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * @desc: 任务管理
 * @author: 20200312686
 * @date: 2020/7/14 19:13
 */
public class SimJobManager {
    private static final Logger LOG = LoggerFactory.getLogger(SimJobManager.class);
    private static SimJobManager manager=null;
    private List<SimJob> jobs=new ArrayList<>();
    private Map<SimJob,ScheduledExecutorService> schedulerMap=new HashMap<>();
    private SimJobManager() {

    }
    public static SimJobManager getInstance() {
        if (manager == null) {
            synchronized (SimJobManager.class) {
                if (manager == null) {
                    manager = new SimJobManager();
                }
            }
        }
        return manager;
    }
    /**
     * @desc 任务初始化
     */
    public void start(){
        TemplateStorage storage=TemplateManager.getInstance().getStorage();
        List<MetaTemplate> templates=storage.listAll();
        if(CollectionUtils.isEmpty(templates)){
            LOG.warn("没有初始化需要注册的任务");
            return;
        }
        for(MetaTemplate meta:templates){
            SimJob job=new SimJob(meta.getPro(),meta.getId(),meta.getName());
            MetaHeader header=meta.getHeader();
            String headerJson = header.transfter(null).trim();
            Gson gson=new Gson();
            Map<String,Object> policyMap=gson.fromJson(headerJson,Map.class);
            job.setInterval(Float.valueOf(policyMap.get("interval").toString()).intValue());
            job.setParams((Map<String, Object>) policyMap.get("params"));
            job.setAutoStart(meta.getPolicy().equals(MetaTemplate.POLICY_INIT));
            this.registerJob(job);
        }
    }

    public void startJobs(){
        for(SimJob job:jobs){
            if(job.isAutoStart()){
                this.startJob(job);
            }

        }
    }
    /**
     * @desc 任务注册
     */
    public void registerJob(SimJob job){
        this.jobs.add(job);
    }

    /**
     * @desc 任务启动
     * @param job
     */
    public void startJob(SimJob job){
        LOG.info("启动作业任务：作业ID={}，作业名称={}",job.getJobId(),job.getJobName());
        ScheduledExecutorService taskScheduler = Executors.newSingleThreadScheduledExecutor(
                (r) -> {
                    Thread t = new Thread(r, "Scheduler-"+job.getJobId());
                    t.setDaemon(true);
                    return t;
                }
        );
        taskScheduler.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                long begin=System.currentTimeMillis();
                try{
                    LOG.info("开始执行作业：countId={},作业详情={}",job.getCurrentCount(),new Gson().toJson(job));
                    int threadNum=Integer.valueOf(SimConfig.getInstance()
                            .getValue("simulator_channel_4g_thread","10").toString());
                    job.buildThreadPool(threadNum);
                    SimHandler handler=new SimHandler(job);
                    handler.execute();
                }catch (Exception e){
                    LOG.error(e.getMessage(),e);
                }finally {
                    job.close();
                    long end=System.currentTimeMillis();
                    long cost=(end-begin)/1000;
                    LOG.info("结束执行作业：countId={},作业ID={}，耗时(秒)={}",job.getCurrentCount(),job.getJobId(),cost);
                }

            }
        },0, job.getInterval(), TimeUnit.SECONDS);
        job.setJobStatus(SimJob.STATUS_STARTED);
        schedulerMap.put(job,taskScheduler);
        LOG.info("启动作业任务结束：作业ID={}，作业名称={}",job.getJobId(),job.getJobName());
    }

    /**
     * @desc 任务停止
     * @param job
     */
    public void stopJob(SimJob job){
        ScheduledExecutorService taskScheduler=schedulerMap.get(job);
        taskScheduler.shutdown();
        job.setJobStatus(SimJob.STATUS_STOPED);
        schedulerMap.put(job,taskScheduler);
    }

    /**
     * @desc 任务查询
     */
    public List<SimJob> queryJob(){
        return jobs;
    }

}
