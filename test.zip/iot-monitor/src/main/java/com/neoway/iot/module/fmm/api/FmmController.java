package com.neoway.iot.module.fmm.api;

import com.neoway.iot.common.HttpResult;
import com.neoway.iot.common.MonitorConstants;
import com.neoway.iot.common.MonitorException;
import com.neoway.iot.module.fmm.model.FmmCommand;
import com.neoway.iot.module.fmm.model.FmmMeta;
import com.neoway.iot.module.fmm.model.FmmModel;
import com.neoway.iot.module.fmm.model.page.FmmMetaSeachParams;
import com.neoway.iot.module.fmm.model.page.FmmSearchParamsPageOfAll;
import com.neoway.iot.module.fmm.service.FmmService;
import com.neoway.iot.util.MonitorPageHelper;
import com.neoway.iot.util.MonitorPageModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <pre>
 *  描述: 告警查询REST接口
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:20
 */
@RestController
@RequestMapping("/v1/fm")
@Slf4j
@Api(tags = "告警" , description = "告警管理接口：元数据、阈值设定、数据查询")
public class FmmController {

    @Autowired
    private FmmService fmmService;

    @ApiOperation("查询告警数据")
    @PostMapping("/data")
    public HttpResult<MonitorPageModel<FmmModel>> queryForList(@RequestBody FmmSearchParamsPageOfAll fmmSearchParamsPageOfAll) {
        try {
            if (fmmSearchParamsPageOfAll == null
                    || StringUtils.isEmpty(fmmSearchParamsPageOfAll.getInstanceId())
                    || fmmSearchParamsPageOfAll.getPageNum() == null
                    || fmmSearchParamsPageOfAll.getPageSize() == null) {
                return HttpResult.returnFail("参数存在问题！");
            }
            return HttpResult.returnSuccess("查询告警数据成功！", fmmService.queryForList(fmmSearchParamsPageOfAll));
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("告警详情查询")
    @GetMapping("/data/{instanceId}/{serialNo}")
    public HttpResult<FmmModel> queryForOne(@PathVariable("instanceId")String instanceId, @PathVariable("serialNo") long serialNo) {
        try {
            FmmModel fmmModel = fmmService.queryForOne(instanceId, serialNo);
            if (fmmModel == null) {
                return HttpResult.returnSuccess("暂无数据！", null);
            }
            return HttpResult.returnSuccess(fmmModel);
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("告警定义信息列表查询")
    @PostMapping("/metas")
    public HttpResult<MonitorPageModel<FmmMeta>> queryMetaForList(@RequestBody FmmMetaSeachParams fmmMetaSeachParams) {
        try {
            if (fmmMetaSeachParams == null || fmmMetaSeachParams.getPageNum() == null || fmmMetaSeachParams.getPageSize() == null) {
               return HttpResult.returnFail("参数存在问题！");
            }
            List<FmmMeta> metas = fmmService.queryForMetas();
            if (CollectionUtils.isEmpty(metas)) {
                return HttpResult.returnSuccess("暂无数据！", null);
            }

            return HttpResult.returnSuccess(MonitorPageHelper.pagination(metas,fmmMetaSeachParams.getPageSize(),fmmMetaSeachParams.getPageNum()));
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("告警定义信息详情查询")
    @GetMapping("/meta/{code}")
    public HttpResult<FmmMeta> queryMetaForOne(@PathVariable("code") long code) {
        try {
            FmmMeta fmmMeta = fmmService.queryForMetaForOne(code);
            if (fmmMeta == null) {
                return HttpResult.returnSuccess("暂无数据！", null);
            }
            return HttpResult.returnSuccess(fmmMeta);
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("告警操作")
    @PostMapping("/data/command")
    public HttpResult dataCommand(@RequestBody FmmCommand fmmCommand) {
        try {
            if (fmmCommand == null || CollectionUtils.isEmpty(fmmCommand.getItems())) {
                return HttpResult.returnFail("参数存在问题！");
            }
            if (!MonitorConstants.FmmCommandEnum.include(fmmCommand.getAction())) {
                return HttpResult.returnFail("不支持的指令操作！");
            }
            fmmService.dataCommand(fmmCommand);
            return HttpResult.returnSuccess();
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

    @ApiOperation("告警配置")
    @PostMapping("/meta/command")
    public HttpResult metaCommand() {
        return HttpResult.returnSuccess();
    }

}
