package com.neoway.iot.module.pmm.handler;

import com.neoway.iot.module.pmm.domain.PmDataQuery;
import com.neoway.iot.module.pmm.domain.PmDataRsp;

import java.util.List;

/**
 * @desc: 监控数据查询
 * @author: 20200312686
 * @date: 2020/7/30 14:41
 */
public interface PmDataHandler {
    List<PmDataRsp> compute(PmDataQuery query);
}
