package com.neoway.iot.module.fmm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 静态告警模型
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/07 10:00
 */
@Data
@ApiModel("静态告警模型")
public class FmmMeta implements Serializable {
    private static final long serialVersionUID = 137963158316437220L;
    @ApiModelProperty("code")
    private int code;
    @ApiModelProperty("产品域")
    private String ns;
    @ApiModelProperty("CI")
    private String ci;
    @ApiModelProperty("告警ID")
    private String alarmId;
    @ApiModelProperty("告警名称")
    private String alarmName;
    @ApiModelProperty("告警级别")
    private String alarmSeverity;
    @ApiModelProperty("告警类别")
    private String alarmCategory;
    @ApiModelProperty("告警可能原因")
    private String alarmCauseTxt;
    @ApiModelProperty("告警修复建议")
    private String alarmRepairTxt;
    @ApiModelProperty("告警业务影响")
    private String alarmEffectBusiness;
    @ApiModelProperty("告警设备影响")
    private String alarmEffectDevice;

}
