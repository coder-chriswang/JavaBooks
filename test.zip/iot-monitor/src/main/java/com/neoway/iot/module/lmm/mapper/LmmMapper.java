package com.neoway.iot.module.lmm.mapper;

import com.neoway.iot.module.lmm.model.LmmModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <pre>
 *  描述: Lmm管理Mapper
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:25
 */
@Mapper
public  interface LmmMapper {
    /**
     * 查询列表
     * @param tableName
     * @param from
     * @param to
     * @return
     */
    List<LmmModel> findAll(@Param("tableName") String tableName, @Param("from") long from, @Param("to") long to);

    /**
     * 根据instanceID查询列表
     * @param tableName
     * @param instanceId
     * @param from
     * @param to
     * @return
     */
    List<LmmModel> findAllByInstanceId(@Param("tableName") String tableName, @Param("instanceId") String instanceId, @Param("from") long from, @Param("to") long to);

}
