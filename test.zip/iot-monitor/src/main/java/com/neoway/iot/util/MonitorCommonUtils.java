package com.neoway.iot.util;

import com.google.common.base.Charsets;
import com.google.common.hash.Hashing;
import lombok.extern.slf4j.Slf4j;

import java.util.Base64;

/**
 * <pre>
 *  描述: Monitor通用工具类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/15 9:35
 */
@Slf4j
public class MonitorCommonUtils {

    /**
     * 获取数据库表名称
     * @param instanceId
     * @param partition
     * @param tableNamePrefix
     * @return
     */
    public static String getTableTable(String instanceId, int partition, String tableNamePrefix) {
        int bucket = Hashing.consistentHash(Hashing.md5().hashString(instanceId, Charsets.UTF_8),partition);
        return tableNamePrefix + "_" + bucket;
    }


    /**
     * Base64加密
     * @param data
     * @return
     */
    public static String encodeBase64(String data) {
        try {
            Base64.Encoder encoder = Base64.getEncoder();
            return new String(encoder.encode(data.getBytes()));
        } catch (Exception e) {
            log.error("Base64加密失败！", e);
            return "";
        }
    }

    /**
     * Base64解密
     * @param data
     * @return
     */
    public static String decodeBase64(byte[] data) {
        try {
            Base64.Decoder decoder = Base64.getDecoder();
            return new String(decoder.decode(data));
        } catch (Exception e) {
            log.error("Base64解密失败！", e);
            return "";
        }
    }

    public static void main(String[] args) {
        String s = "王超";
        String encodeStr = encodeBase64(s);
        log.info(encodeStr);
        String decodeStr = decodeBase64("eyJoZWFkZXIiOnsiaW1laSI6IjEwMDAwMDM5IiwiY21kSWQiOiJkYXRhUmVwb3J0In0sImJvZHkiOnsidGltZSI6IjIwMjAtMDctMjExMDozODoxMyIsImRhdGFPcGVyYXRlSW5mbyI6eyJwYWNrZXRzUnhDb3VudGVyIjo1MiwicGFja2V0c1R4Q291bnRlciI6NywicGFja2V0c0xvc3NDb3VudGVyIjo3NX0sInJhZGlvQ2VsbEluZm8iOnsibmV0TW9kZSI6IkxURSIsImx0ZVRBQyI6MjIsImx0ZVBDSSI6NiwibHRlQVJGQ04iOjg4LCJsdGVSU1JQIjp7Im1pblJTUlAiOjMwLCJhdmVyUlNSUCI6NDAsIm1heFJTUlAiOjE0fSwibHRlUlNSUSI6eyJtaW5SU1JRIjo4NiwiYXZlclJTUlEiOjYsIm1heFJTUlEiOjUzfSwibHRlU0lOUiI6eyJtaW5TSU5SIjo2NCwiYXZlclNJTlIiOjE0LCJtYXhTSU5SIjozMn0sImx0ZU5laWdoYm9yIjpbeyJQQ0kiOjIzLCJBUkZDTiI6MTMsImx0ZVJTUlAiOjY1LCJsdGVSU1JRIjo1NH1dLCJjdXJyZW50Q2VsbElEIjoyNCwiUExNTiI6IjQ2MDAxIn0sImRhdGFJbmZvIjpbeyJBUE4iOiIiLCJhdXRoVHlwZSI6IiIsIlBETlR5cGUiOiIiLCJkYXRhQ2FsbFR5cGUiOiIiLCJJUEluZm8iOnsiSVB2NCI6IiIsIklQdjYiOiIifX1dLCJzaW1JbmZvIjp7IklDQ0lEIjoiOTUiLCJ3b3JrVm90Ijo2Miwid29ya0JwcyI6NzQsIndyaXRlU0lNQ291bnRlciI6OTAsInJlYWRTSU1Db3VudGVyIjo2M30sInJhZGlvT3BlcmF0ZUluZm8iOnsiY2VsbEhPQ291bnRlciI6NTcsImNlbGxTZWxDb3VudGVyIjo0OSwiY2VsbE5laWdoYm9yTnVtYmVycyI6MjQsIkVQU0F0dGFjaCI6eyJNbVJlalZhbHVlIjowLCJHbW1SZWpWYWx1ZSI6MCwiU21SZWpWYWx1ZSI6MCwiRW1tUmVqVmFsdWUiOjAsIkVzbVJlalZhbHVlIjowfX0sImRldmljZUluZm8iOnsic29mdHdhcmVWZXJzaW9uIjoiUElQRUNMT1VEX1YwMyIsImhhcmR3YXJlVmVyc2lvbiI6Ik41Nl9TREsiLCJtb2RlVHlwZSI6Ik41NiJ9fX0=".getBytes());
        log.info(decodeStr);
    }
}
