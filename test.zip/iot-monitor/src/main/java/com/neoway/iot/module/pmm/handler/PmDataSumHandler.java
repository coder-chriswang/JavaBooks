package com.neoway.iot.module.pmm.handler;

import com.neoway.iot.module.pmm.domain.PmDataQuery;
import com.neoway.iot.module.pmm.domain.PmDataRsp;

import java.util.List;

/**
 * @desc: aggregator=avg
 * @author: 20200312686
 * @date: 2020/7/30 17:05
 */
public class PmDataSumHandler implements PmDataHandler{
    @Override
    public List<PmDataRsp> compute(PmDataQuery query) {
        return null;
    }
}
