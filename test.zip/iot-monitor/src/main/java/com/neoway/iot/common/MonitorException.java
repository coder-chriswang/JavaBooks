package com.neoway.iot.common;

/**
 * <pre>
 *  描述: 统一异常处理-继承RuntimeException
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/15 9:45
 */
public class MonitorException extends RuntimeException {
    private static final long serialVersionUID = 1533704113405490577L;
    public MonitorException(String message) {
        super(message);
    }
}
