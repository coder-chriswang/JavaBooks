package com.neoway.iot.module.pmm.handler;

/**
 * @desc: PmDataAbstractHandler
 * @author: 20200312686
 * @date: 2020/7/30 17:07
 */
public class PmDataAbstractHandler {
}
