package com.neoway.iot.module.pmm.mapper;

import com.neoway.iot.module.pmm.domain.PmMetaMetric;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @desc: PmmMapper
 * @author: 20200312686
 * @date: 2020/7/30 18:42
 */
@Mapper
public interface PmmMapper {
    /**
     * 查询性能元数据
     * @return
     */
    List<PmMetaMetric> queryMetas(@Param("start") int start, @Param("limit") int limit,@Param("metaMetric") PmMetaMetric metaMetric);
}
