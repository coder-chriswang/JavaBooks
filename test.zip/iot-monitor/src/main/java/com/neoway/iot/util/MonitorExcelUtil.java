package com.neoway.iot.util;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.event.AnalysisEventListener;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

/**
 * <pre>
 *  描述: Excel导出工具类
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2019/12/13 10:42
 */
public class MonitorExcelUtil {

    /**
     * 导出Excel
     *
     * @param response
     * @param fileName
     * @param sheetName
     * @param clazz
     * @param list
     * @throws Exception
     */
    public static void export(HttpServletResponse response, String fileName, String sheetName, Class clazz, List<?> list) throws Exception {
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        Date date = DateUtil.parse(DateUtil.now());
        fileName = URLEncoder.encode(fileName + DateUtil.format(date, DatePattern.PURE_DATETIME_FORMAT), "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
        EasyExcel.write(response.getOutputStream(), clazz).sheet(sheetName).doWrite(list);
    }

    /**
     * 导入Excel
     *
     * @param file
     * @param clazz
     * @param analysisEventListener
     * @throws Exception
     */
    public static void upload(MultipartFile file, Class clazz, AnalysisEventListener analysisEventListener) throws Exception {
        EasyExcel.read(file.getInputStream(), clazz, analysisEventListener).sheet().doRead();
    }
}
