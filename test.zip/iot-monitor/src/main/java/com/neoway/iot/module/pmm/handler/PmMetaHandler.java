package com.neoway.iot.module.pmm.handler;

import com.neoway.iot.module.pmm.domain.PmMetaMetric;
import com.neoway.iot.module.pmm.mapper.PmmMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @desc: 元数据查询
 * @author: 20200312686
 * @date: 2020/7/30 14:41
 */
@Service
public class PmMetaHandler {
    @Autowired
    private PmmMapper pmmMapper;

    public List<PmMetaMetric> queryMetas(int start,int limit,PmMetaMetric metaMetric){
        return pmmMapper.queryMetas(start,limit,metaMetric);
    }
}
