package com.neoway.iot.module.lmm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: LmmModel
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 10:13
 */
@Data
@ApiModel("位置模型")
public class LmmModel implements Serializable {
    private static final long serialVersionUID = 4151396374115170247L;

    @ApiModelProperty("instanceId")
    private String instanceId;

    @ApiModelProperty("经度")
    private String lat;

    @ApiModelProperty("纬度")
    private String lon;

    @ApiModelProperty("上报时间")
    private long ut;
}
