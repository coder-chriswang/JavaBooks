package com.neoway.iot.module.fmm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 告警操作元素
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/31 13:28
 */
@Data
@ApiModel("告警操作元素")
public class FmmCommandItem implements Serializable {
    private static final long serialVersionUID = -8413525384996709857L;

    @ApiModelProperty("资源instanceId")
    private String instanceId;

    @ApiModelProperty("告警序列号")
    private long serialNo;
}
