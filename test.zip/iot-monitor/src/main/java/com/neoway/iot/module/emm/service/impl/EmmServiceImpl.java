package com.neoway.iot.module.emm.service.impl;


import com.neoway.iot.common.MonitorException;
import com.neoway.iot.module.emm.mapper.EmmMapper;
import com.neoway.iot.module.emm.model.EmmModel;
import com.neoway.iot.module.emm.model.page.EmmSearchParamsPageOfAll;
import com.neoway.iot.module.emm.service.EmmService;
import com.neoway.iot.util.MonitorCommonUtils;
import com.neoway.iot.util.MonitorExcelUtil;
import com.neoway.iot.util.MonitorPageHelper;
import com.neoway.iot.util.MonitorPageModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

import static com.neoway.iot.common.MonitorConstants.EM_TABLE_NAME_PREFIX;

/**
 * <pre>
 *  描述: EmmServiceImpl
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:22
 */
@Service
@Slf4j
public class EmmServiceImpl implements EmmService {

    @Value("${emm.mysql.table.count}")
    private String emmTableCount;

    @Autowired
    private EmmMapper emmMapper;

    @Override
    public MonitorPageModel<EmmModel> queryForList(EmmSearchParamsPageOfAll emmSearchParamsPageOfAll) {
        try {
            String tableName = MonitorCommonUtils.getTableTable(emmSearchParamsPageOfAll.getInstanceId(), Integer.valueOf(emmTableCount), EM_TABLE_NAME_PREFIX);
            return MonitorPageHelper.pagination(transformEventInfo(emmMapper.findAll(tableName, emmSearchParamsPageOfAll)), emmSearchParamsPageOfAll.getPageSize(), emmSearchParamsPageOfAll.getPageNum());
        } catch (Exception e) {
            log.error("查询事件信息失败！", e);
            throw new MonitorException("查询事件失败！");
        }
    }

    @Override
    public EmmModel queryForOne(String instanceId, long eventNo) {
        try {
            String tableName = MonitorCommonUtils.getTableTable(instanceId, Integer.valueOf(emmTableCount), EM_TABLE_NAME_PREFIX);
            EmmModel emmModel = emmMapper.findByNo(tableName, eventNo);
            if (emmModel == null) {
                return null;
            }
            String eventInfo = emmModel.getEventInfo();
            emmModel.setEventInfo(MonitorCommonUtils.decodeBase64(eventInfo.getBytes()));
            return emmModel;
        } catch (Exception e) {
            log.error("查询事件详情失败！", e);
            throw new MonitorException("查询事件详情失败！");
        }
    }

    @Override
    public void exportExcel(EmmSearchParamsPageOfAll searchCondition, HttpServletResponse response) {
        List<EmmModel> result = this.queryForList(searchCondition).getRecords();
        try {
            MonitorExcelUtil.export(response, "EventData", "事件", EmmModel.class, result);
        } catch (Exception e) {
            log.error("导出失败！", e);
        }
    }

    private List<EmmModel> transformEventInfo(List<EmmModel> emmModelList) {
        if (CollectionUtils.isEmpty(emmModelList)) {
            return null;
        }
        for (EmmModel emmModel : emmModelList) {
            String eventInfo = emmModel.getEventInfo();
            emmModel.setEventInfo(MonitorCommonUtils.decodeBase64(eventInfo.getBytes()));
        }
        return emmModelList;
    }
}
