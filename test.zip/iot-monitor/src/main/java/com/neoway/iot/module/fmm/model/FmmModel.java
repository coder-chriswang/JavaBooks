package com.neoway.iot.module.fmm.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: FmmModel
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/30 19:12
 */
@Data
@ApiModel("告警模型")
public class FmmModel implements Serializable {
    private static final long serialVersionUID = -1024924388500384211L;

    @ApiModelProperty("告警序列号")
    private long serialNo;

    @ApiModelProperty("告警ID")
    private String alarmId;

    @ApiModelProperty("instanceId")
    private String instanceId;

    @ApiModelProperty("instanceName")
    private String instanceName;

    @ApiModelProperty("CI")
    private String ci;

    @ApiModelProperty("告警名称")
    private String alarmName;

    @ApiModelProperty("告警等级")
    private String alarmSeverity;

    @ApiModelProperty("告警类别")
    private String alarmCategory;

    @ApiModelProperty("告警产生原因")
    private String alarmCauseTxt;

    @ApiModelProperty("告警修复建议")
    private String alarmRepairTxt;

    @ApiModelProperty("告警可能的商业影响")
    private String alarmEffectBusiness;

    @ApiModelProperty("告警可能的设备影响")
    private String alarmEffectDevice;

    @ApiModelProperty("告警来源")
    private String alarmSource;

    @ApiModelProperty("告警产生时间")
    private long alarmSt;

    @ApiModelProperty("告警结束时间")
    private long alarmEt;

    @ApiModelProperty("告警状态")
    private int alarmStatus;

    @ApiModelProperty("告警描述")
    private String alarmDesc;

    @ApiModelProperty("设备唯一标识")
    private String nativeId;

    @ApiModelProperty("租户ID")
    private String tenantId;

    @ApiModelProperty("告警次数")
    private int alarmCount;
}
