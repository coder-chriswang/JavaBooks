package com.neoway.iot.module.pmm.domain;

/**
 * @desc: 阈值规则
 * @author: 20200312686
 * @date: 2020/7/30 14:08
 */
public class PmMetaRule {
    //指标编码
    private String code;
    //发生检测周期
    private int operiod;
    //发生检测门限
    private int othreahold;
    //触发动作
    private String oaction;
    //关闭检测周期
    private int cperiod;
    //关闭阈值门限
    private int cthreahold;
    //关闭触发动作
    private String caction;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getOperiod() {
        return operiod;
    }

    public void setOperiod(int operiod) {
        this.operiod = operiod;
    }

    public int getOthreahold() {
        return othreahold;
    }

    public void setOthreahold(int othreahold) {
        this.othreahold = othreahold;
    }

    public String getOaction() {
        return oaction;
    }

    public void setOaction(String oaction) {
        this.oaction = oaction;
    }

    public int getCperiod() {
        return cperiod;
    }

    public void setCperiod(int cperiod) {
        this.cperiod = cperiod;
    }

    public int getCthreahold() {
        return cthreahold;
    }

    public void setCthreahold(int cthreahold) {
        this.cthreahold = cthreahold;
    }

    public String getCaction() {
        return caction;
    }

    public void setCaction(String caction) {
        this.caction = caction;
    }
}
