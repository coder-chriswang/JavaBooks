package com.neoway.iot.common;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 统一返回data中封装的实参
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:20
 */
@Data
@ApiModel("统一返回data中封装的实参")
public class MonitorResponse implements Serializable {
    private static final long serialVersionUID = -8485864202813795555L;
}
