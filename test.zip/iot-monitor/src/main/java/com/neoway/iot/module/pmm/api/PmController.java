package com.neoway.iot.module.pmm.api;

import com.neoway.iot.common.HttpResult;
import com.neoway.iot.module.emm.service.EmmService;
import com.neoway.iot.module.pmm.domain.PmDataQuery;
import com.neoway.iot.module.pmm.domain.PmDataRsp;
import com.neoway.iot.module.pmm.domain.PmMetaMetric;
import com.neoway.iot.module.pmm.domain.PmMetaRule;
import com.neoway.iot.module.pmm.handler.PmMetaHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 *  描述: 性能查询REST接口
 *  1、第一阶段，按照具体查询方式输出数据
 *  2、第二阶段，整合ES API模式，统一通用调用接口，此部分需要抽象OUTPUT data模型，涉及业务对象整合
 *  3、或者，后续各业务查询，封装ES API
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:20
 */
@RestController
@RequestMapping("/v1/pm")
@Api(tags = "监控",description = "监控管理接口：元数据、阈值规则、数据查询")
public class PmController {
    private static final Logger LOG = LoggerFactory.getLogger(PmController.class);
    @Autowired
    private PmMetaHandler metaHandler;

    @ApiOperation("监控元数据列表查询")
    @PostMapping("/metas")
    public HttpResult<List<PmMetaMetric>> queryMetas(@RequestParam(value="start",defaultValue = "0") int start,
                                                     @RequestParam(value="limit",defaultValue = "20") int limit,
                                                     @RequestBody PmMetaMetric metric) {
        try{
            List<PmMetaMetric> metrics=metaHandler.queryMetas(start,limit,metric);
            return HttpResult.returnSuccess(metrics);
        }catch (Exception e){
            LOG.error(e.getMessage(),e);
            return HttpResult.returnFail("查询失败！");
        }

    }

    @ApiOperation("监控元数据详情查询")
    @GetMapping("/meta/{code}")
    public HttpResult<List<PmMetaMetric>> getMeta(@PathVariable("code") String code) {
        return null;
    }

    @ApiOperation("监控阈值规则设置")
    @PostMapping("/meta/rule")
    public HttpResult<List<PmMetaRule>> setMetaRule(@RequestBody PmMetaRule param) {
        return null;
    }
    @ApiOperation("监控阈值规则查询")
    @GetMapping("/meta/rule/{code}")
    public HttpResult<PmMetaRule> getMetaRule(@PathVariable("code") String code) {
        return null;
    }
    @ApiOperation("监控阈值规则删除")
    @DeleteMapping("/meta/rule/{code}")
    public HttpResult deleteMetaRule(@PathVariable("code") String code) {
        return null;
    }
    @ApiOperation("监控聚合函数查询")
    @GetMapping("/data/aggregators")
    public HttpResult<List<String>> queryAggregators() {
        return null;
    }
    @ApiOperation("监控数据查询")
    @PostMapping("/data")
    public HttpResult<List<PmDataRsp>> queryData(@RequestBody PmDataQuery param) {
        return null;
    }
}
