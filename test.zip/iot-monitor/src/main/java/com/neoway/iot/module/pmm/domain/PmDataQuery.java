package com.neoway.iot.module.pmm.domain;

import java.util.List;

/**
 * @desc: 监控数据查询条件。语义与opentsdb一致（opentsdb的query接口的裁剪版）
 * @author: 20200312686
 * @date: 2020/7/30 14:23
 */
public class PmDataQuery {
    private int st;
    private int et;
    private List<PmDataQuerySub> queries;

    public int getSt() {
        return st;
    }

    public void setSt(int st) {
        this.st = st;
    }

    public int getEt() {
        return et;
    }

    public void setEt(int et) {
        this.et = et;
    }

    public List<PmDataQuerySub> getQueries() {
        return queries;
    }

    public void setQueries(List<PmDataQuerySub> queries) {
        this.queries = queries;
    }
}
