package com.neoway.iot.module.pmm.domain;

import java.util.Map;

/**
 * @desc: PmDataQuerySub
 * @author: 20200312686
 * @date: 2020/7/30 14:26
 */
public class PmDataQuerySub {
    //聚合方式
    private String aggregator;
    private String metric;
    private Map<String,Object> tags;
    //下采样 采样时间-采样方式-补值策略。 <interval><units>-<aggregator>[-<policy>]  例如 1h-max-zero
    private String downsample;

    public String getAggregator() {
        return aggregator;
    }

    public void setAggregator(String aggregator) {
        this.aggregator = aggregator;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public Map<String, Object> getTags() {
        return tags;
    }

    public void setTags(Map<String, Object> tags) {
        this.tags = tags;
    }
}
