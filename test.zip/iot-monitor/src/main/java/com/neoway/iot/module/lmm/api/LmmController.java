package com.neoway.iot.module.lmm.api;

import com.neoway.iot.common.HttpResult;
import com.neoway.iot.common.MonitorException;
import com.neoway.iot.module.lmm.model.LmmModel;
import com.neoway.iot.module.lmm.model.page.LmmSearchParamsPageOfAll;
import com.neoway.iot.module.lmm.service.LmmService;
import com.neoway.iot.util.MonitorPageModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <pre>
 *  描述: 位置查询REST接口
 *  1、第一阶段，按照具体查询方式输出数据
 *  2、第二阶段，整合ES API模式，统一通用调用接口，此部分需要抽象OUTPUT data模型，涉及业务对象整合
 *  3、或者，后续各业务查询，封装ES API
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:20
 */
@RestController
@RequestMapping("/v1/lm")
@Slf4j
@Api(tags = "位置轨迹" , description = "位置轨迹管理接口：数据查询")
public class LmmController {
    @Autowired
    private LmmService lmmService;

    @ApiOperation("查询位置轨迹")
    @PostMapping("/data")
    public HttpResult<MonitorPageModel<LmmModel>> queryForList(@RequestBody LmmSearchParamsPageOfAll lmmSearchParamsPageOfAll) {
        try {
            if (lmmSearchParamsPageOfAll == null
                    || StringUtils.isEmpty(lmmSearchParamsPageOfAll.getInstanceId())
                    || lmmSearchParamsPageOfAll.getPageNum() == null
                    || lmmSearchParamsPageOfAll.getPageSize() == null) {
                return HttpResult.returnFail("参数存在问题！");
            }
            return HttpResult.returnSuccess(lmmService.queryForList(lmmSearchParamsPageOfAll));
        } catch (MonitorException e) {
            return HttpResult.returnFail(e.getMessage());
        }
    }

}
