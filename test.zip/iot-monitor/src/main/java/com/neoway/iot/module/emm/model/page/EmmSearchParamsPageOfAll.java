package com.neoway.iot.module.emm.model.page;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * <pre>
 *  描述: 分页查询参数
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/16 14:07
 */
@Data
@ApiModel("事件查询参数")
public class EmmSearchParamsPageOfAll implements Serializable {
    private static final long serialVersionUID = 2217046179528264957L;

    @ApiModelProperty("开始时间")
    private long from;

    @ApiModelProperty("结束时间")
    private long to;

    @ApiModelProperty("时间条件类别，默认为0，选择发生置1，选择结束置2")
    private Integer timeType;

    @ApiModelProperty("当前页")
    private Integer pageNum;

    @ApiModelProperty("页行数")
    private Integer pageSize;

    @ApiModelProperty("事件ID")
    private String eventId;

    @ApiModelProperty("事件名称")
    private String eventName;

    @ApiModelProperty("事件分类(OM,Device)")
    private String eventCategory;

    @ApiModelProperty("事件类型(System,Operate)")
    private String eventType;

    @ApiModelProperty("事件级别(Major,Normal)")
    private String eventSeverity;

    @ApiModelProperty(value = "实例资源ID",required = true)
    private String instanceId;
}
