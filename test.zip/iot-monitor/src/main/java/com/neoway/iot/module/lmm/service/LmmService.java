package com.neoway.iot.module.lmm.service;

import com.neoway.iot.module.lmm.model.LmmModel;
import com.neoway.iot.module.lmm.model.page.LmmSearchParamsPageOfAll;
import com.neoway.iot.util.MonitorPageModel;

/**
 * <pre>
 *  描述:LmmService
 * </pre>
 *
 * @author Chris(wangchao)
 * @version 1.0.0
 * @date 2020/07/04 13:22
 */
public interface LmmService {
    /**
     * 查询返回列表
     * @param lmmSearchParamsPageOfAll
     * @return
     */
    MonitorPageModel<LmmModel> queryForList(LmmSearchParamsPageOfAll lmmSearchParamsPageOfAll);

}
